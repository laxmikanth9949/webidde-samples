// eslint
const config = module.exports = {
    "env": {
        "browser": true,
        "es2021": true,
        "node": true,
        "qunit": true,
        "jquery": true
    },
    "extends": [
        "eslint:recommended"
    ],
    "overrides": [
    ],
    "parserOptions": {
        "ecmaVersion": "latest",
        "sourceType": "module"
    },
    "rules": {
        "indent": [
            "error",
            4,
            {
                "SwitchCase": 1,
                "flatTernaryExpressions": false,
                "offsetTernaryExpressions": false,
                "ignoreComments": false
            }
        ],
        "linebreak-style": [
            "error",
            "unix"
        ],
        "operator-linebreak": [
            "error",
            "before"
        ],
        "quotes": [
            "error",
            "double"
        ],
        "semi": [
            "error",
            "always"
        ],
        "no-extra-semi": [
            "error"
        ],
        "semi-spacing": [
            "error",
            {
                "before": false,
                "after": true
            }
        ],
        "semi-style": [
            "error",
            "last"
        ],
        "eqeqeq": [
            "error",
            "smart"
        ],
        "no-multi-spaces": "error",
        "block-spacing": [
            "error",
            "always"
        ],
        "func-call-spacing": [
            "error",
            "never"
        ],
        "keyword-spacing": [
            "error",
            {
                "before": true,
                "after": true
            }
        ],
        "space-before-blocks": [
            "error",
            "always"
        ],
        "switch-colon-spacing": [
            "error"
        ],
        "arrow-spacing": [
            "error"
        ],
        "brace-style": [
            "error",
            "1tbs",
            {
                "allowSingleLine": false
            }
        ],
        "no-var": ["error"],
        "no-dupe-else-if": [
            "error"
        ],
        "no-else-return": [
            "error"
        ],
        "no-lonely-if": [
            "error"
        ],
        "curly": ["error"],
        "spaced-comment": [
            "error"
        ],
        "array-bracket-spacing": [
            "error"
        ],
        "no-whitespace-before-property": [
            "error"
        ],
        "template-curly-spacing": [
            "error",
            "never"
        ],
        "object-curly-spacing": [
            "error",
            "never"
        ],
        "no-dupe-keys": [
            "error"
        ],
        "accessor-pairs": [
            "error"
        ],
        "no-useless-computed-key": [
            "error"
        ],
        "comma-style": ["error", "last"],
        "space-before-function-paren": [
            "error",
            "never"
        ],
        "space-infix-ops": [
            "error",
            {
                "int32Hint": false
            }
        ],
        "space-unary-ops": [
            2, {
                "words": true,
                "nonwords": false
            }],
        "quote-props": ["error", "as-needed"]
    },
    "globals": {
        "sap": true,
        "QUnit": true,
        "jQuery": true,
        "sinon": true,
        "$": true,
        "adobe": true,
        "CoveoHeadless": true
    }
};
/* eslint-disable no-undef */
import path from "node:path";
import {fileURLToPath} from "node:url";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
import {mockData, mockRequest} from "@forme/mockserver/helper";


export default [

    {
        method: "GET",
        path: "coveo/UserContext",
        handle: function(req, res) {
            setTimeout(() => {
                res.send(mockData("userContext.json", __dirname));
            }, 3000);
        }
    },

    {
        method: "POST",
        path: "support/Translate",
        handle: function(req, res) {
            res.send(mockData("support.Translate.json", __dirname));
        }
    },

    {
        method: "POST",
        path: "support/CaseCreateCaseSolution",
        handle: function(req, res) {
            res.send(mockData("support.CaseCreateRecommendedSolutions.json",__dirname));
        }
    },

    {
        method: "GET",
        path: "support/SystemSpecificNotes",
        handle: function(req, res) {
            res.send(mockData("support.SystemSpecificNotes.json",__dirname));
        }
    },

    {
        method: "POST",
        path: "support/MultiSystemSpecificNotes",
        handle: function(req, res) {
            res.send(mockData("support.MultiSystemSpecificNotes.json",__dirname));
        }
    },

    {
        method: "PUT",
        path: "support/CaseUpdateVerticle",
        handle: function(req, res) {
            res.send(mockData("support.UpdateCaseSuccess.json", __dirname));
        }
    },

    {
        method: "PUT",
        path: "support/UserProfile",
        handle: function(req, res) {
            res.send(mockData("support.UpdateProfileSuccess.json", __dirname));
        }
    },

    {
        method: "GET",
        path: "support/CaseCreateProductW7?:resultType",
        handle: function(req, res) {
            switch (req.query.resultType) {
                case "List":
                    res.send(mockData("support.CaseCreateProductW7ProductFunctionList.json", __dirname));
                    break;
                case "Tree":
                    res.send(mockData("support.CaseCreateProductW7ProductFunctionTree.json", __dirname));
                    break;
                default:
                    res.send(mockData("support.CaseCreateProductW7ProductList.json", __dirname));
            }
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateProductAndProductFunctionW7",
        handle: function(req, res) {
            // Ariba system
            if (req.query["$filter"]?.includes("000000000740812801")) {
                res.send(mockData("support.CaseCreateProductAndProductFunctionW7.Ariba.json", __dirname));
                return;
            }
            // S/4HANA system
            if (req.query["$filter"]?.includes("000000000850151225")) {
                res.send(mockData("support.CaseCreateProductAndProductFunctionW7.hana.json", __dirname));
                return;
            }
            // Default
            res.send(mockData("support.CaseCreateProductAndProductFunctionW7.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateProductPrediction",
        handle: function(req, res) {
            res.send(mockData("support.CaseCreateProductPrediction.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateProductFunctionPrediction",
        handle: function(req, res) {
            res.send(mockData("support.CaseCreateProductFunctionPrediction.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateHotAndTrendingW7",
        handle: function(req, res) {
            res.send(mockData("support.CaseCreateHotAndTrending.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/ChannelRecommender",
        handle: function(req, res) {
            res.send(mockData("support.ChannelRecommender.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseSubmitAuthW7Verticle",
        handle: function(req, res) {
            res.send(mockData("support.CaseSubmitAuthW7Verticle.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateComponentW7",
        handle: function(req, res) {
            res.send(mockData("support.CaseCreateComponentW7.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateCompPredictionSetW7",
        handle: function(req, res) {
            res.send(mockData("support.CaseCreateCompPredictionSetW7.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseF4HelpW7Verticle",
        handle: function(req, res) {
            if (req.query["$filter"]?.includes("SYSTEM_RECENT")) {
                res.send(mockData("support.F4HelpW7System.json", __dirname));
            } else {
                res.send(mockData("support.F4HelpW7.json", __dirname));
            }
        }
    },
    {
        method: "GET",
        path: "support/CaseCreationSACVerticle",
        handle: function(req, res) {
            if (req.query.requestType === "initialCall" && req.query.productFunctionPath === "0000010000-0000000313-0000000876-0000001006-0000001014") {
                res.send(mockData("support.CaseCreationSACVerticle.init.json", __dirname));
                return;
            }
            if (req.query.requestType === "treeNode") {
                switch (req.query.nodeId) {
                    case "105670":
                        res.send(mockData("support.CaseCreationSACVerticle.105670.json", __dirname));
                        return;
                    case "105674":
                        res.send(mockData("support.CaseCreationSACVerticle.105674.json", __dirname));
                        return;
                    case "105678":
                        res.send(mockData("support.CaseCreationSACVerticle.105678.json", __dirname));
                        return;
                    case "105671":
                        res.send(mockData("support.CaseCreationSACVerticle.105671.json", __dirname));
                        return;
                    case "105686":
                        res.send(mockData("support.CaseCreationSACVerticle.105686.json", __dirname));
                        return;
                    case "105687":
                        res.send(mockData("support.CaseCreationSACVerticle.105687.json", __dirname));
                        return;
                    case "105692":
                        res.send(mockData("support.CaseCreationSACVerticle.105692.json", __dirname));
                        return;
                }
            }
            res.send({});
        }
    },
    {
        method: "GET",
        path: "support/TimeZoneConfigCacheVerticle",
        handle: function(req, res) {
            res.send(mockData("support.TimeZoneConfigCache.json", __dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateIntentService",
        handle: function(req, res) {
            if (req.query.systemId === "000000000740812801" && req.query.productId === "67838200100800005703") {
                res.send(mockData("support.CaseCreateIntentService.json", __dirname));
                return;
            }
            res.send({});
        }
    },
    {
        method: "POST",
        path: "support/QuerySLAObjectVerticle",
        handle: function(req, res) {
            res.send(mockData("support.QuerySLAObjectVerticle.json",__dirname));
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateAribaGuidedAnswer",
        handle: function(req, res) {
            switch (req.query.nodeId) {
                case "1437":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.1437.json", __dirname));
                    return;
                case "54":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.54.json", __dirname));
                    return;
                case "47":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.47.json", __dirname));
                    return;
                case "48":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.48.json", __dirname));
                    return;
                case "15":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.15.json", __dirname));
                    return;
                case "26":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.26.json", __dirname));
                    return;
                case "37":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.37.json", __dirname));
                    return;
                case "12":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.12.json", __dirname));
                    return;
                case "11":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.11.json", __dirname));
                    return;
                case "49":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.49.json", __dirname));
                    return;
                case "40":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.40.json", __dirname));
                    return;
                case "41":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.41.json", __dirname));
                    return;
                case "13":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.13.json", __dirname));
                    return;
                case "17":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.17.json", __dirname));
                    return;
                case "52":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.52.json", __dirname));
                    return;
                case "53":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.53.json", __dirname));
                    return;
                case "24":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.24.json", __dirname));
                    return;
                case "25":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.25.json", __dirname));
                    return;
                case "27":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.27.json", __dirname));
                    return;
                case "28":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.28.json", __dirname));
                    return;
                case "29":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.29.json", __dirname));
                    return;
                case "21":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.21.json", __dirname));
                    return;
                case "22":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.22.json", __dirname));
                    return;
                case "23":
                    res.send(mockData("support.CaseCreateAribaGuidedAnswer.23.json", __dirname));
                    return;
            }
            res.send({});
        }
    },
    {
        method: "GET",
        path: "support/CaseSystemAllInfo",
        handle: function(req, res) {
            res.send({
                "Sysnr": "000000000850006913",
                "Pointer": "000000000000000000000000",
                "Uname": "S0024587324",
                "ConnectionOpen": false,
                "AccessDataMaintained": false,
                "AccessDataRestricted": false,
                "AccessDataAuthorized": true,
                "AccessDataError": "",
                "SecureAreaURL": "",
                "ConnectionJSON": "[]",
                "DssClassified": "X",
                "RampUpFlag": "X"
            });
        }
    },
    {
        method: "GET",
        path: "support/CaseCreateCompMapToProductW7",
        handle: function(req, res) {
            let data;
            if (req.query["$filter"]?.includes("CX") || req.query["$filter"]?.includes("XX-PART-MFS-QUC")) {
                data = [];
            } else {
                data = mockData("support.CaseCreateCompMapToProductW7.json", __dirname);
            }
            res.send(data);
        }
    },
    {
        method: "GET",
        path: "common/SupportProxy/odata/svt/systemdatasrv/SystemSoftWS4MSet",
        handle: function(req, res) {
            const data = mockData("support.SystemSoftWS4MSet.json", __dirname);
            if (req.query["$filter"]?.includes("000000000850641080")) {
                data.d.results[0].SOFTWAREVALUE = "SAP S/4HANA Cloud";
                data.d.results[0].ProdNumber = "67837800100800007389";
            }
            res.send(data);
        }
    },
    {
        method: "GET",
        path: "support/CasePermissionW7Verticle",
        handle: function (req, res) {
            if (req.query["action"]?.includes("COMPLETE")) {
                const data = mockData("support.CasePermissionCompleteW7.json", __dirname);
                res.send(data);
            }
        }
    },

    {
        method: "GET",
        path: "common/SupportProxy/odata/svt/systemdatasrv/SystemTypeSet(:sysId)",
        handle: function(req, res) {
            let data = mockData("support.CloudSystemType.json", __dirname);
            if (req.params.sysId.includes("000000000850641080")) {
                data = mockData("support.OnPremiseSystemType.json", __dirname);
            }
            res.send(data);
        }
    },

    {
        method: "GET",
        path: "support/CaseCreateInstallationW7",
        handle: function(req, res) {
            //CLOUD
            let data = mockData("support.CloudInstallationRelation.json", __dirname);
            //ONPREM
            if (req.param('InstallationNbr') === "0090119716") {
                data = mockData("support.OnPremiseInstallationRelation.json", __dirname);
            }
            res.send(data);
        }
    },



    mockRequest ("CaseScheduleAnExpertCard", "caseScheduleAnExpertCard.json", __dirname),
    mockRequest ("CaseScheduleAManagerCard", "caseScheduleAManagerCard.json", __dirname),
    //no service for this mock data
    mockRequest ("ServiceDeliveryStatusCard", "serviceDeliveryStatusCard.json", __dirname),
    mockRequest ("contactsSectionCard", "contactsSectionCard.json", __dirname),
    mockRequest ("contractDetails", "contractDetails.json", __dirname),
    mockRequest ("premiumengagement", __dirname),
    mockRequest ("support/HecServiceRequest", "support.HecServiceRequest.json", __dirname),
    mockRequest ("support/ServiceRequest", "support.ServiceRequest.json", __dirname),
    mockRequest ("support/HECDeploymentData", "support.HECDeploymentData.json", __dirname),
    mockRequest ("support/AdvanceCustomerService", "support.AdvanceCustomerService.json", __dirname),
    mockRequest ("support/HecCustomerContractType", "support.HecCustomerContractType.json", __dirname),
    mockRequest ("support/StoredPasswords", "support.StoredPasswords.json", __dirname),
    mockRequest ("support/ecsWorkspaceCard", __dirname),
    mockRequest ("support/IncidentsAlert", "support.IncidentsAlertCard.json", __dirname),
    mockRequest ("support/serviceCatalogCard", __dirname),
    mockRequest ("supportEngagementCard", "supportEngagementCard.json", __dirname),
    mockRequest ("supportmaintenance", __dirname),
    mockRequest ("support/CaseValidationVerticle", "support.CaseValidationVerticle.json", __dirname),
    mockRequest ("support/PGContractType", "support.PGContractType.json", __dirname),
    mockRequest ("support/SystemSearchFilterItemsVerticle", "support.SystemSearchFilterItems.json", __dirname)
    ,mockRequest ("support/CaseCreateProductAndProductFunctionW7", "support.CaseCreateProductAndProductFunctionW7.json", __dirname)
    ,mockRequest ("support/UserProfile", "support.UserProfile.json", __dirname)
    ,mockRequest ("support/CaseContactsList", "support.CaseContactsList.json", __dirname)
    ,mockRequest ("support/SystemSearch", "support.SystemSearch.json", __dirname)
    ,mockRequest ("support/CaseContactsW7Verticle", "support.CaseContactsW7Verticle.json", __dirname)
    ,mockRequest ("support/CustomerInfoVerticle", "support.CustomerInfo.json", __dirname)
    ,mockRequest ("support/EventCardStatusFilter", "support.EventCardStatusFilter.json", __dirname)
    ,mockRequest ("support/CaseMessageDSSW7Verticle", "support.CaseMessageDSSW7Verticle.json", __dirname)
    ,mockRequest ("support/CaseSystemInfoVerticle", "support.CaseSystemInfoVerticle.json", __dirname)
    ,mockRequest ("support/CaseUpdateW7Verticle", "support.CaseUpdateW7Verticle.json", __dirname)
    ,mockRequest ("support/CaseList", "support.CaseListVerticle.json", __dirname)
    ,mockRequest ("support/CaseCreationRampUpSet", "support.CaseCreationRampUpSet.json", __dirname)
    ,mockRequest ("support/TranslationTextsVerticle", "support.TranslationTextsVerticle.json", __dirname)
    ,mockRequest ("support/CaseQualtricsAuthW7", "support.CaseQualtricsAuthW7.json", __dirname)
    ,mockRequest ("support/CaseUpdateVerticle", "support.CaseUpdateVerticle.json", __dirname)
    ,mockRequest ("support/CaseDetailsW7Verticle", "support.CaseDetailsW7Verticle.json", __dirname)
    ,mockRequest ("support/CaseClassifiedCheckW7Verticle", "support.CaseClassifiedCheckW7Verticle.json", __dirname)
    ,mockRequest ("support/CaseCreateIntentService", "support.CaseCreateIntentService.json", __dirname)
    ,mockRequest ("support/CaseCreateAribaGuidedAnswer", "support.CaseCreateAribaGuidedAnswer.json", __dirname)
    ,mockRequest ("support/CaseNotification", "support.CaseNotification.json", __dirname)
    ,mockRequest ("support/CaseListUserPersonalization", "support.CaseListUserPersonalization.json", __dirname)
    ,mockRequest ("support/IncidentInstSet", "support.IncidentInstSet.json", __dirname)
    ,mockRequest ("support/CasePrioritySet", "support.CasePrioritySet.json", __dirname)
    ,mockRequest ("support/CaseStatusSet", "support.CaseStatusSet.json", __dirname)
    ,mockRequest ("support/CaseSystemSet", "support.CaseSystemSet.json", __dirname)
    ,mockRequest ("support/EmsFetchEntitlements", "support.Entitlements.json", __dirname)
    ,mockRequest ("support/IncidentReporterSet", "support.IncidentReporterSet.json", __dirname)
    ,mockRequest ("support/CaseAttachmentsW7Verticle", "support.CaseAttachmentsW7.json", __dirname)
    ,mockRequest ("support/CaseCreateCompProductSearchSetW7", "support.CaseCreateCompProductSearchSetW7.json", __dirname)
];

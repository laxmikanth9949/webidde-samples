/* eslint-env node */
const puppeteer = require("puppeteer");
const fs = require("fs");
const path = require("path");
process.env.CHROMIUM_BIN = puppeteer.executablePath();

var browser = "ChromiumHeadless",
    bSingleRun = true;
function isDebug(argument) {
    "use strict";
    return argument === "--debug";
}
function isGithub(argument) {
    return argument === "--github"
}

if (process.argv.some(isDebug)) {
    browser = "ChromeDebugging";
    bSingleRun = false;
}

if (process.argv.some(isGithub)) {
    browser = "ChromiumHeadlessGithub";
}

const skipSuccessUTMessageInGithubAction = browser === "ChromiumHeadlessGithub";

function getTestFiles(testDir = "webapp/test") {
    const dirPath = path.join(__dirname, testDir);
    const testFiles = [];
    function getFiles(dirPath) {
        const files = fs.readdirSync(dirPath);
        for (const file of files) {
            const filePath = path.join(dirPath, file);
            const stat = fs.statSync(filePath);
            if (stat.isDirectory()) {
                getFiles(filePath);
            } else {
                if (file.toLowerCase().endsWith("test.js")) {
                    testFiles.push(filePath);
                }
            }

        }
    }

    getFiles(dirPath); // [/xxx/xx/webapp/test/**/*test.js]

    const shortFileList = testFiles.map(file => {
        const short = file.replace(__dirname, "");
        if (short.startsWith("/")) {
            return short.substring(1);
        }
        return short;
    });

    return shortFileList; // ["webapp/test/xxx.js", "webapp/test/yyy.js"]

}

const testFiles = getTestFiles("webapp/test");

module.exports = function (config) {
    "use strict";

    config.set({
        frameworks: ["ui5", "qunit", "sinon"],
        basePath: "./",
        ui5: {
            type: "application",
            paths: {
                webapp: "webapp",
            },
            mode: "script",
            config: {
                bindingSyntax: "complex",
                compatVersion: "edge",
                async: true,
                resourceroots: {
                    "sap.me.apps.supportgetsupport": "./base/webapp"
                }
            },
            tests: testFiles
        },

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: false,

        // start these browsers
        browsers: [browser],
        browserConsoleLogOptions: {
            level: "info",
            format: "%b %T: %m",
            terminal: false
        },

        // you can define custom flags
        customLaunchers: {
            ChromiumHeadlessLargeDesktop: {
                base: "ChromiumHeadless",
                flags: ["--disable-web-security", "--disable-site-isolation-trials", "--window-size=1440,1080", "--no-sandbox"]
            },
            ChromeDebugging: {
                base: "Chrome",
                flags: [
                    "--remote-debugging-port=9333",
                    "--auto-open-devtools-for-tabs"
                ]
            },
            ChromiumHeadlessGithub: {
                base: 'ChromeHeadless',
                flags: ['--no-sandbox']
            }
        },

        plugins: [
            require('karma-coverage'),
            require('karma-junit-reporter'),
            require('karma-spec-reporter'),
            require('karma-ui5'),
            require('karma-qunit'),
            require('karma-sinon'),
            require('karma-chrome-launcher')
        ],
        preprocessors: {
            "webapp/**/*.js": ["coverage"]
        },
        coverageReporter: {
            includeAllSources: true,
            reporters: [
                {
                    type: "cobertura",
                    dir: "./target/jscoverage",
                    subdir: "/./",
                    file: "supportgetsupport-cobertura-coverage.xml"
                },
                { "type": "text" },
                { "type": "html" }
            ]
        },
        junitReporter: {
            outputDir: "./target/surefire-reports",
            outputFile: "supportgetsupport.unitTests.qunit.xml",
            suite: "",
            useBrowserName: false
        },
        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_INFO,

        reporters: ["spec", "coverage", "junit"],
        specReporter: {
            maxLogLines: 300,            // limit number of lines logged per test
            suppressFailed: false,      // do not print information about failed tests
            suppressPassed: skipSuccessUTMessageInGithubAction,      // do not print information about passed tests
            suppressSkipped: true,      // do not print information about skipped tests
            showSpecTiming: false       // print the time elapsed for each spec
        },
        singleRun: bSingleRun
    });
};
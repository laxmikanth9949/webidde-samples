import Controller from "sap/ui/core/mvc/Controller";


export default class GetSupport extends Controller {
    onInit() {
    }
}
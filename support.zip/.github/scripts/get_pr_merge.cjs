const path = require("path");
const fs = require("fs");
const os = require("os");

const hook_url = "https://sap.webhook.office.com/webhookb2/16386ebe-7d82-43fe-ab5c-b305e5102830@42f7676c-f455-423c-82f6-dc2d99791af7/IncomingWebhook/4bdd45dbc58147e1b11b764d12864fb9/f47fe018-b71a-4e91-bd7d-3e86173006e2";

async function getData(link) {
    const token = process.env.TOKEN;
    console.log("get data start", link)
    const res = await fetch(link, {
        headers: {
            Accept: "application/vnd.github+json",
            Authorization: `Bearer ${ token }`,
            "X-GitHub-Api-Version": "2022-11-28"
        }
    })
    console.log("get data end", link)
    return await res.json()
}

function getPRConfig() {
    try {
        const pr = JSON.parse(process.env.PR_CONTEXT);
        const pr_link = pr.url;
        const pr_number = pr_link.split("/").pop();
        const pr_commits = pr_link + "/commits";
        const prs_url = pr_link.replace(pr_number, "");

        return {
            pr,
            pr_link,
            pr_number,
            pr_commits_link: pr_commits,
            prs_url
        }
    } catch (e) {
        console.log("get pr config error: ", e)
        return null;
    }
}

async function getPRNumberInPRCommits(config) {
    try {
        const data = await getData(config.pr_commits_link);
        const commits = data.map(item => item.commit);
        const commitMessages = commits.map(item => item.message);
        const prs = [];
        for (const msg of commitMessages) {
            const reg = /#\d+/;
            const match = msg.match(reg)?.[0];
            if (match) {
                prs.push(match.replace("#", ""))
            }
        }
        return prs;
    } catch {
        return [];
    }
}

async function getPRDetails(config, pr_numbers) {
    const pr_links = pr_numbers.map(num => config.prs_url + num);
    const arr = [];
    for (const link of pr_links) {
        arr.push(getData(link));
    }
    return Promise.allSettled(arr).then(res => {
        return res.filter(item => item.status === "fulfilled").map(item => item.value)
    }).then(pr_datas => {
        return pr_datas.map(data => {
            return {
                html_url: data.html_url,
                number: data.number,
                title: data.title,
                user: data.user.url
            }
        })
    })
}

/**
 *
 * @param key {string}
 * @param val {string}
 */
function setOutput(key, val) {
    // fs.appendFileSync(process.env.GITHUB_OUTPUT, `${key}=${val}${os.EOL}`)
}

function generateTitle(config) {
    const componentVersion = fs.readFileSync(path.join(__dirname, "../../VERSION"), "utf-8");
    return `deploy dev to test v${componentVersion} [#${config.pr_number}](${config.pr.html_url})`;
}

async function generateContent(data) {

    function isTranslation(email) {
        return /corp_service-tip-git/.test(email)
    }

    const msgs = [];
    const users = {};

    for (const item of data) {
        let msg = `- ${item.title} [#${item.number}](${item.html_url})`;
        try {
            if (!users[item.user]) {
                users[item.user] = await getData(item.user);
            }
            const user = users[item.user];
            if (isTranslation(user.email)) {
                msgs.push(msg);
                continue;
            }
            const full = ` create by <at>${user.name}</at>`
            msg += full;
        } catch (e) {
            console.log("get user failed: ", item.user);
        }
        msgs.push(msg);
    }

    return {
        message: msgs.join("\n "),
        users: Object.values(users).filter(item => !isTranslation(item.email))
    };
}

function generateTeamsCardContent(title, message, users, pr_html_url, pr_number, versions) {
    const userMentions = users.map(user => {
        return {
            "type": "mention",
            "text": `<at>${user.name}</at>`,
            "mentioned": {
                "id": user.email,
                "name": user.name
            }
        }
    })

    const versionContent = {
        "type": "FactSet",
        "facts": []
    };
    for (const landscape in versions) {
        const fact = {
            title: landscape,
            value: versions[landscape]
        }
        versionContent.facts.push(fact);
    }
    return {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": null,
                "content": {
                    "type": "AdaptiveCard",
                    "body": [
                        {
                            "type": "TextBlock",
                            "size": "Medium",
                            "weight": "Bolder",
                            "text": title
                        },
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": message,
                                            "wrap": true,
                                            "size": "Medium"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "TextBlock",
                            "size": "Medium",
                            "weight": "Bolder",
                            "text": "Versions"
                        },
                        versionContent
                    ],
                    "msteams": {
                        "entities": userMentions
                    },
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.5",
                    "actions": [
                        {
                            "type": "Action.OpenUrl",
                            "title": `open #${pr_number}`,
                            "url": pr_html_url
                        }
                    ]
                }
            }
        ]
    }
}

async function postMessageToTeams(cardTemplate) {
    const raw = JSON.stringify(cardTemplate);
    await fetch(hook_url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: raw,
        redirect: "follow"
    }).then(res => {
        // console.log("hhhhhhh", res)
    });
}

async function getVersionDataFromDeploymentRepo() {
    const url = "https://github.wdf.sap.corp/api/v3/repos/forme/deployment/contents/landscapes/$LAND_SCAPE/component-versions.yml";
    const landscapes = {
        canary: "canary",
        stage: "stage",
        prod: "factory"
    }
    const defaultVersion = "NO_VERSION";
    const versions = {}
    for (const landscape in landscapes) {
        versions[landscape] = defaultVersion;
        try {
            const requestUrl = url.replace("$LAND_SCAPE", landscapes[landscape]);
            const res = await getData(requestUrl);
            const data = Buffer.from(res.content, "base64").toString("utf-8");
            const support_version = data.split("\n").find(item => /support/.test(item));
            const version = support_version.split(":")[1].trim()
            versions[landscape] = version;
        } catch (e) {
            console.log("get version from ", landscape, " error: ", e);
        }
    }
    return versions;
}



async function main() {
    const config = getPRConfig();
    if (!config) {
        return
    }

    const pr_numbers = await getPRNumberInPRCommits(config);
    console.log("pr_numbers", pr_numbers);
    if (!pr_numbers?.length) {
        return
    }
    const pr_datas = await getPRDetails(config, pr_numbers);
    const messageTitle = generateTitle(config);
    setOutput("messageTitle", messageTitle);

    const content = await generateContent(pr_datas);
    setOutput("messageContent", content.message)
    const versions = await getVersionDataFromDeploymentRepo()
    const cardTemplate = generateTeamsCardContent(messageTitle, content.message, content.users, config.pr.html_url, config.pr_number, versions);
    await postMessageToTeams(cardTemplate);
    console.log(JSON.stringify(cardTemplate))

    // console.log("pr_datas", pr_datas)
}

main()
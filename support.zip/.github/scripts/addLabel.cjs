const request = require("./requests.cjs");
const path = require("path");

function getArgs() {
    const args = process.argv.slice(2);
    return args.reduce((acc, arg) => {
        let [key, value] = arg.split("=");
        key = key.replace("--", "");
        acc[key] = value;
        return acc;
    }, {});
}

const labels = {
    reviewed: "Reviewed",
    needReview: "need review",
    needAdjustment: "Need adjustment",
    titleTag: "titleTag",
    version: "version",
}

function getPRTagByTitle(title) {
    const [titleTag, titleContent] = title.split(":");
    const tag = titleTag.trim().toLowerCase();
    switch (tag) {
        case "fix":
            return "bug";
    }
    return tag;

}

async function main() {
    const args = getArgs();
    const label = args.label;
    if (!label) {
        console.log("Please provide label to add");
        return;
    }
    switch (label) {
        case "reviewed":
            await request.removeLabel(labels.needReview);
            await request.removeLabel(labels.needAdjustment);
            await request.addLabels([labels.reviewed])
            break;
        case "needReview":
            await request.removeLabel(labels.reviewed);
            await request.removeLabel(labels.needAdjustment);
            await request.addLabels([labels.needReview])
            break;
        case "needAdjustment":
            await request.removeLabel(labels.reviewed);
            await request.removeLabel(labels.needReview);
            await request.addLabels([labels.needAdjustment])
            break;
        case "titleTag":{
            const tag = getPRTagByTitle(request.getPRConfig().pr.title);
            if (tag === "bug") {
                await request.addLabels([tag]);
                return;
            }
            const allLabels = await request.getAllLabels();
            const lowLabels = allLabels.map(tag => tag.name.toLowerCase());
            console.log(lowLabels)
            console.log("tag", tag)
            const index = lowLabels.indexOf(tag.trim().toLowerCase());
            console.log("tag2", index)
            if(index === -1){
                return;
            }
            console.log("tag3", allLabels[index])
            await request.addLabels([allLabels[index].name]);
        }
            break;
        case "version": {
            const pkg = path.join(__dirname, "../../package.json");
            const content = require(pkg);
            const labels = await request.getPRLabels();
            const versionLabels = labels.map(tag => tag.name).filter(tag => {
                if (/\d+\.\d+\.\d+/.test(tag)) {
                    const versions = tag.split(".");
                    if (versions.length !== 3) {
                        return false;
                    }
                    return versions.every(version => !isNaN(Number(version)));
                }
            });

            for (const v of versionLabels) {
                if (v == content.version) {
                    continue;
                }
                await request.removeLabel(v);
            }
            if (!versionLabels.includes(content.version)) {
                await request.addLabels([content.version]);
            }
        }
            break;
        default:
            console.log("Label not found");
    }
}

main();

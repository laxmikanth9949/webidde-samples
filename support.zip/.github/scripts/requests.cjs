function getRequestHeader() {
    const token = process.env.TOKEN;
    return {
        Accept: "application/vnd.github+json",
        Authorization: `Bearer ${ token }`,
        "X-GitHub-Api-Version": "2022-11-28"
    }
}

function getPRConfig() {
    try {
        const pr = JSON.parse(process.env.PR_CONTEXT);
        const pr_link = pr.url;
        const pr_number = pr_link.split("/").pop();
        const pr_commits = pr_link + "/commits";
        const prs_url = pr_link.replace(pr_number, "");

        return {
            pr,
            pr_link,
            pr_number,
            pr_commits_link: pr_commits,
            prs_url
        }
    } catch (e) {
        console.log("get pr config error: ", e)
        return null;
    }
}

async function getReviewers() {
    const config = getPRConfig();
    const link = config.pr_link + "/requested_reviewers";
    return fetch(link, {
        headers: {
            ...getRequestHeader()
        }
    }).then(res => res.json())
}

/**
 *
 * @param type {"team"| "user"}
 * @param name
 * @returns {Promise<*>}
 */
async function addReviewers(type, name="panacea") {
    const reviewers = await getReviewers();
    const teamReviewers = reviewers.teams.map(team => team.name);
    const userReviewers = reviewers.users.map(user => user.login);
    if (teamReviewers.includes("panacea") && type === "team") {
        return;
    }
    if (userReviewers.includes("panacea") && type === "user") {
        return;
    }
    const pr = getPRConfig();
    const link = pr.pr_link + "/requested_reviewers";
    const key = type === "team" ? "team_reviewers" : "reviewers";
    const body = {
        [key]: [name]
    }
    return fetch(link, {
        method: "POST",
        headers: {
            ...getRequestHeader()
        },
        body: JSON.stringify(body)
    }).then(res => res.json())
}

async function getPRLabels() {
    const config = getPRConfig();
    const link = config.pr._links.issue.href + "/labels";
    return fetch(link, {
        headers: {
            ...getRequestHeader()
        }
    }).then(res => res.json())
}

async function addLabels(labels) {
    const config = getPRConfig();
    const link = config.pr._links.issue.href + "/labels";
    const body = {
        labels
    }
    return fetch(link, {
        method: "POST",
        headers: {
            ...getRequestHeader()
        },
        body: JSON.stringify(body)
    }).then(res => res.json())
}

async function removeLabel(label) {
    const config = getPRConfig();
    const link = config.pr._links.issue.href + `/labels/${label}`;
    return fetch(link, {
        method: "DELETE",
        headers: {
            ...getRequestHeader()
        },
    }).then(res => res.json())
}

async function getAllLabels() {
    const config = getPRConfig();
    const link = config.pr.base.repo.url + "/labels";
    return fetch(link, {
        headers: {
            ...getRequestHeader()
        }
    }).then(res => res.json())
}

module.exports = {
    getPRConfig,
    addReviewers,
    getPRLabels,
    addLabels,
    removeLabel,
    getAllLabels
}




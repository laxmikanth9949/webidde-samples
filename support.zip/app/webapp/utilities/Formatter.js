sap.ui.define([
    'sap/me/apps/support/utilities/i18nWrapper',
    'sap/ui/core/LocaleData',
    'sap/ui/core/format/DateFormat',
    "sap/base/security/sanitizeHTML"
], (i18nWrapper,LocaleData,DateFormat,sanitizeHTML) => {
    const _oResourceBundle = i18nWrapper.init();

    const formatter = {
        priorityStatus: (sPriority) => {
        if (sPriority === '1' || sPriority === '2') return 'Error'; // 1 Very High 2 High
        return 'None'; // 3 Medium 4 Low
        },

        installationNameTxt: (sInstallationTxt) => {
            const arr = sInstallationTxt.split("-");
            const txt = arr.slice(1);
            return txt.join("-");
        },

        installationIdTxt: (sInstallationTxt) => {
            return sInstallationTxt.split("-")[0];
        },

        customerNameTxt: (sCustomerNametxt) => {
            const arr = sCustomerNametxt.split("-");
            const txt = arr.slice(1);
            return txt.join("-");
        },

        componentDescription: (sCompTxt, sCompKey) => {
        return sCompTxt + '\n' +' ('+sCompKey+')';
        },

        sapNumberandSapYear: (sSapNumber, sSapYear) => {
            return sSapNumber + '/'+ sSapYear;
        },

        priority: (sId, sTxt) => {
        return sId + ' - ' + sTxt;
        },

        systemDescription: (sTxt, sKey) => {
        return sTxt ;
        },

        dateFormat(sDate) {
            let sDateF = "";
            if (sDate !== null && sDate !== "") {
                let dDate = new Date(sDate);
                sDateF = dDate.toLocaleDateString() + '\n' + ' at ' + dDate.toLocaleTimeString() ;
            }
            return sDateF;
        },

        autoConfirmDateSeparator(sDateIn) {
            let sDate = sDateIn;
            let dummyDate = new Date("2023-01-09");
            let sDummyDate = dummyDate.toLocaleDateString();
            if (sDummyDate.includes(".") && sDate.includes("/")) {
                sDate = sDate.replaceAll("/",".");
            }  else if (sDummyDate.includes("/") && sDate.includes(".")) {
                sDate = sDate.replaceAll(".","/");
            }
            return sDate;
        },

        datesAt: (sDate, sTime) => {
            const _oLocaleData = LocaleData.getInstance(sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale());
            const oLocalTimeFormat = DateFormat.getDateTimeInstance({pattern:  _oLocaleData.getTimePattern("medium")});
            const oDateFormatTime = DateFormat.getDateTimeInstance({pattern: "HH:mm:ss"});

            return sDate ? sDate + '\n' + (sTime ? oLocalTimeFormat.format(oDateFormatTime.parse(sTime)) : ''): String();
        },

        AaEPTimeFormat: (dateString) => {
            const sDate = new Date(dateString);
            const _oLocaleData = LocaleData.getInstance(sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale());
            const oLocalDateFormat = DateFormat.getDateTimeInstance({pattern:  _oLocaleData.getDatePattern("medium")});

            return oLocalDateFormat.format(sDate);
        },


        getI18nText: (sText, columnKey) => {
            if (!sText) {
                return "";
            }  else if (sText === i18nWrapper.getText(_oResourceBundle, sText, [])) {
                // fallback logic for customers who stores the legacy parameters which can't be consumed with the updated text/key pairs
                return i18nWrapper.getText(_oResourceBundle, columnKey, []);
            } else {
                return i18nWrapper.getText(_oResourceBundle, sText, []);
            };
        },
        formatCasesCount: (count,sText) => {
        if (typeof count === 'undefined'){ count = 0 }
        return sText+' ('+count+')';
        },

        getBtnFavIcon: (bFavorite) => {
            return bFavorite ? "sap-icon://favorite" : "sap-icon://unfavorite";
        },
        formatCaseDiscussionText: (sText,RespITSM) => {
            const escapeMap = {
                "&lt;": "<",
                "&gt;": ">",
                "&amp;": "&",
                "&nbsp;": " ",
                "&#43;": "+",
                "&#39;": "'",
                "&cent;": "¢",
                "&pound;": "£",
                "&yen;": "¥",
                "&copy;": "©",
                "&reg;": "®",
                "&deg;": "°",
                "&ndash;": "-",
                "&mdash;": "—",
                "&radic;": "√",
                "&quot;": "\""
            };

            let html = formatter._removeUnsupportedThings(sText);

            if(RespITSM?.toUpperCase() === "BCP"){
                html = html.replace(/&\S+?;/g, function(str) {
                    if (!escapeMap[str]) {
                        console.log(`Unsupported tag: ${str} Please add this tag to escapeMap`);
                    }
                    return escapeMap[str] || str;
                });
            }

            const sanitizeOption = {
                uriRewriter: function(url) {
                    return url;
                }
            };

            return sanitizeHTML(`<div class="sapUiCasePreviewHTMLMemo">${html}</div>`, sanitizeOption);
        },

        toggleCloseCaseBtn: (isCanClose, caseSource, statusId) => {
            if (isCanClose && (caseSource !== "BCP" || statusId === "5")) {
                return true;
            }
            return false;
        },
        formatCaseDiscussionDateTimeUser: (sDateTime, sIsSAPAgent) => {
            return sDateTime;
        },
        formatPOCaseID: (sNumber, sYear) => {
            return sNumber + ' / ' + sYear;
        },
        formatPODate: (sDateTime) => {
            const dateTime = new Date(sDateTime).toLocaleString(undefined,{hour12:false,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit"});
            const [raw, month, day, year, h, m, s] = /(\d{2})\/(\d{2})\/(\d{4}), (\d{2}):(\d{2}):(\d{2})/g.exec(dateTime);
            return `${year}/${month}/${day} at ${h}:${m}:${s}`;
        },
        formatPOInstallation: (sInstTxt, sInstId) => {
            const arr = sInstTxt.split("-");
            const txt = arr.slice(1);
            return txt.join("-") + ' (' + sInstId + ')';
        },
        formatPOComponent: (sCompTxt, sCompKey) => {
            return sCompTxt + ' (' + sCompKey + ')';
        },

    };

    formatter._removeUnsupportedThings = function (sText) {
        [
            "[code]", "[/code]", // SAP4METRANSFORMERS-476 why originalText is surrounded with [code] ?
            "[Code]","[/Code]"
        ].forEach(s => {
            sText = sText.replaceAll(s, "");
        });
        return sText;
    };

    /**
     * @description if the Auto Confirm date is Today or in the future return true
     */
    formatter.checkAutoConfirmDate = function (autoConfirmDate) {
        if (autoConfirmDate) {
            const year = new Date().getFullYear().toString();
            const month = (new Date().getMonth() + 1).toString().padStart(2, "0");
            const day = new Date().getDate().toString().padStart(2, "0");
            const todayTimestamp = year + month + day;
            return autoConfirmDate >= todayTimestamp;
        }
        return  false;
    }

    return formatter;
});

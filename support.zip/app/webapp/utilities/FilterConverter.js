sap.ui.define([], function () {
  'use strict';
  return {
   convertLastUpdateFilter: function(lastUpdateFilterString) {

                  var fromDay, toDay;

                  switch (lastUpdateFilterString) {

                      case "TODAY":
                          fromDay = 0;
                          toDay = 1;
                          break;

                      case "THISWEEK":
                          fromDay = -7;
                          toDay = 1;
                          break;

                      case "NOTTHISWEEK":
                          fromDay = -3650;
                          toDay = -7;
                          break;

                      case "WITHINLAST4WEEKS":
                          fromDay = -28;
                          toDay = 1;
                          break;

                      case "OLDERTHAN4WEEKS":
                          fromDay = -3650;
                          toDay = -28;
                          break;

                      case "WITHINLAST1DAY":
                          fromDay = -1;
                          toDay = 1;
                          break;

                      case "WITHINLAST2DAYS":
                          fromDay = -2;
                          toDay = 1;
                          break;

                      case "ALL":

                      case "":

                      default:

                          fromDay = -3650;  // 10 years
                          toDay = 1;
                          break;

                  }

                  var todayDate = new Date();

                  var iYear = todayDate.getUTCFullYear();
                  var iMonth = todayDate.getUTCMonth();
                  var iDate = todayDate.getUTCDate();

                  var todayLocalDate = new Date(iYear, iMonth, iDate);

                  var todayLocalDateEpoch = Date.parse(todayLocalDate);

                  var msxDay = (60 * 60 * 24 * 1000);  // milliseconds in a day

                  var fromDayMs = fromDay * msxDay;

                  var fromDayLocalEpoch = (todayLocalDateEpoch + fromDayMs);

                  var toDayLocalEpoch = (Date.parse(todayDate) + (toDay* msxDay));

                  var newTimeWindowParameter = "((updatedAt%20ge%20" + fromDayLocalEpoch + ")%20and%20(updatedAt%20le%20" + toDayLocalEpoch + "))";

                  return {newTimeWindowParameter,fromDayLocalEpoch,toDayLocalEpoch};
              },

        /*
        this returns incorrect dates  -1 day in some timezones

         convertDatesFilter: function(date) {
                      var iYear = date.getUTCFullYear();
                      var iMonth = date.getUTCMonth();
                      var iDate = date.getUTCDate();
                      var LocalDate = new Date(Date.UTC(iYear, iMonth, iDate));
                      var LocalDateEpoch = Date.parse(LocalDate);
                      return LocalDateEpoch;
         }
         */

        convertDatesFilter: function (sDate) {

            let x = null, y = null;

            try {
                x = new Date(sDate);
                y = Number(x);
                y = isNaN(y) ? null : y;
                y = (y === undefined) ? null : y + (sDate.getTimezoneOffset() * 60 * 1000 * -1);
            } catch {
                // not a valid date
                y = null;
            }

            return y;
        }

    };
  });
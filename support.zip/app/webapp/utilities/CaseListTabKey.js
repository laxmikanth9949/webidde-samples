sap.ui.define([], function() {

    "use strict";

    return Object.freeze({
        ALL_OPEN : "ALL_OPEN",
        MY_OPEN : "MY_OPEN",
        ALL_CLOSED : "ALL_CLOSED",
        DRAFTS : "DRAFTS",
        RESULTS : "RESULTS",
        SES : "SES",
        FAV : "FAV",
        AUTO_CONFIRM: "AUTO_CONFIRM"
    });

});

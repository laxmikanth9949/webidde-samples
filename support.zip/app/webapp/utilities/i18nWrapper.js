sap.ui.define(['sap/ui/model/resource/ResourceModel'], (ResourceModel) => {
  return {
    /**
     * Initialize Resource Bundle
     * @returns {sap.base.i18n.ResourceBundle}
     */
    init: () => {
      let sResourceUrl;
      sResourceUrl = sap.ui.require.toUrl('sap/me/apps/support/i18n');
      sResourceUrl = sResourceUrl + '/i18n.properties';
      const sLocale = sap.ui.getCore().getConfiguration().getLanguage();
      const oResourceModel = new ResourceModel({
        bundleUrl: sResourceUrl,
        bundleLocale: sLocale,
      });
      return oResourceModel.getResourceBundle();
    },

    /**
     * Wraps the i18n resource bundle to expose the get text method.
     *
     * NOTE: This should be avoided where possible in favour of the
     * BaseController getText method or XML. However, having it as a standalone
     * function, means it can be used in the Formatter and TablePersonalization
     * without passing the app context.
     *
     * @function
     * @public
     * @param {object} oResourceBundle
     * @param {string} sProperty - Name of i18n entry
     * @param {string[]} aArgs - Name of i18n entry
     * @returns {string} the resourceModel of the component
     */
    getText: (oResourceBundle, sProperty, aArgs) => {
      return oResourceBundle.getText(sProperty, aArgs);
    },
  };
});

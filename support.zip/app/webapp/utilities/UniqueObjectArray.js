sap.ui.define([], function () {
  'use strict';

  return {
    /**
     * Similar to https://lodash.com/docs/#uniqBy, but only accept a `String` as the key of object
     * Creates a duplicate-free version of an object array, in which only the first occurrence of each element is kept
     * with the uniqueness computed with the specified key of the object
     *
     * @param {Array} array The array to inspect.
     * @param {String} objectKey The key of the object
     * @returns {Array} Returns the new duplicate-free array.
     */

    get: function (array, objectKey) {
      let // to indicate which is duplicated
        duplicatedFlags = {},
        distinct = []; // the new duplicate-free array
      array.forEach(function (elem, idx) {
        const objectValue = elem[objectKey];
        if (duplicatedFlags[objectValue] !== true) {
          distinct.push(elem);
        }
        // add a k-v pair, objectValue as the key,
        duplicatedFlags[objectValue] = true;
      });
      return distinct;
    },
  };
});

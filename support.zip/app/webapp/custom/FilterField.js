sap.ui.define(
  ['sap/m/InputBase', 'sap/ui/core/IconPool'],
  (InputBase, IconPool) => {
    /**
     * Use case is similar to SearchField, however the icon appears as a filter.
     * @public
     * @returns {sap.m.InputBase}
     */
    return InputBase.extend('casemanagement.custom.FilterField', {
      metadata: {
        events: {
          endButtonPress: {},
          liveChange: {
            parameters: {
              value: { type: 'string' },
            },
          },
        },
      },

      /**
       * Initialializes the CustomFilterField
       * @function
       * @public
       * @override
       */
      init: function () {
        InputBase.prototype.init.apply(this, arguments);
        this.addEndIcon({
          id: this.getId() + '-searchBtn',
          src: IconPool.getIconURI('filter'),
          noTabStop: true,
          press: this._onEndButtonPress.bind(this),
        });
        InputBase.prototype.onkeyup = function (oEvent) {
          const sValue = this.$('inner').val() || '';
          this.fireLiveChange({
            value: sValue,
          });
        };
      },

      /**
       * Handles the filter icon button press event
       * @function
       * @private
       */
      _onEndButtonPress: function () {
        if (this.getEnabled() && this.getEditable()) {
          this.fireEndButtonPress({});
        }
      },

      /**
       * Returns the current value of the input (CustomFilterField)
       * @function
       * @public
       * @returns {string}
       */
      getLiveValue: function () {
        return this.$('inner').val() || '';
      },

      renderer: 'sap.m.InputBaseRenderer',
    });
  },
);

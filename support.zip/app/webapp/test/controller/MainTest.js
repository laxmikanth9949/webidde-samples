sap.ui.define([
		"sap/ui/core/UIComponent",
		"sap/ui/core/mvc/Controller",
		"sap/me/apps/support/controller/Main.controller",
		"sap/me/apps/support/controller/FilterHandler",
		"sap/me/apps/support/utilities/i18nWrapper",
		"sap/ui/core/routing/Router",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/resource/ResourceModel",
		"sap/ui/core/mvc/View",
		"sap/ui/base/ManagedObject",
		"sap/me/shared/Models",
		'sap/ui/comp/smartvariants/SmartVariantManagement',
		'sap/ui/comp/filterbar/FilterBar'
	],

	function (UIComponent,
	Controller,
	MainController,
	FilterHandler,
	i18nWrapper,
	Router,
	JSONModel,
	ResourceModel,
	View,
	ManagedObject,
	SharedModels,
	SmartVariantManagement,
	FilterBar) {
		"use strict";

		QUnit.module("CaseList", {
            before: function () {
                this.sandbox = sinon.createSandbox ();
            },
			beforeEach: function () {
				this.oView = new View({});
				this.oMain = new MainController();
				this.oFilter = new FilterHandler();
				this.oMain._FilterHandler = new FilterHandler();
				this.oMain._smv = new SmartVariantManagement();
				this.oMain._i18nWrapper = i18nWrapper.init();
				this.oMain._filterBar = new FilterBar();
			    this.oMain._filterBar.setModel(new JSONModel (),"$this.fb");
			    var value = {};
			    value.CaseStatusSet = [];
			    value.CaseStatusSet=[{"statusId":"1","statusTxt":"Not Sent to SAP"},{"statusId":"C","statusTxt":"Sent to SAP"},{"statusId":"5","statusTxt":"Customer Action"},{"statusId":"S","statusTxt":"In Processing by SAP"},{"statusId":"3","statusTxt":"SAP Proposed Solution"},{"statusId":"R","statusTxt":"Pending Release"},{"statusId":"M","statusTxt":"Sent to SAP Partner"},{"statusId":"N","statusTxt":"Partner-Customer Action"},{"statusId":"8","statusTxt":"Confirmed"},{"statusId":"Z","statusTxt":"Confirmed Automatically"}];
			    this.oMain._filterBar.getModel("$this.fb").setProperty("/statusAll", value.CaseStatusSet);
                value.CaseStatusSet = value.CaseStatusSet.filter( obj => obj.statusId !== 'Z');
                value.CaseStatusSet = value.CaseStatusSet.filter( obj => obj.statusId !== '8');
			    this.oMain._filterBar.getModel("$this.fb").setProperty("/statusOpen", value.CaseStatusSet)
				this.oComponent = new ManagedObject();
				this.oComponent.setModel(new JSONModel (),"$this.odata")
				//sinon.stub(this.oMain, "getControl").returns(this.oComponent);
			},
			afterEach: function () {
				this.oView.destroy();
				this.oMain.destroy();
				this.oMain._caseListTable = null;
				sinon.restore();
			}
		});

//_setLogonUserModel
//_createGlobalModels

	/**	QUnit.test("onBeforeRendering - Variant default", function (assert) {
			this.oMain._selectedTab = 'ALL_OPEN';
			var oComponent = new UIComponent();
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(oComponent);
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			var oStubFilterBar = new sinon.stub(this.oMain, "_filterBar");
			oStubFilterBar.returns(this.oMain._filterBar);
            var oStatusControl = new sap.m.MultiComboBox({
                            items:
                            [{key: '3', text: '3'},
                             {key: '5', text: '5'},
                             {key: 'N', text: 'N'},]
                        });
            var oLastUpdateControl = new sap.m.Select({
                            items: [{text: "Within Last 4 weeks",
                                    key: "WITHINLAST4WEEKS"
                                }]
                        });
			sinon.stub(this.getControl("status_mcb"), 'setSelectedKeys').withArgs(['3', '5', 'N']).returns(oStatusControl);
			//sinon.stub(this.oMain.getControl()).withArgs("lastUpdate_s").returns(oLastUpdateControl);
			this.oMain.onBeforeRendering(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		}); **/
		QUnit.test("onStatusChange - Variant modified", function (assert) {
			this.oMain._selectedTab = 'ALL_OPEN';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onStatusChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		});
		QUnit.test("onStatusChange - Variant not modified", function (assert) {
			this.oMain._selectedTab = 'ALL_CLOSED';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onStatusChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), false);
		});
		QUnit.test("onPriorityChange - Variant modified", function (assert) {
			this.oMain._selectedTab = 'ALL_OPEN';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onPriorityChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		});
		QUnit.test("onPriorityChange - Variant not modified", function (assert) {
			this.oMain._selectedTab = 'ALL_CLOSED';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onPriorityChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), false);
		});
		QUnit.test("onLastUpdateChange - Variant modified", function (assert) {
			this.oMain._selectedTab = 'ALL_OPEN';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onLastUpdateChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		});
		QUnit.test("onLastUpdateChange - Variant not modified", function (assert) {
			this.oMain._selectedTab = 'ALL_CLOSED';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onLastUpdateChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), false);
		});
		QUnit.test("onSystemChange - Variant modified", function (assert) {
			this.oMain._selectedTab = 'ALL_OPEN';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onSystemChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		});
		QUnit.test("onSystemChange - Variant not modified", function (assert) {
			this.oMain._selectedTab = 'ALL_CLOSED';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onSystemChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), false);
		});
		QUnit.test("onInstallationChange - Variant modified", function (assert) {
			this.oMain._selectedTab = 'ALL_OPEN';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onInstallationChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		});
		QUnit.test("onInstallationChange - Variant not modified", function (assert) {
			this.oMain._selectedTab = 'ALL_CLOSED';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onInstallationChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), false);
		});
		QUnit.test("onReporterChange - Variant modified", function (assert) {
			this.oMain._selectedTab = 'ALL_OPEN';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onReporterChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		});
		QUnit.test("onReporterChange - Variant not modified", function (assert) {
			this.oMain._selectedTab = 'ALL_CLOSED';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onReporterChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), false);
		});
		QUnit.test("onCustomerChange - Variant modified", function (assert) {
			this.oMain._selectedTab = 'ALL_OPEN';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onCustomerChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		});
		QUnit.test("onCustomerChange - Variant not modified", function (assert) {
			this.oMain._selectedTab = 'ALL_CLOSED';
			var oEvent = {};
			var oStubFilter = new sinon.stub(this.oMain, "_FilterHandler");
			oStubFilter.returns(this.oFilter);
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			sinon.stub(this.oFilter, "updateFb");
			this.oMain.onCustomerChange(oEvent);
			assert.strictEqual(this.oMain._smv.currentVariantGetModified(), false);
		});
		QUnit.test("onSearch - Go button pressed", function (assert) {
            sinon.stub(this.oMain, "_searchCases");
            this.oMain.onSearch();
            assert.ok(true,"Go button pressed.");
		});
		QUnit.test("_createFilter - Open Cases default", function (assert) {
			var aFilters = {"statusOn":true,"statusVisible":true,"reporterOn":true,"statusSesVisible":false,"statusId":["3","5","N"],"lastUpdate":"WITHINLAST4WEEKS","updatedAt":{"fromEPOCH":1670194800000,"toEPOCH":1672736307000}};
			var vFilter = this.oMain._createFilter(aFilters);
			assert.strictEqual(vFilter.getFilters()[0].aFilters[0].oValue1, "3");
			assert.strictEqual(vFilter.getFilters()[0].aFilters[1].oValue1, "5");
			assert.strictEqual(vFilter.getFilters()[0].aFilters[2].oValue1, "N");
			assert.strictEqual(vFilter.getFilters()[1].oValue1.toString().length, 13);
			assert.strictEqual(vFilter.getFilters()[1].oValue1.toString().length, 13);
		});
		QUnit.test("_createFilter - My Open Cases default", function (assert) {
			var aFilters = {"statusId":"5","statusOn":false,"statusVisible":true,"reporterOn":false,"statusSesVisible":false,"reporterId":["S0009460456"]};
			var vFilter = this.oMain._createFilter(aFilters);
			assert.strictEqual(vFilter.getFilters()[0].aFilters[0].oValue1, "5");
			assert.strictEqual(vFilter.getFilters()[1].aFilters[0].oValue1, "S0009460456");
		});
		QUnit.test("_createFilter - Closed Cases default", function (assert) {
			var aFilters = {"statusId":["8","Z"],"statusVisible":true,"statusOn":false,"statusSesVisible":false};
			var vFilter = this.oMain._createFilter(aFilters);
			assert.strictEqual(vFilter.getFilters()[0].aFilters[0].oValue1, "8");
			assert.strictEqual(vFilter.getFilters()[0].aFilters[1].oValue1, "Z");
		});
		QUnit.test("_createFilter - Drafts default", function (assert) {
			var aFilters = {"statusId":"1","statusOn":false,"statusVisible":true,"reporterOn":false,"statusSesVisible":false,"reporterId":["S0009460456"]};
			var vFilter = this.oMain._createFilter(aFilters);
			assert.strictEqual(vFilter.getFilters()[0].aFilters[0].oValue1, "1");
			assert.strictEqual(vFilter.getFilters()[1].aFilters[0].oValue1, "S0009460456");
		});
		QUnit.test("_createFilter - Sessions default", function (assert) {
			var aFilters = {"statusOn":false,"statusVisible":false,"reporterOn":true,"statusSesVisible":true,"statusId":"1","source":["AAEP"]};
			var vFilter = this.oMain._createFilter(aFilters);
			assert.strictEqual(vFilter.getFilters()[0].aFilters[0].oValue1, "1");
			assert.strictEqual(vFilter.getFilters()[1].aFilters[0].oValue1, "AAEP");
		});
	/*	QUnit.test("onFilterTable - by Keyword", function (assert) {
			var oEvent = {
				getSource: function () {
					return {
						getLiveValue: function () {
							return "unit";
						}
					};
				}
			};
		    this.oMain._caseListTable = new sap.m.Table({
                id:"caseListTable",
                items: "/CaseList",
                columns:[new sap.m.Column({header:[new sap.m.Label({text:"ID"})]}),
                    new sap.m.Column({header:[new sap.m.Label({text:"SUBJECT"})]}),
                    new sap.m.Column({header:[new sap.m.Label({text:"STATUS"})]}),
                    new sap.m.Column({header:[new sap.m.Label({text:"PRIORITY"})]}),
                    new sap.m.Column({header:[new sap.m.Label({text:"COMPONENT"})]}),],
                items:[new sap.m.ColumnListItem({cells:[
                                      new sap.m.Text({text:"{ID}"}),
                                      new sap.m.Text({text:"{SUBJECT}"}),
                                      new sap.m.Text({text:"{STATUS}" }),
                                      new sap.m.Text({text:"{PRIORITY}"}),
                                      new sap.m.Text({text:"{COMPONENT}"})]})]});
            var oTemplate = new sap.m.ColumnListItem({cells:[
                                                                  new sap.m.Text({text:"{ID}"}),
                                                                  new sap.m.Text({text:"{SUBJECT}"}),
                                                                  new sap.m.Text({text:"{STATUS}" }),
                                                                  new sap.m.Text({text:"{PRIORITY}"}),
                                                                  new sap.m.Text({text:"{COMPONENT}"})]});
            this.oMain._caseListTable.bindAggregation("items", "/CaseList", oTemplate)
            this.oMain._caseListTable.setBindingContext( new sap.ui.model.Context(new JSONModel({"ID": "4254379/2022", "SUBJECT":"Unit Test", "STATUS":"Customer Action","PRIORITY":"High","COMPONENT":"LOD-SF-ANA"}), "/CaseList"));
            this.oMain._caseListTable.addItem(new sap.m.ColumnListItem({cells:[
                                            new sap.m.Text({text:"4254379/2022"}),
                                            new sap.m.Text({text:"Unit Test"}),
                                            new sap.m.Text({text:"Customer Action" }),
                                            new sap.m.Text({text:"High"}),
                                            new sap.m.Text({text:"LOD-SF-ANA"})]}));
            this.oMain.onFilterTable(oEvent);
			assert.strictEqual(vFilter.getFilters()[0].aFilters[0].oValue1, "1");
		}); */
		QUnit.test("onTabFilterSelect - All Open", function (assert) {
			var oEvent = {
				getParameter: function () {
					return "ALL_OPEN";
				}
			};
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			var oStubFilterBar = new sinon.stub(this.oMain, "_filterBar");
			oStubFilterBar.returns(this.oMain._filterBar);
			sinon.stub(this.oMain, "getModel");
			sinon.stub(this.oMain, "_searchCases");
			this.oMain.onTabFilterSelect(oEvent);
			assert.strictEqual(this.oMain._smv.getProperty("visible"), true);
			assert.strictEqual(this.oMain._smv.getProperty("enabled"), true);
			var sStatusOpen = '[{"statusId":"1","statusTxt":"Not Sent to SAP"},{"statusId":"C","statusTxt":"Sent to SAP"},{"statusId":"5","statusTxt":"Customer Action"},{"statusId":"S","statusTxt":"In Processing by SAP"},{"statusId":"3","statusTxt":"SAP Proposed Solution"},{"statusId":"R","statusTxt":"Pending Release"},{"statusId":"M","statusTxt":"Sent to SAP Partner"},{"statusId":"N","statusTxt":"Partner-Customer Action"}]';
			assert.strictEqual(JSON.stringify(this.oMain._filterBar.getModel("$this.fb").getProperty("/statusOpen")), sStatusOpen);
		});
		QUnit.test("onTabFilterSelect - My Open", function (assert) {
			var oEvent = {
				getParameter: function () {
					return "MY_OPEN";
				}
			};
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			var oStubFilterBar = new sinon.stub(this.oMain, "_filterBar");
			oStubFilterBar.returns(this.oMain._filterBar);
			sinon.stub(this.oMain, "getModel");
			sinon.stub(this.oMain, "_searchCases");
			this.oMain.onTabFilterSelect(oEvent);
			assert.strictEqual(this.oMain._smv.getProperty("visible"), false);
			assert.strictEqual(this.oMain._smv.getProperty("enabled"), false);
			var sStatusAll = '[{"statusId":"1","statusTxt":"Not Sent to SAP"},{"statusId":"C","statusTxt":"Sent to SAP"},{"statusId":"5","statusTxt":"Customer Action"},{"statusId":"S","statusTxt":"In Processing by SAP"},{"statusId":"3","statusTxt":"SAP Proposed Solution"},{"statusId":"R","statusTxt":"Pending Release"},{"statusId":"M","statusTxt":"Sent to SAP Partner"},{"statusId":"N","statusTxt":"Partner-Customer Action"},{"statusId":"8","statusTxt":"Confirmed"},{"statusId":"Z","statusTxt":"Confirmed Automatically"}]';
			assert.strictEqual(JSON.stringify(this.oMain._filterBar.getModel("$this.fb").getProperty("/statusAll")), sStatusAll);
		});
		QUnit.test("onTabFilterSelect - All Closed", function (assert) {
			var oEvent = {
				getParameter: function () {
					return "ALL_CLOSED";
				}
			};
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			var oStubFilterBar = new sinon.stub(this.oMain, "_filterBar");
			oStubFilterBar.returns(this.oMain._filterBar);
			sinon.stub(this.oMain, "getModel");
			sinon.stub(this.oMain, "_searchCases");
			this.oMain.onTabFilterSelect(oEvent);
			assert.strictEqual(this.oMain._smv.getProperty("visible"), false);
			assert.strictEqual(this.oMain._smv.getProperty("enabled"), false);
		});
		QUnit.test("onTabFilterSelect - Drafts", function (assert) {
			var oEvent = {
				getParameter: function () {
					return "DRAFTS";
				}
			};
			var oStubSMV = new sinon.stub(this.oMain, "_smv");
			oStubSMV.returns(this.oMain._smv);
			var oStubFilterBar = new sinon.stub(this.oMain, "_filterBar");
			oStubFilterBar.returns(this.oMain._filterBar);
			sinon.stub(this.oMain, "getModel");
			sinon.stub(this.oMain, "_searchCases");
			this.oMain.onTabFilterSelect(oEvent);
			assert.strictEqual(this.oMain._smv.getProperty("visible"), false);
			assert.strictEqual(this.oMain._smv.getProperty("enabled"), false);
		});
		QUnit.test("onExport", function (assert) {
		    var oModel = {
				getProperty: function () {
					return [{'statusId':'S','priorityId':'1','sapNumber':'4253971','subject':'child case in sync with ort','componentTxt':'for SAP ONE Support Launchpad test purposes only'}];
					}
			};
			sinon.stub(this.oMain, "getModel").returns(oModel);
		    sinon.stub(this.oMain, "_createColumnConfig").returns([{"label":"ID","type":"String","property":"sapNumber"},{"label":"SUBJECT","type":"String","property":"subject"},{"label":"STATUS","type":"String","property":"statusId"},{"label":"PRIORITY","type":"String","property":"priorityId"},{"label":"COMPONENT","type":"String","property":"componentTxt"}]);
			this.oMain.onExport();
			assert.ok(true,"onExport button pressed.");
		});
		QUnit.test("_getPropertyColumn - ID", function (assert) {
			sinon.stub(this.oMain, "getModel").returns(new JSONModel({"columns": [{"text": "tablecol_id","visibleByDefault": true,"key": "sapNumber"},
                                                                         {"text": "tablecol_subject","visibleByDefault": true,"key": "subject"},
                                                                         {"text": "tablecol_status","visibleByDefault": true,"key": "statusId"},
                                                                         {"text": "tablecol_priority","visibleByDefault": true,"key": "priorityId"},
                                                                         {"text": "tablecol_installation","visibleByDefault": true,"key": "installationTxt"},
                                                                         {"text": "tablecol_systemproduct","visibleByDefault": true,"key": "systemId"},
                                                                         {"text": "tablecol_component","visibleByDefault": true,"key": "componentTxt"},
                                                                         {"text": "tablecol_reporter","visibleByDefault": true,"key": "reporterTxt"},
                                                                         {"text": "tablecol_customer","visibleByDefault": true,"key": "customerTxt"},
                                                                         {"text": "tablecol_createdon","visibleByDefault": true,"key": "createdAt"},
                                                                         {"text": "tablecol_updatedon","visibleByDefault": true,"key": "updatedAt"}]}));
		    var sLabel = 'ID';
			var sColumn = this.oMain._getPropertyColumn(sLabel);
			assert.strictEqual(sColumn, 'sapNumber');
		});
		QUnit.test("_createColumnConfig - selection 5 columns", function (assert) {
            sinon.stub(this.oMain, "getModel").returns(new JSONModel({"columns": [{"text": "tablecol_id","visibleByDefault": true,"key": "sapNumber"},
                                                                         {"text": "tablecol_subject","visibleByDefault": true,"key": "subject"},
                                                                         {"text": "tablecol_status","visibleByDefault": true,"key": "statusId"},
                                                                         {"text": "tablecol_priority","visibleByDefault": true,"key": "priorityId"},
                                                                         {"text": "tablecol_installation","visibleByDefault": true,"key": "installationTxt"},
                                                                         {"text": "tablecol_systemproduct","visibleByDefault": true,"key": "systemId"},
                                                                         {"text": "tablecol_component","visibleByDefault": true,"key": "componentTxt"},
                                                                         {"text": "tablecol_reporter","visibleByDefault": true,"key": "reporterTxt"},
                                                                         {"text": "tablecol_customer","visibleByDefault": true,"key": "customerTxt"},
                                                                         {"text": "tablecol_createdon","visibleByDefault": true,"key": "createdAt"},
                                                                         {"text": "tablecol_updatedon","visibleByDefault": true,"key": "updatedAt"}]}));
            this.oMain._caseListTable = new sap.m.Table({
                items: "/CaseList",
                columns:[new sap.m.Column({header:[new sap.m.Label({text:"ID"})]}),
                    new sap.m.Column({header:[new sap.m.Label({text:"SUBJECT"})]}),
                    new sap.m.Column({header:[new sap.m.Label({text:"STATUS"})]}),
                    new sap.m.Column({header:[new sap.m.Label({text:"PRIORITY"})]}),
                    new sap.m.Column({header:[new sap.m.Label({text:"COMPONENT"})]}),],
                items:[new sap.m.ColumnListItem({cells:[
                                      new sap.m.Text({text:"{ID}"}),
                                      new sap.m.Text({text:"{SUBJECT}"}),
                                      new sap.m.Text({text:"{STATUS}" }),
                                      new sap.m.Text({text:"{PRIORITY}"}),
                                      new sap.m.Text({text:"{COMPONENT}"})]})]});
			var aCols = this.oMain._createColumnConfig();
			assert.strictEqual(aCols.length , 5);
			assert.strictEqual(aCols[0].property , 'sapNumber');
			assert.strictEqual(aCols[1].property , 'subject');
			assert.strictEqual(aCols[2].property , 'statusId');
			assert.strictEqual(aCols[3].property , 'priorityId');
			assert.strictEqual(aCols[4].property , 'componentTxt');
		});

//openTableSettings
	}
);
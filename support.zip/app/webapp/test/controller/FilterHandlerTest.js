sap.ui.define([
		"sap/ui/core/UIComponent",
		"sap/ui/core/mvc/Controller",
		"sap/me/apps/controller/FilterHandler",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/resource/ResourceModel",
		"sap/ui/core/mvc/View",
	],

	function (UIComponent,
	Controller,
	FilterHandler,
	JSONModel,
	ResourceModel,
	View,
	ManagedObject) {
		"use strict";

		QUnit.module("Filter CaseList", {
            before: function () {
                this.sandbox = sinon.createSandbox ();
            },
			beforeEach: function () {
				this.oFilter = new FilterHandler();
			},
			afterEach: function () {
				this.oFilter.destroy();
				sinon.restore();
			}
		});

		QUnit.test("updateFb - Variant default", function (assert) {
			//this.oFilterHandler.updateFb();
			//assert.strictEqual(this.oMain._smv.currentVariantGetModified(), true);
		});

	}
);
sap.ui.define([
		"sap/ui/core/UIComponent",
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/resource/ResourceModel",
		"sap/ui/core/mvc/View",
        '../../utilities/Formatter',
	],

	function (UIComponent,
	Controller,
	JSONModel,
	ResourceModel,
	View,
    Formatter) {
		"use strict";

		QUnit.module("Formatter", {
            before: function () {
                this.sandbox = sinon.createSandbox ();
            },
			beforeEach: function () {

			},
			afterEach: function () {
				sinon.restore();
			}
		});

		QUnit.test("toggleCloseCaseBtn fn should return the button availablity according to the case source and status", function (assert) {
            assert.true (Formatter.toggleCloseCaseBtn (true, "BCP", "5"));
            assert.false (Formatter.toggleCloseCaseBtn (false, "", "4"));
            assert.false (Formatter.toggleCloseCaseBtn (true, "BCP", "1"));
		});

	}
);
sap.ui.define(
  ['../utilities/UniqueObjectArray'],
  (UniqueObjectArray) => {
    'use strict';

    return {
      /**
       * Promisifies read call to IncidentInstSet
       * Converts IncidentInstSet into two Unique Object Arrays
       * @public
       * @param {object} oScope
       * @returns
       */
      all: (oModel) => {
        return new Promise(function (resolve, reject) {
            oModel.setSizeLimit(5000);
            const oListBindingInst = oModel.bindList("/IncidentInstSet");
            oListBindingInst.attachRefresh(() => {oListBindingInst.getContexts();});
            oListBindingInst.refresh();
            oListBindingInst.attachDataReceived((oEvent) => {
                let oInstCustModel = {IncidentInstSet:[],CustomerSet:[]};
                if(!!oEvent.getParameter("error")){
                    resolve(oInstCustModel);
                    return;
                }

                const oContexts = oEvent.getSource().getCurrentContexts();
                if ((typeof oContexts !== 'undefined')&&(typeof oContexts[0] !== 'undefined')){
                    oInstCustModel.IncidentInstSet = oContexts.map(oContext => oContext.getObject());
                    oInstCustModel.InstallationSet = UniqueObjectArray.get(
                        oInstCustModel.IncidentInstSet,
                        'installationId',
                    );
                    oInstCustModel.CustomerSet = UniqueObjectArray.get(
                        oInstCustModel.IncidentInstSet,
                        'customerId',
                    );
                }
                resolve(oInstCustModel);
            });
        });
      },
    };
  },
);

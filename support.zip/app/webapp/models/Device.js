sap.ui.define(
  ['sap/ui/model/json/JSONModel', 'sap/ui/Device'],
  (JSONModel, Device) => {
    'use strict';

    return {
      /**
       * Initializes the UI Device Model
       * @public
       * @returns {sap.ui.model.json.JSONModel} oModel
       */
      initializeModel: () => {
        const oModel = new JSONModel(Device);
        oModel.setDefaultBindingMode('OneWay');
        return oModel;
      },
    };
  },
);

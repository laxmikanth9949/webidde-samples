sap.ui.define(
  ['../utilities/UniqueObjectArray'],
  (UniqueObjectArray) => {
    'use strict';

    return {
      /**
       * Promisifies read call to SystemSet
       * @public
       * @param {object} oScope
       * @returns
       */
      all: (oModel) => {
        return new Promise(function (resolve, reject) {
            oModel.setSizeLimit(5000);
            const oListBindingSystem = oModel.bindList("/CaseSystemSet");
            oListBindingSystem.attachRefresh(() => {oListBindingSystem.getContexts();});
            oListBindingSystem.refresh();
            oListBindingSystem.attachDataReceived((oEvent) => {
                let oSystemModel = {CaseSystemSet:[]};
                if(!!oEvent.getParameter("error")){
                    resolve(oSystemModel);
                    return;
                }

                const oContexts = oEvent.getSource().getCurrentContexts();
                if ((typeof oContexts !== 'undefined')&&(typeof oContexts[0] !== 'undefined')){
                    oSystemModel.CaseSystemSet=oContexts.map(oContext => oContext.getObject())
                }
                resolve(oSystemModel);
            });
        });
      },
    };
  },
);

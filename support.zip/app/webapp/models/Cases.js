sap.ui.define(
    ['sap/ui/model/odata/v4/ODataModel',
        '../utilities/CaseListTabKey',
        '../utilities/Formatter'],
    (ODataModel, CaseListTabKey, Formatter) => {
        'use strict';

        const getTimezone = async () => {
            const userProfile = await $.get("/backend/raw/support/UserProfile?$filter=Attribute eq 'TIME_ZONE'");
            return userProfile.timezone;
        };

        let timezoneConfigs = [];
        const getTimezoneConfigs = async (timezone) => {
            if (!timezoneConfigs) {
                try{
                    timezoneConfigs = await $.get("/backend/raw/support/TimeZoneConfigCacheVerticle");
                } catch (e){
                    console.log(e);
                }

            }
            return timezoneConfigs.find(config => config.TZONE === timezone);
        };

        const adjustTimezone = (timezoneConfig, timeInUserTimeZone) => {
            if (!timezoneConfig) return timeInUserTimeZone;
            const [raw, h, m, s] = /^PT(\d{2})H(\d{2})M(\d{2})S$/g.exec(timezoneConfig.UTCDIFF);
            let offset = (Number(h) * 60 * 60 + Number(m) * 60 + Number(s)) * 1000;
            if (!offset) return timeInUserTimeZone;
            if (timezoneConfig.UTCSIGN === "-") {
                offset = 0 - offset;
            }
            return timeInUserTimeZone - offset;
        };

        return {
            /**
             * Promisifies read call to MessageHeaderSet
             * @public
             * @param {object} oModel
             * @returns
             */
            all: (oModel) => {
                return new Promise(function (resolve, reject) {
                    oModel.setSizeLimit(10000);
                    const oListBindingCases = oModel.bindList("/CaseList");
                    oListBindingCases.attachRefresh(() => {
                        oListBindingCases.getContexts();
                    });
                    oListBindingCases.refresh();
                    oListBindingCases.attachDataReceived((oEvent) => {
                        let oCasesModel = {CaseList:[],count:0};
                        if(!!oEvent.getParameter("error")){
                            resolve(oCasesModel);
                            return;
                        }

                        const oContexts = oEvent.getSource().getCurrentContexts();

                        // this.getControl('caseListTable').setBusy(false);
                        if ((typeof oContexts !== 'undefined') && (typeof oContexts[0] !== 'undefined')) {
                            oCasesModel.CaseList = oContexts.map(oContext => oContext.getObject())
                            oCasesModel.count = oContexts.length;

                        }
                        resolve(oCasesModel);
                    });
                });
            },
            filter: (oContext, vFilter, sCaseListSource, customParameters) => {
                //const sQueryParams = `?filter=${oContext.attributes.caseKey}`;
                var mainControl = oContext;
                //if last request model is exist then should destroy
                if (mainControl._requestOModelList) {
                    mainControl._requestOModelList.destroy();
                    mainControl._requestOModelList = false;
                }
                const oModel = new ODataModel({
                    serviceUrl: `/backend/odata/support/`,
                    synchronizationMode: "None",
                    // for easier development
                    groupId: "$direct",
                    // groupId: "$auto",
                    operationMode: "Server"
                });
                oModel.setSizeLimit(10000);

                const sVerticleUrl = sCaseListSource === "W7" ? "/CaseList" : "/CaseListAggregated";

                return new Promise(function (resolve, reject) {
                    const oListBindingCases = oModel.bindList(sVerticleUrl, undefined, undefined, vFilter);

                    if (customParameters) {
                        oListBindingCases.changeParameters(customParameters);
                    }
                    oListBindingCases.attachRefresh(() => {
                        oListBindingCases.getContexts();
                    });
                    oListBindingCases.refresh();
                    mainControl._requestOModelList = oListBindingCases;
                    oListBindingCases.attachDataReceived(async (oEvent) => {
                        let oCasesModel = {CaseList:[],count:0}
                        if(!!oEvent.getParameter("error")){
                            resolve(oCasesModel);
                            return;
                        }

                        const timezone = await getTimezone();
                        const timezoneConfig = await getTimezoneConfigs(timezone);

                        const oContexts = oEvent.getSource().getCurrentContexts();
                        if ((typeof oContexts !== 'undefined') && (typeof oContexts[0] !== 'undefined')) {
                            oCasesModel = {
                                CaseList: oContexts.map(oContext => {
                                    const data = oContext.getObject();
                                    data.createdAt = adjustTimezone(timezoneConfig, data.createdAt);
                                    data.updatedAt = adjustTimezone(timezoneConfig, data.updatedAt);
                                    // if case have Auto confirm date then show message strip and Auto Confirm tab
                                    if (Formatter.checkAutoConfirmDate(data?.autoConfirmDate)) {
                                        mainControl.getModel('$this.selectionAutoConfirm').setProperty('/messageStripVisible', true);
                                        mainControl.getModel('$this.selectionAutoConfirm').setProperty('/autoConfirmTabVisible', true);
                                    }
                                    return data;
                                })
                            };

                            if(mainControl._selectedTab === CaseListTabKey.AUTO_CONFIRM){
                                oCasesModel.CaseList = oCasesModel.CaseList.filter(data => Formatter.checkAutoConfirmDate(data?.autoConfirmDate));
                            }
                            oCasesModel.count = oCasesModel.CaseList.length;
                        }
                        resolve(oCasesModel);
                    });
                });
            },
        };
    },
);

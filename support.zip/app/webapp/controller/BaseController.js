sap.ui.define(['sap/ui/core/mvc/Controller'], (Controller) => {
  return Controller.extend('support.controllers.BaseController', {
    /**
     * Convenience method for getting the view model by name.
     * @function
     * @public
     * @param {string} [sName] the model name
     * @returns {sap.ui.model.Model} the model instance
     */
    getModel: function (sName) {
      return this.getView().getModel(sName);
    },

    /**
     * Convenience method for setting the view model.
     * @function
     * @public
     * @param {sap.ui.model.Model} oModel the model instance
     * @param {string} sName the model name
     * @returns {sap.ui.mvc.View} the view instance
     */
    setModel: function (oModel, sName) {
      return this.getView().setModel(oModel, sName);
    },

    /**
     * Getter for the resource bundle.
     * @function
     * @public
     * @param {string} sProperty - Name of i18n entry
     * @param {array} aArgs - Array of injectable strings
     * @returns {string} the resourceModel of the component
     */
    getText: function (sProperty, _aArgs) {
      return this.getOwnerComponent()
        .getModel('i18n')
        .getResourceBundle()
        .getText(sProperty, aArgs);
    },

    /**
     * Convenience method for getting an Element by ID
     *
     * @function
     * @public
     * @param {string} sId View-local ID
     * @returns {sap.ui.core.Element}
     */
    getControl: function (sId) {
      return this.getView().byId(sId);
    },

    /**
     * Convenience method for getting an Element by ID using ui getCore
     *
     * @function
     * @public
     * @param {string} sId View-local ID
     * @returns {sap.ui.core.Element}
     */
    getCoreControl: function (sId) {
      return sap.ui.getCore().byId(sId);
    },

    /**
     * Convenience method for getting a Fragment by Name
     *
     * @function
     * @public
     * @param {string} sFragmentName Fragment Name
     * @returns {sap.ui.core.Element}
     */
    getFragment: function (sFragmentName, oScope) {
      const sFragment = 'sap.me.apps.support.views.fragments.' + sFragmentName;
      return sap.ui.xmlfragment(sFragment, oScope);
    },

    /**
     * Message and Error Handling
     * Will display Message Box containing message and for a message type
     * @public
     * @function
     * @param {string} sMessage
     * @param {string} sType
     */
    messageHandler: function (sMessage, sType) {
      console.log(sMessage);
      if (['error', 'warning', 'information'].includes(sType)) {
        // @todo: Adam Kavanagh create a message box for each sType
        //        We need to discuss the expected action for each e.g.
        //        - Error is the app is dead in the water
        //        - Warning is something has failed but the user can still use
        //        the app etc.
      }
    },
  });
});

sap.ui.define([
	"sap/ui/base/ManagedObject",
	'../utilities/FilterConverter',
    "../utilities/CaseListTabKey",
], function(ManagedObject,LastUpdateFilterConverter,CaseListTabKey) {
	"use strict";

	return ManagedObject.extend("support.controllers.FilterHandler", {

		/**
		 * Updates the custom filter to be set in the variant
		 *
		 * @returns {void}
		 */
		 updateFb: function (oContext, sField, sTab) {
		 	var value;
		 	var oModel = this._getSelectedModelTab(oContext, sTab);
			oContext._filterBar = oContext.getView().byId("caseListFilterBar");
			var oFilterBarModel =  oContext._filterBar.getModel('$this.fb');
			var aFilterBar = oFilterBarModel.getData();

			if (oContext._filterBar) {
				switch(sField){
					case "status":
					    var controlId = sField + '_mcb';
					    value = oContext.getControl(controlId).getSelectedKeys();

					    oModel.setProperty("/statusId", value);
						break;

					case "sessionState":
					    var controlId = sField + '_mcb';
					    value = oContext.getControl(controlId).getSelectedKeys();
					    oModel.setProperty("/aaEPQuesStatus", value);
						break;

					case "priority":
					    var controlId = sField + '_mcb';
					    value = oContext.getControl(controlId).getSelectedKeys();
					    oModel.setProperty("/priorityId", value);
						break;

					case "lastUpdate":
					    value = oContext.getControl("lastUpdate_s").getSelectedKey();
					    oModel.setProperty("/lastUpdate", value);
						break;

			 		case "createdOn":
			 		    var valueFromConverted = "";
			 		    var valueToConverted = "";
                        var valueFrom = oContext.getControl("createdOn_drs").getDateValue();
                        var valueTo = oContext.getControl("createdOn_drs").getSecondDateValue();
                        if (valueFrom && valueTo){
                            valueFromConverted = LastUpdateFilterConverter.convertDatesFilter(valueFrom);
                            valueToConverted = LastUpdateFilterConverter.convertDatesFilter(valueTo);
                        }
					    oModel.setProperty("/createdAt", {"fromEPOCH": valueFromConverted, "toEPOCH": valueToConverted, "from": valueFrom, "to": valueTo });
						break;

			 		case "changedOn":
			 		    var valueFromConverted = "";
			 		    var valueToConverted = "";
                        var valueFrom = oContext.getControl("changedOn_drs").getDateValue();
                        var valueTo = oContext.getControl("changedOn_drs").getSecondDateValue();
                        if (valueFrom && valueTo){
                            valueFromConverted = LastUpdateFilterConverter.convertDatesFilter(valueFrom);
                            valueToConverted = LastUpdateFilterConverter.convertDatesFilter(valueTo);
                        }
					    oModel.setProperty("/updatedAt", {"fromEPOCH": valueFromConverted, "toEPOCH": valueToConverted, "from": valueFrom, "to": valueTo });
						break;

                    case "reporter":
                        var controlId = sField + '_sel';
                        var aTokens = [];
                        var aReporters = [];
                        if (oModel.getData().reporterId) {
                            aTokens =  oModel.getData().reporterId;
                            aTokens.map(function (oToken) {
                                aReporters.push(oToken);
                            });
                        }
                        oModel.setProperty("/reporterId", aReporters);
                        break;
                    case "creator": {
                        const aCreators = [];
                        if (oModel.getData().creatorId) {
                            const aTokens = oModel.getData().creatorId;
                            aTokens.forEach(function (oToken) {
                                aCreators.push(oToken);
                            });
                        }
                        oModel.setProperty("/creatorId", aCreators);
                        break;
                    }
                    case "system":
                        var controlId = sField + '_sel';
                        var aTokens = [];
                        var aSystems = [];
                        if (oModel.getData().systemNumber) {
                            aTokens = oModel.getData().systemNumber;
                            aTokens.map(function (oToken) {
                                aSystems.push(oToken);
                            });
                        }
                        oModel.setProperty("/systemNumber", aSystems);
                        break;

                    case "installation":
                        var controlId = sField + '_sel';
                        var aTokens = [];
                        var aInstallations = [];
                        if (oModel.getData().installationId) {
                            aTokens = oModel.getData().installationId;
                            aTokens.map(function (oToken) {
                                aInstallations.push(oToken);
                            });
                        }
                        oModel.setProperty("/installationId", aInstallations);
                        break;

                    case "customer":
                        var controlId = sField + '_sel';
                        var aTokens = [];
                        var aCustomers = [];
                        if (oModel.getData().customerId) {
                            aTokens = oModel.getData().customerId;
                            aTokens.map(function (oToken) {
                                aCustomers.push(oToken);
                            });
                        }
                        oModel.setProperty("/customerId", aCustomers);
                        break;
				}
			}
			},

      _getSelectedModelTab: function(oContext, sTab){
          const modelKeyMap = {
              [CaseListTabKey.MY_OPEN]: "$this.selectionMyOpen",
              [CaseListTabKey.ALL_CLOSED]: "$this.selectionAllClosed",
              [CaseListTabKey.DRAFTS]: "$this.selectionDrafts",
              [CaseListTabKey.FAV]: "$this.selectionFav",
              [CaseListTabKey.SES]: "$this.selectionSes",
              [CaseListTabKey.AUTO_CONFIRM]: "$this.selectionAutoConfirm"
          };
          const modelKey = modelKeyMap[sTab] || "$this.selectionAllOpen";
          return oContext.getModel(modelKey);
      },

		createTile: function (oEvent) {
			var bTile = oEvent.getSource().oCreateTile.getSelected();
			if (bTile) {
				var variantid = oEvent.getSource().getCurrentVariantId();
				var sUri = "incident/list/variant/" + variantid;
				sap.ui.getCore().getEventBus().publish("sap.support.launchpad", "saveastile", {
					uri: sUri
				});
			}
		}
	});
});
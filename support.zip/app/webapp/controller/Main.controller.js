sap.ui.define(
    [
        './BaseController',
        'sap/m/library',
        'sap/ui/model/json/JSONModel',
        'sap/ui/model/odata/v4/ODataModel',
        'sap/ui/model/Filter',
        'sap/ui/model/FilterOperator',
        'sap/ui/model/Sorter',
        './FilterHandler',
        '../models/Installations',
        '../models/Cases',
        '../models/Priorities',
        '../models/Status',
        '../models/Systems',
        '../models/Reporters',
        '../utilities/Formatter',
        'sap/ui/comp/filterbar/FilterBar',
        'sap/ui/comp/smartvariants/PersonalizableInfo',
        'sap/ui/export/library',
        'sap/ui/export/Spreadsheet',
        '../utilities/i18nWrapper',
        'sap/m/FormattedText',
        "sap/me/shared/Models",
        "sap/me/support/utils/helper",
        "sap/m/Token",
        "sap/ui/core/Fragment",
        "sap/ui/core/routing/Router",
        "sap/m/PDFViewer",
        "sap/m/MessageToast",
        "sap/me/support/utils/SaveMsgEventBus",
        "sap/me/support/utils/QualtricsService",
        "sap/me/shared/util/getBrowserTabId",
        "sap/me/shared/util/getApplicationInstanceId",
        "sap/me/shared/util/getPreferredLanguage",
        "sap/ui/core/format/DateFormat",
        "../utilities/CaseListTabKey",
        "sap/me/support/utils/Constants",
        "sap/base/Log",
    ],
    (
        BaseController,
        mlibrary,
        JSONModel,
        ODataModel,
        Filter,
        FilterOperator,
        Sorter,
        FilterHandler,
        Installations,
        Cases,
        Priorities,
        Status,
        Systems,
        Reporters,
        Formatter,
        FilterBar,
        PersonalizableInfo,
        ExportLibrary,
        Spreadsheet,
        i18nWrapper,
        FormattedText,
        SharedModels,
        helper,
        Token,
        Fragment,
        Router,
        PDFViewer,
        MessageToast,
        SaveMsgEventBus,
        QualtricsService,
        getBrowserTabId,
        getApplicationInstanceId,
        getPreferredLanguage,
        DateFormat,
        CaseListTabKey,
        Constants,
        Log
    ) => {


        var mGroupFunctions = {
            statusTxt: function (oContext) {
                var name = oContext.getProperty("statusTxt");
                return {
                    key: name,
                    text: name
                };
            },
            priorityTxt: function (oContext) {
                var name = oContext.getProperty("priorityTxt");
                return {
                    key: name,
                    text: name
                };
            },
            installationTxt: function (oContext) {
                var name = oContext.getProperty("installationTxt");
                return {
                    key: name,
                    text: name
                };
            },
            systemTxt: function (oContext) {
                var name = oContext.getProperty("systemTxt");
                return {
                    key: name,
                    text: name
                };
            },
            componentKey: function (oContext) {
                var name = oContext.getProperty("componentKey");
                return {
                    key: name,
                    text: name
                };
            },
            componentTxt: function (oContext) {
                var name = oContext.getProperty("componentTxt");
                return {
                    key: name,
                    text: name
                };
            },
            reporterTxt: function (oContext) {
                var name = oContext.getProperty("reporterTxt");
                return {
                    key: name,
                    text: name
                };
            },
            customerTxt: function (oContext) {
                var name = oContext.getProperty("customerTxt");
                return {
                    key: name,
                    text: name
                };
            },
            /*
            createdAt: function (oContext) {
                var date = oContext.getProperty("createdAt");
                var time = oContext.getProperty("createdTime");
                var timezone = oContext.getProperty("userTimezone");
                var name = formatter.datesAt(date, time, timezone);
                return {
                    key: name,
                    text: name
                };
            },
            updatedAt: function (oContext) {
                var date = oContext.getProperty("updatedAt");
                var time = oContext.getProperty("updatedTime");
                var timezone = oContext.getProperty("userTimezone");
                var name = formatter.datesAt(date, time, timezone);
                return {
                    key: name,
                    text: name
                };
            },
            */
            autoConfirmDateTxt: function (oContext) {
                var date = oContext.getProperty("autoConfirmDateTxt");
                return {
                    key: date,
                    text: date
                };
            }
        };

        const ResetAllMode = mlibrary.ResetAllMode;
        var EdmType = ExportLibrary.EdmType;

        return BaseController.extend('support.controller.Main', {
            /**
             * Globals
             */
            formatter: Formatter,
            _sInitialLoading: true,

            /**
             * Called when a view is instantiated and its controls (if available) have
             * already been created; used to modify the view before it is displayed to
             * bind event handlers and do other one-time initialization
             * @public
             * @override
             * @async
             */
            onInit: async function () {
                this._mainPage = this.getControl('mainPage');
                this._filterBar = this.getView().byId("caseListFilterBar");
                this._caseListUserPersonalizationAPI = 'caseListUserPersonalization';
                this._caseListTable = this.getControl('caseListTable');
                this._iconTabBar = this.getControl('iconTabBar');
                this._FilterHandler = new FilterHandler();
                this._i18nWrapper = i18nWrapper.init();
                this._caseListTable.onColumnPress = (column) => {
                    this.onSortPress(column);
                };
                const availableHost = [ "test.me.sap.com", "dev.me.sap.com", "localhost" ];
                this.getControl("dataSource").setVisible(availableHost.includes(window.location.hostname));

                // Set Main Page Busy
                this._mainPage.setBusy(true);

                // Create Global Models
                await this._createGlobalModels();
                //FilterBar
                await this._initialiseFilterBar();
                await this.checkIsVARDCustomer();
                // Creating Group Functions
                // this._generateGroupFunctions();

                this._loadUserProfileModel(); // if this is not loaded there may be odd behavior

                this._checkMessageStripBarVisibility();

                //load filter data
                await this._loadFilterModels();

                this.router = Router.getRouter("shellRouter");
                this.router.attachRouteMatched(this._routeMatched, this);

                let tab = this.parseTabFromURL();
                if (tab === CaseListTabKey.AUTO_CONFIRM) {
                    tab = CaseListTabKey.ALL_OPEN;
                }
                if (tab !== CaseListTabKey.ALL_OPEN) {
                    this.fetchCaseListCheckConfirmDate();
                }
                //set ui in every tab
                this._iconTabBar.setSelectedKey(tab);

                this.onTabFilterSelect({getParameter: function() {return tab}});
                // Set Main Page Busy
                this._mainPage.setBusy(false);
            },

            checkIsVARDCustomer: async function () {
                const userInfo = SharedModels.getUserModel().getData();
                const queryData = `?$filter=Uname eq '${userInfo.userName}' and Type eq 'CUSTOMER'`;
                const result = await jQuery.ajax("/backend/raw/support/CaseF4HelpW7Verticle" + queryData, {
                    method: "GET",
                    contentType: "application/json"
                });
                this.isSupportCustomer = !!result?.find(item => item.Category === "ALL" && item.Desc2 === "SUPPORTED");
            },

            createSMV : function () {
                this._smv = this.getView().byId("caseListSVM");
                const oPersInfo = new PersonalizableInfo({
                    type: "filterBar",
                    keyName: "persistencyKey",
                    dataSource: "",
                    control: this._filterBar
                });
                this._smv.addPersonalizableControl(oPersInfo);
                this._smv.setShowShare(false); //Disable public checkbox
                this._smv.setShowCreateTile(false);
            },

            _routeMatched : function() {
                const isFromServiceSupport = this.router.sMatchedRouteName === "dashboardServicessupport" && this.router.mMatchedRouteArguments?.section === "cases";
                const isFromCL = this.router.sMatchedRouteName === "applicationCl";

                if(isFromServiceSupport || isFromCL){
                    const tab = this.parseTabFromURL();
                    this._iconTabBar.setSelectedKey(tab);
                    this._handleTabFilterSelect(tab);

                    this.onSearch();
                }
            },

            getSearchParams : function () {
                const pathParams = JSON.parse(decodeURIComponent(this.router.mMatchedRouteArguments.group??this.router.mMatchedRouteArguments.searchTerm??"{}"));
                const searchParams = {};
                if(Object.keys(pathParams).length > 0){
                    searchParams.tab = pathParams.tab;
                    searchParams.searchTerm = pathParams.searchTerm;
                } else if (document.location.search){
                    const queryParams = new URLSearchParams(document.location.search);
                    searchParams.tab = queryParams.get("tab");
                    searchParams.searchTerm = queryParams.get("searchTerm");
                }

                return this.searchParams = searchParams;
            },

            parseTabFromURL : function () {
                const searchParams = this.getSearchParams();

                const tabInURL = searchParams.tab?.toUpperCase();
                const needSearch = !!searchParams.searchTerm;
                const tabInUserPersonalization = this.getOwnerComponent()?.getModel("userProfileModel")?.getProperty("/Tab");
                return tabInURL || (needSearch ? CaseListTabKey.RESULTS : tabInUserPersonalization);
            },

             /**
             * This method checks if given some criteria the messagestripbar should be visible or not
             */


            _checkMessageStripBarVisibility : function() {

                const todaysDate = new Date();
                const startDate = new Date("2023-08-28");
                const endDate = new Date("2023-10-04");
                const bVisible = todaysDate >= startDate && todaysDate <= endDate;
                this.getControl("caseListMsgStrip").setVisible(bVisible);

            },

            closeDialog : function(){
                const elements = ["#sap-ui-blocklayer-popup", ".sapMPageHeader", "#__xmlview0--shellContent", "#__xmlview0--shellFooter"];
                elements.forEach (e => {
                    jQuery (e).removeClass ("forbiddenClick")
                  });
            },

            openDialog : function(oEvent){
                clearInterval(this.timer);
                this.timer = setInterval(()=>{
                    const filterDialogId = oEvent.getSource().sId + "-adapt-filters-dialog";
                    if(sap.ui.getCore().byId(filterDialogId)){
                        const elements = ["#sap-ui-blocklayer-popup",".sapMPageHeader", "#__xmlview0--shellContent", "#__xmlview0--shellFooter"];
                        elements.forEach (e => {
                            jQuery (e).addClass ("forbiddenClick")
                          });
                          jQuery ( "#" + filterDialogId + " .sapMPageHeader").removeClass ("forbiddenClick")
                          clearInterval(this.timer);
                    }

                },5)
            },

            /**
             * This method is called upon destruction of the View. The controller should
             * perform its internal destruction in this hook.
             * @public
             * @override
             * @async
             */
            onExit: function () {
                this._FilterHandler.destroy();
                this._smv = null;
                this._filterBar = null;
                this._caseListTable = null;
            },

            /**
            * This method initializes the filter bar
            */
            _initialiseFilterBar: async function () {
                this._filterBar.fireInitialise();
                this._filterBar.registerFetchData(this.fetchData.bind(this));
                this._filterBar.registerApplyData(this.applyData.bind(this));
                this._filterBar.registerGetFiltersWithValues(this.getFiltersWithValues.bind(this));
            },

            /**
             * Set logon user model (s-user)
             * @function
             * @private
             */
            _setLogonUserModel: function () {
                this._oUserModel = SharedModels.getUserModel().getData();
                var aFilterBar = this._filterBar.getModel('$this.fb').getData();
                if ((this._oUserModel) && (Object.keys(this._oUserModel).length !== 0)) {
                    var aTokens = [];
                    var aReporters = [];
                    if (aFilterBar.reporters) {
                        //bug(https://jira.tools.sap/browse/S4M-6051): haven't fix, when a user is a new user, reporters from IncidentReporterSet don't include this user
                        //so when switch to MY_OPEN or Draft tab, it won't query with this user. So it will get another user's cases.
                        //but show current user token in filter bar
                        aTokens = aFilterBar.reporters;
                        sUserName = this._oUserModel.simulatedUser || this._oUserModel.userName;
                        aTokens.map(function (oToken) {
                            if (oToken.reporterId === sUserName){
                                aReporters.push(oToken);
                            }
                        });
                    this.getModel('$this.selectionMyOpen').setProperty("/reporterId", aReporters);
                    this.getModel('$this.selectionDrafts').setProperty("/reporterId", aReporters);
                    }
                }
            },
            /**
             * Creates JSONModels for all globally required data
             * @function
             * @private
             */
            _createGlobalModels: async function () {
                this.setModel(new JSONModel(), '$this.odata');
                this.setModel(new JSONModel(), '$this.fb');
                this.setModel(new JSONModel({
                    allOpen: '',
                    myOpen: '',
                    allClosed: '',
                    drafts: '',
                    fav: '',
                    ses: '',
                    autoConfirm: ''
                }), '$this.count');
                this.setModel(new JSONModel({
                    statusSesVisible: false
                }), '$this.selection');

                this.setModel(new JSONModel({
                    statusId: ["3", "5", "N"],
                    statusOn: true,
                    statusVisible: true,
                    reporterOn: true,
                    creatorOn: true,
                    creatorId: "",
                    statusSesVisible: false,
                    showCreator: false
                }), '$this.selectionAllOpen');
                this.setModel(new JSONModel({ value: "" }), '$this.searchInput');
                this.setModel(new JSONModel(), '$this.selectionCustomSearch');
                this.setModel(new JSONModel({
                    statusId: ["3", "5", "N"],
                    statusOn: true,
                    statusVisible: true,
                    reporterOn: false,
                    statusSesVisible: false,
                    reporterId: ""
                }), '$this.selectionMyOpen');

                this.setModel(new JSONModel({
                    statusId: ["8", "Z"],
                    statusOn: true,
                    statusVisible: true,
                    reporterVisible: true,
                    statusSesVisible: false
                }), '$this.selectionAllClosed');
                this.setModel(new JSONModel({
                    statusId: "1",
                    statusOn: false,
                    statusVisible: true,
                    reporterOn: true,
                    statusSesVisible: false
                }), '$this.selectionDrafts');
                this.setModel(new JSONModel({
                    statusOn: true,
                    statusVisible: true,
                    reporterOn: true,
                    statusSesVisible: false,
                    isFavorite:true,
                }), '$this.selectionFav');
                this.setModel(new JSONModel({
                    statusOn: false,
                    statusVisible: false,
                    reporterOn: true,
                    statusSesVisible: true,
                    statusId: "1",
                    aaEPDraftFlag: "X",
                    aaEPSessStatus: ["Open / Running Sessions", "Completed Sessions"]
                }), '$this.selectionSes');
                this.setModel(new JSONModel({
                    statusId: ["3", "5", "N"],
                    statusOn: true,
                    statusVisible: true,
                    reporterOn: true,
                    statusSesVisible: false,
                    messageStripVisible: false,
                    autoConfirmTabVisible: false
                }), '$this.selectionAutoConfirm');
            },

            /**
             * Load user profile model for personalization
             * - Selected Tab
             * - Table sort
             * - Table group
             * - Table columns
             *
             * @param  {void}
             * @return {void}
             */
            _loadUserProfileModel: async function () {
                var oUserProfModel = new JSONModel();
                this.getOwnerComponent().setModel(oUserProfModel, "userProfileModel");
                let oUserProfile = this._getFromUserProfile();
                var oTab = CaseListTabKey.ALL_OPEN;
                if (oUserProfile !== undefined) {
                    oTab = oUserProfile.tab != undefined ? oUserProfile.tab : null;
                }

                var bSesVisibility = oTab !== CaseListTabKey.SES;
                var oSort = `[{\"sPath":"Stext"\"","bDescending":true}]`;
                var oGroup = `[{\"sPath":"Stext"\"","bDescending":true}]`;
                var oColumns = `{"_persoSchemaVersion":"1.0","aColumns":[["tablecol_id",0,true,"sapNumber"],
                    ["tablecol_status",2,true,"statusTxt"],["tablecol_priorityId",3,true,"priorityId"],
                    ["tablecol_installation",4,true,"installationTxt"],["tablecol_system",5,true,"systemTxt"],
                    ["tablecol_component",6,true,"componentTxt"],["tablecol_reporter",7,true,"reporterTxt"],["tablecol_customer",8,true,"customerTxt"],
                    ["tablecol_createdon",9,${!bSesVisibility},"createdAt"], ["tablecol_updatedon",10,${!bSesVisibility},"updatedAt"],
                    ["tablecol_autoconfirmdate",11,${!bSesVisibility},"autoConfirmDateTxt"],
                    ["tablecol_sessionstate",9,${bSesVisibility},"aaEPSessStatus"], ["tablecol_sessioncreated",10,${bSesVisibility},"quesDateCreated"],
                    ["tablecol_sessioncompleted",11,${bSesVisibility},"quesExpirationDate"]]}`;


                try {
                    oGroup = oUserProfile.group != undefined ? oUserProfile.group : oGroup;
                } catch (error) {
                    // ignore;
                }
                try {
                    oSort = oUserProfile.sort != undefined ? oUserProfile.sort : oSort;
                } catch (error) {
                    // ignore;
                }
                try {
                    oColumns = oUserProfile.columns != undefined && oTab !== CaseListTabKey.SES ? oUserProfile.columns : oColumns;
                } catch (error) {
                    // ignore;
                }

                this.getOwnerComponent().getModel("userProfileModel").setProperty("/Tab", oTab);
                this.getOwnerComponent().getModel("userProfileModel").setProperty("/Sort", oSort);
                this.getOwnerComponent().getModel("userProfileModel").setProperty("/Group", oGroup);
                this.getOwnerComponent().getModel("userProfileModel").setProperty("/Columns", oColumns);
            },

            /**
             * Get personalization from user profile -> read from model
             *
             * @return {void}
             */
            _getFromUserProfile: function () {
                var oResult = null;
                var userProfileJson = new JSONModel();
                userProfileJson.attachRequestCompleted(function (oData, oResponse) {
                    var _oData = oData.getSource().getData();
                    if (_oData && _oData.value) {
                        oResult = _oData.value[0];
                    }
                });
                userProfileJson.loadData('/backend/odata/support/CaseListUserPersonalization', false, false);
                return oResult;
            },

            /**
             *      ___ _ _ _             ___
             *     | __(_) | |_ ___ _ _  | _ ) __ _ _ _
             *     | _|| | |  _/ -_) '_| | _ \/ _` | '_|
             *     |_| |_|_|\__\___|_|   |___/\__,_|_|
             *
             *     FINDSFB
             *
             */

            /**
             * Fetch data from smart variant
             * @function
             * @private
             */
            fetchData: function () {
                var aData = this._filterBar.getAllFilterItems().reduce(function (aResult, oFilterItem) {
                    var sFieldData;
                    if (oFilterItem.getProperty('name') === 'lastUpdate_fi') {
                        sFieldData = oFilterItem.getControl().getSelectedKey();
                    } else if ((oFilterItem.getProperty('name') === 'createdOn_fi')
                            || (oFilterItem.getProperty('name') === 'changedOn_fi')) {
                        sFieldData = { 'to': oFilterItem.getControl().getTo(), 'from': oFilterItem.getControl().getFrom() };
                    } else if (oFilterItem.getProperty('name') === 'status_fi'
                            || oFilterItem.getProperty('name') === 'priority_fi'
                            || oFilterItem.getProperty('name') === 'session_fi') {
                        sFieldData = oFilterItem.getControl().getSelectedKeys();
                    } else {
                        if (oFilterItem.getControl().getTokens().length > 0) {
                            var aTokens = [];
                            var aTokenKeys = [];
                            aTokens = oFilterItem.getControl().getTokens();
                            aTokens.map(function (oToken) {
                                aTokenKeys.push(oToken.getKey());
                            });
                            sFieldData = JSON.stringify(aTokenKeys);
                        } else {
                            sFieldData = "";
                        }
                    }
                    aResult.push({
                        groupName: oFilterItem.getGroupName(),
                        fieldName: oFilterItem.getName(),
                        fieldData: sFieldData
                    });
                    return aResult;
                }, []);
                //Sort
                aData.push({
                    groupName: aData[0].groupName,
                    fieldName: 'sort',
                    fieldData: JSON.stringify(this._aSorter)
                });
                //Group
                aData.push({
                    groupName: aData[0].groupName,
                    fieldName: 'group',
                    fieldData: JSON.stringify(this._aGroup)
                });

                var sSelectionKey = this._smv.getSelectionKey();
                if (this._smv._getVariantById(sSelectionKey).getProperty("executeOnSelection") === true && !this._sInitialLoading){
                    this.onSearch();
                }

                //Columns
                return aData;
            },
            /**
             * Apply data to smart variant
             * @function
             * @private
             */
            applyData: function (aData) {
                var that = this;
                aData.forEach(function (oDataObject) {
                    var oControl = this._filterBar.determineControlByName(oDataObject.fieldName, oDataObject.groupName);

                    switch (oDataObject.fieldName) {

                        case 'lastUpdate_fi':
                            oControl.setSelectedKey(oDataObject.fieldData);
                            break;
                        case 'createdOn_fi':
                        case 'changedOn_fi':
                            oControl.setTo(oDataObject.fieldData.to);
                            oControl.setFrom(oDataObject.fieldData.from);
                            break;
                        case 'sort':
                            this._aSorter = JSON.parse(oDataObject.fieldData);
                            break;
                        case 'group':
                            this._aGroup = JSON.parse(oDataObject.fieldData);
                            break;
                        case 'status_fi':
                        case 'priority_fi':
                        case 'session_fi':
                            oControl.setSelectedKeys(oDataObject.fieldData);
                            break;
                        case 'system_fi':
                            oControl.destroyTokens();
                            var selTokens = [];
                            if (oDataObject.fieldData !==  "") {
                                var aTokens = [];
                                var aTokenKeys = JSON.parse(oDataObject.fieldData);
                                let oSystem = this._filterBar.getModel("$this.fb").getProperty("/systems");
                                for (var i = 0; i < aTokenKeys.length; i++) {
                                    let oSystemDisplay = oSystem.find(function (oSys) {
                                        return oSys.systemNumber === aTokenKeys[i];
                                     });
                                     oControl.addToken(new Token({
                                        key: aTokenKeys[i],
                                        text: oSystemDisplay.systemTxt
                                     }));
                                     selTokens.push({
                                        systemNumber: aTokenKeys[i],
                                        systemTxt: oSystemDisplay.systemTxt
                                     })
                                }
                            }
                            var oModel = this._getSelectedModelTab(this._selectedTab);
                            oModel.setProperty("/systemNumber", selTokens)
                            break;
                        case 'installation_fi':
                            oControl.destroyTokens();
                            var selTokens = [];
                            if (oDataObject.fieldData !==  "") {
                                var aTokens = [];
                                var aTokenKeys = JSON.parse(oDataObject.fieldData);
                                let oInstallation = this._filterBar.getModel("$this.fb").getProperty("/installations");
                                for (var i = 0; i < aTokenKeys.length; i++) {
                                    let oInstallationDisplay = oInstallation.find(function (oInst) {
                                        return oInst.installationId === aTokenKeys[i];
                                     });
                                     oControl.addToken(new Token({
                                        key: aTokenKeys[i],
                                        text: oInstallationDisplay.installationTxt
                                     }));
                                     selTokens.push({
                                        installationId: aTokenKeys[i],
                                        installationTxt: oInstallationDisplay.installationTxt
                                     })
                                }
                            }
                            var oModel = this._getSelectedModelTab(this._selectedTab);
                            oModel.setProperty("/installationId", selTokens)
                            break;
                        case 'reporter_fi':
                            oControl.destroyTokens();
                            var selTokens = [];
                            if (oDataObject.fieldData !==  "") {
                                var aTokens = [];
                                var aTokenKeys = JSON.parse(oDataObject.fieldData);
                                let oReporter = this._filterBar.getModel("$this.fb").getProperty("/reporters");
                                for (var i = 0; i < aTokenKeys.length; i++) {
                                    let oReporterDisplay = oReporter.find(function (oRep) {
                                        return oRep.reporterId === aTokenKeys[i];
                                     });
                                     oControl.addToken(new Token({
                                        key: aTokenKeys[i],
                                        text: oReporterDisplay.reporterTxt
                                     }));
                                     selTokens.push({
                                        reporterId: aTokenKeys[i],
                                        reporterTxt: oReporterDisplay.reporterTxt
                                     })
                                }
                            }
                            var oModel = this._getSelectedModelTab(this._selectedTab);
                            oModel.setProperty("/reporterId", selTokens)
                            break;
                        case "creator_fi": {
                            oControl.destroyTokens();
                            const selTokens = [];
                            if (oDataObject.fieldData !==  "") {
                                const aTokenKeys = JSON.parse(oDataObject.fieldData);
                                const oReporter = this._filterBar.getModel("$this.fb").getProperty("/reporters");
                                for (let i = 0; i < aTokenKeys.length; i++) {
                                    const oReporterDisplay = oReporter.find(function (oRep) {
                                        return oRep.reporterId === aTokenKeys[i];
                                    });
                                    oControl.addToken(new Token({
                                        key: aTokenKeys[i],
                                        text: oReporterDisplay.reporterTxt
                                    }));
                                    selTokens.push({
                                        reporterId: aTokenKeys[i],
                                        reporterTxt: oReporterDisplay.reporterTxt
                                    });
                                }
                            }
                            const oModel = this._getSelectedModelTab(this._selectedTab);
                            oModel.setProperty("/creatorId", selTokens)
                            break;
                        }
                        case 'customer_fi':
                            oControl.destroyTokens();
                            var selTokens = [];
                            if (oDataObject.fieldData !==  "") {
                                var aTokens = [];
                                var aTokenKeys = JSON.parse(oDataObject.fieldData);
                                let oCustomer = this._filterBar.getModel("$this.fb").getProperty("/customers");
                                for (var i = 0; i < aTokenKeys.length; i++) {
                                    let oCustomerDisplay = oCustomer.find(function (oCust) {
                                        return oCust.customerId === aTokenKeys[i];
                                     });
                                     oControl.addToken(new Token({
                                        key: aTokenKeys[i],
                                        text: oCustomerDisplay.customerTxt
                                     }));
                                     selTokens.push({
                                        customerId: aTokenKeys[i],
                                        customerTxt: oCustomerDisplay.customerTxt
                                     })
                                }
                            }
                            var oModel = this._getSelectedModelTab(this._selectedTab);
                            oModel.setProperty("/customerId", selTokens)
                            break;
                        }
                }, this);


            },
            /**
             * Get filters with values
             * @function
             * @private
             */
            getFiltersWithValues: function () {
                var aFiltersWithValue = this._filterBar.getFilterGroupItems().reduce(function (aResult, oFilterGroupItem) {
                    var oControl = oFilterGroupItem.getControl();
                    if (oControl.sId.includes("system_sel")
                        || oControl.sId.includes("installation_sel")
                        || oControl.sId.includes("reporter_sel")
                        || oControl.sId.includes("customer_sel")) {
                        if (oControl && oControl.getTokens && oControl.getTokens().length > 0) {
                            aResult.push(oFilterGroupItem);
                        }
                    } else {
                        if (oControl && oControl.getSelectedKeys && oControl.getSelectedKeys().length > 0) {
                            aResult.push(oFilterGroupItem);
                        }
                    }
                    return aResult;
                }, []);
                return aFiltersWithValue;
            },

            /**
             * Disable share option in smart variant
             * @function
             * @public
             */
            onAfterVariantLoad: function (oEvent) {
                this._smv.setShowShare(false); //Disable public checkbox
                var sSelectionKey = this._smv.getSelectionKey();
                if (this._smv._getVariantById(sSelectionKey).getProperty("executeOnSelection") === true || oEvent.mParameters.context === "INIT"){
                    this.onSearch();
                }
            },




            /**
             * Loads all content for Smart Filter Models
             * @function
             * @private
             * @async
             */
            _loadFilterModels: async function () {
                try {
                    const oModel = new ODataModel({
                        serviceUrl: `/backend/odata/support/`,
                        synchronizationMode: "None",
                        // for easier development
                        groupId: "$direct",
                        // groupId: "$auto",
                        operationMode: "Server"
                    });

                    // Use Model to Call Backend
                    const oInstallations = {}, aPriorities = {}, aStatus = {}, aSystems = {}, aReporters = {};
                    oInstallations.installations = {};
                    oInstallations.customers = {};
                    this._oFilterBar = new JSONModel({
                        installations: oInstallations.installations,
                        customers: oInstallations.customers,
                        priorities: aPriorities,
                        status: aStatus,
                        systems: aSystems,
                        reporters: aReporters,
                    });
                    this._filterBar.setModel(this._oFilterBar, "$this.fb");
                   // this._filterBar.getModel("$this.fb").setSizeLimit(10000);

                    const installationValue = await Installations.all(oModel);
                    this._filterBar.getModel("$this.fb").setProperty("/installations", installationValue.InstallationSet);
                    this._filterBar.getModel("$this.fb").setProperty("/customers", installationValue.CustomerSet);
                    const propertiesValue = await Priorities.all(oModel);
                    this._filterBar.getModel("$this.fb").setProperty("/priorities", propertiesValue.CasePrioritySet);

                    const closeStatus = ['8', 'Z'];
                    const draftStatus = ['1'];
                    const autoConfirm = ['3', '5', 'N'];
                    const statusValue = await Status.all(oModel);

                    this._filterBar.getModel("$this.fb").setProperty("/statusAll", statusValue.CaseStatusSet);
                    const openStatusSet = statusValue.CaseStatusSet.filter (obj => !closeStatus.includes(obj.statusId) && !draftStatus.includes(obj.statusId))
                    this._filterBar.getModel("$this.fb").setProperty("/statusOpen", openStatusSet);

                    const closeStatusSet = statusValue.CaseStatusSet.filter(obj => closeStatus.includes(obj.statusId));
                    this._filterBar.getModel("$this.fb").setProperty("/statusClosed", closeStatusSet);

                    const draftStatusSet = statusValue.CaseStatusSet.filter(obj => draftStatus.includes(obj.statusId));
                    this._filterBar.getModel("$this.fb").setProperty("/statusDrafts", draftStatusSet);

                    this._filterBar.getModel("$this.fb").setProperty("/status", statusValue.CaseStatusSet);

                    const systemsValue = await Systems.all(oModel);
                    this._filterBar.getModel("$this.fb").setProperty("/systems", systemsValue.CaseSystemSet);
                    const reportersValue = await Reporters.all(oModel);
                    this._filterBar.getModel("$this.fb").setProperty("/reporters", reportersValue.IncidentReporterSet);

                    this._filterBar.getModel("$this.fb").setProperty("/statusAutoConfirm", statusValue.CaseStatusSet.filter(obj => autoConfirm.includes(obj.statusId)));
                    // Logon User model
                    this._setLogonUserModel();
                } catch (error) {
                    this.messageHandler(error, 'debug');
                }
            },
            /**
             * FilterBar events onChange
             * @function
             * @public
             */
            onStatusChange: function () {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'status', this._selectedTab);
            },
            onSessionStateChange: function () {
                if (this._selectedTab === CaseListTabKey.SES) {
                    this._FilterHandler.updateFb(this, 'sessionState', this._selectedTab);
                }
            },
            onPriorityChange: function () {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'priority', this._selectedTab);
            },
            onLastUpdateChange: function () {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'lastUpdate', this._selectedTab);
            },

            // BEGIN HANDLERS FOR REPORTER SELECTION

            _handleReporterHelp: function (oEvent) {
                var oMultiInput = this.getControl("reporter_sel");
                var oTokens = oMultiInput.getTokens();
                // create system help dialog
                if (!this._pReporterHelpDialog) {
                    this._pReporterHelpDialog = this.getFragment('ReporterHelpDialog', this);
                    this.getView().addDependent(this._pSystemHelpDialog);
                }
                this._pReporterHelpDialog.setModel(this._filterBar.getModel("$this.fb"), "$this.fb");
                this._pReporterHelpDialog.setModel(this.getModel("i18n"), "$this.i18n");
                aListInDialog = this._pReporterHelpDialog.getItems();
                this.restoreSelectionOfList("reporterId", oTokens, aListInDialog, "$this.fb");
                this._pReporterHelpDialog.open();
            },

            _handleCreatorHelp: function () {
                const oMultiInput = this.getControl("creator_sel");
                const oTokens = oMultiInput.getTokens();
                // create system help dialog
                if (!this._pCreatorHelpDialog) {
                    this._pCreatorHelpDialog = this.getFragment('CreatorHelpDialog', this);
                    this.getView().addDependent(this._pCreatorHelpDialog);
                }
                this._pCreatorHelpDialog.setModel(this._filterBar.getModel("$this.fb"), "$this.fb");
                this._pCreatorHelpDialog.setModel(this.getModel("i18n"), "$this.i18n");
                aListInDialog = this._pCreatorHelpDialog.getItems();
                this.restoreSelectionOfList("reporterId", oTokens, aListInDialog, "$this.fb");
                this._pCreatorHelpDialog.open();
            },

            _handleReporterHelpSearch: function (oEvent) {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'reporter', this._selectedTab);
            },

            /**
             * Triggered on change event when token deleted
             *
             * @param  {event}
             * @return {void}
             */
            onReporterChange: function (oEvent) {
                var sField = 'reporter';
                this._onMultiInputChange(oEvent, sField);
            },

            onCreatorChange: function (oEvent) {
                this._onMultiInputChange(oEvent, "creator");
            },


            /**
             * Triggered on search event of value help reporterSel
             *
             * @param  {event}
             * @return {void}
             */
            handleReporterValueHelpSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var aFilters = this._generateSearchDialogFilters(["reporterId", "reporterTxt"], sValue);
                var items = oEvent.getSource().getBinding("items");
                if (items) {
                    items.filter(aFilters);
                }
            },


            /**
           * Triggered on confirm event of value help reporterSel
           *
           * @param  {event}
           * @return {void}
           */
            handleReporterValueHelpConfirm: function (oEvent) {
                var aSelectedItems = oEvent.getParameter("selectedItems");
                var aContexts = oEvent.getParameter("selectedContexts");
                var oModel = this._getSelectedModelTab(this._selectedTab);

                var oMultiInput = this.byId("reporter_sel");
                oMultiInput.destroyTokens();
                // clear search filter
                const itemsList = oEvent.getSource().getBinding("items");
                itemsList?.filter([]);

                if (aContexts?.length) {
                    oModel.setProperty("/reporterId", []);
                    var aTokens = [];
                    for (var i = 0; i < aContexts.length; i++) {
                        var oSelectedReporter = aContexts[i].getObject();
                        // add tokens to the filterbar
                        aTokens.push({
                            reporterId: oSelectedReporter.reporterId,
                            reporterTxt: oSelectedReporter.reporterTxt
                        });
                        // add tokens to the control itself
                        oMultiInput.addToken(new Token({
                            key: oSelectedReporter.reporterId,
                            text: oSelectedReporter.reporterTxt
                        }));
                    }
                    if (!this._sInitialLoading) {
                        oModel.setProperty("/reporterId", aTokens);
                    }
                    this._smv.currentVariantSetModified(true);
                    this._FilterHandler.updateFb(this, 'reporter', this._selectedTab);
                }

            },

            handleCreatorValueHelpConfirm: function (oEvent) {
                const aContexts = oEvent.getParameter("selectedContexts");
                const oModel = this._getSelectedModelTab(this._selectedTab);

                const oMultiInput = this.byId("creator_sel");
                oMultiInput.destroyTokens();
                // clear search filter
                const itemsList = oEvent.getSource().getBinding("items");
                itemsList?.filter([]);

                if (aContexts?.length) {
                    oModel.setProperty("/creatorId", []);
                    const aTokens = [];
                    for (let i = 0; i < aContexts.length; i++) {
                        const oSelectedCreator= aContexts[i].getObject();
                        // add tokens to the filterbar
                        aTokens.push({
                            reporterId: oSelectedCreator.reporterId,
                            reporterTxt: oSelectedCreator.reporterTxt
                        });
                        // add tokens to the control itself
                        oMultiInput.addToken(new Token({
                            key: oSelectedCreator.reporterId,
                            text: oSelectedCreator.reporterTxt
                        }));
                    }
                    if (!this._sInitialLoading) {
                        oModel.setProperty("/creatorId", aTokens);
                    }
                    this._smv.currentVariantSetModified(true);
                    this._FilterHandler.updateFb(this, 'creator', this._selectedTab);
                }

            },
            /**
             * Triggered on cancel event of value help reporterSel
             *
             * @param  {event}
             * @return {void}
             */
            handleReporterValueHelpCancel: function () {
                if (this._pReporterHelpDialog) {
                    this._pReporterHelpDialog.getBinding("items").filter([]);
                    this._pReporterHelpDialog._dialog.close();
                }
            },

            handleCreatorValueHelpCancel: function () {
                if (this._pCreatorHelpDialog) {
                    this._pCreatorHelpDialog.getBinding("items").filter([]);
                    this._pCreatorHelpDialog._dialog.close();
                }
            },


            // END OF HANDLERS FOR REPORTER SELECTION

            // BEGIN HANDLERS FOR CUSTOMER SELECTION

            _handleCustomerHelp: function (oEvent) {
                var oMultiInput = this.getControl("customer_sel");
                var oTokens = oMultiInput.getTokens();
                // create system help dialog
                if (!this._pCustomerHelpDialog) {
                    this._pCustomerHelpDialog = this.getFragment('CustomerHelpDialog', this);
                    this.getView().addDependent(this._pSystemHelpDialog);
                }
                this._pCustomerHelpDialog.setModel(this._filterBar.getModel("$this.fb"), "$this.fb");
                this._pCustomerHelpDialog.setModel(this.getModel("i18n"), "$this.i18n");
                aListInDialog = this._pCustomerHelpDialog.getItems();
                this.restoreSelectionOfList("customerId", oTokens, aListInDialog, "$this.fb");
                this._pCustomerHelpDialog.open();
            },

            _handleCustomerHelpSearch: function (oEvent) {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'customer', this._selectedTab);
            },

            /**
             * Triggered on change event when token deleted
             *
             * @param  {event}
             * @return {void}
             */
            onCustomerChange: function (oEvent) {
                var sField = 'customer';
                this._onMultiInputChange(oEvent, sField);
            },


            /**
             * Triggered on search event of value help customerSel
             *
             * @param  {event}
             * @return {void}
             */
            handleCustomerValueHelpSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var aFilters = this._generateSearchDialogFilters(["customerId", "customerTxt"], sValue);
                var items = oEvent.getSource().getBinding("items");
                if (items) {
                    items.filter(aFilters);
                }
            },


            /**
           * Triggered on confirm event of value help customerSel
           *
           * @param  {event}
           * @return {void}
           */
            handleCustomerValueHelpConfirm: function (oEvent) {
                var aSelectedItems = oEvent.getParameter("selectedItems"),
                    oMultiInput = this.byId("customer_sel");
                oMultiInput.destroyTokens();
                // clear search filter
                const itemsList = oEvent.getSource().getBinding("items");
                itemsList?.filter([]);

                var aContexts = oEvent.getParameter("selectedContexts");
                var oModel = this._getSelectedModelTab(this._selectedTab);

                if (aContexts?.length) {
                    oModel.setProperty("/customerId", []);
                    var aTokens = [];
                    for (var i = 0; i < aContexts.length; i++) {
                        var oSelectedCustomer = aContexts[i].getObject();
                        aTokens.push({
                            customerId: oSelectedCustomer.customerId,
                            customerTxt: oSelectedCustomer.customerTxt
                        });
                        oMultiInput.addToken(new Token({
                            key: oSelectedCustomer.customerId,
                            text: oSelectedCustomer.customerTxt
                        }));

                    }
                    if (!this._sInitialLoading) {
                        oModel.setProperty("/customerId", aTokens);
                    }
                    this._smv.currentVariantSetModified(true);
                    this._FilterHandler.updateFb(this, 'customer', this._selectedTab);
                }

            },

            /**
             * Triggered on cancel event of value help customerSel
             *
             * @param  {event}
             * @return {void}
             */
            handleCustomerValueHelpCancel: function () {
                if (this._pCustomerHelpDialog) {
                    this._pCustomerHelpDialog.getBinding("items").filter([]);
                    this._pCustomerHelpDialog._sSearchFieldValue = "";
                    this._pCustomerHelpDialog._dialog.close();
                }
            },


            // END OF HANDLERS FOR CUSTOMER SELECTION


            // BEGIN HANDLERS FOR INSTALLATION SELECTION

            _handleInstallationHelp: function (oEvent) {
                var oMultiInput = this.getControl("installation_sel");
                var oTokens = oMultiInput.getTokens();
                // create installation help dialog
                if (!this._pInstallationHelpDialog) {
                    this._pInstallationHelpDialog = this.getFragment('InstallationHelpDialog', this);
                    this.getView().addDependent(this._pInstallationHelpDialog);
                }
                this._pInstallationHelpDialog.setModel(this._filterBar.getModel("$this.fb"), "$this.fb");
                this._pInstallationHelpDialog.setModel(this.getModel("i18n"), "$this.i18n");
                aListInDialog = this._pInstallationHelpDialog.getItems();
                this.restoreSelectionOfList("installationId", oTokens, aListInDialog, "$this.fb");
                this._pInstallationHelpDialog.open();
            },

            _handleInstallationHelpSearch: function (oEvent) {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'installation', this._selectedTab);
            },

            /**
             * Triggered on change event when token deleted
             *
             * @param  {event}
             * @return {void}
             */
            onInstallationChange: function (oEvent) {
                var sField = 'installation';
                this._onMultiInputChange(oEvent, sField);
            },

            /**
             * Triggered on search event of value help installationSel
             *
             * @param  {event}
             * @return {void}
             */
            handleInstallationValueHelpSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var aFilters = this._generateSearchDialogFilters(["installationId", "installationTxt"], sValue);
                var items = oEvent.getSource().getBinding("items");
                if (items) {
                    items.filter(aFilters);
                }
            },


            /**
           * Triggered on confirm event of value help installationSel
           *
           * @param  {event}
           * @return {void}
           */
            handleInstallationValueHelpConfirm: function (oEvent) {
                var aSelectedItems = oEvent.getParameter("selectedItems"),
                    oMultiInput = this.byId("installation_sel");
                oMultiInput.destroyTokens();
                // clear search filter
                const itemsList = oEvent.getSource().getBinding("items");
                itemsList?.filter([]);

                var aContexts = oEvent.getParameter("selectedContexts");
                var oModel = this._getSelectedModelTab(this._selectedTab);

                if (aContexts?.length) {
                    oModel.setProperty("/installationId", []);
                    var aTokens = [];
                    for (var i = 0; i < aContexts.length; i++) {
                        var oSelectedInstallation = aContexts[i].getObject();
                        aTokens.push({
                            installationId: oSelectedInstallation.installationId,
                            installationTxt: oSelectedInstallation.installationTxt
                        });
                       oMultiInput.addToken(new Token({
                            key: oSelectedInstallation.installationId,
                            text:  oSelectedInstallation.installationTxt
                        }));
                    }
                    if (!this._sInitialLoading) {
                        oModel.setProperty("/installationId", aTokens);
                    }
                    this._smv.currentVariantSetModified(true);
                    this._FilterHandler.updateFb(this, 'installation', this._selectedTab);
                }
            },

            /**
             * Triggered on cancel event of value help installationSel
             *
             * @param  {event}
             * @return {void}
             */
            handleInstallationValueHelpCancel: function () {
                if (this._pInstallationHelpDialog) {
                    this._pInstallationHelpDialog.getBinding("items").filter([]);
                    this._pInstallationHelpDialog._dialog.close();
                }
            },

            // END OF HANDLERS FOR INSTALLATION SELECTION


            // BEGIN HANDLERS FOR SYSTEM SELECTION

            _handleSystemHelp: function (oEvent) {
                var oMultiInput = this.getControl("system_sel");
                var oTokens = oMultiInput.getTokens();
                // create system help dialog
                if (!this._pSystemHelpDialog) {
                    this._pSystemHelpDialog = this.getFragment('SystemHelpDialog', this);
                    this.getView().addDependent(this._pSystemHelpDialog);
                }
                this._pSystemHelpDialog.setModel(this._filterBar.getModel("$this.fb"), "$this.fb");
                aListInDialog = this._pSystemHelpDialog.getItems();
                this.restoreSelectionOfList("systemNumber", oTokens, aListInDialog, "$this.fb");
                this._pSystemHelpDialog.open();
            },

            _handleSystemHelpSearch: function (oEvent) {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'system', this._selectedTab);
            },

            /**
             * Triggered on change event when token deleted
             *
             * @param  {event}
             * @return {void}
             */
            onSystemChange: function (oEvent) {
                var sField = 'system';
                this._onMultiInputChange(oEvent, sField);
            },

            /**
             * Triggered on search event of value help systemSel
             *
             * @param  {event}
             * @return {void}
             */
            handleSystemValueHelpSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var aFilters = this._generateSearchDialogFilters(["systemNumber", "systemTxt"], sValue);
                var items = oEvent.getSource().getBinding("items");
                if (items) {
                    items.filter(aFilters);
                }
            },

            /**
             * Triggered on confirm event of value help systemSel
             *
             * @param  {event}
             * @return {void}
             */
            handleSystemValueHelpConfirm: function (oEvent) {
                var aSelectedItems = oEvent.getParameter("selectedItems"),
                    oMultiInput = this.byId("system_sel");
                oMultiInput.destroyTokens();
                // clear search filter
                const itemsList = oEvent.getSource().getBinding("items");
                itemsList?.filter([]);

                var aContexts = oEvent.getParameter("selectedContexts");
                var oModel = this._getSelectedModelTab(this._selectedTab);
                if (aContexts?.length) {
                    oModel.setProperty("/systemNumber", []);
                    var aTokens = [];
                    for (var i = 0; i < aContexts.length; i++) {
                        var oSelectedSystem = aContexts[i].getObject();
                        aTokens.push({
                            systemNumber: oSelectedSystem.systemNumber,
                            systemTxt: oSelectedSystem.systemTxt
                        });
                        // add tokens to the control itself
                        oMultiInput.addToken(new Token({
                            key: oSelectedSystem.systemNumber,
                            text: oSelectedSystem.systemId
                        }));
                    }
                    if (!this._sInitialLoading) {
                        oModel.setProperty("/systemNumber", aTokens);
                    }
                    this._smv.currentVariantSetModified(true);
                    this._FilterHandler.updateFb(this, 'system', this._selectedTab);
                }

            },
            /**
             * Triggered on cancel event of value help systemSel
             *
             * @param  {event}
             * @return {void}
             */
            handleSystemValueHelpCancel: function () {
                if (this._pSystemHelpDialog) {
                    this._pSystemHelpDialog.getBinding("items").filter([]);
                    this._pSystemHelpDialog._dialog.close();
                }
            },


            /**
             * Remove token from MultiInput: reporter, customer, installation and system
             *
             * @param  {oTokenUpdateEvent}
             * @param  {aBindingList}
             * @param  {sField}
             * @return {void}
             */
            _removeFromTokenBindingList: function (oTokenUpdateEvent, aBindingList, sField) {
                var oMultiInput = oTokenUpdateEvent.getSource(),
                    oRemoved = oTokenUpdateEvent.getParameter("removedTokens")[0],
                    iRemovedTokenIndex = oMultiInput.indexOfToken(oRemoved);
                aBindingList.splice(iRemovedTokenIndex, 1);
                this._FilterHandler.updateFb(this, sField, this._selectedTab);
            },

            /**
             * Handles the change event from MultiInput: reporter, customer, installation and system
             *
             * @param  {oEvent}
             * @param  {sField}
             */
            _onMultiInputChange: function (oEvent, sField) {
                var sFieldSuffix = sField === 'system' ? 'Number' : 'Id';
                var sFieldName = sField + sFieldSuffix;
                var sTab = this._selectedTab;
                var oModel = this._getSelectedModelTab(sTab);
                var aList = oModel.getProperty(`/${sFieldName}`);
                this._removeFromTokenBindingList(oEvent, aList, sFieldName);
                this._FilterHandler.updateFb(this, sField, this._selectedTab);
            },


            // END OF HANDLERS FOR SYSTEM SELECTION

            _getSelectedModelTab: function (sTab) {
                var oModel;
                if (sTab === CaseListTabKey.MY_OPEN) {
                    oModel = this.getModel("$this.selectionMyOpen");
                } else if (sTab === CaseListTabKey.ALL_CLOSED) {
                    oModel = this.getModel("$this.selectionAllClosed");
                } else if (sTab === CaseListTabKey.DRAFTS) {
                    oModel = this.getModel("$this.selectionDrafts");
                } else if (sTab === CaseListTabKey.FAV) {
                    oModel = this.getModel("$this.selectionFav");
                } else if (sTab === CaseListTabKey.SES) {
                    oModel = this.getModel("$this.selectionSes");
                } else if (sTab === CaseListTabKey.RESULTS) {
                    oModel = this.getModel("$this.selectionCustomSearch");
                } else if (sTab === CaseListTabKey.AUTO_CONFIRM) {
                    oModel = this.getModel("$this.selectionAutoConfirm");
                } else {
                    oModel = this.getModel("$this.selectionAllOpen");
                }
                return oModel;
            },


            /**
             * Generates dialogs for MultiInput: reporter, customer, installation and system
             *
             * @param  {aSearchFields}
             * @param  {sQueryStr}
             * @return {void}
             */
            _generateSearchDialogFilters: function (aSearchFields, sQueryStr) {
                var oFilter = null;
                var iLength = aSearchFields.length;
                if (iLength === 1) {
                    oFilter = new Filter(aSearchFields[0], sap.ui.model.FilterOperator.Contains, sQueryStr);
                } else if (iLength > 1) {
                    var searchFilters = [];
                    for (var i = 0; i < iLength; i++) {
                        searchFilters.push(new Filter(aSearchFields[i], sap.ui.model.FilterOperator.Contains, sQueryStr));
                    }
                    oFilter = new Filter({
                        filters: searchFilters,
                        bAnd: false
                    });
                }
                if (oFilter === null) {
                    return [];
                } else {
                    return [oFilter];
                }
            },

            /**
             * Mark selected token in dialogs: reporter, customer, installation and system
             *
             * @param  {sSelectKey}
             * @param  {aSelectValues}
             * @param  {aListItems}
             * @param  {sModelName}
             * @return {void}
             */
            restoreSelectionOfList: function (sSelectKey, aSelectValues, aListItems, sModelName) {
                aListItems.forEach(function (oItem) {
                    oItem.setSelected(false);
                });
                aSelectValues.forEach(function (sKey) {
                    var aItems = aListItems.filter(function (oItem) {
                        return oItem.getBindingContext(sModelName).getObject()[sSelectKey] === sKey.getProperty("key");
                    });
                    if (aItems.length === 1) {
                        aItems[0].setSelected(true);
                    }
                });
            },

            onCreatedOnChange: function () {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'createdOn', this._selectedTab);
            },

            onChangedOnChange: function () {
                if (this._selectedTab === CaseListTabKey.ALL_OPEN) {
                    this._smv.currentVariantSetModified(true);
                }
                this._FilterHandler.updateFb(this, 'changedOn', this._selectedTab);
            },

            onSearch: async function () {
                var aFilters;
                var sTab = this._selectedTab;
                var oModel = this._getSelectedModelTab(sTab);


                if (typeof oModel !== 'undefined') {
                    if (sTab !== CaseListTabKey.RESULTS) {
                        aFilters = oModel.getData();
                    } else {
                        aFilters = this._createResultsFilter();
                    }

                }

                await this._searchCases(aFilters);
                this._resetParamSorting();
                this._handleSortTableFromUserSettings();
                this._handleGroupTableFromUserSettings();

            },
            /**
             * Case list search based on filter
             * @function
             * @private
             */
            _searchCases: async function (aFilters) {
                var vOdataFilter = this._createOdataFilter(aFilters);  // filters for the backend
                var vModelFilter = this._createModelFilter(aFilters);  // filters for the frontend
                var sCaseListSource = this.getCaseListSource();
                this._handleColumnPersonalization();
                this._caseListTable.setBusy(true);
                // console.log("CaseList Source = " + sCaseListSource);
                const cases = await Cases.filter(this, vOdataFilter, sCaseListSource, this.customParameters);
                //remove auto confirm sort
                var oTable = this.getView().byId("caseListTable");
                oTable.getBinding("items").aSorters = [];

                // Get Updated Time
                const timeFormatter = DateFormat.getTimeInstance({
                    pattern: "HH:mm:ss"
                })
                const sTime = timeFormatter.format(new Date())


                this._caseListTable.setBusy(false);
                this._sInitialLoading = false;

                // Set the model
                this.getModel('$this.odata').setProperty('/', {
                    CaseList: cases.CaseList,
                    lastUpdatedTime: sTime,
                    count: cases.count
                });

                if (oTable.getBinding("items")) {
                    if (vModelFilter !== null && vModelFilter.length > 0) {
                        var filter = new sap.ui.model.Filter({
                            filters: vModelFilter
                        });
                        oTable.getBinding("items").filter(filter);
                        if (this._selectedTab === CaseListTabKey.AUTO_CONFIRM) {
                            oTable.getBinding("items").sort([new Sorter("autoConfirmDate", false)]);
                        }
                        this.getModel('$this.odata').setProperty('/count', oTable.getBinding("items").getCount());
                    } else {
                        oTable.getBinding("items").filter([]);
                    }
                }

            },

             /**
             * Create filter for odata request
             * used by _searchCases
             * @function
             * @private
             */
            _createModelFilter: function (aFilter) {
                var oFilter = [];
                var aPropertiesSessionStatus = ["aaEPSessStatus"];
                for (var i = 0; i < aPropertiesSessionStatus.length; i++) {
                    if ((aFilter.hasOwnProperty(aPropertiesSessionStatus[i])) && (aFilter[aPropertiesSessionStatus[i]].length > 0)) {
                        for (var j = 0; j < aFilter[aPropertiesSessionStatus[i]].length; j++) {
                            var oFilter0 = new Filter({
                                path: aPropertiesSessionStatus[i],
                                operator: FilterOperator.EQ,
                                value1: aFilter[aPropertiesSessionStatus[i]][j]
                            });
                            oFilter.push(oFilter0);
                        }
                    }
                }

                if(this.tableFilters){
                    oFilter = oFilter.concat(this.tableFilters);
                }
                return oFilter;
            },

            setDefaultStatusFilter: function(aFilter){
                // set default status for filter, otherwise all status case will be display
                switch(this._selectedTab) {
                    case CaseListTabKey.MY_OPEN:
                    case CaseListTabKey.ALL_OPEN: {
                        aFilter.statusId = [
                            Constants.CASE_STATUS.CUSTOMER_ACTION,
                            Constants.CASE_STATUS.IN_PROCESSING_BY_SAP,
                            Constants.CASE_STATUS.SAP_PROPOSED_SOLUTION,
                            Constants.CASE_STATUS.PENDING_RELEASE,
                            Constants.CASE_STATUS.SENT_TO_SAP_PARTNER,
                            Constants.CASE_STATUS.PARTNER_CUSTOMER_ACTION,
                            Constants.CASE_STATUS.SENT_TO_SAP
                        ];
                        break;
                    }
                    case CaseListTabKey.ALL_CLOSED:
                        aFilter.statusId = [
                            Constants.CASE_STATUS.CONFIRMED_AUTOMATICALLY,
                            Constants.CASE_STATUS.CONFIRMED
                        ];
                        break;
                }
            },

            /**
             * Create filter for odata request
             * used by _searchCases
             * @function
             * @private
             */
            _createOdataFilter: function (aFilter) {
                const aPropertiesLU = "lastUpdate"
                const aPropertiesKey = ["statusId", "priorityId", "aaEPDraftFlag"];
                const aPropertiesMI = ["systemNumber", "installationId", "reporterId", "creatorId", "customerId"];
                const aPropertiesDR = ["createdAt", "updatedAt"];
                const aFiltersAll = [];
                this.customParameters = "";

                if(aFilter.statusId?.length === 0){
                   this.setDefaultStatusFilter(aFilter)
                }
                if(aFilter.isFavorite !== undefined){
                    var oFilter = new Filter({
                        path: "isFavorite",
                        operator: FilterOperator.EQ,
                        value1:!!aFilter.isFavorite
                    });
                    aFiltersAll.push(oFilter);
                }

                for (var i = 0; i < aPropertiesKey.length; i++) {
                    if ((aFilter.hasOwnProperty(aPropertiesKey[i])) && (aFilter[aPropertiesKey[i]].length > 0)) {
                        var aFilters = [];
                        for (var j = 0; j < aFilter[aPropertiesKey[i]].length; j++) {
                            var oFilter = new Filter({
                                path: aPropertiesKey[i],
                                operator: FilterOperator.EQ,
                                value1: aFilter[aPropertiesKey[i]][j]
                            });
                            aFilters.push(oFilter);
                        }
                        var aFilterT = new Filter({ filters: aFilters, or: true });
                        aFiltersAll.push(aFilterT);
                    }
                }

                for (var i = 0; i < aPropertiesMI.length; i++) {
                    if ((aFilter.hasOwnProperty(aPropertiesMI[i])) && (aFilter[aPropertiesMI[i]].length > 0)) {
                        var aFilters = [];
                        for (var j = 0; j < aFilter[aPropertiesMI[i]].length; j++) {
                            var sValue = "";
                            var sPath = "";
                            switch (aPropertiesMI[i]) {
                                case "systemNumber":
                                    sValue =  aFilter[aPropertiesMI[i]][j].systemNumber;
                                    sPath = "systemNumber";
                                    break;
                                case "installationId":
                                    sValue =  aFilter[aPropertiesMI[i]][j].installationId;
                                    sPath = "installationId";
                                    break;
                                case "reporterId":
                                    sValue =  aFilter[aPropertiesMI[i]][j].reporterId;
                                    sPath = "reporterId";
                                    break;
                                case "creatorId":
                                    sValue =  aFilter[aPropertiesMI[i]][j].reporterId;
                                    sPath = "createdBy";
                                    break;
                                case "customerId":
                                    sValue =  aFilter[aPropertiesMI[i]][j].customerId;
                                    sPath = "customerId";
                                    break;
                            }

                            const oFilter = new Filter({
                                path: sPath,
                                operator: FilterOperator.EQ,
                                value1: sValue
                            });
                            aFilters.push(oFilter);
                        }
                        if (this._selectedTab === CaseListTabKey.MY_OPEN && aPropertiesMI[i] === "reporterId"){
                            this.customParameters = {
                                reporterId: sValue,
                                createdBy: sValue
                            };
                        }else{
                            const aFilterT = new Filter({ filters: aFilters, or: true });
                            aFiltersAll.push(aFilterT);
                        }
                    }
                }

                for (var i = 0; i < aPropertiesDR.length; i++) {
                    if ((aFilter.hasOwnProperty(aPropertiesDR[i])) && (aFilter[aPropertiesDR[i]].fromEPOCH !== '')) {
                        var oFilter = new Filter({
                            path: aPropertiesDR[i],
                            operator: FilterOperator.BT,
                            value1: aFilter[aPropertiesDR[i]].fromEPOCH,
                            value2: aFilter[aPropertiesDR[i]].toEPOCH
                        });
                        aFiltersAll.push(oFilter);
                    }
                }

                var aFilterLU = aFilter[aPropertiesLU];
                aFilterLU = aFilterLU === null  || aFilterLU === undefined ? "ALL" : aFilterLU;

                // Last Update Filter
                var aFiltersLU = [];

                var oFilterLUX = new Filter({
                        path: aPropertiesLU,
                        operator: FilterOperator.EQ,
                        value1: aFilterLU
                    });

               aFiltersLU.push(oFilterLUX);
               var aFilterL = new Filter({filters:aFiltersLU});
               aFiltersAll.push(aFilterL);

               if (this._selectedTab === CaseListTabKey.RESULTS) {
                    var aFilterST = this._createResultsFilter();
                    if (aFilterST) {
                        aFiltersAll.push(aFilterST)
                    }
                }

                var vOdataFilter = new Filter({ filters: aFiltersAll, and: true });
                return vOdataFilter;

        },

            /**
             * Select the Source REST API for Case List
             * whether CaseListAggregated or CaseList
             * used by _searchCases
             * @function
             * @private
             */

            getCaseListSource: function () {
                var sBtnSelection = this.byId("dataSource").getSelectedKey();
                sBtnSelection = (sBtnSelection === null || sBtnSelection === "") ? "Aggregated" : sBtnSelection;
                return sBtnSelection;
            },

            /***
             *       ___                _____     _    _
             *      / __|__ _ ___ ___  |_   _|_ _| |__| |___
             *     | (__/ _` (_-</ -_)   | |/ _` | '_ \ / -_)
             *      \___\__,_/__/\___|   |_|\__,_|_.__/_\___|
             *
             *     FINDCT
             *
             */

            /**
             * Opens OSLP in a new tab and focuses that tab
             * @function
             * @public
             */
            onCreateNewCasePressed: () => {
                Router.getRouter("shellRouter").navTo("createIssue", {
                    draftCasePointer: "0",
                    section: "overview"
                });
            },

            /**
             * Triggering local table search
             *
             * @param  {void}
             * @return {void}
             */
            onSearchTable: function (oEvent) {
                const view = this.getView();
                this.tableFilters = [];
                let searchFilters = [];
                const favoriteFilter = [];

                const containsField = [ "sapNumber", "sapYear", "subject", "statusTxt", "priorityTxt","installationTxt","systemTxt","componentTxt","componentKey",
                                        "customerTxt","reporterTxt","reporterId", "createdBy", "creationDate","creationTime","updateDate","updateTime","autoConfirmDateTxt" ];

                let queryStr = oEvent.getParameters().value;
                if(typeof queryStr === 'undefined'){ //click favorite button
                    queryStr = view.byId("filterTable").getValue()
                }else{
                    this.getModel('$this.searchInput').setProperty('/value', queryStr);
                }

                if (queryStr && queryStr.length > 0) {
                    containsField.forEach((field) => {
                        const filter = new sap.ui.model.Filter(field, sap.ui.model.FilterOperator.Contains, queryStr);
                        searchFilters.push(filter);
                    })
                }

                if (searchFilters.length > 0 ) {
                    const filter = new sap.ui.model.Filter({
                        filters: searchFilters,
                        bAnd: false
                    });
                    this.tableFilters.push(filter);
                }

                const bFavoritesOnOff = view.byId("favoritesOnOff").getSelected();

                if (bFavoritesOnOff) {
                    const favoriteSearch = new sap.ui.model.Filter("isFavorite", sap.ui.model.FilterOperator.EQ, true);
                    favoriteFilter.push(favoriteSearch);

                    const filter = new sap.ui.model.Filter({
                        filters: favoriteFilter,
                        bAnd: true
                    });
                    this.tableFilters.push(filter);
                }

                var oTable = this.getView().byId("caseListTable");
                if (oTable.getBinding("items")) {
                    if (this.tableFilters !== null && this.tableFilters.length > 0) {
                        const filter = new sap.ui.model.Filter({
                            filters: this.tableFilters,
                            bAnd: true
                        });
                        oTable.getBinding("items").filter(filter);
                    } else {
                        oTable.getBinding("items").filter([]);
                    }
                    this.getModel('$this.odata').setProperty('/count', oTable.getBinding("items").getCount());
                }
            },

            /**
             * Handles Tab Selection
             * @function
             * @public
             * @param {sap.ui.base.Event} oEvent
             */
            onTabFilterSelect: function (oEvent) {
                var aFilters = [];
                var sKey = oEvent.getParameter("key");
                this._handleTabFilterSelect(sKey);
                if (sKey !== CaseListTabKey.RESULTS) {
                    this._updateUserSettings("Tab");
                }
                this._filterBar.setVisible(sKey !== CaseListTabKey.RESULTS);
                this._resetParamSorting();
                if (typeof this.getModel('$this.selection') !== 'undefined') {
                    if (sKey !== CaseListTabKey.RESULTS) {
                        aFilters = this.getModel('$this.selection').getData();
                    } else {
                        aFilters = this._createResultsFilter();
                    }
                }
                this.tableFilters = [];
                this._searchCases(aFilters);
            },


            _createResultsFilter : function() {

               let sSearchParamName = "searchTerm";
               let oFilter;
               if (this.searchParams.searchTerm) {
                    oFilter = new Filter({
                        path: sSearchParamName,
                        operator: FilterOperator.EQ,
                        value1: decodeURIComponent(this.searchParams.searchTerm)
                    });
                }

                return oFilter;

            },

            /**
            * Handles Tab Selection
            * @function
            * @private
            * @param {string} tab
            */
            _handleTabFilterSelect: async function (tab) {
                if(!this._smv) {
                    this.createSMV();
                }

                if(!this._smv._bIsInitialized && (tab === CaseListTabKey.ALL_OPEN || tab === "ALL" )){
                    this._smv.initialise(function () { }, this._filterBar);
                }

                this._selectedTab = tab;
                this._smv.setProperty("visible", false);
                this._smv.setProperty("enabled", false);
                this.getView().byId('system_sel').removeAllTokens();
                this.getView().byId('installation_sel').removeAllTokens();
                this.getView().byId('customer_sel').removeAllTokens();
                this.getModel("$this.selectionAllOpen").setProperty("/showCreator", this.isSupportCustomer && tab === CaseListTabKey.ALL_OPEN);

                let oModel = SharedModels.getUserModel().getData();
                const sUserId = oModel.simulatedUser || oModel.userName;
                const sUserName = oModel.simulatedUser || oModel.firstName + " " + oModel.lastName;

                let bEnabled = tab !== CaseListTabKey.SES;
                this.getControl('tableSettingsButton').setEnabled(bEnabled);

                switch (tab) {

                    case CaseListTabKey.ALL_OPEN:
                        this.getView().byId('reporter_sel').removeAllTokens();
                        this._smv.setProperty("visible", true);
                        this._smv.setProperty("enabled", true);
                        this._filterBar.getModel("$this.fb").setProperty("/status", this._filterBar.getModel("$this.fb").getProperty("/statusOpen"));
                        oModel = this.getModel("$this.selectionAllOpen");
                        break;

                    case 'MY': //upward compatible
                    case CaseListTabKey.MY_OPEN:
                        oModel = this.getModel("$this.selectionMyOpen");
                        this._filterBar.getModel("$this.fb").setProperty("/status", this._filterBar.getModel("$this.fb").getProperty("/statusOpen"));
                        var oMultiInput = this.byId("reporter_sel");
                        oMultiInput.destroyTokens();
                        oMultiInput.addToken(new Token({
                          key: sUserId,
                          text: sUserName
                        }));
                        break;

                    case CaseListTabKey.ALL_CLOSED:
                        this.getView().byId('reporter_sel').removeAllTokens();
                        this._filterBar.getModel("$this.fb").setProperty("/status", this._filterBar.getModel("$this.fb").getProperty("/statusClosed"));
                        oModel = this.getModel("$this.selectionAllClosed");
                        break;

                    case CaseListTabKey.DRAFTS:
                        oModel = this.getModel("$this.selectionDrafts");
                        this._filterBar.getModel("$this.fb").setProperty("/status", this._filterBar.getModel("$this.fb").getProperty("/statusDrafts"));
                        var oMultiInput = this.byId("reporter_sel");
                        oMultiInput.destroyTokens();
                        oMultiInput.addToken(new Token({
                          key: sUserId,
                          text: sUserName
                        }));
                        break;

                    case CaseListTabKey.FAV :
                        this._filterBar.getModel("$this.fb").setProperty("/status", this._filterBar.getModel("$this.fb").getProperty("/statusAll"));
                        this.getView().byId('reporter_sel').removeAllTokens();
                        oModel = this.getModel("$this.selectionFav");
                        break;

                    case CaseListTabKey.SES :
                        this.getView().byId('reporter_sel').removeAllTokens();
                        oModel = this.getModel("$this.selectionSes");
                        break;

                    case CaseListTabKey.RESULTS :
                        oModel = this.getModel("$this.selectionCustomSearch");
                        this.getControl("resultsTab").setVisible(true);
                        this._filterBar.setVisible(false);
                        break;

                    case CaseListTabKey.AUTO_CONFIRM :
                        this.getView().byId('reporter_sel').removeAllTokens();
                        this._filterBar.getModel("$this.fb").setProperty("/status", this._filterBar.getModel("$this.fb").getProperty("/statusAutoConfirm"));
                        oModel = this.getModel("$this.selectionAutoConfirm");
                        break;

                    default :
                        this.getView().byId('reporter_sel').removeAllTokens();
                        this._smv.setProperty("visible", true);
                        this._smv.setProperty("enabled", true);
                        this._filterBar.getModel("$this.fb").setProperty("/status", this._filterBar.getModel("$this.fb").getProperty("/statusOpen"));
                        oModel = this.getModel("$this.selectionAllOpen");
                        break;

                }

                this.setModel(oModel, '$this.selection');
                this.getOwnerComponent().getModel("userProfileModel").setProperty("/Tab", tab);
                this.getModel('$this.searchInput').setProperty('/value', "");
                this.getView().byId("favoritesOnOff").setSelected(false);
                this.getView().byId("favoritesOnOff").setVisible(tab !== CaseListTabKey.FAV);
            },

            /**
             * Opens Settings Table Dialog
             * @function
             * @public
             */
            openTableSettings: function () {

                if (this._iconTabBar.getSelectedKey()===CaseListTabKey.SES) {
                   window.alert("Functionality not implemented yet");
                   return;
                }

                if (!this._tableSettingsDialog) {
                    this._tableSettingsDialog = this.getFragment('TableSettings', this);
                    this.getView().addDependent(this._tableSettingsDialog);
                }

                try {
                    const oGroupOptions =  JSON.parse(this.getOwnerComponent().getModel("userProfileModel").getProperty("/Group"));
                    const sGroupField = oGroupOptions[0].sPath;
                    const bGroupDescending =  oGroupOptions[0].bDescending;
                    this._tableSettingsDialog.setSelectedGroupItem(sGroupField);
                    this._tableSettingsDialog.setGroupDescending(bGroupDescending);
                } catch (e) {
                    // no grouping applied
                }

                this._tableSettingsDialog.open();
            },

            /**
            * Applies  sorting of columns to the case list table from user profile settings
            * @function
            * @public
            */
            _handleSortTableFromUserSettings: function () {
                let oSortOptions = null;
                let groupOptions = null;
                const oBinding = this._caseListTable.getBinding('items');
                try {
                    oSortOptions = JSON.parse(this.getOwnerComponent().getModel("userProfileModel").getProperty("/Sort"));
                } catch (error) {
                    // wrong data in model
                    return;
                }
                try {
                    oGroupOptions = JSON.parse(this.getOwnerComponent().getModel("userProfileModel").getProperty("/Group"));
                } catch (error) {
                    // wrong data in model
                    return;
                }
                let aSorter = [];
                let sPath = oSortOptions[0].sPath;
                let bSortDesc = oSortOptions[0].bDescending;
                aSorter.push(new sap.ui.model.Sorter(sPath, bSortDesc));
                oBinding.sort(aSorter);
            },

            /**
            * Applies  grouping of columns to the case list table from user profile settings
            * @function
            * @public
            */

            _handleGroupTableFromUserSettings: function () {
                let oSortOptions = null;
                let groupOptions = null;
                let aGroups = [];
                const oBinding = this._caseListTable.getBinding('items');
                try {
                    oGroupOptions = JSON.parse(this.getOwnerComponent().getModel("userProfileModel").getProperty("/Group"));
                } catch (error) {
                    // wrong data in model
                    return;
                }
                let sPathG = oGroupOptions[0].sPath;
                let bDescendingG = oGroupOptions[0].bDescending;
                let vGroup = mGroupFunctions[sPathG];
                aGroups.push(new sap.ui.model.Sorter(sPathG, bDescendingG, vGroup));
                oBinding.sort(aGroups);
            },

            /**
             * Selects all list items in select dialog that are currently displayed
             * in the case table
             * @function
             * @private
             *
             */
            _checkCurrentlyDisplayedColumns: function () {
                this.getCoreControl('tableColumnsSelectDialog').setBusy(true);
                // Get currently shown columns
                let aColumns = this._caseListTable.getColumns();
                aColumns = aColumns.map((arg) => {
                    const oColumn = arg.getHeader().getItems()[0];
                    if (arg.getVisible()) {
                        return oColumn.getProperty('text');
                    }
                });
                // Select list items based on current displayed columns
                const aListItems = this.getCoreControl(
                    'tableColumnsSelectDialog',
                ).getSortItems();
                aListItems.forEach(
                    function (aListItem) {
                        aColumns.includes(aListItem.getProperty("text"))
                            ? aListItem.setVisible(true)
                            : aListItem.setVisible(false);
                    }.bind(this),
                );
                this.getCoreControl('tableColumnsSelectDialog').setBusy(false);
            },

            /**
             * Applies the selected list of columns to the case list table
             * @function
             * @public
             * @param {sap.ui.base.Event} oEvent
             */
            _handleColumnSelection: function (oEvent) {
                // Get selected columns
                var aSelectedItems = [];
                var that = this;
                let oSelectedItems = this.getModel("caseColumns").getProperty('/columnsSettings');
                oSelectedItems.forEach(function (obj) {
                    if (obj.visible === true) {
                        var sField = that._i18nWrapper.getText(obj.text);
                        aSelectedItems.push(sField);
                    }
                });

                // Show or hide columns based on selection
                const aColumns = this._caseListTable.getColumns();
                let iPrioCount = 0; // workaround to hide the Priority ID Column...
                aColumns.forEach(
                    function (arg) {
                        const oColumn = arg.getHeader().getItems()[0];
                        const columnTitle = oColumn.getProperty('text');
                        if (columnTitle === that._i18nWrapper.getText("")) {
                            arg.setVisible(true);
                         }
                        else if (columnTitle === that._i18nWrapper.getText("tablecol_priorityId") && iPrioCount === 0) {
                            arg.setVisible(false);
                            iPrioCount++;
                        } else {
                            arg.setVisible(aSelectedItems.includes(columnTitle));
                        }
                    }.bind(this),
                );
                this.getOwnerComponent().getModel("userProfileModel").setProperty("/Columns", oSelectedItems);
                // this._caseListTable.setBusy(false);
            },

            /**
            * Applies the column personalization
            * @function
            * @public
            * @param {sap.ui.base.Event} oEvent
            */
            _handleColumnPersonalization: function () {
                // Get selected columns
                var aSelectedItems = [];
                var that = this;
                var oColumns = null;
                var aColumns1 = null;
                var sTab = this._iconTabBar.getSelectedKey();
                var oColumns = null;

                try {
                    oColumns = JSON.parse(this.getOwnerComponent().getModel("userProfileModel").getProperty("/Columns"));
                } catch (error) {
                    // no action taken
                }
                try {
                    aColumns1 = oColumns.aColumns;
                } catch (error) {
                    // no action taken
                }
                var aColSelModel = [];
                var iSelectedColumns = 0;
                if (oColumns === null || aColumns1 === null) {
                    // TODO: RESET JSON MODEL TO DEFAULT FOR COLUMNS IN CASE OF WRONG DATA
                    return;
                }

                oColumns.aColumns.forEach(function (obj) {
                    if (obj[2]) {
                        var sField = that._i18nWrapper.getText(obj[0]);
                        aSelectedItems.push(sField);
                        iSelectedColumns = iSelectedColumns + 1;
                    }
                    aColSelModel.push({
                        text: obj[0],
                        order: obj[1],
                        visible: obj[2],
                        key: obj[3]
                    });
                });

                // Show or hide columns based on selection
                const aColumns = this._caseListTable.getColumns();
                let iPrioCount = 0; // workaround to hide the Priority ID Column...

                var bSesColumnVisibility = sTab === CaseListTabKey.SES;
                const creatorVisible = this.isSupportCustomer && sTab === CaseListTabKey.ALL_OPEN;

                aColumns.forEach(
                    function (arg) {
                        // oColumn = the Hbox arg
                        const oColumn = arg.getHeader().getItems()[0];
                        const columnTitle = oColumn.getProperty('text');
                        if (columnTitle === that._i18nWrapper.getText("")) {
                           arg.setVisible(true);
                        }
                        else if (columnTitle === that._i18nWrapper.getText("tablecol_priorityId") && iPrioCount === 0) {
                            arg.setVisible(false);
                            iPrioCount++;
                        } else  if (columnTitle === that._i18nWrapper.getText("tablecol_createdon")) {
                               arg.setVisible(!bSesColumnVisibility);
                           } else if (columnTitle === that._i18nWrapper.getText("tablecol_sessionstate") ||
                                    columnTitle === that._i18nWrapper.getText("tablecol_sessioncreated") ||
                                    columnTitle === that._i18nWrapper.getText("tablecol_sessioncompleted")) {
                                    arg.setVisible(bSesColumnVisibility);
                           } else {
                                  arg.setVisible(aSelectedItems.includes(columnTitle));
                           }
                    }.bind(this),
                );

                this.getModel("caseColumns").setProperty("/columnsSettings", aColSelModel);

                // this._caseListTable.setBusy(false);
            },

            /**
             * Generate Group by Functions Object
             * @function
             * @private
             */
            _generateGroupFunctions: function () {
                let oGroupFunctions = {};
                // Gets group setting from case columns model
                const aGroups = this.getOwnerComponent()
                    .getModel('userProfileSettings')
                    .getProperty('/Group');
                // Creates a function for each element
                aGroups.forEach((oGroup) => {
                    oGroupFunctions[oGroup.key] = (oContext) => {
                        oContext.getProperty(oGroup.key);
                        return {
                            key: oContext.getProperty(oGroup.key),
                            text: oContext.getProperty(oGroup.text),
                        };
                    };
                });

                // Sets the created object of functions to context
                this._mGroupFunctions = oGroupFunctions;
            },

            /**
             * Applies the selected list of columns to the case list table
             * @function
             * @public
             * @param {sap.ui.base.Event} oEvent
             */
            _handleGroupTable: function (oEvent) {
                // Set grouping
                const mParams = oEvent.getParameters();
                let aGroups = [];
                let sPath = "";
                let bDescending = false;
                if (mParams.groupItem) {
                    sPath = mParams.groupItem.getKey();
                    bDescending = mParams.groupDescending;
                    const vGroup = mGroupFunctions[sPath];
                    aGroups.push(new Sorter(sPath, bDescending, vGroup));
                }
                // Update list binding
                const oBinding = this._caseListTable.getBinding('items');
                oBinding.sort(aGroups);
                this.getOwnerComponent().getModel("userProfileModel").setProperty("/Group", aGroups);
            },


            /**
             * Applies the selected list of columns to the case list table
             * @function
             * @public
             * @param {sap.ui.base.Event} oEvent
             */
            onConfirmViewSettings: function (oEvent) {
                this._handleGroupTable(oEvent);
                this._handleColumnSelection(oEvent);
                this._updateUserSettings("Group");
                this._updateUserSettings("Columns");
            },

            _updateUserSettings: function (sType) {
                let data = {};
                let method = "POST";
                let sUrl = "/backend/raw/support/CaseListUserPersonalization" + (sType !== "Columns" ? "List" + sType : sType + "Selection");
                data.columns = this.getOwnerComponent().getModel("userProfileModel").getProperty("/Columns");
                data.sort = this.getOwnerComponent().getModel("userProfileModel").getProperty("/Sort");
                data.group = this.getOwnerComponent().getModel("userProfileModel").getProperty("/Group");
                data.tab = this.getOwnerComponent().getModel("userProfileModel").getProperty("/Tab");

                return new Promise((resolve, reject) => {
                    jQuery.ajax(sUrl, {
                        method: method,
                        contentType: "application/json",
                        data: JSON.stringify(data),
                        success: (result) => {
                            resolve(result);
                        },
                        error: (error) => {
                            reject(error);
                        }
                    });
                });
            },

            _getPropertyColumn: function (sLabel) {
                var aColumns;
                if (typeof this.getModel("caseColumns") !== 'undefined') {
                    var aColumns = this.getModel("caseColumns").getData();
                }
                return aColumns.columns.filter(oCol => this._i18nWrapper.getText(oCol.text) === sLabel).map(oCol => oCol.key).toString();
            },
            _createColumnConfig: function () {
                var that = this;
                var aColumns = [];
                var iPrioCount = 0;
                aColumns = this._caseListTable.getColumns();
                aColumns = aColumns.map((arg) => {
                    const oColumn = arg.getHeader().getItems()[0];
                    const columnTitle = oColumn.getProperty('text');
                    if (columnTitle !== that._i18nWrapper.getText("")) {
                        if (arg.getVisible() || that._i18nWrapper.getText("tablecol_reporterId") || that._i18nWrapper.getText("tablecol_customerId") || that._i18nWrapper.getText("tablecol_systemId") || that._i18nWrapper.getText("tablecol_subject")) {
                            var oResult = {};
                            var sProperty = this._getPropertyColumn(oColumn.getProperty('text'));
                            if  (sProperty === "priorityId,priorityTxt") {
                                sProperty = "priorityTxt";
                                iPrioCount = iPrioCount + 1;
                            }
                            var sType = EdmType.String;
                            if (sProperty === "updatedAt" || sProperty === "createdAt") {
                                sType = EdmType.DateTime;
                            }
                            if (iPrioCount === 1 || sProperty != "priorityTxt" ) {
                                try {
                                    oResult = {
                                        label: oColumn.getProperty('text'),
                                        type: sType,
                                        property: sProperty
                                        };
                                        if (sProperty === "componentTxt" || sProperty === "createdAt" || sProperty === "updatedAt"){
                                            oResult.wrap = true
                                        }
                                    return oResult;
                                } catch (err) {
                                    // does not return the column
                                }
                            }

                        }
                    }
                });
                return aColumns;
            },
            onExport: function () {
                var aCols, oSettings, oSheet, oTable, aCases;
                oTable = this._caseListTable;
                aCases = this.getModel("$this.odata").getProperty("/CaseList");
                aCases.forEach(item =>{
                        item.systemNumber = item?.systemNumber.substring(9);
                        item.componentTxt = item?.componentTxt+'\r\n' +'('+ item?.componentKey +')';
                        item.customerTxt = item?.customerTxt.split("-").slice(1).join("-");
                    }
                );
                aCols = this._createColumnConfig();
                oSettings = {
                    workbook: {
                        columns: aCols,
                        hierarchyLevel: 'Level'
                    },
                    dataSource: aCases,
                    fileName: 'caseList.xlsx',
                    worker: false // We need to disable worker because we are using a MockServer as OData Service
                };
                oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },


            /**
             * @description status mapping statusTxt
             *      1: Not Set to SAP
             *      8: CONFIRM
             *      Z: Confirmed Automatically
             */
            _setAuthClose: async function (oPreviewModelData, oPopover) {
                await helper.currentUserPermission(oPreviewModelData.pointer, oPopover);
                if (oPreviewModelData.statusId === "1" || oPreviewModelData.statusId === "8" || oPreviewModelData.statusId === "Z" || oPreviewModelData.source === "019") {
                    const currentUser = this._oUserModel.userName;
                    if (oPreviewModelData.statusId === "1" && currentUser === oPreviewModelData.reporterId) {
                        oPreviewModelData.isCanClose = true;
                    } else {
                        oPreviewModelData.isCanClose = false;
                    }
                }
            },
            /**
             * Open Popover incident preview
             *
             * @param  {oButton}
             * @return {void}
             */
            _createPopOverPreview: async function (oButton) {

                var oPreviewModel = oButton.getBindingContext('$this.odata').getObject();
                var sPath = oButton.getBindingContext('$this.odata').getPath();
                // create popover
                if (!this._oPopover) {
                    this._oPopover = this.getFragment("Preview", this);
                    this.getView().addDependent(this._oPopover);
                }
                //discussion
                oPreviewModel.lctype = '';
                oPreviewModel.lcdateTime = '';
                oPreviewModel.lcoriginalText = '';
                oPreviewModel.isSAPAgent = false;
                oPreviewModel.RespITSM = "";

                //auth
                oPreviewModel.isCanWrite = false;
                oPreviewModel.isCanRead = false;
                oPreviewModel.isCanClose = false;
                oPreviewModel.isShowDeleteButton = false;
                oPreviewModel.isShowCloseButton = true;
                if (this._selectedTab === CaseListTabKey.DRAFTS) {
                    oPreviewModel.isShowCloseButton = false;
                    //TODO
                    const result = await jQuery.ajax("/backend/raw/support/CasePermissionW7Verticle?action=COMPLETE&pointer=" + oButton.getBindingContext('$this.odata').getObject().pointer, {
                        method: "GET",
                        contentType: "application/json"
                    }).catch(e => {
                        console.error(e);
                    });
                    if (result?.AuthResult === "PASS") {
                        oPreviewModel.isShowDeleteButton = true;
                    }
                }
                this._oPopover.setModel(this._oPopover._oContextModel = new JSONModel(oPreviewModel), "$this.preview");
                //make sure get customer close permission before init qualitricks
                await this._setAuthClose(oPreviewModel, this._oPopover);

                const sQueryParams = '?pointer=' + oButton.getBindingContext('$this.odata').getObject().pointer;
                const oModel = new ODataModel({
                    serviceUrl: `/backend/odata/support/${sQueryParams}`,
                    synchronizationMode: "None",
                    groupId: "$direct",
                    operationMode: "Server"
                });
                const oListBinding = oModel.bindList("/CaseDiscussion");
                oListBinding.attachRefresh(() => {
                    oListBinding.getContexts();
                });
                oListBinding.refresh();

                this._oPopover.setBusy(true);
                this._oPopover.openBy(oButton); // trying to open before

                oListBinding.attachDataReceived((oEvent) => {
                    const oContexts = oEvent.getSource().getCurrentContexts();
                    if ((typeof oContexts !== 'undefined') && (typeof oContexts[0] !== 'undefined')) {
                        const lastOne = oContexts.map(c=>c.getObject()).reduce((a,b)=>a.dateTime.localeCompare(b.dateTime) > 0 ? a : b)
                        this._oPopover.getModel('$this.preview').setProperty("/lctype", lastOne.type);
                        this._oPopover.getModel('$this.preview').setProperty("/lcdateTime", lastOne.dateTime);
                        const sText = '<div>' + lastOne.originalText + '</div>';
                        this._oPopover.getModel('$this.preview').setProperty("/lcoriginalText", sText);
                        this._oPopover.getModel('$this.preview').setProperty("/isSAPAgent", lastOne.isSAPAgent);
                    }
                    //                if(oButton.getAggregation("cells")){
                    //                oButton = oButton.getAggregation("cells")[0];
                    //                }

                    // init qualitricks
                    if (oPreviewModel?.isCanClose) {
                        this.initFeedBackSurvey ();
                    };
                    this._oPopover.setBusy(false);

                }, this);
            },

             /**
             * Open Popover incident preview
             *
             * @param  {oButton}
             * @return {void}
             */
            _createPopOverPreviewArchivedCase: function (oButton) {
                // IF 3H  OPENS https://userapps.support.sap.com/sap/support/incident/print/default.htm?pointer=POINTERID
                // i.e. https://userapps.support.sap.com/sap/support/incident/print/default.htm?pointer=002028376700044607242022

                var oPreviewModel = oButton.getBindingContext('$this.odata').getObject();
                var sPath = oButton.getBindingContext('$this.odata').getPath();

                this._pdfViewer = new PDFViewer();
                this.getView().addDependent(this._pdfViewer);
                this._pdfViewer.setTitle(this._i18nWrapper.getText("preview_archived_case"));

                let sPointer = oPreviewModel.pointer;
                let sUrl = `https://userapps.support.sap.com/sap/support/incident/print/default.htm?pointer=${sPointer}`;

                this._pdfViewer.setSource(sUrl);

                // create popover
                if (!this._oPopoverArchivedCase) {
                    this._oPopoverArchivedCase = this.getFragment("PreviewArchivedCase", this);
                    this.getView().addDependent(this._oPopoverArchivedCase);
                }

                this._oPopoverArchivedCase.openBy(oButton); // trying to open before

            },

             /**
             * Open PDF Viewer for Archived Cases
             *
             * @param  {pointer}
             * @return {void}
             */
             onOpenArchivedCase : function() {

                this._pdfViewer.open();

             },

            onClosePreviewArchivedCaseDialog: function (oEvent) {
                this._oPopoverArchivedCase.close();
            },

            onCancelPreviewDialog: function (oEvent) {
                this._oPopover.close();
            },
            //delete draft
            onDeleteCase: function (oEvent) {
                let oPreviewModel = oEvent.getSource().getModel("$this.preview").getData();
                sap.m.MessageBox.confirm(new FormattedText({ htmlText: this._i18nWrapper.getText("CreateDeleteDraft_message_content") }),
                    {
                        title: this._i18nWrapper.getText("caseDeleteTipTitle"),
                        styleClass: "",
                        actions: ["YES", "NO"],
                        emphasizedAction: "YES",
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit,
                        onClose: function (sAction) {
                            if (sAction === "YES") {
                                this._deleteDraft(oPreviewModel);
                            }
                        }.bind(this)
                    });
            },

            onCloseCase: function (oEvent) {
                let oPreviewModel = oEvent.getSource().getModel("$this.preview").getData();
                sap.m.MessageBox.confirm(new FormattedText({ htmlText: this._i18nWrapper.getText("caseCloseTipText1") }),
                    {
                        title: this._i18nWrapper.getText("caseCloseTipTitle"),
                        styleClass: "",
                        actions: ["YES", "NO"],
                        emphasizedAction: "YES",
                        initialFocus: null,
                        textDirection: sap.ui.core.TextDirection.Inherit,
                        onClose: function (sAction) {
                            if (sAction === "YES") {
                                this._closeCase(oPreviewModel);
                            }
                        }.bind(this)
                    });
            },

            _closeCase: function (oPreviewModel) {
                this._mainPage.setBusy(true);
                $.ajax("/backend/raw/support/CaseUpdateVerticle", {
                    method: "PUT",
                    contentType: "application/json",
                    data: JSON.stringify({
                        action: "CONFIRM",
                        pointer: oPreviewModel.pointer,
                        long_text: this._i18nWrapper.getText("caseHaseBeenClosed"),
                        status: oPreviewModel.statusId
                    })
                }).done(() => {
                    this._mainPage.setBusy(false);
                    MessageToast.show(`${this._i18nWrapper.getText("caseCloseSuccess")}`);
                    this.onSearch();
                    this.showFeedBackSurvey(oPreviewModel);
                }).fail(() => {
                    this._mainPage.setBusy(false);
                    MessageToast.show(`${this._i18nWrapper.getText("caseCloseFailed")}`);
                });
            },

            _deleteDraft: function (oPreviewModel) {
                this._mainPage.setBusy(true);
                jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
                    method: "PUT",
                    contentType: "application/json",
                    data: JSON.stringify({
                        action: "COMPLETE",
                        pointer: oPreviewModel.pointer,
                        draft_flag: "X"
                    }),
                    success: () => {
                        MessageToast.show(`${this._i18nWrapper.getText("caseDeleteSuccess")}`);
                        this.onSearch();
                    },
                    error: () => {
                        MessageToast.show(`${this._i18nWrapper.getText("caseDeleteFailed")}`);
                    }
                }).always(() => {
                    this._mainPage.setBusy(false);
                });
            },

            initFeedBackSurvey: function () {
                $.ajax ("/backend/raw/support/CaseQualtricsAuthW7?pointer=" + this._oPointer, {
                    method: "GET",
                    contentType: "application/json"
                }).done ((url) => {
                    if (url) {
                        QualtricsService.initQualtricsSurvey (url, this);
                    }
                }).fail (() => {
                    //do nothing just let it go
                });
            },

            showFeedBackSurvey: function (oPreviewModel) {
                if (this._surveyUrl.w7pUrl) {
                    this.openQualtricsIntercept (oPreviewModel);
                }
                if (this._surveyUrl.proUrl) {
                    this.openProcessorSurvey (oPreviewModel);
                }
            },

            processLanguageCode : function() {
                let preferredLang = getPreferredLanguage();
                let lang = preferredLang ? preferredLang.toUpperCase() : sap.ui.core.Configuration.getLanguage().toUpperCase();
                let qualtricsLangList = {
                    "DE": "DE",
                    "JA": "JA",
                    "ZH-CN": "ZH-S",
                    "ZH_CN":"ZH-S",
                    "ZH-S": "ZH-S",
                    "FR" : "FR",
                    "ES" : "ES",
                    "PT" : "PT"
                };
                return qualtricsLangList[lang] || "EN";
            },

            openQualtricsIntercept : function (oPreviewModel) {
                this._oCustomerModel = SharedModels.getCustomerModel ();
                let pointer = oPreviewModel?.pointer;
                //    this.getLanguage ().then (preferredLanguage => {
                this.session_id = getApplicationInstanceId ("getSupport",true);
                this.page_id = getBrowserTabId ();
                    var mParams = {
                        CrmCustomerID: this._oCustomerModel.getProperty ("/crmcustomernumber"),
                        CaseId: + pointer.slice (10, 20) + "/" + pointer.slice (- 4),
                        Pointer: pointer,
                        Language: this.processLanguageCode(),
                        source: "SIS",
                        CaseSource: oPreviewModel.source,
                        Subject: oPreviewModel.subject,
                        Component: oPreviewModel.componentTxt,
                        CasePriority: oPreviewModel.priorityTxt,
                        Status: oPreviewModel.statusId,
                        OpenedDate: oPreviewModel.createdAt,
                        Country: this._oCustomerModel.getProperty ("/country"),
                        CustomerEmail: this._oCustomerModel.getProperty ("/email"),
                        CustomerPhoneNumber: this._oCustomerModel.getProperty ("/phone"),
                        CompanyName: this._oCustomerModel.getProperty ("/companyname"),
                        UserName: oPreviewModel.reporterId,
                        APP_INSTANCE_ID: this.session_id,
                        BROWSER_TAB_ID: this.page_id
                    };
                        //if window.QLT_MMI2S_PARAM clear it
                    if (window.QLT_MMI2S_PARAM) {
                        delete window.QLT_MMI2S_PARAM;
                    }
                    //if window.QLT_MMI1S_PARAM clear it
                    if (window.QLT_MMI1S_PARAM) {
                        delete window.QLT_MMI1S_PARAM;
                    }

                    window.QLT_LAUNCHPAD_PARAM = mParams;

                    if (this.hasInterceptLoaded) {
                        window.QSI.API.unload ();
                        //QSI.isDebug = true;
                        window.QSI.API.load ().done (window.QSI.API.run ());
                    }
            },

            openProcessorSurvey : function (oPreviewModel) {
                var info = {
                    Pointer: oPreviewModel.pointer,
                    Subject: oPreviewModel.subject,
                    Info: "Sap For Me",
                    Source: "Sap For Me",
                    CaseID: + oPreviewModel.pointer.slice (10, 20) + "/" + oPreviewModel.pointer.slice (- 4),
                };


                window.QLT_SN_CASE_PARAM = info;


                if (this.hasInterceptLoaded) {
                    window.QSI.API.unload ();
                    window.QSI.API.load ().done (window.QSI.API.run ());
                }
            },

            onOpenCaseByIdlink: function (pointer) {
                let sPointer;
                if (pointer) {
                    sPointer = pointer;
                } else {
                    sPointer = this._oPopover._oContextModel.getData().pointer;
                }
                return "/case/"+sPointer+"/overview";
            },

            onOpenCase: function (oEvent) {
                var oPreviewModelData;

                if (oEvent.getSource().getBindingContext('$this.odata')) {
                    oPreviewModelData = oEvent.getSource().getBindingContext('$this.odata').getObject()
                } else {
                    oPreviewModelData = oEvent.getSource().getModel("$this.preview").getData();
                }

                var sPointer = oPreviewModelData.pointer;
                sap.m.URLHelper.redirect("/case/"+sPointer+"/overview",true);
                this._oPopover?.close();
            },

            onCaseListSourceSelectionChange: function (oEvent) {
                var aFilters = this.getModel('$this.selectionAllOpen').getData();
                this._searchCases(aFilters);
            },

            /**
             * Triggered when clicking on information icon
             *
             * @param  {oEvent}
             * @return {void}
             */
            onCasePreview: function (oEvent) {
                var oButton = oEvent.getSource();
                this._oPreviewButton = oButton;
                var oPreviewModel = oButton.getBindingContext('$this.odata').getObject();
                if (oPreviewModel.serviceType !== "H") {
                    this._createPopOverPreview(this._oPreviewButton);
                } else {
                   this._createPopOverPreviewArchivedCase(this._oPreviewButton);
                }
            },

            _updateUserModel: function _updateUserModel() {
                jQuery.ajax("/backend/raw/core/User", {
                    method: "PUT",
                    contentType: "application/json",
                    data: JSON.stringify(this._oUserModel)
                }).fail(function () {
                    Log.info("Could not update user model.");
                });
            },
            /**
             * Handles favorite button press in header, checks whether to favourite or unfavourite incident,
             * updates backend service and frontend model
             *
             * Test Created
             *
             * @param {object} oEvent
             * @returns {void}
             */
            onFavoritePressed: function (oEvent) {
                var oSource = oEvent.getSource();
                var oBindingContext = oSource.getBindingContext("$this.odata");
                var sPath = oSource.getBindingContext("$this.odata").getPath();
                var pointer = oSource.getBindingContext("$this.odata").getObject().pointer;
                var isFavorite = oSource.getBindingContext("$this.odata").getObject().isFavorite;

                var sEntNr = sPath.substr(10);
                try {
                    iEntNr = Number(sEntNr);
                } catch (e) {
                    iEntNr = -1;
                }
                oBindingContext.getModel().oData.CaseList[iEntNr].isFavorite = !isFavorite;
                oBindingContext.getModel().refresh(true);

                $.ajax(`/backend/odata/support/CaseDetails('${pointer}')?pointer=${pointer}`, {
                    method: "PATCH",
                    contentType: "application/json",
                    data: JSON.stringify({
                        isFavorite: !isFavorite
                    })
                }).done(() => {
                    // no action taken
                }).fail(() => {
                    oBindingContext.getModel().oData.CaseList[iEntNr].isFavorite = isFavorite;
                    oBindingContext.getModel().refresh(true);
                    MessageToast.show(`ERROR UPDATING FAVORITES`);
                });


            },

            onSortPress: function (sColumn) {
                // iconActions sort is not available
                const sColumnKey = sColumn.getBindingContext("caseColumns").getObject().key;
                if (!sColumnKey) {
                    return;
                }
                // specific para should be formatted again
                let sortParam = sColumnKey;
                if (sortParam == "autoConfirmDateTxt") {
                    sortParam = "autoConfirmDate"
                }
                if (sortParam == "priorityTxt") {
                    sortParam = "priorityId"
                }

                const itemsBinding = this._caseListTable.getBinding("items");
                const columnIcon = sColumn.getHeader().getItems()[1];
                let bDescending = false;
                if (columnIcon.getVisible()) {
                    bDescending = !itemsBinding.aSorters[0].bDescending;
                };

                const sortArr = [];
                sortArr.push(new sap.ui.model.Sorter(sortParam, bDescending));
                itemsBinding.sort(sortArr);

                // change the icon to initial, only active the press column sort
                const columns = this._caseListTable.getColumns();
                columns.forEach(e => {
                    const columnIcon = e.getHeader().getItems()[1];
                    columnIcon.setVisible(false);
                    columnIcon.removeStyleClass("columnTableIconRotate");
                });

                columnIcon.setVisible(true);
                if (!bDescending) {
                    columnIcon.removeStyleClass("columnTableIconRotate");
                } else {
                    columnIcon.addStyleClass("columnTableIconRotate");
                }
            },

            _resetParamSorting : function () {
                const aColumns = this._caseListTable.getColumns();
                aColumns.forEach(e => {
                    const columnIcon = e.getHeader().getItems()[1];
                    columnIcon.setVisible(false);
                    columnIcon.removeStyleClass("columnTableIconRotate");
                });
            },

            _formatInstallationLink: function(sInstallationId){
                return `/installation/${sInstallationId}`;
            },

            _formatSystemLink: function(sSystemNumber){
                return `/systemdata/view/${sSystemNumber}`;
            },

            _formatSystemLinkText: function(sSystemNumber){
                return sSystemNumber.substring(9);
            },

            _formatreporterIdLink:function(sReporterId){
                return `/user/${sReporterId}`;
            },

            _formatCreatorTxt: function(createdBy = ""){
                if (!createdBy.match(/^S/)) {
                    return "SAP"
                }
                const reporters = this._filterBar.getModel("$this.fb").getProperty("/reporters");
                const reporterTxt = reporters.find(v => v.reporterId === createdBy)?.reporterTxt;

                return reporterTxt ? reporterTxt : '';
            },

            _formatCreatorLinkVisible: function(createdBy = "") {
                return !!createdBy.match(/^S/);
            },

            onNavToAutoConfirm: function () {
                this._iconTabBar.setSelectedKey(CaseListTabKey.AUTO_CONFIRM);
                this.onTabFilterSelect({getParameter: function() {return CaseListTabKey.AUTO_CONFIRM}});
            },

            fetchCaseListCheckConfirmDate: function () {
                jQuery.ajax("/backend/odata/support/CaseList?$filter=(statusId eq '3' or statusId eq '5' or statusId eq 'N') and (lastUpdate eq 'ALL')&$skip=0&$top=10000&$format=json", {
                    method: "GET",
                    contentType: "application/json",
                    success: (result) => {
                        result?.value?.forEach(item => {
                            if (Formatter.checkAutoConfirmDate(item?.autoConfirmDate)) {
                                this.getModel('$this.selectionAutoConfirm').setProperty('/messageStripVisible', true);
                                this.getModel('$this.selectionAutoConfirm').setProperty('/autoConfirmTabVisible', true);
                            }
                        });
                    }
                });
            }

        });
    },
);
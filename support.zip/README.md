# SAP For Me

    Maintenance & Support Component

## Content

1. [Branch Structure](#-branch-structure)
2. [Commit Guidelines](#-commit-guidelines)

## Branch Structure
We are dealing with 3 types of branches:
- `master` it contains the code which actually is deployed on Stage and Production servers
- `develop` it contains the latest code (trunk) that will be deployed on Dev and Test servers
- `SAP4METRANSFORMERS-XYZ` feature branch which contains the implementation for a particular feature. The name of the branch is the same with the Jira feature number.

## Commit Guidelines
	- Please make your commit message concise.
	- Please use one of the following prefixes:
	    feat: a new feature (e.g. feat: add a new card which display the attachments for a case)
        fix: a bug fix (e.g. fix: the non-purchased products vertical does not retrieve duplicates)
        test: adding missing unit tests
        bump: upgrade the core libraries or component version
        perf: a code change that improves performance (e.g. perf: add cache mechanism for case permission vertical)
        refactor: a code change that neither fixes a bug nor adds a feature
        docs: documentation only changes
        style: changes that do not affect the meaning of the code (white-space, formatting, missing semi-colons, etc)
        chore: changes to the build process or auxiliary tools and libraries such as documentation generation
    - Please use the following rules for the subject message:
        Use the imperative, present tense: “change” not “changed” nor “changes”
        Don’t capitalize first letter
        No dot (.) at the end
    - Please use the following rules for the body message:
        Just as in the subject, use the imperative, present tense: “change” not “changed” nor “changes”
    - Please make sure you add unit tests for your code (Frontend and Backend as well)
    - Please make sure that your PR (commit) did not broke the Jenkins validation jobs. In case of a failed job the PR will not be approved
    - Please link your commit with the Jira ticket since we don't have yet an automatic mechanism (plugin) to do this

/* eslint-env node */
 const puppeteer = require("puppeteer");
 process.env.CHROMIUM_BIN = puppeteer.executablePath();

 var browser = "ChromiumHeadless",
     bSingleRun = true;
 function isDebug(argument) {
     "use strict";
     return argument === "--debug";
 }
 if (process.argv.some(isDebug)) {
     browser = "ChromeDebugging";
     bSingleRun = false;
 }

 module.exports = function(config) {
     "use strict";

     config.set({
         frameworks: ["ui5", "qunit", "sinon"],
         basePath: "./",
         ui5: {
             type: "application",
             paths: {
                 webapp: "webapp",
             },
             mode: "script",
             config: {
                 bindingSyntax: "complex",
                 compatVersion: "edge",
                 async: true,
                 resourceroots: {
                     "sap.me.apps.supportsurveyapp": "./base/webapp"
                 }
             },
             tests: [
                 "sap/me/apps/supportsurveyapp/test/controller/MainTest"
             ]
         },

         // enable / disable watching file and executing tests whenever any file changes
         autoWatch: false,

         // start these browsers
         browsers: [browser],
         browserConsoleLogOptions: {
             level: "info",
             format: "%b %T: %m",
             terminal: false
         },

         // you can define custom flags
         customLaunchers: {
             ChromiumHeadlessLargeDesktop: {
                 base: "ChromiumHeadless",
                 flags: ["--disable-web-security", "--disable-site-isolation-trials", "--window-size=1440,1080", "--no-sandbox"]
             },
             ChromeDebugging: {
                 base: "Chrome",
                 flags: [
                     "--remote-debugging-port=9333",
                     "--auto-open-devtools-for-tabs"
                 ]
             }
         },

         plugins: [
             require('karma-coverage'),
             require('karma-junit-reporter'),
             require('karma-spec-reporter'),
             require('karma-ui5'),
             require('karma-qunit'),
             require('karma-sinon'),
             require('karma-chrome-launcher')
         ],
         preprocessors: {
            "webapp/controller/**/*.js": ["coverage"]
        },
         coverageReporter: {
             includeAllSources: true,
             reporters: [
                 {
                     type: "cobertura",
                     dir: "./target/jscoverage",
                     subdir: "/./",
                     file: "supportsurveyapp-cobertura-coverage.xml"
                 },
                 {"type": "text"},
                 {"type": "html"}
             ]
         },
         junitReporter: {
             outputDir: "./target/surefire-reports",
             outputFile: "supportsurveyapp.unitTests.qunit.xml",
             suite: "",
             useBrowserName: false
         },
         // level of logging
         // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
         logLevel: config.LOG_INFO,

         reporters: ["spec", "coverage", "junit"],
         specReporter: {
             maxLogLines: 300,            // limit number of lines logged per test
             suppressFailed: false,      // do not print information about failed tests
             suppressPassed: false,      // do not print information about passed tests
             suppressSkipped: true,      // do not print information about skipped tests
             showSpecTiming: false       // print the time elapsed for each spec
         },
         singleRun: bSingleRun
     });
 };
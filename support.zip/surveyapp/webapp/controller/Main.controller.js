sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/me/shared/Models",
    "sap/me/support/utils/QualtricsService",
    "sap/me/support/utils/DetailPageCacheUtil",
    "sap/me/shared/util/getBrowserTabId",
    "sap/me/shared/util/getApplicationInstanceId",
    "sap/me/shared/util/getPreferredLanguage",
    "sap/m/FlexBox",
    "sap/m/IllustratedMessage",
    "sap/m/IllustratedMessageType",
    "sap/m/library"
], function(Controller, Fragment, SharedModels, QualtricsService, DetailPageCacheUtil, getBrowserTabId, getApplicationInstanceId, getPreferredLanguage, FlexBox, IllustratedMessage, IllustratedMessageType, sapLibrary) {
    "use strict";

    const MainController = Controller.extend("sap.me.apps.supportsurveyapp.controller.Main", {
        onInit: function() {
            this.mainPage = this.getView().byId("mainPage");
            this._i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            this.sharedModel = SharedModels;
            this._oCustomerModel = SharedModels.getCustomerModel();

            const searchParams = new URLSearchParams(window.location.search);
            this.pointer = searchParams.get("caseID");
            this.displayIllustration(this._i18n.getText("survey_loading_title"), this._i18n.getText("survey_loading_text"), "sapIllus-Survey");
            this.mainPage.getContent().setBusy(true);
            this.callSurvey();
        }

    });

    MainController.prototype.processLanguageCode = function() {
        let preferredLang = getPreferredLanguage();
        let lang = preferredLang ? preferredLang.toUpperCase() : sap.ui.core.Configuration.getLanguage().toUpperCase();
        let qualtricsLangList = {
            DE: "DE",
            JA: "JA",
            "ZH-CN": "ZH-S",
            ZH_CN:"ZH-S",
            "ZH-S": "ZH-S",
            FR : "FR",
            ES : "ES",
            PT : "PT"
        };
        return qualtricsLangList[lang] || "EN";
    };

    MainController.prototype.callSurvey = async function() {

               $.ajax("/backend/raw/support/CaseQualtricsAuthW7?pointer=" + this.pointer, {
                    method: "GET",
                    contentType: "application/json"
                }).done((result) => {
                    this._surveyUrl = result;

                    if (this._surveyUrl) {
                        DetailPageCacheUtil.getCaseDetailData(this.pointer).then((caseDetails) => {

                            QualtricsService.initQualtricsSurvey(this._surveyUrl, this).then(() => {
                                this.openQualtricsIntercept(caseDetails);
                            }).catch(() =>{
                                this.mainPage.destroyContent();
                                this.displayIllustration(this._i18n.getText("survey_not_available_title"), this._i18n.getText("survey_not_available_text"), "sapIllus-UnableToLoad");
                            });

                        });
                    } else{
                        this.mainPage.destroyContent();
                        this.displayIllustration(this._i18n.getText("survey_not_available_title"), this._i18n.getText("survey_no_authorization"), "sapIllus-UnableToLoad");
                    }
                });
    };

    MainController.prototype.openQualtricsIntercept = function(oDetails){

                this.session_id = getApplicationInstanceId("getSupport",true);
                this.page_id = getBrowserTabId();
                let mParams = {
                    CrmCustomerID: oDetails.customerNumber,
                    CaseId: +this.pointer.slice(10, 20) + "/" + this.pointer.slice(-4),
                    Pointer: this.pointer,
                    Language: this.processLanguageCode(),
                    source: "SIS",
                    CaseSource: "test",
                    Subject: oDetails.subject,
                    Component: oDetails.component,
                    CasePriority: oDetails.priority,
                    Status: oDetails.status,
                    OpenedDate: oDetails.createdAt,
                    Country: this._oCustomerModel.getProperty('/country'),
                    CustomerEmail: this._oCustomerModel.getProperty('/email'),
                    CustomerPhoneNumber: this._oCustomerModel.getProperty('/phone'),
                    CompanyName: this._oCustomerModel.getProperty('/companyname'),
                    UserName: this._oCustomerModel.getProperty('/userName'),
                    APP_INSTANCE_ID: this.session_id,
                    BROWSER_TAB_ID: this.page_id
                };
                    // if window.QLT_MMI2S_PARAM clear it
                if (window.QLT_MMI2S_PARAM) {
                    delete window.QLT_MMI2S_PARAM;
                }
                // if window.QLT_MMI1S_PARAM clear it
                if (window.QLT_MMI1S_PARAM) {
                    delete window.QLT_MMI1S_PARAM;
                }

                window.QLT_LAUNCHPAD_PARAM = mParams;

                if (this.hasInterceptLoaded) {
                    window.QSI.API.unload();
                    //QSI.isDebug = true;
                    window.QSI.API.load().done(window.QSI.API.run());
                    this.mainPage.getContent().setBusy(false);
                    this.mainPage.destroyContent();
                }


    };

    MainController.prototype.displayIllustration = function(sTitle, sText, sType){
        this.mainPage.setContent(new FlexBox({
            height: "100%",
            width: "100%",
            direction: sap.m.FlexDirection.Column,
            alignContent: sap.m.FlexAlignContent.Center,
            alignItems: sap.m.FlexAlignItems.Center,
            justifyContent: sap.m.FlexJustifyContent.Center,
            items: [this._getMessageViewer(sTitle, sText, sType)]
        }));
    };

    MainController.prototype._getMessageViewer = function(oTitle, oSubTitle, illustrationType) {
        let view = new IllustratedMessage({
            illustrationSize: sapLibrary.IllustratedMessageSize["Scene"],
            illustrationType: illustrationType,
            enableVerticalResponsiveness: false
        });
        view.setTitle(oTitle);
        view.setDescription(oSubTitle);
        return view;
    };

    return MainController;
});
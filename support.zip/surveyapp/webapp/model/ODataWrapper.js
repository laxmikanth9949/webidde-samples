sap.ui.define([
	"sap/ui/base/Object"
], function(BaseObject) {
	"use strict";

	var Wrapper = BaseObject.extend("sap.support.incident.pcc.model.ODataWrapper", {
		constructor: function(oDataModel) {
			if (oDataModel) {
				this._oModel = oDataModel;
			} else {
				throw new Error("oDataModel is required when instantiated");
			}
		}
	});

	function _createParameters(resolve, reject, mParameters) {
		var mParams = mParameters || {};
        mParams.success = function () {
            resolve.apply(undefined, arguments);
        };
        mParams.error = function () {
            reject.apply(undefined, arguments);
        };
		return mParams;
	}

	/**
     * Asynchronous read of the OData model
     * @param {string} sPath path to read
     * @param {object} [mParameters] additional parameters, see ODataModel.read
     * @returns {Promise} the promise
     */
    Wrapper.prototype.read = function (sPath, mParameters) {
        return new Promise(function(resolve, reject) {
            this._oModel.read(sPath, _createParameters(resolve, reject, mParameters));
        }.bind(this));
    };

    return Wrapper;
});
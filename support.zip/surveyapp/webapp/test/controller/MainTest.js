sap.ui.define([
    "../../controller/Main.controller",
], function(Maincontroller) {
    "use strict";
    QUnit.module("MainTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            this.mainController = new Maincontroller();
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test init MainController process", function(assert) {
        const stubCallSurvey = this.sandbox.stub(this.mainController, "callSurvey");
        const stubDisplayIllustration = this.sandbox.stub(this.mainController, "displayIllustration");
        this.mainController.getOwnerComponent = function() {
            return {
                getModel: function() {
                    return {
                        getResourceBundle: function() {
                            return {
                                getText: function() {
                                    return "survey_loading_title";
                                }
                            };
                        }
                    };
                }
            };
        };
        this.mainController.getView = function() {
            return {
                byId: function() {
                    return {
                        getContent: function() {
                            return {
                                setBusy: function() {}
                            };
                        }
                    };
                }
            };
        }
        this.mainController.onInit();

        assert.true(stubCallSurvey.calledOnce);
        assert.true(stubDisplayIllustration.calledOnce);
    });
});
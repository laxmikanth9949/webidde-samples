sap.ui.define([
    "./BaseControl",
    "../utilities/ExportTableUtil",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/LocaleData",
    "sap/ui/core/format/DateFormat",
    "sap/m/MessageToast",
    "../utilities/ApiCallCollection",
    "./TableSettingsDialog",
    "./CasePreviewDialog",
    "./CasePreviewArchivedDialog",
    "sap/base/security/sanitizeHTML"
], function(BaseControl, ExportTableUtil, Fragment, JSONModel, LocaleData, DateFormat, MessageToast, ApiCallCollection, TableSettingsDialog, CasePreviewDialog, CasePreviewArchivedDialog, sanitizeHTML) {
    const ContentTable = BaseControl.extend("sap.me.apps.supportnewcl.controller.ContentTable", {
        constructor: function(oCaseListController) {
            BaseControl.prototype.constructor.call(this, oCaseListController);
            this.getFragment().onColumnPress = (column) => {
                this.onColumnPress(column);
            };
            ApiCallCollection.getUserSettings().then(userSettings => {
                try {
                    const columnList = userSettings["NEWCASELISTSETTINGS.COLUMNSLIST"];
                    if (columnList && columnList.length > 0 && columnList[0] !== "") {
                        this.userColumnsSettings = columnList.map(column => JSON.parse(column));
                    }
                } catch (e) {
                    // do nothing
                }
                this.setDefaultModels();
            });
        }
    });

    ContentTable.prototype.fragmentConfig = {
        id: "ContentTableFrg",
        boxId: "ContentTableContent",
        name: "sap.me.apps.supportnewcl.views.layout.ContentTable"
    };

    ContentTable.prototype.setDefaultModels = function() {
        this.mainPage.setModel(this.contentTableData = new JSONModel(), "$this.contentTableData");
        this.mainPage.setModel(this.contentTableColumns = new JSONModel({
            columns: this.getTableColumns()
        }), "$this.contentTableColumns");
        this.mainPage.setModel(this.contentTableDisplay = new JSONModel({
            isOnlyFavorite: false,
            searchFieldValue: ""
        }), "$this.contentTableDisplay");
    };

    ContentTable.prototype.adjustTableSettingsByVm = function() {
        let sType;
        if (this.mainPage.getModel("$this.personalVariantModel").getProperty("/segmentButton/selectedKey") !== "personal") {
            sType = this.mainPage.getModel("$this.personalVariantModel").getProperty("/defaultVm/selectedKey");
        } else {
            sType = "personal";
        }
        let displayColumns = this.getTableColumns();
        let bFavoriteOnly = false;
        let sorters = [];
        let bSearchResultVmDisplay = false;
        // reset the group items (a workaround, it may failed when the ui5 team change this private method)
        this.tableSettingsDialog?.groupReset();
        switch (sType) {
            case "favoriteCase":
                bFavoriteOnly = true;
                break;
            case "aaepCase":
                // deep clone
                displayColumns = JSON.parse(JSON.stringify(this.contentTableColumns.getProperty("/columns")));
                displayColumns.forEach(column => {
                    if (["statusTxt","createdBy","createdAt","autoConfirmDateTxt"].includes(column.key)) {
                        column.visible = false;
                    } else {
                        column.visible = true;
                    }
                    return column;
                });
                break;
            case "autoConfirm":
                sorters = new sap.ui.model.Sorter("autoConfirmDate", false);
                break;
            case "searchResult":
                bSearchResultVmDisplay = true;
                break;
            case "personal":
                const svm = this.mainPageCtrl.personalizeControl.svm;
                // standard view, always using the default settings
                if (svm.getCurrentVariantKey() !== svm.getStandardVariantKey()) {
                    // set in the personal variant, HeaderFilterBar.js: variantApplyData
                    sorters = this.getFragment().getBinding("items").aSorters;
                }
                break;
            default:
                break;
        }
        // reset the 'search' tab view and the filter bars visibilities, only shows in the first time user open the app by searching
        this.mainPage.getModel("$this.personalVariantModel").setProperty("/defaultVm/items/6/visible", bSearchResultVmDisplay);
        // reset the table display model
        this.mainPage.setModel(this.contentTableDisplay = new JSONModel({
            isOnlyFavorite: bFavoriteOnly,
            searchFieldValue: ""
        }), "$this.contentTableDisplay");
        // reset the table columns model
        this.mainPage.setModel(this.contentTableColumns = new JSONModel({
            columns: displayColumns
        }), "$this.contentTableColumns");
        // reset the table items sorts and filter
        this.getFragment()?.getBinding("items")?.sort(sorters);
        this.getFragment()?.getBinding("items")?.filter([]);

    };

    /** ************************************************************************************** */
    /*                                        Formatter                                        */
    /** ************************************************************************************** */
    ContentTable.prototype.getI18nText = function(sText) {
        return sText ? this.i18n.getText(sText) : "";
    };

    ContentTable.prototype.formatCaseDiscussionText = function(sText,RespITSM) {
        if (!sText) {
            return "";
        }
        const escapeMap = {
            "&lt;": "<",
            "&gt;": ">",
            "&amp;": "&",
            "&nbsp;": " ",
            "&#43;": "+",
            "&#39;": "'",
            "&cent;": "¢",
            "&pound;": "£",
            "&yen;": "¥",
            "&copy;": "©",
            "&reg;": "®",
            "&deg;": "°",
            "&ndash;": "-",
            "&mdash;": "—",
            "&radic;": "√",
            "&quot;": "\""
        };
        [
            "[code]", "[/code]", // SAP4METRANSFORMERS-476 why originalText is surrounded with [code] ?
            "[Code]","[/Code]"
        ].forEach(s => {
            sText = sText.replaceAll(s, "");
        });
        let html = sText;
        if (RespITSM?.toUpperCase() === "BCP") {
            html = html.replace(/&\S+?;/g, function(str) {
                if (!escapeMap[str]) {
                    console.log(`Unsupported tag: ${str} Please add this tag to escapeMap`);
                }
                return escapeMap[str] || str;
            });
        }
        const sanitizeOption = {
            uriRewriter: function(url) {
                return url;
            }
        };
        return sanitizeHTML(`<div class="sapUiCasePreviewHTMLMemo">${html}</div>`, sanitizeOption);
    };

    ContentTable.prototype.formatPODate = function(sDateTime) {
        if (!sDateTime) {
            return "";
        }

        const dateTime = new Date(sDateTime);
        if (isNaN(dateTime.getTime())) {
            return "";
        }

        const year = dateTime.getFullYear();
        const month = String(dateTime.getMonth() + 1).padStart(2, "0");
        const day = String(dateTime.getDate()).padStart(2, "0");
        const hours = String(dateTime.getHours()).padStart(2, "0");
        const minutes = String(dateTime.getMinutes()).padStart(2, "0");
        const seconds = String(dateTime.getSeconds()).padStart(2, "0");

        return `${year}/${month}/${day} at ${hours}:${minutes}:${seconds}`;
    };

    ContentTable.prototype.formatColumnsTitle = function(rText) {
        return rText ? this.i18n.getText(rText) : "";
    };

    ContentTable.prototype.formatPriorityStatus = function(sPriority) {
        if (sPriority === "1" || sPriority === "2") {
            return "Error";
        } // 1 Very High 2 High
        return "None"; // 3 Medium 4 Low
    };

    ContentTable.prototype.formatInstallationNameTxt = function(sInstallationTxt) {
        return sInstallationTxt.split("-").slice(1).join("-").trim();
    };

    ContentTable.prototype.formatInstallationIdTxt = function(sInstallationTxt) {
        return sInstallationTxt.split("-")[0].trim();
    };

    ContentTable.prototype.formatSystemLinkText = function(sSystemNumber) {
        return sSystemNumber.substring(9);
    };


    ContentTable.prototype.formatComponentDescription = function(sCompTxt, sCompKey) {
        return sCompTxt + "\n" + "(" + sCompKey + ")";
    };

    ContentTable.prototype.formatCreatorLinkVisible = function(createdBy = "") {
        return !!createdBy.match(/^S/);
    };

    ContentTable.prototype.formatCreatorTxt = function(createdBy = "") {
        if (!createdBy.match(/^S/)) {
            return "SAP";
        }
        const reporters = this.mainPage.getModel("$this.filterBarData").getProperty("/reporter")?.value ?? [];
        const reporterTxt = reporters.find(v => v.reporterId === createdBy)?.reporterTxt;
        return reporterTxt ? reporterTxt : "";
    };

    ContentTable.prototype.formatCustomerNameTxt = function(sCustomerNameTxt) {
        return sCustomerNameTxt.split("-").slice(1).join("-").trim();
    };

    ContentTable.prototype.datesAt = function(sDate, sTime) {
        const _oLocaleData = LocaleData.getInstance(sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale());
        const oLocalTimeFormat = DateFormat.getDateTimeInstance({pattern:  _oLocaleData.getTimePattern("medium")});
        const oDateFormatTime = DateFormat.getDateTimeInstance({pattern: "HH:mm:ss"});

        return sDate ? sDate + "\n" + (sTime ? oLocalTimeFormat.format(oDateFormatTime.parse(sTime)) : "") : String();
    },

    ContentTable.prototype.AaEPTimeFormat = function(dateString) {
        if (!dateString) {
            return "";
        }
        const sDate = new Date(dateString);
        const _oLocaleData = LocaleData.getInstance(sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale());
        const oLocalDateFormat = DateFormat.getDateTimeInstance({pattern:  _oLocaleData.getDatePattern("medium")});

        return oLocalDateFormat.format(sDate);
    },


    /** ************************************************************************************** */
    /*                                        Events                                           */
    /** ************************************************************************************** */

    ContentTable.prototype.onDisplayAutoConfirm = function() {
        this.mainPage.getModel("$this.personalVariantModel").setProperty("/defaultVm/selectedKey", "autoConfirm");
        // triggered from personal tab should change to default tab first
        if (this.mainPage.getModel("$this.personalVariantModel").getProperty("/segmentButton/selectedKey") === "personal") {
            this.mainPage.getModel("$this.personalVariantModel").setProperty("/segmentButton/selectedKey","default");
            this.mainPageCtrl.personalizeControl.onSwitchSegBtnChange();
        } else {
            // triggered from the default tab
            this.mainPageCtrl.personalizeControl.onDefaultVmSetAndSearch();
        }
    };

    ContentTable.prototype.onPressCasePreview = function(oEvent) {
        const oPreviewModel = oEvent.getSource().getBindingContext("$this.contentTableData").getObject();
        if (oPreviewModel.serviceType === "H") {
            if (!this.casePreviewArchivedDialog) {
                this.casePreviewArchivedDialog = new CasePreviewArchivedDialog(this);
            }
            this.casePreviewArchivedDialog.open(oEvent);
        } else {
            if (!this.casePreviewDialog) {
                this.casePreviewDialog = new CasePreviewDialog(this);
            }
            this.casePreviewDialog.open(oEvent);
        }
    };

    ContentTable.prototype.onPressFavoriteIcon = function(oEvent) {
        const icon = oEvent.getSource();
        const pointer = icon.data("pointer");
        const bIsFavorite = !(icon.getSrc() === "sap-icon://favorite");
        icon.setBusy(true);

        ApiCallCollection.updateCaseFavState(pointer, bIsFavorite).then(() => {
            // find the index of the case in the model with the pointer
            this.contentTableData.getData().items.find((item, index) => {
                if (item.pointer === pointer) {
                    this.contentTableData.setProperty("/items/" + index + "/isFavorite", bIsFavorite);
                    return true;
                }
            });
            icon.setBusy(false);
        }).catch((e) => {
            if (bIsFavorite) {
                MessageToast.show(this.i18n.getText("table_mark_as_favorite_failed"));
            } else {
                MessageToast.show(this.i18n.getText("table_unmark_as_favorite_failed"));
            }
            icon.setBusy(false);
        });
    };

    ContentTable.prototype.onPressListItem = function(sPointer) {
        sap.m.URLHelper.redirect("/case/" + sPointer + "/overview", true);
    };

    ContentTable.prototype.onFavoriteOnlyAndSearchChange = function() {
        const searchField = this.contentTableDisplay.getProperty("/searchFieldValue");
        // Assemble all column filters
        const filtersArr = ["sapNumber", "sapYear", "subject", "statusTxt", "priorityTxt","installationTxt","systemTxt",
            "componentTxt","componentKey","customerTxt","reporterTxt","reporterId", "createdBy", "creationDate",
            "creationTime","updateDate","updateTime","autoConfirmDateTxt","incidentNumber"];
        let aFilters = [];
        filtersArr.forEach(filterKey => {
            aFilters.push(new sap.ui.model.Filter(filterKey, sap.ui.model.FilterOperator.Contains, searchField));
        });

        const columnFilters = new sap.ui.model.Filter({
            filters: aFilters,
            bAnd: false
        });

        let queryFilterItem = [columnFilters];
        // Favorite filter
        if (this.contentTableDisplay.getProperty("/isOnlyFavorite")) {
            const favFilter = new sap.ui.model.Filter("isFavorite", sap.ui.model.FilterOperator.EQ, true);
            queryFilterItem.push(favFilter);
        }

        // Combine all filters
        const queryFilter = new sap.ui.model.Filter({
            filters: queryFilterItem,
            bAnd: true
        });

        this.getFragment().getBinding("items").filter(queryFilter);
    };

    ContentTable.prototype.openTableSettingsDialogOpen = function() {
        if (!this.tableSettingsDialog) {
            this.tableSettingsDialog = new TableSettingsDialog(this);
        }
        // only triggered when press the confirm button
        this.tableSettingsDialog.open().then((data) => {
            this.onFavoriteOnlyAndSearchChange();
            this.groupByTableSettingDialog(data);
            this.clearColumnSortIcon();
            // aaepCase View should not update the user column settings
            if ("aaepCase" !== this.mainPage.getModel("$this.personalVariantModel").getProperty("/defaultVm/selectedKey")) {
                this.updateColumnVisibilityInUserSettings();
            }
            this.mainPageCtrl.personalizeControl.setModifiedFlagForVariant();
        });
    };

    ContentTable.prototype.updateColumnVisibilityInUserSettings = function() {
        const currentColumnsSettings = this.contentTableColumns.getData().columns;
        this.userColumnsSettings = JSON.parse(JSON.stringify(currentColumnsSettings));// deep copy
        ApiCallCollection.updateUserSettingsColumListSelection(currentColumnsSettings.map(o => JSON.stringify(o)));
    };

    ContentTable.prototype.groupByTableSettingDialog = function(data) {
        if (data.groupItem) {
            const bDescending = data.groupDescending;
            const groupKey = data.groupItem.getKey();
            const groupFn = function(oContext) {
                const value = oContext.getProperty(groupKey);
                return {
                    key: value,
                    text: value
                };
            };
            this.getFragment().getBinding("items").sort(new sap.ui.model.Sorter(groupKey, bDescending, groupFn));
        } else {
            this.getFragment().getBinding("items").sort([]);
        }
    };

    ContentTable.prototype.clearColumnSortIcon = function() {
        const columns = this.getFragment().getColumns();
        columns.forEach(e => {
            const columnIcon = e.getHeader().getItems()[1];
            columnIcon.setVisible(false);
            columnIcon.removeStyleClass("columnTableIconRotate");
        });
    };

    ContentTable.prototype.onColumnPress = function(sColumn) {
        // trigger the sort
        this.onPressColumnSortBtn(sColumn);
    };

    ContentTable.prototype.onPressColumnSortBtn = function(sColumn) {
        // iconActions sort is not available
        const sColumnKey = sColumn.getBindingContext("$this.contentTableColumns").getObject().key;
        if (sColumnKey === "iconActions") {
            return;
        }
        // specific para should be adjusted
        let sortParam = sColumnKey;
        if (sortParam == "autoConfirmDateTxt") {
            sortParam = "autoConfirmDate";
        }

        if (sortParam == "priorityTxt") {
            sortParam = "priorityId";
        }

        const itemsBinding = this.getFragment().getBinding("items");
        const columnIcon = sColumn.getHeader().getItems()[1];
        let bDescending = false;
        if (columnIcon.getVisible()) {
            bDescending = !itemsBinding.aSorters[0].bDescending;
        }

        itemsBinding.sort(new sap.ui.model.Sorter(sortParam, bDescending));
        // set the dirty flag for personal variant
        this.mainPageCtrl.personalizeControl.setModifiedFlagForVariant();
        // change the icon to initial, only active the press column sort
        const columns = this.getFragment().getColumns();
        columns.forEach(e => {
            const columnIcon = e.getHeader().getItems()[1];
            columnIcon.setVisible(false);
            columnIcon.removeStyleClass("columnTableIconRotate");
        });

        columnIcon.setVisible(true);
        if (!bDescending) {
            columnIcon.removeStyleClass("columnTableIconRotate");
        } else {
            columnIcon.addStyleClass("columnTableIconRotate");
        }
    };

    ContentTable.prototype.onExport = function() {
        ExportTableUtil.onExport(this);
    };

    ContentTable.prototype.getTableColumns = function() {
        const defaultColumns = [
            {
                text: "",
                visible: true,
                key: "iconActions",
                width: "70px"
            },
            {
                text: "table_col_id",
                visible: true,
                key: "incidentNumber",
                width: "350px"
            },
            {
                text: "table_col_status",
                visible: true,
                key: "statusTxt"
            },
            {
                text: "table_col_session_state",
                visible: false,
                key: "aaEPSessStatus"
            },
            {
                text: "table_col_priorityTxt",
                visible: true,
                key: "priorityTxt"
            },
            {
                text: "table_col_installation",
                visible: true,
                key: "installationTxt"
            },
            {
                text: "table_col_system",
                visible: true,
                key: "systemTxt"
            },
            {
                text: "table_col_component",
                visible: true,
                key: "componentTxt"
            },
            {
                text: "table_col_reporter",
                visible: true,
                key: "reporterTxt"
            },
            {
                text: "table_col_creator",
                visible: true,
                key: "createdBy"
            },
            {
                text: "table_col_customer",
                visible: true,
                key: "customerTxt"
            },
            {
                text: "table_col_created_on",
                visible: true,
                key: "createdAt"
            },
            {
                text: "table_col_updated_on",
                visible: true,
                key: "updatedAt"
            },
            {
                text: "table_col_auto_confirm_date",
                visible: true,
                key: "autoConfirmDateTxt"
            },
            {
                text: "table_col_session_created",
                visible: false,
                key: "quesDateCreated"
            },
            {
                text: "table_col_session_completed",
                visible: false,
                key: "quesExpirationDate"
            }
        ];
        return this.userColumnsSettings || defaultColumns;
    };

    return ContentTable;

});

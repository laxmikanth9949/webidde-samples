sap.ui.define([
    "./BaseControl",
    "sap/m/PDFViewer"
], function(BaseControl, PDFViewer) {

    const CasePreviewArchivedDialog = BaseControl.extend("support.controller.CasePreviewArchivedDialog", {
        constructor: function(oContentTable) {
            BaseControl.prototype.constructor.call(this, oContentTable.mainPageCtrl);
            this.oContentTable = oContentTable;
            this.fragmentConfig = {
                id: "CasePreviewArchivedDialog",
                boxId: "CasePreviewArchivedDialogContent",
                name: "sap.me.apps.supportnewcl.views.fragments.CasePreviewArchivedDialog"
            };
        }
    });

    CasePreviewArchivedDialog.prototype.open = function(oEvent) {
        const sourceBtn = oEvent.getSource();
        this.caseDetailData = sourceBtn.getBindingContext("$this.contentTableData").getObject();
        if (!this._oDialog) {
            this._oDialog = this.getFragment();
            this.mainPage.addDependent(this._oDialog);
        }
        this._oDialog.openBy(sourceBtn);
    };

    CasePreviewArchivedDialog.prototype.onClosePreviewArchived = function() {
        this._oDialog?.close();
    };

    CasePreviewArchivedDialog.prototype.onOpenArchivedCase = function() {
        if (!this._pdfViewer) {
            this._pdfViewer = new PDFViewer();
            this._pdfViewer.setTitle(this.i18n.getText("preview_archived_case"));
            this.mainPage.addDependent(this._pdfViewer);
        }
        const sUrl = `https://userapps.support.sap.com/sap/support/incident/print/default.htm?pointer=${this.caseDetailData.pointer}`;
        this._pdfViewer.setSource(sUrl);
        this._pdfViewer.open();
    };

    return CasePreviewArchivedDialog;
});
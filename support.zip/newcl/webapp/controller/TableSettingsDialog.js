sap.ui.define([
    "./BaseControl",
], function(BaseControl) {

    const TableSettingsDialog = BaseControl.extend("support.controller.TableSettingsDialog", {
        /**
         * @param {*} oHeaderFilter
         * @param {Object} oFilterItem
         */
        constructor: function(oContentTable) {
            BaseControl.prototype.constructor.call(this, oContentTable.mainPageCtrl);
            this.oContentTable = oContentTable;
            this.fragmentConfig = {
                id: "TableSettingsDialog",
                boxId: "TableSettingsDialogContent",
                name: "sap.me.apps.supportnewcl.views.fragments.TableSettingsDialog"
            };
            this.dialogResolve = () => {};
        }
    });

    TableSettingsDialog.prototype.open = function() {
        if (!this._oDialog) {
            this._oDialog = this.getFragment();
            this.mainPage.addDependent(this._oDialog);
        }

        this.initDialogModel();
        this.applyVariantGroupItemSelections();
        this._oDialog.open();

        const waitForDialogClose = new Promise((resolve) => {
            this.dialogResolve = resolve;
        });
        return waitForDialogClose;
    };

    TableSettingsDialog.prototype.initDialogModel = function() {
        this._oDialog.setModel(this.oContentTable.contentTableColumns, "$this.tableSettingsDialog");
        this.setTheLastSelectionColumns();
    };

    TableSettingsDialog.prototype.applyVariantGroupItemSelections = function() {
        if (this.mainPage.getModel("$this.personalVariantModel").getProperty("/segmentButton/selectedKey") !== "personal") {
            return;
        }

        let variantGroupSorter;
        if (this.mainPageCtrl.personalizeControl.svm.getModified()) {
            variantGroupSorter = this.oContentTable.getFragment().getBinding("items").aSorters[0];
        } else {
            // group sort should be the first one in this array. Formatted by variantFetchData in HeaderFilterBar.js
            // only standard variant hasn't saved the variantSorters in the first time
            const variantGroupSorters = this.mainPageCtrl.headerFilterBar.variantSorters;
            variantGroupSorter = !!variantGroupSorters ? variantGroupSorters[0] : [];
        }

        if (!!variantGroupSorter?.vGroup) {
            this.getFragment().setGroupDescending(variantGroupSorter.bDescending);
            this.getFragment().getGroupItems().find(e => e.getProperty("key") === variantGroupSorter.sPath)?.setSelected(true);
        } else {
            this.groupReset();
        }
    };

    TableSettingsDialog.prototype.setTheLastSelectionColumns = function() {
        this.lastSelectedColumnsList = this.oContentTable.contentTableColumns.getData().columns.map((column) => {
            return {key:column.key, visible:column.visible};
        });
    };

    TableSettingsDialog.prototype.formatColumnsTitle = function(rText) {
        return this.i18n.getText(rText);
    };

    TableSettingsDialog.prototype.groupReset = function() {
        const nonSelectedItem = this.getFragment()._oGroupingNoneItem;
        nonSelectedItem.setSelected(true);
        this.getFragment().setGroupDescending(false);
        this.getFragment().getGroupItems().forEach(e => e.setSelected(false));
        this.getFragment().setAssociation("selectedGroupItem", nonSelectedItem, true);
    };

    TableSettingsDialog.prototype.onPressConfirm = function(oEvent) {
        this.setTheLastSelectionColumns();
        this.dialogResolve(oEvent.getParameters());
    };

    TableSettingsDialog.prototype.onPressCancel = function() {
        this.onPressReset();
    };

    TableSettingsDialog.prototype.onPressReset = function() {
        // reset columns visibility according to lastSelectedColumnsList
        this.oContentTable.contentTableColumns.getData().columns.forEach((column) => {
            this.lastSelectedColumnsList.find((lastColumn, index) => {
                if (lastColumn.key === column.key) {
                    this.oContentTable.contentTableColumns.setProperty(`/columns/${index}/visible`, lastColumn.visible);
                    return true;
                }
            });
        });
    };

    return TableSettingsDialog;

});

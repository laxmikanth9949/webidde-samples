sap.ui.define([
    "./BaseControl",
    "sap/ui/model/Filter",
    "sap/ui/model/json/JSONModel"
], function(BaseControl, Filter, JSONModel) {

    const FilterValueHelpDialog = BaseControl.extend("support.controller.FilterValueHelpDialog", {
        /**
         * @param {*} oHeaderFilter
         * @param {Object} oFilterItem
         */
        constructor: function(oHeaderFilter, oFilterItem) {
            BaseControl.prototype.constructor.call(this, oHeaderFilter.mainPageCtrl);
            this.oHeaderFilter = oHeaderFilter;
            this.oFilterItem = oFilterItem;
            this.fragmentConfig = {
                id: "FilterValueHelpDialog" + this.oFilterItem.titleKey,
                boxId: "FilterValueHelpDialogContent" + this.oFilterItem.titleKey,
                name: "sap.me.apps.supportnewcl.views.fragments.FilterValueHelpDialog"
            };
            this.dialogResolve = () => {};
        }
    });

    FilterValueHelpDialog.prototype.open = function() {
        if (!this._oDialog) {
            this._oDialog = this.getFragment();
            this.mainPage.addDependent(this._oDialog);
        }
        this.initDialogModel();
        this._oDialog.open();
        const waitForDialogClose = new Promise((resolve) => {
            this.dialogResolve = resolve;
            this.oHeaderFilter.filterBarDataModel.firePropertyChange();
        });
        return waitForDialogClose;
    };

    FilterValueHelpDialog.prototype.initDialogModel = function() {
        const titleKeyList = this.oHeaderFilter.filterBarDataModel.getProperty(`${this.oFilterItem.sPath}/selectedKey`).map(v => v[this.oFilterItem.titleKey]);
        const itemList = this.oHeaderFilter.filterBarDataModel.getProperty(`${this.oFilterItem.sPath}/value`).map(item => ({
            title: item[this.oFilterItem.titleKey],
            desc: item[this.oFilterItem.descKey],
            selected: titleKeyList.includes(item[this.oFilterItem.titleKey])
        })).sort((a) => a.selected ? -1 : 1);

        this._oDialog.setModel(this.filterHelperDialog = new JSONModel({
            list: itemList
        }), "$this.filterHelperDialog");
        this._oDialog.setTitle(this.oFilterItem.dialogTitle);
    };

    FilterValueHelpDialog.prototype.handleValueHelpSearch = function(oEvent) {
        const items = oEvent.getSource().getBinding("items");
        if (!items) {
            return;
        }

        const sValue = oEvent.getParameter("value");
        const aFilters = this.generateSearchDialogFilters(["title", "desc"], sValue);
        items.filter(aFilters);
    };

    FilterValueHelpDialog.prototype.handleValueHelpConfirm = function(oEvent) {
        const aContexts = oEvent.getParameter("selectedContexts");
        const selectedItems = aContexts.map(v => ({
            [this.oFilterItem.titleKey]: v?.getObject().title,
            [this.oFilterItem.descKey]: v?.getObject().desc,
        }));
        this.dialogResolve(selectedItems);
    };

    FilterValueHelpDialog.prototype.generateSearchDialogFilters = function(aSearchFields, sQueryStr) {
        const iLength = aSearchFields.length;
        const searchFilters = [];
        for (let i = 0; i < iLength; i++) {
            searchFilters.push(new Filter(aSearchFields[i], sap.ui.model.FilterOperator.Contains, sQueryStr));
        }
        const oFilter = new Filter({
            filters: searchFilters,
            bAnd: false
        });
        return searchFilters.length > 0 ? [oFilter] : [];
    };

    return FilterValueHelpDialog;

});

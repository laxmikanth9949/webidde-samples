sap.ui.define([
    "./BaseControl",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "../utilities/ApiCallCollection",
    "sap/base/util/deepClone",
    "./FilterValueHelpDialog"
], function(
    BaseControl,
    JSONModel,
    MessageToast,
    ApiCallCol,
    deepClone,
    FilterValueHelpDialog
) {

    const HeaderFilterBar = BaseControl.extend("sap.me.apps.supportnewcl.controller.HeaderFilterBar", {
        constructor: function(oCaseListController) {
            BaseControl.prototype.constructor.call(this, oCaseListController);
            this.router = oCaseListController.router;
            this.setDefaultModels();
            this.loadFilterBar().then(res => this.setFilterBarItems(res)).then(() => this.initLoad());
        }
    });

    HeaderFilterBar.prototype.fragmentConfig = {
        id: "HeaderFilterFrg",
        boxId: "HeaderFilterFrgContent",
        name: "sap.me.apps.supportnewcl.views.layout.HeaderFilterBar"
    };

    HeaderFilterBar.prototype.setDefaultModels = function() {
        this.mainPage.setModel(this.filterBarDisplayModel = new JSONModel({
            isShowAdaptFilter : false
        }), "$this.filterBarDisplay");
    };

    HeaderFilterBar.prototype.registerFilterBarVariantEvents = function() {
        this.getFragment().registerFetchData(this.variantFetchData.bind(this));
        this.getFragment().registerApplyData(this.variantApplyData.bind(this));
    };

    // when saving a personal variant, return JSON for the variant service
    HeaderFilterBar.prototype.variantFetchData = function() {
        // only used for update/create new user variant and standard generator
        // filter bar items save
        const filterData = this.filterBarDataModel.getData();
        const variantData = [];
        for (const key in filterData) {
            const selectedKeys = filterData[key].selectedKey;
            if ((Array.isArray(selectedKeys) && selectedKeys.length > 0) || (!Array.isArray(selectedKeys) && selectedKeys)) {
                variantData.push({
                    groupName : "caseListFilters",
                    fieldName : key,
                    fieldData : selectedKeys
                });
            }
        }
        // group and sort save
        const groupSortersData = this.mainPageCtrl.contentTable.getFragment().getBinding("items").aSorters;
        if (!!groupSortersData && groupSortersData.length > 0) {
            const sortData = [];
            groupSortersData.forEach(e => {
                sortData.push({
                    sPath: e.sPath,
                    bDescending: e.bDescending,
                    isGroup: !!e.vGroup
                })
            });
            variantData.push({
                groupName : "caseListSorters",
                fieldName : "sorters",
                fieldData : JSON.stringify(sortData)
            });
        }
        return variantData;
    };

    // when loading a personal variant, do the selection fulfilled
    HeaderFilterBar.prototype.variantApplyData = function(oVariantData) {
        this.clearAllFilters();
        oVariantData.forEach(e => {
            if (!e.fieldData) {
                return;
            }
            // load the filter bar items
            if (e.groupName === "caseListFilters") {
                switch (e.fieldName) {
                    case "system":
                    case "creator":
                    case "installation":
                    case "reporter":
                    case "customer":
                        if (typeof e.fieldData === "string") {
                            // old app variant data
                            const data = JSON.parse(e.fieldData);
                            const fieldKey = e.fieldName;
                            const valueKey = fieldKey === "system" ? "systemNumber" : `${fieldKey}Id`;
                            const valueTxt = `${fieldKey}Txt`;
                            const valueProperty = this.filterBarDataModel.getProperty(`/${fieldKey}/value`);
                            const formattedData = data.map(item => {
                                // creator and reporter share the same selection data key and value
                                const formattedKey = valueKey === "creatorId" ? "reporterId" : valueKey;
                                const formattedTxt = valueTxt === "creatorTxt" ? "reporterTxt" : valueTxt;
                                const selectedOne = valueProperty.find(v => v[formattedKey] === item);
                                return selectedOne ? { [valueKey]: item, [formattedTxt]: selectedOne[formattedTxt] } : null;
                            }).filter(v => v != null);
                            this.filterBarDataModel.setProperty("/" + e.fieldName + "/selectedKey", formattedData);
                        } else {
                            // new app variant data
                            this.filterBarDataModel.setProperty("/" + e.fieldName + "/selectedKey", e.fieldData);
                        }
                        break;
                    case "createdOn":
                    case "updatedOn":
                        if (!Array.isArray(e.fieldData)){
                            // old app variant data
                            const from = new Date(e.fieldData.from).getTime();
                            const to = new Date(e.fieldData.to).getTime();
                            this.filterBarDataModel.setProperty("/" + e.fieldName + "/selectedKey", [from, to]);
                        } else {
                            // new app variant data
                            this.filterBarDataModel.setProperty("/" + e.fieldName + "/selectedKey", e.fieldData);
                        }
                        break;
                    default:
                        this.filterBarDataModel.setProperty("/" + e.fieldName + "/selectedKey", e.fieldData);
                        break;
                }
            };
            // load the group and sort
            this.variantSorters = [];
            if (e.groupName === "caseListSorters") {
                this.variantSorters = JSON.parse(e.fieldData).sort((a,b) => b.isGroup - a.isGroup).map(item => {
                    return new sap.ui.model.Sorter(item.sPath, item.bDescending, item.isGroup ? (oContext) => {
                        const value = oContext.getProperty(item.sPath);
                        return {
                            key: value,
                            text: value
                        };
                    } : undefined);
                });
            }
            this.mainPageCtrl.contentTable.getFragment().getBinding("items").aSorters = this.variantSorters;
        });
    };

    HeaderFilterBar.prototype.loadFilterBar = function() {
        // strictly follow the order of 'filterBarItems'
        const filterBarItemsName = [
            "/status",
            "/priority",
            "/system",
            "/installation",
            "/reporter"
        ];

        return Promise.allSettled([
            ApiCallCol.getStatusList(),
            ApiCallCol.getPriorityList(),
            ApiCallCol.getSystemList(),
            ApiCallCol.getInstallationList(),
            ApiCallCol.getReporterList()
        ]).then(res => {
            // in case mess up the 'filterBarItems' order
            res.forEach((o,index) => {
                o.itemName = filterBarItemsName[index];
            });
            return res;
        });
    };

    HeaderFilterBar.prototype.initLoad = function() {
        // register the variant events only happened in initLoad
        this.registerFilterBarVariantEvents();

        // auto confirm data should be search in every cases only happened in initLoad
        this.setAutoConfirmCasesDisplay();

        // init router matched for wow search and tab search
        this.currentUrlPath = this.router?.sMatchedRouteName;
        this.router?.attachRouteMatched(this.routeMatched, this);

        const urlParam = this.getUrlParam();
        if (urlParam && Object.keys(urlParam).length > 0) {
            this.urlParamSearch(urlParam);
            return;
        }

        // default search should be 'openCases'
        this.mainPageCtrl.personalizeControl.onDefaultVmSetAndSearch();
    };

    HeaderFilterBar.prototype.routeMatched = function() {
        const isFromServiceSupport = this.router.sMatchedRouteName === "dashboardServicessupport" && this.router.mMatchedRouteArguments?.section === "cases";
        const isFromCL = this.router.sMatchedRouteName === "applicationCl";

        if (this.currentUrlPath !== this.router?.sMatchedRouteName){
            return;
        }

        if (isFromServiceSupport || isFromCL) {
            const urlParam = this.getUrlParam();
            if (urlParam && Object.keys(urlParam).length > 0) {
                this.urlParamSearch(urlParam);
            }
        }
    };

    HeaderFilterBar.prototype.destroy = function() {
        this.router?.detachRouteMatched(this.routeMatched, this);
    }

    HeaderFilterBar.prototype.getUrlParam = function() {
        // search team will decode the searchTerm in the router group
        const routerGroup = this.router?.mMatchedRouteArguments.group;
        if (routerGroup) {
            try {
                const searchTerm = JSON.parse(decodeURIComponent(routerGroup)).searchTerm;
                if (searchTerm) {
                    return {searchTerm : searchTerm};
                }
            } catch (e) {
                return {};
            }
        }
        // tab search would be like "?tab=DRAFT"
        const tab = new URLSearchParams(document.location.search).get("tab");
        if (tab) {
            return {tab : tab};
        }

        return {};
    };

    HeaderFilterBar.prototype.urlParamSearch = function(urlParam) {
        const searchFilter = [];
        // always switch back to 'default' view
        this.mainPage.getModel("$this.personalVariantModel").setProperty("/segmentButton/selectedKey", "default");

        if (urlParam.searchTerm) {
            searchFilter.push({key: "searchTerm", value: [urlParam.searchTerm]});
            searchFilter.push({key: "lastUpdate", value: ["ALL"]});
            this.mainPage.getModel("$this.personalVariantModel").setProperty("/defaultVm/selectedKey", "searchResult");
            this.mainPage.setBusy(true);
            ApiCallCol.onSearchCaseList(searchFilter).then(res => {
                this.loadContentTable(res);
                this.mainPage.setBusy(false);
            }).catch(error => {
                MessageToast.show(this.i18n.getText("msg_toast_search_error"));
                this.mainPage.setBusy(false);
            });
            return;
        }

        if (urlParam.tab) {
            const defaultVmFilterMap = this.mainPageCtrl.personalizeControl.defaultVmFilterMap();
            const matchingVm = Object.keys(defaultVmFilterMap).find(key => key.toLowerCase() === urlParam.tab.toLowerCase()) || "openCases";
            this.mainPage.getModel("$this.personalVariantModel").setProperty("/defaultVm/selectedKey", matchingVm);
            this.mainPageCtrl.personalizeControl.onDefaultVmSetAndSearch();
            return;
        }
    }

    HeaderFilterBar.prototype.setFilterBarItems = function(apiCallBacks) {
        // fixed selections, the 'selectedKey'.
        this.mainPage.setModel(this.filterBarDataModel = new JSONModel({
            status: {},
            priority: {},
            lastUpdate: {},
            system: {},
            createdOn: {},
            updatedOn: {},
            installation: {},
            reporter: {},
            creator: {},
            customer: {},
            isFavorite: {},
            aaEPDraftFlag: {},
            autoConfirmDate: {}
        }), "$this.filterBarData");

        apiCallBacks.forEach((e) => {
            const bIsApiSuccess = e.status === "fulfilled";
            this.filterBarDataModel.setProperty(e.itemName, {
                value : bIsApiSuccess ? e.value : [],
                enable : bIsApiSuccess,
                selectedKey : getDefaultSelectedKey(e.itemName)
            });
        });

        // filters not in apiCallBacks
        const noRequestFilters = ["/lastUpdate", "/createdOn", "/updatedOn", "/creator", "/customer", "/installation"];
        for (const pathName of noRequestFilters) {
            const selectionData = this.getNoApiCalledColumnValue(pathName);
            this.filterBarDataModel.setProperty(pathName, {
                value: selectionData,
                enable: selectionData.length > 0,
                selectedKey: getDefaultSelectedKey(pathName)
            });
        }

        // reconstruct the headerFilterBar model to monitor the value change for svm dirty flag set
        this.filterBarDataModel.attachPropertyChange(() => {
            // only changed in personal variant tab
            if (this.mainPage.getModel("$this.personalVariantModel").getProperty("/segmentButton/selectedKey") === "default") {
                return;
            }

            const svm = this.mainPageCtrl.personalizeControl.svm;
            // standard variant should not be monitored
            if (svm.getCurrentVariantKey() === svm.getStandardVariantKey()) {
                return;
            }

            svm.currentVariantSetModified(true);
            return;
        });


        function getDefaultSelectedKey(itemName) {
            switch (itemName) {
                case "/lastUpdate":
                    return "ALL";
                default: return [];
            }
        }

    };

    /**
     * @param item current filter item
     * @param arr all filter item
     */
    HeaderFilterBar.prototype.getNoApiCalledColumnValue = function(itemName) {
        switch (itemName) {
            case "/lastUpdate": {
                return [
                    {
                        lastUpdateId: "ALL",
                        lastUpdateText: this.i18n.getText("fb_lastUpdate_all")
                    },
                    {
                        lastUpdateId: "TODAY",
                        lastUpdateText: this.i18n.getText("fb_lastUpdate_today")
                    },
                    {
                        lastUpdateId: "THISWEEK",
                        lastUpdateText: this.i18n.getText("fb_lastUpdate_within7")
                    },
                    {
                        lastUpdateId: "NOTTHISWEEK",
                        lastUpdateText: this.i18n.getText("fb_lastUpdate_notwithin7")
                    },
                    {
                        lastUpdateId: "WITHINLAST4WEEKS",
                        lastUpdateText: this.i18n.getText("fb_lastUpdate_last4w")
                    },
                    {
                        lastUpdateId: "OLDERTHAN4WEEKS",
                        lastUpdateText: this.i18n.getText("fb_lastUpdate_older4w")
                    }
                ];
            }
            case "/creator": {
                // creator share selection data with reporter
                const reporterResult = this.filterBarDataModel.getProperty("/reporter");
                return deepClone(reporterResult.value);
            }
            case "/customer": {
                const installationResult = this.filterBarDataModel.getProperty("/installation");
                return this.getUniqueElementsByKey(installationResult.value, "customerId");
            }
            case "/installation": {
                const installationResult = this.filterBarDataModel.getProperty("/installation");
                return this.getUniqueElementsByKey(installationResult.value, "installationId");
            }
            default:
                return [];
        }
    };

    // only be used in filter bar items search, other case please write a new function
    HeaderFilterBar.prototype.onSearch = function() {
        this.mainPage.setBusy(true);
        const aFilters = this.getAllFilters();
        ApiCallCol.onSearchCaseList(aFilters).then(res => {
            this.loadContentTable(res);
            this.mainPage.setBusy(false);
        }).catch(error => {
            MessageToast.show(this.i18n.getText("msg_toast_search_error"));
            this.mainPage.setBusy(false);
        });
    };

    HeaderFilterBar.prototype.setAutoConfirmCasesDisplay = function() {
        // get the auto confirm filters
        const autoConfirmFilters = this.mainPageCtrl.personalizeControl.defaultVmFilterMap()["autoConfirm"];
        // formatted them
        const autoConfirmSearchFilters = Object.entries(autoConfirmFilters).map(([key, value]) => {
            const transformedValue = Array.isArray(value) ? value : [value];
            return {key, value: transformedValue};
        });

        ApiCallCol.onSearchCaseList(autoConfirmSearchFilters).then(res => {
            const bIsShowAutoConfirm = res.value.length > 0;
            if (bIsShowAutoConfirm) {
                this.mainPage.getModel("$this.personalVariantModel").setProperty("/defaultVm/items/5/visible", true);
                this.mainPageCtrl.contentTable.getFragment().getInfoToolbar().setVisible(true);
            }
        }).catch(error => {
            // do nothing
        });
    };

    // each filter returns should be like: { key:keyName，value:array[] }
    HeaderFilterBar.prototype.getAllFilters = function() {
        const data = this.filterBarDataModel.getData();
        const aFilters = [];
        for (const key in data) {
            switch (key) {
            // case "" :
                default: getDefaultFilters(key, data);
            }
        }

        function getDefaultFilters(key,data) {
            const sSelectedKey = data[key].selectedKey;
            let filterValues = [];

            if (Array.isArray(sSelectedKey) && sSelectedKey.length > 0) {
                filterValues = sSelectedKey;
            } else if (!Array.isArray(sSelectedKey) && sSelectedKey) {
                filterValues = [sSelectedKey];
            } else {
                return;
            }

            if (filterValues.length !== 0) {
                aFilters.push({
                    key: key,
                    value: filterValues
                });
            }
        }

        return aFilters;
    };

    HeaderFilterBar.prototype.getUniqueElementsByKey = function(array, objectKey) {
        const seenValues = new Set();
        const distinct = [];

        array.forEach(function(elem) {
            const objectValue = elem[objectKey];

            if (!seenValues.has(objectValue)) {
                distinct.push(elem);
                seenValues.add(objectValue);
            }
        });

        return distinct;
    };

    HeaderFilterBar.prototype.clearAllFilters = function() {
        const data = this.filterBarDataModel.getData();
        for (const key in data) {
            const filterItemSelectedKeys = data[key].selectedKey;
            const emptyValue = Array.isArray(filterItemSelectedKeys) ? [] : "";
            this.filterBarDataModel.setProperty("/" + key + "/selectedKey", emptyValue);
        }
        // special cases and judgments
    };

    HeaderFilterBar.prototype.loadContentTable = function(oCaseListData) {
        // clear the content table data and its settings
        this.mainPageCtrl.contentTable.adjustTableSettingsByVm();
        this.mainPageCtrl.contentTable.clearColumnSortIcon();
        this.mainPage.getModel("$this.contentTableData").setProperty("/items",oCaseListData.value);
    };

    HeaderFilterBar.prototype.onDateChange = function(oEvent) {
        const from = oEvent.getParameters().from;
        const to = oEvent.getParameters().to;
        const dateKey = oEvent.getSource().data("dateKey");

        if (oEvent.getParameters().valid) {
            this.filterBarDataModel.setProperty(`/${dateKey}/selectedKey`, [from?.getTime(), to?.getTime()]);
        }
        this.filterBarDataModel.firePropertyChange();
    };

    // covert timestamp to date object
    HeaderFilterBar.prototype.dateRangeFormat = function(sTime) {
        return sTime ? new Date(sTime) : null;
    };

    HeaderFilterBar.prototype.onTokenChange = function(oEvent) {
        const filterName = oEvent.getSource().data("filterName");
        const filterKey = oEvent.getSource().data("filterKey");
        const removedTokenKeys = oEvent.getParameters().removedTokens.map(i => i?.getKey());
        const selectedItems = this.filterBarDataModel.getProperty(`/${filterName}/selectedKey`).filter(v => !removedTokenKeys.includes(v[filterKey]));
        this.filterBarDataModel.setProperty(`/${filterName}/selectedKey`, selectedItems);
    };

    HeaderFilterBar.prototype.systemTextFormat = function(systemTokenText) {
        return systemTokenText?.split(" - ")[0];
    };

    HeaderFilterBar.prototype.openSelectDialog = function(oEvent) {
        const filterName = oEvent.getSource().data("filterName");

        switch (filterName) {
            case "customer":
                if (!this.customerValueHelpDialog) {
                    this.customerValueHelpDialog = new FilterValueHelpDialog(this, {
                        sPath: "/customer",
                        titleKey: "customerId",
                        descKey: "customerTxt",
                        dialogTitle: this.i18n.getText("dialog_customer_title")
                    });
                }
                this.customerValueHelpDialog.open().then(data => {
                    this.filterBarDataModel.setProperty("/customer/selectedKey", data);
                });
                break;
            case "creator":
                if (!this.creatorValueHelpDialog) {
                    this.creatorValueHelpDialog = new FilterValueHelpDialog(this, {
                        sPath: "/creator",
                        titleKey: "reporterId",
                        descKey: "reporterTxt",
                        dialogTitle: this.i18n.getText("dialog_creators_title")
                    });
                }
                this.creatorValueHelpDialog.open().then(data => {
                    this.filterBarDataModel.setProperty("/creator/selectedKey", data);
                });
                break;
            case "reporter":
                if (!this.reporterValueHelpDialog) {
                    this.reporterValueHelpDialog = new FilterValueHelpDialog(this, {
                        sPath: "/reporter",
                        titleKey: "reporterId",
                        descKey: "reporterTxt",
                        dialogTitle: this.i18n.getText("dialog_reporters_title")
                    });
                }
                this.reporterValueHelpDialog.open().then(data => {
                    this.filterBarDataModel.setProperty("/reporter/selectedKey", data);
                });
                break;
            case "installation":
                if (!this.installationValueHelpDialog) {
                    this.installationValueHelpDialog = new FilterValueHelpDialog(this, {
                        sPath: "/installation",
                        titleKey: "installationId",
                        descKey: "installationTxt",
                        dialogTitle: this.i18n.getText("dialog_installations_title")
                    });
                }
                this.installationValueHelpDialog.open().then(data => {
                    this.filterBarDataModel.setProperty("/installation/selectedKey", data);
                });
                break;
            case "system":
                if (!this.systemValueHelpDialog) {
                    this.systemValueHelpDialog = new FilterValueHelpDialog(this, {
                        sPath: "/system",
                        titleKey: "systemNumber",
                        descKey: "systemTxt",
                        dialogTitle: this.i18n.getText("dialog_systems_title")
                    });
                }
                this.systemValueHelpDialog.open().then(data => {
                    this.filterBarDataModel.setProperty("/system/selectedKey", data);
                });
                break;
            default: break;
        }
    };

    return HeaderFilterBar;

});

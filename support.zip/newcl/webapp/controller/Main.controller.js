sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/me/shared/Models",
    "sap/ui/core/routing/Router",
    "./PersonalizeControl",
    "./HeaderFilterBar",
    "./ContentTable"
], function(Controller, Fragment, SharedModels, Router, PersonalizeControl, HeaderFilterBar, ContentTable) {
    "use strict";

    const MainController = Controller.extend("sap.me.apps.supportnewcl.controller.Main", {
        onInit: function() {
            this.mainPage = this.getView().byId("mainPage");
            this.i18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            this.sharedModel = SharedModels;
            this.router = Router.getRouter("shellRouter");
            this.addMainPageAggregations();
            this.setSpecialConfigForDashboardApp();
        }
    });

    MainController.prototype.addMainPageAggregations = function() {
        // add header content part (filter bars)
        this.headerFilterBar = new HeaderFilterBar(this);
        this.mainPage.getHeader().addContent(this.headerFilterBar.getFragment());

        // add title head part (personalize/default variant)
        this.personalizeControl = new PersonalizeControl(this);
        this.mainPage.getTitle().setHeading(this.personalizeControl.getFragment());

        // add content table
        this.contentTable = new ContentTable(this);
        this.mainPage.setContent(this.contentTable.getFragment());
    };

    MainController.prototype.setSpecialConfigForDashboardApp = function() {
        // in case of servicessupport/cases page, hide breadcrumbs
        if (document.location.href.indexOf("servicessupport/cases") > -1) {
            this.mainPage.getTitle().getBreadcrumbs().setVisible(false);
            this.mainPage.getTitle()._getExpandButton().addStyleClass("expandBtnDisplay");
            this.mainPage.getHeader()._getCollapseButton().addStyleClass("expandBtnDisplay");
            this.mainPage.getContent().addStyleClass("contentTablePadding");
        }
    }

    return MainController;
});
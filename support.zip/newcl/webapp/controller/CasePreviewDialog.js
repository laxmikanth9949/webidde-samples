sap.ui.define([
    "./BaseControl",
    "../utilities/ApiCallCollection",
    "sap/m/FormattedText",
    "sap/me/support/utils/QualtricsService",
    "sap/ui/model/json/JSONModel",
    "sap/me/shared/util/getBrowserTabId",
    "sap/me/shared/util/getApplicationInstanceId",
    "sap/me/shared/util/getPreferredLanguage",
    "sap/m/MessageToast",
    "sap/ui/core/LocaleData",
    "sap/ui/core/format/DateFormat"
], function(BaseControl, ApiCallCollection, FormattedText, QualtricsService, JSONModel, getBrowserTabId, getApplicationInstanceId, getPreferredLanguage, MessageToast, LocaleData, DateFormat) {

    const CasePreviewDialog = BaseControl.extend("support.controller.CasePreviewDialog", {
        /**
         * @param {*} oHeaderFilter
         * @param {Object} oFilterItem
         */
        constructor: function(oContentTable) {
            BaseControl.prototype.constructor.call(this, oContentTable.mainPageCtrl);
            this.oContentTable = oContentTable;
            this.fragmentConfig = {
                id: "CasePreviewDialog",
                boxId: "CasePreviewDialogContent",
                name: "sap.me.apps.supportnewcl.views.fragments.CasePreviewDialog"
            };
        }
    });

    CasePreviewDialog.prototype.open = function(oEvent) {
        // note the current data entry
        const sourceBtn = oEvent.getSource();
        sourceBtn.setBusy(true);
        this.caseDetailData = sourceBtn.getBindingContext("$this.contentTableData").getObject();
        // init dialog
        if (!this._oDialog) {
            this._oDialog = this.getFragment();
            this.mainPage.addDependent(this._oDialog);
        }
        // clear data
        this._oDialog.setModel(this.previewModel = new JSONModel({
            isShowCloseButton: false,
            isShowDeleteButton: false,
            isCanRead: false
        }), "$this.preview");

        this.initDialogModel().then(() => {
            this._oDialog.openBy(sourceBtn);
            sourceBtn.setBusy(false);
        });
    };

    CasePreviewDialog.prototype.onOpenCaseDetail = function() {
        const pointer = this.previewModel.getProperty("/pointer");
        sap.m.URLHelper.redirect("/case/" + pointer + "/overview",true);
        this._oDialog?.close();
    };

    CasePreviewDialog.prototype.onCancelPreviewDialog = function() {
        this._oDialog?.close();
    };

    CasePreviewDialog.prototype.initDialogModel = async function() {
        const [discussionRes, validationRes, deleteDraftAuthRes] = await this.callApiForFetchData();
        this.handleCaseDiscussionRes(discussionRes);
        this.handleCaseCaseValidationRes(validationRes);
        if (deleteDraftAuthRes) {
            this.handDeleteDraftAuthRes(deleteDraftAuthRes);
        }

        this._oDialog.setModel(this.previewModel = new JSONModel(this.caseDetailData), "$this.preview");
    };

    CasePreviewDialog.prototype.callApiForFetchData = function() {
        const pointer = this.caseDetailData.pointer;
        const apiCalls = [
            ApiCallCollection.requestCaseDiscussion(pointer),
            ApiCallCollection.requestCaseValidation(pointer)
        ];
        // draft case should call api to know whether the user have the delete permission
        if (this.caseDetailData.statusId === "1") {
            apiCalls.push(ApiCallCollection.checkDeleteDraftAuth(pointer));
            this.caseDetailData.isShowCloseButton = false;
        } else {
            // default value for normal case
            this.caseDetailData.isShowDeleteButton = false;
            this.caseDetailData.isShowCloseButton = true;
        }
        return Promise.allSettled(apiCalls);
    };

    CasePreviewDialog.prototype.handleCaseDiscussionRes = function(o) {
        if (o.status === "fulfilled" && o.value?.length > 0) {
            const lastReply = o.value.reduce((a,b) => a.dateTime.localeCompare(b.dateTime) > 0 ? a : b);
            this.caseDetailData.lctype = lastReply.type;
            this.caseDetailData.lcdateTime = lastReply.dateTime;
            this.caseDetailData.lcoriginalText = "<div>" + lastReply.originalText + "</div>";
            this.caseDetailData.isSAPAgent = lastReply.isSAPAgent;
        } else {
            this.caseDetailData.lctype = "";
            this.caseDetailData.lcdateTime = "";
            this.caseDetailData.lcoriginalText = "";
            this.caseDetailData.isSAPAgent = false;
        }
    };

    CasePreviewDialog.prototype.handleCaseCaseValidationRes = function(o) {
        if (o.status === "fulfilled") {
            this.caseDetailData.RespITSM = o.value.RespITSM;
            this.caseDetailData.isCanWrite = o.value.CanWrite;
            this.caseDetailData.isCanRead = o.value.CanRead;
            this.caseDetailData.infoDoc = o.value.InfoDoc;
            if (this.caseDetailData.statusId === "8" || this.caseDetailData.statusId === "Z" || this.caseDetailData.source === "019") {
                this.caseDetailData.isCanClose = false;
            } else {
                this.caseDetailData.isCanClose = o.value.CanClose;
            }
        } else {
            this.caseDetailData.RespITSM = "";
            this.caseDetailData.infoDoc = false;
            this.caseDetailData.isCanWrite = false;
            this.caseDetailData.isCanRead = false;
            this.caseDetailData.isCanClose = false;
        }
        this.regenerateCanCloseValue();
    };
    // same as in CaseDetailHeaderController.js (isEnableCloseButton)
    CasePreviewDialog.prototype.regenerateCanCloseValue = function() {
        if (this.caseDetailData.infoDoc) {
            this.caseDetailData.isCanClose = false;
            return;
        }

        if (this.caseDetailData.RespITSM === "BCP" && this.caseDetailData.statusId === "1") {
            this.caseDetailData.isCanClose = true;
        } else {
            this.caseDetailData.isCanClose = ["3","5","N"].includes(this.caseDetailData.statusId) && this.caseDetailData.isCanClose;
        }
    };


    CasePreviewDialog.prototype.handDeleteDraftAuthRes = function(o) {
        this.caseDetailData.isShowDeleteButton = o.status === "fulfilled" && o.value?.AuthResult === "PASS";
    };

    CasePreviewDialog.prototype.buildMessageBox = function(sText, sTitle) {
        return new Promise((resolve) => {
            sap.m.MessageBox.confirm(new FormattedText({htmlText: sText}), {
                title: sTitle,
                styleClass: "",
                actions: ["YES", "NO"],
                emphasizedAction: "YES",
                initialFocus: null,
                textDirection: sap.ui.core.TextDirection.Inherit,
                onClose: function(sAction) {
                    resolve(sAction);
                }.bind(this)
            });
        });
    };

    CasePreviewDialog.prototype.removeCaseFromCaseList = function(pointer) {
        const result = this.oContentTable.contentTableData.getProperty("/items").filter(item => item.pointer !== pointer);
        this.oContentTable.contentTableData.setProperty("/items", result);
    };

    CasePreviewDialog.prototype.onCloseCase = function() {
        const previewModel = this.previewModel.getData();
        this.initFeedBackSurvey();
        return this.buildMessageBox(this.i18n.getText("caseCloseTipText"),this.i18n.getText("caseCloseTipTitle")).then(async action => {
            if (action === "YES") {
                const payload = {
                    action: "CONFIRM",
                    pointer: previewModel.pointer,
                    long_text: this.i18n.getText("caseHasBeenClosed"),
                    status: previewModel.statusId
                };
                this.oContentTable.getFragment().setBusy(true);
                await ApiCallCollection.requestCaseUpdate(payload).then(() => {
                    this.removeCaseFromCaseList(previewModel.pointer);
                    MessageToast.show(this.i18n.getText("caseCloseSuccess"));
                    this.openQualtricsIntercept();
                    this.oContentTable.getFragment().setBusy(false);
                }).catch(() => {
                    MessageToast.show(this.i18n.getText("caseCloseFailed"));
                    this.oContentTable.getFragment().setBusy(false);
                });
            }
        });
    };

    CasePreviewDialog.prototype.onDeleteCase = function() {
        const previewModel = this.previewModel.getData();
        return this.buildMessageBox(this.i18n.getText("CreateDeleteDraft_message_content"),this.i18n.getText("caseDeleteTipTitle")).then(async action => {
            if (action === "YES") {
                const payload = {
                    action: "COMPLETE",
                    pointer: previewModel.pointer,
                    draft_flag: "X"
                };
                this.oContentTable.getFragment().setBusy(true);
                await ApiCallCollection.requestCaseUpdate(payload).then(() => {
                    this.removeCaseFromCaseList(previewModel.pointer);
                    MessageToast.show(this.i18n.getText("caseDeleteSuccess"));
                    this.oContentTable.getFragment().setBusy(false);
                }).catch(() => {
                    MessageToast.show(this.i18n.getText("caseDeleteFailed"));
                    this.oContentTable.getFragment().setBusy(false);
                });
            }
        });
    };


    CasePreviewDialog.prototype.initFeedBackSurvey = function() {
        this.surveyUrl = "https://zncwifqo8baxlukrv-sapinsights.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_3RhlAhK4QHYAyJD";
        QualtricsService.initQualtricsSurvey(this.surveyUrl, this);
    };

    CasePreviewDialog.prototype.openQualtricsIntercept = function() {
        const previewModel = this.previewModel.getData();
        this._oCustomerModel = this.sharedModel.getCustomerModel();
        let mParams = {
            CrmCustomerID: this._oCustomerModel.getProperty("/crmcustomernumber"),
            CaseId: +previewModel.pointer.slice(10, 20) + "/" + previewModel.pointer.slice(-4),
            Pointer: previewModel.pointer,
            Language: this.processLanguageCode(),
            source: "SIS",
            CaseSource: previewModel.source,
            Subject: previewModel.subject,
            Component: previewModel.componentTxt,
            CasePriority: previewModel.priorityTxt,
            Status: previewModel.statusId,
            OpenedDate: previewModel.createdAt,
            Country: this._oCustomerModel.getProperty("/country"),
            CustomerEmail: this._oCustomerModel.getProperty("/email"),
            CustomerPhoneNumber: this._oCustomerModel.getProperty("/phone"),
            CompanyName: this._oCustomerModel.getProperty("/companyname"),
            UserName: previewModel.reporterId,
            APP_INSTANCE_ID: getApplicationInstanceId("getSupport",true),
            BROWSER_TAB_ID: getBrowserTabId()
        };
        // if window.QLT_MMI2S_PARAM clear it
        if (window.QLT_MMI2S_PARAM) {
            delete window.QLT_MMI2S_PARAM;
        }
        // if window.QLT_MMI1S_PARAM clear it
        if (window.QLT_MMI1S_PARAM) {
            delete window.QLT_MMI1S_PARAM;
        }
        window.QLT_LAUNCHPAD_PARAM = mParams;
        if (this.hasInterceptLoaded) {
            window.QSI.API.unload();
            // QSI.isDebug = true;
            window.QSI.API.load().done(window.QSI.API.run());
        }
    };

    CasePreviewDialog.prototype.processLanguageCode = function() {
        const preferredLang = getPreferredLanguage();
        const lang = preferredLang ? preferredLang.toUpperCase() : sap.ui.core.Configuration.getLanguage().toUpperCase();
        const qualtricsLangList = {
            DE: "DE",
            JA: "JA",
            "ZH-CN": "ZH-S",
            ZH_CN:"ZH-S",
            "ZH-S": "ZH-S",
            FR : "FR",
            ES : "ES",
            PT : "PT"
        };
        return qualtricsLangList[lang] || "EN";
    };

    CasePreviewDialog.prototype.formatPOInstallation = function(sInstTxt, sInstId) {
        if (!sInstTxt && !sInstId) {
            return "";
        }
        const arr = sInstTxt.split("-");
        const txt = arr.slice(1);
        return txt.join("-").trim() + " (" + sInstId + ")";
    };

    CasePreviewDialog.prototype.handleDatesAt = function(sDate, sTime) {
        const _oLocaleData = LocaleData.getInstance(sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale());
        const oLocalTimeFormat = DateFormat.getDateTimeInstance({pattern:  _oLocaleData.getTimePattern("medium")});
        const oDateFormatTime = DateFormat.getDateTimeInstance({pattern: "HH:mm:ss"});

        return sDate ? sDate + " at " + (sTime ? oLocalTimeFormat.format(oDateFormatTime.parse(sTime)) : "") : String();
    };

    return CasePreviewDialog;
});
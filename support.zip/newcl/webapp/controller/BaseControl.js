sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
], function(BaseObject, Fragment) {

    const BaseFrgController = BaseObject.extend("sap.me.apps.supportnewcl.controller.BaseControl", {
        constructor: function(oCaseListController) {
            this.mainPageCtrl = oCaseListController;
            this.mainPage = oCaseListController.mainPage;
            this.i18n = oCaseListController.i18n;
            this.sharedModel = oCaseListController.sharedModel;
        }
    });

    BaseFrgController.prototype.fragmentConfig = {};

    BaseFrgController.prototype.getFragment = function() {
        if (!this.oFragmentView) {
            this.oFragmentView = this.load();
        }
        return this.oFragmentView;
    };

    BaseFrgController.prototype.load = function() {
        const existFragment = Fragment.byId(this.fragmentConfig.id, this.fragmentConfig.boxId);

        if (existFragment) {
            existFragment.setVisible(false);
            existFragment.destroy();
            existFragment.controller.destroy();
        }

        const frag = new Fragment({
            type: "XML",
            id: this.fragmentConfig.id,
            fragmentName: this.fragmentConfig.name,
            oController: this
        });

        frag.controller = this;

        frag.addEventDelegate({
            onAfterRendering: this.onAfterRendering.bind(this)
        });

        return frag;
    };

    BaseFrgController.prototype.onAfterRendering = function() {};

    BaseFrgController.prototype.destroy = function() {};

    return BaseFrgController;

});

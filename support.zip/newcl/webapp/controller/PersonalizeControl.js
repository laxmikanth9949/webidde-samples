sap.ui.define([
    "./BaseControl",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    // should be deleted soon, all for sync app
    "../utilities/ApiCallCollection",
    "../utilities/VariantSync"
], function(BaseControl, Fragment, JSONModel, MessageToast, ApiCallCollection, VariantSync) {

    const PersonalizeControl = BaseControl.extend("sap.me.apps.supportnewcl.controller.PersonalizeControl", {
        constructor: function(oCaseListController) {
            BaseControl.prototype.constructor.call(this, oCaseListController);
            this._oUserModelData = this.sharedModel.getUserModel().getData();
            this.setDefaultModels();
        }
    });

    PersonalizeControl.prototype.fragmentConfig = {
        id: "PersonalizeControlFrg",
        boxId: "PersonalizeControlContent",
        name: "sap.me.apps.supportnewcl.views.layout.PersonalizeControl"
    };

    PersonalizeControl.prototype.defaultVmFilterMap = function() {
        return {
            openCases : {
                status : ["3","5","N"],
                lastUpdate : "ALL"
            },
            closedCases : {
                status : ["8","Z"],
                lastUpdate : "ALL"
            },
            draftCase : {
                status : ["1"],
                reporter: this.getReporterInfo(),
                lastUpdate: "ALL"
            },
            favoriteCase : {
                isFavorite : true,
                lastUpdate: "ALL"
            },
            aaepCase : {
                status : ["1"],
                aaEPDraftFlag : "X",
                lastUpdate : "ALL"
            },
            autoConfirm : {
                status : ["3","5","N"],
                lastUpdate : "ALL",
                // this value is not existed in headerFilterBar but used in api search
                autoConfirmDate: "larger than today"
            },
            // only used in standard view choosen in personal variant
            standardPersonal: {
                status : ["3","5","N"],
                lastUpdate : "ALL"
            }
        };
    };

    PersonalizeControl.prototype.setDefaultModels = function() {
        this.mainPage.setModel(this.personalVariantModel = new JSONModel({
            segmentButton : {
                selectedKey: "default",
                visible: true
            },
            defaultVm : {
                items : [
                    {key : "openCases", text : this.i18n.getText("hp_preDefinedVmItems_open_cases"), visible : true},
                    {key : "closedCases", text : this.i18n.getText("hp_preDefinedVmItems_closed_cases"), visible : true},
                    {key : "draftCase", text : this.i18n.getText("hp_preDefinedVmItems_draft_case"), visible : true},
                    {key : "favoriteCase", text : this.i18n.getText("hp_preDefinedVmItems_favorite_case"), visible : true},
                    {key : "aaepCase", text : this.i18n.getText("hp_preDefinedVmItems_aaep_case"), visible : true},
                    // the autoConfirm index is bound for the msg infoBar by using the index 5, please keep the order
                    {key : "autoConfirm", text : this.i18n.getText("hp_preDefinedVmItems_auto_confirm"), visible : false},
                    // the searchResult index is bound for the default Vm changes by using the index 6, please keep the order
                    {key : "searchResult", text : this.i18n.getText("hp_preDefinedVmItems_result"), visible : false}
                ],
                defaultKey : "openCases",
                selectedKey : "openCases"
            },
            isShowSyncBtn : false
        }), "$this.personalVariantModel");
    };

    PersonalizeControl.prototype.setUpPersonalizationVariant = function() {
        // in case, the standard variant is the first selection. Should adjust the filter bar item to what we like first
        const headerFilterBar = this.mainPageCtrl.headerFilterBar;
        const standardPersonal = this.defaultVmFilterMap()["standardPersonal"];
        headerFilterBar.clearAllFilters();
        for (const key in standardPersonal) {
            this.mainPage.getModel("$this.filterBarData").setProperty("/" + key + "/selectedKey",standardPersonal[key]);
        }

        // init the svm
        this.svm = sap.ui.getCore().byId("PersonalizeControlFrg--newCaseListSvm");
        const oPersonalInfo = new sap.ui.comp.smartvariants.PersonalizableInfo({
            type: "filterBar",
            keyName: "persistencyKey",
            control: headerFilterBar.getFragment()
        });
        this.svm.addPersonalizableControl(oPersonalInfo);
        this.svm.initialise(function() {}, headerFilterBar.getFragment());
    };

    PersonalizeControl.prototype.firstPersonalVariantLoad = function() {
        try {
            this.setUpPersonalizationVariant();
        } catch (error) {
            MessageToast.show(this.i18n.getText("msg_toast_personalize_error"));
            this.personalVariantModel.setProperty("/segmentButton/visible",false);
            this.personalVariantModel.setProperty("/segmentButton/selectedKey","default");
        }
    };

    PersonalizeControl.prototype.onDefaultVmSetAndSearch = function() {
        // clear the filter items first
        this.mainPageCtrl.headerFilterBar.clearAllFilters();

        const type = this.personalVariantModel.getProperty("/defaultVm/selectedKey");
        const defaultVmFilters = this.defaultVmFilterMap()[type];
        for (const item in defaultVmFilters) {
            this.mainPage.getModel("$this.filterBarData").setProperty("/" + item + "/selectedKey",defaultVmFilters[item]);
        }
        this.mainPageCtrl.headerFilterBar.onSearch();
    };

    PersonalizeControl.prototype.onSwitchSegBtnChange = function() {
        const selectedKey = this.personalVariantModel.getProperty("/segmentButton/selectedKey");
        const headerFrg = this.mainPageCtrl.headerFilterBar.getFragment();

        if (selectedKey === "default") {
            this.mainPage.getModel("$this.filterBarDisplay").setProperty("/isShowAdaptFilter", false);
            // if switch back to default, the search result should be reset to openCases
            if (this.personalVariantModel.getProperty("/defaultVm/selectedKey") === "searchResult") {
                this.personalVariantModel.setProperty("/defaultVm/selectedKey","openCases");
            }
            // all filters items should be set visible in case personal filter adapter hide them
            headerFrg.getFilterGroupItems().forEach(e => e.setVisibleInFilterBar(true));
            this.onDefaultVmSetAndSearch();
        }

        if (selectedKey === "personal") {
            this.isShowSyncBtn();
            this.mainPage.getModel("$this.filterBarDisplay").setProperty("/isShowAdaptFilter", true);
            if (!this.isVariantLoaded) {
                this.firstPersonalVariantLoad();
                this.isVariantLoaded = true;
            } else {
                const currentVariantObject = this.svm.getAllVariants().find(e => e.getVariantId() === this.svm.getCurrentVariantKey());
                let currentVariant = currentVariantObject?.getContent().newCaseListSvm;
                if (!currentVariant && currentVariantObject?.getStandardVariant()) {
                    // if the variant is standard, should set the default filter items
                    const standardFilters = this.defaultVmFilterMap()["standardPersonal"];
                    currentVariant = {filterBarVariant : []};
                    for (const key in standardFilters) {
                        currentVariant.filterBarVariant.push(
                            {groupName: 'caseListFilters', fieldName: key, fieldData: standardFilters[key]}
                        )
                    }
                }
                if (currentVariantObject?.getExecuteOnSelection()) {
                    currentVariant.executeOnSelection = true;
                }
                headerFrg.applyVariant(currentVariant);
            }
        }
    };


    PersonalizeControl.prototype.setModifiedFlagForVariant = function() {
        // in personal variant view (exclude standard), the dirty flag should be set
        if ("personal" === this.personalVariantModel.getProperty("/segmentButton/selectedKey") && this.svm.getCurrentVariantKey() !== this.svm.getStandardVariantKey()) {
            this.svm.currentVariantSetModified(true);
        }
    };

    PersonalizeControl.prototype.isShowSyncBtn = async function() {
        if (this.btnVisibleCaculatedValue !== undefined) {
            return;
        }

        // ***** this part of logic below should only be triggered once *****
        // whether user has old cl variant data
        const oldAppData = await VariantSync.fetchData();
        const isHaveOldAppData = Object.keys(oldAppData).length > 0;

        // whether user has done the sync before
        const bSyncedOldVaraintData = await ApiCallCollection.getUserSettings().then(userSettings => {
            try {
                return !!userSettings["NEWCASELISTSETTINGS.SYNCEDOLDAPPVARIANT"];
            } catch (e) {
                return false;
            }
        });

        this.btnVisibleCaculatedValue = isHaveOldAppData && !bSyncedOldVaraintData;

        this.personalVariantModel.setProperty("/isShowSyncBtn", this.btnVisibleCaculatedValue);
    };

    PersonalizeControl.prototype.getReporterInfo = function() {
        const reporterId = this._oUserModelData?.simulatedUser || this._oUserModelData?.userName;
        const reporterTxt = this.mainPage.getModel("$this.filterBarData").getProperty("/reporter").value.find(e => e.reporterId === reporterId)?.reporterTxt;
        return [{reporterId : reporterId, reporterTxt, reporterTxt}];
    };

    PersonalizeControl.prototype.onVariantSyncPress = function(oEvent) {
        VariantSync.sync().then(resp => {
            const isFinishSync = resp.find(apiResult => apiResult.status !== "fulfilled");
            if (!isFinishSync) {
                // update user settings
                ApiCallCollection.updateUserSettingsIsSyncedOldVariantData(true);
                const btn = oEvent.getSource();
                btn.setEnabled(false);
                btn.setText(this.i18n.getText("hp_sync_refresh"));
                MessageToast.show(this.i18n.getText("hp_sync_success"));
            } else {
                MessageToast.show(this.i18n.getText("hp_sync_error"));
            }
        });
    };

    return PersonalizeControl;

});

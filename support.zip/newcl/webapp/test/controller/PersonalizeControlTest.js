sap.ui.define([
    "./BaseTestUtility",
    "../../utilities/ApiCallCollection",
    "../../utilities/VariantSync",
    "sap/ui/model/json/JSONModel",
    "sap/ui/comp/filterbar/FilterItem",
], function(BaseTestUtility, ApiCallCollection, VariantSync, JSONModel, FilterItem) {
    "use strict";
    QUnit.module("PersonalizeControlTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test onAfterRendering process", function(assert) {
        const stubOnAfterRendering = this.sandbox.stub(this.personalizeControl, "onAfterRendering");

        this.personalizeControl.onAfterRendering();

        assert.true(stubOnAfterRendering.calledOnce);
    });

    QUnit.test("test onDefaultVmSetAndSearch process", function(assert) {
        const stubOnSearch = this.sandbox.stub(this.personalizeControl.mainPageCtrl.headerFilterBar, "onSearch");
        const stubClearAllFilters = this.sandbox.stub(this.personalizeControl.mainPageCtrl.headerFilterBar, "clearAllFilters");
        this.personalizeControl.personalVariantModel.setProperty("/defaultVm/selectedKey","closedCases");
        this.personalizeControl.onDefaultVmSetAndSearch();

        assert.true(stubOnSearch.calledOnce);
        assert.true(stubClearAllFilters.calledOnce);
        assert.deepEqual(this.personalizeControl.mainPage.getModel("$this.filterBarData").getData().status.selectedKey, ["8","Z"]);
        assert.deepEqual(this.personalizeControl.mainPage.getModel("$this.filterBarData").getData().lastUpdate.selectedKey,"ALL");
    });

    QUnit.test("test onSwitchSegBtnChange process. input = default", function(assert) {
        const filterItem = new FilterItem();
        filterItem.setVisibleInFilterBar(false);
        this.personalizeControl.personalVariantModel.setProperty("/segmentButton/selectedKey","default");
        this.personalizeControl.personalVariantModel.setProperty("/defaultVm/selectedKey","searchResult");
        this.personalizeControl.mainPageCtrl.headerFilterBar = {
            getFragment : function() {
                return {getFilterGroupItems:function() {
                    return [filterItem];
                }};
            }
        };
        const stubOnDefaultVmSetAndSearch = this.sandbox.stub(this.personalizeControl, "onDefaultVmSetAndSearch");

        this.personalizeControl.onSwitchSegBtnChange();

        assert.false(this.personalizeControl.mainPage.getModel("$this.filterBarDisplay").getProperty("/isShowAdaptFilter"));
        assert.true(stubOnDefaultVmSetAndSearch.calledOnce);
        assert.equal(this.personalizeControl.personalVariantModel.getProperty("/defaultVm/selectedKey"),"openCases");
        assert.true(this.personalizeControl.mainPageCtrl.headerFilterBar.getFragment().getFilterGroupItems()[0].getVisibleInFilterBar());
    });

    QUnit.test("test onSwitchSegBtnChange process. input = personal, variant returns, not first load", function(assert) {
        const stubApplyVariant = this.sandbox.stub();
        this.personalizeControl.isVariantLoaded = true;
        this.personalizeControl.personalVariantModel.setProperty("/segmentButton/selectedKey","personal");
        this.personalizeControl.mainPageCtrl.headerFilterBar = {
            getFragment : function() {
                return {
                    fetchVariant : function() {
                        return {};
                    },
                    applyVariant: stubApplyVariant
                };
            }
        };
        this.personalizeControl.svm = {
            getAllVariants : function() {
                return [];
            }
        }

        this.personalizeControl.onSwitchSegBtnChange();

        assert.true(this.personalizeControl.mainPage.getModel("$this.filterBarDisplay").getProperty("/isShowAdaptFilter"));
        assert.true(stubApplyVariant.calledOnce);
    });

    QUnit.test("test onSwitchSegBtnChange process. input = personal, is first load", function(assert) {
        const stubFirstPersonalVariantLoad = this.sandbox.stub(this.personalizeControl, "firstPersonalVariantLoad");
        this.personalizeControl.isVariantLoaded = false;
        this.personalizeControl.personalVariantModel.setProperty("/segmentButton/selectedKey","personal");
        this.personalizeControl.mainPageCtrl.headerFilterBar = {
            getFragment : function() {}
        };

        this.personalizeControl.onSwitchSegBtnChange();

        assert.true(this.personalizeControl.mainPage.getModel("$this.filterBarDisplay").getProperty("/isShowAdaptFilter"));
        assert.true(stubFirstPersonalVariantLoad.calledOnce);
        assert.true(this.personalizeControl.isVariantLoaded);
    });

    QUnit.test("test isShowSyncBtn(), already has a value", function(assert) {
        this.personalizeControl.btnVisibleCaculatedValue = true;

        this.personalizeControl.isShowSyncBtn();

        assert.equal(this.personalizeControl.btnVisibleCaculatedValue, true);
    });

    QUnit.test("test isShowSyncBtn(), first generate", function(assert) {
        const done = assert.async();
        this.personalizeControl.btnVisibleCaculatedValue = undefined;
        this.sandbox.stub(VariantSync, "fetchData").returns({});


        this.personalizeControl.isShowSyncBtn().then(() => {
            setTimeout(() => {
                assert.equal(this.personalizeControl.btnVisibleCaculatedValue, false);
                done();
            });
        });
    });

    QUnit.test("test onVariantSyncPress(), success", function(assert) {
        const done = assert.async();
        const stubSetEnable = this.sandbox.stub();
        const stubSetText = this.sandbox.stub();
        const stubVariantSync = this.sandbox.stub(VariantSync, "sync").returns(Promise.resolve([{
            status: "fulfilled"
        }]));
        const event = {
            getSource: function() {
                return {
                    setEnabled: stubSetEnable,
                    setText: stubSetText
                };
            }
        };
        const stubUpdateUserSettingsIsSyncedOldVariantData = this.sandbox.stub(ApiCallCollection, "updateUserSettingsIsSyncedOldVariantData");
        const stubMsgToast = this.sandbox.stub(sap.m.MessageToast, "show");

        this.personalizeControl.onVariantSyncPress(event);

        stubVariantSync.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.true(stubUpdateUserSettingsIsSyncedOldVariantData.calledWith(true));
                assert.true(stubMsgToast.calledOnce);
                assert.true(stubSetEnable.calledWith(false));
                assert.true(stubSetText.calledOnce);
                done();
            });
        });
    });

    QUnit.test("test onVariantSyncPress(), failed", function(assert) {
        const done = assert.async();
        const stubSetEnable = this.sandbox.stub();
        const stubSetText = this.sandbox.stub();
        const stubVariantSync = this.sandbox.stub(VariantSync, "sync").returns(Promise.resolve([{
            status: "failed"
        }]));
        const event = {
            getSource: function() {
                return {
                    setEnabled: stubSetEnable,
                    setText: stubSetText
                };
            }
        };
        const stubUpdateUserSettingsIsSyncedOldVariantData = this.sandbox.stub(ApiCallCollection, "updateUserSettingsIsSyncedOldVariantData");
        const stubMsgToast = this.sandbox.stub(sap.m.MessageToast, "show");

        this.personalizeControl.onVariantSyncPress(event);

        stubVariantSync.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.true(stubUpdateUserSettingsIsSyncedOldVariantData.notCalled);
                assert.true(stubMsgToast.calledOnce);
                assert.true(stubSetEnable.notCalled);
                assert.true(stubSetText.notCalled);
                done();
            });
        });
    });
});
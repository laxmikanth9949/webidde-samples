sap.ui.define([
    "../../utilities/ApiCallCollection",
    "../../controller/ContentTable",
    "../../controller/HeaderFilterBar",
    "../../controller/PersonalizeControl",
    "../../controller/Main.controller",
    "sap/ui/core/mvc/View",
    "sap/f/DynamicPage",
    "../../controller/CasePreviewArchivedDialog",
    "../../controller/CasePreviewDialog",
    "../../controller/TableSettingsDialog"
], function(ApiCallCollection, ContentTable, HeaderFilterBar, PersonalizeControl, Main, View, DynamicPage, CasePreviewArchivedDialog, CasePreviewDialog, TableSettingsDialog) {
    const BaseTestUtility = {};

    BaseTestUtility.constructorApp = async function(oTestController) {
        this.apiCallStub(oTestController);
        await this.constructorMainController(oTestController);
        await this.constructorHeaderFilterBar(oTestController);
        await this.constructorPersonalizeControl(oTestController);
        await this.constructorContentTable(oTestController);
    };

    BaseTestUtility.apiCallStub = function(oTestController) {
        oTestController.getReporterListStub = oTestController.sandbox.stub(ApiCallCollection, "getStatusList").returns(Promise.resolve([
            {
                statusId: "1",
                statusTxt: "Not Sent to SAP"
            },
            {
                statusId: "5",
                statusTxt: "Customer Action"
            },
            {
                statusId: "C",
                statusTxt: "Sent to SAP"
            },
            {
                statusId: "S",
                statusTxt: "In Processing by SAP"
            },
            {
                statusId: "R",
                statusTxt: "Pending Release"
            },
            {
                statusId: "N",
                statusTxt: "Partner-Customer Action"
            },
            {
                statusId: "8",
                statusTxt: "Confirmed"
            },
            {
                statusId: "3",
                statusTxt: "SAP Proposed Solution"
            },
            {
                statusId: "M",
                statusTxt: "Sent to SAP Partner"
            },
            {
                statusId: "Z",
                statusTxt: "Confirmed Automatically"
            }
        ]));
        oTestController.getPriorityListStub = oTestController.sandbox.stub(ApiCallCollection, "getPriorityList").returns(Promise.resolve([
            {
                priorityId: "1",
                priorityTxt: "Very High"
            },
            {
                priorityId: "2",
                priorityTxt: "High"
            },
            {
                priorityId: "3",
                priorityTxt: "Medium"
            },
            {
                priorityId: "4",
                priorityTxt: "Low"
            }
        ]));
        oTestController.sandbox.stub(ApiCallCollection, "getSystemList").returns(Promise.resolve([{
            systemId: "",
            systemNumber: "",
            systemTxt: " - (No system name)"
        },
        {
            systemId: "A11",
            systemNumber: "000000000311834471",
            systemTxt: "A11 - (No system name)"
        },
        {
            systemId: "A12",
            systemNumber: "000000000800834669",
            systemTxt: "A12 - (No system name)"
        }]));
        oTestController.getInstallationListStub = oTestController.sandbox.stub(ApiCallCollection, "getInstallationList").returns(Promise.resolve([{
            installationId: "0020601305",
            installationTxt: "Dummy Installation",
            inactive: "",
            customerId: "0001105772",
            customerTxt: "SAP Test Solution Manager"
        },
        {
            installationId: "0020601305",
            installationTxt: "Dummy Installation",
            inactive: "",
            customerId: "0001208936",
            customerTxt: "SAP Test Account - aPaul Pharma Test-Account AGS Data Quality"
        },
        {
            installationId: "0020601305",
            installationTxt: "Dummy Installation",
            inactive: "",
            customerId: "0001527516",
            customerTxt: "SAP Test - Prokesch Pharma Data Loa AGS Test Landscape Service/Support"
        }]));
        oTestController.getReporterListStub = oTestController.sandbox.stub(ApiCallCollection, "getReporterList").returns(Promise.resolve([{
            reporterId: "S0016556530",
            reporterTxt: "000 ---TECH-USER---"
        },
        {
            reporterId: "S0020207666",
            reporterTxt: "20659001-ABC ---TECH-USER---"
        },
        {
            reporterId: "S0016676326",
            reporterTxt: "Agent Yuan"
        }]));
        oTestController.getUserSettingsStub = oTestController.sandbox.stub(ApiCallCollection, "getUserSettings").returns(Promise.resolve({}));
        oTestController.onSearchCaseListStub = oTestController.sandbox.stub(ApiCallCollection, "onSearchCaseList").returns(Promise.resolve([]));
    };

    BaseTestUtility.constructorMainController = function(oTestController) {
        oTestController.mainController = new Main();
        oTestController.mainController.mainPage = new DynamicPage();
        oTestController.mainController.i18n = {getText:function(text) {
            return text;
        }};
        oTestController.mainController.sharedModel = {
            getUserModel: function() {
                return {
                    getData: function() {
                        return {};
                    }
                };
            }
        };
        oTestController.sandbox.stub(oTestController.mainController, "getView").returns(new View());
        oTestController.sandbox.stub(oTestController.mainController, "getOwnerComponent").returns({
            getModel: function() {
                return {
                    getResourceBundle: function() {
                        return {};
                    }
                };
            }
        });
    };

    BaseTestUtility.constructorHeaderFilterBar = function(oTestController) {
        oTestController.headerFilterBar = new HeaderFilterBar(oTestController.mainController);
        oTestController.mainController.headerFilterBar = oTestController.headerFilterBar;
    };

    BaseTestUtility.constructorPersonalizeControl = function(oTestController) {
        oTestController.personalizeControl = new PersonalizeControl(oTestController.mainController);
        oTestController.mainController.personalizeControl = oTestController.personalizeControl;
    };

    BaseTestUtility.constructorContentTable = function(oTestController) {
        oTestController.contentTable = new ContentTable(oTestController.mainController);
        oTestController.contentTable.casePreviewArchivedDialog = new CasePreviewArchivedDialog(oTestController.contentTable);
        oTestController.contentTable.casePreviewDialog = new CasePreviewDialog(oTestController.contentTable);
        oTestController.contentTable.tableSettingsDialog = new TableSettingsDialog(oTestController.contentTable);
        oTestController.contentTable.tableSettingsDialog.getFragment()._globalReset = function() {};
        oTestController.mainController.contentTable = oTestController.contentTable;
    };

    return BaseTestUtility;

});
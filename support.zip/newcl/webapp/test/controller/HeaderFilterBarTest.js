sap.ui.define([
    "./BaseTestUtility",
    "sap/ui/model/json/JSONModel"
], function(BaseTestUtility, JSONModel) {
    "use strict";

    QUnit.module("HeaderFilterBarTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test getUrlParam(), router", function(assert) {
        this.headerFilterBar.router = {
            mMatchedRouteArguments: {
                group: encodeURIComponent(JSON.stringify({searchTerm: "aaa"}))
            }
        };

        assert.equal(this.headerFilterBar.getUrlParam().searchTerm, "aaa");
    });

    QUnit.test("test initLoad(), with tab", function(assert) {
        this.sandbox.stub(this.headerFilterBar, "registerFilterBarVariantEvents");
        this.sandbox.stub(this.headerFilterBar, "setAutoConfirmCasesDisplay");
        this.sandbox.stub(this.headerFilterBar, "getUrlParam").returns({tab: "draftcase"});
        this.headerFilterBar.mainPageCtrl.personalizeControl = {
            onDefaultVmSetAndSearch : function() {},
            defaultVmFilterMap : function() {
                return {draftCase: {}};
            }
        };
        const stubOnDefaultVmSetAndSearch = this.sandbox.stub(this.headerFilterBar.mainPageCtrl.personalizeControl, "onDefaultVmSetAndSearch");

        this.headerFilterBar.initLoad();

        assert.ok(stubOnDefaultVmSetAndSearch.calledOnce);
        assert.equal(this.headerFilterBar.mainPage.getModel("$this.personalVariantModel").getData().defaultVm.selectedKey, "draftCase");
    });

    QUnit.test("test initLoad(), with searchTerm", function(assert) {
        this.sandbox.stub(this.headerFilterBar, "registerFilterBarVariantEvents");
        this.sandbox.stub(this.headerFilterBar, "setAutoConfirmCasesDisplay");
        this.sandbox.stub(this.headerFilterBar, "getUrlParam").returns({searchTerm: "aaa"});
        const done = assert.async();

        this.headerFilterBar.initLoad();

        this.onSearchCaseListStub.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.true(this.onSearchCaseListStub.calledWith([{
                    key: "searchTerm", value: ["aaa"]
                },{
                    key: "lastUpdate", value: ["ALL"]
                }]));
                done();
            });
        });
    });

    QUnit.test("test setAutoConfirmCasesDisplay(), no auto confirm returns, keep invisible", function(assert) {
        const done = assert.async();
        this.onSearchCaseListStub.returns(Promise.resolve({
            value: []
        }));

        this.headerFilterBar.setAutoConfirmCasesDisplay();

        this.onSearchCaseListStub.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.false(this.headerFilterBar.mainPage.getModel("$this.personalVariantModel").getProperty("/defaultVm/items/5/visible"));
                assert.false(this.headerFilterBar.mainPageCtrl.contentTable.getFragment().getInfoToolbar().getVisible());
                done();
            });
        });
    });

    QUnit.test("test setAutoConfirmCasesDisplay(), no auto confirm returns, keep invisible", function(assert) {
        const done = assert.async();
        this.onSearchCaseListStub.returns(Promise.resolve({
            value: [1,2,3]
        }));

        this.headerFilterBar.setAutoConfirmCasesDisplay();

        this.onSearchCaseListStub.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.ok(this.headerFilterBar.mainPage.getModel("$this.personalVariantModel").getProperty("/defaultVm/items/5/visible"));
                assert.ok(this.headerFilterBar.mainPageCtrl.contentTable.getFragment().getInfoToolbar().getVisible());
                done();
            });
        });
    });

    QUnit.test("test onDateChange()", function(assert) {
        const event = {
            getSource: function() {
                return {
                    data: function() {
                        return "aa";
                    }
                };
            },
            getParameters: function() {
                return {
                    valid : true,
                    from: {getTime : function() {
                        return "111";
                    }},
                    to: {getTime : function() {
                        return "222";
                    }}
                };
            }
        };
        this.headerFilterBar.filterBarDataModel = new JSONModel({
            "aa" : {
                selectedKey: "A"
            }
        });
        const stubFirePropertyChange = this.sandbox.stub(this.headerFilterBar.filterBarDataModel, "firePropertyChange");

        this.headerFilterBar.onDateChange(event);

        assert.deepEqual(this.headerFilterBar.filterBarDataModel.getProperty("/aa/selectedKey"), ["111","222"]);
        assert.ok(stubFirePropertyChange.calledOnce);
    });

    QUnit.test("test openSelectDialog()", function(assert) {
        let dialogName = "customer";
        const event = {
            getSource: function() {
                return {
                    data: function() {
                        return dialogName;
                    }
                };
            }
        };

        this.headerFilterBar.openSelectDialog(event);
        assert.ok(!!this.headerFilterBar.customerValueHelpDialog);

        dialogName = "installation";
        this.headerFilterBar.openSelectDialog(event);
        assert.ok(!!this.headerFilterBar.installationValueHelpDialog);

        dialogName = "creator";
        this.headerFilterBar.openSelectDialog(event);
        assert.ok(!!this.headerFilterBar.creatorValueHelpDialog);

        dialogName = "reporter";
        this.headerFilterBar.openSelectDialog(event);
        assert.ok(!!this.headerFilterBar.reporterValueHelpDialog);


    });

    QUnit.test("test variantFetchData(), with filter bar items", function(assert) {
        this.headerFilterBar.filterBarDataModel = new JSONModel({
            "A" : {
                selectedKey: [1,1,1]
            },
            "B" : {
                selectedKey: "B"
            }
        });
        this.headerFilterBar.mainPageCtrl.contentTable = {
            getFragment: function() {
                return {
                    getBinding: function() {
                        return {aSorters : []};
                    }
                };
            }
        };

        const result = this.headerFilterBar.variantFetchData();

        assert.deepEqual(result, [{
            groupName : "caseListFilters",
            fieldName : "A",
            fieldData : [1,1,1]
        },{
            groupName : "caseListFilters",
            fieldName : "B",
            fieldData : "B"
        }]);
    });

    QUnit.test("test variantFetchData(), with sorter filters", function(assert) {
        this.headerFilterBar.filterBarDataModel = new JSONModel();
        this.headerFilterBar.mainPageCtrl.contentTable = {
            getFragment: function() {
                return {
                    getBinding: function() {
                        return {aSorters : [
                            {sPath: "A", bDescending: true, vGroup: null},
                            {sPath: "B", bDescending: false, vGroup: "A"}
                        ]};
                    }
                };
            }
        };

        const result = this.headerFilterBar.variantFetchData();

        assert.deepEqual(result, [{
            groupName : "caseListSorters",
            fieldName : "sorters",
            fieldData : "[{\"sPath\":\"A\",\"bDescending\":true,\"isGroup\":false},{\"sPath\":\"B\",\"bDescending\":false,\"isGroup\":true}]"
        }]);
    });

    QUnit.test("test variantApplyData(), with all filter bar filter and sorter", function(assert) {
        const data = [{
            groupName : "caseListFilters",
            fieldName : "system",
            fieldData : ["system1"]
        },{
            groupName : "caseListFilters",
            fieldName : "creator",
            fieldData : ["creator1"]
        },{
            groupName : "caseListFilters",
            fieldName : "installation",
            fieldData : ["installation1"]
        },{
            groupName : "caseListFilters",
            fieldName : "reporter",
            fieldData : ["reporter1"]
        },{
            groupName : "caseListFilters",
            fieldName : "customer",
            fieldData : ["customer1"]
        },{
            groupName : "caseListFilters",
            fieldName : "createdOn",
            fieldData : []
        },{
            groupName : "caseListFilters",
            fieldName : "updatedOn",
            fieldData : []
        },{
            groupName : "caseListSorters",
            fieldName : "sorters",
            fieldData : "[{\"sPath\":\"A\",\"bDescending\":true,\"isGroup\":false},{\"sPath\":\"B\",\"bDescending\":false,\"isGroup\":true}]"
        }];
        this.headerFilterBar.filterBarDataModel = new JSONModel({
            "system" : {
                selectedKey: []
            },
            "creator" : {
                selectedKey: []
            },
            "installation" : {
                selectedKey: []
            },
            "reporter" : {
                selectedKey: []
            },
            "customer" : {
                selectedKey: []
            },
            "createdOn" : {
                selectedKey: []
            },
            "updatedOn" : {
                selectedKey: []
            }
        });
        this.headerFilterBar.mainPageCtrl.contentTable = {
            getFragment: function() {
                return {
                    getBinding: function() {
                        return {aSorters : []};
                    }
                };
            }
        };

        this.headerFilterBar.variantApplyData(data);

        assert.deepEqual(this.headerFilterBar.filterBarDataModel.getData(), {
            system: {
                selectedKey: ["system1"]
            },
            creator: {
                selectedKey: ["creator1"]
            },
            installation: {
                selectedKey: ["installation1"]
            },
            reporter: {
                selectedKey: ["reporter1"]
            },
            customer: {
                selectedKey: ["customer1"]
            },
            createdOn: {
                selectedKey: []
            },
            updatedOn: {
                selectedKey: []
            }
        });

        assert.deepEqual(this.headerFilterBar.variantSorters[0].sPath, "B");
        assert.deepEqual(this.headerFilterBar.variantSorters[0].bDescending, false);
        assert.ok(!!this.headerFilterBar.variantSorters[0].vGroup);
        assert.deepEqual(this.headerFilterBar.variantSorters[1].sPath, "A");
        assert.deepEqual(this.headerFilterBar.variantSorters[1].bDescending, true);
        assert.ok(!this.headerFilterBar.variantSorters[1].vGroup);
    });
});
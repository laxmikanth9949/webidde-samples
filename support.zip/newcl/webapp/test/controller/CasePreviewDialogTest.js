sap.ui.define([
    "./BaseTestUtility",
    "../../controller/CasePreviewDialog",
    "../../utilities/ApiCallCollection",
    "sap/ui/core/mvc/View",
    "sap/ui/model/json/JSONModel"
], function(BaseTestUtility, CasePreviewDialog, ApiCallCollection, View, JSONModel) {

    QUnit.module("CasePreviewDialogTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                this.casePreviewDialog = new CasePreviewDialog(this.contentTable);
                this.casePreviewDialog._oDialog = new View();
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });


    QUnit.test("test initDialogModel() process", function(assert) {
        const stubCallApiForFetchData = this.sandbox.stub(this.casePreviewDialog, "callApiForFetchData").returns(Promise.resolve([{},{},{}]));
        const stubHandleCaseDiscussionRes = this.sandbox.stub(this.casePreviewDialog, "handleCaseDiscussionRes");
        const stubHandleCaseValidationRes = this.sandbox.stub(this.casePreviewDialog, "handleCaseCaseValidationRes");
        const stubHandleDraftAuthRes = this.sandbox.stub(this.casePreviewDialog, "handDeleteDraftAuthRes");
        this.casePreviewDialog._oDialog.setBusy(true);
        const done = assert.async();

        this.casePreviewDialog.initDialogModel();

        stubCallApiForFetchData.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.ok(stubHandleCaseDiscussionRes.calledOnce);
                assert.ok(stubHandleCaseValidationRes.calledOnce);
                assert.ok(stubHandleDraftAuthRes.calledOnce);
                assert.ok(this.casePreviewDialog._oDialog.getModel("$this.preview"));
                done();
            });
        });
    });

    QUnit.test("test callApiForFetchData() process, draft case should returns 3api calls", function(assert) {
        this.sandbox.stub(ApiCallCollection, "requestCaseDiscussion");
        this.sandbox.stub(ApiCallCollection, "requestCaseValidation");
        this.sandbox.stub(ApiCallCollection, "checkDeleteDraftAuth");
        this.casePreviewDialog.caseDetailData = {
            pointer : "111",
            statusId : "1",
            isShowCloseButton : true
        };
        const stubPromiseCalls = this.sandbox.stub(Promise, "allSettled");

        this.casePreviewDialog.callApiForFetchData();

        assert.equal(stubPromiseCalls.getCall(0).firstArg.length, 3);
        assert.false(this.casePreviewDialog.caseDetailData.isShowCloseButton);
    });

    QUnit.test("test callApiForFetchData() process, normal case should returns 2api calls", function(assert) {
        this.sandbox.stub(ApiCallCollection, "requestCaseDiscussion");
        this.sandbox.stub(ApiCallCollection, "requestCaseValidation");
        this.casePreviewDialog.caseDetailData = {
            pointer : "111",
            statusId : "3",
            isShowDeleteButton : true,
            isShowCloseButton : false
        };
        const stubPromiseCalls = this.sandbox.stub(Promise, "allSettled");

        this.casePreviewDialog.callApiForFetchData();

        assert.equal(stubPromiseCalls.getCall(0).firstArg.length, 2);
        assert.false(this.casePreviewDialog.caseDetailData.isShowDeleteButton);
        assert.ok(this.casePreviewDialog.caseDetailData.isShowCloseButton);
    });

    QUnit.test("test handleCaseDiscussionRes() process, api return correct respond", function(assert) {
        const returns = {
            value : [
                {
                    dateTime: "2024-05-06T20:11:09.UTC",
                    type: "type1",
                    originalText: "lcoriginalText1",
                    isSAPAgent: true
                },
                {
                    dateTime: "2024-06-06T20:11:09.UTC",
                    type: "type2",
                    originalText: "lcoriginalText2",
                    isSAPAgent: false
                }
            ],
            status: "fulfilled"
        };
        this.casePreviewDialog.caseDetailData = {};

        this.casePreviewDialog.handleCaseDiscussionRes(returns);

        assert.equal(this.casePreviewDialog.caseDetailData.lctype, "type2");
        assert.equal(this.casePreviewDialog.caseDetailData.lcdateTime, "2024-06-06T20:11:09.UTC");
        assert.equal(this.casePreviewDialog.caseDetailData.lcoriginalText, "<div>lcoriginalText2</div>");
        assert.false(this.casePreviewDialog.caseDetailData.isSAPAgent);
    });

    QUnit.test("test handleCaseDiscussionRes() process, api return non, set default data", function(assert) {
        const returns = {
            status: "rejected"
        };
        this.casePreviewDialog.caseDetailData = {};

        this.casePreviewDialog.handleCaseDiscussionRes(returns);

        assert.equal(this.casePreviewDialog.caseDetailData.lctype, "");
        assert.equal(this.casePreviewDialog.caseDetailData.lcdateTime, "");
        assert.equal(this.casePreviewDialog.caseDetailData.lcoriginalText, "");
        assert.false(this.casePreviewDialog.caseDetailData.isSAPAgent);
    });

    QUnit.test("test handleCaseCaseValidationRes() process, api return correct respond, set data but statusId eq 8", function(assert) {
        const returns = {
            value : {
                CanRead: true,
                CanWrite: true,
                CanClose: true,
                RespITSM: "BCP"
            },
            status: "fulfilled"
        };
        this.casePreviewDialog.caseDetailData = {statusId: "8"};

        this.casePreviewDialog.handleCaseCaseValidationRes(returns);

        assert.true(this.casePreviewDialog.caseDetailData.isCanRead);
        assert.true(this.casePreviewDialog.caseDetailData.isCanWrite);
        assert.equal(this.casePreviewDialog.caseDetailData.RespITSM, "BCP");
    });

    QUnit.test("test handleCaseCaseValidationRes() process, api return correct respond, set data but statusId eq Z", function(assert) {
        const returns = {
            value : {
                CanRead: true,
                CanWrite: true,
                CanClose: true,
                RespITSM: "BCP"
            },
            status: "fulfilled"
        };
        this.casePreviewDialog.caseDetailData = {statusId: "Z"};

        this.casePreviewDialog.handleCaseCaseValidationRes(returns);

        assert.true(this.casePreviewDialog.caseDetailData.isCanRead);
        assert.true(this.casePreviewDialog.caseDetailData.isCanWrite);
        assert.equal(this.casePreviewDialog.caseDetailData.RespITSM, "BCP");
    });

    QUnit.test("test handleCaseCaseValidationRes() process, api return correct respond, set data but source eq 019", function(assert) {
        const returns = {
            value : {
                CanRead: true,
                CanWrite: true,
                CanClose: true,
                RespITSM: "BCP"
            },
            status: "fulfilled"
        };
        this.casePreviewDialog.caseDetailData = {source: "019"};

        this.casePreviewDialog.handleCaseCaseValidationRes(returns);

        assert.true(this.casePreviewDialog.caseDetailData.isCanRead);
        assert.true(this.casePreviewDialog.caseDetailData.isCanWrite);
        assert.equal(this.casePreviewDialog.caseDetailData.RespITSM, "BCP");
    });

    QUnit.test("test handleCaseCaseValidationRes() process, api return correct respond, set data", function(assert) {
        const returns = {
            value : {
                CanRead: true,
                CanWrite: true,
                CanClose: true,
                RespITSM: "BCP"
            },
            status: "fulfilled"
        };
        this.casePreviewDialog.caseDetailData = {};

        this.casePreviewDialog.handleCaseCaseValidationRes(returns);

        assert.true(this.casePreviewDialog.caseDetailData.isCanRead);
        assert.true(this.casePreviewDialog.caseDetailData.isCanWrite);
        assert.equal(this.casePreviewDialog.caseDetailData.RespITSM, "BCP");
    });

    QUnit.test("test handleCaseCaseValidationRes() process, api return non, set default data", function(assert) {
        const returns = {
            status: "rejected"
        };
        this.casePreviewDialog.caseDetailData = {};

        this.casePreviewDialog.handleCaseCaseValidationRes(returns);

        assert.false(this.casePreviewDialog.caseDetailData.isCanRead);
        assert.false(this.casePreviewDialog.caseDetailData.isCanWrite);
        assert.equal(this.casePreviewDialog.caseDetailData.RespITSM, "");
    });

    QUnit.test("test handDeleteDraftAuthRes() process, api return correct respond PASS, set data", function(assert) {
        const returns = {
            value : {
                AuthResult: "PASS"
            },
            status: "fulfilled"
        };
        this.casePreviewDialog.caseDetailData = {};

        this.casePreviewDialog.handDeleteDraftAuthRes(returns);

        assert.ok(this.casePreviewDialog.caseDetailData.isShowDeleteButton);
    });

    QUnit.test("test handDeleteDraftAuthRes() process, api return correct respond FAILED, set data", function(assert) {
        const returns = {
            value : {
                AuthResult: "FAILED"
            },
            status: "fulfilled"
        };
        this.casePreviewDialog.caseDetailData = {};

        this.casePreviewDialog.handDeleteDraftAuthRes(returns);

        assert.false(this.casePreviewDialog.caseDetailData.isShowDeleteButton);
    });

    QUnit.test("test handDeleteDraftAuthRes() process, api returns failed, set default data", function(assert) {
        const returns = {
            status: "rejected"
        };
        this.casePreviewDialog.caseDetailData = {};

        this.casePreviewDialog.handDeleteDraftAuthRes(returns);

        assert.false(this.casePreviewDialog.caseDetailData.isShowDeleteButton);
    });

    QUnit.test("test removeCaseFromCaseList() should remove case from case list", function(assert) {
        this.casePreviewDialog.oContentTable.contentTableData = new JSONModel({
            items : [{pointer: "002075129200002236722024", incidentNumber: "223672/2024"}]
        });

        this.casePreviewDialog.removeCaseFromCaseList("002075129200002236722024");

        assert.ok(this.casePreviewDialog.oContentTable.contentTableData.getProperty("/items").length === 0);
    });

    QUnit.test("test formatPOInstallation() should return format installation text", function(assert) {
        assert.deepEqual(this.casePreviewDialog.formatPOInstallation("123 - ERP Standard Support", "0020659687"), "ERP Standard Support (0020659687)");
    });

    QUnit.test("test open()", function(assert) {
        const event = {
            getSource: function() {
                return {
                    getBindingContext: function() {
                        return {
                            getObject: function() {
                                return {
                                    pointer: "123"
                                };
                            }
                        };
                    },
                    setBusy: function() {}
                };
            }
        };
        const done = assert.async();
        this.casePreviewDialog._oDialog.openBy = function() {};


        const stubInitDialogModel = this.sandbox.stub(this.casePreviewDialog, "initDialogModel").returns(Promise.resolve());
        const stubOpenBy = this.sandbox.stub(this.casePreviewDialog._oDialog, "openBy");

        this.casePreviewDialog.open(event);

        stubInitDialogModel.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.ok(stubInitDialogModel.calledOnce);
                assert.ok(stubOpenBy.calledOnce);
                done();
            });
        });
    });

    QUnit.test("test onOpenCaseDetail()", function(assert) {
        this.casePreviewDialog.previewModel = new JSONModel({
            pointer: "123"
        });
        this.casePreviewDialog._oDialog.close = function() {};

        const stubRedirectToCaseDetail = this.sandbox.stub(sap.m.URLHelper, "redirect");

        this.casePreviewDialog.onOpenCaseDetail();

        assert.equal(this.casePreviewDialog.previewModel.getProperty("/pointer"), "123");
        assert.deepEqual(stubRedirectToCaseDetail.getCall(0).args[0], "/case/123/overview");
    });

    QUnit.test("test regenerateCanCloseValue(), infoDoc is true", function(assert) {
        this.casePreviewDialog.caseDetailData = {
            infoDoc: true
        };
        this.casePreviewDialog.regenerateCanCloseValue();
        assert.false(this.casePreviewDialog.caseDetailData.isCanClose);
    });

    QUnit.test("test regenerateCanCloseValue(), infoDoc is false, RespITSM is BCP but statusId not eq 1", function(assert) {
        this.casePreviewDialog.caseDetailData = {
            infoDoc: false,
            RespITSM: "BCP",
            statusId: "2"
        };
        this.casePreviewDialog.regenerateCanCloseValue();
        assert.false(this.casePreviewDialog.caseDetailData.isCanClose);
    });

    QUnit.test("test regenerateCanCloseValue(), infoDoc is false, RespITSM is BCP, statusId eq 1", function(assert) {
        this.casePreviewDialog.caseDetailData = {
            infoDoc: false,
            RespITSM: "BCP",
            statusId: "1"
        };
        this.casePreviewDialog.regenerateCanCloseValue();
        assert.ok(this.casePreviewDialog.caseDetailData.isCanClose);
    });

    QUnit.test("test regenerateCanCloseValue(), infoDoc is false, RespITSM is not BCP", function(assert) {
        this.casePreviewDialog.caseDetailData = {
            infoDoc: false,
            RespITSM: "BCP",
            statusId: "1"
        };
        this.casePreviewDialog.regenerateCanCloseValue();
        assert.ok(this.casePreviewDialog.caseDetailData.isCanClose);
    });

    QUnit.test("test regenerateCanCloseValue(), isCanClose is false, infoDoc is false, RespITSM is not bcp", function(assert) {
        this.casePreviewDialog.caseDetailData = {
            infoDoc: false,
            isCanClose: false,
            RespITSM: "BCP",
            statusId: "1"
        };
        this.casePreviewDialog.regenerateCanCloseValue();
        assert.ok(this.casePreviewDialog.caseDetailData.isCanClose);
    });
});
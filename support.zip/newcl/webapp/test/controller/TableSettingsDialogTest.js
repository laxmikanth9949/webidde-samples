sap.ui.define([
    "./BaseTestUtility",
    "../../controller/TableSettingsDialog",
    "../../controller/Main.controller",
    "sap/ui/core/mvc/View",
    "sap/ui/model/json/JSONModel"
], function(BaseTestUtility, TableSettingsDialog, Main, View, JSONModel) {

    QUnit.module("TableSettingsDialogTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                this.tableSettingsDialog = new TableSettingsDialog(this.contentTable);
                this.tableSettingsDialog._oDialog = new View();
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test onPressReset process", function(assert) {
        this.tableSettingsDialog.oContentTable.contentTableColumns = new JSONModel({
            columns: [
                {key: "column1", visible: false},
                {key: "column2", visible: true},
                {key: "column3", visible: false}
            ]
        });
        this.tableSettingsDialog.lastSelectedColumnsList = [
            {key: "column1", visible: true},
            {key: "column2", visible: false},
            {key: "column3", visible: true}
        ];

        this.tableSettingsDialog.onPressReset();

        assert.true(this.tableSettingsDialog.oContentTable.contentTableColumns.getData().columns[0].visible);
        assert.false(this.tableSettingsDialog.oContentTable.contentTableColumns.getData().columns[1].visible);
        assert.true(this.tableSettingsDialog.oContentTable.contentTableColumns.getData().columns[2].visible);
    });

    QUnit.test("test setTheLastSelectionColumns", function(assert) {
        this.tableSettingsDialog.oContentTable.contentTableColumns = new JSONModel({
            columns: [
                {key: "column1", visible: false},
                {key: "column2", visible: true},
                {key: "column3", visible: false}
            ]
        });

        this.tableSettingsDialog.setTheLastSelectionColumns();

        assert.deepEqual(this.tableSettingsDialog.lastSelectedColumnsList, this.tableSettingsDialog.oContentTable.contentTableColumns.getData().columns);
    });

    QUnit.test("test open process", function(assert) {
        this.tableSettingsDialog._oDialog = {
            open: this.sandbox.stub()
        };
        const stubInitDialogModel = this.sandbox.stub(this.tableSettingsDialog, "initDialogModel");
        const stubApplyVariantGroupItemSelections = this.sandbox.stub(this.tableSettingsDialog, "applyVariantGroupItemSelections");

        this.tableSettingsDialog.open();

        assert.ok(stubInitDialogModel.calledOnce);
        assert.ok(stubApplyVariantGroupItemSelections.calledOnce);
        assert.ok(this.tableSettingsDialog._oDialog.open.calledOnce);
    });

    QUnit.test("test initDialogModel process", function(assert) {
        this.tableSettingsDialog._oDialog = {
            setModel: this.sandbox.stub()
        };
        this.tableSettingsDialog.oContentTable.contentTableColumns = new JSONModel();
        const stubSetTheLastSelectionColumns = this.sandbox.stub(this.tableSettingsDialog, "setTheLastSelectionColumns");

        this.tableSettingsDialog.initDialogModel();

        assert.ok(this.tableSettingsDialog._oDialog.setModel.calledOnce);
        assert.ok(stubSetTheLastSelectionColumns.calledOnce);
    });

    QUnit.test("test applyVariantGroupItemSelections process, nothing happens", function(assert) {
        this.tableSettingsDialog.mainPage.setModel(new JSONModel({
            segmentButton: {selectedKey: "other"}
        }), "$this.personalVariantModel");
        const stubGroupReset = this.sandbox.stub(this.tableSettingsDialog, "groupReset");
        const stubGetFragment = this.sandbox.stub(this.tableSettingsDialog, "getFragment");


        this.tableSettingsDialog.applyVariantGroupItemSelections();

        assert.ok(stubGroupReset.notCalled);
        assert.ok(stubGetFragment.notCalled);
    });

    QUnit.test("test applyVariantGroupItemSelections process, with variantGroupSorter", function(assert) {
        this.tableSettingsDialog.mainPage.setModel(new JSONModel({
            segmentButton: {selectedKey: "personal"}
        }), "$this.personalVariantModel");

        this.tableSettingsDialog.mainPageCtrl = {
            personalizeControl: {
                svm: {
                    getModified: function() {
                        return true;
                    }
                }
            }
        };

        this.tableSettingsDialog.oContentTable = {
            getFragment: function() {
                return {
                    getBinding: function() {
                        return {
                            aSorters: [{vGroup: "group", bDescending: true}]
                        };
                    }
                };
            }
        };

        const stubSetGroupDescending = this.sandbox.stub(this.tableSettingsDialog.getFragment(), "setGroupDescending");
        const stubGetGroupItems = this.sandbox.stub(this.tableSettingsDialog.getFragment(), "getGroupItems").returns([]);
        const stubGroupReset = this.sandbox.stub(this.tableSettingsDialog, "groupReset");

        this.tableSettingsDialog.applyVariantGroupItemSelections();

        assert.ok(stubSetGroupDescending.calledOnce);
        assert.ok(stubGetGroupItems.calledOnce);
        assert.ok(stubGroupReset.notCalled);
    });
});
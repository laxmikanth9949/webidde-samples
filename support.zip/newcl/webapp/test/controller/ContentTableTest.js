sap.ui.define([
    "./BaseTestUtility",
    "../../utilities/ApiCallCollection",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast"
], function( BaseTestUtility, ApiCallCollection, JSONModel, MessageToast) {
    "use strict";

    QUnit.module("ContentTableTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test setDefaultModels() should set default model", function(assert) {
        this.contentTable.setDefaultModels();
        assert.ok(this.contentTable.mainPage.getModel("$this.contentTableData") !== undefined);
        assert.ok(this.contentTable.mainPage.getModel("$this.contentTableColumns") !== undefined);
    });

    QUnit.test("test formatColumnsTitle() should return Title value", function(assert) {
        const expected = "table_col_creator";
        const result = this.contentTable.formatColumnsTitle("table_col_creator");
        assert.deepEqual(result, expected);
    });

    QUnit.test("test formatPriorityStatus() should return right status type of ObjectStatus", function(assert) {
        const R1 = this.contentTable.formatPriorityStatus("1");
        const R2 = this.contentTable.formatPriorityStatus("2");
        const R3 = this.contentTable.formatPriorityStatus("3");
        const R4 = this.contentTable.formatPriorityStatus("4");
        assert.deepEqual(R1, "Error");
        assert.deepEqual(R2, "Error");
        assert.deepEqual(R3, "None");
        assert.deepEqual(R4, "None");
    });

    QUnit.test("test formatInstallationNameTxt() should return right installation name", function(assert) {
        const expected = "Installation AH1";
        const result = this.contentTable.formatInstallationNameTxt("0020659001 - Installation AH1");
        assert.deepEqual(result, expected);
    });

    QUnit.test("test formatInstallationIdTxt() should return right installation id", function(assert) {
        const expected = "0020659001";
        const result = this.contentTable.formatInstallationIdTxt("0020659001 - Installation AH1");
        assert.deepEqual(result, expected);
    });

    QUnit.test("test formatSystemLinkText() should remove leading 0 in system number", function(assert) {
        const expected = "850493900";
        const result = this.contentTable.formatSystemLinkText("000000000850493900");
        assert.deepEqual(result, expected);
    });

    QUnit.test("test formatComponentDescription() should return component description", function(assert) {
        const expected = "Network connection" + "\n" + "(XX-SER-NET)";
        const result = this.contentTable.formatComponentDescription("Network connection", "XX-SER-NET");
        assert.deepEqual(result, expected);
    });

    QUnit.test("test formatCreatorLinkVisible() should show link if user is a S-user", function(assert) {
        const R1 = this.contentTable.formatCreatorLinkVisible("S0018132425");
        const R2 = this.contentTable.formatCreatorLinkVisible("Test Sap");
        assert.true(R1);
        assert.false(R2);
    });

    QUnit.test("test formatCreatorTxt() should return right creator name", function(assert) {
        const R1 = this.contentTable.formatCreatorTxt("Test Sap");
        assert.deepEqual(R1, "SAP");
        this.mainController.mainPage.setModel(new JSONModel({reporter: {value: [{reporterId: "S0018132425", reporterTxt: "TEST SAP CREATOR"}]}}), "$this.filterBarData");
        const R2 = this.contentTable.formatCreatorTxt("S0018132425");
        assert.deepEqual(R2, "TEST SAP CREATOR");
    });

    QUnit.test("test formatCustomerNameTxt() should return right customer name", function(assert) {
        const expected = "Aldinger Cosmetics Test-Account AGS Data Quality";
        const result = this.contentTable.formatCustomerNameTxt("1272047 - Aldinger Cosmetics Test-Account AGS Data Quality");
        assert.deepEqual(result, expected);
    });

    QUnit.test("test onPressFavoriteIcon(), api success, then change to unmark", function(assert) {
        const stubUpdateCaseFavState = this.sandbox.stub(ApiCallCollection, "updateCaseFavState").returns(Promise.resolve());
        const done = assert.async();
        const oEvent = {
            getSource : function() {
                return {
                    data : function() {
                        return "123456";
                    },

                    getSrc : function() {
                        return "sap-icon://favorite";
                    },

                    setBusy : function() {}
                };
            }
        };
        this.contentTable.contentTableData.setProperty("/items", [{
            pointer : "1111",
            isFavorite : true
        },
        {
            pointer : "123456",
            isFavorite : true
        }
        ]);

        this.contentTable.onPressFavoriteIcon(oEvent);

        stubUpdateCaseFavState.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.false(this.contentTable.contentTableData.getProperty("/items/1/isFavorite"));
                done();
            });
        });
    });

    QUnit.test("test onPressFavoriteIcon(), api success, then change to mark", function(assert) {
        const stubUpdateCaseFavState = this.sandbox.stub(ApiCallCollection, "updateCaseFavState").returns(Promise.resolve());
        const done = assert.async();
        const oEvent = {
            getSource : function() {
                return {
                    data : function() {
                        return "123456";
                    },

                    getSrc : function() {
                        return "sap-icon://unfavorite";
                    },

                    setBusy : function() {}
                };
            }
        };
        this.contentTable.contentTableData.setProperty("/items", [{
            pointer : "1111",
            isFavorite : true
        },
        {
            pointer : "123456",
            isFavorite : false
        }
        ]);

        this.contentTable.onPressFavoriteIcon(oEvent);

        stubUpdateCaseFavState.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.true(this.contentTable.contentTableData.getProperty("/items/1/isFavorite"));
                done();
            });
        });
    });

    QUnit.test("test onPressFavoriteIcon(), api failed, then show unmark failed Msg", function(assert) {
        const stubUpdateCaseFavState = this.sandbox.stub(ApiCallCollection, "updateCaseFavState").returns(Promise.reject());
        const done = assert.async();
        const messageStub = this.sandbox.stub(MessageToast, "show");
        const oEvent = {
            getSource : function() {
                return {
                    data : function() {
                        return "123456";
                    },

                    getSrc : function() {
                        return "sap-icon://favorite";
                    },

                    setBusy : function() {}
                };
            }
        };

        this.contentTable.onPressFavoriteIcon(oEvent);

        stubUpdateCaseFavState.lastCall.returnValue.catch(() => {
            setTimeout(() => {
                assert.true(messageStub.calledWith("table_unmark_as_favorite_failed"));
                done();
            });
        });
    });

    QUnit.test("test onPressFavoriteIcon(), api failed, then show mark failed Msg", function(assert) {
        const stubUpdateCaseFavState = this.sandbox.stub(ApiCallCollection, "updateCaseFavState").returns(Promise.reject(new Error("whatever")));
        const done = assert.async();
        const messageStub = this.sandbox.stub(MessageToast, "show");
        const oEvent = {
            getSource : function() {
                return {
                    data : function() {
                        return "123456";
                    },

                    getSrc : function() {
                        return "sap-icon://unfavorite";
                    },

                    setBusy : function() {}
                };
            }
        };

        this.contentTable.onPressFavoriteIcon(oEvent);

        stubUpdateCaseFavState.lastCall.returnValue.catch(() => {
            setTimeout(() => {
                assert.true(messageStub.calledWith("table_mark_as_favorite_failed"));
                done();
            });
        });
    });

    QUnit.test("test adjustTableSettingsByVm() should hide some columns and show the aaep columns when change to aaep", function(assert) {
        this.contentTable.mainPage.getModel("$this.personalVariantModel").setProperty("/defaultVm/selectedKey","aaepCase");
        this.sandbox.stub(this.contentTable.tableSettingsDialog, "groupReset");

        this.contentTable.adjustTableSettingsByVm();

        const hideColumns = this.contentTable.mainPage.getModel("$this.contentTableColumns").getData().columns.filter(v => v.visible === false).map(v => v.key);
        const displayColumns = this.contentTable.mainPage.getModel("$this.contentTableColumns").getData().columns.filter(v => v.visible === true).map(v => v.key);
        assert.deepEqual(hideColumns, ["statusTxt","createdBy","createdAt","autoConfirmDateTxt"]);
        assert.true(displayColumns.includes("aaEPSessStatus"));
        assert.true(displayColumns.includes("quesDateCreated"));
        assert.true(displayColumns.includes("quesExpirationDate"));
    });

    QUnit.test("test adjustTableSettingsByVm() search for normal default Vm", function(assert) {
        this.contentTable.mainPage.getModel("$this.personalVariantModel").setProperty("/defaultVm/selectedKey","whatever");
        this.sandbox.stub(this.contentTable.tableSettingsDialog, "groupReset");

        this.contentTable.adjustTableSettingsByVm();

        const hideColumns = this.contentTable.mainPage.getModel("$this.contentTableColumns").getData().columns.filter(v => v.visible === false).map(v => v.key);
        assert.deepEqual(hideColumns, ["aaEPSessStatus","quesDateCreated","quesExpirationDate"]);
    });

    QUnit.test("test formatCaseDiscussionText(), sno case", function(assert) {
        const result = this.contentTable.formatCaseDiscussionText("test");
        assert.deepEqual(result, "<div class=\"sapUiCasePreviewHTMLMemo\">test</div>");
    });

    QUnit.test("test formatCaseDiscussionText(), bcp case", function(assert) {
        const result = this.contentTable.formatCaseDiscussionText("test","BCP");
        assert.deepEqual(result, "<div class=\"sapUiCasePreviewHTMLMemo\">test</div>");
    });

    QUnit.test("test onDisplayAutoConfirm(), default tab press", function(assert) {
        const stubOnSwitchSegBtnChange = this.sandbox.stub(this.personalizeControl, "onSwitchSegBtnChange");
        const stubOnDefaultVmSetAndSearch = this.sandbox.stub(this.personalizeControl, "onDefaultVmSetAndSearch");
        this.personalizeControl.personalVariantModel.setProperty("/defaultVm/selectedKey", "aaa");

        this.contentTable.onDisplayAutoConfirm();

        assert.true(stubOnDefaultVmSetAndSearch.calledOnce);
        assert.true(stubOnSwitchSegBtnChange.notCalled);
        assert.deepEqual(this.personalizeControl.personalVariantModel.getProperty("/defaultVm/selectedKey"), "autoConfirm");
    });

    QUnit.test("test onDisplayAutoConfirm(), personal tab pree", function(assert) {
        const stubOnSwitchSegBtnChange = this.sandbox.stub(this.personalizeControl, "onSwitchSegBtnChange");
        const stubOnDefaultVmSetAndSearch = this.sandbox.stub(this.personalizeControl, "onDefaultVmSetAndSearch");
        this.personalizeControl.personalVariantModel.setProperty("/defaultVm/selectedKey", "aaa");
        this.personalizeControl.personalVariantModel.setProperty("/segmentButton/selectedKey", "personal");

        this.contentTable.onDisplayAutoConfirm();

        assert.true(stubOnDefaultVmSetAndSearch.notCalled);
        assert.true(stubOnSwitchSegBtnChange.calledOnce);
        assert.deepEqual(this.personalizeControl.personalVariantModel.getProperty("/defaultVm/selectedKey"), "autoConfirm");
        assert.deepEqual(this.personalizeControl.personalVariantModel.getProperty("/segmentButton/selectedKey"), "default");
    });

    QUnit.test("test onPressCasePreview(), serviceType = H", function(assert) {
        const oEvent = {
            getSource : function() {
                return {
                    getBindingContext : function() {
                        return {
                            getObject : function() {
                                return {
                                    serviceType : "H"
                                };
                            }
                        };
                    }
                };
            }
        };
        const stubOpenCasePreviewArchivedDialog = this.sandbox.stub(this.contentTable.casePreviewArchivedDialog, "open");
        const stubOpenCasePreviewDialog = this.sandbox.stub(this.contentTable.casePreviewDialog, "open");

        this.contentTable.onPressCasePreview(oEvent);

        assert.true(stubOpenCasePreviewArchivedDialog.calledOnce);
        assert.true(stubOpenCasePreviewDialog.notCalled);
    });

    QUnit.test("test onPressCasePreview(), serviceType != H", function(assert) {
        const oEvent = {
            getSource : function() {
                return {
                    getBindingContext : function() {
                        return {
                            getObject : function() {
                                return {
                                    serviceType : "S"
                                };
                            }
                        };
                    }
                };
            }
        };
        const stubOpenCasePreviewArchivedDialog = this.sandbox.stub(this.contentTable.casePreviewArchivedDialog, "open");
        const stubOpenCasePreviewDialog = this.sandbox.stub(this.contentTable.casePreviewDialog, "open");

        this.contentTable.onPressCasePreview(oEvent);

        assert.true(stubOpenCasePreviewArchivedDialog.notCalled);
        assert.true(stubOpenCasePreviewDialog.calledOnce);
    });

    QUnit.test("test onFavoriteOnlyAndSearchChange()", function(assert) {
        this.contentTable.contentTableDisplay.setProperty("/searchFieldValue", "111");
        this.sandbox.stub(this.contentTable.getFragment(), "getBinding").returns([]);
        const stubQueryFilter = this.sandbox.stub(this.contentTable.getFragment().getBinding("items"), "filter");

        this.contentTable.onFavoriteOnlyAndSearchChange();

        stubQueryFilter.getCalls()[0].lastArg.aFilters[0].aFilters.forEach( e => {
            assert.equal(e.oValue1, "111");
        });
    });

    QUnit.test("test openTableSettingsDialogOpen(), aaep case", function(assert) {
        const stubOpenTableSettingsDialogOpen = this.sandbox.stub(this.contentTable.tableSettingsDialog, "open").returns(Promise.resolve({}));
        const done = assert.async();
        const stubOnFavoriteOnlyAndSearchChange = this.sandbox.stub(this.contentTable, "onFavoriteOnlyAndSearchChange");
        const stubGroupByTableSettingDialog = this.sandbox.stub(this.contentTable, "groupByTableSettingDialog");
        const stubclearColumnSortIcon = this.sandbox.stub(this.contentTable, "clearColumnSortIcon");
        this.sandbox.stub(this.contentTable, "updateColumnVisibilityInUserSettings");
        this.contentTable.contentTableDisplay.setProperty("/searchFieldValue", "111");
        this.contentTable.mainPage.getModel("$this.personalVariantModel").setProperty("/defaultVm/selectedKey","aaepCase");

        this.contentTable.openTableSettingsDialogOpen();

        stubOpenTableSettingsDialogOpen.lastCall.returnValue.then(() => {
            setTimeout(() => {
                assert.true(stubOnFavoriteOnlyAndSearchChange.calledOnce);
                assert.true(stubGroupByTableSettingDialog.calledOnce);
                assert.true(stubclearColumnSortIcon.calledOnce);
                assert.true(stubOnFavoriteOnlyAndSearchChange.calledOnce);
                done();
            });
        });
    });

    QUnit.test("test updateColumnVisibilityInUserSettings()", function(assert) {
        this.contentTable.contentTableColumns.getData().columns = [{a:"a"},{b:"b"}];
        const stubUpdateUserSettingsColumListSelection = this.sandbox.stub(ApiCallCollection, "updateUserSettingsColumListSelection");

        this.contentTable.updateColumnVisibilityInUserSettings();

        assert.true(stubUpdateUserSettingsColumListSelection.calledOnce);
        assert.deepEqual(this.contentTable.userColumnsSettings[0].a,"a");
        assert.deepEqual(this.contentTable.userColumnsSettings[1].b,"b");
    });

    QUnit.test("test groupByTableSettingDialog()", function(assert) {
        const data = {
            groupItem : {
                getKey : function() {
                    return "a";
                }
            },
            groupDescending : true,
        };
        this.sandbox.stub(this.contentTable.getFragment(), "getBinding").returns([]);
        const stubGetItemsSort = this.sandbox.stub(this.contentTable.getFragment().getBinding("items"), "sort");

        this.contentTable.groupByTableSettingDialog(data);

        assert.deepEqual(stubGetItemsSort.getCall(0).firstArg.sPath, "a");
        assert.true(stubGetItemsSort.getCall(0).firstArg.bDescending);
    });

    QUnit.test("test datesAt AaEPTimeFormat", function(assert) {
        assert.equal(this.contentTable.datesAt("2024-07-05", "11:16:48"), "2024-07-05\n11:16:48 AM");
        assert.equal(this.contentTable.datesAt("2024-07-05", "18:16:48"), "2024-07-05\n6:16:48 PM");
        assert.equal(this.contentTable.AaEPTimeFormat("2024-06-27T03:34:40Z"), "Jun 27, 2024");
    });
});
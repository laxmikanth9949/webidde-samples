sap.ui.define([
    "./BaseTestUtility",
    "../../controller/FilterValueHelpDialog",
    "sap/ui/model/json/JSONModel"
], function(BaseTestUtility, FilterValueHelpDialog, JSONModel) {

    QUnit.module("FilterValueHelpDialogTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                this.filterValueHelpDialog = new FilterValueHelpDialog(this.headerFilterBar,{});
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test open() process", function(assert) {
        this.filterValueHelpDialog._oDialog = {
            open : function() {}
        };
        const stubInitDialogModel = this.sandbox.stub(this.filterValueHelpDialog, "initDialogModel");
        const stubDialogOpen = this.sandbox.stub(this.filterValueHelpDialog._oDialog, "open");

        const returnPromise = this.filterValueHelpDialog.open();

        assert.ok(stubInitDialogModel.calledOnce);
        assert.ok(stubDialogOpen.calledOnce);
        assert.ok(returnPromise instanceof Promise);
    });

    QUnit.test("test open() process, no _oDialog", function(assert) {
        this.filterValueHelpDialog._oDialog = null;
        this.filterValueHelpDialog.getFragment = function() {
            return {
                open: function() {}
            };
        };
        const stubInitDialogModel = this.sandbox.stub(this.filterValueHelpDialog, "initDialogModel");
        const stubAddDependent = this.sandbox.stub(this.filterValueHelpDialog.mainPage, "addDependent");

        this.filterValueHelpDialog.open();

        assert.ok(stubInitDialogModel.calledOnce);
        assert.ok(stubAddDependent.calledOnce);
        assert.ok(this.filterValueHelpDialog._oDialog);
    });

    QUnit.test("test open() initDialogModel", function(assert) {
        this.filterValueHelpDialog._oDialog = new sap.m.Dialog();
        this.filterValueHelpDialog.oFilterItem = {
            titleKey: "key1",
            descKey: "desc1",
            dialogTitle: "dialogTitle1",
            sPath: "/path1"
        };
        this.filterValueHelpDialog.oHeaderFilter.filterBarDataModel = new JSONModel({
            path1: {
                selectedKey: [{key1: "1"},{key1: "2"}],
                value: [{key1: "1", desc1: "1"},{key1: "2", desc1: "2"},{key1: "3", desc1: "3"}]
            }
        });

        this.filterValueHelpDialog.initDialogModel();

        assert.deepEqual(this.filterValueHelpDialog._oDialog.getTitle(), "dialogTitle1");
        assert.deepEqual(this.filterValueHelpDialog._oDialog.getModel("$this.filterHelperDialog").getData().list, [
            {title: "2", desc: "2", selected: true},
            {title: "1", desc: "1", selected: true},
            {title: "3", desc: "3", selected: false}
        ]);
    });

    QUnit.test("test handleValueHelpSearch() process", function(assert) {
        const stubFilter = this.sandbox.stub();
        const event = {
            getSource: function() {
                return {
                    getBinding: function() {
                        return {
                            filter: stubFilter
                        };
                    }
                };
            },
            getParameter: function() {
                return "searchValue";
            }
        };

        this.sandbox.stub(this.filterValueHelpDialog, "generateSearchDialogFilters").returns(["filter1"]);

        this.filterValueHelpDialog.handleValueHelpSearch(event);

        assert.deepEqual(stubFilter.firstCall.args[0], ["filter1"]);
    });

    QUnit.test("test handleValueHelpSearch() process, no items", function(assert) {
        const event = {
            getSource: function() {
                return {
                    getBinding: function() {}
                };
            },

            getParameter: function() {
                return "searchValue";
            }
        };
        const stubGetParameter = this.sandbox.stub(event, "getParameter");

        this.filterValueHelpDialog.handleValueHelpSearch(event);

        assert.ok(stubGetParameter.notCalled);
    });

    QUnit.test("test handleValueHelpConfirm() process", function(assert) {
        const event = {
            getParameter: function() {
                return {
                    map: function(callback) {
                        return callback({getObject: function() {
                            return {title: "title1", desc: "desc1"};
                        }});
                    }
                };
            }
        };
        const stubDialogResolve = this.sandbox.stub(this.filterValueHelpDialog, "dialogResolve");
        this.filterValueHelpDialog.oFilterItem = {
            titleKey: "key1",
            descKey: "desc1"
        };

        this.filterValueHelpDialog.handleValueHelpConfirm(event);

        assert.deepEqual(stubDialogResolve.firstCall.args[0], {key1: "title1", desc1: "desc1"});
    });

    QUnit.test("test generateSearchDialogFilters() process", function(assert) {
        const result = this.filterValueHelpDialog.generateSearchDialogFilters(["field1"], "searchValue");

        assert.deepEqual(result[0].aFilters[0].sPath, "field1");
        assert.deepEqual(result[0].aFilters[0].sOperator, "Contains");
        assert.deepEqual(result[0].aFilters[0].oValue1, "searchValue");
    });

    QUnit.test("test generateSearchDialogFilters() process， no filters", function(assert) {
        const result = this.filterValueHelpDialog.generateSearchDialogFilters([], "searchValue");

        assert.deepEqual(result, []);
    });
});
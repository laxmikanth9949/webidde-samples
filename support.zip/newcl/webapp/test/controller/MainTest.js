sap.ui.define([
    "./BaseTestUtility"
], function(BaseTestUtility) {
    "use strict";
    QUnit.module("MainTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test init MainController process", function(assert) {
        const stubAddAggregations = this.sandbox.stub(this.mainController, "addMainPageAggregations");

        this.mainController.onInit();

        assert.true(stubAddAggregations.calledOnce);
    });
});
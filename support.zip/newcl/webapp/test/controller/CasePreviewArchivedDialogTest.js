sap.ui.define([
    "./BaseTestUtility",
    "../../controller/CasePreviewArchivedDialog",
    "sap/m/PDFViewer"
], function(BaseTestUtility, CasePreviewArchivedDialog, PDFViewer) {

    QUnit.module("CasePreviewArchivedDialogTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                this.casePreviewArchivedDialog = new CasePreviewArchivedDialog(this.contentTable);
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test open() process", function(assert) {
        this.casePreviewArchivedDialog._oDialog = {
            openBy : function() {}
        };
        const stubOpenBy = this.sandbox.stub(this.casePreviewArchivedDialog._oDialog, "openBy");
        const event = {
            getSource: function() {
                return {
                    getBindingContext: function() {
                        return {
                            getObject: function() {
                                return {
                                    pointer: "123"
                                };
                            }
                        };
                    }
                };
            }
        };

        this.casePreviewArchivedDialog.open(event);

        assert.deepEqual(this.casePreviewArchivedDialog.caseDetailData.pointer, "123");
        assert.ok(stubOpenBy.calledOnce);
        assert.ok(this.casePreviewArchivedDialog._oDialog);

    });

    QUnit.test("test open() process, no _oDialog", function(assert) {
        const event = {
            getSource: function() {
                return {
                    getBindingContext: function() {
                        return {
                            getObject: function() {
                                return {
                                    pointer: "123"
                                };
                            }
                        };
                    }
                };
            }
        };
        this.casePreviewArchivedDialog._oDialog = null;
        this.casePreviewArchivedDialog.getFragment = function() {
            return {
                openBy: function() {}
            };
        };
        const stubAddDependent = this.sandbox.stub(this.casePreviewArchivedDialog.mainPage, "addDependent");

        this.casePreviewArchivedDialog.open(event);

        assert.ok(stubAddDependent.calledOnce);
        assert.ok(this.casePreviewArchivedDialog._oDialog);

    });

    QUnit.test("test onOpenArchivedCase() process", function(assert) {
        const stubSetSource = this.sandbox.stub(PDFViewer.prototype, "setSource");
        this.casePreviewArchivedDialog.caseDetailData = {
            pointer: "123"
        };
        const sUrl = "https://userapps.support.sap.com/sap/support/incident/print/default.htm?pointer=123";

        this.casePreviewArchivedDialog.onOpenArchivedCase();

        assert.deepEqual(stubSetSource.getCall(0).args[0], sUrl);
    });

    QUnit.test("test onOpenArchivedCase() process， _pdfViewer exsist", function(assert) {
        const stubSetSource = this.sandbox.stub();
        this.casePreviewArchivedDialog._pdfViewer = {
            open : function() {},
            setSource : stubSetSource,
            setTitle : function() {}
        };

        this.casePreviewArchivedDialog.caseDetailData = {
            pointer: "123"
        };
        const sUrl = "https://userapps.support.sap.com/sap/support/incident/print/default.htm?pointer=123";

        this.casePreviewArchivedDialog.onOpenArchivedCase();

        assert.deepEqual(stubSetSource.getCall(0).args[0], sUrl);
    });

    QUnit.test("test onClosePreviewArchived()", function(assert) {
        this.casePreviewArchivedDialog._oDialog = {
            close : function() {}
        };
        const stubClose = this.sandbox.stub(this.casePreviewArchivedDialog._oDialog, "close");

        this.casePreviewArchivedDialog.onClosePreviewArchived();

        assert.ok(stubClose.calledOnce);
    });
});
sap.ui.define([
    "../../utilities/ExportTableUtil",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel",
    "../controller/BaseTestUtility"
], function(ExportTableUtil, JSONModel, ResourceModel, BaseTestUtility) {
    "use strict";

    const contentTableData = new JSONModel({
        items: [{
            incidentNumber: "223041/2024",
            systemNumber: "000000000311834471",
            statusTxt: "Customer Action",
            subject: "test",
            componentTxt: "SAP for me",
            componentKey: "SV-ES-SEC",
            customerTxt: "1208936 - SAP Test Account - aPaul Pharma Test-Account AGS Data Quality"
        }]
    });

    QUnit.module("ExportTableUtilTest", {
        before: function() {
            QUnit.onUncaughtException = function() {};
            QUnit.config.current.ignoreGlobalErrors = true;
            this.sandbox = sinon.createSandbox();
        },

        beforeEach: function(assert) {
            const done = assert.async();
            BaseTestUtility.constructorApp(this).then(() => {
                this.contentTable.getFragment = () => ({
                    getBinding: () => ({
                        getAllCurrentContexts: () => {
                            return [{getObject: () => contentTableData.getData().items[0]}];
                        }
                    })
                });
                done();
            });
        },

        afterEach: function() {
            this.sandbox.restore();
        }
    });

    QUnit.test("test getColumns when download data", function(assert) {
        const expectData = [
            "incidentNumber",
            "subject",
            "statusTxt",
            "priorityTxt",
            "installationTxt",
            "systemNumber",
            "systemTxt",
            "componentTxt",
            "reporterId",
            "reporterTxt",
            "creatorId",
            "createdBy",
            "customerId",
            "customerTxt",
            "createdAt",
            "updatedAt",
            "autoConfirmDateTxt"
        ];
        const actualData = ExportTableUtil.getColumns(this.contentTable).map(item => item.property);
        assert.deepEqual(expectData, actualData);
    });

    QUnit.test("test getDataSource when download data", function(assert) {
        const expectData = {
            incidentNumber: "223041/2024",
            systemNumber: "311834471",
            statusTxt: "Customer Action",
            subject: "test",
            componentKey: "SV-ES-SEC",
            componentTxt: "SAP for me\r\n(SV-ES-SEC)",
            customerTxt: " SAP Test Account - aPaul Pharma Test-Account AGS Data Quality",
            createdBy: "SAP",
            creatorId: "",
            quesDateCreated: "",
            quesExpirationDate: "",
        };
        const actualData = ExportTableUtil.getDataSource(this.contentTable);
        assert.deepEqual(expectData, actualData[0]);
    });

});
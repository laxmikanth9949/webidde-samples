sap.ui.define([], function() {
    const apiCallCollection = new Object();

    apiCallCollection.getStatusList = function() {
        return jQuery.ajax("/backend/odata/support/CaseStatusSet", {
            method: "GET",
            data: {$format:"json"}
        }).then(data => data.value);
    };

    apiCallCollection.getPriorityList = function() {
        return jQuery.ajax("/backend/odata/support/CasePrioritySet", {
            method: "GET",
            data: {$format:"json"}
        }).then(data => data.value);
    };

    apiCallCollection.getSystemList = function() {
        return jQuery.ajax("/backend/odata/support/CaseSystemSet", {
            method: "GET",
            data: {$format:"json"}
        }).then(data => data.value);
    };

    apiCallCollection.getInstallationList = function() {
        return jQuery.ajax("/backend/odata/support/IncidentInstSet", {
            method: "GET",
            data: {$format:"json"}
        }).then(data => data.value);
    };

    apiCallCollection.getReporterList = function() {
        return jQuery.ajax("/backend/odata/support/IncidentReporterSet", {
            method: "GET",
            data: {$format:"json"}
        }).then(data => data.value);
    };

    apiCallCollection.updateCaseFavState = function(pointer, isFavorite) {
        return jQuery.ajax(`/backend/odata/support/CaseDetails('${pointer}')?pointer=${pointer}`, {
            method: "PATCH",
            contentType: "application/json",
            data: JSON.stringify({
                isFavorite: isFavorite
            })
        });
    };

    apiCallCollection.checkDeleteDraftAuth = function(pointer) {
        return jQuery.ajax("/backend/raw/support/CasePermissionW7Verticle?action=COMPLETE&pointer=" + pointer, {
            method: "GET",
            contentType: "application/json"
        });
    };

    apiCallCollection.updateUserSettingsColumListSelection = function(columnsList) {
        return jQuery.ajax("/backend/raw/common/Settings", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({"NEWCASELISTSETTINGS.COLUMNSLIST": columnsList}),
        });
    };

    apiCallCollection.updateUserSettingsIsSyncedOldVariantData = function(bIsSynced) {
        return jQuery.ajax("/backend/raw/common/Settings", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({"NEWCASELISTSETTINGS.SYNCEDOLDAPPVARIANT": bIsSynced}),
        });
    };

    apiCallCollection.getUserSettings = function() {
        return jQuery.ajax("/backend/raw/common/Settings/NEWCASELISTSETTINGS").catch((error) => {
            return {};
        });
    };

    apiCallCollection.requestCaseValidation = function(pointer) {
        return jQuery.ajax(`/backend/raw/support/CaseValidationVerticle?pointer=${pointer}`, {
            method: "GET",
            contentType: "application/json",
            dataType: "json"
        });
    };

    apiCallCollection.requestCaseDiscussion = function(pointer) {
        return jQuery.ajax(`/backend/odata/support/CaseDiscussion?$format=json&pointer=${pointer}`, {
            method: "GET",
            contentType: "application/json",
            dataType: "json"
        }).then(data => data.value);
    };

    apiCallCollection.requestCaseUpdate = function(data) {
        return jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
            method: "PUT",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify(data)
        });
    };

    apiCallCollection.onSearchCaseList = function(aFilters) {
        const filterMap = {
            status : "statusId",
            priority: "priorityId",
            lastUpdate: "lastUpdate",
            system: "systemNumber",
            createdOn: "createdAt",
            updatedOn: "updatedAt",
            installation: "installationId",
            reporter: "reporterId",
            customer: "customerId",
            creator: "createdBy",
            isFavorite: "isFavorite",
            aaEPDraftFlag: "aaEPDraftFlag",
            autoConfirmDate: "autoConfirmDate",
            searchTerm : "searchTerm"
        };

        let filterArray = [];

        aFilters.forEach( e => {
            const mappedKey = filterMap[e.key];
            switch (mappedKey) {
                case "createdAt": case "updatedAt": {
                    if (!e.value[0] || !e.value[1]) {
                        break;
                    }
                    // in case date value like '2024-05-02T06:27:46.866Z', need to covert to timestamp
                    const startTimestamp = e.value[0] === "string" ? new Date(e.value[0]).getTime() : e.value[0];
                    const endTimestamp = e.value[1] === "string" ? new Date(e.value[1]).getTime() : e.value[1];

                    const query = `${mappedKey} ge ${startTimestamp} and ${mappedKey} le ${endTimestamp}`;
                    filterArray.push(query);
                    break;
                }
                case "isFavorite": {
                    // cannot use the default fn, require isFavorite eq true, not 'true'
                    const query = `(${mappedKey} eq ${e.value[0]})`;
                    filterArray.push(query);
                    break;
                }
                case "autoConfirmDate": {
                    const today = new Date();
                    const year = today.getFullYear().toString();
                    const month = (today.getMonth() + 1).toString().padStart(2, "0");
                    const day = today.getDate().toString().padStart(2, "0");
                    // formated date YYYYMMDD
                    const todayTimestamp = year + month + day;
                    const query = `(${mappedKey} ge '${todayTimestamp}')`;
                    filterArray.push(query);
                    break;
                }
                default: filterArray.push(formatterFilterStringForEachEntry(mappedKey,e));
            }
        });

        function formatterFilterStringForEachEntry(mappedKey, aFilters) {
            // For creator, reporterID is the value key
            const key = mappedKey === "createdBy" ? "reporterId" : mappedKey;
            const conditions = aFilters.value.map(item => `${mappedKey} eq '${item[key] ?? item}'`).join(" or ");
            return `(${conditions})`;
        }

        const jQData = {};
        if (filterArray.length !== 0) {
            jQData["$filter"] = filterArray.join(" and ");
        }

        return jQuery.ajax("/backend/odata/support/CaseList", {
            method: "GET",
            data: jQData
        });
    };

    return apiCallCollection;
});

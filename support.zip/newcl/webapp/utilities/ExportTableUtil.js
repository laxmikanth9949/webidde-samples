sap.ui.define([
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet"
], function(ExportLibrary, Spreadsheet) {

    const ExportTableUtil = new Object();

    const EdmType = ExportLibrary.EdmType;

    ExportTableUtil.getColumns = function(oController) {
        const aExportColumns = [].concat(oController.contentTableColumns.getData().columns);
        // add a subject colunm after caseNr, only for export
        aExportColumns.splice(2, 0, {text: "table_col_subject", visible: true, key: "subject"});
        // add id information for customer, reporter, system, only for export
        for (let i = aExportColumns.length - 1; i >= 0; i--) {
            if (aExportColumns[i].text === "table_col_customer" && aExportColumns[i].visible) {
                aExportColumns.splice(i, 0, {text: "table_col_customer_number", visible: true, key: "customerId"});
            }
            if (aExportColumns[i].text === "table_col_reporter" && aExportColumns[i].visible) {
                aExportColumns.splice(i, 0, {text: "table_col_reporter_id", visible: true, key: "reporterId"});
            }
            if (aExportColumns[i].text === "table_col_creator" && aExportColumns[i].visible) {
                aExportColumns.splice(i, 0, {text: "table_col_creator_id", visible: true, key: "creatorId"});
            }
            if (aExportColumns[i].text === "table_col_system" && aExportColumns[i].visible) {
                aExportColumns.splice(i, 0, {text: "table_col_system_number", visible: true, key: "systemNumber"});
            }
        }
        return aExportColumns.filter(column => column.text && column.visible).map(column => {
            let sType = EdmType.String;
            if (column.key === "updatedAt" || column.key === "createdAt") {
                sType = EdmType.DateTime;
            }
            const oResult = {
                label: oController.i18n.getText(column.text), // title of excel
                type: sType,
                property: column.key // according to the attribute of data source
            };
            if (column.key === "componentTxt" || column.key === "createdAt" || column.key === "updatedAt") {
                oResult.wrap = true;
            }
            return oResult;
        });
    },

    ExportTableUtil.getDataSource = function(oController) {
        // using getBinds for keep the case list original sort
        const aCasesData = oController.getFragment().getBinding("items").getAllCurrentContexts().map(v => v.getObject());
        aCasesData?.forEach(item => {
            item.systemNumber = item?.systemNumber.substring(9);
            item.componentTxt = item?.componentTxt + "\r\n" + "(" + item?.componentKey + ")";
            item.customerTxt = item?.customerTxt.split("-").slice(1).join("-");
            item.creatorId = oController.formatCreatorLinkVisible(item.createdBy) ? item.createdBy : "";
            item.createdBy = oController.formatCreatorTxt(item.createdBy);
            item.quesDateCreated = oController.AaEPTimeFormat(item.quesDateCreated);
            item.quesExpirationDate = oController.AaEPTimeFormat(item.quesExpirationDate);
        });
        return aCasesData;
    },

    ExportTableUtil.onExport = function(oController) {
        const oSettings = {
            workbook: {
                columns: this.getColumns(oController),
                hierarchyLevel: "Level"
            },
            dataSource: this.getDataSource(oController) || [],
            fileName: "caseList.xlsx",
            worker: false
        };
        const oSheet = new Spreadsheet(oSettings);
        oSheet.build().finally(function() {
            oSheet.destroy();
        });
    };

    return ExportTableUtil;

});

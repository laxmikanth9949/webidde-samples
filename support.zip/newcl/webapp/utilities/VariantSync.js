sap.ui.define([], function() {

    const variantSync = new Object();
    let preparedSyncData = {};

    variantSync.sync = function() {
        return this.saveData();
    };

    variantSync.fetchData = function() {
        return jQuery.ajax("/flex/personalization/v1/data/sap.me.apps.support", {
            method: "GET",
            data: {$format:"json"}
        }).then(data => this.formatData(data));
    };


    variantSync.formatData = async function(data) {
        if (!data || !Object.keys(data).length > 0) {
            return {};
        }

        const currentVariantsIds = sap.ui.getCore().byId("PersonalizeControlFrg--newCaseListSvm").getAllVariants().map(e => e.getId());
        const newVariants = [];

        const replacedData = JSON.stringify(data.compVariants)
            .replaceAll("sap.me.apps.support","sap.me.apps.supportnewcl")
            .replaceAll("__$INTERNAL$","caseListFilters")
            .replaceAll("undefined","newCaseListSvm")
            .replaceAll("status_fi","status")
            .replaceAll("priority_fi","priority")
            .replaceAll("lastUpdate_fi","lastUpdate")
            .replaceAll("system_fi","system")
            .replaceAll("createdOn_fi","createdOn")
            .replaceAll("changedOn_fi","updatedOn")
            .replaceAll("installation_fi","installation")
            .replaceAll("reporter_fi","reporter")
            .replaceAll("creator_fi","creator")
            .replaceAll("customer_fi","customer");

        JSON.parse(replacedData).forEach(e => {
            if (!currentVariantsIds.includes(e.variantId)) {
                newVariants.push(e);
            }
        });

        if (newVariants.length > 0) {
            preparedSyncData.newVariants = newVariants;
        }

        const defaultVariantArr = JSON.stringify(data.changes).replaceAll("sap.me.apps.support","sap.me.apps.supportnewcl").replaceAll("undefined","newCaseListSvm");
        const defaultVariant = JSON.parse(defaultVariantArr).find(e => e.changeType === "defaultVariant");
        if (defaultVariant && Object.keys(defaultVariant).length > 0) {
            preparedSyncData.defaultVariant = defaultVariant;
        }

        return preparedSyncData;
    };

    variantSync.saveData = function() {
        const jQArr = [];

        const newVariants = preparedSyncData.newVariants;
        if (newVariants && newVariants.length > 0) {
            jQArr.push(jQuery.ajax("/flex/personalization/v1/changes/", {
                method: "POST",
                data: JSON.stringify(newVariants),
                headers: {"Content-Type": "application/json; charset=UTF-8"}
            }));
        }

        const defaultVariants = preparedSyncData.defaultVariant;
        if (defaultVariants) {
            jQArr.push(jQuery.ajax("/flex/personalization/v1/changes/" + defaultVariants.fileName, {
                method: "PUT",
                data: JSON.stringify(defaultVariants),
                headers: {"Content-Type": "application/json; charset=UTF-8"}
            }));
        }
        return Promise.allSettled(jQArr);
    };

    return variantSync;
});
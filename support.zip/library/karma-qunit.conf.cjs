/* eslint-env node */
const puppeteer = require("puppeteer");
process.env.CHROMIUM_BIN = puppeteer.executablePath();

let browser = "ChromiumHeadless",
    bSingleRun = true;
function isDebug(argument) {
    "use strict";
    return argument === "--debug";
}

function isGithub(argument) {
    return argument === "--github"
}
if (process.argv.some(isDebug)) {
    browser = "ChromeDebugging";
    bSingleRun = false;
}

if (process.argv.some(isGithub)) {
    browser = "ChromiumHeadlessGithub";
}

const skipSuccessUTMessageInGithubAction = browser === "ChromiumHeadlessGithub";

module.exports = function(config) {
    "use strict";

    config.set({
        frameworks: ["ui5", "qunit", "sinon"],
        basePath: "./",
        type: "library",
        paths: {
            src: "src/sap/me/support/cards",
            test: "test/sap/me/support/cards"
        },
        ui5: {
            mode: "script",
            config: {
                bindingSyntax: "complex",
                compatVersion: "edge",
                async: true,
                resourceroots: {
                    "sap.me.support.cards": "./base/src/sap/me/support/cards",
                    "sap.me.support.fragments": "./base/src/sap/me/support/fragments",
                    "test": "/base/test",
                    "mockModule": "/base/test/sap/me/support/fragments/mockModule", // defile the shorten module path
                }
            },
            tests: [
                "test/sap/me/support/cards/CaseCreationCardTest",
                "test/sap/me/support/cards/SupportNewsCardTest",
                "test/sap/me/support/cards/RequestExtendedSupportEntranceCardTest",
                "test/sap/me/support/cards/ReportCaseEntranceCardTest",
                "test/sap/me/support/utils/ContactHelperFactoryTest",
                "test/sap/me/support/utils/InfoExchangeTest",
                "test/sap/me/support/utils/HelpTest",
                "test/sap/me/support/utils/AttachmentHelperTest",
                "test/sap/me/support/utils/OpenDraftHelperTest",
                "test/sap/me/support/utils/CreationHelperTest",
                "test/sap/me/support/utils/SAEHelperTest",
                "test/sap/me/support/utils/PrefillHelperTest",
                "test/sap/me/support/utils/AaEPTest",
                "test/sap/me/support/utils/ServiceNowExpertChatTest",
                "test/sap/me/support/utils/ServiceMonitorTest",
                "test/sap/me/support/utils/engineerMemo/BaseActionTest",
                "test/sap/me/support/fragments/PriorityAndImpactBaseFragmentTest",
                "test/sap/me/support/fragments/PriorityAndImpactEditFragmentTest",
                "test/sap/me/support/fragments/PriorityAndImpactCreateFragmentTest",
                "test/sap/me/support/fragments/CreateSystemDialogTest",
                "test/sap/me/support/fragments/CreateReportAnIssueHeaderTest",
                "test/sap/me/support/fragments/CreateSelectCustomerOrSuserBaseDialogTest",
                "test/sap/me/support/fragments/CreateSelectSUserDialogTest",
                "test/sap/me/support/fragments/CreateSelectCustomerDialogTest",
                "test/sap/me/support/fragments/CreateNewServiceRequestDialogTest",
                "test/sap/me/support/fragments/ClosedServiceRequestDialogTest",
                "test/sap/me/support/fragments/RequestExtendedSupportDialogueTest",
                "test/sap/me/support/fragments/CreateSelectComponentDialogTest",
                "test/sap/me/support/fragments/CreateProductSelectDialogTest",
                "test/sap/me/support/fragments/CreateSelectProductFunctionDialogTest",
                "test/sap/me/support/fragments/CaseContactControllerTest",
                "test/sap/me/support/fragments/CaseContactCreationControllerTest",
                "test/sap/me/support/fragments/CaseContactEditControllerTest",
                "test/sap/me/support/fragments/ContactBaseValueHelpControllerTest",
                "test/sap/me/support/fragments/ContactListValueHelpControllerTest",
                "test/sap/me/support/fragments/ContactAddDialogValueHelpControllerTest",
                "test/sap/me/support/fragments/AddAttachmentsDialogTest",
                "test/sap/me/support/fragments/AnalyzeFilesDialogTest",
                "test/sap/me/support/fragments/CreateExistingDraftDialogTest",
                "test/sap/me/support/fragments/CaseCreationSACTest",
                "test/sap/me/support/fragments/CaseCreationChangeComponentDialogTest",
                "test/sap/me/support/model/formatterTest",
                "test/sap/me/support/utils/AdvancedJSONModelTest",
                "test/sap/me/support/cards/caseCreationCards/CaseCreationAppointmentInformationStepTest",
                "test/sap/me/support/cards/caseCreationCards/CaseCreationAttachmentStepTest",
                "test/sap/me/support/cards/caseCreationCardsTest/BasicInformationStepTest",
                "test/sap/me/support/cards/caseCreationCardsTest/SubmitStepTest",
                "test/sap/me/support/cards/caseCreationCardsTest/CaseCreationDetailedInformationStepTest",
                "test/sap/me/support/cards/caseCreationCardsTest/CaseCreationContactStepTest",
                "test/sap/me/support/cards/caseCreationCardsTest/BestActionStepTest",
                "test/sap/me/support/fragments/KBASelectSystemDialogTest",
                "test/sap/me/support/fragments/AppQRCodeDialogTest",
                "test/sap/me/support/cards/ActionPlansCardTest",
                "test/sap/me/support/cards/CaseAttachedSolutionsCardTest",
                "test/sap/me/support/cards/CaseAttachmentsCardTest",
                "test/sap/me/support/cards/CaseDiscussionCardTest",
                "test/sap/me/support/cards/ContactsSectionCardTest",
                "test/sap/me/support/cards/ServicesRequestsAdvancedCardTest",
                "test/sap/me/support/cards/ServicesRequestsOverviewCardTest",
                "test/sap/me/support/cards/ServiceCatalogCardTest",
                "test/sap/me/support/cards/SupportEngagementCardTest",
                "test/sap/me/support/cards/ECSWorkspaceCardTest",
                "test/sap/me/support/cards/CaseScheduleAnExpertCardTest",
                "test/sap/me/support/cards/CaseScheduleAManagerCardTest",
                // "test/sap/me/support/fragments/CaseDetailHeaderControllerTest",
                "test/sap/me/support/fragments/CaseDetailReplyDialogTest",
                "test/sap/me/support/fragments/caseDetail/CaseDetailInformationControllerTest",
                "test/sap/me/support/fragments/caseDetail/CaseDetailBusinessImpactCardTest",
                "test/sap/me/support/fragments/caseDetail/CaseDetailConnectionInformationCardTest",
                "test/sap/me/support/fragments/AddContactControllerTest",
                "test/sap/me/support/cards/caseCreationCardsTest/Step0Test",
                "test/sap/me/support/fragments/Step0SystemDialogTest",
                "test/sap/me/support/fragments/ProductKnowledgeCriticalDialogTest",
                "test/sap/me/support/fragments/CaseCreationExpertChatDialogTest",
                "test/sap/me/support/fragments/CaseCreationAribaQATest",
                "test/sap/me/support/cards/CaseKBASolutionsCardTest",
                "test/sap/me/support/cards/caseCreationCardsTest/CommunityStepTest",
                "test/sap/me/support/cards/PreventativeKBACardTest",
                "test/sap/me/support/cards/PrepackagedServicesCardTest",
            ]
        },

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,

        // start these browsers
        browsers: [browser],
        browserConsoleLogOptions: {
            level: "info",
            format: "%b %T: %m",
            terminal: false
        },

        // you can define custom flags
        customLaunchers: {
            ChromiumHeadlessLargeDesktop: {
                base: "ChromiumHeadless",
                flags: ["--disable-web-security", "--disable-site-isolation-trials", "--window-size=1440,1080", "--no-sandbox"]
            },
            ChromeDebugging: {
                base: "Chrome",
                flags: [
                    "--remote-debugging-port=9333",
                    "--auto-open-devtools-for-tabs"
                ]
            },
            ChromiumHeadlessGithub: {
                base: 'ChromeHeadless',
                flags: ['--no-sandbox']
            }
        },

        plugins: [
            require("karma-coverage"),
            require("karma-junit-reporter"),
            require("karma-spec-reporter"),
            require("karma-ui5"),
            require("karma-qunit"),
            require("karma-sinon"),
            require("karma-chrome-launcher")
        ],
        preprocessors: {
            "src/sap/me/support/cards/**/*.js": ["coverage"],
            "src/sap/me/support/fragments/**/*.js": ["coverage"]
        },
        coverageReporter: {
            includeAllSources: true,
            reporters: [
                {
                    type: "cobertura",
                    dir: "./target/jscoverage",
                    subdir: "/./",
                    file: "support-cobertura-coverage.xml"
                },
                {"type": "text"},
                {"type": "html"}
            ],

        },
        junitReporter: {
            outputDir: "./target/surefire-reports",
            outputFile: "support.unitTests.qunit.xml",
            suite: "",
            useBrowserName: false
        },
        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_ERROR,

        reporters: ["spec", "coverage", "junit"],
        specReporter: {
            maxLogLines: 300, // limit number of lines logged per test
            suppressFailed: false, // true is not print information about failed tests, not print the success test case when it is in github action pipeline
            suppressPassed: skipSuccessUTMessageInGithubAction, // true is not print information about passed tests, not print the success test case when it is in github action pipeline
            suppressSkipped: true, // true is not print information about skipped tests
            showSpecTiming: false // true is print the time elapsed for each spec
        },
        singleRun: bSingleRun,
        // https://karma-runner.github.io/6.4/config/configuration-file.html#browsernoactivitytimeout
        browserNoActivityTimeout: 40000
    });
};

sap.ui.define([
    "sap/ui/core/format/DateFormat",
    "sap/ui/core/LocaleData",
    "sap/ui/core/format/NumberFormat",
    "sap/ui/core/format/FileSizeFormat",
    "sap/ui/core/date/UI5Date"
], function(DateFormat, LocaleData, NumberFormat, FileSizeFormat, UI5Date) {
    "use strict";
    const i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
    let _oLocaleData = LocaleData.getInstance(sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale());

    const formatter = {

        formatInitials: function(sFirstName, sLastName) {
            if (typeof sFirstName !== "undefined"
                && typeof sLastName !== "undefined") {
                return sFirstName.charAt(0) + sLastName.charAt(0);
            }
            return "";
        },

        formatServiceRequestPointer: function(sPointer) {
            // the pointer has a general structure of [10 digit installation][10 digit message id][4 digit year] sometimes
            // it is specified only as [10 digit message id] (as known to customer), or [10 digit message id][4 digit year]
            // or (very seldom) the full pointer. this formatter reduces every format to only the message id
            if (sPointer) {
                if (sPointer.length > 10) {
                    // remove the four digit year (for formats {installation no}[message id][year])
                    sPointer = sPointer.substr(0, sPointer.length - 4);
                }

                if (sPointer.length > 10) {
                    // remove the ten digit installation number (for formats {installation no}[message id]{year})
                    sPointer = sPointer.substr(10);
                }
            }

            return sPointer;
        },

        formatDateTimeBasedOnPattern: function(sPattern) {
            return DateFormat.getDateTimeInstance({
                pattern: sPattern
            });
        },

        mediumDate: function(sDate) {
            let sDatePattern = _oLocaleData.getCombinedDateTimePattern("medium","medium"),
                dateFormat = formatter.formatDateTimeBasedOnPattern(sDatePattern);
            return sDate ? dateFormat.format(dateFormat.parse(sDate)) : String();
        },

        /**
         *
         * @param {string | Date} sDate current date
         * @param {boolean} toDate only parse to date not datetime
         * @returns
         */
        mediumDateFromDateNumberAndString: function(sDate, toDate = false) {
            if (!sDate) {
                return "";
            }
            // is date string
            if (Number.isNaN(Number(sDate))) {
                sDate = new Date(sDate);
            } else {
                sDate = new Date(Number(sDate));
            }
            let sDatePattern = toDate ? _oLocaleData.getDatePattern("medium") : _oLocaleData.getCombinedDateTimePattern("medium","medium"),
                dateFormat = formatter.formatDateTimeBasedOnPattern(sDatePattern);
            return sDate ? dateFormat.format(sDate) : String();
        },

        /**
         *
         * @param {*} sDate date
         * @param {*} sDatePattern parse pattern
         * @param {*} bUTC used by DateFormat.prototype.format()  default false
         * @returns
         */
        mediumDateFromUI5Date: function(sDate, sDatePattern, bUTC = false) {
            if (sDate) {
                sDate = UI5Date.getInstance(sDate);
                return formatter.formatDateTimeBasedOnPattern(sDatePattern).format(sDate, bUTC);
            }
            return "";
        },

        longDate: function(sDate) {
            let sDatePattern = _oLocaleData.getCombinedDateTimePattern("long","long"),
                dateFormat = formatter.formatDateTimeBasedOnPattern(sDatePattern);
            return sDate ? dateFormat.format(new Date(sDate)) : String();
        },

        longDateFromDateNumber: function(sDate) {
            let dateFormat = DateFormat.getDateTimeInstance({style: "long", UTC: false});
            return sDate ? dateFormat.format(new Date(Number(sDate))) : String();
        },

        shortDate: function(sDate) {
            let sDatePattern = _oLocaleData.getCombinedDateTimePattern("short","short"),
                dateFormat = formatter.formatDateTimeBasedOnPattern(sDatePattern);
            return sDate ? dateFormat.format(dateFormat.parse(sDate)) : String();
        },

        relativeDate: function(sDate) {
            let dateFormat = DateFormat.getDateTimeInstance({relative: "true"});
            return sDate ? dateFormat.format(dateFormat.parse(sDate)) : String();
        },

        customDate: function(sDate, sPattern) {
            if (sDate) {
                let dateFormat = formatter.formatDateTimeBasedOnPattern(sPattern), sISODate;
                sISODate = formatter.formatISODate(sDate);
                return dateFormat.format(new Date(sISODate));
            }
            return new String();
        },

        formatISODate: function(sDate) {
            if (sDate) {
                return sDate.substring(0,4) + "-" + sDate.substring(4,6) + "-" + sDate.substring(6,8) + "T" + sDate.substring(8,10) + ":" + sDate.substring(10,12) + ":" + sDate.substring(12,14);
            }
            return new String();
        },

        formatPhoneNumber: function(sPhone) {
            let sFormattedPhone = "";
            if (sPhone) {
                sFormattedPhone = [sPhone.slice(0, 3), "-", sPhone.slice(3)].join("");
            }
            return sFormattedPhone;
        },

        formatNullItem: function(item) {
            if (!item) {
                return "—";
            }
            return item;
        },

        formatServicePeriod: function(sStartDate, sEndDate) {
            let dateFormat = DateFormat.getDateInstance({pattern: "dd.MM.yyy"}), sPeriod = String();
            if (sStartDate && sEndDate) {
                sPeriod = i18n.getText("premiumEngagementCardDetailsFromLabel") + " " + dateFormat.format(new Date(Number(sStartDate))) + "  " + i18n.getText("premiumEngagementCardDetailsToLabel") + " " + dateFormat.format(new Date(Number(sEndDate)));
            } else if (sStartDate) {
                sPeriod = i18n.getText("premiumEngagementCardDetailsFromLabel") + " " + dateFormat.format(new Date(Number(sStartDate))) + "  " + i18n.getText("premiumEngagementCardDetailsToLabel") + " -";
            } else if (sEndDate) {
                sPeriod = i18n.getText("premiumEngagementCardDetailsFromLabel") + " - " + i18n.getText("premiumEngagementCardDetailsToLabel") + " " + dateFormat.format(new Date(Number(sEndDate)));
            } else {
                sPeriod = i18n.getText("premiumEngagementCardDetailsFromLabel") + " - " + i18n.getText("premiumEngagementCardDetailsToLabel") + " -";
            }
            return sPeriod;
        },

        formatOpenCapacityTitle: function(sTotalDays) {
            let sTotalDaysFormat = String();
            if (sTotalDays) {
                sTotalDaysFormat = i18n.getText("premiumEngagementCardDetailsOpenCapacityofLabel", [sTotalDays]);
            }
            return sTotalDaysFormat;
        },

        formatIncidentPointer: function(sPointer) {
            // the pointer has a general structure of [10 digit installation][10 digit message id][4 digit year] sometimes
            // it is specified only as [10 digit message id] (as known to customer), or [10 digit message id][4 digit year]
            // or (very seldom) the full pointer. this formatter reduces every format to only the message id
            if (sPointer) {
                //  uncomment the code bellow if you want to hide the year

                // if (sPointer.length > 10) {
                //     // remove the four digit year (for formats {installation no}[message id][year])
                //     sPointer = sPointer.substr(0, sPointer.length - 4);
                // }

                if (sPointer.length > 10) {
                    // remove the ten digit installation number (for formats {installation no}[message id]{year})
                    sPointer = sPointer.substr(10);
                }
            }

            return sPointer;
        },

        /**
         * if input is "yyyy-MM-dd HH:mm:ss" format, it should also be in local time zone, rather than UTC time zone
         * if input is a timestamp, it should be in UTC time zone, it would trans to local time zone When new Date(input)
         *
         * @param sDate
         * @return {string}
         */
        formatDateTime: function(sDate) {
            let dateFormat = DateFormat.getDateTimeInstance({style: "short", UTC: false});
            let dateFormated = dateFormat.format(new Date(new RegExp("\\d{13}").test(sDate) ? sDate * 1 : sDate));// "* 1" can convert String to number
            // var dateFormated = dateFormat.format(new Date(sDate.split(" ")[0] + "T" + sDate.split(" ")[1]));
            return dateFormated.replace(",", ` ${i18n.getText("action_plans_dateTimeConjunction")}`);
        },

        // Format number according to globally defined number format
        formatNumber: function(iNumber) {
            return NumberFormat.getIntegerInstance({groupingEnabled: true}).format(iNumber);
        },

        // Format short date according to globally defined date format
        formatShortDate: function(oDate) {
            return oDate ? DateFormat.getDateInstance({
                style: "short"
            }).format(oDate) : "";
        },

        // Format medium date according to globally defined date format
        formatMediumDate: function(oDate) {
            return DateFormat.getDateInstance({
                style: "medium"
            }).format(oDate);
        },

        getMediumDatePattern: function() {
            return sap.ui.getCore().getConfiguration().getFormatSettings().getDatePattern("medium");
        },

        // time:"2022-03-29T07:15:04"
        dateFormat: function(time) {
            return time ? sap.ui.core.format.DateFormat.getDateInstance({style: "short", UTC: false}).format(new Date(time)) : "";
        },

        /**
         * get attachment icon by file type
         * used in attachment list and add attachment dialog
         * @param {string} sFileType
         * @returns
         */
        formatAttachmentIcon: function(sFileType = "") {
            const type = sFileType.toLocaleLowerCase?.();
            switch (type) {
                case "png":
                case "jpeg":
                case "image/png":
                case "image/jpeg":
                    return "sap-icon://attachment-photo";
                case "pdf":
                case "application/pdf":
                    return "sap-icon://pdf-attachment";
                case "txt":
                    return "sap-icon://attachment-text-file";
                case "html":
                case "xml":
                    return "sap-icon://attachment-html";
                case "zip":
                    return "sap-icon://attachment-zip-file";
                case "mp4":
                case "avi":
                case "mov":
                case "wmv":
                    return "sap-icon://attachment-video";
                default:
                    return "sap-icon://attachment";
            }
        },

        /**
		 * Format the file size with the sap.ui.core.format.FileSizeFormat
         * */
        formatFileSize: function(nFileSize) {
            return FileSizeFormat.getInstance({
                maxFractionDigits: 1,
                maxIntegerDigits: 3,
                binaryFilesize: false
            }).format(nFileSize);
        },
        removeLeadingZero: function(parameter) {
            return parameter ? parameter.replace(/^0+/, "") : "";
        },

        /*
         * Decode the HTML entities, such as &lt; &gt; &amp;
         *
         * Refer to: https://stackoverflow.com/a/2419664/3074866
         *
         * @param  {String} sEncodedStr, the string to be decoded
         * @return {String}              the string after decode
         */
        fnDecodeEntities: function(sEncodedStr) {
            const oTextArea = document.createElement("textarea");
            oTextArea.innerHTML = sEncodedStr;
            return oTextArea.value;
        },

        /**
         * @desc format if analysis button can be shown
         * @param {*} oAnalysisStatus
         * @returns
         */
        formatAnalysisBtnStatus: function(nAnalysisStatus) {
            // status equals 7/8 means zip file has sub-file can be analyzed
            // status equals 9 means has generated pdf
            return (nAnalysisStatus > 0 && nAnalysisStatus < 5) || nAnalysisStatus === 7 || nAnalysisStatus === 8 || nAnalysisStatus === 9;
        },

        // set analyzable file icon color
        formatAnalysisIconColor: function(nAnalysisStatus) {
            return nAnalysisStatus === 9 ? "#949494" : "#0A6ED1";
        },

        // if 'analyze all' button can be click
        /**
         *
         * @param {array} aAnalyzableFiles can be analyzed files
         * @param {array} aUploadedFiles already generate pdf files
         * @returns
         */
        formatAnalysisAllBtnEnable: function(nAnalyzableFilesLength, nUploadedFilesLength) {
            return nAnalyzableFilesLength > 0 && nAnalyzableFilesLength > nUploadedFilesLength;
        },

        formatUTC2CET: function(sDate) {
            let localStartDate = new Date(sDate);
            let startTime = localStartDate.getTime();
            let offset = 60 * 60000; // CET is UTC + 60
            let startTimeInCET = startTime + offset;
            let cetStartDate = new Date(startTimeInCET);

            return cetStartDate.toString().substr(0, 25) + "(CET)";
        },

        formatExpertChatText: function(data) {
            let isAvailable = true;
            let expertChatText = "";
            // let expertChatConnectionText = "";
            let showConfirmMessage = false;
            const expectedAvailableTime = `<strong class="sapMeCreationBestActionExpertStrongText">${data.BUSINESSHOURFROM} - ${data.BUSINESSHOURTO} (${data.USERTIMEZONE ?? "UTC"})</strong>`;

            if (!data.ISWORKTIME) {
                expertChatText = i18n.getText("case_create_expert_channel_not_available", [expectedAvailableTime]);
                isAvailable = false;
                return {isAvailable, expertChatText, showConfirmMessage};
            }

            if (!data.DEPARTMENTID && !data.CHAT_QUEUE_ID) {
                expertChatText = i18n.getText("case_create_expert_channel_not_available_component");
                isAvailable = false;
                return {isAvailable, expertChatText, showConfirmMessage};
            }

            if (data.ISHOLIDAY) {
                expertChatText = i18n.getText("case_create_expert_channel_not_available_holiday");
                isAvailable = false;
                return {isAvailable, expertChatText, showConfirmMessage};
            }
            if (data.ISREGIONALQUEQUE && !data.COMPAVA) {
                isAvailable = false;
                expertChatText = `${i18n.getText("case_create_expert_channel_not_available_moment")} ${data.BUSINESSHOURFROM} - ${data.BUSINESSHOURTO} (${data.USERTIMEZONE ?? "UTC"})`;
                return {isAvailable, expertChatText, showConfirmMessage};
            }

            // No need this check for now
            // if (!data.ISREGIONALQUEQUE && !data.COMPAVA) {
            //     isAvailable = true;
            //     expertChatText = i18n.getText("case_create_expert_channel_expert_lack");
            //     expertChatConnectionText = i18n.getText("case_create_expert_channel_expert_connection_lack");
            //     return {isAvailable, expertChatText, showConfirmMessage, expertChatConnectionText};
            // }

            if (data.ESTOVERBUSINESS) {
                showConfirmMessage = true;
                expertChatText = `${i18n.getText("case_create_expert_channel_expected_wait_time")}<strong class="sapMeCreationBestActionExpertStrongText"> ${this.formatExpertChatTime(data.ESTWAITTIME)} ${i18n.getText("case_create_expert_channel_minutes")}</strong> ${i18n.getText("case_create_expert_channel_operation_time")} <strong class="sapMeCreationBestActionExpertStrongText">${data.BUSINESSHOURFROM - data.BUSINESSHOURTO} ${i18n.getText("case_create_expert_channel_hours")}</strong> ${i18n.getText("case_create_expert_channel_exceed_wait_time")}`;
                isAvailable = true;
                return {isAvailable, expertChatText, showConfirmMessage};
            }

            if (!data.ESTOVERBUSINESS) {
                isAvailable = true;
                if (data.ESTWAITTIME > 30) {
                    showConfirmMessage = true;
                }
                expertChatText = `${i18n.getText("case_create_expert_channel_expected_wait_time")}<strong class="sapMeCreationBestActionExpertStrongText"> ${this.formatExpertChatTime(data.ESTWAITTIME)} ${i18n.getText("case_create_expert_channel_minutes")}</strong>`;
                return {isAvailable, expertChatText, showConfirmMessage};
            }

            return {isAvailable, expertChatText, showConfirmMessage};
        },

        formatExpertChatTime : function(time) {
            let waitTimeText = "";
            if (time <= 2) {
                waitTimeText = `${i18n.getText("case_create_expert_channel_less_than")} 2`;
            } else if (time <= 5) {
                waitTimeText = "2 - 5";
            } else if (time <= 10) {
                waitTimeText = "5 - 10";
            } else if (time <= 15) {
                waitTimeText = "10 - 15";
            } else if (time <= 20) {
                waitTimeText = "15 - 20";
            } else if (time <= 30) {
                waitTimeText = "20 - 30";
            } else {
                waitTimeText = `${i18n.getText("case_create_expert_channel_more_than")} 30`;
            }
            return waitTimeText;
        },

        formatSystemDisplayName : function(sSystemName) {
            // A11 - => A11, A11 - XX => A11 - XX, A11 - (PROD) => A11 (PROD), A11 - XX (PROD) => A11 - XX (PROD)
            // remove en dash
            if (!sSystemName) {
                return;
            }
            const iEnDashIndex = sSystemName.indexOf("-");
            let iLeftBracketIndex = sSystemName.indexOf("(");
            iLeftBracketIndex = iLeftBracketIndex < 0 ? sSystemName.length : iLeftBracketIndex;
            if (iEnDashIndex < 0 || sSystemName.substring(iEnDashIndex + 1, iLeftBracketIndex).trim()) {
                return sSystemName;
            }
            const sPart2 = sSystemName.substring(iEnDashIndex + 1, sSystemName.length).trim();
            return sSystemName.substring(0, iEnDashIndex).trim() + (sPart2 ? " " + sPart2 : "");
        },

        /**
         * @param {Date | string} time
         * @param {string} cFormat
         * @param {boolean} default false
         * @returns {string}
         */
        transferDateFormating: function(time, cFormat, toLocal = false) {
            if (arguments.length === 0 || !time) {
                return null;
            }
            const format = cFormat || "{y}-{m}-{d} {h}:{i}:{s}.{a}";
            let date;
            let formatObj;
            if (typeof time === "object") {
                date = time;
            } else {
                date = new Date(time);
            }
            if (toLocal) {
                formatObj = {
                    y: date.getFullYear(),
                    m: date.getMonth() + 1,
                    d: date.getDate(),
                    h: date.getHours(),
                    i: date.getMinutes(),
                    s: date.getSeconds(),
                    a: date.getMilliseconds()
                };
            } else {
                formatObj = {
                    y: date.getUTCFullYear(),
                    m: date.getUTCMonth() + 1,
                    d: date.getUTCDate(),
                    h: date.getUTCHours(),
                    i: date.getUTCMinutes(),
                    s: date.getUTCSeconds(),
                    a: date.getUTCMilliseconds()
                };
            }
            const time_str = format.replace(/{([ymdhisa])+}/g, (result, key) => {
                const value = formatObj[key];
                // For milliseconds, length is 3
                // Others length is 2
                const padLength = key === "a" ? 3 : 2;
                return value.toString().padStart(padLength, "0");
            });
            return time_str;
        },


        // Escape special characters, such as ""~!@#$%^&";
        formatSpecialCharacter: function(content) {
            const shortText = encodeURI(encodeURIComponent(content));
            return shortText;
        },

        formatHtmlTag : function(sText) {
            if (!sText || "" === sText.trim()) {
                return "";
            }
            [
                ["<br\\s*(/){0,1}([a-zA-Z,-]+=\"[0-9]+\")*>", "\n"],
                ["<(/){0,1}[a-zA-Z]{1,10}>", ""]
            ].forEach(function(aItem) {
                let oReg = new RegExp(aItem[0],"gm");
                sText = sText.replace(oReg, aItem[1]);
            });
            return sText;
        },

        parseHtmlText: function(sText) {
            const domParser = new DOMParser();
            const domString = domParser.parseFromString(sText, "text/html");
            // recurse parse node
            this.recurseParseDomText(domString);
            return domString.querySelector("body").innerHTML;
        },

        /**
         * @param {*} el
         * @desc parse all html pure text '<' to '&lt;'
         * @result <<<<<12323<br> -----> &lt;&lt;&lt;&lt;&lt;12323<br>
         */
        recurseParseDomText: function(node) {
            if (node.hasChildNodes()) {
                for (let i = 0; i < node.childNodes.length; i++) {
                    // replace now node text <
                    if (node.childNodes[i].nodeName === "#text") {
                        node.childNodes[i].textContent = node.childNodes[i].textContent.replaceAll("<", "&lt;");
                    } else {
                        this.recurseParseDomText(node.childNodes[i]);
                    }
                }
            }
        },

        replaceHtmlTagsInText: function(sValue) {
            if (sValue) {
                return sValue.replaceAll("&quot;", "\"")
                    .replaceAll("&lt;", "<")
                    .replaceAll("&gt;", ">")
                    .replaceAll("&amp;", "&");
            }
            return sValue;
        },

        formatTimezoneList: function(sDescription, sUtcSign, utcDiff) {
            const utcHourDiff = +utcDiff.substring(2, 4);
            const utcMinsDiff = utcDiff.substring(5, 7);
            let postfix, prefix = "";
            switch (utcMinsDiff) {
                case "30":
                    postfix = ":30";
                    break;
                case "45":
                    postfix = ":45";
                    break;
                default:
                    postfix = ":00";
            }
            if (utcHourDiff < 10) {
                prefix = "0";
            }
            if (Number.isNaN(utcHourDiff)) {
                return sDescription;
            }

            return "(UTC " + sUtcSign + " " + prefix + Math.floor(utcHourDiff) + postfix + ") " + sDescription;
        },
        /**
        * get timezone offset milliseconds
        * @param {string} str like "PT13H00M00S"
        */
        getUTCStamp: function(str) {
            const hrs = str.substring(2, 4);
            const min = str.substring(5, 7);
            const sec = str.substring(8, 10);
            return (hrs * 60 * 60 + min * 60 + sec) * 1000;
        },

        formatFileAnalysisSolutionIconColor: function(oPriority) {
            switch (oPriority) {
                case 1:
                    return "Negative";
                case 2:
                    return "Critical";
                default:
                    return "Default";
            }
        },

        formatFileAnalysisSolutionIcon: function(oPriority) {
            switch (oPriority) {
                case 1:
                    return "sap-icon://message-error";
                case 2:
                    return "sap-icon://message-warning";
                default:
                    return "sap-icon://message-information";
            }
        },

        formatSystemLoginDetailsStatusText: function(sAccessDataError, bAccessDataAuthorized, bAccessDataMaintained) {
            if (sAccessDataError) {
                return "";
            }
            if (bAccessDataAuthorized) {
                if (bAccessDataMaintained) {
                    return i18n.getText("case_discussion_logon_details_maintained");
                }
                return i18n.getText("case_discussion_logon_details_missing");

            } else if (bAccessDataMaintained) { // Not authorized, but maintained
                return i18n.getText("case_discussion_loginDetailsMaintainedNoAuth");
            } // Not authorized, nor maintained
            return i18n.getText("case_discussion_loginDetailsMissingNoAuth");
        },

    };
    return formatter;
});

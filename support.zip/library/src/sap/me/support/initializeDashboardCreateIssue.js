sap.ui.define([
    "./library",
    "sap/ui/core/mvc/View",
    "sap/ui/core/mvc/Controller",
    "sap/me/shared/BackendException",
    "sap/me/shared/UnauthorizedException",
    "sap/me/shared/util/getShellComponent",
    "sap/me/shared/util/ElementMap",
    "sap/ui/core/library",
], function(library, View, Controller, BackendException, UnauthorizedException, getShellComponent, ElementMap) {
    "use strict";

    /**
     * This initialization module can be set in a dashboard / application definition and is loaded,
     * as soon as the dashboard / application definition is received for the first time. If multiple
     * dashboards have the same initialization module set, the module will only be loaded once. Thus
     * the coding of the module itself may only be executed once. In this case the module may return
     * any value, that will be ignored.
     *
     * Alternatively the module may return a function. This function will be called with the dashboard /
     * application definition, on every dashboard / application that is loaded. It can be used to run
     * any custom initialization logic. The function may change the provided definition at runtime, in
     * order to influence the dashboard / application. E.g. adding / removing / renaming sections
     * dynamically.
     *
     * Both the module itself, or the initialization function may return a promise. The dashboard /
     * application view will wait (either once if the module returns a promise, or for every loaded
     * dashboard / application) for the promise to resolve, before starting to load the content as it
     * the (changed) definition suggests.
     *
     * @function
     * @param {object} oDashboard The definition of the dashboard / application
     * @return {Promise<any>|any} A promise that resolves when the initialization is done
     * @private
     */
    return oDashboard => new Promise((fnResolve) => {

        this._oHeaderFragments = new ElementMap();

        // this initialization function can be used to change the dashboard / application definition at runtime
        // oDashboard.sections[0].title += ` (${Math.floor(Math.random() * 9) + 1})`;

        // in order to get access to functionalities from the shell, use:
        let oShellComponent = getShellComponent();
        if (oShellComponent) {
            // ...
        }

        if (oDashboard.name === "createIssue") {
            fnResolve();
        }


        // it can also be used, e.g. to perform asynchronous activities, like checking for authorizations or similar
        setTimeout(() => {


            // the promise should be resolved, to start loading the dashboard
            // fnResolve();
        }, 2e3);
    });
});
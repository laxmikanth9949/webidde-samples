/* !
 * ${copyright}
 */
sap.ui.define([
    "sap/ui/Global",
    "sap/me/cards/library",
    "sap/base/security/URLListValidator"
], function(Global, library, URLListValidator) {
    "use strict";
    // delegate further initialization of this library to the Core
    sap.ui.getCore().initLibrary({
        name: "sap.me.support",
        dependencies: ["sap.me.cards"],
        controls: [
            "sap.me.support.cards.CaseAttachmentsCard",
            "sap.me.support.cards.CaseCreationCard",
            "sap.me.support.cards.CaseDiscussionCard",
            "sap.me.support.cards.CaseKBASolutionsCard",
            "sap.me.support.cards.CaseScheduleAManagerCard",
            "sap.me.support.cards.CaseScheduleAnExpertCard",
            "sap.me.support.cards.ContactsSectionCard",
            "sap.me.support.cards.ECSWorkspaceCard",
            "sap.me.support.cards.EnterpriseSupportDetailsCard",
            "sap.me.support.cards.IncidentsAlertCard",
            "sap.me.support.cards.OverviewContractCard",
            "sap.me.support.cards.PreferredSuccessCard",
            "sap.me.support.cards.PremiumEngagementCard",
            "sap.me.support.cards.ServiceCatalogCard",
            "sap.me.support.cards.ServicesRequestsOverviewCard",
            "sap.me.support.cards.SupportEngagementCard",
            "sap.me.support.cards.IncidentsCard",
            "sap.me.support.cards.SupportNewsCard",
            "sap.me.support.cards.ServicesRequestsAdvancedCard",
            "sap.me.support.cards.RequestExtendedSupportEntranceCard",
            "sap.me.support.cards.CaseActionLogCard",
            "sap.me.support.cards.CaseActionLogCard",
            "sap.me.support.cards.caseDetailsPages.CaseDetailInformationCard",
            "sap.me.support.cards.caseDetailsPages.CaseDetailBusinessImpactCard",
            "sap.me.support.cards.ServiceDeliveryStatusCard",
            "sap.me.support.cards.PreventativeKBACard",
            "sap.me.support.cards.PrepackagedServicesCard"
        ],
        // in case your library comes without an own theming, remove the themes
        // folder and set this parameter to true, to stop looking for theme files
        noLibraryCSS: false
    });

    // add validate url
    // because launchpad test is not a safe url, <a> href attribute can't be parse
    URLListValidator.add("https", "supportshell-tnxd3nxr8c.dispatcher.int.sap.eu2.hana.ondemand.com");

    let thisLib = sap.me.support;

    return thisLib;
});

sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/core/Fragment",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/me/support/model/formatter",
    "sap/me/shared/Models",
    "../utils/Constants",
    "sap/ui/model/resource/ResourceModel",
    "../utils/helper",
    "sap/ui/core/routing/Router",
    "sap/me/support/utils/SaveMsgEventBus",
    "sap/base/util/uid",
    "sap/base/security/sanitizeHTML",
    "sap/me/shared/util/getShellComponent",
    "sap/me/support/utils/DetailPageCacheUtil",
], function(
    library,
    jQuery,
    CardComposite,
    deepEqual,
    Fragment,
    ODataModel,
    JSONModel,
    Filter,
    FilterOperator,
    MessageBox,
    formatter,
    SharedModels,
    Constants,
    ResourceModel,
    helper,
    Router,
    SaveMsgEventBus,
    uid,
    sanitizeHTML,
    getShellComponent,
    DetailPageCacheUtil,
) {
    "use strict";


    const translateLanguages = [
        {
            code: "NONE",
            text: "None",
            translateableFrom: []
        },
        {
            code: "en-US",
            text: "English",
            translateableFrom: ["NONE", "en-US", "de-DE", "zh-CN", "pt-BR", "es-ES", "ko-KR", "ja-JP", "fr-FR", "ru-RU", "it-IT"]
        },
        {
            code: "de-DE",
            text: "Deutsch",
            translateableFrom: ["de-DE", "NONE", "en-US"]
        },
        {
            code: "zh-CN",
            text: "中文",
            translateableFrom: ["zh-CN", "NONE", "en-US"]
        },
        {
            code: "pt-BR",
            text: "Portugues",
            translateableFrom: ["pt-BR", "NONE", "en-US"]
        },
        {
            code: "es-ES",
            text: "Español",
            translateableFrom: ["es-ES", "NONE", "en-US"]
        },
        {
            code: "ko-KR",
            text: "한국어",
            translateableFrom: ["ko-KR", "NONE", "en-US"]
        },
        {
            code: "ja-JP",
            text: "日本語",
            translateableFrom: ["ja-JP", "NONE", "en-US"]
        },
        {
            code: "fr-FR",
            text: "Français",
            translateableFrom: ["fr-FR", "NONE", "en-US"]
        },
        {
            code: "ru-RU",
            text: "Pусский",
            translateableFrom: ["ru-RU", "NONE", "en-US"]
        },
        {
            code: "it-IT",
            text: "Italiano",
            translateableFrom: ["it-IT", "NONE", "en-US"]
        }
    ];

    let CaseDiscussionCard = CardComposite.extend("sap.me.support.cards.CaseDiscussionCard", {
        metadata: {library: "sap.me.support"},
        _oBindingContext: null,
        formatter: formatter,
    });

    CaseDiscussionCard.prototype._overruleModel = new JSONModel({
        title: "",
        contentUpper: "",
        contentBottom: "",
        activeEnabled: false
    });

    CaseDiscussionCard.prototype.getShellComponent = getShellComponent;

    CaseDiscussionCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this._oEventBus = sap.ui.getCore().getEventBus();
        this.oCard = this.getCard();
        this.oCard.setHeader(null);
    };

    CaseDiscussionCard.prototype.onAfterRendering = function() {
        CardComposite.prototype.onAfterRendering.apply(this);
        this.isFirstTimeIn ? this.isFirstTimeIn = false : this._oODataModel.refresh();
    };

    CaseDiscussionCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setModel(this._oTLModel = new JSONModel(translateLanguages), "$" + this.alias + ".translateLanguages");
        oCard.setModel(this._oOLModel = new JSONModel({language: "en-US"}), "$" + this.alias + ".originalLanguage");
        this._oUserModel = SharedModels.getUserModel();
    };

    CaseDiscussionCard.prototype.setContext = async function(oContext) {
        this.isFirstTimeIn = true;
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        this._simulatedUser = oContext.user?.simulatedUser;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        // overrule model
        this.oCard.setModel(this._overruleModel, "overruleModel");
        this._pointer = `${oContext.attributes.caseKey}`;/* get pointer for submitReply*/

        this.setCacheModels();


        const sQueryParams = `?pointer=${oContext.attributes.caseKey}`;
        const oModel = new ODataModel({
            serviceUrl: `/backend/odata/support/${sQueryParams}`,
            synchronizationMode: "None",
            // for easier development
            groupId: "$direct",
            operationMode: "Server"

        });
        oModel.setSizeLimit(10000);
        this.oCard.setModel(this._oODataModel = oModel, "$" + this.alias + ".odata");

        // Recent Solutions
        let oRCModel = {};
        oRCModel.showResults = false;
        oRCModel.lastCommDate = "";
        oRCModel.lastCommUserName = "";
        this.oCard.setModel(this._oRCModel = new JSONModel(oRCModel), "$" + this.alias + ".recentSolutions");
        this.oCaseDiscussionList = this.byId("sapMeCaseDiscussionList");
        this.oCaseDiscussionList.getBinding("items").attachDataReceived((oEvent) => {
            if (oEvent.getParameters().data) {
                const oContexts = oEvent.getSource().getCurrentContexts();
                let iLastCommCust = 0;
                for (let j = oContexts.length - 1; j > 0; j--) {
                    if (!oContexts[j]?.getProperty("isSAPAgent")) {
                        iLastCommCust = j;
                    }
                }
                this._originalText = oContexts[0]?.getProperty("originalText");
                const sLastCommCustDatetime = oContexts[iLastCommCust].getProperty("dateTime");
                const sLastCommDatetime = oContexts[0].getProperty("dateTime");
                const sLastCommUserName = oContexts[0].getProperty("userName");
                let oLastDiscussion = oContexts[0];
                if (oLastDiscussion.getProperty("isSAPAgent") === true) {
                    const oListBinding = oModel.bindList("/CaseAttachedSolutions");
                    oListBinding.attachRefresh(() => {
                        oListBinding.getContexts();
                    });
                    oListBinding.refresh();
                    oListBinding.attachDataReceived((oEvent) => {
                        const oContexts = oEvent.getSource().getCurrentContexts();
                        if (oContexts.length) {
                            for (let i = 0; i < 2; i++) {
                                let sAttachedNoteCreation = oContexts[i].getObject().created_on;
                                if (sAttachedNoteCreation.includes("-") && sAttachedNoteCreation.includes(":") && sAttachedNoteCreation.includes(" ")) {
                                    sAttachedNoteCreation = sAttachedNoteCreation.split("-").join("").split(":").join("").split(" ").join("");
                                }
                                if (sAttachedNoteCreation > sLastCommCustDatetime) {
                                    if (!oRCModel.text1) {
                                        oRCModel.text1 = oContexts[i].getObject().type + " " + oContexts[i].getObject().ID;
                                        oRCModel.href1 = "/notes/" + oContexts[i].getObject().ID;
                                    } else {
                                        oRCModel.text2 = oContexts[i].getObject().type + " " + oContexts[i].getObject().ID;
                                        oRCModel.href2 = "/notes/" + oContexts[i].getObject().ID;
                                    }
                                }
                            }
                        }
                        if ((oRCModel.text1) || (oRCModel.text2)) {
                            oRCModel.showResults = true;
                        }
                        oRCModel.lastCommDate = sLastCommDatetime;
                        oRCModel.lastCommUserName = sLastCommUserName;
                        this.oCard.setModel(this._oRCModel = new JSONModel(oRCModel), "$" + this.alias + ".recentSolutions");
                    }, this);
                }
            }
        }, this);

        this._Router = Router.getRouter("shellRouter");
        // get permission to visable richtexteditor
        await helper.currentUserPermission(this._pointer,this);
        this._oEventBus.subscribe("sap.me.support.fragments.CaseDetailReplyDialog", "newReplied", () => {
            this._oODataModel.refresh();
        });
        this._oEventBus.subscribe("sap.me.support.cards.ContactsSectionCard", "contactChange", () => {
            // TODO add refresh flag and refresh model in onAfterRendering
            this._oODataModel.refresh();
        });
        this._oEventBus.subscribe("sap.me.support.fragments.AddAttachmentsDialog", "attachmentAdded", () => {
            // TODO add refresh flag and refresh model in onAfterRendering
            this._oODataModel.refresh();
        });
        this._oEventBus.subscribe("sap.me.support.fragments.CaseDetailHeaderController", "AaEPCaseUpdated", (oListener, identifier, params) => {
            this.updateAaEPCase(params);
        });

        return this;
    };

    CaseDiscussionCard.prototype.setCacheModels = function() {
        this.cacheDetailModel = DetailPageCacheUtil.getCacheDetailModel(this._pointer);
        this.oCard.setModel(this.cacheDetailModel, "CacheDetailModel");

        this.cacheConnectionModel = DetailPageCacheUtil.getCacheConnectionModel(this._pointer);
        this.oCard.setModel(this.cacheConnectionModel, "CacheConnectionModel");
    };

    /** ************************************************************************************** */
    /*                                         Event Handlers                                 */
    /** ************************************************************************************** */
    CaseDiscussionCard.prototype.updateAaEPCase = async function(params) {
        const componentInfo = await this.getComponentInfo(params.component);
        // K is "X" means the component is selectable
        if (componentInfo?.K !== "X") {
            return;
        }

        let longText = this._formatCaseDiscussionHtml(this._originalText);

        // replaced previous AaEP transcript
        longText = longText.replace(/\*\*\*Expert Peer Session Transcript.*/, "");
        longText += params.AaEPMessageText;

        const payload = {
            action: Constants.CASE_UPDATE_ACTION.SAVE,
            pointer: this._pointer,
            long_text: longText,
            status: Constants.CASE_STATUS.NOT_SENT_TO_SAP,
            draftFlag: Constants.DRAFT_CASE_FLAG.YES,
            component: componentInfo.CompKey,
            priority: params.priority,
            short_text: params.subject
        };
        await this.updateListRequest(payload);
        this._oODataModel.refresh();
    };

    CaseDiscussionCard.prototype.getComponentInfo = async function(component) {
        try {
            const result = await jQuery.ajax(`/backend/raw/support/CaseCreateCompProductSearchSetW7?$filter=CompName eq '${component}'`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
            });
            return result ? result[0] : {};
        } catch (e) {
            console.error("get component info fail");
        }
    };

    CaseDiscussionCard.prototype.updateListRequest = async function(data) {
        try {
            await jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify(data)
            });
        } catch (e) {
            console.error("update case fail");
        }
    };

    CaseDiscussionCard.prototype._onTranslatePress = function(oEvent) {
        const oTranslateButton = oEvent.getSource();
        this._oBindingContext = oTranslateButton.getBindingContext("$this.odata");
        if (!this._oTranslateView) {
            this._pTranslateViewPromise = Fragment.load({
                id: this._sCaseTranslateViewgId = (this.getId() + "-sCaseTranslateViewg"),
                name: "sap.me.support.fragments.CaseTranslateView",
                controller: this
            }).then(function(oTranslateView) {
                this.oCard.addDependent(oTranslateView);
                this._oTranslateView = oTranslateView;
                return oTranslateView;
            }.bind(this));
        }
        this._pTranslateViewPromise.then(oTranslateView => {
            // Original language based on currenly clicked entry
            this._oOLModel.setProperty("/language", this._oBindingContext.getProperty("sourceLanguage") || "NONE");
            oTranslateView.openBy(oTranslateButton).$().removeClass("sapUiSizeCompact");
        });
    };

    CaseDiscussionCard.prototype._onNavToTranslateFrom = function() {
        const oNavContainer = this._oTranslateView.getContent()[0];
        let caseDiscussionTranslateFromId = Fragment.byId(this._sCaseTranslateViewgId, "caseDiscussionTranslateFrom");
        oNavContainer.to(caseDiscussionTranslateFromId);
    };

    CaseDiscussionCard.prototype._onNavBack = function() {
        const oNavContainer = this._oTranslateView.getContent()[0];
        oNavContainer.back();
    };

    CaseDiscussionCard.prototype._onSearchTranslate = function(oEvent) {
        // add filter for search
        const aFilters = [];
        const sQuery = oEvent.getSource().getValue();
        if (sQuery && sQuery.length > 0) {
            const filter = new Filter("text", FilterOperator.Contains, sQuery);
            aFilters.push(filter);
        }
        // update list binding
        const oList = oEvent.getSource().$().closest(".sapMeCaseTranslatePage").find(".sapMeCaseTranslateList").control()[0];
        const oBinding = oList.getBinding("items");
        oBinding.filter(aFilters, "Application");
    };

    CaseDiscussionCard.prototype._onTranslateLanguageSelected = function(oEvent) {
        this._oTranslateView.close();

        const sTargetLanguage = oEvent.getSource().getBindingContext("$this.translateLanguages").getObject().code;
        // if language (Original) is selected, do not send the translation request
        this._oBindingContext.setProperty("selectedLanguage", sTargetLanguage, null);
        if (sTargetLanguage === this._oOLModel.getProperty("/language")) {
            // display the originalText
            this._oBindingContext.setProperty("translatedText", "", null);
            return;
        }

        this._sendTranslateRequest(sTargetLanguage);
    };

    // Select a Source Language
    CaseDiscussionCard.prototype._onTranslateFromLanguageSelected = function(oEvent) {
        this._oTranslateView.close();
        this._onNavBack();
        const sTranslateFromLanguageCode = oEvent.getSource().getBindingContext("$this.translateLanguages").getObject().code;
        // display the originalText
        this._oBindingContext.setProperty("translatedText", "", null);
        this._oBindingContext.setProperty("sourceLanguage", sTranslateFromLanguageCode, null);
        this._oOLModel.setProperty("/language", sTranslateFromLanguageCode);
    };

    CaseDiscussionCard.prototype._sendTranslateRequest = function(sTargetLanguage) {
        jQuery.ajax({
            url: "/backend/raw/support/Translate",
            type: "POST",
            data: JSON.stringify({
                sourceText: this._oBindingContext.getProperty("originalText"),
                sourceLanguage: this._oBindingContext.getProperty("sourceLanguage"),
                targetLanguage: sTargetLanguage
            }),
            dataType: "json",
            success: result => {
                if (result.targetText && result.targetLanguage) {
                    this._oBindingContext.setProperty("translatedText", result.targetText, null);
                }
            },
            error: e => {
                switch (e.status) {
                    case 400:
                        MessageBox.alert(`${this._i18n.getText("case_discussion_bad_request")}`);
                        break;
                    default:
                        MessageBox.alert(`${this._i18n.getText("case_discussion_internal_server_error")}`);
                        break;
                }
            }
        });
    };

    /** ************************************************************************************** */
    /*                                         Formatters                                     */
    /** ************************************************************************************** */

    CaseDiscussionCard.prototype._formatDateTime = function(sDate) {
        return sDate.replace(",", ` ${this._i18n.getText("case_discussion_dateTimeConjunction")}`);
    };

    CaseDiscussionCard.prototype._formatCaseDiscussionHtml = function(sTranslatedText, sOriginalText, sStyleClass) {
        let text = sTranslatedText || sOriginalText;
        const escapeMap = {
            "&lt;": "<",
            "&gt;": ">",
            "&amp;": "&",
            "&nbsp;": " ",
            "&#43;": "+",
            "&#39;": "'",
            "&cent;": "¢",
            "&pound;": "£",
            "&yen;": "¥",
            "&copy;": "©",
            "&reg;": "®",
            "&deg;": "°",
            "&mdash;": "—",
            "&radic;": "√",
            "&quot;": "\""
        };

        if (text.includes(Constants.SAP4MEP_PORTAL_SAYS_MSG)) {
            text = text.replace(/[\n]/g, "<br/>");
        }

        let html = this._removeUnsupportedThings(text);

        const context = this.oCard.getModel("$this.context")?.getData();
        if (context?.RespITSM === "BCP") {
            html = html.replace(/&\S+?;/g, function(str) {
                if (!escapeMap[str]) {
                    console.log(`Unsupported tag: ${str} Please add this tag to escapeMap`);
                }
                return escapeMap[str] || str;
            });
        } else {
            // sno case
            html = new DOMParser().parseFromString(html, "text/html").body.innerHTML;
        }

        const sanitizeOption = {
            uriRewriter: function(url) {
                return url;
            }
        };

        if (sStyleClass) {
            return sanitizeHTML(`<div class="${sStyleClass}">${html}</div>`, sanitizeOption);
        }
        return sanitizeHTML(`<div>${html}</div>`, sanitizeOption);
    };

    CaseDiscussionCard.prototype._removeUnsupportedThings = function(sText) {
        [
            "[code]", "[/code]", // SAP4METRANSFORMERS-476 why originalText is surrounded with [code] ?
            "[Code]","[/Code]"
        ].forEach(s => {
            sText = sText.replaceAll(s, "");
        });
        return sText;
    };

    // language (Original) is the original language except when source language is selected -> "Select a source language"
    CaseDiscussionCard.prototype._formatTranslateLanguageText = function(sText, sCode, sOriginalLanguage) {
        return sText + `${sCode === sOriginalLanguage ? ` (${this._i18n.getText("case_discussion_translateOriginal")})` : ""}`;
    };
    CaseDiscussionCard.prototype._recentSolVisibility = function(sActualCommDate, sActualCommUserName, sShow, sLastDate, sUname) {
        return (((sShow === true) && (sLastDate === sActualCommDate) && (sUname === sActualCommUserName)) ? true : false);
    };
    CaseDiscussionCard.prototype._singleSolVisibility = function(sId) {
        return (sId ? true : false);
    };

    CaseDiscussionCard.prototype._formatSystemLink = function(sSystemNumber) {
        return `/systemdata/view/${sSystemNumber}`;
    };

    CaseDiscussionCard.prototype._formatSystemInstallationLink = function(sInstallationNumber) {
        return `/installation/${sInstallationNumber}`;
    };

    CaseDiscussionCard.prototype._formatSystemRampUpFlag = function(RampUpFlag) {
        return RampUpFlag === "X" ? this._i18n.getText("yes") : "";
    };

    CaseDiscussionCard.prototype._formatDataProcessingVisibility = function(dataProtection) {
        return !!dataProtection && dataProtection !== "NONE";
    };

    /**
     *
     * @param { string } oDataProtection
     * @param { boolean } oOverruleAuth
     * @returns
     */
    CaseDiscussionCard.prototype._formatDataProcessingAct = function(oDataProtection, oOverruleAuth) {
        if (oDataProtection === "EUDP" || oDataProtection === "CNDP") {
            if (oOverruleAuth) {
                this._overruleModel.setProperty("/activeEnabled", true);
                return this._i18n.getText("case_discussion_dataProcessing_active");
            }
            this._overruleModel.setProperty("/activeEnabled", false);
            return this._i18n.getText("case_discussion_dataProcessing_active");
        }
        if (oDataProtection === "EMER") {
            this._overruleModel.setProperty("/activeEnabled", false);
            return this._i18n.getText("case_discussion_dataProcessing_deactived");
        }
        this._overruleModel.setProperty("/activeEnabled", false);
        return "";
    };

    CaseDiscussionCard.prototype._formatDataProcessing = function(oDataProtection) {
        switch (oDataProtection) {
            case "EUDP": return this._i18n.getText("case_discussion_eu_dataProcessing");
            case "CNDP": return this._i18n.getText("case_discussion_cn_dataProcessing");
            case "EMER": return this._i18n.getText("case_discussion_emer_dataProcessing");
            case "SCDP": return this._i18n.getText("case_discussion_scdp_dataProcessing");
            default: return "";
        }
    };

    CaseDiscussionCard.prototype._formatClassifiedContentVisibility = function(classifiedContentFromHeader, classifiedContentFromAllSystemInfo) {
        return classifiedContentFromHeader === "X" || classifiedContentFromAllSystemInfo === "X";
    };

    CaseDiscussionCard.prototype._formatTranslateLanguageVisibility = function(sCode, aTranslateableFrom) {
        return aTranslateableFrom.indexOf(sCode) > -1;
    };

    CaseDiscussionCard.prototype._formatUserName = function(sName, bIsSAPAgent, sType, isInitiallyMessage, sys_created_by) {
        if (isInitiallyMessage) {
            return this._formatInitiallyMessage(sName, bIsSAPAgent, sys_created_by);
        }
        if (bIsSAPAgent && sType === "u_problem_description") {
            return `${this._i18n.getText("case_discussion_u_sap_on_behalf_of")} ${sName}`;
        } else if (bIsSAPAgent) {
            return (this._i18n.getText("case_discussion_SAP_agent"));
        }
        if (sName && sName.length > 0) {
            return sName;
        }
        return sys_created_by ;

    };

    CaseDiscussionCard.prototype._formatInitiallyMessage = function(sName, bIsSAPAgent, sys_created_by) {
        const data = this.cacheDetailModel.getData();
        const reporterId = data?.reporterId ?? "";
        const creator = data?.creator ?? "";
        if (bIsSAPAgent || !creator) {
            return `${this._i18n.getText("case_discussion_u_sap_on_behalf_of")} ${sName}`;
        }
        if (creator.indexOf(reporterId) !== -1) {
            return sName;
        }
        if (creator.indexOf("ServiceNow") !== -1 && !bIsSAPAgent) {
            return `${sys_created_by} ${this._i18n.getText("case_discussion_u_on_behalf_of")} ${sName}`;
        }
        return `${creator} ${this._i18n.getText("case_discussion_u_on_behalf_of")} ${sName}`;
    };

    CaseDiscussionCard.prototype._formatTitle = function(sType) {

        switch (sType) {
            case "u_partner_info_to_customer":
                return this._i18n.getText("case_discussion_u_partner_info_to_customer");
            case "comments":
                return this._i18n.getText("case_discussion_u_comments");
            case "u_customer_comments":
                return this._i18n.getText("case_discussion_u_customer_comments");
            case "u_problem_description":
                return this._i18n.getText("case_discussion_u_problem_description");
            case "u_business_impact":
                return this._i18n.getText("case_discussion_u_business_impact");
            case "c_confirmation_request":
                return this._i18n.getText("case_discussion_u_confirmation_request");
            default:
                return sType;
        }
    };

    /**
     *
     * overrule login
     */
    CaseDiscussionCard.prototype._showOverrulePopUp = function(oEvent) {
        const source = oEvent.getSource();
        const dataProtection = source.getModel("CacheDetailModel").getData().dataProtection;
        this._setOverruleModel(dataProtection);
        if (!this._pPopover) {
            return Fragment.load({
                name: "sap.me.support.fragments.CaseOverrulePopUp",
                controller: this
            }).then(oPopover => {
                this._pPopover = oPopover;
                this.dataProtection = dataProtection;
                this.oCard.addDependent(oPopover);
                oPopover.openBy(source);
            });
        }
        this._pPopover.openBy(source);

    };

    CaseDiscussionCard.prototype._setOverruleModel = function(dataProtection) {
        const title = this._formatDataProcessing(dataProtection);
        this._overruleModel.setProperty("/title", title);
        this._overruleModel.setProperty("/contentBottom", this._i18n.getText("case_discussion_overrule_p2"));
        this._overruleModel.setProperty("/contentUpper", this._i18n.getText("case_discussion_overrule_p1", [this._formatTagByDataProtection(dataProtection)]));
    };

    CaseDiscussionCard.prototype._formatTagByDataProtection = function(dataProtection) {
        if (dataProtection === "EUDP") {
            return "EU";
        }
        if (dataProtection === "CNDP") {
            return "CN";
        }
        if (dataProtection === "EMER") {
            return "EU or CN";
        }
    };

    CaseDiscussionCard.prototype.avatarFormat = function(userName) {
        return typeof userName === "string" ? userName.replace(/\(\w+\)/, "").match(/\b\w/g)?.join("").substring(0, 2) : "";
    };

    CaseDiscussionCard.prototype._deactiveOverrule = function() {
        const tag = this._formatTagByDataProtection(this.dataProtection);
        const longText = `<p>${tag} Data Processing ${Constants.OVERRULE_SENT_PARA1}</p>${Constants.OVERRULE_DIVIDER}${Constants.OVERRULE_SENT_PARA2} ${tag} ${Constants.OVERRULE_SENT_PARA3}<br /><br />${Constants.OVERRULE_SENT_PARA4}`;
        const data = {
            action: "SEND2SAP",
            pointer: this._pointer,
            long_text: longText,
            u_data_protection: "EMER"
        };
        this._closeOverrulePopUp();
        // send update request
        return this.updateListRequest(data).then(() => {
            this._overruleModel.setProperty("/activeEnabled", false);
            this._oODataModel.refresh();
            // update case header status
            this._oEventBus.publish("sap.me.support.cards.CaseDiscussionCard", "overruleChange");
        }, () => {});
    };

    CaseDiscussionCard.prototype._formatMaintainDetailLink = function(sSystemNumber) {
        return `${Constants.PROD_SAP_FOR_ME}/seca/${sSystemNumber}/${this._pointer}`;
    };

    CaseDiscussionCard.prototype._closeOverrulePopUp = function() {
        this._pPopover.close();
    };

    return CaseDiscussionCard;
}, /* bExport= */true);

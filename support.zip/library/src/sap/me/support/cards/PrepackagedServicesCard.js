/**
 * @class
 * @name sap.me.support.cards.PrepackagedServicesCard
 */
sap.ui.define([
    "../library",
    "sap/me/cards/CardComposite",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/json/JSONModel",
    "sap/me/shared/Models",
    "sap/me/support/model/formatter",
    "sap/ui/core/format/DateFormat",
    "sap/me/support/utils/helper"
], function(library, CardComposite, ResourceModel, JSONModel, SharedModels, formatter, DateFormat, Helper) {
    "use strict";

    const PrepackagedServicesCard = CardComposite.extend("sap.me.support.cards.PrepackagedServicesCard", {
        library: "sap.me.support",
        formatter: formatter
    });

    PrepackagedServicesCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this.getEntitlements();
    };

    PrepackagedServicesCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setModel(this._packagedService = new JSONModel({
            allList: []
        }), "servicesList");
    };

    PrepackagedServicesCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        CardComposite.prototype.setContext.call(this, oContext, false);

        return this;
    };

    PrepackagedServicesCard.prototype.getEntitlements = async function() {
        const oCustomerModel = SharedModels.getCustomerModel();
        const crmcustomernumbers = oCustomerModel.getData()?.crmcustomernumbers || [];

        if (crmcustomernumbers.length === 0 && !Helper.isTrial) {
            return;
        }

        const data = await jQuery.ajax("/backend/raw/support/EmsFetchEntitlements", {
            method: "GET",
            data: {
                CustomerID: JSON.stringify(crmcustomernumbers.map(v => v.replace?.(/^0+/, "")))
            }
        });

        const result = data?.data?.entitlements?.map(item => {
            return {
                ...item,
                all_CallOffStatus: this._formatCallOffStatus(item.all_CallOffStatus),
                all_DeliveryStatus: this._formatDeliveryStatus(item.all_DeliveryStatus),
                ValidFromTo: this._formateServiceDate(item.ValidFrom) + " to " + this._formateServiceDate(item.ValidTo),
                all_LastCallOffDate: this._formateServiceDate(item.all_LastCallOffDate),
                all_RequestedDate: this._formateServiceDate(item.all_RequestedDate),
                all_ProjectedDate: this._formateServiceDate(item.all_ProjectedDate)
            };
        });
        this._packagedService.setProperty("/allList", result);
    };

    PrepackagedServicesCard.prototype.onSearchPrepackagedServices = function(oEvent) {
        const aFilters = [];
        const sQuery = oEvent.getParameter("query");
        const filtersArr = ["OriginationDocNo", "OfferingName", "all_CallOffStatus", "all_DeliveryStatus", "ValidFrom", "ValidTo", "all_RequestedDate",
            "all_ProjectedDate", "all_LastCallOffDate", "srv_ServiceReportLink", "GTA_ContactPersonIT", "ValidFromTo"];

        filtersArr.forEach(filterKey => {
            aFilters.push(new sap.ui.model.Filter(filterKey, sap.ui.model.FilterOperator.Contains, sQuery));
        });
        const queryFilter = new sap.ui.model.Filter({
            filters: aFilters,
            bAnd: false
        });
        const tableCard = this.byId("PrepackagedServicesCardTable");
        tableCard.getBinding("items").filter(queryFilter);
    };

    PrepackagedServicesCard.prototype._formatCallOffStatus = function(value) {
        switch (value) {
            case "Pending":
                return this._i18n.getText("prepackaged_services_card_pending");
            case "ToBeRequested":
                return this._i18n.getText("prepackaged_services_card_to_be_requested");
            case "Expired":
                return this._i18n.getText("prepackaged_services_card_expired");
            case "Initial":
                return this._i18n.getText("prepackaged_services_card_initial");
            case "Requested":
                return this._i18n.getText("prepackaged_services_card_requested");
            case "Completed":
                return this._i18n.getText("prepackaged_services_card_completed");
            default:
                return "-";
        }
    };

    PrepackagedServicesCard.prototype._formatDeliveryStatus = function(value) {
        switch (value) {
            case "Cancelled":
                return this._i18n.getText("prepackaged_services_card_cancelled");
            case "DeliveryInProgress":
                return this._i18n.getText("prepackaged_services_card_delivery_in_progress");
            case "Expired":
                return this._i18n.getText("prepackaged_services_card_expired");
            case "NotStarted":
                return this._i18n.getText("prepackaged_services_card_not_started");
            case "CallOffRequested":
                return this._i18n.getText("prepackaged_services_card_call_off_requested");
            case "DeliveryCompleted":
                return this._i18n.getText("prepackaged_services_card_completed");
            default:
                return "-";
        }
    };

    PrepackagedServicesCard.prototype._formateServiceDate = function(value) {
        if (!value || typeof value !== "string") {
            return "-";
        }
        const oDateFormat = DateFormat.getDateTimeInstance({pattern: "yyyyMMdd"});
        return DateFormat.getDateInstance({pattern: "MMM dd yyyy"}).format(oDateFormat.parse(value));
    };

    PrepackagedServicesCard.prototype._formateAvatarName = function(name) {
        return typeof name === "string" ? name.replace(/\(\w+\)/, "").match(/\b\w/g)?.join("").substring(0, 2) : "";
    };

    return PrepackagedServicesCard;
}, /* bExport= */true);

/**
 * @class
 * @name sap.me.support.cards.IncidentsCard
 */
sap.ui.define([
    "../library",
    "sap/me/cards/CardComposite",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/Sorter",
    "sap/me/support/model/formatter",
    "sap/base/util/deepEqual",
    "sap/ui/core/routing/Router",
    "sap/me/shared/Models",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/json/JSONModel"
], function(library, CardComposite, Filter, FilterOperator, Sorter, formatter, deepEqual, Router, SharedModels, ResourceModel, JSONModel) {
    "use strict";

    let IncidentsCard = CardComposite.extend("sap.me.support.cards.IncidentsCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: false, group: "Designtime"},
                growingThreshold: {type: "int", defaultValue: 10, group: "Designtime"},
                showRowCount: {type: "boolean", defaultValue: false, group: "Designtime"}
            }
        },
        formatter: formatter
    });

    IncidentsCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        this.oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
    };

    IncidentsCard.prototype.onAfterLegendContainerRendering = function(oEvent) {

        // The chart legend does not show reliably, therefore we check if the legend container has any content
        // If not, we provide the reference of the legend container to the VIZ chart once again

        // Does the container have content already?
        let bIsDOMContentFilled = (oEvent.getParameter("isPreservedDOM"));

        // If there is no content then provide the reference to the VIZ chart
        if (!bIsDOMContentFilled && this.getChart()) {
            this.getChart().setVizProperties({
                legendGroup: {
                    renderTo: function() {
                        return this.byId("chartLegend").$().get()[0];
                    }.bind(this)
                }
            });
        }
    };

    IncidentsCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext(), oCard = this.oCard;
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        // oCard.authorizationCheck(oContext.authorization, ["READM"], ["READM_INST"], ["ANLEG"], ["GOSAP"]);
        oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);
        oCard.filter(this._getTableFilters());
        // oCard.getTable().setVisible("{= ${$this>/intrinsicWidth} > ${$this.sizes>/M} }");
        oCard.getTable().bindProperty("visible", "{= ${$this>/intrinsicWidth} > ${$this.sizes>/M} }");

        this.byId("createIncident").setVisible(oContext.authorization.exists("ANLEG") || oContext.authorization.exists("GOSAP"));

        this.setModel(this._oODataModel = SharedModels.getODataModel("support"), "$this.odata");
        this.setModel(this._oODataModel.getMetaModel(), "$this.meta");

        this.updateChart();
        // create button enabled
        this.setModel(this._createCaseModel = new JSONModel({enabled: oContext.authorization.exists("ANLEG")}), "isCanCreateCase");

        return this;
    };

    IncidentsCard.prototype.getChart = function() {
        return this.byId("incidentsChart");
    };

    IncidentsCard.prototype.updateChart = function() {
        let oChart = this.getChart();
        if (oChart) {
            let oDataset = oChart.getDataset();
            oDataset.bindData({path: "$" + this.alias + ".odata>/IncidentsOverview", filters: this._getChartFilters()});
            oDataset.refreshData();
        }
    };

    IncidentsCard.prototype._getFilters = function() {
        let aFilter = [], oContext = this._oContext;

        if (oContext.dashboard.name === "productDetail") {
            let sProductKey = oContext.dashboard.attributes.productKey;
            if (sProductKey) {
                aFilter.push(new Filter({
                    path: "productKey",
                    operator: FilterOperator.EQ,
                    value1: sProductKey
                }));
            }
        }

        if (this.byId("incidentTypeButton").getSelectedKey() === "MyIncidents") {
            aFilter.push(new Filter({
                path: "reporter",
                operator: FilterOperator.EQ,
                value1: this._oContext.user.simulatedUser ? this._oContext.user.simulatedUser : this._oContext.user.userName
            }));
        }
        return aFilter;
    };

    IncidentsCard.prototype._getChartFilters = function() {
        return this._getFilters();
    };

    IncidentsCard.prototype._getTableFilters = function() {
        return this._getFilters().concat((this.getChart().vizSelection() || []).map(oSelection => {
            let sStatus = oSelection.data["Incident Status"], iBrace = sStatus.indexOf(" (");
            return iBrace > -1 ? sStatus.substr(0, iBrace) : sStatus;
        }).map(sStatus => new Filter({
            path: "status",
            operator: FilterOperator.EQ,
            value1: sStatus
        })));
    };

    IncidentsCard.prototype.updateFilters = function() {
        this.updateTableFilters();
        this.updateChart();
    };

    IncidentsCard.prototype.updateSorters = function(key) {
        if (key === "MyIncidents") {
            this.oCard.sort(new Sorter("statusKey", false));
        } else {
            this.oCard.sort(new Sorter("priorityKey", false));
        }
    };

    IncidentsCard.prototype.updateTableFilters = function() {
        this.oCard.setCustomFilters(this._getTableFilters());
    };

    // Get translated priority text for incident
    IncidentsCard.prototype._getIncidentsPriorityText = function(sPriorityKey) {
        switch (sPriorityKey) {
            case "1":
                return this._i18n.getText("incidents_priority_veryHigh");
            case "2":
                return this._i18n.getText("incidents_priority_high");
            case "3":
                return this._i18n.getText("incidents_priority_medium");
            case "4":
                return this._i18n.getText("incidents_priority_low");
            default:
                return this._i18n.getText("incidents_priority_none");
        }
    };

    IncidentsCard.prototype._getIncidentsPriorityState = function(sPriority) {
        switch (sPriority) {
            case "1":
                return "Error";
            case "2":
                return "Warning";
            case "3":
                return "Success";
            default:
                return "None";
        }
    };

    IncidentsCard.prototype.onCreateIncident = function() {
        Router.getRouter("shellRouter").navTo("application", {name: "casecreate"});
    };

    IncidentsCard.prototype.onManageIncidents = function() {
        Router.getRouter("shellRouter").navTo("application", {name: "caselist"});
    };

    IncidentsCard.prototype.onChoseIncidentType = function(oEvent) {

        const oItemBinding = this.oCard.getTable().getBinding("items");

        // Suspend the binding to prevent OData requests from immediately triggering
        oItemBinding.suspend();

        this.updateFilters();
        this.updateSorters(oEvent.getSource().getSelectedKey());

        // Once sort and filter is correctly set, the binding is resumed - this triggers a request
        oItemBinding.resume();
    };

    IncidentsCard.prototype.onSelectChartData = function() {
        this.updateTableFilters();
    };

    IncidentsCard.prototype.navigateToIncidentDetailPage = function(oEvent) {
        this.navigateToDetailPage(oEvent, "overview");
    };

    IncidentsCard.prototype.navigateToIncidentDetailPageOSLP = function(oPointer) {
        Router.getRouter("shellRouter").navTo("application", {
            name: "case",
            "rest*": encodeURIComponent(oPointer)
        });
    };

    IncidentsCard.prototype.navigateToDetailPage = function(oEvent, sTab) {
        let oItem = oEvent.getSource(),
            sSelectedIncidentId = encodeURIComponent(this.getSelectedIncident(oItem).incidentID),
            oRouter = Router.getRouter("shellRouter");

        oRouter.navTo("caseDetail", {
            caseKey: sSelectedIncidentId,
            section: sTab
        });
    };

    IncidentsCard.prototype.getSelectedIncident = function(oItem) {
        let oContext = oItem.getBindingContext("$" + this.alias + ".odata"),
            sPath = oContext.getPath(),
            oSelectedProduct = oContext.getObject(sPath);

        return oSelectedProduct;
    };
    return IncidentsCard;
}, /* bExport= */true);

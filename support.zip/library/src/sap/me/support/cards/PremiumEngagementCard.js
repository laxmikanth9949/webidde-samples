/**
 * @class
 * @name sap.me.support.cards.PremiumEngagementCard
 */
sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/base/util/deepEqual",
    "sap/ui/model/json/JSONModel",
    "../utils/Constants",
    "sap/me/support/model/formatter",
    "sap/ui/model/resource/ResourceModel"
], function(library, feLibrary, jQuery, CardComposite, ODataModel, deepEqual, JSONModel, Constants, formatter, ResourceModel) {
    "use strict";

    let mPremiumEngagement = {};

    // shortcut for sap.me.cards.CardState
    // var CardState = feLibrary.CardState;

    let PremiumEngagementCard = CardComposite.extend("sap.me.support.cards.PremiumEngagementCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                text: {type: "string", defaultValue: "Default Text"}
            }
        },
        formatter: formatter,
        _CONSTANTS: Constants
    });

    PremiumEngagementCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
    };

    PremiumEngagementCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setModel(this._oModel = new JSONModel({}), "$" + this.alias + ".model");
    };

    PremiumEngagementCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext(), oCard = this.oCard, sPremiumEngagement = "PremiumEngagement";
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);
        // var oBundle = sap.ui.getCore().getLibraryResourceBundle("sap.me.cards");
        // if (!oContext.authorization.check("READM", "READM_INST", "ANLEG", "GOSAP")) {
        //     oCard.setUnauthorizedMessage(oBundle.getText("unauthorizedMessage", oBundle.getText("authorizationREADM")));
        //     oCard.transitionToState(CardState.Unauthorized);
        // }
        if (!mPremiumEngagement[sPremiumEngagement]) {
            mPremiumEngagement[sPremiumEngagement] = jQuery.get(this._CONSTANTS.CONTRACT_DETAILS_MOCK);
        }
        mPremiumEngagement[sPremiumEngagement].then(oPremiumEngagement => {
            this._oModel.setData({
                PremiumEngagement: oPremiumEngagement,
                CONSTANTS: this._CONSTANTS
            });
            this.setModel(this._oModel, "$" + this.alias + ".model");
        });

        return this;
    };

    PremiumEngagementCard.prototype.handleDetailsCapacity = function(oEvent) {
        let sText = oEvent.getParameter("daysUsed") + " "
            + this._i18n.getText("premiumEngagementCardDetailsDaysUsedLabel") + " / "
            + oEvent.getParameter("daysAvailable") + " "
            + this._i18n.getText("premiumEngagementCardDetailsDaysAvailableLabel"),
            oCapacityResponsivePopover = this.getCapacityResponsivePopover(sText);
        oCapacityResponsivePopover.openBy(oEvent.getSource());
    };

    PremiumEngagementCard.prototype.handlePressDaysUsed = function(oEvent) {
        let sText = oEvent.getParameter("daysUsed") + " "
            + this._i18n.getText("premiumEngagementCardDetailsDaysUsedLabel"),
            oCapacityResponsivePopover = this.getCapacityResponsivePopover(sText);
        oCapacityResponsivePopover.openBy(oEvent.getSource());
    };

    PremiumEngagementCard.prototype.handlePressDaysAvailable = function(oEvent) {
        let sText = oEvent.getParameter("daysAvailable") + " "
            + this._i18n.getText("premiumEngagementCardDetailsDaysAvailableLabel"),
            oCapacityResponsivePopover = this.getCapacityResponsivePopover(sText);
        oCapacityResponsivePopover.openBy(oEvent.getSource());
    };

    PremiumEngagementCard.prototype.getCapacityResponsivePopover = function(sText) {
        let oCapacityResponsivePopover = new sap.m.ResponsivePopover({
            placement: "Bottom",
            showHeader: false,
            content: [
                new sap.m.VBox({
                    items: [
                        new sap.m.Text({
                            text: sText
                        })
                    ]
                }).addStyleClass("sapUiSmallMargin")
            ]
        }).addStyleClass("sapUiSmallMargin");
        this.oCard.addDependent(oCapacityResponsivePopover);
        return oCapacityResponsivePopover;
    };

    return PremiumEngagementCard;
}, /* bExport= */true);

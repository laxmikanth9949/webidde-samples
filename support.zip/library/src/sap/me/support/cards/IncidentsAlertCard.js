sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "jquery.sap.global",
    "sap/me/support/utils/helper",
    "sap/me/cards/CardComposite",
    "sap/ui/model/json/JSONModel",
    "../utils/Constants",
    "sap/me/support/model/formatter",
    "sap/base/util/deepEqual",
    "sap/ui/core/routing/Router",
    "sap/ui/model/resource/ResourceModel",
    "sap/me/shared/FeatureToggles"
], function(library, feLibrary, jQuery, helper, CardComposite, JSONModel, Constants, formatter, deepEqual, Router, ResourceModel, SharedFeatureToggles) {
    "use strict";

    let CardState = feLibrary.CardState;

    let IncidentsAlertCard = CardComposite.extend("sap.me.support.cards.IncidentsAlertCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: false, group: "Designtime"}
            }
        },
        formatter: formatter,
        _CONSTANTS: Constants
    });

    let mIncidentAlertCard = {};

    IncidentsAlertCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setModel(this._oModel = new JSONModel({
            CustomerContractType: null,
            IncidentsAlertCardVisibility: false,
            helper
        }), "$" + this.alias + ".odata");
    };

    IncidentsAlertCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this._oModeIncidentsAlertCard = new JSONModel({
            Visibility: null
        });
        this._oModeIncidentsAlertCard.setProperty("/Visibility", "REAL_CONTENT");
        this.oCard.setModel(this._oModeIncidentsAlertCard, "$" + this.alias + ".raw");
    };

    IncidentsAlertCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        let oTableIncidents = this.byId("incidentsAlertCard");
        let sIncidentsAlertCard = "IncidentsAlertCard";
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        // oTableIncidents.authorizationCheck(oContext.authorization, ["READM"], ["READM_INST"], ["ANLEG"], ["GOSAP"]);
        oTableIncidents.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);
        oTableIncidents.getTable().bindProperty("visible" ,"{= ${$this>/intrinsicWidth} > ${$this.sizes>/M} }");

        if (!mIncidentAlertCard[sIncidentsAlertCard]) {
            mIncidentAlertCard[sIncidentsAlertCard] = jQuery.get(this._CONSTANTS.SERVICE_REQUEST_MY_INCIDENTS_ALERTCARD);
        }

        mIncidentAlertCard[sIncidentsAlertCard].then(oResult => {
            this._oModel.setData({
                AllIncidents: oResult[0],
                MyIncidents: oResult[1],
                IncidentsAlertCard: oResult[2].incidents
            });
            oTableIncidents.setModel(this._oModel, "$" + this.alias + ".odata");
        });

        this.onTableVisibility();
        return this;
    };

    IncidentsAlertCard.prototype.updateTableFilters = function() {
        let oTableIncidents = this.byId("incidentsAlertCard");
        oTableIncidents.setCustomFilters(this._getTableFilters());
    };

    IncidentsAlertCard.prototype._getIncidentsRequestDeepLinkByID = function(sId) {
        if (sId) {
            if (helper.isDev === true || helper.isLocal === true || helper.isTest === true) {
                return this._CONSTANTS.SERVICE_REQUEST_TEST_DEEP_LINK + sId;
            }
            return this._CONSTANTS.SERVICE_REQUEST_OVERVIEW_DEEP_LINK + sId;

            // return this._CONSTANTS.SERVICE_REQUEST_OVERVIEW_DEEP_LINK + sId;
        }
        return "";

    };

    IncidentsAlertCard.prototype._getIncidentsPriorityState = function(sPriority) {
        switch (sPriority) {
            case "Very High":
                return "Error";
            case "High":
                return "Warning";
            case "Medium":
                return "Success";
            default:
                return "None";
        }
    };

    IncidentsAlertCard.prototype.onChoseIncidentType = function() {

        let sMyIncidentsCard = "MyIncidents";
        let sAllIncidentsCard = "AllIncidents";
        let oTableIncidents = this.byId("incidentsAlertCard");

        if (this.byId("incidentsAlertTypeButton").getSelectedKey() === "MyIncidents") {
            if (!mIncidentAlertCard[sMyIncidentsCard]) {
                mIncidentAlertCard[sMyIncidentsCard] = jQuery.get(this._CONSTANTS.SERVICE_REQUEST_MY_INCIDENTS_ALERTCARD);
            }
            mIncidentAlertCard[sMyIncidentsCard].then(oResult => {
                this._oModel.setData({
                    AllIncidents: oResult[0],
                    MyIncidents: oResult[1],
                    IncidentsAlertCard: oResult[2].incidents
                });
                this.onTableVisibility();
                oTableIncidents.setModel(this._oModel, "$" + this.alias + ".odata");
            });
        } else if (this.byId("incidentsAlertTypeButton").getSelectedKey() === "AllIncidents") {
            if (!mIncidentAlertCard[sAllIncidentsCard]) {
                mIncidentAlertCard[sAllIncidentsCard] = jQuery.get(this._CONSTANTS.SERVICE_REQUEST_ALL_INCIDENTS_ALERTCARD);
            }
            mIncidentAlertCard[sAllIncidentsCard].then(oResult => {
                this._oModel.setData({
                    AllIncidents: oResult[0],
                    MyIncidents: oResult[1],
                    IncidentsAlertCard: oResult[2].incidents
                });
                this.onTableVisibility();
                oTableIncidents.setModel(this._oModel, "$" + this.alias + ".odata");
            });
        }

    };

    IncidentsAlertCard.prototype.onTableVisibility = function() {
        let sIncidentsAlertCard = "IncidentsAlertCard";
        let cardVisible = false;

        mIncidentAlertCard[sIncidentsAlertCard].then(sIncidentsAlertCard => {
            this._oModel.setProperty("/CustomerContractType", sIncidentsAlertCard);
            cardVisible = (sIncidentsAlertCard[0].allIncidents === 0) ? false : true;
            this._oModel.setProperty("/IncidentsAlertCardVisibility", cardVisible);
        });
    };

    IncidentsAlertCard.prototype._onNavigateToDetailPage = function(oEvent) {
        const oContext = oEvent.getSource().getBindingContext("$" + this.alias + ".odata");
        const sPointer = oContext.getObject().pointer;

        Router.getRouter("shellRouter").navTo("caseDetail", {
            caseKey: encodeURIComponent(sPointer),
            section: "overview"
        });
    };

    IncidentsAlertCard.prototype.onCaseLinkPressed = function(oEvent) {
        const oContext = oEvent.getSource().getBindingContext("$" + this.alias + ".odata");
        const sPointer = oContext.getObject().pointer;

        Router.getRouter("shellRouter").navTo("application", {
            name: "case",
            "rest*": encodeURIComponent(sPointer)
        });
    };

    IncidentsAlertCard.prototype.onLinkPressed = function() {
        let sIncidentsAlertCard = "IncidentsAlertCard";
        mIncidentAlertCard[sIncidentsAlertCard].then(() => {
            if (helper.isTest) {
                Router.getRouter("shellRouter").navTo("application", {
                    name: "allcasestest"
                });
            } else if (helper.isDev || helper.isLocal) {
                Router.getRouter("shellRouter").navTo("application", {
                    name: "allcasesdev"
                });
            } else {
                Router.getRouter("shellRouter").navTo("application", {
                    name: "allcases"
                });
            }
        });

    };

    IncidentsAlertCard.prototype.changeTransitionToState = function(sCardState, isNoDataActive) {
        let oCardTable = this.byId("incidentsAlertCard"),
            oIncidentsAlertFooterCard = this.byId("incidentsAlertFooterCard"),
            oIncidentsAlertFooterNoDataCard = this.byId("incidentsAlertFooterNoDataCard"),
            oIncidentsAlertHeaderContentLeftCard = this.byId("incidentsAlertHeaderContentLeftCard"),
            oIncidentsAlertTypeButton = this.byId("incidentsAlertTypeButton");
        if (isNoDataActive) {
            oCardTable.setNoDataTitle(this._i18n.getText("incidentsAlert_descriptionNoDataTitle"));
            oCardTable.setNoDataImgUri("sap/me/cards/themes/base/img/error.svg");
            oCardTable.transitionToState(sCardState);
            oCardTable._getNoDataContent().setRenderType("Bare");
            oCardTable._getNoDataContent().addStyleClass("incidentsAlertNoDataContentVBoxCard");
            oCardTable._getNoDataContent().rerender();
            oIncidentsAlertFooterCard.setVisible(false);
            oIncidentsAlertHeaderContentLeftCard.setVisible(false);
            oIncidentsAlertTypeButton.setVisible(false);
            oIncidentsAlertFooterNoDataCard.setVisible(true);
            this._enableOnlyAboutCardItemMenu(true);
        } else {
            oCardTable.transitionToState(sCardState);
            oCardTable._getNoDataContent().setRenderType("Div");
            oCardTable._getNoDataContent().removeStyleClass("incidentsAlertNoDataContentVBoxCard");
            oCardTable._getNoDataContent().rerender();
            oIncidentsAlertFooterCard.setVisible(true);
            oIncidentsAlertHeaderContentLeftCard.setVisible(true);
            oIncidentsAlertTypeButton.setVisible(true);
            oIncidentsAlertFooterNoDataCard.setVisible(false);
            this._enableOnlyAboutCardItemMenu(false);
        }
    };

    IncidentsAlertCard.prototype._enableOnlyAboutCardItemMenu = function(bEnabled) {
        let oCardTable = this.byId("incidentsAlertCard");
        oCardTable.getHeader()?.getMenuItems().forEach(item => {
            if (item.getProperty("text").includes("What")) {
                item.setVisible(bEnabled);
            } else {
                item.setVisible(!bEnabled);
            }
        });
    };

    IncidentsAlertCard.prototype.onLinkPressedNoData = function() {
        Router.getRouter("shellRouter").navTo("application", {
            name: "caselist"
        });
    };

    IncidentsAlertCard.prototype.onUpdateFinished = function() {
        if (this._oModeIncidentsAlertCard.getProperty("/Visibility") === "REAL_CONTENT") {
            this.changeTransitionToState(CardState.Content, false);
        } else {
            this.changeTransitionToState(CardState.NoData, true);
        }
    };

    return IncidentsAlertCard;
}, /* bExport= */true);

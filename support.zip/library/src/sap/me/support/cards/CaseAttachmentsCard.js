sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/model/resource/ResourceModel",
    "sap/me/support/model/formatter",
    "sap/m/Button",
    "sap/me/support/fragments/AddAttachmentsDialog",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/utils/DetailPageCacheUtil",
], function(
    library,
    feLibrary,
    CardComposite,
    deepEqual,
    ODataModel,
    ResourceModel,
    formatter,
    Button,
    AddAttachmentsDialog,
    JSONModel,
    DetailPageCacheUtil,
) {
    "use strict";
    let CardState = feLibrary.CardState;
    let CaseAttachmentsCard = CardComposite.extend("sap.me.support.cards.CaseAttachmentsCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: true, group: "Designtime"},
                growingThreshold: {type: "int", defaultValue: 5, group: "Designtime"},
                showRowCount: {type: "boolean", defaultValue: true, group: "Designtime"}
            },
        },
        formatter: formatter
    });

    CaseAttachmentsCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
    };

    CaseAttachmentsCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setNoDataTitle(this._i18n.getText("attachments_emptyTitle"));
        oCard.setNoDataSubtitle(this._i18n.getText("attachments_emptySubtitle"));
        oCard.setNoDataImgUri("sap/me/support/resources/noAttachments.svg");
        oCard.setModel(this._oAttachmentModel = new JSONModel({
            icon: {src: "sIcon", color: "sBGColor"},
        }), "$this.attachment");
    };

    CaseAttachmentsCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        CardComposite.prototype.setContext.call(this, oContext, false);
        this.oPointer = oContext.attributes.caseKey;
        const sQueryParams = `?pointer=${this.oPointer}`;
        // mock data for e2e
        // const sQueryParams = "?pointer=002075125200000718642021";
        // const sQueryParams = "?pointer=002075125200001021592021";
        const oModel = new ODataModel({
            serviceUrl: `/backend/odata/support/${sQueryParams}`,
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        });

        this.oCard.setModel(this._oODataModel = oModel, "$" + this.alias + ".odata");
        const caseDetailData = DetailPageCacheUtil.getCacheDetailModel(this.oPointer)?.getData();
        if (caseDetailData) {
            this._oCaseDetail = caseDetailData;
            this._checkIsAttachmentBlocked();
        }
        DetailPageCacheUtil.attachCacheChange(this.oPointer, (data) => {
            this.handleCaseDetailChange(data.data);
        });
        return this;
    };

    /** ************************************************************************************** */
    /*                                      Event Handler                                     */
    /** ************************************************************************************** */
    CaseAttachmentsCard.prototype.handleCaseDetailChange = function(data) {
        if (!data) {
            return;
        }
        this._oCaseDetail = data;
        this._checkIsAttachmentBlocked();

        // jira S4M-5319
        this._oODataModel.refresh();
    };

    CaseAttachmentsCard.prototype.onUpdateFinished = function(oEvent) {
        this._iTotalCnt = oEvent.getParameter("total");
        if (this._oCaseDetail) {
            this._checkIsAttachmentBlocked();
        }
    };

    CaseAttachmentsCard.prototype.onAddAttachmentPressed = function() {
        if (!this._addAttachmentDialog) {
            this._addAttachmentDialog = new AddAttachmentsDialog(this);
        }
        this._addAttachmentDialog.open();
    };

    /** ************************************************************************************** */
    /*                                      private method                                    */
    /** ************************************************************************************** */
    CaseAttachmentsCard.prototype._checkIsAttachmentBlocked = async function() {
        // check user attachment display permission
        const sysN = this._oCaseDetail.systemNumber;
        const sysNumber = sysN?.substring(sysN.length - 10, sysN.length);
        const blockAttachmentsFlag = await this.getBlockFlag(this._oCaseDetail.customerNumber, this._oCaseDetail.installationNum, sysNumber);
        // if no, show the 'add attachments' button and the content list
        // and if no data returns, set CardState to NoData and keep the msg unchanged
        if (!blockAttachmentsFlag) {
            if (!!this._oCaseDetail.status && "18Z".indexOf(this._oCaseDetail.status) < 0) {
                this._insertAddAttachmentButton();
            } else if (this._addAttachmentButton) {
                this.getCard().getHeader().removeContentRight(this._addAttachmentButton);
            }
            if (this._iTotalCnt) {
                this.oCard.transitionToState(CardState.Content);
            } else {
                this.oCard.transitionToState(CardState.NoData);
            }
        } else {
            // if yes, show the warnings and hide the row count
            // reset the row count, forbidden the count display in card header
            this.oCard.setShowRowCount(false);
            this.oCard._setTitleWithRowCount();
            this.oCard.transitionToState(CardState.NoData);
            this.oCard.setNoDataTitle(this._i18n.getText("attachments_Blocked_Title"));
            this.oCard.setNoDataSubtitle(this._i18n.getText("attachments_Blocked_Subtitle"));
            this.oCard.setNoDataImgUri("sap/me/support/resources/attachmentBlocked.png");
        }
    };

    CaseAttachmentsCard.prototype.getBlockFlag = async function(customerNumber, installationNumber, systemNumber) {
        try {
            const result = await jQuery.ajax("/backend/raw/support/CaseMessageDSSW7Verticle", {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                data: {
                    customerId: customerNumber,
                    installationNumber: installationNumber,
                    sysNumber:systemNumber
                },
            });
            return result.blockAttachmentsFlag;
        } catch (e) {
            console.log("get block flag fail");
        }
    };

    CaseAttachmentsCard.prototype._insertAddAttachmentButton = function() {
        if (!this._addAttachmentButton) {
            this._addAttachmentButton = new Button({
                text: this._i18n.getText("attachments_add_attachment"),
                press: this.onAddAttachmentPressed.bind(this),
                icon: "sap-icon://attachment"
            }).addStyleClass("sapMeAddAttachmentBtn");
        }
        this.getCard().getHeader().insertContentRight(this._addAttachmentButton);
    };

    /** ************************************************************************************** */
    /*                                         Formatters                                     */
    /** ************************************************************************************** */

    CaseAttachmentsCard.prototype._isDescriptionAvailable = function(description) {
        // hidden default description
        if (!description) {
            return false;
        }
        const reg = /[A-Z]\d{10}\s-\s(([\s\S]*)[AP]M$)/;
        if (reg.test(description)) {
            return false;
        }

        return true;
    };

    CaseAttachmentsCard.prototype._formatDataProtection = function(dataProtection) {
        if (!dataProtection) {
            return;
        }
        if (dataProtection.indexOf("CN") !== -1) {
            return "CNDP";
        }
        if (dataProtection.indexOf("EU") !== -1) {
            return "EUDP";
        }
    };

    CaseAttachmentsCard.prototype._formatDataProtectionTooltip = function(dataProtection) {
        if (!dataProtection) {
            return;
        }
        if (dataProtection.indexOf("CN") !== -1) {
            return this._i18n.getText("attachments_attributesCNTooltip");
        }
        if (dataProtection.indexOf("EU") !== -1) {
            return this._i18n.getText("attachments_attributesEUTooltip");
        }
    };
    return CaseAttachmentsCard;
}, true);

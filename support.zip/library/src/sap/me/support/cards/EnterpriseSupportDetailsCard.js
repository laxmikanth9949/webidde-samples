/**
 * @class
 * @name sap.me.support.cards.EnterpriseSupportDetailsCard
 */
sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/json/JSONModel",
    "../utils/Constants",
    "sap/me/support/model/formatter",
    "sap/ui/model/resource/ResourceModel"
], function(library, feLibrary, jQuery, CardComposite, deepEqual, JSONModel, Constants, formatter, ResourceModel) {
    "use strict";

    let mEnterpriseSupport = {};

    // shortcut for sap.me.cards.CardState
    // var CardState = feLibrary.CardState;

    let EnterpriseSupportDetailsCard = CardComposite.extend("sap.me.support.cards.EnterpriseSupportDetailsCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                text: {type: "string", defaultValue: "Default Text"}
            }
        },
        formatter: formatter,
        _CONSTANTS: Constants
    });

    EnterpriseSupportDetailsCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
    };

    EnterpriseSupportDetailsCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setModel(this._oModel = new JSONModel({}), "$" + this.alias + ".model");
    };

    EnterpriseSupportDetailsCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext(), oCard = this.oCard, sEnterpriseSupport = "EnterpriseSupport";
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);
        // var oBundle = sap.ui.getCore().getLibraryResourceBundle("sap.me.cards");
        // if (!oContext.authorization.check("READM", "READM_INST", "ANLEG", "GOSAP")) {
        //     oCard.setUnauthorizedMessage(oBundle.getText("unauthorizedMessage", oBundle.getText("authorizationREADM")));
        //     oCard.transitionToState(CardState.Unauthorized);
        // }
        if (!mEnterpriseSupport[sEnterpriseSupport]) {
            mEnterpriseSupport[sEnterpriseSupport] = jQuery.get(this._CONSTANTS.CONTRACT_DETAILS_MOCK);
        }
        mEnterpriseSupport[sEnterpriseSupport].then(oPremiumEngagement => {
            this._oModel.setData({
                EnterpriseSupport: oPremiumEngagement
            });
            this.setModel(this._oModel, "$" + this.alias + ".model");
        });

        return this;
    };

    return EnterpriseSupportDetailsCard;
}, /* bExport= */true);

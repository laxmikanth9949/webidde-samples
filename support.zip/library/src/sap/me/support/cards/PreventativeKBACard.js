sap.ui.define([
    "sap/me/cards/CardComposite",
    "sap/me/support/model/formatter",
    "sap/base/util/deepEqual",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel",
    "sap/m/Image",
    "sap/m/Title",
    "sap/m/FormattedText",
    "sap/m/FlexBox",
    "sap/me/cards/library",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/me/support/fragments/SpecificNotesFilterDialog",
    "sap/me/support/utils/SystemNotesMonitorEvents",
    "sap/m/Button",
    "sap/m/ToolbarSpacer",
    "sap/m/IllustratedMessage",
    "sap/m/IllustratedMessageType",
    "sap/m/library",
    "sap/ui/export/library",
    "sap/m/MenuItem",
    "sap/ui/export/Spreadsheet",
    "sap/me/shared/FeatureToggles",
    "sap/m/MessageToast"
], function (CardComposite, formatter, deepEqual, JSONModel, ResourceModel, Image, Title, FormattedText, FlexBox, libraryForCardState, Filter, FilterOperator, SpecificNotesFilterDialog, SystemNotesMonitorEvents, Button, ToolbarSpacer, IllustratedMessage, IllustratedMessageType, sapLibrary, ExportLibrary, MenuItem, Spreadsheet, FeatureToggles, MessageToast) {
    "use strict";

    const currentViewStatus = {
        normal: "normal",
        errorMessage: "errorMessage",
        noSearchData: "noSearchData"
    };
    let PreventativeKBACard = CardComposite.extend("sap.me.support.cards.PreventativeKBACard", {
        library: "sap.me.support",
        formatter: formatter
    });

    PreventativeKBACard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        this._selectorHeaderInit();
        this._addExportExcelMenuButton(oCard);
    };

    PreventativeKBACard.prototype.onAfterRendering = function() {
        CardComposite.prototype.onAfterRendering.call(this);
        this._handleCardDisplayInfo();
    };

    PreventativeKBACard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        this._oSimulatedUser = oContext.user?.simulatedUser ?? "";
        this.swaServiceEvent = SystemNotesMonitorEvents.initConfig();
        this._filterDialog = new SpecificNotesFilterDialog(this);
        this._setCardNoDataText("","");
        this._initializeCardData();
        this._decideSoftwareColumnExist();
        //add click listener
        this.byId("MessageStripPreventativeCard").attachBrowserEvent("click", () => {
            this.onOpenFilterDialog();
        });
        this._feedbackInitCall();
    };

    PreventativeKBACard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this.oCard.setModel(this._oCardInfoModel = new JSONModel({
            isShow: true,
            text: "",
            softwareProductVisible: false,
            currentViewStatus: currentViewStatus.normal // errorMessage/noSearchData/normal
        }), "selectingInfo");
        this.oCard.setModel(this._oCardFilters = new JSONModel({
            componentFilters: [],
            componentSelectedKeys: [],
            softwareProFilters: [],
            softwareProSelectedKeys: [],
            typeFilters: [],
            typeSelectedKeys: []
        }), "$this.allFiltersList");
        this._oCardFilters.setSizeLimit(10000);
        this._oFilterValues = {
            oSearchText: "",
            oComponent: [],
            oType: [],
            oSoftwareProduct: []
        };
        //for request data
        this._oRequestParamsModel = new JSONModel({
            systemNumList: []
        });
        //for cache current display data
        this._oCurrentDataModel = [];
        //for cache show more data
        this._oShowMoreModel = {};
        //setModel when open filter dialog
        this._oCustomerDataModel = new JSONModel({
            allList: [],
            selectedCustomer: {}
        });
        //setModel when open system select dialog
        this._oSystemDataModel = new JSONModel({
            allList: [],
            favList: [],
            selectedSystemList: []
        });
        this._oSystemDataModel.setSizeLimit(10000);
        this._currentUseCustomer = {};
        this._favoriteProducts = [];
        this.oCard.setModel(this._oKbaNotesDisplayModel = new JSONModel({
            allList: []
        }), "kbaNotesDisplayList");
        this._oKbaNotesDisplayModel.setSizeLimit(50000);
        this._excelCacheData = [];
    };

    /** ************************************************************************************** */
    /**                                     Card functions                                     */
    /** ************************************************************************************** */

    /**
     * @description initialize card data
     *  1. should get all customer and update customer model and set default customer number from user settings
     *  2. should get all favorite system and update model and set default system number from user settings
     *  3. should send request to csm to get all notes
     *  Please do not alter the execution order of functions arbitrarily.
     */
    PreventativeKBACard.prototype._initializeCardData = async function() {
        const SUser = this.getCurrentSUser();
        this._setCardLoading(true);
        const cusList = await this.getAllCustomer(SUser);
        this.updateCustomerModel(cusList);
        const userSettings = await this._getUserSettings();
        this._handleCustomerInitSelect(cusList, userSettings);
        const systemResult = await this.getAllSystem(this._currentUseCustomer?.Name);
        this._handleSystemsInitSelect(systemResult, userSettings);
        try {
            this._favoriteProducts = await this.getFavProducts();
        } catch (e) {
            console.error("Error can not get favorite products: ", e);
        }
        if (this._checkIfInitRequestIsRequired()) {
            await this.fetchNotesWithProcessing();
        }
        this._setCardLoading(false);
    };

    /**
     * @description
     *  1. should check user settings systems value. if value is not empty then should use this value
     *  2. if user settings systems value is empty then should use favorite systems
     *  3. if favorite system over 10 items or empty then should show message which means call (_setCardNoDataText)
     */
    PreventativeKBACard.prototype._handleSystemsInitSelect = function(systemResult, userSettings) {
        const systemList = systemResult?.value ?? [];
        const favSystem = this._handleFavoriteSystems(systemList);
        const settings = userSettings["RECENTLY.PRECARDSELECTION"];
        let result = [];
        // handle user settings
        if (settings) {
            const settingsObj = JSON.parse(settings);
            if (settingsObj?.systems?.length > 0) {
                result = systemList.filter(item => settingsObj.systems.includes(item?.sysnr));
            }
        }
        // handle favorite systems
        if (result.length === 0) {
            if (favSystem.length > 10 || favSystem.length === 0) {
                this._setCardNoDataText(this._i18n.getText("noData_noSearchFavSystemFilterTitle"),this._i18n.getText("noData_noSearchFavSystemFilter"));
            } else {
                result = favSystem;
            }
        }
        // check if need to update Model
        if (result.length > 0) {
            this._oRequestParamsModel.setProperty("/systemNumList", result.map(item => item?.sysnr));
            this._oSystemDataModel.setProperty("/selectedSystemList", result.map(item => {
                return this.handleDifferentSystemObj(item);
            }));
        }
    };

    /**
     * @description return a common system object
     * @param system
     */
    PreventativeKBACard.prototype.handleDifferentSystemObj = function (system) {
        let result = {SystemName: "", SystemNum: "", Installation: "", leadingProduct: ""};
        result.SystemName = system?.sysid + "-" + system?.name;
        result.SystemNum = system?.sysnr;
        result.Installation = system?.installationNumber;
        result.leadingProduct = system?.officialProdName;
        return result;
    };


    PreventativeKBACard.prototype._handleFavoriteSystems = function(systemList) {
        let favList = [];
        if (systemList.length > 0) {
            favList = systemList.filter(item => item.isFavorite);
        }
        this._oSystemDataModel.setProperty("/favList", favList);
        return favList;
    };

    PreventativeKBACard.prototype._checkIfInitRequestIsRequired = function() {
        return this._oRequestParamsModel.getProperty("/systemNumList").length > 0 ? true : false;
    };


    /**
     * @description Query all systems based on user and customer
     * @param customerNum
     */
    PreventativeKBACard.prototype.getAllSystem = function (customerNum) {
        return jQuery.ajax(`/backend/odata/provisionsystemsgev/SimpleSystem?$filter=customerId eq '${customerNum}'&$format=json`, {
            method: "GET",
            contentType: "application/json"
        });
    };

    /**
     * @description Query all favorite products
     */
    PreventativeKBACard.prototype.getFavProducts = function() {
        return jQuery.ajax("/backend/odata/frontend/Favorites?$filter=type eq 'PRODUCTS'&$format=json", {
            method: "GET",
            contentType: "application/json"
        }).then(data => data?.value ?? []);
    };


    /**
     * @description
     *  1. should check user settings customer value. if value is not empty then should use this value
     *  2. if user settings customer value is empty then should use default customer
     */
    PreventativeKBACard.prototype._handleCustomerInitSelect = function(customerData, userSettings) {
        const settings = userSettings["RECENTLY.PRECARDSELECTION"];
        if (settings) {
            const settingsObj = JSON.parse(settings);
            if (settingsObj?.customer) {
                customerData.forEach(item => {
                    if (item.Name === settingsObj.customer) {
                        this._updateCurrentCustomer(item);
                    }
                });
                return;
            }
        }
        this.getDefaultCustomer(customerData);
    };

    /**
     * @description get all customers of the user
     * @param userId
     */
    PreventativeKBACard.prototype.getAllCustomer = function (userId) {
        return jQuery.ajax(`/backend/raw/support/CaseF4HelpW7Verticle?$filter=Uname eq '${userId}' and Type eq 'CUSTOMER'`, {
            method: "GET",
            contentType: "application/json"
        });
    };

    PreventativeKBACard.prototype._getUserSettings = function() {
        return jQuery.ajax("/backend/raw/common/Settings/RECENTLY");
    };

    /**
     * @description update customer data model
     * @param customerData
     */
    PreventativeKBACard.prototype.updateCustomerModel = function(customerData) {
        let result = customerData ?? [];
        this._tagFormatCustomerName(result);
        this._oCustomerDataModel.setProperty("/allList",result.filter(item => item?.Category === "ALL" && item?.Desc2 !== "SUPPORTED"));
    };

    /**
     * @description get current s-user customerId and set default request model
     * @param customerData
     */
    PreventativeKBACard.prototype.getDefaultCustomer = function(customerData) {
        let customer = {};
        customerData.forEach(item => {
            if (item?.Category === "ALL" && item?.Desc2 === "" && item?.Desc1 === "") {
                this._updateCurrentCustomer(item);
                customer = item;
            }
        });
        if (!customer?.Name) {
            customer = customerData[0];
            this._updateCurrentCustomer(customer);
        }
        return customer;
    };

    PreventativeKBACard.prototype.onOpenFilterDialog = function() {
        this._filterDialog?.open();
    };

    /**
     * @description update request system notes params customer number
     * @param customerNum
     */
    PreventativeKBACard.prototype._updateCurrentCustomer = function(customer) {
        this._currentUseCustomer = customer;
    };

    PreventativeKBACard.prototype._setCardLoading = function(flag) {
        this.oCard.getContent()?.setBusy(flag);
    };

    /**
     * @description set table no data text
     */
    PreventativeKBACard.prototype._setCardNoDataText = function(title, subTitle) {
        this.byId("sapMePreventativeList").setNoData(new FormattedText({htmlText: "<strong>" + title + "</strong>" + "\n" + subTitle}));
    };

    /**
     * @description set card no data text
     */
    PreventativeKBACard.prototype.handleCardNoDataView = function(notesList) {
        if (notesList?.length === 0) {
            this._setCardNoDataText(this._i18n.getText("system_specific_notes_card_service_no_data_title"),this._i18n.getText("system_specific_notes_card_service_no_data_subTitle"));
        } else {
            this._oCardInfoModel.setProperty("/currentViewStatus", currentViewStatus.normal);
        }
    };

    /**
     * @description handle card view if search data is empty then set Card view to NoSearch else set to Content
     * @param notesList
     */
    PreventativeKBACard.prototype.handleCardNoSearchView = function(notesCount) {
        if (notesCount === 0) {
            this._oCardInfoModel.setProperty("/currentViewStatus", currentViewStatus.noSearchData);
        } else {
            this._oCardInfoModel.setProperty("/currentViewStatus", currentViewStatus.normal);
        }
    };

    PreventativeKBACard.prototype._decideSoftwareColumnExist = function() {
        if (FeatureToggles.get("feature-support-predictive-software-product")) {
            this._oCardInfoModel.setProperty("/softwareProductVisible", true);
        }
    };

    /**
     * @description if current user is simulated then return simulate s-user
     * @return string S-user
     */
    PreventativeKBACard.prototype.getCurrentSUser = function() {
        return this._oContext?.user?.simulatedUser ?? this._oContext?.user?.userName;
    };

    /**
     * @description card header display current filter system info
     */
    PreventativeKBACard.prototype._handleCardDisplayInfo = function() {
        const systems = this._oSystemDataModel.getProperty("/selectedSystemList");
        // handle visible of card filter info
        this._oCardInfoModel.setProperty("/isShow", true);
        // handle display text
        const systemTextArr = systems.map(item => {
            return item.SystemName;
        });
        this._oCardInfoModel.setProperty("/text", `Filtered By: ${systemTextArr.join(", ")}`);
    };

    /**
     * @description send request to csm for get system notes
     * @param systemNumList
     */
    PreventativeKBACard.prototype.sendSystemNotesRequests = function (systemNumList) {
        return jQuery.ajax("/backend/raw/support/MultiSystemSpecificNotes", {
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                system_numbers: systemNumList,
                config: {
                    integrations: {
                        hot_trending: "True"
                    }
                },
                s_user_favorites: this.generateFavThings()
            })
        });
    };

    /**
     * @description generate favorites systems and products struct
     */
    PreventativeKBACard.prototype.generateFavThings = function () {
        const systems = this._oSystemDataModel.getProperty("/favList").map(item => {
            return {id: item?.sysnr, name: `${item?.sysid} - ${item?.name}(${item?.sysrole})`};
        });
        const products = this._favoriteProducts.map(item => {
            return {id: item?.ID, name: item?.text};
        });
        return {
            s_user: this.getCurrentSUser(),
            system_favorites: systems,
            product_favorites: products
        };
    };

    /**
     * @description get all notes of a system and process data
     */
    PreventativeKBACard.prototype.fetchNotesWithProcessing = function() {
        const systemList = this._oRequestParamsModel.getProperty("/systemNumList");
        this._setCardLoading(true);
        return this.sendSystemNotesRequests(systemList).then(result => {
            this.processResponse(result);
        }).catch(error => {
            this.processFailedResponse(error);
        }).always(() => {
            this._handleCardDisplayInfo();
            this._setCardLoading(false);
            this._setUserSettings(this._generateSelectionData());
        });
    };

    /**
     * @description process notes result
     * @param notesList
     */
    PreventativeKBACard.prototype.processResponse = function(notesObj) {
        let notesList = this._assembledData(notesObj);
        notesList = this.handleUpdateData(notesList);
        this.updateDisplayNotesList(notesList);
        this.handleCardFilters(notesList);
        this.handleCardNoDataView(notesList);
    };

    /**
     * @description should update _oKbaNotesDisplayModel
     * @return the data for display
     */
    PreventativeKBACard.prototype.updateDisplayNotesList = function(notesList) {
        if (notesList.length > 0) {
            let groupObj = this._notesGroupBySystem(notesList);
            const keys = Object.keys(groupObj);
            const result = keys.map(item => {
                return {
                    name: groupObj[item][0].systemName,
                    key: groupObj[item][0].systemFullNum,
                    buttonText: this._i18n.getText("system_specific_notes_card_show_more"),
                    isShowButton: this._oShowMoreModel[item]?.length > 0,
                    count: groupObj[item].length,
                    notesItems: groupObj[item],
                    noDataText: this._i18n.getText("system_specific_notes_card_service_no_filter_title")
                };
            });
            const emptyDataResult = this._handleNoReturnKBAShowListBySystem(keys);
            this._oKbaNotesDisplayModel.setProperty("/allList", result.concat(emptyDataResult));
            this._setFirstPanelOpen();
        }
    };

    /**
     * @description should generate show list for system which don't have kba notes
     */
    PreventativeKBACard.prototype._handleNoReturnKBAShowListBySystem = function(systemShowList) {
        let result = [];
        const selectedSystems = this._oSystemDataModel.getProperty("/selectedSystemList");
        const noKBASystems = selectedSystems.filter(item => systemShowList.indexOf(item?.SystemNum) === -1);
        if (noKBASystems.length > 0) {
            result = noKBASystems.map(item => {
                return {
                    name: item.SystemName,
                    key: item.SystemNum,
                    buttonText: "",
                    isShowButton: false,
                    count: 0,
                    notesItems: [],
                    noDataText: "<strong>" + this._i18n.getText("system_specific_notes_card_service_no_data_title_table") + "</strong>" + "\n" + this._i18n.getText("system_specific_notes_card_service_no_data_subTitle_table")
                };
            });
        }
        return result;
    };

    /**
     * @description should update _oCurrentDataModel
     * @return the data for filter
     */
    PreventativeKBACard.prototype.handleUpdateData = function(notesList) {
        if (notesList.length === 0) {
            this._oKbaNotesDisplayModel.setProperty("/allList", []);
            return notesList;
        }
        this._splitDataByRules(notesList);
        let currentList = this._oCurrentDataModel
        const keys = Object.keys(this._oShowMoreModel);
        let result = [];
        keys.forEach(item => {
            result.push(...this._oShowMoreModel[item]?.splice(0,5) || []);
        });
        result = currentList.concat(result);
        this._oCurrentDataModel = result
        return result;
    };

    /**
     * @description should split data for different use
     * first time get notes list then should set all preventative notes to _oShowMoreModel
     * @param notesList
     */
    PreventativeKBACard.prototype._splitDataByRules = function(notesList) {
        const nList = notesList ?? [];
        if (nList.length === 0) return;
        this._oCurrentDataModel = notesList.filter(item => JSON.stringify(item?.pred_type)?.indexOf("Preventative") === -1);
        this._oShowMoreModel = this._notesGroupBySystem(nList.filter(item => JSON.stringify(item?.pred_type)?.indexOf("Preventative") !== -1));
    };

    /**
     * @description  notes list group by system
     * @param notesList
     */
    PreventativeKBACard.prototype._notesGroupBySystem = function(notesList) {
        const nList = notesList ?? [];
        let result = {};
        if (nList.length === 0) return result;
        nList.forEach(item => {
            if (result.hasOwnProperty(item.systemFullNum)) {
                result[item.systemFullNum].push(item);
            } else {
                result[item.systemFullNum] = [item];
            }
        });
        return result;
    };

    /**
     * @description should assemble result as list
     * @param notesObj
     */
    PreventativeKBACard.prototype._assembledData = function(notesObj) {
        const keys = Object.keys(notesObj);
        let result = [];
        // take out the notesFeedback and set value to allList model
        keys.forEach(item => {
            result = result.concat(this._tagSystemsInfoForNotesItems(item, notesObj[item], this.feedbackMap));
        });
        return result;
    };

    /**
     * @description get kba like or dislike from localstorage
     */
    PreventativeKBACard.prototype._feedbackInitCall = function() {
        this.feedbackMap = {};
        this._notesFeedback = JSON.parse(localStorage.getItem("s4mSupportSpecificCardNotesThumbFlag")) || [];
        if (this._notesFeedback.length) {
            this._notesFeedback.forEach(note => {
                this.feedbackMap[note.kmnumber] = note.feedback_score;
            });
        }
    };

    /**
     * @description add new property system name and system number for each notes item and tag feedback_score from localstorage
     * @param systemNum
     * @param notesList
     */
    PreventativeKBACard.prototype._tagSystemsInfoForNotesItems = function(systemNum, notesList, feedbackMap) {
        if (!notesList) {
            return;
        }
        const system = this._oSystemDataModel.getProperty("/selectedSystemList").find(item => item?.SystemNum === systemNum);
        const systemDisplayNum = this.removeZeroBeforeSystem(system?.SystemNum);
        let preIndex = 1;

        notesList.forEach((item, index) => {
            item.systemName = system?.SystemName;
            item.systemDisplayNum = systemDisplayNum;
            item.systemFullNum = system?.SystemNum;
            item.overAllIndex = index + 1;
            if (feedbackMap.hasOwnProperty(item.kmnumber)) {
                item.feedback_score = feedbackMap[item.kmnumber];
            } else {
                item.feedback_score = 0;
            }
            if (item.pred_type?.includes?.("Preventative")) {
                item.preIndex = preIndex;
                preIndex++;
            }
        });
        return notesList;
    };

    /**
     * @description process notes error result
     * @param errorText
     */
    PreventativeKBACard.prototype.processFailedResponse = function(errorText) {
        this._oCardInfoModel.setProperty("/currentViewStatus", currentViewStatus.errorMessage);
    };

    PreventativeKBACard.prototype._generateSelectionData = function() {
        const customerNum = this._currentUseCustomer?.Name ?? "";
        const systemList = this._oRequestParamsModel.getProperty("/systemNumList");
        return {customer: customerNum, systems: systemList};
    };

    PreventativeKBACard.prototype._setUserSettings = function(customResult) {
        jQuery.ajax("/backend/raw/common/Settings", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({"RECENTLY.PRECARDSELECTION": JSON.stringify(customResult)}),
        });
    };

    PreventativeKBACard.prototype.onTableButtonPress = function(oEvent, buttonText) {
        switch (buttonText) {
            case this._i18n.getText("system_specific_notes_card_show_more"):
                this.onShowMorePress(oEvent);
                break;
            case this._i18n.getText("system_specific_notes_card_show_less"):
                this.onShowLessPress(oEvent);
                break;
        }
    };

    PreventativeKBACard.prototype.onShowLessPress = function(oEvent) {
        const systemKey = oEvent.getSource().getBindingContext("kbaNotesDisplayList").getObject()?.key ?? "";
        this._oKbaNotesDisplayModel.aBindings.filter(v => v.sPath === "notesItems").forEach((item,index) => {
            if (item.oModel.getProperty(`/allList/${index}/key`) === systemKey) {
                const notes = item.oModel.getProperty(`/allList/${index}/notesItems`);
                const nKbaList = notes.filter(item => JSON.stringify(item?.pred_type)?.indexOf("Preventative") === -1);
                const pKbaList = notes.filter(item => JSON.stringify(item?.pred_type)?.indexOf("Preventative") !== -1);
                let result = nKbaList.concat(pKbaList.splice(0,5));
                this._oShowMoreModel[systemKey] = pKbaList;
                this._oCurrentDataModel = this._oCurrentDataModel.filter(cNotes => pKbaList.indexOf(cNotes) === -1);
                this.handleCardFilters(this._oCurrentDataModel);
                item.oModel.setProperty(`/allList/${index}/notesItems`, result);
                item.oModel.setProperty(`/allList/${index}/count`, item.getCount());
                item.oModel.setProperty(`/allList/${index}/buttonText`, this._i18n.getText("system_specific_notes_card_show_more"));
            }
        });
    };

    PreventativeKBACard.prototype.onShowMorePress = function(oEvent) {
        const systemKey = oEvent.getSource().getBindingContext("kbaNotesDisplayList").getObject()?.key ?? "";
        //get 10 or less kba notes
        //When there is no filter set, ‘Show More’ button should still show 5 + 5, not 10 together. Right? [Eddie/David/Jorge] How about we just have one click and show the additional 10, rather than 5 and then another 5. So when the user click “Show More Preventative KBAs” it will show 10.
        const moreKBAList = this._oShowMoreModel[systemKey]?.splice(0,10);
        this._oCurrentDataModel = this._oCurrentDataModel.concat(moreKBAList);
        this.handleCardFilters(this._oCurrentDataModel);
        this._oKbaNotesDisplayModel.aBindings.filter(v => v.sPath === "notesItems").forEach((item,index) => {
            //1.find items and add items  2.filter again  3.set count again
            if (item.oModel.getProperty(`/allList/${index}/key`) === systemKey) {
                //before filter count
                const bFilterNum = item.getCount();
                const aFilters = this.getAllFilters();
                item.oModel.setProperty(`/allList/${index}/notesItems`, item.oModel.getProperty(`/allList/${index}/notesItems`).concat(moreKBAList));
                item.filter(aFilters);
                //after filter count
                const aFilterNum = item.getCount();
                if (aFilters.length > 0) {
                    this._popUpMessageWhenFilterNotMatch(bFilterNum, aFilterNum);
                }
                item.oModel.setProperty(`/allList/${index}/count`, aFilterNum);
                //when all cache data loaded then show more button text change to show less text
                if (this._oShowMoreModel[systemKey]?.length === 0) {
                    item.oModel.setProperty(`/allList/${index}/buttonText`, this._i18n.getText("system_specific_notes_card_show_less"));
                    // show less button won't display in filter mode
                    if (aFilters.length > 0) {
                        item.oModel.setProperty(`/allList/${index}/isShowButton`,false);
                        //Eddie: If the only filter set is “Type = Preventative”, can we show the “Show Less”? If only this filter is set, we will see all preventative solutions and therefore might need to show less.
                        if (this._checkIfOnlyPreventativeFilterSet(aFilters)) {
                            item.oModel.setProperty(`/allList/${index}/isShowButton`,true);
                        }
                    }
                }
            }
        });
    };

    //When there is some filter set, and click on ‘Show More’ button no further solutions could be shown, a message should pup up and fades away later. Is it ok that we show it in the footer of the whole screen like below. Would that be OK? [Eddie/David/Jorge] This sounds good to us. As long as it stays visible long enough to read the text.
    PreventativeKBACard.prototype._popUpMessageWhenFilterNotMatch = function(bFilterNum, aFilterNum) {
        if (bFilterNum === aFilterNum) {
            MessageToast.show(this._i18n.getText("system_specific_notes_card_service_no_filter_matched"), {
                width: "40em",
                of: this.oCard,
                offset: "0 100",
            });
        }
    };

    /** ************************************************************************************** */
    /**                                     filters                                            */
    /** ************************************************************************************** */

    /**
     * @description set all filter to _oNotesListModel
     */
    PreventativeKBACard.prototype.setAllFilters = function() {
        let excelData = [];
        let totalCount = 0;
        const aFilters = this.getAllFilters();
        this._oKbaNotesDisplayModel.aBindings.filter(v => v.sPath === "notesItems").forEach((item,index) => {
            item?.filter(aFilters);
            item?.oModel?.setProperty(`/allList/${index}/count`, item?.getCount());
            this._hideShowLessWhenFilterSet(item, index, aFilters);
            totalCount += item?.getCount();
            //for excel cache data
            item?.getContexts()?.forEach(v1 => {
                excelData = excelData.concat(v1?.getObject());
            });
        });
        this._excelCacheData = excelData;
        this.handleCardNoSearchView(totalCount);
    };

    /**
     * @description show less button won't display when filter set
     */
    PreventativeKBACard.prototype._hideShowLessWhenFilterSet = function(item, index, filters) {
        if (item.oModel.getProperty(`/allList/${index}/buttonText`) === this._i18n.getText("system_specific_notes_card_show_less")) {
            if (filters.length > 0) {
                item.oModel.setProperty(`/allList/${index}/isShowButton`,false);
                //Eddie: If the only filter set is “Type = Preventative”, can we show the “Show Less”? If only this filter is set, we will see all preventative solutions and therefore might need to show less.
                if (this._checkIfOnlyPreventativeFilterSet(filters)) {
                    item.oModel.setProperty(`/allList/${index}/isShowButton`,true);
                }
            } else {
                item.oModel.setProperty(`/allList/${index}/isShowButton`,true);
            }
        }
    }

    /**
     * @description should return all item filter in this card currently just input search
     */
    PreventativeKBACard.prototype.getAllFilters = function() {
        const allFilters = [];
        if (this._oFilterValues.oSearchText?.trim()) {
            allFilters.push(this.getSearchFilter());
        }
        if (this._oFilterValues.oComponent.length > 0) {
            allFilters.push(this.getComponentFilter());
        }
        if (this._oFilterValues.oType.length > 0) {
            allFilters.push(this.getTypeFilter());
        }
        if (this._oFilterValues.oSoftwareProduct.length > 0) {
            allFilters.push(this.getSoftwareProductFilter());
        }
        return allFilters;
    };

    /**
     * @description if current all filter model only preventative type set then return true
     */
    PreventativeKBACard.prototype._checkIfOnlyPreventativeFilterSet = function(filters) {
        if (filters.length === 1 && this._oFilterValues.oType.indexOf("Preventative") !== -1) {
            return true;
        }
        return false;
    };

    /**
     * @description should return search filter
     */
    PreventativeKBACard.prototype.getSearchFilter = function() {
        const filterProperties = ["kmnumber", "title", "category", "component", "alert_date", "systemName", "systemDisplayNum"];
        const searchText = this._oFilterValues.oSearchText?.toString();
        const aCustomerFilters = filterProperties.map(item => new Filter({
            path: item,
            operator: FilterOperator.Contains,
            value1: searchText,
            caseSensitive: false
        }));
        return new Filter({filters: aCustomerFilters, and: false});
    };

    /**
     * @description after SearchField input trigger this function
     * @param oEvent
     */
    PreventativeKBACard.prototype.onSearchFilterSystemNotes = function(oEvent) {
        this._oFilterValues.oSearchText = oEvent?.getSource()?.getValue()
        this.setAllFilters();
    };

    /**
     * @description should return component filter
     */
    PreventativeKBACard.prototype.getComponentFilter = function() {
        const oSelectKeys = this._oFilterValues.oComponent;
        const result = oSelectKeys.map(item => new Filter({
            path: "component",
            operator: "EQ",
            value1: item
        }));
        return new Filter({filters: result, and: false});
    };

    /**
     * @description should return type filter
     */
    PreventativeKBACard.prototype.getTypeFilter = function() {
        const oSelectKeys = this._oFilterValues.oType;
        const result = oSelectKeys.map(item => new Filter({
            path: "pred_type",
            test: function(oValue) {
                return oValue.toString().includes(item);
            }
        }));
        return new Filter({filters: result, and: false});
    };

    /**
     * @description should return Software Product filter
     */
    PreventativeKBACard.prototype.getSoftwareProductFilter = function() {
        const oSelectKeys = this._oFilterValues.oSoftwareProduct;
        const result = oSelectKeys.map(item => new Filter({
            path: "software_product/name",
            operator: "EQ",
            value1: item
        }));
        return new Filter({filters: result, and: false});
    };

    /** ************************************************************************************** */
    /**                                     formatter                                          */
    /** ************************************************************************************** */

    /**
     * @description add new property DisplayName for customer list
     * @param customerData
     */
    PreventativeKBACard.prototype._tagFormatCustomerName = function(customerData) {
        if (customerData.length > 0) {
            customerData.forEach(item => {
                item.DisplayName = this.transformCustomerString(item?.Value);
            });
        }
    };

    /**
     * @description fomat customer value
     * '203069 - Test value contract OSS corp. function' -> 'Test value contract OSS corp. function(203069)'
     */
    PreventativeKBACard.prototype.transformCustomerString = function(inputString) {
        const match = inputString.match(/^(\d+)\s*-\s*(.*)$/);
        if (match) {
            const id = match[1];
            const text = match[2];
            const transformedString = `${text.trim()}(${id})`;
            return transformedString;
        }
        return inputString;
    };

    /**
     * @description nav to new path
     */
    PreventativeKBACard.prototype._onClickNumber = function(oEvent) {
        const item = oEvent.getSource().getBindingContext("kbaNotesDisplayList").getObject();
        const systemNum = item.systemFullNum;
        this.swaServiceEvent.swaSolutionRecommendationClicked({
            systemID: systemNum,
            productName: item.software_product?.name,
            componentKey: item.component,
            contentType: Array.isArray(item.pred_type) ? item.pred_type.join(";") : item.pred_type,
            contentCategory: item.solution_type,
            contentURL: `${item.kmnumber}${item.overAllIndex ? ";" + item.overAllIndex : ""}${item.preIndex ? ";" + item.preIndex : ""}`
        });
    };

    /**
     * @description nav to system detail
     */
    PreventativeKBACard.prototype._onClickSystemNumber = function(systemNum) {
        if (systemNum) {
            return `/systemdetail/${systemNum}/general`;
        }
    };

    PreventativeKBACard.prototype._processThumbUpIcon = function(feedback_score) {
        return feedback_score == 1 ? "/resources/sap/me/support/resources/thumbup_highlighted.svg" : "sap-icon://thumb-up";
    };

    PreventativeKBACard.prototype._processThumbDownIcon = function(feedback_score) {
        return feedback_score == -1 ? "/resources/sap/me/support/resources/thumbdown_highlighted.svg" : "sap-icon://thumb-down";
    };

    /**
     * @description 000000000850230949 -> 850230949
     */
    PreventativeKBACard.prototype.removeZeroBeforeSystem = function(systemNum) {
        if (systemNum) {
            return systemNum.replace(/^0+/, "");
        }
        return systemNum;
    };

    /**
     * @description control Critical type visible
     */
    PreventativeKBACard.prototype._setTypeCriticalStyle = function(typeList) {
        return this._handleTypeVisible(typeList, "Critical");
    };

    /**
     * @description control Hot type visible
     */
    PreventativeKBACard.prototype._setTypeHotStyle = function(typeList) {
        return this._handleTypeVisible(typeList, "Hot");
    };

    /**
     * @description control Trending type visible
     */
    PreventativeKBACard.prototype._setTypeTrendingStyle = function(typeList) {
        return this._handleTypeVisible(typeList, "Trending");
    };

    /**
     * @description control Preventative type visible
     */
    PreventativeKBACard.prototype._setTypePreventativeStyle = function(typeList) {
        return this._handleTypeVisible(typeList, "Preventative");
    };

    PreventativeKBACard.prototype._removeDuplicateItem = function(arr) {
        return Array.from(new Set(arr));
    };

    PreventativeKBACard.prototype._alphabeticalOrder = function(compFilter) {
        return compFilter.sort(function(a,b) {
            return a?.keyText.localeCompare(b?.keyText);
        });
    };

    /**
     * @description control type visible
     */
    PreventativeKBACard.prototype._handleTypeVisible = function(typeList, typeFlag) {
        if (typeList.length === 0) {
            return false;
        }
        const type = typeList.toString();
        if (type.indexOf(typeFlag) !== -1) {
            return true;
        }
        return false;
    };

    PreventativeKBACard.prototype.handleCardFilters = async function(notesList) {
        this._buildComponentFilterList(notesList);
        this._buildTypeFilterList(notesList);
        this._buildSoftwareProductFilterList(notesList);
    };

    PreventativeKBACard.prototype._buildComponentFilterList = function(notesList) {
        if (notesList.length > 0) {
            const result = this._removeDuplicateItem(notesList.map(item => item.component)).map(obj => {
                return {keyText: obj, textValue: obj};
            });
            this._oCardFilters.setProperty("/componentFilters", this._alphabeticalOrder(result));
        }
    };

    PreventativeKBACard.prototype._buildTypeFilterList = function(notesList) {
        if (notesList.length > 0) {
            const typeList = notesList.map(item => item.pred_type);
            const text = JSON.stringify(typeList);
            const result = [];
            if (text.indexOf("Hot") !== -1) {
                result.push({
                    keyText: "Hot",
                    textValue: this._i18n.getText("system_specific_notes_card_type_hot")
                });
            }
            if (text.indexOf("Trending") !== -1) {
                result.push({
                    keyText: "Trending",
                    textValue: this._i18n.getText("system_specific_notes_card_type_trending")
                });
            }
            if (text.indexOf("Preventative") !== -1) {
                result.push({
                    keyText: "Preventative",
                    textValue: this._i18n.getText("system_specific_notes_card_type_preventative")
                });
            }
            if (text.indexOf("Critical") !== -1) {
                result.push({
                    keyText: "Critical",
                    textValue: this._i18n.getText("system_specific_notes_card_type_critical")
                });
            }
            this._oCardFilters.setProperty("/typeFilters", result);
        }
    };

    PreventativeKBACard.prototype._buildSoftwareProductFilterList = function(notesList) {
        if (notesList.length > 0) {
            const result = this._removeDuplicateItem(notesList.map(item => item.software_product?.name)).map(obj => {
                return {keyText: obj, textValue: obj};
            });
            this._oCardFilters.setProperty("/softwareProFilters", result);
        }
    };

    /** ************************************************************************************** */
    /**                          Selector Header ui and functions                              */
    /** ************************************************************************************** */

    PreventativeKBACard.prototype.onComponentSelected = function(oEvent) {
        this._MultiBoxCommonSelected(oEvent, "oComponent");
    };

    PreventativeKBACard.prototype.onTypeSelected = function(oEvent) {
        this._MultiBoxCommonSelected(oEvent, "oType");
    };

    PreventativeKBACard.prototype.onSoftwareProductSelected = function(oEvent) {
        this._MultiBoxCommonSelected(oEvent, "oSoftwareProduct");
    };

    PreventativeKBACard.prototype._MultiBoxCommonSelected = function(oEvent, keyText) {
        const selectedKeys = oEvent.getSource().getSelectedKeys();
        this._oFilterValues[keyText] = selectedKeys;
        this.setAllFilters();
    };

    PreventativeKBACard.prototype._handleMultiBoxButtonText = function(selectedKeys) {
        if (selectedKeys.length > 0) {
            return this._i18n.getText("filterClear");
        } else {
            return this._i18n.getText("filterSelectAll");
        }
    };

    PreventativeKBACard.prototype.onComponentHeaderButtonPressed = function(oEvent) {
        this._selectorHeaderButtonPressed(oEvent, this._ComponentMultiBox);
    };

    PreventativeKBACard.prototype.onTypeHeaderButtonPressed = function(oEvent) {
        this._selectorHeaderButtonPressed(oEvent, this._TypeMultiBox);
    };

    PreventativeKBACard.prototype.onSoftwareHeaderButtonPressed = function(oEvent) {
        this._selectorHeaderButtonPressed(oEvent, this._SoftwareMultiBox);
    };

    PreventativeKBACard.prototype._selectorHeaderButtonPressed = function(oEvent, multiBox) {
        const button = oEvent.getSource();
        if (button.getText() === this._i18n.getText("filterClear")) {
            multiBox.setSelectedKeys([]);
            button.setText(this._i18n.getText("filterSelectAll"));
        } else if (button.getText() === this._i18n.getText("filterSelectAll")) {
            let aAllKeys = multiBox.getItems().map((oItem) => oItem.getKey());
            multiBox.setSelectedKeys(aAllKeys);
            button.setText(this._i18n.getText("filterClear"));
        }
        //fireSelectionChange will trigger Multi ComboBox selected function ex: onComponentSelected, onTypeSelected, onSoftwareProductSelected
        multiBox.fireSelectionChange();
    };

    PreventativeKBACard.prototype._componentSelectorHeaderInit = function() {
        const multiBox = this._ComponentMultiBox = this.byId("sap4MePreventativeComponentFilter");
        this._selectorHeaderConstructor(multiBox);
    };

    PreventativeKBACard.prototype._typeSelectorHeaderInit = function() {
        const multiBox = this._TypeMultiBox = this.byId("sap4MePreventativeTypeFilter");
        this._selectorHeaderConstructor(multiBox);
    };

    PreventativeKBACard.prototype._softwareSelectorHeaderInit = function() {
        const multiBox = this._SoftwareMultiBox = this.byId("sap4MePreventativeSoftwareFilter");
        this._selectorHeaderConstructor(multiBox);
    };

    PreventativeKBACard.prototype._selectorHeaderInit = function() {
        this._componentSelectorHeaderInit();
        this._typeSelectorHeaderInit();
        this._softwareSelectorHeaderInit();
    };

    PreventativeKBACard.prototype._selectorHeaderConstructor = function(multiBox) {
        let oPicker = multiBox.createPicker("popover").addStyleClass("sapMeSystemSpecificNotesPopover");
        let oToolbar = oPicker.getContent()[0].getHeaderToolbar();
        const customToolbar = multiBox.getDependents();
        oToolbar.getContent()[0].setVisible(false);
        customToolbar[0].getContent().forEach(item => {
            oToolbar.addContent(item);
        })
    };

    PreventativeKBACard.prototype._setFirstPanelOpen = function () {
        this.oCard.getContent().getItems()[1].getItems()[0].getItems()[0].getContent()[0].setExpanded(true);
    };

    /**
     * @description clean cache data
     */
    PreventativeKBACard.prototype._resetCardModel = function() {
        this._oCardFilters.setProperty("/componentFilters", []);
        this._oCardFilters.setProperty("/componentSelectedKeys", []);
        this._oCardFilters.setProperty("/softwareProFilters", []);
        this._oCardFilters.setProperty("/softwareProSelectedKeys", []);
        this._oCardFilters.setProperty("/typeFilters", []);
        this._oCardFilters.setProperty("/typeSelectedKeys", []);
        this._oFilterValues = {
            oSearchText: "",
            oComponent: [],
            oType: [],
            oSoftwareProduct: []
        };
        this._excelCacheData = [];
        this._oCurrentDataModel = [];
        this._oShowMoreModel = {};
        this.byId("searchPreventativeCard").setValue("");
        this._oKbaNotesDisplayModel?.aBindings?.filter(v => v.sPath === "notesItems")?.forEach(item => {
            item?.filter([]);
        });
    };

    PreventativeKBACard.prototype._thumbButtonEventTracking = function(item, feedback_score) {
        this.swaServiceEvent.thumbUpNDownClicked({
            systemID: item.systemFullNum,
            productName: item.software_product?.name,
            contentType: Array.isArray(item.pred_type) ? item.pred_type.join(";") : item.pred_type,
            contentURL: `${item.kmnumber}${item.overAllIndex ? ";" + item.overAllIndex : ""}${item.preIndex ? ";" + item.preIndex : ""}`,
            feedbackScore: feedback_score
        });
    };

    /**
     * @description send the thumbUp and thumbDown request
     */
    PreventativeKBACard.prototype._onThumbButton = function(oEvent, status) {
        const item = oEvent.getSource().getBindingContext("kbaNotesDisplayList").getObject();
        const feedback_dt = new Date().getTime().toString();
        let new_feedback_score = 0, old_feedback_score = 0;
        let noteFeedbackStored = this._notesFeedback.find(note => note.kmnumber === item.kmnumber) || undefined;
        if (status === "up") {
            new_feedback_score = 1;
        } else if (status === "down") {
            new_feedback_score = -1;
        }
        // If the note feedback record already stored, need to set the old_feedback_score
        // If the note didn't exist yet, push to the notesFeeedback array
        if (noteFeedbackStored) {
            if (item.feedback_score === new_feedback_score) {
                new_feedback_score = 0;
                this._notesFeedback = this._notesFeedback.filter(note => note.kmnumber !== item.kmnumber);
            }
            old_feedback_score = item.feedback_score;
            noteFeedbackStored.feedback_score = new_feedback_score;
        } else {
            this._notesFeedback.push({
                kmnumber: item.kmnumber,
                system_number : item.systemFullNum,
                feedback_score: new_feedback_score
            });
        }

        let payload = {
            kmnumber: item.kmnumber,
            system_number: item.systemFullNum,
            pred_type: item.pred_type,
            overall_pred_pos: item.overAllIndex,
            preventative_pred_pos: item.preIndex ?? 0,
            feedback_dt: feedback_dt,
            feedback_score: new_feedback_score,
            old_feedback_score: old_feedback_score
        };

        // Send the request and event tracking
        jQuery.ajax("/backend/raw/support/SystemNotesFeedback", {
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify(payload)
        });
        // Update the model, localStorage
        this._oKbaNotesDisplayModel.aBindings.filter(v => v.sPath === "notesItems").forEach((innerItem,index) => {
            if (innerItem.oModel.getProperty(`/allList/${index}/key`) === item.systemFullNum) {
                innerItem.oModel.getProperty(`/allList/${index}/notesItems`).forEach((notes,innerIndex) => {
                    if (notes.kmnumber === item.kmnumber) {
                        innerItem.oModel.setProperty(`/allList/${index}/notesItems/${innerIndex}/feedback_score`, new_feedback_score);
                    }
                });
            }
        });
        localStorage.setItem("s4mSupportSpecificCardNotesThumbFlag", JSON.stringify(this._notesFeedback));
        this._thumbButtonEventTracking(item, new_feedback_score);
    };

    /** ************************************************************************************** */
    /**                          export excel functions                                        */
    /** ************************************************************************************** */

    PreventativeKBACard.prototype._addExportExcelMenuButton = function(oCard) {
        oCard.getHeader().addMenuItem(new MenuItem({
            icon: "sap-icon://excel-attachment",
            text: this._i18n.getText("export"),
            press: this._onExport.bind(this)
        }));
    };

    PreventativeKBACard.prototype._onExport = function() {
        const oSettings = {
            workbook: {
                columns: this._eGetNotesCardColumns(),
                hierarchyLevel: "Level"
            },
            dataSource: this._eGetNotesCardData() || [],
            fileName: `${this._i18n.getText("system_specific_notes_card_name")}.xlsx`,
            worker: false
        };
        const oSheet = new Spreadsheet(oSettings);
        oSheet.build().finally(function() {
            oSheet.destroy();
        });
    };

    PreventativeKBACard.prototype._eGetNotesCardColumns = function() {
        const aExportColumns = this._eGetCustomColumns();
        return aExportColumns.filter(item => item.propertyName.length > 0).map(item => {
            const oResult = {
                label: this._i18n.getText(item.label), // title of excel
                type:  ExportLibrary.EdmType.String,
                property: item.propertyName // according to the attribute of data source
            };
            if (item.propertyName === "title") {
                oResult.wrap = true;
            }
            return oResult;
        });
    };

    PreventativeKBACard.prototype._eGetNotesCardData = function() {
        const oList =  this._excelCacheData.length > 0 ? this._excelCacheData : this._oCurrentDataModel;
        if (oList.length === 0) {
            return [];
        }
        let oType;
        oList.forEach(item => {
            oType = "";
            ["Critical", "Hot", "Trending", "Preventative"].forEach(tag => {
                if (this._handleTypeVisible(item.pred_type, tag)) {
                    oType += tag + " ";
                }
            });
            item.pred_type = oType;
        });
        return oList;
    };

    PreventativeKBACard.prototype._eGetCustomColumns = function () {
        return [
            {
                "propertyName": "systemDisplayNum",
                "label": "SystemList_systemNumber"
            },
            {
                "propertyName": "systemName",
                "label": "system_specific_notes_card_table_system",
            },
            {
                "propertyName": "kmnumber",
                "label": "system_specific_notes_card_table_number",
            },
            {
                "propertyName": "url",
                "label": "system_specific_notes_card_table_url"
            },
            {
                "propertyName": "title",
                "label": "system_specific_notes_card_table_title",
            },
            {
                "propertyName": "pred_type",
                "label": "system_specific_notes_card_table_type",
            },
            {
                "propertyName": "category",
                "label": "system_specific_notes_card_table_category",
            },
            {
                "propertyName": "component",
                "label": "system_specific_notes_card_table_component",
            },
            {
                "propertyName": "alert_date",
                "label": "system_specific_notes_card_table_alert_date",
            }
        ]
    };

    return PreventativeKBACard;
});

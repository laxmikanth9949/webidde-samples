sap.ui.define([
    "../library",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/core/routing/Router",
    "sap/ui/model/resource/ResourceModel",
    "sap/me/support/utils/RouterHelper",
], function(library, CardComposite, deepEqual, Router, ResourceModel, RouterHelper
) {
    "use strict";
    const ReportCaseEntranceCard = CardComposite.extend("sap.me.support.cards.ReportCaseEntranceCard", {
        metadata: {library: "sap.me.support"}
    });

    ReportCaseEntranceCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oEventBus = sap.ui.getCore().getEventBus();
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        this._oCard = this.getCard();
        this._oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        this._oCard.attachBrowserEvent("click", () => {
            this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", "clearAllData",{isFromHeader:false});
            RouterHelper.navToCreationDashboard();
        });
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        return this;
    };

    return ReportCaseEntranceCard;
}, /* bExport= */true);

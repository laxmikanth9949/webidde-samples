sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/me/support/model/formatter",
    "sap/ui/model/resource/ResourceModel",
    "sap/m/FlexBox",
    "sap/m/IllustratedMessage",
    "sap/m/IllustratedMessageType",
    "sap/m/library"
], function(
    library,
    feLibrary,
    jquery,
    CardComposite,
    deepEqual,
    ODataModel,
    formatter,
    ResourceModel,
    FlexBox,
    IllustratedMessage,
    IllustratedMessageType,
    sapLibrary,
) {
    "use strict";

    // var CardState = feLibrary.CardState;
    let ActionPlansCard = CardComposite.extend("sap.me.support.cards.ActionPlansCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: true, group: "Designtime"},
                growingThreshold: {type: "int", defaultValue: 5, group: "Designtime"},
                showRowCount: {type: "boolean", defaultValue: false, group: "Designtime"}
            }
        },
        formatter: formatter
    });

    ActionPlansCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this.oCard.getTable().setNoData(new FlexBox({
            height: "100%",
            width: "100%",
            direction: sap.m.FlexDirection.Column,
            alignContent: sap.m.FlexAlignContent.Center,
            alignItems: sap.m.FlexAlignItems.Center,
            justifyContent: sap.m.FlexJustifyContent.Center,
            items: [this._getMessageViewer(this._i18n.getText("action_plan_noPlanTitle"), this._i18n.getText("action_plan_noPlanText"), "sapIllus-EmptyList")]
        }));
    };

    ActionPlansCard.prototype._getMessageViewer = function(oTitle, oSubTitle, illustrationType) {
        const view = new IllustratedMessage({
            illustrationSize: sapLibrary.IllustratedMessageSize["Spot"],
            illustrationType: illustrationType,
            enableVerticalResponsiveness: false
        });
        view.setTitle(oTitle);
        view.setDescription(oSubTitle);
        if (illustrationType === sapLibrary.IllustratedMessageType.SimpleError) {
            view.addAdditionalContent(new Button({
                type: "Transparent",
                text: this._i18n.getText("noData_noSrDataReload"),
                press: () => {
                    this.fetchNotesWithProcessing();
                }
            }));
        }
        return view;
    };

    ActionPlansCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
    };

    ActionPlansCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        CardComposite.prototype.setContext.call(this, oContext, false);

        const sQueryParams = `?pointer=${oContext.attributes.caseKey}`;
        // mock data for e2e
        // const sQueryParams = "?pointer=002075125200001021592021";
        // const sQueryParams = "?pointer=002075125200000718642021";
        const oModel = new ODataModel({
            serviceUrl: `/backend/odata/support/${sQueryParams}`,
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        });

        this.oCard.setModel(this._oODataModel = oModel, "$" + this.alias + ".odata");
        return this;
    };

    return ActionPlansCard;
}, true);

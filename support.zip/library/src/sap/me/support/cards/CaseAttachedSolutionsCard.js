sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/odata/v4/ODataModel",
    "../utils/Constants",
    "sap/ui/model/resource/ResourceModel"
], function(
    library,
    feLibrary,
    CardComposite,
    deepEqual,
    ODataModel,
    Constants,
    ResourceModel,
) {
    "use strict";

    let CaseAttachedSolutionsCard = CardComposite.extend("sap.me.support.cards.CaseAttachedSolutionsCard", {
            metadata: {
                library: "sap.me.support",
                properties: {
                    growing: {type: "boolean", defaultValue: true, group: "Designtime"},
                    growingThreshold: {type: "int", defaultValue: 5, group: "Designtime"},
                    showRowCount: {type: "boolean", defaultValue: true, group: "Designtime"}
                }
            }
        }),
        CardState = feLibrary.CardState;

    CaseAttachedSolutionsCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
    };

    CaseAttachedSolutionsCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setNoDataTitle(this._i18n.getText("attSolutions_emptyTitle"));
        oCard.setNoDataSubtitle(this._i18n.getText("attSolutions_emptySubtitle"));
        oCard.setNoDataImgUri("sap/me/support/resources/noSolutions.svg");
    };

    CaseAttachedSolutionsCard.prototype.setContext = function(oContext) {

        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        CardComposite.prototype.setContext.call(this, oContext, false);

        const sQueryParams = `?pointer=${oContext.attributes.caseKey}`;
        // mock data for e2e
        // const sQueryParams = "?pointer=002075125200001021592021";
        // const sQueryParams = "?pointer=002075125200000718642021";

        const oModel = new ODataModel({
            serviceUrl: `/backend/odata/support/${sQueryParams}`,
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        });

        this.oCard.setModel(this._oODataModel = oModel, "$" + this.alias + ".odata");

        return this;
    };

    CaseAttachedSolutionsCard.prototype.onUpdateFinished = function(oEvent) {
        if (oEvent.getParameter("total")) {
            this.oCard.transitionToState(CardState.Content);
        } else {
            this.oCard.transitionToState(CardState.NoData);
        }
    };

    CaseAttachedSolutionsCard.prototype._formatLink = function(sId) {
        return `/notes/${sId}`;
    };

    return CaseAttachedSolutionsCard;
}, true);

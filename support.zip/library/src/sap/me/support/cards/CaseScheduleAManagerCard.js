sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/dom/includeStylesheet",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/me/support/utils/icsConverter",
    "sap/ui/core/Fragment",
    "sap/me/support/utils/DateTimeUtil",
    "../utils/TextEditor",
    "../utils/UpdateFailedDialog",
    "sap/m/MessageToast",
    "sap/me/support/utils/SAEHelper",
    "sap/me/shared/Models",
    "sap/me/support/model/formatter",
    "sap/base/util/deepClone",
    "sap/ui/core/format/DateFormat",
], function(library, jQuery, CardComposite, deepEqual, JSONModel, ResourceModel, ODataModel,
    includeStylesheet, Filter, FilterOperator, icsConverter, Fragment, DateTimeUtil, TextEditor, UpdateFailedDialog, MessageToast, SAEHelper, SharedModels, Formatter, deepClone, DateFormat) {
    "use strict";

    let CaseScheduleAManagerCard = CardComposite.extend("sap.me.support.cards.CaseScheduleAManagerCard", {
        library: "sap.me.support",
        metadata: {
            properties: {
                growing: {type: "boolean", defaultValue: false, group: "Designtime"}
            }
        },
        _oSelectedTimeSlot: null,
        _oSelectedSlot: {selectedDate: "",
            selectedTime: ""},
        _oSam_info: {
            AppInfo: "",
            SamAction: "",
            SamContact: "",
            SamPhone: "",
            SamEmail: "",
            SamcProcessing: "",
            SaMcLackResponse: "",
            SaMcCriticalIssue: "",
            SaMcCommunication: "",
            SaMcOther: "",
            SaMOtherInput: "",
            SaMAdditionalInfo: "",
            sam_start_time: ""
        }
    });

    CaseScheduleAManagerCard.prototype.SAEHelper = SAEHelper;

    let mCaseScheduleAManagerCard = {};

    CaseScheduleAManagerCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(this._oModel = new JSONModel({
        }), "$" + this.alias + ".odata");
        oCard.setModel(this._oModel1 = new JSONModel({
        }), "$" + this.alias + ".oBookSAMdata");
        oCard.setModel(this._oModel2 = new JSONModel({
        }), "$" + this.alias + ".oBookSAMdata2");
        oCard.setModel(this._oSlotToSave = new JSONModel({
        }), "$" + this.alias + ".oSlotToSave");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");

        const _sResourceUri = sap.ui.require.toUrl("sap/me/support/model/CountryCodes.json");

        oCard.setModel(this._oModel = new JSONModel(_sResourceUri), "$" + this.alias + ".oCountryCodes");

        const timePeriodOptionsSample = deepClone(SAEHelper.getTimePeriodOptions("SAM"));

        oCard.setModel(this._oAppointmentInformationSAMModel = new JSONModel({
            isAppointmentInformationVisible: false,
            isNoAppointmentButtonVisible: false,
            dayList: [],
            timePeriodOptions: timePeriodOptionsSample,
            selectedTimeList: [],
            selectedTimeItem: {},
            totalCount: 0,
            timezone: "",
            localTimezone: "",
            selectedDay: -1,
            selectedTimeIndex: 0,
            weekDayFormat: "EE",
            monthFormat: "MMM",
            dateFormat: "d",
        }), "$this.appointmentInformationSAM");

        this._oCustomerModel = SharedModels.getCustomerModel();

        oCard.setModel(this._disabledDatesModel = new JSONModel({
            disabled: [
                {
                    // disable all past dates
                    end: new Date()
                },{
                    // disable the dates after 10 valid dates
                    start: this.getOffsetDate(14),
                    end: this.getOffsetDate(365)
                }
            ]
        }), "$this.disabledDates");

    };

    CaseScheduleAManagerCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        this._oEventBus = sap.ui.getCore().getEventBus();
        this._fragment = sap.ui.core.Fragment;
        this.getCore = sap.ui.getCore();
        //        this._sResourceUri = sap.ui.require.toUrl("sap/me/support");
        //        includeStylesheet(this._sResourceUri + "/css/SAE-SAM.css", {
        //            id: "CalendarGrid"
        //        });
        this.oCard.setModel(this.samBindingData = new JSONModel({
            "sap.me.support": this._sResourceUri = sap.ui.require.toUrl("sap/me/support"),
            bookSaMButtonVisible: false,
            bookSaMButtonEnable: false,
            bookSaMButtonToolTip: ""
        }), "binding"); // model for binding paths
    };

    CaseScheduleAManagerCard.prototype.setTimeSlots = function(iSelectedDate) {
        this._oModel2.setData({
            ScheduleAManagerBookingTimeSlot: this.getCard().getModel("$this.calendarGrid").getData().DAYS[iSelectedDate].SLOTS
        });
    };

    CaseScheduleAManagerCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext(), oCard = this.getCard(), sCaseScheduleAManager = "CaseScheduleAManager";
        this.oCard.getContent().setBusy(true);
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        this._pointer = `${oContext.attributes.caseKey}`;
        // this._pointer = "002075126000001615912023";
        // oCard.authorizationCheck(oContext.authorization, ["READM"], ["READM_INST"], ["ANLEG"], ["GOSAP"]);
        oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);

        const oModel2 = new ODataModel({
            serviceUrl: "/backend/odata/support/",
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        });
        this.getCard().setModel(this._oODataModel = oModel2, "$" + this.alias + ".userTimezone");

        this._updateFailedDialog = new UpdateFailedDialog(this.getCard());

        this._oEventBus.subscribe("sap.me.support.cards.CaseScheduleAManagerCard", "appointmentChange", () => {
            this.oCard.getContent().setBusy(true);
            this.setListContexts().then(listCount => {
                this.oCard.getContent().setBusy(false);
                this.noDataInSectionReset();
            });
        });

        this.getUserTimeZone();
        this.getAvailableSessions();

        return this;
    };

    CaseScheduleAManagerCard.prototype.getUserTimeZone = function() {
        this.oTimeZoneDataHolder = this.byId("timeZoneDataHolder");
        let oHolderBinding = this.oTimeZoneDataHolder.getBinding("items");
        oHolderBinding.attachDataReceived((oEvent) => {
            const oHolderContexts = oEvent.getSource().getCurrentContexts();
            if (oHolderContexts.length > 0) {
                this._userTimezone = Formatter.formatTimezoneList(oHolderContexts[0].getProperty("timeZoneDescription"), oHolderContexts[0].getProperty("timeZoneUTCsign"), oHolderContexts[0].getProperty("timeZoneUTCdiff"));
                this._timeZoneUTCdiffHrs = parseInt(oHolderContexts[0].getProperty("timeZoneUTCdiff").substring(2, 4));
                this._timeZoneUTCdiffMins = parseInt(oHolderContexts[0].getProperty("timeZoneUTCdiff").substring(5, 7));
                this._timeZoneUTCdiffSecs = parseInt(oHolderContexts[0].getProperty("timeZoneUTCdiff").substring(8, 10));
                this._timeZoneUTCsign = oHolderContexts[0].getProperty("timeZoneUTCsign");
            }
            this.setListContexts();
        });
    };

    CaseScheduleAManagerCard.prototype.getOffsetDate = function(dateOffset = 0) {
        const date = new Date();
        date.setDate(date.getDate() + dateOffset);
        return date;
    };

    CaseScheduleAManagerCard.prototype.addWeekendDisabledDays = function(disabledDates) {
        // calculate for future 14 days and add to disabledDates
        for (let i = 0; i <= 14; i++) {
            let date = new Date();
            date.setDate(date.getDate() + i);
            if (date.getDay() % 6 === 0) {
                disabledDates.push({start: date});
            }
        }
        return disabledDates;
    };

    CaseScheduleAManagerCard.prototype.getAvailableSessions = function() {
        let that = this;
        this.getChannelRecommenderData().then(data => {
            let samData = data.find(o => o.ChannelID === "SAM");
            that.checkReceivedData(samData);
            const serviceTimezone = JSON.parse(samData.ChannelData).slots?.TimezoneUTC ?? "UTC";
            const {result, isTotalAvailable} = SAEHelper.formatTimeToLocalTimezone(JSON.parse(samData.ChannelData).slots.DAYS, serviceTimezone);

            // add disabled dates to calendar
            const disabledDates = this._disabledDatesModel.getProperty("/disabled"); // [{end: Date.now()}]
            result.forEach(dayItem => {
                if (!dayItem.isAvailable) {
                    const disabledDay = new Date(dayItem.Date.slice(0, 4), dayItem.Date.slice(4, 6) - 1, dayItem.Date.slice(6, 8));
                    disabledDates.push({start: disabledDay});
                }
            });
            this.addWeekendDisabledDays(disabledDates);
            this._disabledDatesModel.setProperty("/disabled", disabledDates);

            this._oAppointmentInformationSAMModel.setProperty("/isTotalAvailable", isTotalAvailable);
            this._oAppointmentInformationSAMModel.setProperty("/dayList", result);
            this._oAppointmentInformationSAMModel.setProperty("/userProfileTimezone", serviceTimezone);
            this._oAppointmentInformationSAMModel.setProperty("/localTimezone", sap.ui.core.Configuration.getTimezone());

            that._oReceivedChannelData = samData;
            this.selectAppointmentDay(result);
            this.oCard.getContent().setBusy(false);
        }).catch(oError => {
            console.log("channelRecommender data unavailable: " + oError.responseText);
            this.oCard.getContent().setBusy(false);
            this.samBindingData.setProperty("/bookSaMButtonVisible", false);
        });
    };

    CaseScheduleAManagerCard.prototype.getChannelRecommenderData = function() {
        let pointer = this._pointer;

        return new Promise((resolve, reject) => {
            jQuery.ajax(`/backend/raw/support/ChannelRecommender?$filter=CasePointer eq '${pointer}' and UseCaseID eq 'S4MSupportDisplay'`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                success:(data) => {
                    resolve(data); // /////////////////////remove[4] for live data
                },
                error: (error) => {
                    reject(error);
                },
                complete: () => {

                }
            });
        });
    };

    CaseScheduleAManagerCard.prototype.checkReceivedData = function(oData) {

        if (oData) {

            let cActive = oData.Status;
            let oDetails = JSON.parse(oData.ChannelData).details;

            if ((cActive === "A") && (oData.Priority !== "1" && oData.Priority !== "4")) {

                if (oDetails.ACTIVE !== true) {
                    this.setNoDataTextAndToolTip(this._i18n.getText("SAMRule1"), "invisible");
                } else if (oDetails.BOOKED === false) {
                    this.setNoDataTextAndToolTip(this._i18n.getText("SAMConditionalText1"), "enabled");
                } else {
                    if (oDetails.PRIO !== true) {
                        this.setNoDataTextAndToolTip(this._i18n.getText("SAMRule4"), "disabled");
                    }
                    if (oDetails.PS !== true) {
                        this.setNoDataTextAndToolTip(this._i18n.getText("SAMRule2"), "disabled");
                    }
                    if (oDetails.PRIO === true && oDetails.PS === true) {
                        if (oDetails.STATUS !== true) {
                            this.setNoDataTextAndToolTip(this._i18n.getText("SAMRule2"), "disabled");
                        } else if (oDetails.SLOTS !== true) {
                            this.setNoDataTextAndToolTip(this._i18n.getText("SAMRule3"), "disabled");
                        } else {
                            this.setNoDataTextAndToolTip(this._i18n.getText("bookManagerAppointmentText"), "enabled");
                        }
                    }

                }
            } else {
                this.setNoDataTextAndToolTip(this._i18n.getText("SAMNotAllowed"), "invisible");
            }

        } else {
            this.setNoDataTextAndToolTip(this._i18n.getText("SAMUnavailable"), "invisible");
        }

    };

    CaseScheduleAManagerCard.prototype.setListContexts = function() {
        return new Promise(function(resolve, reject) {
            let pointer = this._pointer;

            const sQueryParams = `?pointer=${pointer}&type=sam`;

            const oModel = new ODataModel({
                serviceUrl: `/backend/odata/support/${sQueryParams}`,
                synchronizationMode: "None",
                groupId: "$direct",
                operationMode: "Server"
            });
            this.getCard().setModel(this._oODataModel = oModel, "$" + this.alias + ".odata");

            this.oCaseAppointmentsList = this.byId("caseSAMAppointmentsList");
            let aFilter = [];
            let sQuery = "sam";

            aFilter.push(new Filter("type", FilterOperator.Contains, sQuery));

            let oBinding = this.oCaseAppointmentsList.getBinding("items");
            oBinding.filter(aFilter);

            oBinding.attachDataReceived((oEvent) => {
                const oContexts = oEvent.getSource().getCurrentContexts();
                this.noDataInSectionReset();

                for (let i = 0, j = this.oCaseAppointmentsList.getItems().length; i < j; i++) {
                    const attachmentItem = this.oCaseAppointmentsList.getItems()[i].getContent()[0].getItems()[0].getItems()[0].getItems()[0].getItems()[0].getItems()[0].getItems()[1];
                    if (oContexts[i].getProperty("status") === "cancelled") {
                        attachmentItem.addStyleClass("sapMeCaseSessionCancelled");
                    } else {
                        attachmentItem.removeStyleClass("sapMeCaseSessionCancelled");
                    }
                }

                if (oContexts[0] === undefined || this.oCaseAppointmentsList.getItems().length === 0) {
                    this.noDataInSection();
                }
                resolve(this.oCaseAppointmentsList.getItems().length);

            }, this);

        }.bind(this));
    };

    CaseScheduleAManagerCard.prototype.setNoDataTextAndToolTip = function(sMessage, buttonState) {
        this.byId("noDataMessagePage").setDescription(sMessage);

        switch (buttonState) {
            case "invisible":
                this.samBindingData.setProperty("/bookSaMButtonVisible", false);
                break;
            case "enabled":
                this.samBindingData.setProperty("/bookSaMButtonVisible", true);
                this.samBindingData.setProperty("/bookSaMButtonEnable", true);
                if (sMessage === this._i18n.getText("bookManagerAppointmentText")) {
                    this.samBindingData.setProperty("/bookSaMButtonToolTip", this._i18n.getText("bookManagerAppointmentToolTip"));
                } else {
                    this.samBindingData.setProperty("/bookSaMButtonToolTip", sMessage);
                }
                break;
            case "disabled":
                this.samBindingData.setProperty("/bookSaMButtonVisible", false);
                this.samBindingData.setProperty("/bookSaMButtonEnable", false);
                this.samBindingData.setProperty("/bookSaMButtonToolTip", sMessage);
                break;
            default:
                this.samBindingData.setProperty("/bookSaMButtonVisible", false);
                this.samBindingData.setProperty("/bookSaMButtonEnable", true);
        }
    };

    CaseScheduleAManagerCard.prototype.noDataInSection = function() {
        this.byId("noDataMessagePage").setVisible(true);
        this.byId("caseSAMAppointmentsList").setVisible(false);
    };

    CaseScheduleAManagerCard.prototype.noDataInSectionReset = function() {
        this.byId("noDataMessagePage").setVisible(false);
        this.byId("caseSAMAppointmentsList").setVisible(true);
    };

    CaseScheduleAManagerCard.prototype._createRichTextEditor = function() {
        if (sap.ui.getCore().byId("scheduleAManagerBookingRichtextEditor")) {
            sap.ui.getCore().byId("scheduleAManagerBookingRichtextEditor").destroy();
        }
        this._oEditor = new TextEditor.createRichTextEditor("scheduleAManagerBookingRichtextEditor",{
            editable: true,
            value:"",
            readOnly: false,
            statusbar: false,
            height: 170,
            change: this._textOnChange.bind(this)
        });
        this._fragment.byId(this._sSAMBookingDialogId, "SAMRichTextVBox").addItem(this._oEditor);
    };

    CaseScheduleAManagerCard.prototype._textOnChange = function() {
        this._oSlotToSave.setProperty("/enteredAdditionalInfo", this._oEditor.getValue());
    };

    CaseScheduleAManagerCard.prototype._destroyRichTextEditor = function() {

        if (this.getCore.byId("scheduleAManagerBookingRichtextEditor")) {
            this.getCore.byId("scheduleAManagerBookingRichtextEditor").destroy();
        }
    };

    /** ************************************************************************************** */
    /*                                         Event Handlers                                 */
    /** ************************************************************************************** */

    CaseScheduleAManagerCard.prototype.downloadPress = function(oEvent) {
        let saeEvent = {};
        let caseLink;

        if (window.location.hostname.startsWith("test")) {
            caseLink = "https://test.me.sap.com/case/";
        } else {
            caseLink = "https://me.sap.com/case/";
        }
        saeEvent.title = oEvent.getSource().getBindingContext("$this.odata").getProperty("title");
        saeEvent.start = this.convertTimezone(oEvent.getSource().getBindingContext("$this.odata").getProperty("startTime")).replace(" ", "T");
        saeEvent.meetingUrl = oEvent.getSource().getBindingContext("$this.odata").getProperty("teamsUrl");
        saeEvent.type = oEvent.getSource().getBindingContext("$this.odata").getProperty("type");
        saeEvent.end = this.convertTimezone(oEvent.getSource().getBindingContext("$this.odata").getProperty("endTime")).replace(" ", "T");
        saeEvent.targetSystemUrl = this._i18n.getText("ICSdirectCallText");
        saeEvent.additionalInfo = JSON.parse(oEvent.getSource().getBindingContext("$this.odata").getProperty("additionalInfo"));
        //      saeEvent.description = this._i18n.getText("ICSScheduleForText") + "\n" + saeEvent.meetingUrl +
        //                                "\n_____________________________\n" +
        //                                 this._i18n.getText("PleaseCallAt") + " " + saeEvent.additionalInfo.phone +
        //                                "\n" + this._i18n.getText("CustomerName") + " " + saeEvent.additionalInfo.name +
        //                                "\n" + this._i18n.getText("CustomerEmail") + " " + saeEvent.additionalInfo.email;
        saeEvent.description = this._i18n.getText("ICSScheduleForText") + "\n"
                                + caseLink + this._pointer
                                + "\n_____________________________\n"
                                + this._i18n.getText("ICSCalledAt") + saeEvent.additionalInfo.phone;
        icsConverter.saveTimelineEventAsCalendarFile(saeEvent);

    };

    /**
     * convert to user local timezone
     * @param {string} sDate UTC time
     */
    CaseScheduleAManagerCard.prototype.convertTimezone = function(sDate) {
        if (!sDate) {
            return;
        }
        const oDateFormatUTC = DateFormat.getDateTimeWithTimezoneInstance({pattern: "yyyy-MM-dd HH:mm:ss"});
        const timestamp = oDateFormatUTC.parse(sDate, "UTC")?.[0].getTime();
        return oDateFormatUTC.format(new Date(timestamp), Intl.DateTimeFormat().resolvedOptions().timeZone);
    };

    CaseScheduleAManagerCard.prototype.onPressAppointmentDay = function(oEvent) {

        const selectedDateObj = oEvent.getSource().getSelectedDates()[0].getStartDate();
        const year = selectedDateObj.getFullYear();
        const month = selectedDateObj.getMonth() + 1;
        const day = selectedDateObj.getDate();
        const dateStr = `${year}${month < 10 ? "0" + month : month}${day < 10 ? "0" + day : day}`;

        const dayItem = this._oAppointmentInformationSAMModel.getProperty("/dayList")?.find(day => day.Date == dateStr);

        if (dayItem?.Date === this._oAppointmentInformationSAMModel.getProperty("/selectedDay")) {
            return;
        }
        this.selectAppointmentDay([dayItem]);
        this._fragment.byId(this._sSAMBookingDialogId, "SAMSaveAndContinue").setEnabled(false);
    };

    CaseScheduleAManagerCard.prototype.onSamSelected = function(oEvent) {
        let samItemSessionInfo = oEvent.getSource().getContent()[1];

        if (!samItemSessionInfo.getVisible()) {
            samItemSessionInfo.setVisible(true);
            oEvent.getSource().getContent()[0].addStyleClass("sapFlexboxBottomDivLine");
        } else {
            samItemSessionInfo.setVisible(false);
            oEvent.getSource().getContent()[0].removeStyleClass("sapFlexboxBottomDivLine");
        }
    };

    CaseScheduleAManagerCard.prototype.onPressCancelSession = function(oEvent) {
        this.samStartDateToCancel = oEvent.getSource().getBindingContext("$this.odata").getProperty("startTime").replace(/-|T|:|\.| /g,"");
        this.samAdditionalInfoSelected = JSON.parse(oEvent.getSource().getBindingContext("$this.odata").getProperty("additionalInfo"));

        this._oSam_info.AppInfo = "CIA";
        this._oSam_info.SamAction = "delete";
        this._oSam_info.SamContact = this.samAdditionalInfoSelected.name;
        this._oSam_info.SamPhone = this.samAdditionalInfoSelected.phone;
        this._oSam_info.SamEmail = this.samAdditionalInfoSelected.email;
        this._oSam_info.SamcProcessing = this.samAdditionalInfoSelected.reason_1;
        this._oSam_info.SaMcLackResponse = this.samAdditionalInfoSelected.reason_2;
        this._oSam_info.SaMcCriticalIssue = this.samAdditionalInfoSelected.reason_3;
        this._oSam_info.SaMcCommunication = this.samAdditionalInfoSelected.reason_4;
        this._oSam_info.SaMcOther = this.samAdditionalInfoSelected.reason_5;
        this._oSam_info.SaMOtherInput = this.samAdditionalInfoSelected.reason_5_text;
        this._oSam_info.sam_start_time = this.samStartDateToCancel;

        sap.m.MessageBox.warning(this._i18n.getText("CancelSaMAppointmentText"), {
            title: this._i18n.getText("CancelSaMAppointmentTitle"),
            styleClass: "sapUiSizeCompact",
            actions: ["Confirm","Cancel"],
            emphasizedAction: "Confirm",
            initialFocus: null,
            textDirection: sap.ui.core.TextDirection.Inherit,
            onClose: (sAction) => {
                if (sAction === "Confirm") {
                    this.onConfirmDeleteSession();
                }
            }
        });
    };

    CaseScheduleAManagerCard.prototype.onConfirmDeleteSession = function(oEvent) {
        this.oCard.getContent().setBusy(true);
        let oChannelData = JSON.parse(this._oReceivedChannelData.ChannelData);
        jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({
                action: "SEND2SAP",
                pointer: this._pointer,
                long_text: "SAM Appointment for Case " + this._pointer + " to be cancelled",
                sam_duration: 30,
                sam_start_time: this.samStartDateToCancel,
                rep_case: "1",
                component: oChannelData.case.component,
                status: "SEND2SAP",
                sam_info: JSON.stringify(this._oSam_info),
                sam_action:"delete"
            })
        }).done(success => {
            this._oEventBus.publish("sap.me.support.cards.CaseScheduleAManagerCard", "appointmentChange");
            MessageToast.show(`${this._i18n.getText("SAMSessionCancelled")}`);
            this._oODataModel.refresh();
            setTimeout(() => this.getAvailableSessions(), 1000);
        }).fail(error => {
            this._updateFailedDialog.open();
        }).always(() => {
            this.oCard.getContent().setBusy(false);
        });
    };

    CaseScheduleAManagerCard.prototype.onPressViewEvent = function(oEvent) {
        //        if (window.location.hostname.startsWith("test")) {
        //            sap.m.URLHelper.redirect( "https://test.me.sap.com/calendar", true);
        //        } else {
        //            sap.m.URLHelper.redirect( "https://me.sap.com/calendar", true);
        //        }
        sap.m.URLHelper.redirect( window.origin + "/calendar", true);
    };


    /** ************************************************************************************** */
    /*                            Book a Session Event Handlers                               */
    /** ************************************************************************************** */


    CaseScheduleAManagerCard.prototype.scheduleASessionPress = function() {

        if (!this._oSAMBookingDialog) {
            return Fragment.load({
                id: this._sSAMBookingDialogId = (this.getId() + "-sSAMBookingDialog"),
                name: "sap.me.support.fragments.ScheduleAManagerBookingDialog",
                controller: this
            }).then(function(oSAMBookingDialog) {
                this._oSAMBookingDialog = oSAMBookingDialog;
                this.oCard.addDependent(this._oSAMBookingDialog);

                this.updateBookingDialogDetails();
                this._oSAMBookingDialog.open();

            }.bind(this));
        }
        this.clearBookingDialogDetails();
        this.updateBookingDialogDetails();
        this._oSAMBookingDialog.open();


    };


    CaseScheduleAManagerCard.prototype.updateBookingDialogDetails = function() {
        this.setDialogContext();
        this._fragment.byId(this._sSAMBookingDialogId, "phoneComboBox").setSelectedKey(this._oCustomerModel.getData().country);
        this._fragment.byId(this._sSAMBookingDialogId, "phoneNumberInput1").setValue(this._oCustomerModel.getData().phone);
        this._fragment.byId(this._sSAMBookingDialogId, "nameInput1").setValue(this._oCustomerModel.getData().firstname + " " + this._oCustomerModel.getData().lastname);
        this._fragment.byId(this._sSAMBookingDialogId, "emailInput1").setValue(this._oCustomerModel.getData().email);

    };

    CaseScheduleAManagerCard.prototype.onCloseBookSAMDialog = function(oEvent) {
        this._oSAMBookingDialog.close();
        if (this._oEditor) {
            this._oEditor.setValue("");
        }

    };

    CaseScheduleAManagerCard.prototype.clearBookingDialogDetails = function() {
        this._fragment.byId(this._sSAMBookingDialogId, "SAMSaveAndContinue").setEnabled(false);
        this._oAppointmentInformationSAMModel.setProperty("/selectedDay", -1);
        this._fragment.byId(this._sSAMBookingDialogId, "firstInfoVBox").setVisible(true);
        this._fragment.byId(this._sSAMBookingDialogId, "secondInfoVBox").setVisible(false);

        this._fragment.byId(this._sSAMBookingDialogId, "nameInput1").setValue("");
        this._fragment.byId(this._sSAMBookingDialogId, "phoneComboBox").setValue("");
        this._fragment.byId(this._sSAMBookingDialogId, "emailInput1").setValue("");

        this._fragment.byId(this._sSAMBookingDialogId, "timeCheckBox").setSelected(false);
        this._fragment.byId(this._sSAMBookingDialogId, "lackRespCheckBox").setSelected(false);
        this._fragment.byId(this._sSAMBookingDialogId, "criticalIssueCheckBox").setSelected(false);
        this._fragment.byId(this._sSAMBookingDialogId, "comChallengeCheckBox").setSelected(false);
        this._fragment.byId(this._sSAMBookingDialogId, "OtherCheckBox").setSelected(false);

    };

    CaseScheduleAManagerCard.prototype.setDialogContext = function() {

        let oChannelData = JSON.parse(this._oReceivedChannelData.ChannelData);
        this.getCard().setModel(this._oCGModel = new JSONModel(oChannelData.slots),
            "$" + this.alias + ".calendarGrid");
        this._pointerForAppointment = this._oReceivedChannelData.CasePointer;
        this._componentForAppointment = oChannelData.case.component;
        if (oChannelData.case.title) {
            this._oModel2.setData({incidentTitle: oChannelData.case.title});
        }

    };

    CaseScheduleAManagerCard.prototype.selectAppointmentDay = function(dayList) {
        // select first available day
        const firstAvailableDay = dayList.find(v => v.isAvailable);
        if (!firstAvailableDay) {
            return;
        }

        const timePeriodOptions = SAEHelper.getAvailableTimeList(firstAvailableDay.SLOTS, this._oAppointmentInformationSAMModel.getProperty("/timePeriodOptions"));
        const availableCount = timePeriodOptions.reduce((acc, cur) => [...acc, ...cur.timeList], []).filter(item => item.isAvailable)?.length;
        const firstAvailableItem = timePeriodOptions.find(v => v.timeList.find(t => t.isAvailable));

        this._oAppointmentInformationSAMModel.setProperty("/selectedDay", firstAvailableDay.Date);
        this._oAppointmentInformationSAMModel.setProperty("/timePeriodOptions", timePeriodOptions);
        this._oAppointmentInformationSAMModel.setProperty("/availableCount", availableCount);
        this._oAppointmentInformationSAMModel.setProperty("/selectedTimeList", timePeriodOptions[firstAvailableItem.key].timeList);
        this._oAppointmentInformationSAMModel.setProperty("/selectedTimeIndex", firstAvailableItem.key);
        this._oAppointmentInformationSAMModel.setProperty("/selectedTimeItem", {});
        this._oAppointmentInformationSAMModel.setProperty("/selectedDate", this.parseDate(firstAvailableDay.Date).toDateString());
    };

    CaseScheduleAManagerCard.prototype.onPressAppointmentTimeIconSAM = function(oEvent) {
        const key = oEvent.getSource().getBindingContext("$this.appointmentInformationSAM").getProperty("key");
        if (key === this._oAppointmentInformationSAMModel.getProperty("/selectedTimeIndex")) {
            return;
        }

        const timePeriodOptions = this._oAppointmentInformationSAMModel.getProperty("/timePeriodOptions");

        this._oAppointmentInformationSAMModel.setProperty("/selectedTimeIndex", key);
        this._oAppointmentInformationSAMModel.setProperty("/selectedTimeList", timePeriodOptions[key].timeList);
        this._oAppointmentInformationSAMModel.setProperty("/selectedTimeItem", {});
        this._fragment.byId(this._sSAMBookingDialogId, "SAMSaveAndContinue").setEnabled(false);
    };

    CaseScheduleAManagerCard.prototype.onPressTimeItem = function(oEvent) {
        const selectedTimeItem = oEvent.getSource().getBindingContext("$this.appointmentInformationSAM").getObject();

        if (!selectedTimeItem.isAvailable) {
            return;
        }
        this._oAppointmentInformationSAMModel.setProperty("/selectedTimeItem", selectedTimeItem);
        this._fragment.byId(this._sSAMBookingDialogId, "SAMSaveAndContinue").setEnabled(true);
    };


    CaseScheduleAManagerCard.prototype.onSaveAndContinue = function(oEvent) {
        this._oSlotToSave.setProperty("/selectedDate", this._oSelectedSlot.selectedDate);
        this._oSlotToSave.setProperty("/selectedTime", this._oSelectedSlot.selectedTime);
        this._fragment.byId(this._sSAMBookingDialogId, "firstInfoVBox").setVisible(false);
        this._fragment.byId(this._sSAMBookingDialogId, "secondInfoVBox").setVisible(true);
    };

    CaseScheduleAManagerCard.prototype.onBackSelected = function() {
        this._fragment.byId(this._sSAMBookingDialogId, "firstInfoVBox").setVisible(true);
        this._fragment.byId(this._sSAMBookingDialogId, "secondInfoVBox").setVisible(false);
    };

    CaseScheduleAManagerCard.prototype.onCheckboxSelect = function(oEvent) {
        let oRequestReason = oEvent.getSource();
        let bOtherSelected;
        if (oRequestReason.getSelectedItems().length > 0) {
            oRequestReason.getSelectedItems().forEach((oReason) => {
                if (oReason.getId().includes("OtherCheckBox")) {
                    bOtherSelected = true;
                } else {
                    bOtherSelected = false;
                }
            });

            if (bOtherSelected) {
                if (!sap.ui.getCore().byId("scheduleAManagerBookingRichtextEditor")) {
                    this._createRichTextEditor();
                    this._fragment.byId(this._sSAMBookingDialogId, "reasonText").setVisible(true);
                    this._oEditor.setWidth("99%");
                }
            } else {
                this._destroyRichTextEditor();
                this._fragment.byId(this._sSAMBookingDialogId, "reasonText").setVisible(false);
            }


        } else {
            this._destroyRichTextEditor();
            this._fragment.byId(this._sSAMBookingDialogId, "reasonText").setVisible(false);
        }

    };

    CaseScheduleAManagerCard.prototype.onBookSession = function() {
        this._oSAMBookingDialog.setBusy(true);
        this.setBookingReason();

        this._oSam_info.AppInfo = "CIA";
        this._oSam_info.SamAction = "insert";
        this._oSam_info.SamContact = this._fragment.byId(this._sSAMBookingDialogId, "nameInput1").getValue();
        this._oSam_info.SamPhone = this._fragment.byId(this._sSAMBookingDialogId, "phoneComboBox").getValue().substr(0, this._fragment.byId(this._sSAMBookingDialogId, "phoneComboBox").getValue().indexOf("(")) + this._fragment.byId(this._sSAMBookingDialogId, "phoneNumberInput1").getValue();
        this._oSam_info.SamEmail = this._fragment.byId(this._sSAMBookingDialogId, "emailInput1").getValue();
        const caseObj = JSON.parse(this._oReceivedChannelData.ChannelData)?.case;

        jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({
                event:"SAM",
                action: "SEND2SAP",
                component: caseObj?.component_key ? caseObj?.component_key : caseObj?.component,
                pointer: this._pointerForAppointment,
                priority: "2",
                rep_case: "1",
                sam_duration: 30,
                sam_info: JSON.stringify(this._oSam_info),
                sam_start_time: this._oAppointmentInformationSAMModel.getProperty("/selectedTimeItem/value")})
        }).done(updateResult => {
            this._oEventBus.publish("sap.me.support.cards.CaseScheduleAManagerCard", "appointmentChange");
            MessageToast.show(`${this._i18n.getText("SAMSubmittedSuccess")}`);
            this._oODataModel.refresh();
            this._oSAMBookingDialog.setBusy(false);
            // after submit clear content
            this.onCloseBookSAMDialog();
            this._oEditor?.setValue("");

            this.getAvailableSessions();
        }).fail(error => {
            this._oSAMBookingDialog.setBusy(false);
            this._updateFailedDialog.open();
        });

    };

    CaseScheduleAManagerCard.prototype.setBookingReason = function() {
        let selectedReasons = this._fragment.byId(this._sSAMBookingDialogId, "bookingReasonList").getSelectedItems();
        let reasonID;
        selectedReasons.forEach((oReason) => {
            reasonID = oReason.getId();
            switch (true) {
                case reasonID.includes("timeCheckBox"):
                    this._oSam_info.SamcProcessing = "X";
                    break;
                case reasonID.includes("lackRespCheckBox"):
                    this._oSam_info.SaMcLackResponse = "X";
                    break;
                case reasonID.includes("criticalIssueCheckBox"):
                    this._oSam_info.SaMcCriticalIssue = "X";
                    break;
                case reasonID.includes("comChallengeCheckBox"):
                    this._oSam_info.SaMcCommunication = "X";
                    break;
                case reasonID.includes("OtherCheckBox"):
                    this._oSam_info.SaMcOther = "X";
                    if (this._oEditor) {
                        this._OtherReasonText = this._oEditor.getValue();
                    }
                    this._oSam_info.SaMOtherInput = this._OtherReasonText;
                    break;
            }

        });

    };



    /** ************************************************************************************** */
    /*                                         Formatters                                     */
    /** ************************************************************************************** */

    CaseScheduleAManagerCard.prototype._formatToUserTZone = function(sLocalDate) {
        let toMilliseconds = (hrs,min,sec) => (hrs * 60 * 60 + min * 60 + sec) * 1000;

        let diffToMilli = (toMilliseconds(this._timeZoneUTCdiffHrs, this._timeZoneUTCdiffMins , this._timeZoneUTCdiffSecs));

        let localStartDate = new Date(sLocalDate);
        let startTime = localStartDate.getTime();

        let startTimeInUserTZone;

        if (this._timeZoneUTCsign === "+") {
            startTimeInUserTZone = startTime + diffToMilli;
        } else {
            startTimeInUserTZone = startTime - diffToMilli;
        }
        let userStartDate = new Date(startTimeInUserTZone);

        return userStartDate.toString().substr(0, 25) + this._userTimezone;
    };

    CaseScheduleAManagerCard.prototype._formatNoDataInSection = function(sNoDataText) {
        this.byId("caseSAMAppointmentsList").setShowNoData(false);
        this.byId("noDataMessagePage").setVisible(true);
    };


    CaseScheduleAManagerCard.prototype._formatAdditionalInfo = function(sAdditionalInfo, type) {

        try {
            var oInfo = JSON.parse(sAdditionalInfo);
        } catch (e) {
            // console.log (e); // error in the above string (in this case, yes)!
        }

        if (oInfo) {
            switch (type) {
                case "name": return oInfo.name;
                case "phone": return oInfo.phone;
                case "email": return oInfo.email;
            }
        }
    };

    CaseScheduleAManagerCard.prototype._formatTodayTextVisible = function(sDate, sStatus) {
        let currentDate = new Date();
        let bookedDate = new Date(sDate);
        if (sStatus === "cancelled") {
            return false;
        }
        return currentDate.getDate() === bookedDate.getDate();
    };

    /** ****************************************************************************************** */
    /*                                  Book A Session Formatters                                 */
    /** ****************************************************************************************** */

    CaseScheduleAManagerCard.prototype.parseDate = function(sDate) {
        return new Date(sDate.substr(0,4), parseInt(sDate.substr(4,2)) - 1, sDate.substr(6,2));
    };

    CaseScheduleAManagerCard.prototype._formatCancelledTextVisible = function(sStatus) {
        return sStatus === "cancelled";
    };

    CaseScheduleAManagerCard.prototype._formatMenuButtonVisible = function(sStatus) {
        if ( sStatus === "cancelled" || sStatus === "completed" ) {
            return false;
        }
        return true;
    };

    return CaseScheduleAManagerCard;
}, /* bExport= */true);

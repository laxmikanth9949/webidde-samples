sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "../utils/Constants",
    "sap/base/util/deepEqual",
    "sap/ui/model/resource/ResourceModel"
], function(library, jQuery, CardComposite, JSONModel, Device, Constants, deepEqual, ResourceModel) {
    "use strict";

    let ECSWorkspaceCard = CardComposite.extend("sap.me.support.cards.ECSWorkspaceCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                contractType: {type: "int"}
            }
        },
        _CONSTANTS: Constants
    });

    let mECSWorkspaceCard = {};
    ECSWorkspaceCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
    };

    ECSWorkspaceCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        // this card uses an own OData model (the Example Model, so initialize the model and set it to the card)
        oCard.setModel(this._oModel = new JSONModel({
            CustomerContractType: null,
            ecsWorkspaceCardVisible: false
        }), "$" + this.alias + ".ecsWorkspace");
    };

    ECSWorkspaceCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        let cardVisible = false;
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        let sCustomerContractType;

        if (!sCustomerContractType) {
            sCustomerContractType = "CustomerContractType";
        }

        if (sCustomerContractType) {
            if (!mECSWorkspaceCard[sCustomerContractType]) {
                mECSWorkspaceCard[sCustomerContractType] = jQuery.get(this._CONSTANTS.HEC_CUSTOMER_CONTRACT_TYPE);
            }
            mECSWorkspaceCard[sCustomerContractType].then(sCustomerContractType => {
                this._oModel.setProperty("/CustomerContractType", sCustomerContractType);
                cardVisible = (sCustomerContractType !== 10) ? true : false;
                this._oModel.setProperty("/ecsWorkspaceCardVisible", cardVisible);
            });
        }
        return this;
    };

    ECSWorkspaceCard.prototype._handlePress = function() {
        const url = "https://launchpad.support.sap.com/#/hec/ovp";
        sap.m.URLHelper.redirect(url, true);
    };

    ECSWorkspaceCard.prototype.onsapenter = ECSWorkspaceCard.prototype._handlePress;
    if (Device.support.touch) {
        ECSWorkspaceCard.prototype.ontap = ECSWorkspaceCard.prototype._handlePress;
    } else {
        ECSWorkspaceCard.prototype.onclick = ECSWorkspaceCard.prototype._handlePress;
    }

    return ECSWorkspaceCard;
}, /* bExport= */true);

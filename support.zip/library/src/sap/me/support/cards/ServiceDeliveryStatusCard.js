sap.ui.define([
    "../library",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/json/JSONModel"
], function(library, CardComposite, deepEqual, JSONModel
) {
    "use strict";
    const ServiceDeliveryStatusCard = CardComposite.extend("sap.me.support.cards.ServiceDeliveryStatusCard", {
        metadata: {library: "sap.me.support"}
    });

    ServiceDeliveryStatusCard.prototype.setContext = async function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        // mock data
        const model = new JSONModel();
        model.setProperty("/ServiceDeliveryStatusCard", [
            {
                engagement : "SAP Pref. Success",
                service : "Service Plan",
                initiativeProjectDesc : "SuccessFactors Talent Management",
                id : "20123456",
                contact : "Susanne Factor",
                solutionProduct : "SFSF Talent",
                implPartner : "N/A",
                status : "In Process",
                startDate : "02/01/2023",
                endDate : "02/01/2023",
                goLiveDate : ""
            },
            {
                engagement : "SAP MaxAttention",
                service : "Service Plan",
                initiativeProjectDesc : "CBA PE BW TO B4W HANA TRANSFORM",
                id : "20099391",
                contact : "Andrew Gorman",
                solutionProduct : "NetWeaver (PS0)",
                implPartner : "N/A",
                status : "In Process",
                startDate : "",
                endDate : "30/06/2024",
                goLiveDate : "29/06/2024"
            }
        ]);
        this.getCard().setModel(model,"$this.odata");
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        return this;
    };

    return ServiceDeliveryStatusCard;
}, /* bExport= */true);

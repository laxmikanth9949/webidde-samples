sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/me/support/model/formatter",
    "../utils/Constants",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel"
], function(library, jQuery, CardComposite, deepEqual, formatter, Constants, JSONModel, ResourceModel) {
    "use strict";

    let SupportEngagementCard = CardComposite.extend("sap.me.support.cards.SupportEngagementCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: true, group: "Designtime"},
                growingThreshold: {type: "int", defaultValue: 10, group: "Designtime"},
                showRowCount: {type: "boolean", defaultValue: false, group: "Designtime"}
            }
        },
        formatter: formatter,
        _CONSTANTS: Constants
    });

    let mTotalSEngagement = {};
    SupportEngagementCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
    };

    SupportEngagementCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setModel(this._oModel = new JSONModel({}), "$" + this.alias + ".odata");
    };

    SupportEngagementCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext(), oCard = this.oCard;

        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        // oCard.authorizationCheck(oContext.authorization, ["READM"], ["READM_INST"], ["ANLEG"], ["GOSAP"]);
        oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);
        oCard.getTable().bindProperty("visible" ,"{= ${$this>/intrinsicWidth} > ${$this.sizes>/M} }");

        const mockCustomer = oContext.attributes.mockCustomer;
        // const mockCustomer = "0000010039";
        // const mockCustomer = "0000032893";

        // Mock data: SUPPORT_ENGAGEMENT_MOCK
        if (!mTotalSEngagement[mockCustomer]) {
            mTotalSEngagement[mockCustomer] = jQuery.get(this._CONSTANTS.PG_CONTRACT_TYPE, {mockCustomer: mockCustomer});
        }

        this.setBusy(true);
        mTotalSEngagement[mockCustomer].then(oResult => {
            this._oModel.setData(oResult);
            this.setBusy(false);
            this._oModel.refresh();
            this._oModel.updateBindings();
        }).catch(err => {
            // eslint-disable-next-line no-console
            console.error(`${err.status} ${err.statusText}`);
            this.setBusy(false);
        });

        return this;
    };

    SupportEngagementCard.prototype._getSupportEngagementState = function(oEvent) {
        switch (oEvent) {
            case true:
                return "Success";
            case false:
                return "None";
            default:
                return "None";
        }
    };

    SupportEngagementCard.prototype._getSupportEngagementStateText = function(oEvent) {
        switch (oEvent) {
            case true:
                return "ACTIVE";
            case false:
                return "NOT ACTIVE";
            default:
                return "None";
        }
    };

    SupportEngagementCard.prototype.onPressDetails = function(oEvent) {
        let seeDetails = oEvent.getSource().getBindingContext("$this.odata").getObject().ContractTypeLink;
        sap.m.URLHelper.redirect(seeDetails, true);
    };

    SupportEngagementCard.prototype.onUpdateFinished = function() {
        if (!this.bRenderHeader) {
            this.oCard.setTitle("");
        }
    };

    return SupportEngagementCard;
}, /* bExport= */true);

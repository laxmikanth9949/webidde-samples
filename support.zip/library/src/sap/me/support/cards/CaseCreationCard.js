sap.ui.define([
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/model/formatter",
    "sap/me/shared/Models",
    "sap/ui/model/resource/ResourceModel",
    "../utils/helper",
    "sap/ui/core/routing/Router",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/base/Event",
    "sap/m/Button",
    "sap/me/support/fragments/CreateSelectCustomerDialog",
    "sap/me/support/fragments/CreateSelectSUserDialog",
    "sap/me/support/utils/InfoExchange",
    "sap/me/support/fragments/CreateSelectComponentDialog",
    "sap/me/support/utils/Constants",
    "sap/me/support/utils/OpenDraftHelper",
    "sap/me/support/fragments/CaseCreationSAC",
    "sap/me/support/utils/SAEHelper",
    "sap/me/support/utils/CreationHelper",
    "sap/m/Dialog",
    "sap/m/FormattedText",
    "sap/m/library",
    "sap/me/support/utils/ServiceMonitor",
    "sap/me/support/fragments/CaseCreationExpertChatDialog",
    "sap/me/support/utils/QualtricsService",
    "sap/me/support/utils/PrefillHelper",
    "sap/me/support/utils/AaEPService",
    "sap/me/support/utils/CreationServiceMonitorEvents",
    "sap/me/support/utils/AdvancedJSONModel",
    "sap/me/support/utils/SaveMsgEventBus",
    "sap/me/support/utils/CreationEventType",
    "./caseCreationCards/FragmentLibrary",
    "sap/me/shared/FeatureToggles",
    "sap/me/shared/util/getBrowserTabId",
    "sap/me/shared/util/getApplicationInstanceId",
    "sap/me/support/utils/ServiceNowExpertChat",
    "sap/me/support/fragments/caseCreationLayout/TimeLineLayout",
    "sap/me/shared/util/getPreferredLanguage",
    "sap/me/support/utils/CoveoUtil",
    "sap/me/support/utils/DetailPageCacheUtil",
    "sap/ui/core/library",
    "sap/me/support/utils/engineerMemo/index"
], function(
    jQuery,
    CardComposite,
    deepEqual,
    ODataModel,
    JSONModel,
    formatter,
    SharedModels,
    ResourceModel,
    helper,
    Router,
    MessageToast,
    MessageBox,
    Event,
    Button,
    CreateSelectCustomerDialog,
    CreateSelectSUserDialog,
    InfoExchange,
    CreateSelectComponentDialog,
    Constants,
    OpenDraftHelper,
    CaseCreationSAC,
    SAEHelper,
    CreationHelper,
    Dialog,
    FormattedText,
    mobileLibrary,
    ServiceMonitor,
    CaseCreationExpertChatDialog,
    QualtricsService,
    PrefillHelper,
    AaEPService,
    CreationServiceMonitorEvents,
    AdvancedJSONModel,
    SaveMsgEventBus,
    CreationEventType,
    FragmentLibrary,
    FeatureToggles,
    getBrowserTabId,
    getApplicationInstanceId,
    ServiceNowExpertChat,
    TimeLineLayout,
    getPreferredLanguage,
    CoveoUtil,
    DetailPageCacheUtil,
    CoreLib,
    engineerMemo,
) {
    "use strict";
    const {ProductFunctionMemoUtil, ComponentMemoUtil, MemoAction} = engineerMemo;
    /**
     * @class
     */
    let CaseCreationCard = CardComposite.extend("sap.me.support.cards.CaseCreationCard", {
        metadata: {library: "sap.me.support"},

        _oBindingContext: null,
        formatter: formatter
    });

    CaseCreationCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);

        // this part is for router leave lifecycle
        this._oRouter = Router.getRouter("shellRouter");
        this._currentHash = this._oRouter.getHashChanger().getHash();
        this._toRoute = {
            name: "dashboard",
            arguments: {
                nameOrId: "servicessupport"
            }
        };

        this.oCard = this.getCard();
        this._oEventBus = sap.ui.getCore().getEventBus();
        this.currentCardPageView = this.oCard.getContent().getItems()[2];
        this._oCaseCreationSAC = CaseCreationSAC;
        this.constructProcessBarData();
        this.setupStepViews();
        this._addRoutePatternMatchedListener();

        // swa service
        this.swaService = new ServiceMonitor({eventPrefix:"SFM-CaseForm-"});
        this._oSelectionMethodRecordsTxt = "";

        // coveo search
        this.coveoUtil = new CoveoUtil(this.oCard);
        this.coveoUtil.initCoveoSearch();

    };

    CaseCreationCard.prototype.setupTimeLineView = function() {
        const container = this.byId("timeLineContainer");
        container.removeAllItems();
        if (!this.timeLineLayoutControl) {
            this.timeLineLayoutControl = new TimeLineLayout(this);
        }
        this.timeLineLayoutFragment = this.timeLineLayoutControl.getFragment();
        this.timeLineLayoutControl.clearData();
        container.addItem(this.timeLineLayoutFragment);
    };

    CaseCreationCard.prototype.setupEachFragmentStep = function(fragmentStepClassName, frag, controller) {
        const shortName = fragmentStepClassName.replace("sap.me.support.cards.caseCreationCards.", "");
        if (!this.fragmentControllers) {
            this.fragmentControllers = {};
        }
        this.fragmentControllers[shortName]?.destroy();
        this.fragmentControllers[shortName] = controller;
        this.getCard().setModel(controller.dataModel, shortName + "DataModel");
        this.getCard().setModel(controller.computedModel, shortName + "ComputedModel");
        controller.init();

        switch (shortName) {
            case "Step0":
                break;
            case "BasicInformationStep":
                this._issueInformationPart = frag;
                if (this.compURLPrefillMode && this.selectComponent) {
                    this.handleIssueProductInputVisibility(false);
                    controller.data.component.info = this.selectComponent;
                }
                this._priorityAndImpactVBox = controller._priorityAndImpactVBox;
                this._oPriorityAndImpactCreateController = controller._oPriorityAndImpactCreateController;
                break;
            case "BestActionStep":
                this._bestActionPart = frag;
                break;
            case "CaseCreationAttachmentStep":
                this._attachmentPart = frag;
                this.fragmentControllers.CaseCreationAttachmentStep.clearAll();
                this.fragmentControllers.CaseCreationAttachmentStep.restFileTypeList();
                break;
            // case "CaseCreationAppointmentInformationStep":
            //     this._appointmentInformationPart = frag;
            //     break;
            case "SubmitStep":
                this._submitPart = frag;
                break;
            case "CaseCreationContactStep":
                this._contactPart = frag;
                this._oCaseContactCreationController = controller.contactCreationController;
                break;
            case "CaseCreationDetailedInformationStep":
                this._detailedInformationPart = frag;
                this.oReproduceStepsRichTextEditor = sap.ui.getCore().byId("CaseCreationDetailedInformationStep--stepToReproduceStepsRichTextEditor");
                this.oDetailedDescriptionRichTextEditor = sap.ui.getCore().byId("CaseCreationDetailedInformationStep--detailedDescriptionRichTextEditor");
                break;
            // case "CaseCreationAribaQA":
            //     this.aribaQuestionAribaQAPart = frag;
            //     break;
        }
    };

    CaseCreationCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");

        oCard.setModel(this._oContinueButtonModel = new JSONModel({
            isContinueButtonEnabled: false,
        }), "continueButtonEnabled");

        oCard.setModel(this._oMissAuthPanelModel = new JSONModel({
            isMissAuthPanelVisible: false
        }), "missAuthPanelVisible");


        // this._constructTimeLineModel(oCard);
        // this.setupTimeLineView();

        this.departmentInChannelData = {};

        /**
         * TODO: Initialize saved data for each step.
         */
        oCard.setModel(new ODataModel({
            serviceUrl: "/backend/odata/support/",
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        }),"$this.odata");

        this._constructIssueInformationModel(oCard);

        oCard.setModel(this._oSystemInformationModel = new JSONModel({
            SystemInformationVBox:false,
            isSystemDetailVisible:false,
            isMessageStripVisible:false,
            isMessageStripAttachVisible:false,
            isSystemAccessDataVisible:false,
            isSystemConnectionVisible:false,
            isSystemDProcessRestrictionVisible:false,
            sTextAccessData:"",
            sLinkAccessData:"",
            sHrefAccessData:"",
            sProcessRestrictionData:"",
            sTextSystemConnection:"",
            sLinkSystemConnection:"",
            sHrefSystemConnection:"",
            accessDataMaintained:true,
            connectionOpen:true,
            smaintainedconnections:"",
            suploadedconnection:"",
            systemDetailLink:"",
            RampUpFlagVisible:false,
            isClassifiedContentButtonVisible: false,
            isClassifiedContentButtonEnabled: true,
            isSystemCloud:"",
            isSystemURLVisible:false,
            sSystemURL : "",
        }), "$this.systemInformation");

        this._constructProductModel(oCard);

        oCard.setModel(this._oProductFunctionModel = new JSONModel({
            allProductFunctions:[],
            // The following fields are all bound within the selection box
            all: [],
            suggest: [],
            searchList: [],
            suggestModelNumber: [],
            recommendedModelNumbers: undefined,
            productFunctionInputBusy: false,
            isProductFnSearchTabVisible: false
        }), "productFunctionList");
        this._oProductFunctionModel.setSizeLimit(10000);

        this._constructCompModel(oCard);

        oCard.setModel(this._oTextDescriptionModel = new JSONModel({
            title: "",
            reminder: "",
            isShowCompWarning: false
        }),"textDescription");

        oCard.setModel(this._oRecommendedSolutionModel = new JSONModel({
            all: [],
            isShow: false
        }),"recommendedSolutionList");

        oCard.setModel(this._oHotAndTrendingModel = new JSONModel({
            all: [],
            isShow: false,
            criticalList: []
        }),"hotAndTrendingList");

        oCard.setModel(this._oCoveoRecommendationsModel = new JSONModel({
            all: [],
            isShow: false
        }),"coveoRecommendationList");

        oCard.setModel(this._oSACContentRecommendationsModel = new JSONModel({
            all: [],
            isShow: false
        }),"sacContentRecommendationsList");

        oCard.setModel(this._oRightSideAllKindsListModel = new JSONModel({
            isShowHotAndTrending: true,
            isShowCoveoRecommendations: false,
            isShowRecommendedSolution: false,
            isShowSACRecommendations: false,
        }),"rightSideAllKindsListVisibleControl");

        oCard.setModel(this.creationCardViewModel = new JSONModel({
            leftPartWidth : "15rem",
            leftPartVisible : true,
            dividingLineWidth : "1%",
            dividingLineVisible : true,
            middlePartWidth : "55%",
            middlePartVisible : true,
            rightPartWidth : "calc(44% - 15rem)",
            rightPartVisible : true,
            currentStepName : "BasicInformationStep"
        }),"creationCardView");

        oCard.setModel(this._channelListEventSentModel = new JSONModel({
            isSent: false,
            sentMethod: ""
        }),"_channelListEventSentModel");

        oCard.setModel(this._slaFilesEventSentModel = new JSONModel({
            isSent: false,
            sentMethod: ""
        }),"_slaFilesEventSentModel");

        this._oUserProfileInfoModel = new JSONModel({
            recentProductList: [],
            recentProductFunctionList: [],
            phone: "",
        });

        this._oExpertChatVarModel = new JSONModel({
            // will be used in expert chat
            communicationStarted: false,
            bIssueSolved: false
        });

        this._oUserModel = SharedModels.getUserModel();
        this._oCustomerModel = SharedModels.getCustomerModel();

        const userName = SharedModels.getUser()?.userName;
        const userTypeSuffix = userName?.slice(-2) < 50 ? "_A" : "_B";

        this._oTrackingData = {
            session_id: "",
            page_id: getBrowserTabId(),
            page_url: window.location.href,
            init_select_data: {
                product: "",
                product_init_flag: true,
                product_selected_type: "",
                product_function: "",
                product_function_init_flag: true,
                product_function_selected_type: "",
                sac_node_id: "",
                proudctSuggestList: []
            },
            user_type: this._oCustomerModel.getData().type + userTypeSuffix
        };
        // for ISM solution
        this._cacheSacQuestionList = [];
        this._cacheSACAnswerMap = {};

        this.setupStepViews();
        this._oCurrentProcess = this._oProcessBarIssueStepIndex;

    };

    CaseCreationCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        this._oSimulatedUser = oContext.user?.simulatedUser ?? "";
        this._selectCustomerDialog = new CreateSelectCustomerDialog(this);
        this._selectSuserDialog = new CreateSelectSUserDialog(this);
        this._systemSelectDialog = this.fragmentControllers.BasicInformationStep?._systemSelectDialog;

        // init timeline for language select
        this.onLanguageChange();

        // set system dialog disabled when no customer selected
        !this._selectCustomerDialog.getCustomerModel() && sap.ui.getCore().byId("BasicInformationStepFragment--sapMeCreationSystemInputControl").setEditable(false);
        // watch the customer&suser data
        if (!this._oEventBus._mChannels["sap.me.support.fragments.CreateReportAnIssueHeaderController"]?.mEventRegistry?.clearAllData) {
            this._oEventBus.subscribe("sap.me.support.fragments.CreateReportAnIssueHeaderController", "clearAllData", (pListener, identifier, params) => {
                // not first time to load the page
                if (!params.isFromHeader) {
                    // if enter case creation from reportcase card, this can be execute
                    this._selectCustomerDialog.setCustomerModel(new JSONModel());
                    this._selectSuserDialog.setSuserModel(new JSONModel());
                }
                this.initSystemSelectDialogInfo();
                this.compURLPrefillMode = this.getCaseCreationMode() === Constants.CASE_CREATION_CASE_MODE.COMP_PREFILL && PrefillHelper.isComponentValid;
                // reset all data
                this.clearData();
                this.gotoDefaultStepAfterClearData();
                this.deleteDraft();
                CaseCreationSAC.mapList?.clear();
            });
        }

        this.getUserProfileInfo();
        return this;
    };

    CaseCreationCard.prototype.onAfterRendering = function() {
        console.log("card onAfterRendering");
        // open the draft dialog after case creation card has been rendered
        CardComposite.prototype.onAfterRendering.call(this);
        if (!this.isNavByRouterEvent) {
            this.constructSelectionMethodRecords();
            this.setupStepViews();
            InfoExchange.initInfoExchange(this, "caseCreationInfoExchange");
            this.swaServiceEvent = CreationServiceMonitorEvents.initConfig(this);
            this.initCreationMode();
            // SWA Custom Event start
            if (!window?.adobeOpenDraftParams?.session_id) {
                this.swaService.populateIncidentEventLayer("incidentStart","");
                this.swaService.triggerAdobeNonPageView();
                this._oTrackingData.session_id = getApplicationInstanceId("getSupport",true);
                this.swaServiceEvent.swaCaseCreationStart(false);
            } else {
                this._oTrackingData.session_id = window?.adobeOpenDraftParams?.session_id;
                this.swaServiceEvent.swaCaseCreationStart(true);
                window.adobeOpenDraftParams = {session_id:undefined};
            }
            this.isNavByRouterEvent = true;
            this.resetProductAndProductFunctionInitiallySelected();
        }
        this._addRoutePatternMatchedListener();
        const pointer = this._oIssueInformationModel.getProperty("/pointer");
        DetailPageCacheUtil.clearAllDetailCaches(pointer);
    };


    CaseCreationCard.prototype.setupStepViews = function() {
        this.setupTimeLineView();
        const container = this.byId("sapMeCaseCreationStepContainer");
        container.removeAllItems();
        for (const fragControl of FragmentLibrary) {
            const ctrl = new fragControl(this);
            const frag = ctrl.getFragment();
            container.addItem(frag);
            this.timeLineLayoutControl.addTimelineItem(ctrl.timeLineItem);
            this.setupEachFragmentStep(ctrl.getMetadata()._sClassName, frag, ctrl);
        }
        this.constructProcessBarData();
    };

    /**
     * This is the lifecycle which will be called before router leave case creation card
     * @param from {RouteInfo}
     * @param to {RouteInfo}
     * @param {function(RouteInfo?)} next
     */
    CaseCreationCard.prototype.onBeforeRouterLeave = function(from, to, next) {
        // jump between create case and draft case
        if (from.name === to.name && to.name === "dashboardCreateIssue") {
            // create case --> draft case
            if (from.arguments.draftCasePointer === "0" && to.arguments.draftCasePointer !== "0") {
                next();
                return;
            }
            // draft case --> create case: jump to service support page
            if (from.arguments.draftCasePointer !== "0" && to.arguments.draftCasePointer === "0") {
                next({
                    name: "dashboard",
                    arguments: {
                        nameOrId: "servicessupport"
                    }
                });
                return;
            }
        }
        this.isSolvedProblemDialog();
    };

    CaseCreationCard.prototype._constructIssueInformationModel = function(oCard) {
        const defaultValue = {
            "pointer":"",
            "impactText": undefined,
            "contacts": undefined,
            "installationData": null,
            "isSystemCloud": null
        };
        if (!this._oIssueInformationModel) {
            this._oIssueInformationModel = new AdvancedJSONModel();
            oCard.setModel(this._oIssueInformationModel, "$this.issueInformation");
        }
        this._oIssueInformationModel.setData(defaultValue);

    };

    CaseCreationCard.prototype._constructCompModel = function(oCard) {
        oCard.setModel(this._oComponentModel = new JSONModel({
            all: [],
            rec: [],
            search: [],
            suggest: [],
            suggestNameList: [],
            recentNameList: [],
            isSearchTabVisible: false
        }),"componentList");
        this._oComponentModel.setSizeLimit(10000);
    };

    CaseCreationCard.prototype._constructProductModel = function(oCard) {
        oCard.setModel(this._oProductModel = new JSONModel({
            allData: [],
            productFilters: [],
            softerFilters: [],
            relationshipTypeFilters: [],
            recommendedModelNumbers: undefined,
            productInputBusy: false
        }), "productList");
    };

    /** ************************************************************************************** */
    /*                                        Constructors                                    */
    /** ************************************************************************************** */

    /**
     * Initialize number of total mandatory fields for each step.
     */
    CaseCreationCard.prototype.constructProcessBarData = function() {
        // this._oProcessBarIssueStepIndex = 0;
        // this._oProcessBarActionStepIndex = 1;
        // this._oProcessBarDetailedStepIndex = 2;
        // this._oProcessBarAttachmentsStepIndex = 3;
        // this._oProcessBarContactsStepIndex = 4;
        // this._oProcessBarAppointmentInformationStepIndex = 5;
        // this._oProcessBarSubmitStepIndex = 6;

        this.totalProcessBarStepsCount = this.timeLineLayoutControl.data.timeLineItems.length;
        this._oProcessBarIssueStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("BasicInformationStep");
        this._oProcessBarAribaStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("CaseCreationAribaQA");
        this._oProcessBarActionStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("BestActionStep");
        this._oProcessBarDetailedStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("CaseCreationDetailedInformationStep");
        this._oProcessBarAttachmentsStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("CaseCreationAttachmentStep");
        this._oProcessBarContactsStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("CaseCreationContactStep");
        this._oProcessBarAppointmentInformationStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("CaseCreationAppointmentInformationStep");
        this._oProcessBarSubmitStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("SubmitStep");
        this._oProcessBarCommunityStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("CommunityStep");
    };

    /**
     * @typedef {Object} SelectionMethodRecord
     * @property {string} name product/productfunction/component (ppfc) name
     * @property {string} prefix predict/userSelect/userChange/normalPrefix, explains how the ppfc was selected
     * @property {string} suffix pfSuffix/sac/recommended/recent/recommended&recent/url/compChange/normalSuffix, explains what causes the ppfc was selected
     * @property {string} root ppfc's subject, first letter is capitalized depends on if prefix exists
     * @property {string} placeholder when no p or pf selected, popping a no p/pf was seleted record as the placeholder
     */
    CaseCreationCard.prototype.constructSelectionMethodRecords = function() {
        /**
         * @type {SelectionMethodRecord[]}
         * @private
         */
        this._oSelectionMethodRecords = [];
        if (this._oIssueInformationModel?.getProperty("/pointer")) {
            if (this._draftPointer !== this._oIssueInformationModel?.getProperty("/pointer")) {
                this._oSelectionMethodRecordsTxt = "";
            }
        }
    };

    /**
     * Draft Case - fill draft data
     * Prefill Case - fill data by URL search query
     * Normal Case - Open draft Select Dialog
     */
    CaseCreationCard.prototype.initCreationMode = function() {
        const creationMode = this.getCaseCreationMode();
        this.compURLPrefillMode = false;
        if (creationMode === Constants.CASE_CREATION_CASE_MODE.DRAFT) {
            OpenDraftHelper.init(this);
        } else if (creationMode === Constants.CASE_CREATION_CASE_MODE.SYS_PREFILL || creationMode === Constants.CASE_CREATION_CASE_MODE.COMP_PREFILL) {
            PrefillHelper.init(this);
        } else {
            // TODO-refactor: the event bus to new ExistingDraftDialog()
            this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", "openDraftList");
            // this.openExistingDraftDialog();
        }
    };

    /**
     * prepare customer and suser data for system dialog selection
     */
    CaseCreationCard.prototype.initSystemSelectDialogInfo = function() {
        const systemSelectionPart = sap.ui.getCore().byId("BasicInformationStepFragment--sapMeCreationSystemInputControl");
        if (Object.keys(this._selectCustomerDialog.getCustomerModel()?.getData() || {}).length) {
            systemSelectionPart.setEditable(true);
            const customerNum = this.getModel("headerCustomerInfo").getData().customerNum;
            const suserNumber = this.getModel("headerSuserInfo").getData().suserNumber;
            this.selectedCutAndSuserInfo = {customerNum: customerNum, suserNumber: suserNumber};
            this._systemSelectDialog.getRecentAndFavList();
        } else {
            systemSelectionPart.setEditable(false);
        }

    };
    /**
     * Process language code for Qualtrics parameter
     */
    CaseCreationCard.prototype.processLanguageCode = function() {
        let preferredLang = getPreferredLanguage();
        let lang = preferredLang ? preferredLang.toUpperCase() : sap.ui.core.Configuration.getLanguage().toUpperCase();
        let qualtricsLangList = {
            DE: "DE",
            JA: "JA",
            "ZH-CN": "ZH-S",
            ZH_CN:"ZH-S",
            "ZH-S": "ZH-S",
            FR : "FR",
            ES : "ES",
            PT : "PT"
        };
        return qualtricsLangList[lang] || "EN";
    };
    /**
     * compose Qualtrics parameters
     * @param {string} sSurveyType SCENARIO2/SCENARIO3
     * @param {boolean} isSolved
     * SCENARIO2 -> exit process
     * SCENARIO3 -> submit process
     */
    CaseCreationCard.prototype.initFeedBackSurvey = function(sSurveyType, isSolved) {

        this._oPointer = this._oIssueInformationModel.getProperty("/pointer");
        this._sProduct = this.fragmentControllers.BasicInformationStep.data.product.info?.FullName;
        this._sProductArea = this.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber;

        this._sProductFunction = this.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber;

        let currentDate = new Date().toISOString();
        let mParams = {
            CrmCustomerID: this._oCustomerModel.getProperty("/crmcustomernumber"),
            CaseId: +this._oPointer.slice(10, 20) + "/" + this._oPointer.slice(-4),
            Pointer: this._oPointer,
            Language: this.processLanguageCode(),
            source: sSurveyType,
            Subject: this.fragmentControllers.BasicInformationStep.data.shortDesc,
            CustomerEmail: this._oCustomerModel.getProperty("/email"),
            CustomerPhoneNumber: this._oCustomerModel.getProperty("/phone"),
            OpenedDate: currentDate,
            ComponentName: this.fragmentControllers.BasicInformationStep.data.component.info?.CompName,
            ComponentKey:  this.fragmentControllers.BasicInformationStep.data.component.info?.CompKey,
            CasePriority: this.fragmentControllers.BasicInformationStep.data.priority.value,
            Country: this._oCustomerModel.getProperty("/country"),
            CompanyName: this._oCustomerModel.getProperty("/companyname"),
            UserName: this._oCustomerModel.getProperty("/userName"),
            product: this._sProduct,
            productArea: this._sProductArea,
            productFunction: this._sProductFunction,
            SLAUsed: this.attachmentService.SupportLogAssistantUsed ? "Y" : "N",
            SAUsed: this.isSupportAssistantUsed ? "Y" : "N",
            APP_INSTANCE_ID: this._oTrackingData.session_id,
            BROWSER_TAB_ID: this._oTrackingData.page_id
        };

        if (window.QLT_LAUNCHPAD_PARAM) {
            delete window.QLT_LAUNCHPAD_PARAM;
        }

        if (sSurveyType === "SCENARIO2") {
            // if a case was created previously and the SIS survey was called clear window.QLT_MMI2S_PARAM
            if (window.QLT_MMI2S_PARAM) {
                delete window.QLT_MMI2S_PARAM;
            }
            mParams.Solved = isSolved ? "Y" : "N";
            window.QLT_MMI1S_PARAM = mParams;
        } else {
            // if an exit with case survey was called clear window.QLT_MMI1S_PARAM
            if (window.QLT_MMI1S_PARAM) {
                delete window.QLT_MMI1S_PARAM;
            }
            window.QLT_MMI2S_PARAM = mParams;
        }
        // Logic for calling zoneid from backend
        /*
        var that = this;
        $.ajax ("/backend/raw/support/CaseQualtricsAuthW7?pointer=" + this._oPointer, {
            method: "GET",
            contentType: "application/json"
        }).done ((url) => {
            if (url) {
                QualtricsService.initQualtricsSurvey (url, this)
                    .then (function () {
                        that.openQualtricsIntercept (sSurveyType);
                    });

            }
        }).fail (() => {
            //do nothing just let it go
        });
  */


    };
    /** ************************************************************************************** */
    /*                                         Event Handlers                                 */
    /** ************************************************************************************** */

    CaseCreationCard.prototype.onProcessPreviewEditButtonPressed = function(oEvent, targetProcessStep) {
        /**
         * If current step's title button is pressed, then nothing happens.
         */
        if (this._oCurrentProcess === targetProcessStep) {
            return;
        }

        /**
         * Set the input part's display.
         */
        // this.setTargetPartVisible(targetProcessStep);
        this.handleRightSideRecommendVisibleByPreview(targetProcessStep);
        /**
         * Set progress indicator visibility for other steps and set icons for other steps.
         */
        this.refreshProcessBarDisplay(targetProcessStep);

        /**
         * Go to target step.
         */
        this._oCurrentProcess = targetProcessStep;
        this.setIntervalToChannelRecommender();
    };

    CaseCreationCard.prototype.onOpenQuestionPressed = function() {
        if(!FeatureToggles.get("feature-support-cummunity-step-enable")){
            this.coveoUtil.sendCoveoAnalytics("CreateCase", "OpenQuestion", this._oIssueInformationModel.getData(), true, this.fragmentControllers.BasicInformationStep.data);
            const communityUrl = this._oBestActionModel.getProperty("/openCommunityTargetLink");
            // sap.m.URLHelper.redirect (Constants.CASE_CREATION_COMMUNITY_QUSTION_URL, true);
            sap.m.URLHelper.redirect(communityUrl, true);
            return;
        }

        this.timeLineLayoutControl.onProcessPreviewEditButtonPressed(null, this._oProcessBarCommunityStepIndex);
        this.timeLineLayoutControl.data.timeLineItems.forEach((item, index) => {
            if(index < this._oProcessBarCommunityStepIndex){
                item.timeLineIcon = "sap-icon://sys-enter-2";
            }else if(index === this._oProcessBarCommunityStepIndex){
                item.timeLineIcon = "sap-icon://overlay";
            }
            if(index > this._oProcessBarCommunityStepIndex){
                item.isStepVisible = false;
            }
        });
    };

    CaseCreationCard.prototype.onFindMoreButtonPressed = function() {
        let redirectionUrl = "";
        let coveoRedirectUrl = "";
        if (helper.isDev) {
            redirectionUrl = Constants.CASE_CREATION_FIND_MORE_REDIRECT_URL_DEV;
            coveoRedirectUrl = Constants.CASE_CREATION_FIND_MORE_COVEO_REDIRECT_URL_DEV;
        } else if (helper.isTest) {
            redirectionUrl = Constants.CASE_CREATION_FIND_MORE_REDIRECT_URL_TEST;
            coveoRedirectUrl = Constants.CASE_CREATION_FIND_MORE_COVEO_REDIRECT_URL_TEST;
        } else {
            redirectionUrl = Constants.CASE_CREATION_FIND_MORE_REDIRECT_URL_PRD;
            coveoRedirectUrl = Constants.CASE_CREATION_FIND_MORE_COVEO_REDIRECT_URL_PRD;
        }
        if (this._oCurrentProcess === this._oProcessBarActionStepIndex && FeatureToggles.get("feature-support-coveo-search")) {
            const productName = this.fragmentControllers.BasicInformationStep.data.product.info?.DisplayName.trim();
            const jsonStructure = {
                tab: "All",
                f: {
                    mh_product: [productName]
                }
            };
            redirectionUrl = coveoRedirectUrl + encodeURIComponent(JSON.stringify(jsonStructure));
        }
        sap.m.URLHelper.redirect(redirectionUrl, true);
    };

    CaseCreationCard.prototype.onFindMoreButtonAnalysisReportPressed = function() {
        this.fragmentControllers.CaseCreationAttachmentStep.onDisplayAnalysisDetailsButtonPress();
    };

    CaseCreationCard.prototype.onSLASolutionLinkPressed = function(oEvent) {
        this.swaServiceEvent.slaSolutionClicked(oEvent);
    };

    /** ************************************************************************************** */
    /*                                    Handlers' Functions                                 */
    /** ************************************************************************************** */
    CaseCreationCard.prototype.gotoDefaultStepAfterClearData = function() {
        this._oCurrentProcess = this._oProcessBarIssueStepIndex;
        if (this._oPriorityAndImpactCreateController) {
            this._oPriorityAndImpactCreateController.priorityReminderVBox?.setVisible(false);
        }
        this.getUserProfileInfo();
        this.setupStepViews();

        // clear product search bar data
        this.fragmentControllers.BasicInformationStep._productSelectDialog?.clearPreviousSystemInfo();

        // clear product function search bar data
        this.fragmentControllers.BasicInformationStep._productFunctionSelectDialog?.clearPreviousProduct();

        // clear ariba Q&A data
        this.fragmentControllers.CaseCreationAribaQA.clearAribaQAData();
    },


    CaseCreationCard.prototype.clearData = function() {
        // clear aaep select status, set it to not selected
        this.aaepClosedByPoster = false;
        !this.compURLPrefillMode && PrefillHelper.clearPrefillData();
        for (const key in this.fragmentControllers) {
            this.fragmentControllers[key]?.clearData();
        }
        this.clearCreationCardModel();
        this.reSetRightSideAllKindsList();
    };

    CaseCreationCard.prototype.clearCreationCardModel = function () {
        this._oCurrentProcess = this._oProcessBarIssueStepIndex;
        // should reset continue card model in creationCard, Otherwise it show save draft dialog in step0
        this._oContinueButtonModel?.setData({
            isContinueButtonEnabled: false,
        });
        // should reset creationCardViewModel, Otherwise it will hide solutions part as submit step in last time.
        this.creationCardViewModel?.setData({
            leftPartWidth : "15rem",
            leftPartVisible : true,
            dividingLineWidth : "1%",
            dividingLineVisible : true,
            middlePartWidth : "55%",
            middlePartVisible : true,
            rightPartWidth : "calc(44% - 15rem)",
            rightPartVisible : true,
            currentStepName : "BasicInformationStep"
        });
    };

    CaseCreationCard.prototype.clearSACFormerData = function() {
        CaseCreationSAC.firstTimeIn = true;
        CaseCreationSAC.setRecommendedComponent("");
        this.isSupportAssistantUsed = false;
    };

    /**
     * @param {int} oTargetProcess - The process whose title button is pressed and is about to jump to.
     * @description - Refresh the timeline's (aka the process bar on the left) display.
     */
    CaseCreationCard.prototype.refreshProcessBarDisplay = function(oTargetProcess) {
        // return
        const latestEditProcess = this.timeLineLayoutControl.data.lastEditStepIndex;

        /**
         * Set continue button's availability
         */
        if (latestEditProcess === oTargetProcess) {
            switch (latestEditProcess) {
                case this._oProcessBarIssueStepIndex:
                    this.fragmentControllers.BasicInformationStep.setIssueContinueButtonEnabled();
                    break;
                case this._oProcessBarDetailedStepIndex:
                    break;
                case this._oProcessBarAppointmentInformationStepIndex:
                    // Occurs when from "contact" step to "appointment information" step
                    this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", this.fragmentControllers.CaseCreationAppointmentInformationStep.checkAppointmentInformationFinishedInput());
                    break;
                case this._oProcessBarSubmitStepIndex:
                    if (this._channelText === this._i18n.getText("case_creation_best_action_expert_chat")) {
                        this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", CreationHelper.selectedCustomerIsSupported() ? false : this._expertChatChannel.getProperty("/isExpertChatAvailable"));
                    } else {
                        this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", true);
                    }
                    break;
                default:
                    this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", true);
                    break;
            }
        } else if (oTargetProcess === this._oProcessBarAppointmentInformationStepIndex) {
            // Occurs when from "submit" step to "appointment information" step
            // AKA click "SAE" button in submit step
            this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", this.fragmentControllers.CaseCreationAppointmentInformationStep.checkAppointmentInformationFinishedInput());
        } else {
            this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", true);
        }

        if (oTargetProcess === this._oProcessBarSubmitStepIndex && this._channelText === this._i18n.getText("case_creation_best_action_expert_chat")) {
            this._expertChatChannel.setProperty("/isShowExpertChatStatusTextInSubmit", true);
        }
        if (oTargetProcess === this._oProcessBarDetailedStepIndex) {
            const sacValue = this.getCard().getModel("$this.detailedInformation").getProperty("/sacInfo/value");
            if (this._channelText === this._i18n.getText("case_creation_best_action_expert_peer")) {
                sap.ui.getCore().byId("CaseCreationDetailedInformationStep--sapMeSACQuestionListBox").setVisible(false);
                sap.ui.getCore().byId("CaseCreationDetailedInformationStep--sapMeSACQuestionLeafNodeListBox").setVisible(false);
            } else if (this.getCaseCreationMode() !== Constants.CASE_CREATION_CASE_MODE.DRAFT || !sacValue || sacValue.length === 0) {
                sap.ui.getCore().byId("CaseCreationDetailedInformationStep--sapMeSACQuestionListBox").setVisible(true);
                sap.ui.getCore().byId("CaseCreationDetailedInformationStep--sapMeSACQuestionLeafNodeListBox").setVisible(true);
                CaseCreationSAC.onSACDialogOpen(this);
            }
            this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", this.fragmentControllers.CaseCreationDetailedInformationStep.data.isProgressFinished);
        }

        /**
         * Set contact button's visibility
         */
        this.fragmentControllers.CaseCreationAttachmentStep.data.isContinueToAddButtonVisible = oTargetProcess === this._oProcessBarAttachmentsStepIndex && this.attachmentService.attachmentsInfo.length !== 0

        // show no appointment button in sae step
        const appointmentInformationModel = this.getCard().getModel("$this.appointmentInformation");
        appointmentInformationModel.setProperty("/isNoAppointmentButtonVisible", appointmentInformationModel.getProperty("/isAppointmentInformationVisible") && oTargetProcess === this._oProcessBarAppointmentInformationStepIndex);
    };

    CaseCreationCard.prototype._resetTimeLineToFirstStep = function() {
        this._handleSaeStepAndClearChannelText();
        const basicInformationStepIndex = this.timeLineLayoutControl.getTimeLineItemIndex("BasicInformationStep");

        this.timeLineLayoutControl.data.timeLineItems.forEach((item, index) => {
            item.isStepVisible = index <= basicInformationStepIndex;
        });
        const bestActionIndex = this.timeLineLayoutControl.getTimeLineItemIndex("BestActionStep");
        this.timeLineLayoutControl.data.timeLineItems[bestActionIndex].isStepPreviewEditEnabled = false;
        this.timeLineLayoutControl.data.timeLineItems[bestActionIndex].isStepVisible = true;
        this.timeLineLayoutControl.setProcessStatusInProcessBar(bestActionIndex, "T");
        this.timeLineLayoutControl.updateTimeLineItemsModel();
    };

    CaseCreationCard.prototype._setTimeLineToCreateCase = async function() {
        const detailInfoStepIndex = this._oProcessBarDetailedStepIndex;
        const appointmentInformatioStepIndex = this._oProcessBarAppointmentInformationStepIndex;
        const aribaStepIndex = this._oProcessBarAribaStepIndex;
        const attachmentsStepIndex = this._oProcessBarAttachmentsStepIndex;
        const submitStepIndex = this._oProcessBarSubmitStepIndex;
        const contactsStepIndex = this._oProcessBarContactsStepIndex;

        this.timeLineLayoutControl.data.timeLineItems.forEach((item, index) => {
            item.isStepVisible = true;
            item.isStepPreviewEditEnabled = index <= detailInfoStepIndex;
        });

        this.timeLineLayoutControl.data.timeLineItems[appointmentInformatioStepIndex].isStepVisible = false;
        this.timeLineLayoutControl.data.timeLineItems[aribaStepIndex].isStepVisible = false;
        this.timeLineLayoutControl.data.timeLineItems[this._oProcessBarCommunityStepIndex].isStepVisible = false;

        //jira 7211 fix bug: should enable preview button when create case select in last step
        if (this._oCurrentProcess === submitStepIndex) {
            this.timeLineLayoutControl.data.timeLineItems[attachmentsStepIndex].isStepPreviewEditEnabled = true;
            this.timeLineLayoutControl.data.timeLineItems[contactsStepIndex].isStepPreviewEditEnabled = true;
            this.timeLineLayoutControl.data.timeLineItems[submitStepIndex].isStepPreviewEditEnabled = true;
        }

        if (this.fragmentControllers.CaseCreationDetailedInformationStep.isProgressFinished) {
            for (let i = detailInfoStepIndex + 1; i < this.timeLineLayoutControl.data.timeLineItems.length; i++) {
                this.timeLineLayoutControl.data.timeLineItems[i].isStepPreviewEditEnabled = true;
            }
        }

        const isShowAriba = await this.fragmentControllers.CaseCreationAribaQA.isInitAribaQuestions();
        if (isShowAriba) {
            this.timeLineLayoutControl.data.timeLineItems[aribaStepIndex].isStepVisible = true;
        }
        // this func for clear sae step
        this._handleSaeStepAndClearChannelText();
        this._setBestChannelText(this._i18n.getText("case_creation_best_action_create_a_case"));

        this.timeLineLayoutControl.updateTimeLineItemsModel();
    };

    CaseCreationCard.prototype._setCreationCardToCreateCaseStatus = function(spaceFlag) {
        if (spaceFlag === "SAC-Expert-change" || spaceFlag === "Comp-Expert-change") {
            // if sac or component change channel and new channel don't contain expert chat then need to show message in last step
            this._expertChatChannel.setProperty("/isShowExpertChatChangeWarningTextInSubmit", true);
        }
        // reset timeline for create a case
        this._setTimeLineToCreateCase().then(res => {
            this._resetStatusWhenChannelChange();
            // make sure when become create a case in submit step continue button text change to 'submit'
            if (this._oCurrentProcess === this._oProcessBarSubmitStepIndex) {
                this.fragmentControllers.SubmitStep.decideLastStepButton();
            }
        });

    };

    CaseCreationCard.prototype._setTimeLineToExpertChat = async function() {
        const isShowAriba = await this.fragmentControllers.CaseCreationAribaQA.isInitAribaQuestions();

        const detailInfoStepIndex = this._oProcessBarDetailedStepIndex;
        this.timeLineLayoutControl.data.timeLineItems.forEach((item, index) => {
            item.isStepVisible = index <= detailInfoStepIndex;
            item.isStepPreviewEditEnabled = index <= detailInfoStepIndex;
        });

        const aribaStepIndex = this._oProcessBarAribaStepIndex;
        const submitStepIndex = this._oProcessBarSubmitStepIndex;
        this.timeLineLayoutControl.data.timeLineItems[submitStepIndex].isStepVisible = true;
        this.timeLineLayoutControl.data.timeLineItems[aribaStepIndex].isStepVisible = isShowAriba;
        this.timeLineLayoutControl.data.timeLineItems[this._oProcessBarCommunityStepIndex].isStepVisible = false;

        // this func for clear sae step
        this._handleSaeStepAndClearChannelText();
        this._setBestChannelText(this._i18n.getText("case_creation_best_action_expert_chat"));
        this.timeLineLayoutControl.updateTimeLineItemsModel();
    };

    CaseCreationCard.prototype._setTimeLineToAaEP = async function() {
        const isShowAriba = await this.fragmentControllers.CaseCreationAribaQA.isInitAribaQuestions();

        const detailInfoStepIndex = this._oProcessBarDetailedStepIndex;
        this.timeLineLayoutControl.data.timeLineItems.forEach((item, index) => {
            item.isStepVisible = index <= detailInfoStepIndex;
            item.isStepPreviewEditEnabled = index <= detailInfoStepIndex;
        });

        const aribaStepIndex = this._oProcessBarAribaStepIndex;
        this.timeLineLayoutControl.data.timeLineItems[aribaStepIndex].isStepVisible = isShowAriba;
        this.timeLineLayoutControl.data.timeLineItems[this._oProcessBarCommunityStepIndex].isStepVisible = false;

        // this func for clear sae step
        this._handleSaeStepAndClearChannelText();
        this._setBestChannelText(this._i18n.getText("case_creation_best_action_expert_peer"));
        this._resetStatusWhenChannelChange();
        this.timeLineLayoutControl.updateTimeLineItemsModel();
    };

    CaseCreationCard.prototype._setCreationCardToExpertChatStatus = function() {
        // expert chat need to hide reproduce text editor
        sap.ui.getCore().byId("CaseCreationDetailedInformationStep--sapMeCreationDetailedInformationReproduceStepsVBox").setVisible(false);
        // expert chat should set last step title to 'Chat with an Expert'
        this.fragmentControllers.SubmitStep.timeLineItem.title = this._i18n.getText("case_creation_time_line_best_action_expert_chat");
        // expert chat should set detail description text editor label
        this.getModel("$this.detailedInformation").setProperty("/detailedDescriptionLabelText", this._i18n.getText("case_creation_detailed_information_expert_description"));
        // expert chat should display wait time in submit step
        this._expertChatChannel.setProperty("/isShowExpertChatStatusTextInSubmit", true);
        this._setTimeLineToExpertChat().then(res => {
            this._resetStatusWhenChannelChange();
            if (this._oCurrentProcess === this._oProcessBarSubmitStepIndex) {
                this.fragmentControllers.SubmitStep.decideLastStepButton();
            }
        });

    };

    CaseCreationCard.prototype._setTimeLineToSAE = async function() {
        const isShowAriba = await this.fragmentControllers.CaseCreationAribaQA.isInitAribaQuestions();
        const detailInfoStepIndex = this._oProcessBarDetailedStepIndex;

        this.timeLineLayoutControl.data.timeLineItems.forEach((item, index) => {
            item.isStepVisible = true;
            item.isStepPreviewEditEnabled = index <= detailInfoStepIndex;
        });

        const aribaStepIndex = this._oProcessBarAribaStepIndex;
        this.timeLineLayoutControl.data.timeLineItems[aribaStepIndex].isStepVisible = isShowAriba;
        this.timeLineLayoutControl.data.timeLineItems[this._oProcessBarCommunityStepIndex].isStepVisible = false;

        if (this.fragmentControllers.CaseCreationDetailedInformationStep.data.isProgressFinished) {
            for (let i = detailInfoStepIndex + 1; i < this.timeLineLayoutControl.data.timeLineItems.length; i++) {
                this.timeLineLayoutControl.data.timeLineItems[i].isStepPreviewEditEnabled = true;
            }
        }
        this._setBestChannelText(this._i18n.getText("case_creation_best_action_expert_session"));
    };

    CaseCreationCard.prototype._setCreationCardToSAEStatus = async function() {
        await this._setTimeLineToSAE();
        this._resetStatusWhenChannelChange();
    };

    /**
     * @param spaceFlag - sac and component change will call this func so need this flag to know where changed channel
     * @description - after channel recommended change check if need to set creation card to 'creat a case' status.
     */
    CaseCreationCard.prototype._channelChangeCheckIfSetToCreateCase = function(spaceFlag) {
        const chatIndex = this.availableChannelArr.findIndex(item => item.ChannelID === "CHAT");
        const saeIndex = this.availableChannelArr.findIndex(item => item.ChannelID === "SAE");

        // clear Ariba data due to the component change, refresh the timeline
        this.resetAribaStep();

        if (this._channelText === this._i18n.getText("case_creation_best_action_create_a_case")) {
            return;
        }
        if ((this._channelText === this._i18n.getText("case_creation_best_action_expert_chat") && chatIndex !== -1)
            || (this._channelText === this._i18n.getText("case_creation_best_action_expert_session") && saeIndex !== -1) ) {
            return;
        }
        let flag = "";
        if (spaceFlag === "SAC" && this._channelText === this._i18n.getText("case_creation_best_action_expert_chat")) {
            flag = "SAC-Expert-change";
        }
        if (spaceFlag === "SAC" && this._channelText === this._i18n.getText("case_creation_best_action_expert_session")) {
            flag = "SAC-SAE-change";
        }
        if (spaceFlag === "Comp" && this._channelText === this._i18n.getText("case_creation_best_action_expert_chat")) {
            flag = "Comp-Expert-change";
        }
        if (spaceFlag === "Comp" && this._channelText === this._i18n.getText("case_creation_best_action_expert_session")) {
            flag = "Comp-SAE-change";
        }
        // change to create case
        this._setCreationCardToCreateCaseStatus(flag);
    };

    /**
     * @description - after choose different channel need to clean channel cache status. This status could be such as hide VBox or text change
     * example 'expert chat' channel need to hide Reproduce text editor but other channel need to show Reproduce text editor so when
     * 'expert chat' channel change to 'create a case' channel need to clean cache which means need to set Reproduce text editor show again
     */
    CaseCreationCard.prototype._resetStatusWhenChannelChange = function() {
        const detailInfomationModel = this.getModel("$this.detailedInformation");
        if (this._channelText === this._i18n.getText("case_creation_best_action_expert_peer")) {
            this.fragmentControllers.CaseCreationDetailedInformationStep.data.isStaticPartVisible = true;
            detailInfomationModel.setProperty("/issueHappenedPartVisible", false);
            sap.ui.getCore().byId("CaseCreationDetailedInformationStep--sapMeCreationDetailedInformationReproduceStepsVBox").setVisible(false);
            return;
        }
        // for clean expert chat channel cache
        if (this._channelText !== this._i18n.getText("case_creation_best_action_expert_chat") && this._channelText !== this._i18n.getText("case_creation_best_action_expert_peer")) {
            sap.ui.getCore().byId("CaseCreationDetailedInformationStep--sapMeCreationDetailedInformationReproduceStepsVBox").setVisible(true);
        }
        if (this._channelText !== this._i18n.getText("case_creation_best_action_expert_chat")) {
            this.fragmentControllers.SubmitStep.timeLineItem.title = this._i18n.getText("Submit");
            detailInfomationModel.setProperty("/detailedDescriptionLabelText", this._i18n.getText("case_creation_detailed_information_detailed_description"));
            this._expertChatChannel.setProperty("/isShowExpertChatStatusTextInSubmit", false);
        }
        if (this._channelText !== this._i18n.getText("case_creation_best_action_create_a_case")) {
            this._expertChatChannel.setProperty("/isShowExpertChatChangeWarningTextInSubmit", false);
        }
        if (this._channelText !== this._i18n.getText("case_creation_best_action_create_a_case") && this._channelText !== this._i18n.getText("case_creation_best_action_expert_session")) {
            detailInfomationModel.setProperty("/issueHappenedPartVisible", false);
        } else {
            detailInfomationModel.setProperty("/issueHappenedPartVisible", true);
        }
    };

    CaseCreationCard.prototype.resetTimeLineAfterStepOneValueChanged = function() {
        this.fragmentControllers.BasicInformationStep.resetTimeLineAfterStepOneValueChanged();
    };

    /**
     * @description
     *  - Clear the ariba selection and display data due to the component change through either SAC or submit step dialog
     *  - Refresh the timeline object to toggle the ariba step visibility
     */
    CaseCreationCard.prototype.resetAribaStep = async function() {
        this.fragmentControllers.CaseCreationAribaQA.clearAribaQAData();
        const isShowAriba = await this.fragmentControllers.CaseCreationAribaQA.isInitAribaQuestions();
        if (isShowAriba) {
            this.fragmentControllers.CaseCreationAribaQA.timeLineItem.isStepVisible = true;
            this.fragmentControllers.CaseCreationAribaQA.initAribaPageUI();
        }
        this.timeLineLayoutControl.updateTimeLineItem(this.fragmentControllers.CaseCreationAribaQA.timeLineItem);
    };

    /**
     * @param {int} oTargetProcess - The process whose input part is expected to be displayed.
     * @description - Set the target part visibile and set other parts invisible.
     */
    CaseCreationCard.prototype.setTargetPartVisible = function(oTargetProcess) {
        this.timeLineLayoutControl.hideAllStepViews();
        this.timeLineLayoutControl.showTargetStepView(oTargetProcess);

        /**
         * Ensure that the main process width of all steps except the submit remains the same.
         */
        this.handleRightSideRecommendVisibleByPreview(oTargetProcess);
    };

    CaseCreationCard.prototype.sendAlternativeChannelEvent = function() {
        // list of alternative channel list
        const index = this.channelIDList.findIndex(item => item === this.getChannelIDByText(this._channelText));
        const submitStepChannelIDList = Object.assign([], this.channelIDList);
        if (index !== -1) {
            submitStepChannelIDList.splice(index, 1);
        }
        this.swaServiceEvent.swaAlternativeChannelList(JSON.stringify(submitStepChannelIDList));
    };

    CaseCreationCard.prototype.handleRightSideRecommendVisibleByPreview = function(targetProcessStep) {

        // if current choose step then show HotAndTrending
        // else if current step is the third / best actions step then show coveo recommendation, if no coveo recommendation, then show HotAndTrending
        // else show RecommendedSolution
        switch (targetProcessStep) {
            case this._oProcessBarSubmitStepIndex:
                break;
            case this._oProcessBarIssueStepIndex:
            case this._oProcessBarAribaStepIndex:
                this.setExpertTrendingSolutionVisible("T");
                break;
            case this._oProcessBarActionStepIndex:
                FeatureToggles.get("feature-support-coveo-search") ? this.setExpertTrendingSolutionVisible("C") : this.setExpertTrendingSolutionVisible("T");
                break;
            default: {
                const hasRecommendSolution = this._oRecommendedSolutionModel.getProperty("/all").length > 0;
                const hasSACRecommend = this._oSACContentRecommendationsModel.getProperty("/all").length > 0;
                if (hasRecommendSolution) {
                    this.setExpertTrendingSolutionVisible("R");
                } else if (hasSACRecommend) {
                    this.setExpertTrendingSolutionVisible("S");
                } else {
                    this.setExpertTrendingSolutionVisible("T");
                }
                break;
            }
        }
    };

    /**
     * @param {string} oInput - The input to be validated.
     * @returns {string} - The validated input.
     * @description - If the input only contains blank space then the input is formatted to empty string.
     */
    CaseCreationCard.prototype.validateInput = function(oInput) {
        if (oInput.trim() === "") {
            return "";
        }
        return oInput;
    };

    /**
     * @param {"T"|"C"|"S"|"R"|"CLOSE"} oPart - Set the part visible (visible: true)
     *                          'T' for hot and trending content,
     *                          'C' for hot and coveo recommendations,
     *                          'R' for recommended solution,
     */
    CaseCreationCard.prototype.setExpertTrendingSolutionVisible = function(oPart) {
        const isShowHotAndTrending = oPart === "T";
        const isShowSACRecommendations = oPart === "S";
        const isShowRecommendedSolution = oPart === "R";
        const isShowCoveoRecommendations = oPart === "C";

        this._oRightSideAllKindsListModel.setProperty("/isShowHotAndTrending", isShowHotAndTrending);
        this._oRightSideAllKindsListModel.setProperty("/isShowSACRecommendations", isShowSACRecommendations);
        this._oRightSideAllKindsListModel.setProperty("/isShowRecommendedSolution", isShowRecommendedSolution);
        this._oRightSideAllKindsListModel.setProperty("/isShowCoveoRecommendations", isShowCoveoRecommendations);
    };

    // clear 'hot and trending'  data, SAC contentRecommendations, and ISM recommended solution data
    CaseCreationCard.prototype.reSetRightSideAllKindsList = function() {
        this._oHotAndTrendingModel.setProperty("/all",[]);
        this._oHotAndTrendingModel.setProperty("/isShow",false);
        this._oSACContentRecommendationsModel.setProperty("/all",[]);
        this._oSACContentRecommendationsModel.setProperty("/isShow",false);
        this._oRecommendedSolutionModel.setProperty("/all",[]);
        this._oRecommendedSolutionModel.setProperty("/isShow",false);
        this._oCoveoRecommendationsModel.setProperty("/all",[]);
        this._oCoveoRecommendationsModel.setProperty("/isShow",false);
        this._oIssueInformationModel.setProperty("/isRecommendedContentShown", false);
    };

    /**
     * set selected value
     * if openWarningHook returns true, then open warning
     *      if customer confirm to change, then call afterConfirmHook
     *      otherwise, then call afterCancelHook
     * if openWarningHook returns false, then call afterConfirmHook
     *
     * @param openWarningHook
     * @param afterConfirmHook
     * @param afterCancelHook
     * @param warningTitle
     * @param warningMsg
     */
    CaseCreationCard.prototype.setSelectedValue = function(openWarningHook, afterConfirmHook, afterCancelHook, warningTitle, warningMsg) {
        // eslint-disable-next-line
        if (!!openWarningHook.call ()) {
            sap.m.MessageBox.confirm(warningMsg, {
                title: warningTitle,
                styleClass: "sapUiSizeCompact",
                actions: ["Cancel", "Confirm"],
                emphasizedAction: "Confirm",
                initialFocus: null,
                textDirection: sap.ui.core.TextDirection.Inherit,
                onClose: function(sAction) {
                    if (sAction === "Confirm") {
                        this.aaepClosedByPoster = false;
                        afterConfirmHook.call();
                    } else {
                        afterCancelHook.call();
                    }
                }.bind(this)
            });
        } else {
            afterConfirmHook.call();
        }
    };

    /** ************************************************************************************** */
    /*                                Functions for each step                                 */
    /** ************************************************************************************** */

    /** ************************************************************************************** */
    /*                                   Issue Event Handlers                                 */
    /** ************************************************************************************** */

    CaseCreationCard.prototype.setTextDescriptionModel = function(title,reminder) {
        this._oTextDescriptionModel.setProperty("/title", this._i18n.getText(title));
        this._oTextDescriptionModel.setProperty("/reminder", this._i18n.getText(reminder));
    };

    CaseCreationCard.prototype.onLanguageChange = function() {
        this.fragmentControllers.BasicInformationStep.handleProcessAfterSysSelection();
    };

    // If the value of classified content changes while it is already in a draft state, the previous draft needs to be deleted.
    CaseCreationCard.prototype.onClassifiedContentSelected = function(oEvent) {
        let selectedValue = oEvent.getParameter("selected");
        this.fragmentControllers.BasicInformationStep.data.dss_classified = selectedValue;
        if (this._oIssueInformationModel.getProperty("/pointer")) {
            this.deleteDraft();
            this._oIssueInformationModel.setProperty("/pointer","");
        }
    };

    CaseCreationCard.prototype.getProductFunctionTree = function(modelNumber) {
        const treeTypePFData = this.fragmentControllers.BasicInformationStep.formatProductFunctionsToTreeType(modelNumber);
        this._oProductFunctionModel.setProperty("/all", treeTypePFData);
    };

    CaseCreationCard.prototype.getProductFunctionList = function(modelNumber) {
        const listTypePFData = this.fragmentControllers.BasicInformationStep.formatProductFunctionsToListType(modelNumber);
        if (listTypePFData.length === 0) {
            this.handleIssueProductFunctionInputVisibility(false);
        } else {
            this.handleIssueProductFunctionInputVisibility(true);
            this.afterGetProductFunctionList(listTypePFData,modelNumber);
            this.getProductFunctionTree(modelNumber);
        }
        this.handleProcessAfterProSelection();
    };

    CaseCreationCard.prototype.afterGetProductFunctionList = function(listTypePFData,modelNumber) {
        this.tagRecentlyUsedProductFunction(listTypePFData);
        if (listTypePFData.length === 1) {
            this._oProductFunctionModel.setProperty("/recommendedModelNumbers", [listTypePFData[0]?.ModelNumber]);
            listTypePFData[0].Recommended = true;
            listTypePFData[0].RecommendedIndex = 1;
            // should check product function entitlement
            const checkResult = this.handleEntitlementCheck(listTypePFData[0].CheckResult);
            if(checkResult.prevent) {
                return;
            }
            // If only have one data,should set data to page directly. and no need to prediction.
            this.handleProductFunctionValueChange(listTypePFData[0], false);
            // TODO why are they the same ?
            this._oProductFunctionModel.setProperty("/searchList",listTypePFData);
            this._oProductFunctionModel.setProperty("/suggest",listTypePFData);
            this.trackProductFunctionChange("System(Prefilled)", listTypePFData[0], 0, "");
        } else {
            this.productFunctionPredictor(modelNumber,listTypePFData);
        }
    };

    CaseCreationCard.prototype.adobeProductFunctionSelectedType = function() {
        if (this._oTrackingData.init_select_data.product_function_init_flag) {
            this._oTrackingData.init_select_data.product_function_selected_type = "initially";
            return;
        }
        if (this.fragmentControllers.BasicInformationStep.data.productFunction.info) {
            this._oTrackingData.init_select_data.product_function_selected_type = "changed";
        } else {
            this._oTrackingData.init_select_data.product_function_selected_type = "reset";
        }
    };

    CaseCreationCard.prototype.handleProductFunctionValueChange = function(oProductFunction, isUserSelected) {
        this.adobeProductFunctionSelectedType();
        // give check result value after select or change product function
        this.checkResultTxt = this.checkResultTxtStore;
        this.fragmentControllers.BasicInformationStep.data.productFunction.info = oProductFunction;
        this.processPPFCSelectionRecordsArr(isUserSelected ? ProductFunctionMemoUtil.userSelect(oProductFunction) : ProductFunctionMemoUtil.predictNormal(oProductFunction.FullName));
        this._oPriorityAndImpactCreateController.prioritySelectLimit(oProductFunction?.DefaultCompPrioLimit);
        this.getRefinementComponent();
        this.getHotAndTrending(oProductFunction?.ModelNumber, true, "PENDING");
        this.handleIssuePriorityInputVisibility(true);
        this.handleProcessAfterProSelection();
    };

    CaseCreationCard.prototype.productFunctionPredictor = function(selectedProduct,listTypePFData, method) {
        if (!this.fragmentControllers.BasicInformationStep.data.shortDesc) {
            return;
        }
        this._oProductFunctionModel.setProperty("/productFunctionInputBusy", true);
        this._productFunctionPredictedRequest = jQuery.ajax("/backend/raw/support/CaseCreateProductFunctionPrediction", {
            method: "GET",
            contentType: "application/json",
            data: {
                $filter: `SystemNumber eq '${this.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber}'`,
                ModelNumber: selectedProduct,
                shortDescription: this.fragmentControllers.BasicInformationStep.data.shortDesc,
                installationNbr: this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr
            },
            dataType: "json",
            async: true,
        }).done(data => {
            this._oProductFunctionModel.setProperty("/productFunctionInputBusy", false);
            this.setSuggestedProductFunction(data?.results,listTypePFData,data?.conf_threshold_met, method);
        }).fail(() => {
            this._oProductFunctionModel.setProperty("/productFunctionInputBusy", false);
            // not doing anything if call fails
        });
    };

    CaseCreationCard.prototype.setSuggestedProductFunction = function(predictorResult, listTypePFData, flagThreshold, method) {
        let suggestedList = [];
        this.tagRecommendedProductFunction(listTypePFData,predictorResult);
        this.setProductFunctionRecommendValueInOrder(listTypePFData,predictorResult);
        listTypePFData.sort(CreationHelper.productCompare);
        this._oProductFunctionModel.setProperty("/searchList",listTypePFData);
        suggestedList = listTypePFData.filter(item => item.Recommended === true);
        suggestedList.sort((a, b) => b?.node_score - a?.node_score).forEach((item, index) => {
            item.RecommendedIndex = index + 1;
        });
        suggestedList.sort(CreationHelper.productCompare);
        this._oProductFunctionModel.setProperty("/suggest",suggestedList);
        // no suggestedList
        if (suggestedList.length <= 0) {
            this.addPlaceholderMemoByMethodsInPFPredictor(method);
            return;
        }
        // has suggestedList and has productFunction or !flagThreshold
        if (this.fragmentControllers.BasicInformationStep.data.productFunction.info || !flagThreshold) {
            this.addPlaceholderMemoByMethodsInPFPredictor(method);
            return;
        }
        // if product function input doesn't have value then set predictor result list first object
        // has suggestedList and no productFunction and flagThreshold===true
        let mostRecProductFunction = suggestedList.find(item => item?.ModelNumber === predictorResult[0]?.path_node_id);
        this._mostRecommendProductFunction = predictorResult[0]?.path_node_id;
        // should check product function entitlement
        const checkResult = this.handleEntitlementCheck(mostRecProductFunction.CheckResult);
        if(checkResult.prevent) {
            return;
        }
        this.handleProductFunctionValueChange(mostRecProductFunction, false);
        // no need to predict best action here, it will predict when press continue btn of first step.
        // swa	Product function predicted accepted
        this.trackProductFunctionChange("System(Predicted)", mostRecProductFunction, 0, "");
    };

    CaseCreationCard.prototype.addPlaceholderMemoByMethodsInPFPredictor = function(method) {
        switch (method) {
            case "draft":
            case "sac":
            case "compchange":
                // not adding memo record for draft, sac, or compchange scenario
                break;
            default:
                this.processPPFCSelectionRecordsArr(ProductFunctionMemoUtil.noPredictProductFunction());
                break;
        }
    };

    CaseCreationCard.prototype.trackProductFunctionChange = function(eventTrack, oProductFunction, rankIndex, determinedBy) {
        let result = Object.assign({},oProductFunction);
        result["rankIndex"] = rankIndex ?? 0;
        result["selectedType"] = this._oTrackingData.init_select_data.product_function_selected_type;
        result["determinedBy"] = determinedBy ?? "";
        this.swaServiceEvent.listenProductFunctionValueChange(eventTrack,result);
        this.cacheProductFunctionInitiallySelected(oProductFunction);
    };

    CaseCreationCard.prototype.cacheProductFunctionInitiallySelected = function(oProductFunction) {
        if (this._oTrackingData.init_select_data.product_function_init_flag) {
            this._oTrackingData.init_select_data.product_function = oProductFunction?.ModelNumber;
            this._oTrackingData.init_select_data.product_function_init_flag = false;
        }
    };

    CaseCreationCard.prototype.resetProductAndProductFunctionInitiallySelected = function() {
        this._oTrackingData.init_select_data.product_function_init_flag = true;
        this._oTrackingData.init_select_data.product_function = "";
        this._oTrackingData.init_select_data.product_function_selected_type = "";
        this._oTrackingData.init_select_data.product_init_flag = true;
        this._oTrackingData.init_select_data.product = "";
        this._oTrackingData.init_select_data.product_selected_type = "";
    };

    CaseCreationCard.prototype.tagRecommendedProductFunction = function(pfList,predictList = []) {
        let sugList = predictList.map(item => item?.path_node_id);
        this._oProductFunctionModel.setProperty("/suggestModelNumber", sugList.filter(i => i && i?.trim()));
        pfList.forEach(item => {
            item.Recommended = sugList.includes(item.ModelNumber);
            item.node_score = predictList.find(obj => obj?.path_node_id.indexOf(item.ModelNumber) !== -1)?.node_score ?? 0;
        });
    };

    CaseCreationCard.prototype.setProductFunctionRecommendValueInOrder = function(productFunctionAllList = [],suggestList = []) {
        const sugList = productFunctionAllList.filter(item => item?.ModelNumber && item.Recommended).map(item => item?.ModelNumber);
        const productFunctionPredictList = suggestList.filter(item => sugList.includes(item?.path_node_id)).map(item => item.path_node_id);
        this._oProductFunctionModel.setProperty("/recommendedModelNumbers", productFunctionPredictList);
    };

    CaseCreationCard.prototype.trackProductChange = function(eventTrack, oProduct, rankIndex, determinedBy) {
        this.adobeProductSelectedType();
        const result = Object.assign({},oProduct);
        result["rankIndex"] = rankIndex ?? 0;
        result["selectedType"] = this._oTrackingData.init_select_data.product_selected_type;
        result["determinedBy"] = determinedBy ?? "";
        this.swaServiceEvent.listenProductValueChange(eventTrack,result);
        this.cacheProductInitiallySelected(oProduct);
    };

    CaseCreationCard.prototype.cacheProductInitiallySelected = function(oProduct) {
        if (this._oTrackingData.init_select_data.product_init_flag) {
            this._oTrackingData.init_select_data.product = oProduct?.ModelNumber;
            this._oTrackingData.init_select_data.product_init_flag = false;
        }
    };

    CaseCreationCard.prototype.adobeProductSelectedType = function() {
        if (this._oTrackingData.init_select_data.product_init_flag) {
            this._oTrackingData.init_select_data.product_selected_type = "initially";
            return;
        }
        // if (this._oIssueInformationModel.getProperty("/product")) {
        if (this.fragmentControllers.BasicInformationStep.data.product.info) {
            this._oTrackingData.init_select_data.product_selected_type = "changed";
        } else {
            this._oTrackingData.init_select_data.product_selected_type = "reset";
        }
    };

    CaseCreationCard.prototype.handleEntitlementCheck = function(checkData, method) {
        const checkResult = CreationHelper.ppfCheck(checkData);
        this.checkResultTxtStore = checkResult.text;
        // if sac change component and is prevent, should not show warning message
        if(checkResult.prevent && method !== "sac") {
            CreationHelper.showWarningMessageBox();
        }
        return checkResult;
    };

    CaseCreationCard.prototype.getUserProfileInfo = function() {
        jQuery.ajax("/backend/raw/support/UserProfile", {
            method: "GET",
            contentType: "application/json"
        }).done(data => {
            this.handleUserProfileInfo(data);
        });
    };

    CaseCreationCard.prototype.handleUserProfileInfo = function(data) {
        const productList = data.recentProduct ?? [];
        const productFunctionList = data.recentProductFunction ?? [];
        this.cleanOldRecentlyUsed(productList,productFunctionList);
        this.updateRecentlyProductAndProductFunction(productList,productFunctionList);
        this._oUserProfileInfoModel.setProperty("/phone",data?.phone);
    };

    CaseCreationCard.prototype.updateRecentlyProductAndProductFunction = function(recentlyProductArray, sRecentlyProductFunctionArray) {
        if (recentlyProductArray.length === 1) {
            this._oUserProfileInfoModel.setProperty("/recentProductList", recentlyProductArray[0]?.split(","));
        }
        if (sRecentlyProductFunctionArray.length === 1) {
            this._oUserProfileInfoModel.setProperty("/recentProductFunctionList", sRecentlyProductFunctionArray[0]?.split(","));
        }
    };

    // recently product and product function refactor should remove old data
    CaseCreationCard.prototype.cleanOldRecentlyUsed = async function(recentlyProductArray, sRecentlyProductFunctionArray) {
        let data = {profile : {}};
        if (recentlyProductArray.length > 1) {
            data.profile.recentProduct = "1";
        }
        if (sRecentlyProductFunctionArray.length > 1) {
            data.profile.recentProductFunction = "1";
        }
        if (!data.profile?.recentProduct && !data.profile?.recentProductFunction) {
            return;
        }
        return jQuery.ajax("/backend/raw/support/UserProfile", {
            method: "DELETE",
            contentType: "application/json",
            data: JSON.stringify(data)
        });
    };

    // return update info of recently used product or product function
    CaseCreationCard.prototype._generateTopFiveRecently = function(type, modelNumber) {
        let key = type === "p" ? "/recentProductList" : "/recentProductFunctionList";
        const result = [modelNumber];
        const recentList = this._oUserProfileInfoModel.getProperty(key);
        const recentListTop4 = recentList.slice(0, 4);
        const mergeList = result.concat(recentListTop4);
        this._oUserProfileInfoModel.setProperty(key, mergeList);
        return mergeList.join();
    };

    CaseCreationCard.prototype.setRecentlyUsedProductAndProductFunction = function() {

        const productId = this.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber;
        const productRelationshipType = this.fragmentControllers.BasicInformationStep.data.product.info?.RelationshipType;
        const productFunctionId = this.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber;

        let data = {profile : {}};
        if (productId && !this._oUserProfileInfoModel.getProperty("/recentProductList").includes(productId) && productRelationshipType !== "Service") {
            data.profile.recentProduct = this._generateTopFiveRecently("p",productId);
        }
        if (productFunctionId && !this._oUserProfileInfoModel.getProperty("/recentProductFunctionList").includes(productFunctionId)) {
            data.profile.recentProductFunction = this._generateTopFiveRecently("pf",productFunctionId);
        }
        if (!data.profile?.recentProduct && !data.profile?.recentProductFunction) {
            return;
        }
        jQuery.ajax("/backend/raw/support/UserProfile", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify(data)
        });
    };

    CaseCreationCard.prototype.tagRecentlyUsedProductFunction = function(listTypePFData) {
        const recentList = this._oUserProfileInfoModel.getProperty("/recentProductFunctionList");
        listTypePFData.forEach(item => item.Recently = recentList.includes(item.ModelNumber));
    };

    CaseCreationCard.prototype.getHotAndTrending = function(selectedModelNumber, isShowCriticalPop, needRefreshISM = "FALSE") {
        this._hotAndTrendingRequest = jQuery.ajax(`/backend/raw/support/CaseCreateHotAndTrendingW7?$filter=UseCaseID eq 'S4MSupportCreate' and ModelNumber eq '${selectedModelNumber}'`, {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            async: true,
            success: (data) => {
                this._handleCriticalKnowledge(data, isShowCriticalPop);
                this.afterGetHotAndTrending(data);
                // swa simcat list length
                this.swaServiceEvent.swaSimCatKnowledgeEntries(data);
                if (FeatureToggles.get("feature-support-coveo-search")) {
                    this.coveoUtil.coveoSearch();
                }
                // update the ISM result for steps after desc and the topSuggestedSolutions in submit step
                if (this.getModel("$this.detailedInformation")?.getProperty("/detailedDescription")) {
                    switch (needRefreshISM) {
                        case "TRUE":
                            this.updateISMresult();
                            break;
                        case "PENDING":
                            // change watched value
                            this.fragmentControllers.BasicInformationStep.data.readyRefreshISM += "hotTrendingReady";
                            break;
                    }
                }
            }
        });
    };

    CaseCreationCard.prototype.afterGetHotAndTrending = function(data) {
        if (data.length === 0) {
            this._oHotAndTrendingModel.setProperty("/isShow", false);
        } else {
            this._oHotAndTrendingModel.setProperty("/isShow",true);
            this._oHotAndTrendingModel.setProperty("/all",data);
            this._oIssueInformationModel.setProperty("/isRecommendedContentShown", true);
        }
    };

    CaseCreationCard.prototype.updateISMresult = function(comp) {
        const component = comp ?? this.fragmentControllers.BasicInformationStep.data.component.info?.CompName ?? "";
        const {detailedDescription, stepsToReproduce} = this.fragmentControllers.CaseCreationDetailedInformationStep.data;
        const payload = {
            title: this.fragmentControllers.BasicInformationStep.data.shortDesc,
            problemDescription: detailedDescription,
            systemNumber: this.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber ?? "",
            installationNumber: this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr ?? "",
            leadingproduct_id: this.fragmentControllers.BasicInformationStep.data.product.info?.SoftwareProductNumber ?? "",
            component: component,
            stepsToReproduce: stepsToReproduce ?? "",
            productKnowledgeSet: this._oHotAndTrendingModel.getProperty("/all") ?? "",
            treeInteractionSet: this?._cacheSacQuestionList ?? []
        };
        if (this._oSimulatedUser) {
            payload.userId = this._oSimulatedUser;
        }

        this._ISMRefreshRequest = jQuery.ajax("/backend/raw/support/CaseCreateCaseSolution", {
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            async: true,
            data: JSON.stringify(payload),
            success: (solutions) => {
                this._oRecommendedSolutionModel.setProperty("/all", solutions);
                this.fragmentControllers.SubmitStep._oSubmitPageModel.setProperty("/topSuggestedList",solutions.length > 5 ? solutions.slice(0, 5) : solutions);
            }
        });
    };

    // tag_id: C, tag: CRITICAL
    // tag_id: F, tag: HOT
    // tag_id: T, tag: TRENDING
    CaseCreationCard.prototype._handleCriticalKnowledge = function(data, isShowCriticalPop) {
        if (isShowCriticalPop && this._oCurrentProcess === this._oProcessBarIssueStepIndex) {
            const criticalList = data.filter(item => JSON.parse(item.Tag).map(obj => obj?.tag_id).indexOf("C") !== -1);
            if (criticalList.length > 0) {
                this._oHotAndTrendingModel.setProperty("/criticalList", criticalList);
                this.fragmentControllers.BasicInformationStep?._productKnowledgeCriticalDialog.openCriticalPop();
            }
        }
    };

    CaseCreationCard.prototype._handleHotStatus = function(tag) {
        if (tag.length === 0 || tag.indexOf("tag_id") === -1) {
            return false;
        }
        return JSON.parse(tag)?.map(item => item?.tag_id).indexOf("F") !== -1;
    };

    CaseCreationCard.prototype._handleTrendingStatus = function(tag) {
        if (tag.length === 0 || tag.indexOf("tag_id") === -1) {
            return false;
        }
        return JSON.parse(tag)?.map(item => item?.tag_id).indexOf("T") !== -1;
    };

    CaseCreationCard.prototype._handleCriticalStatus = function(tag) {
        if (tag.length === 0 || tag.indexOf("tag_id") === -1) {
            return false;
        }
        return JSON.parse(tag)?.map(item => item?.tag_id).indexOf("C") !== -1;
    };

    CaseCreationCard.prototype.onAnalyzeReportExpandBtnPress = function(oEvent) {
        const oBtn = oEvent.getSource();
        const oBtnState = oBtn.getIcon() === "sap-icon://navigation-down-arrow" ? "expanded" : "unExpanded";
        oBtn.setIcon(oBtnState === "expanded" ? "sap-icon://navigation-right-arrow" : "sap-icon://navigation-down-arrow");
        this.byId("analyzeReportingList").setVisible(!(oBtnState === "expanded"));
    };

    CaseCreationCard.prototype.issueComponentDialogOpen = function() {
        if (!this._componentSelectDialog) {
            this._componentSelectDialog = new CreateSelectComponentDialog(this);
        }
        if (this.compURLPrefillMode && (!this.fragmentControllers.BasicInformationStep.data.system.info || !this.fragmentControllers.BasicInformationStep.data.shortDesc)) {
            return MessageToast.show(`${this._i18n.getText("case_creation_prefill_cmponent_tip")}`);
        }
        this._componentSelectDialog.open();
    };

    CaseCreationCard.prototype.handleProcessAfterProSelection = function() {
        this.fragmentControllers.BasicInformationStep.setIssueContinueButtonEnabled();
        this.fragmentControllers.BasicInformationStep.updateTimelineProgress();
    };


    /** ************************************************************************************** */
    /*                                        Issue Functions                                 */
    /** ************************************************************************************** */

    CaseCreationCard.prototype.sendSAPHanaCloudProductChange = function() {
        SaveMsgEventBus.publish(
            "sap.me.support.cards.CaseCreationCard",
            CreationEventType.SAP_HANA_CLOUD_PRODUCT_CHANGE,
            this.fragmentControllers.BasicInformationStep.data.system.info
        );
    };

    CaseCreationCard.prototype.getInstallationData = function() {
        let installationNbr = this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr;
        jQuery.ajax(`/backend/raw/support/CaseCreateInstallationW7?InstallationNbr=${installationNbr}`, {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            async: false,
            success: (data) => {
                this._oIssueInformationModel.setProperty("/installationData", data);
            }
        });
    };

    CaseCreationCard.prototype.getComponentLevel1List = function() {
        let installationNbr = this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr;
        jQuery.ajax(`/backend/raw/support/CaseCreateComponentW7?$filter=Category eq 'LEVEL1' and Installation eq '${installationNbr}'&resultType=CompF4Help`, {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            async: true,
            success: (data) => {
                this._oComponentModel.setProperty("/all", data);
            }
        });
    };

    CaseCreationCard.prototype.setCompAllNeedsModel = function() {
        this.getComponentLevel1List();
        this.getInstallationData();
        this.getComponentRecentlyUsedList();
        this.getComponentSuggesterList();
    };

    CaseCreationCard.prototype.getComponentRecentlyUsedList = function() {
        let installationNbr = this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr;
        let SWType = this._oIssueInformationModel.getProperty("/installationData")?.SWType;
        let suserNumber = this.selectedCutAndSuserInfo.suserNumber;
        jQuery.ajax(`/backend/raw/support/CaseCreateComponentW7?$filter=SWType eq '${SWType}' and ShortText eq '' and LongText eq '' and Installation eq '${installationNbr}' and Uname eq '${suserNumber}'&resultType=CompF4Help`, {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            success: (data) => {
                this._oComponentModel.setProperty("/rec", data);
                this._oComponentModel.setProperty("/recentNameList", data.map(item => item?.CompName));
            }
        });
    };

    CaseCreationCard.prototype.getComponentSuggesterList = function() {
        const installationNbr = this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr;
        const SWType = this._oIssueInformationModel.getProperty("/installationData/SWType");
        const suserNumber = this.selectedCutAndSuserInfo.suserNumber;
        const shortText = this.fragmentControllers.BasicInformationStep.data.shortDesc;
        let detailText = this.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription;
        detailText = !detailText ? "" : encodeURIComponent(detailText);
        const longText = detailText !== "" ? detailText : shortText;
        jQuery.ajax(`/backend/raw/support/CaseCreateCompPredictionSetW7?$filter=SWType eq '${SWType}' and ShortText eq '${shortText}' and Installation eq '${installationNbr}' and Uname eq '${suserNumber}' and LongText eq '${longText}'`, {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            success: (data) => {
                this._oComponentModel.setProperty("/suggestNameList", data.map(item => item?.CompName));
                this._oComponentModel.setProperty("/suggest", data);
                if (data?.length) {
                    this._mostRecommendComponent = data[0].CompKey;
                }
            }
        });
    };

    CaseCreationCard.prototype.getRefinementComponent = function() {
        const systemNumber = this.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber;
        const productFnNumber = this.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber;
        const productFn = this.fragmentControllers.BasicInformationStep.data.productFunction.info;

        const product = this.fragmentControllers.BasicInformationStep.data.product.info;
        const installationNbr = this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr;
        const shortText = this.fragmentControllers.BasicInformationStep.data.shortDesc;
        let longText = this.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription || shortText;
        longText = encodeURIComponent(longText);
        this.fragmentControllers.BasicInformationStep.data.component.info = null;
        // if previous request is not finished, abort it
        if (this._componentPredictionRequest) {
            this._componentPredictionRequest.abort();
        }
        this._componentPredictionRequest = jQuery.ajax(`/backend/raw/support/CaseCreateCompPredictionSetW7?$filter=Type eq 'COMPTOP' and ShortText eq '${shortText}' and SystemNr eq '${systemNumber}' and NodePath eq '${productFnNumber}' and LongText eq '${longText}' and Installation eq '${installationNbr}' & sap-language=en`, {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            success: (refinmentComp) => {
                if (refinmentComp?.length) {
                    this.fragmentControllers.BasicInformationStep.data.component.info = {...refinmentComp[0], selectionMethod: "Product Function Selection",submitStepEventInfo : {systemAction : "Predicted", determinedBy:productFnNumber}};
                    this.processPPFCSelectionRecordsArr(ComponentMemoUtil.predictPF(refinmentComp[0].CompName));
                    this.fragmentControllers.CaseCreationAttachmentStep.resetSuggestFileTypeList(refinmentComp[0].CompName);
                } else if (productFn?.DefaultCompKey) {
                    this.fragmentControllers.BasicInformationStep.data.component.info = {CompKey: productFn.DefaultCompKey, CompName: productFn.DefaultCompName, PrioLimit: productFn.DefaultCompPrioLimit, CompDesc: ""};
                    this.processPPFCSelectionRecordsArr(ComponentMemoUtil.normalPF(productFn.DefaultCompName));
                    this.fragmentControllers.CaseCreationAttachmentStep.resetSuggestFileTypeList(productFn.DefaultCompName);
                } else if (product?.DefaultCompKey) {
                    this.fragmentControllers.BasicInformationStep.data.component.info = {CompKey: product.DefaultCompKey, CompName: product.DefaultCompName, PrioLimit: product.DefaultCompPrioLimit, CompDesc: ""};
                    this.processPPFCSelectionRecordsArr(ComponentMemoUtil.normalPF(product.DefaultCompName));
                    this.fragmentControllers.CaseCreationAttachmentStep.resetSuggestFileTypeList(product.DefaultCompName);
                }
                this.fragmentControllers.BasicInformationStep.data.readyRefreshISM += "compRefineReady";
            }
        });
    };

    CaseCreationCard.prototype.setPrioritySelectLimit = function() {
        this._oPriorityAndImpactCreateController.prioritySelectLimit(this.fragmentControllers.BasicInformationStep.data.component.info?.PrioLimit);
    };

    // after system or product select change clear model and set visible false
    CaseCreationCard.prototype.clearInputAfterSysOrProOrProFuncChange = function(inputChangeFlag) {
        const previousProductSelect = this.fragmentControllers.BasicInformationStep.data.product.info;

        const previousProductFunctionSelect = this.fragmentControllers.BasicInformationStep.data.productFunction.info;

        // Commented out for fixing the draft pop was stopped if jumping back and hot&trending empty
        // this._oIssueInformationModel.setProperty("/isRecommendedContentShown", false);

        if (window.location.search.includes("aaepuuid")) {
            this.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription = "";
        }

        switch (inputChangeFlag) {
            case "system":
            case "description":
                this.stopRequestsAfterSystemChange();
                this.fragmentControllers.BasicInformationStep.data.product.info = null;
                this.fragmentControllers.BasicInformationStep.data.productFunction.info = null;
                this.fragmentControllers.BasicInformationStep.data.component.info = null;
                this.fragmentControllers.BasicInformationStep.data.component.visible = false;
                this.fragmentControllers.BasicInformationStep.data.product.visible = false;
                this.fragmentControllers.BasicInformationStep.data.productFunction.visible = false;
                this.fragmentControllers.BasicInformationStep.data.priority.visible = false;
                this._oTextDescriptionModel.setProperty("/isShowCompWarning", false);
                this._oHotAndTrendingModel.setProperty("/isShow", false);
                if (previousProductSelect) {
                    this.trackProductChange(`System(User changed ${inputChangeFlag})`);
                }
                break;
            case "product":
                this.fragmentControllers.BasicInformationStep.data.productFunction.info = null;
                this.fragmentControllers.BasicInformationStep.data.component.info = null;
                this.fragmentControllers.BasicInformationStep.data.component.visible = false;
                this.fragmentControllers.BasicInformationStep.data.productFunction.visible = false;
                this.fragmentControllers.BasicInformationStep.data.priority.visible = false;
                this._oTextDescriptionModel.setProperty("/isShowCompWarning", false);
                this._oProductFunctionModel.setProperty("/searchList",[]);
                this._oProductFunctionModel.setProperty("/suggest",[]);
                this._oProductFunctionModel.setProperty("/recommendedModelNumbers",undefined);
                this._oProductFunctionModel.setProperty("/all",[]);
                break;
        }
        if (previousProductFunctionSelect) {
            this.adobeProductFunctionSelectedType();
            this.trackProductFunctionChange("System(User changed " + inputChangeFlag + ")");
        }
    };

    CaseCreationCard.prototype.stopRequestsAfterSystemChange = function() {
        this._systemSelectDialog?._productAllListRequest?.abort();
        this._systemSelectDialog?._productPredictedRequest?.abort();
        this?._hotAndTrendingRequest?.abort();
        this?._productFunctionPredictedRequest?.abort();
        this?._ISMRefreshRequest?.abort();
    };

    CaseCreationCard.prototype.handleIssueProductInputVisibility = function(isTargetPartVisible) {
        this.fragmentControllers.BasicInformationStep.data.component.visible = !isTargetPartVisible;
        this.fragmentControllers.BasicInformationStep.data.product.visible = isTargetPartVisible;
        this.fragmentControllers.BasicInformationStep.data.productFunction.visible = false;
        this.fragmentControllers.BasicInformationStep.data.priority.visible = false;
    };

    CaseCreationCard.prototype.handleSystemInformationVisibility = function(isTargetPartVisible) {
        this._oSystemInformationModel.setProperty("/SystemInformationVBox", isTargetPartVisible);
        this._oSystemInformationModel.setProperty("/isSystemDetailVisible", isTargetPartVisible);
    };

    CaseCreationCard.prototype.handleIssueProductFunctionInputVisibility = function(isTargetPartVisible) {
        this.fragmentControllers.BasicInformationStep.data.component.visible = !isTargetPartVisible;
        this._oTextDescriptionModel.setProperty("/isShowCompWarning", !isTargetPartVisible);
        this.fragmentControllers.BasicInformationStep.data.productFunction.visible = isTargetPartVisible;
        this.fragmentControllers.BasicInformationStep.data.priority.visible = false;
    };

    CaseCreationCard.prototype.handleIssuePriorityInputVisibility = function(isTargetPartVisible) {
        this.fragmentControllers.BasicInformationStep.data.priority.visible = isTargetPartVisible;
    };

    CaseCreationCard.prototype.setIssueContinueButtonEnabled = function() {
        // TODO: 迁移到basic info

        if (this.fragmentControllers.BasicInformationStep.data.isProgressFinished && this._oCurrentProcess === this._oProcessBarIssueStepIndex) {
            this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", true);
            // TODO: 迁移到detail
        } else if (this._oCurrentProcess !== this._oProcessBarSubmitStepIndex && this._oCurrentProcess !== this._oProcessBarDetailedStepIndex) {
            this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", false);
        }
    };

    /** ************************************************************************************** */
    /*                                       Best Action Functions                            */
    /** ************************************************************************************** */


    /**
     * Send an ajax request to retrieve dynamic channel recommender data from W7
     */
    CaseCreationCard.prototype.requestChannelRecommend = function() {
        const shortText = formatter.formatSpecialCharacter(this.fragmentControllers.BasicInformationStep.data.shortDesc);
        const systemNum = this.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber;
        const priority = this.fragmentControllers.BasicInformationStep.data.priority.value;
        const productFunctionPath = this.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber;
        const component = this.fragmentControllers.BasicInformationStep.data.component.info;
        let detailDescription = this.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription || "";
        detailDescription = encodeURIComponent(detailDescription);
        let isComponentExist = productFunctionPath ? productFunctionPath : `COMP:${component?.CompName}`;
        // if SAC change component then ModelNumber use CompName
        if (this.isSACChangeComponent) {
            isComponentExist = `COMP:${component?.CompName}`;
            this.isSACChangeComponent = undefined;
        }
        // reset the channelssuggestedList event sent flag value
        this._channelListEventSentModel.setProperty("/isSent", false);
        this.channelIDList = [];
        this.channelDataList = [];
        return new Promise((resolve, reject) => {
            jQuery.ajax(`/backend/raw/support/ChannelRecommender?$filter=CaseTitle eq '${shortText}' and CaseDescription eq '${detailDescription}' and SystemNumber eq '${systemNum}' and Priority eq '${priority}' and ModelNumber eq '${isComponentExist}' and UseCaseID eq 'S4MSupportCreate'`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                success: (data) => {
                    // to record channel ID in track
                    const newData = data.filter((item) => {
                        return item?.Status === "A";
                    });
                    this.channelDataList = newData;
                    this.channelIDList = newData.map(item => item.ChannelID);
                    this.setExpertChatChannelData(newData);
                    let method = this._channelListEventSentModel.getProperty("/sentMethod");
                    this.swaServiceEvent.swaChannelsSuggestedList(newData, method);
                    resolve(newData);
                },
                error: (error) => {
                    // When the service call fails or the returned data is unavailable, Sets the default channel recommender and jump to step 3
                    this.setDefaultBestChannel({ChannelID:"CASE"});
                    reject(error);
                },
                complete: () => {
                    this.currentCardPageView.setBusy(false);
                }
            });
        });
    };

    CaseCreationCard.prototype.setExpertChatChannelData = function(newData) {
        if (newData) {
            const chat = newData.filter(item => item.ChannelID === "CHAT");
            if (chat.length > 0 && chat[0]?.ChannelData !== "") {
                this.departmentInChannelData = JSON.parse(chat[0].ChannelData);
                const {expertChatText, isAvailable, showConfirmMessage, expertChatConnectionText} = formatter.formatExpertChatText(this.departmentInChannelData);
                this._expertChatChannel.setProperty("/expertChatStatusText", expertChatText);
                this._expertChatChannel.setProperty("/expertChatConnectionText", expertChatConnectionText || expertChatText);
                this._expertChatChannel.setProperty("/isExpertChatAvailable", isAvailable);
                this._expertChatChannel.setProperty("/showExpertChatConfirmBox", showConfirmMessage);
                this._expertChatChannel.setProperty("/expertChatWaitMinutes", this.departmentInChannelData.ESTWAITTIME);
            }
        }
    };

    CaseCreationCard.prototype._handleSaeStepAndClearChannelText = function() {
        this.closeSAEStep();
        this.getCard().getModel("$this.appointmentInformation").setProperty("/isAppointmentInformationVisible", false);
        this._setBestChannelText();
    };

    CaseCreationCard.prototype._setBestChannelText = function(oText) {
        // if oText equals undefined means clear channel text
        this._channelText = oText ?? "";
        this.fragmentControllers.BestActionStep.timeLineItem.fileText = oText ?? "";
        this.fragmentControllers.BestActionStep.timeLineItem.isFileTextVisible = !!oText;
    };

    /**
     * this func only need to call when request channel recommend, To overwrite the previous cache
     */
    CaseCreationCard.prototype.resetBestActionModel = function() {
        this.oCard.setModel(this._oBestActionModel = new JSONModel({
            bestAction: "",
            recommendedActions:[],
            alternativeChannelList:[],
            openCommunityTargetLink: "",
            saeChannelData: "",
            submitVisibleChannelCount: 0,
            AaEPChannel: {},
            ExperChatChannel: {},
            isShowChat: false,
            isShowChatBtn: false
        }), "$this.createCaseBestAction");

        // could not set in _oBestActionModel, getProperty("availableChannelArr") would return null
        this.availableChannelArr = [];

        this.oCard.setModel(this._expertChatChannel = new JSONModel({
            expertChatStatusText: "",
            expertChatConnectionText: "",
            isExpertChatAvailable: true,
            showExpertChatConfirmBox: false,
            expertChatWaitMinutes: 0,
            isShowExpertChatStatusTextInSubmit: false,
            isShowExpertChatChangeWarningTextInSubmit : false,
            ExpertChatChangeWarningTextInSubmit : this._i18n.getText("case_create_expert_channel_change_warning_message")
        }), "$this.expertChatChannel");
    };

    /**
     * call this when you need to refresh the channel recommender in best action
     * 1. First reset the channel model.
     * 2. Check if the expert chat is available
     * 3. Get the channel recommender data Array
     * 4. Sort the channel recommender data Array, currently the sort is only based on the expert chat
     * 5. Create the UI based on the channel recommender data Array
     * 6. Update or Close the SAE channel if there existed SAE in timeline before
     */
    CaseCreationCard.prototype.channelRecommender = function(source = "") {
        // if aaep selected,  keep creation channel
        if (this.aaepClosedByPoster) {
            return;
        }
        this.resetBestActionModel();
        this.currentCardPageView.setBusy(true);
        switch (source) {
            case "sacChangeComp":
                this._channelListEventSentModel.setProperty("/sentMethd", "SAC");
                break;
            case "dialogChangeComp":
                this._channelListEventSentModel.setProperty("/sentMethod", "Submit");
                break;
            default:
                break;
        }
        return this.requestChannelRecommend().then((availableChannelArr) => {
            this.availableChannelArr = availableChannelArr;
            this.currentCardPageView.setBusy(false);
            this.setChannelBtnEnable();
            this.sortRecommenderChannel();
            this.dynamicCreateUIForCaseBestAction();
            this.updateSAEChannelData();
            return availableChannelArr;
        });
    };

    CaseCreationCard.prototype.setIntervalToChannelRecommender = function() {
        // if aaep selected,  keep creation channel
        if (this.aaepClosedByPoster) {
            return;
        }
        switch (this._oCurrentProcess) {
            case this._oProcessBarActionStepIndex:
            case this._oProcessBarSubmitStepIndex:
                clearInterval(this.timer);
                this.timer = setInterval(async() => {
                    this.channelRecommender().then(() => {
                        this.setSubmitPageChannelModel();
                        if (this._channelText === this._i18n.getText("case_creation_best_action_expert_chat")) {
                            this.onPressExpertChatChannel();
                        }
                    });
                }
                ,120 * 1000);
                break;
            default:
                clearInterval(this.timer);
                break;
        }
    };

    /**
     * should put expert chat to last position if expert chat is not available
     */
    CaseCreationCard.prototype.sortRecommenderChannel = function() {
        const isExpertChatAvailable = this._expertChatChannel.getProperty("/isExpertChatAvailable");
        if (this.availableChannelArr.length > 1) {
            const chatIndex = this.availableChannelArr.findIndex(item => item.ChannelID === "CHAT");
            if (chatIndex !== -1) {
                // if expert chat is not available then put it to last position
                if (!isExpertChatAvailable) {
                    const chatData = this.availableChannelArr.splice(chatIndex, 1);
                    this.availableChannelArr.push(chatData[0]);
                }
                // if expert chat can be pressed but wait time more than 30 minutes then put it to last can be pressed position
                if (isExpertChatAvailable && this._expertChatChannel.getProperty("/expertChatWaitMinutes") > 30) {
                    const chatData = this.availableChannelArr.splice(chatIndex, 1);
                    const lastIndex = this.availableChannelArr.findLastIndex(item => item.isEnabledPress);
                    this.availableChannelArr.splice(lastIndex + 1, 0, chatData[0]);
                }
            }
        }
    };

    CaseCreationCard.prototype.setChannelBtnEnable = function() {
        this.availableChannelArr.forEach( e => {
            e.isEnabledPress = true;

            if (e.ChannelID === "SAE" && CreationHelper.selectedCustomerIsSupported()) {
                e.isEnabledPress = false;
            }

            if (e.ChannelID === "CHAT") {
                e.isEnabledPress = CreationHelper.selectedCustomerIsSupported() ? false : this._expertChatChannel.getProperty("/isExpertChatAvailable");
            }

        });

        // ordered by isEnabledPress, 'true' should in front of 'false'
        this.availableChannelArr.sort((a,b) => b.isEnabledPress - a.isEnabledPress);
    };

    CaseCreationCard.prototype.updateSAEChannelData = function() {
        const isAppointmentInformationVisible = this.getCard().getModel("$this.appointmentInformation").getProperty("/isAppointmentInformationVisible");
        // if appointment information is not visible before, do nothing
        if (!isAppointmentInformationVisible) {
            return;
        }

        const saeItem = this.availableChannelArr.find(v => v?.ChannelID === "SAE");
        if (saeItem) {
            // if SAE is available, update SAE data by new selected component
            this.updateSAEData();
        } else {
            // if SAE is not available, clear SAE
            this.closeSAEStep();
        }
    };

    /**
     * The UI page is dynamically modified based on the channel recommender data returned by W7
     */
    CaseCreationCard.prototype.dynamicCreateUIForCaseBestAction = function() {
        // When the service call fails or the returned data is unavailable, Sets the default channel recommend create a case
        if (this.availableChannelArr.length === 0) {
            this.setDefaultBestChannel({ChannelID:"CASE"});
        } else if (this.availableChannelArr.length === 1 && (this.availableChannelArr[0].ChannelID === "CASE" || (this.availableChannelArr[0].ChannelID === "SAE" && this.availableChannelArr[0].isEnabledPress) )) {
            // When only one channel is returned, the corresponding channel is directly entered
            // if recommender return single data and ChannelID equal CASE or SAE--(login user should not be the supported user) then chose this channel recommend and jump to step 3
            this.setDefaultBestChannel();
        } else {
            this.setBestActionsUIDisplay();
        }
    };

    /**
     * if channel recommend return 0 or response error then set default channel 'create a case' then jump to step 3
     */
    CaseCreationCard.prototype.setDefaultBestChannel = function(sDefaultChannelEntry) {
        this.setBestActionsUIDisplay(sDefaultChannelEntry);
        if (this._oCurrentProcess === this._oProcessBarActionStepIndex) {
            this.skipStepTwo();
        }
    };

    /**
     *  skip step 2 only for sae & case create
     */
    CaseCreationCard.prototype.skipStepTwo = function() {
        const itemTxt = this._oBestActionModel.getProperty("/bestAction/text");
        const event = new Event("press",new Button().setText(itemTxt),{});
        this.fragmentControllers.BestActionStep.onChannelRecommenderPressed(event);
    };

    CaseCreationCard.prototype.setBestActionsUIDisplay = function(sDefaultChannelEntry) {
        // no data return then construct default entry for availableChannelArr
        if (sDefaultChannelEntry) {
            sDefaultChannelEntry.isEnabledPress = true;
            this.availableChannelArr?.push(sDefaultChannelEntry);
        }

        const resultArr = this.setBestActionEntries();
        // set up the UI display model (at least one entry would be provided)
        this._oBestActionModel.setProperty("/bestAction", resultArr.shift());
        this._oBestActionModel.setProperty("/recommendedActions", resultArr);
    };

    CaseCreationCard.prototype.setBestActionEntries = function() {
        let resultEntry;
        let resultEntryArray = [];
        this.availableChannelArr.forEach(e => {
            switch (e.ChannelID) {
                case "CASE":
                    resultEntry = {icon:"sap-icon://write-new-document",text: this._i18n.getText("case_creation_best_action_create_a_case")};
                    break;
                case "CHAT":
                    resultEntry = {icon:"sap-icon://discussion",text: this._i18n.getText("case_creation_best_action_expert_chat")};
                    break;
                case "SAE":
                    this._oBestActionModel.setProperty("/saeChannelData", e.ChannelData ? JSON.parse(e.ChannelData) : {});
                    resultEntry = {icon:"sap-icon://appointment",text: this._i18n.getText("case_creation_best_action_expert_session")};
                    break;
                case "AEP":
                    if (!this.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription.includes("***Expert Peer Session Transcript***")) {
                        this._oBestActionModel.setProperty("/AaEPChannel", e.ChannelData ? JSON.parse(e.ChannelData) : {});
                        resultEntry = {icon:"sap-icon://travel-request",text: this._i18n.getText("case_creation_best_action_expert_peer")};
                    }
                    break;
                case "COM":
                    this._oBestActionModel.setProperty("/openCommunityTargetLink", JSON.parse(e.ChannelData)?.SOURCE);
                    resultEntry = {icon:"sap-icon://sys-help",text:this._i18n.getText("case_creation_best_action_open_question")};
                    break;
            }

            if (resultEntry) {
                resultEntry.isEnabledPress = e.isEnabledPress;
                resultEntry.channelReason = e?.ChannelReason !== "Unknown" ? e.ChannelReason : "";
                resultEntryArray.push(resultEntry);
            }
        });
        return resultEntryArray;
    };

    CaseCreationCard.prototype.getChannelIDByText = function(sText) {
        return {
            [this._i18n.getText("case_creation_best_action_create_a_case")]: "CASE",
            [this._i18n.getText("case_creation_best_action_expert_chat")]: "CHAT",
            [this._i18n.getText("case_creation_best_action_expert_session")]: "SAE",
            [this._i18n.getText("case_creation_best_action_expert_peer")]: "AEP",
            [this._i18n.getText("case_creation_best_action_open_question")]: "COM",
        }[sText];
    };

    CaseCreationCard.prototype.formatIsShowExpertChatText = function(sText) {
        return sText === this._i18n.getText("case_creation_best_action_expert_chat") && !!this._expertChatChannel.getProperty("/expertChatStatusText");
    };

    CaseCreationCard.prototype.onPressExpertChatChannel = function() {
        this._setCreationCardToExpertChatStatus();
        // toggle off the visiility of chat btn in the submit step
        this._oBestActionModel.setProperty("/isShowChatBtn", false);
        if (FeatureToggles.get("feature-support-service-now-chat") && this.departmentInChannelData.CHAT_QUEUE_ID) {
            this.snoChat = new ServiceNowExpertChat(this);
        }
        if (this._oCurrentProcess === this._oProcessBarActionStepIndex) {
            this.timeLineLayoutControl.onProcessPreviewEditButtonPressed(null,this._oProcessBarDetailedStepIndex);
        }
    };

    CaseCreationCard.prototype.onPressCreateCaseChannel = function() {
        this._setCreationCardToCreateCaseStatus();
        // if in last step chose 'create a case', then set SAE visible false, and set 'book session' button to 'submit case'
        if (this._oCurrentProcess === this._oProcessBarActionStepIndex) {
            this.fragmentControllers.BestActionStep.onContinueButtonPressed();
        } else if (this._oCurrentProcess === this._oProcessBarAppointmentInformationStepIndex) {
            // when clicked "create a case" in sae step
            this.fragmentControllers.CaseCreationAppointmentInformationStep.onContinueButtonPressed();
        }
    };

    CaseCreationCard.prototype.addChannelIdInfoToLongtext = function(selectedChannelTxt) {
        this.channelDataList.forEach((item) => {
            const channelTxt = item.ChannelText ? JSON.parse(item.ChannelText) : "";
            if (channelTxt.length !== 0) {
                if ((channelTxt[0].TEXT === "Create Case" && selectedChannelTxt === this._i18n.getText("case_creation_best_action_create_a_case"))
                    || (channelTxt[0].TEXT === "Schedule an Expert" && selectedChannelTxt === this._i18n.getText("case_creation_best_action_expert_session"))
                    || (channelTxt[0].TEXT === selectedChannelTxt)) {
                    // set property
                    this.getModel("$this.detailedInformation").setProperty("/TagID", item.TagID);
                    this.getModel("$this.detailedInformation").setProperty("/AreaID", item.AreaID);
                }
            } else if ((item.ChannelID === "CASE" && selectedChannelTxt === this._i18n.getText("case_creation_best_action_create_a_case"))
                   || (item.ChannelID === "COM" && selectedChannelTxt === this._i18n.getText("case_creation_best_action_open_question"))) {
                this.getModel("$this.detailedInformation").setProperty("/TagID", item.TagID);
                this.getModel("$this.detailedInformation").setProperty("/AreaID", item.AreaID);
            }
        });
    };

    CaseCreationCard.prototype.setSubmitPageChannelModel = function() {
        // best action + other recommended actions - the chosen one = left alternative list
        const bestAction = this._oBestActionModel.getProperty("/bestAction");
        const recommendedActions = this._oBestActionModel.getProperty("/recommendedActions");
        const alternativeList = [bestAction].concat(recommendedActions).filter(e => e.text !== this._channelText);
        // substract expert chat from the channelList for horizontal styling in submit step
        const expertChatIdx = alternativeList.findIndex(channel => channel.text === "Expert Chat");
        if (expertChatIdx > -1) {
            this._oBestActionModel.setProperty("/ExperChatChannel", alternativeList[expertChatIdx]);
            this._oBestActionModel.setProperty("/isShowChat", true);
            this._oBestActionModel.setProperty("/isShowChatBtn", true);
            alternativeList.splice(expertChatIdx, 1);
        }
        this._oBestActionModel.setProperty("/alternativeChannelList", alternativeList);
    };

    CaseCreationCard.prototype.openExpertChat = function() {
        if (helper.isTrial) {
            MessageBox.error(this._i18n.getText("case_creation_expert_mode_error"));
            return;
        }
        const showExpertChatConfirmBox = this._expertChatChannel.getProperty("/showExpertChatConfirmBox");
        const DialogType = mobileLibrary.DialogType;
        const ButtonType = mobileLibrary.ButtonType;

        if (showExpertChatConfirmBox) {
            if (!this._oExpertChatWarningMessageDialog) {
                this._oExpertChatWarningMessageDialog = new Dialog({
                    type: DialogType.Message,
                    title: this._i18n.getText("case_create_expert_channel_launch"),
                    state: CoreLib.ValueState.Warning,
                    content: new sap.m.Text({text: this._i18n.getText("case_create_expert_channel_launch_message")}),
                    beginButton: new Button({
                        type: ButtonType.Emphasized,
                        text: this._i18n.getText("case_create_expert_channel_join_queue"),
                        press: function() {
                            this._oExpertChatWarningMessageDialog.close();
                            this.launchExpertChatDialog();
                        }.bind(this)
                    }),
                    endButton: new Button({
                        text: this._i18n.getText("case_create_expert_channel_quit"),
                        press: function() {
                            this._oExpertChatWarningMessageDialog.close();
                        }.bind(this)
                    }),
                });
            }

            this._oExpertChatWarningMessageDialog.open();
        } else {
            this.launchExpertChatDialog();
        }
    };

    CaseCreationCard.prototype.launchExpertChatDialog = function() {
        if (this.expertChatDialog) {
            this.expertChatDialog.openPADialog();
        } else {
            (this.expertChatDialog = new CaseCreationExpertChatDialog(this)).openPADialog();
        }
    };

    CaseCreationCard.prototype.launchExpertChat = function() {
        if (this.departmentInChannelData.CHAT_QUEUE_ID) {
            this.snoChat.chatInit();
        }
    };

    /** ************************************************************************************** */
    /*                           Detailed Information Event Handlers                          */
    /** ************************************************************************************** */

    /**
     * replace the component by using recommended component in SAC if it is not empty
     */
    CaseCreationCard.prototype.checkSACRecommendedComponent = function() {
        const recommendedComponent = CaseCreationSAC.getRecommendedComponent();
        this._oTrackingData.init_select_data.sac_node_id = CaseCreationSAC.getCompChangedCurrentNodeId();
        const previousCompName = this.fragmentControllers.BasicInformationStep.data.component.info?.CompName;
        if (previousCompName === recommendedComponent.CompName) {
            return;
        }

        if (!this._componentSelectDialog) {
            this._componentSelectDialog = new CreateSelectComponentDialog(this);
        }
        this.selectComponent = {
            ...recommendedComponent,
            selectionMethod: "Support Assistant",
            submitStepEventInfo : {systemAction : "Support Assistant",determinedBy:CaseCreationSAC.getCompChangedCurrentNodeId()}
        };

        this._componentSelectDialog._requestProductByComp("sac").then((data) => {
            this.fragmentControllers.BasicInformationStep.data.component.info = this.selectComponent;
            this.isSACChangeComponent = true;
            this._slaFilesEventSentModel.setProperty("/isSent", false);
            this.processPPFCSelectionRecordsArr(ComponentMemoUtil.normalSac(recommendedComponent.CompName));
            this._componentSelectDialog._handleProductPartAfterRequest(data.data, data.method);
            this.fragmentControllers.CaseCreationAttachmentStep.resetSuggestFileTypeList(recommendedComponent.CompName);
            this._channelListEventSentModel.setProperty("/sentMethod", "SAC");
            this.handleProcessAfterProSelection();
            // this.getRecommendedSolutionList ();
            this.channelRecommender("sacChangeComp").then(() => {
                this._channelChangeCheckIfSetToCreateCase("SAC");
                // need to refresh channel of submit step, sometimes the channel list is different as before when sac component changed
                this.setSubmitPageChannelModel();
            });
        }).catch(() => {
            // means prevent. do nothing
        })
    };

    CaseCreationCard.prototype.getRecommendedSolutionList = function() {
        const shortDescription = this.fragmentControllers.BasicInformationStep.data.shortDesc;
        const systemNumber = this.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber;
        const installationNbr = this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr;
        const product = this.fragmentControllers.BasicInformationStep.data.product.info;
        const component = this.fragmentControllers.BasicInformationStep.data.component.info;
        const {detailedDescription, stepsToReproduce} = this.fragmentControllers.CaseCreationDetailedInformationStep.data;
        const hotAndTrending = this._oHotAndTrendingModel.getProperty("/all");
        if (Object.keys(this._cacheSACAnswerMap?.questionsMap ?? {}).length > 0) {
            this?._cacheSacQuestionList.push(Object.values(this._cacheSACAnswerMap?.questionsMap));
        }
        let payload = {
            title: shortDescription,
            problemDescription: detailedDescription,
            systemNumber: systemNumber ? systemNumber : "",
            installationNumber: installationNbr ? installationNbr : "",
            leadingproduct_id: product ? product.SoftwareProductNumber : "",
            component: component ? component.CompName : "",
            stepsToReproduce: stepsToReproduce,
            productKnowledgeSet: hotAndTrending,
            treeInteractionSet: this?._cacheSacQuestionList ?? []
        };
        if (this._oSimulatedUser) {
            payload.userId = this._oSimulatedUser;
        }
        jQuery.ajax("/backend/raw/support/CaseCreateCaseSolution", {
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            async: true,
            data: JSON.stringify(payload),
            success: (data) => {
                this.afterGetRecommendedSolutionList(data);
            }
        });
    };

    CaseCreationCard.prototype.afterGetRecommendedSolutionList = function(data) {
        if (data.length === 0) {
            this._oRecommendedSolutionModel.setProperty("/isShow",false);
        } else {
            // in case Ism load in submit step
            if (this._oCurrentProcess !== this._oProcessBarSubmitStepIndex) {
                this.setExpertTrendingSolutionVisible("R");
            }
            this._oRecommendedSolutionModel.setProperty("/isShow",true);
            this._oRecommendedSolutionModel.setProperty("/all",data);
            data.length > 3 ? this.fragmentControllers.SubmitStep._oSubmitPageModel.setProperty("/topSuggestedList",data.slice(0, 5))
                : this.fragmentControllers.SubmitStep._oSubmitPageModel.setProperty("/topSuggestedList",data);
            this._oIssueInformationModel.setProperty("/isRecommendedContentShown", true);
        }
    };

    CaseCreationCard.prototype.onNavToRecommendedSolution = function(oEvent) {
        // swa  ISM knowledge entry pressed (+ position in list)
        const oBinding = oEvent.getSource().getBindingContext("recommendedSolutionList");
        const recommendSolution = oBinding.getObject();
        const aPath = oBinding.sPath.split("/");
        const tagNames = [];
        const productName = this.fragmentControllers.BasicInformationStep.data.productFunction.info?.FullName || this.fragmentControllers.BasicInformationStep.data.product.info?.DisplayName || "";
        const modelNbr = this.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber || this.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber || "";
        recommendSolution.trending && tagNames.push("Trending");
        recommendSolution.hot && tagNames.push("Hot");
        this.swaServiceEvent.swaISMKnowledgePressed(recommendSolution,aPath[aPath.length - 1],JSON.stringify(tagNames), productName, modelNbr);
        if (recommendSolution.external_url) {
            sap.m.URLHelper.redirect(recommendSolution.external_url, true);
        }
    };

    CaseCreationCard.prototype.onNavToHotAndTrendingUrl = function(oEvent) {
        // swa  simcat knowledge entry pressed (+ position in list)
        const oBinding = oEvent.getSource().getBindingContext("hotAndTrendingList");
        const hotAndTrending = oBinding.getObject();
        const aPath = oBinding.sPath.split("/");
        const tagNames = JSON.parse(hotAndTrending.Tag).filter(item => item.tag === "HOT" || item.tag === "TRENDING" || item.tag === "CRITICAL").map(item => this.shiftCapitalization(item.tag));
        this.swaServiceEvent.swaSimCatKnowledgePressed(hotAndTrending,aPath[aPath.length - 1],JSON.stringify(tagNames));
        if (hotAndTrending.URL) {
            sap.m.URLHelper.redirect(hotAndTrending.URL, true);
        }
    };

    CaseCreationCard.prototype.shiftCapitalization = function(label) {
        return label[0] + label.substring(1).toLowerCase();
    };

    CaseCreationCard.prototype.onNavToCoveoRecommendation = function(oEvent) {
        const coveoRecommendationData = oEvent.getSource().getBindingContext("coveoRecommendationList").getObject();
        if (coveoRecommendationData.URL) {
            if (coveoRecommendationData.raw) {
                this.coveoUtil.trackClickEvent(coveoRecommendationData.raw);
            }
            sap.m.URLHelper.redirect(coveoRecommendationData.URL, true);
        }
    };

    CaseCreationCard.prototype.afterGetSACcontentRecommendations = function(data) {
        if (data.length === 0) {
            this._oSACContentRecommendationsModel.setProperty("/isShow",false);
        } else {
            this.setExpertTrendingSolutionVisible("S");
            this._oSACContentRecommendationsModel.setProperty("/isShow",true);
            this._oSACContentRecommendationsModel.setProperty("/all",data);
            this._oIssueInformationModel.setProperty("/isRecommendedContentShown", true);
        }
    };

    CaseCreationCard.prototype.onNavToSACcontentRecommendationUrl = function(oEvent) {
        // sac question related content recommendation entry pressed (+ position in list)
        const oBinding = oEvent.getSource().getBindingContext("sacContentRecommendationsList");
        const sacContentRecommendation = oBinding.getObject();
        const aPath = oBinding.sPath.split("/");
        this.swaServiceEvent.swaSACKnowledgePressed(sacContentRecommendation,aPath[aPath.length - 1], CaseCreationSAC.getKnowledgePressedTreeNodeId(), CaseCreationSAC.getKnowledgePressedCurrentNodeId());
        if (sacContentRecommendation.url) {
            sap.m.URLHelper.redirect(sacContentRecommendation.url, true);
        }
    };

    CaseCreationCard.prototype.formatTypeAndCategory = function(type, category) {
        if (type && category) {
            return `${type} (${category})`;
        } else if (!type && category) {
            return category;
        } else if (type && !category) {
            return type;
        }
        return "";

    };

    /** ************************************************************************************** */
    /*                              Detailed Information Functions                            */
    /** ************************************************************************************** */

    CaseCreationCard.prototype.checkISOnlyContainWhiteSpaceAndBreakLine = function(str) {
        const reg = new RegExp("<br>|<br/>|<br />", "g");
        if (str.replace(reg,"").trim().length === 0) {
            return true;
        }
        return false;
    };

    CaseCreationCard.prototype.saveDetailedInformationData = function() {
        /**
         * if current channel is expert chat then next step is submit.
         */
        if (this._channelText === this._i18n.getText("case_creation_best_action_expert_chat")) {
            this._oCurrentProcess += 4;
            // submit step
            this.fragmentControllers.SubmitStep.timeLineItem.isStepPreviewEditEnabled = true;
            this.refreshProcessBarDisplay(this._oCurrentProcess);
            this.setTargetPartVisible(this._oCurrentProcess);
            return;
        }

        /**
         * Go to next step.
         */
        this._oCurrentProcess++;

        // attachment step
        this.fragmentControllers.CaseCreationAttachmentStep.timeLineItem.isStepPreviewEditEnabled = true;
        this.refreshProcessBarDisplay(this._oCurrentProcess);
        this.setTargetPartVisible(this._oCurrentProcess);
        this._oContinueButtonModel.setProperty("/isContinueButtonEnabled", true);
    };

    /** ************************************************************************************** */
    /*                                       Appointment Information Functions                            */
    /** ************************************************************************************** */
    CaseCreationCard.prototype.closeSAEStep = function() {
        // clear SAE data
        this.fragmentControllers.CaseCreationAppointmentInformationStep.initSAEModel();
        // hide SAE step
        this.fragmentControllers.CaseCreationAppointmentInformationStep.timeLineItem.isStepVisible = false;
    };

    CaseCreationCard.prototype.saveAppointmentData = function() {
        this._oCurrentProcess++;
        // submit step
        this.fragmentControllers.SubmitStep.timeLineItem.isStepPreviewEditEnabled = true;
        this.refreshProcessBarDisplay(this._oCurrentProcess);
        this.setTargetPartVisible(this._oCurrentProcess);
    };

    CaseCreationCard.prototype.updateSAEData = function() {
        const channelData = this._oBestActionModel.getProperty("/saeChannelData");
        const serviceTimezone = channelData?.TimezoneUTC ?? "UTC";
        const {result, isTotalAvailable} = SAEHelper.formatTimeToLocalTimezone(channelData?.DAYS, serviceTimezone);

        const appointmentInformationModel = this.getCard().getModel("$this.appointmentInformation");
        appointmentInformationModel.setProperty("/isTotalAvailable", isTotalAvailable);
        appointmentInformationModel.setProperty("/dayList", result);
        appointmentInformationModel.setProperty("/userProfileTimezone", serviceTimezone);
        appointmentInformationModel.setProperty("/localTimezone", sap.ui.core.Configuration.getTimezone());

        // by default, selected the first available day
        if (isTotalAvailable) {
            this.fragmentControllers.CaseCreationAppointmentInformationStep.selectAppointmentDay(result);
        } else {
            // The previous data should be cleared
            appointmentInformationModel.setProperty("/selectedDay", -1);
            appointmentInformationModel.setProperty("/timePeriodOptions", SAEHelper.getTimePeriodOptions());
            appointmentInformationModel.setProperty("/availableCount", 0);
            appointmentInformationModel.setProperty("/selectedTimeItem", {});
        }
    };

    CaseCreationCard.prototype.onPressSAEChannel = function() {
        this.updateSAEData();
        this.getCard().getModel("$this.appointmentInformation").setProperty("/isAppointmentInformationVisible", true);

        // when click schedule an expert session in submit step, it will go back to the appointment information step
        if (this._oCurrentProcess === this._oProcessBarSubmitStepIndex) {
            this._setCreationCardToSAEStatus().then(res => {
                this.timeLineLayoutControl.onProcessPreviewEditButtonPressed(null,this._oProcessBarAppointmentInformationStepIndex);
            });

        } else {
            this._setCreationCardToSAEStatus().then(res => {
                this.timeLineLayoutControl.onProcessPreviewEditButtonPressed(null, this._oProcessBarDetailedStepIndex);
            });

        }
    };

    CaseCreationCard.prototype.deleteDraft = function(successCallback, completeCallback) {
        const pointer = this._oIssueInformationModel.getProperty("/pointer");
        if (!pointer) {
            completeCallback && completeCallback();
            return;
        }

        jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({
                action: "COMPLETE",
                pointer: pointer,
                draft_flag: "X"
            }),
            success: (data) => {
                this._oIssueInformationModel.setProperty("/pointer", undefined);
                successCallback && successCallback(data);
            },
            complete: () => {
                completeCallback && completeCallback();
            }
        });
    };

    /** ************************************************************************************** */
    /*                                    Ask an Expert Peer Functions                        */
    /** ************************************************************************************** */

    /**
     * when click Ask an Expert Peer
     * - Go to detailed information step, and only display Detailed Description Input
     * - Hide step after Detailed Information step
     * - Continue button text change to Send Description
     */
    CaseCreationCard.prototype.onPressAaEP = function() {
        // if clicked AaEP in submit step, just start to chat
        if (this._oCurrentProcess === this._oProcessBarSubmitStepIndex) {
            this.sendDetailDescriptionForAaep();
            return;
        }
        this._setTimeLineToAaEP().then(res => {
            this.timeLineLayoutControl.onProcessPreviewEditButtonPressed(null, this._oProcessBarDetailedStepIndex);
        });
    };

    /**
     * when click Send Description
     * - delete draft
     * - create an AaEP session
     * - load the Directly Expert Chat
     */
    CaseCreationCard.prototype.sendDetailDescriptionForAaep = function() {
        this.coveoUtil.sendCoveoAnalytics("CreateCase", "AskExpertPeer", this._oIssueInformationModel.getData(), true, this.fragmentControllers.BasicInformationStep.data);
        const data = this.getSubmitData();
        data.action = "SAVEAAEP";
        this.currentCardPageView.setBusy(true);
        this.deleteDraft(null, () => {
            this.callUpdateBackendAPI("POST", data).then((data) => {
                this.currentCardPageView.setBusy(false);
                this._oIssueInformationModel.setProperty("/pointer", data.Pointer);
                if (this.AaEPService) {
                    this.AaEPService.loadAaEP(data.Pointer);
                } else {
                    this.AaEPService = new AaEPService(this, data.Pointer);
                }
            }).catch(() => {
                this.currentCardPageView.setBusy(false);
                if (helper.isTrial) {
                    MessageBox.error(this._i18n.getText("case_creation_create_mode_error"));
                } else {
                    this.submitFailedDialog();
                }
            });
        });
    };

    CaseCreationCard.prototype.updateAaEPChatToDetailDescription = function(AaEPMessageText) {
        if (!AaEPMessageText) {
            return;
        }
        this.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription += AaEPMessageText;
    };

    /**
    * convert to normal case flow if user select AaEP is not resolved problem
    */
    CaseCreationCard.prototype.convertAaEPToCreateACase = function() {
        this._setCreationCardToCreateCaseStatus();
        this.setSubmitPageChannelModel();
        if (this._oCurrentProcess !== this._oProcessBarSubmitStepIndex) {
            this.timeLineLayoutControl.onProcessPreviewEditButtonPressed(null, this._oProcessBarActionStepIndex);
            this.timeLineLayoutControl.data.timeLineItems.forEach((item, index) => {
                item.isStepVisible = index <= this._oProcessBarActionStepIndex;
            });
            this.timeLineLayoutControl.updateTimeLineItemsModel();
        }
    };

    CaseCreationCard.prototype.getAttxString = function() {
        // this function is fit to normal case creation, not for SAE
        const isAppointmentInformationVisible = this.getCard().getModel("$this.appointmentInformation").getProperty("/isAppointmentInformationVisible");
        if (isAppointmentInformationVisible) {
            return [];
        }

        const pointer = this._oIssueInformationModel.getProperty("/pointer") || "";
        const userInfo = this._oUserModel.getData();
        const dataProcessRestriction = this.fragmentControllers.BasicInformationStep.data.system.info?.dataProcessRestriction;
        const installationNbr = this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr || "";
        const formattedAttachments = this.attachmentService.formatAttachments(dataProcessRestriction);
        const attxstr = this.attachmentService.getAttachmentStringList(formattedAttachments, pointer, userInfo, installationNbr);

        return attxstr;
    };

    /** ************************************************************************************** */
    /*                                       Contacts Functions                            */
    /** ************************************************************************************** */

    CaseCreationCard.prototype.saveContacts = function() {
        const isAppointmentInformationVisible = this.getCard().getModel("$this.appointmentInformation").getProperty("/isAppointmentInformationVisible");
        this._oCurrentProcess++; // appointment step
        // when appointment step is not available, it will skip the appointment step
        if (!isAppointmentInformationVisible) {
            this._oCurrentProcess++; // submit step
        }
        const stepName = isAppointmentInformationVisible ? "CaseCreationAppointmentInformationStep" : "SubmitStep";
        this.fragmentControllers[stepName].timeLineItem.isStepPreviewEditEnabled = true;
        this.refreshProcessBarDisplay(this._oCurrentProcess);
        this.setTargetPartVisible(this._oCurrentProcess);

    };

    CaseCreationCard.prototype.setContactProcessBar = function() {
        // At beginning, total step and current step should set to 1;
        // When priority set to vh, count of total step should plus one, and if primary contact is filled, current step should plus one;
        // When user is supported, total step and current step should plus one;
        this.fragmentControllers.CaseCreationContactStep.updateTimelineProgress();
    };

    /** ************************************************************************************** */
    /*                                       Submit Functions                            */
    /** ************************************************************************************** */
    CaseCreationCard.prototype.assembleLongText = function() {
        let longText = "";
        // product/pf/c
        longText += Constants.CASE_CREATION_LONG_TEXT_BLOCK.PPFC;
        if (this._oSelectionMethodRecordsTxt?.length > 1 || this._oSelectionMethodRecords?.length >= 1) {
            // new case and draft scenario, assemble the pf txt from parsing long text and stored array
            longText += this._oSelectionMethodRecordsTxt + new MemoAction().assemblePPFCselectionRecords(this._oSelectionMethodRecords);
        } else {
            // compatible to the old cases that don't have a selection method records
            if (this.fragmentControllers.BasicInformationStep.data.product.info) {
                longText += "Product selected: " + this.fragmentControllers.BasicInformationStep.data.product.info?.DisplayName + "<br />";
            }
            if (this.fragmentControllers.BasicInformationStep.data.productFunction.info) {
                longText += "Product Function selected: " + this.fragmentControllers.BasicInformationStep.data.productFunction.info?.FullName + "<br />";
            }
            longText += "Component selected (" + this.fragmentControllers.BasicInformationStep.data.component.info?.selectionMethod + "): " + this.fragmentControllers.BasicInformationStep.data.component.info?.CompName + "<br />";
        }
        // product/pf check text
        if (this.checkResultTxt) {
            longText += "Entitlement check text: " + this.checkResultTxt + "<br />";
        }
        // ariba guided answer & draft text
        const aribaAddonText = this.fragmentControllers.CaseCreationAribaQA.getAribaAddOnText() || this._aribaGATxt;
        if (aribaAddonText) {
            longText += aribaAddonText;
        }
        // support asistant (sac)
        const sacValue = this.getCard().getModel("$this.detailedInformation").getProperty("/sacInfo/value");
        if ( sacValue && sacValue.length > 0) {
            longText += Constants.CASE_CREATION_LONG_TEXT_BLOCK.SAC;
            longText += this.getCard().getModel("$this.detailedInformation").getProperty("/sacInfo/value");
        } else {
            let sacText = CaseCreationSAC.restoreQuestionIntoDescriptionArea();
            if (sacText.length > 1) {
                longText += Constants.CASE_CREATION_LONG_TEXT_BLOCK.SAC;
                longText += sacText;
            }
        }

        // ChannelRecommender TagID, AreaID
        longText += Constants.CASE_CREATION_LONG_TEXT_BLOCK.TAGID;
        let tagID = this.getCard().getModel("$this.detailedInformation").getProperty("/TagID") ? this.getCard().getModel("$this.detailedInformation").getProperty("/TagID").toString() : "";
        let areaID = this.getCard().getModel("$this.detailedInformation").getProperty("/AreaID") ? this.getCard().getModel("$this.detailedInformation").getProperty("/AreaID").toString() : "";
        longText += `TagID: ${tagID}<br />`;
        longText += `AreaID: ${areaID}<br />`;
        // steps to reproduce
        const detailInformationModel = this.getModel("$this.detailedInformation");
        const {detailedDescription, stepsToReproduce} = this.fragmentControllers.CaseCreationDetailedInformationStep.data;
        if (stepsToReproduce || detailInformationModel.getProperty("/isStepsToReproduceReminderSelected")) {
            longText += Constants.CASE_CREATION_LONG_TEXT_BLOCK.STEPS;
            longText += stepsToReproduce ? helper.deleteEnterFromBothSide(stepsToReproduce) + "<br />" : "";
            longText += detailInformationModel.getProperty("/isStepsToReproduceReminderSelected") ? Constants.SAP4MEP_STEPS_TO_PRODUCE_CHECKBOX_YES_TEXT : "";
        }
        // issue happened time
        const issueHappenedStartTime = detailInformationModel.getProperty("/issueHappenedStartTime");
        const issueHappenedEndTime = detailInformationModel.getProperty("/issueHappenedEndTime");
        if (detailInformationModel.getProperty("/issueHappenedPartVisible") && (issueHappenedStartTime || issueHappenedEndTime)) {
            longText += Constants.CASE_CREATION_LONG_TEXT_BLOCK.ISSUEDATE;
            // transfer to UTC
            const startUTCDate = formatter.mediumDateFromUI5Date(issueHappenedStartTime, "yyyy-MM-dd HH:mm:ss", true);
            const endUTCDate = formatter.mediumDateFromUI5Date(issueHappenedEndTime, "yyyy-MM-dd HH:mm:ss", true);
            longText += `${startUTCDate || ""}${endUTCDate ? " - " + endUTCDate : ""}<br />`;
        }
        // description
        longText += Constants.CASE_CREATION_LONG_TEXT_BLOCK.DESC + helper.deleteEnterFromBothSide(detailedDescription);
        return longText;
    };

    /**
     * @description: process the record entry that is appended to the selection method records array
     * @param ppfcObj {object} {name, prefix, suffix, root}
     */
    CaseCreationCard.prototype.processPPFCSelectionRecordsArr = function(ppfcObj) {
        this._oSelectionMethodRecords.push(ppfcObj);
    };

    /**
     * @description: get basic submit data, some params(action,draft_flag,pointer) will filled when calling this.updateCase
     * @returns
     */
    CaseCreationCard.prototype.getSubmitData = function() {
        const submitData = {
            text_active: "A",
            u_name: this.selectedCutAndSuserInfo.suserNumber,
            sys_nr: this.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber,
            value_str: "",
            short_text: this.fragmentControllers.BasicInformationStep.data.shortDesc,
            long_text: this.assembleLongText(),
            language: this.fragmentControllers.BasicInformationStep.data.language,
            component: this.fragmentControllers.BasicInformationStep.data.component.info?.CompKey ?? "",
            product_selected: this.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber || "",
            attxstr: this.getAttxString(),
            priority: this.fragmentControllers.BasicInformationStep.data.priority.value,
            contacts: this._oCaseContactCreationController.setUpContactList(),
            eea_path: this.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber || "",
            dss_classified : this.fragmentControllers.BasicInformationStep.data.dss_classified ? "X" : ""
        };
        if (this.fragmentControllers.BasicInformationStep.data.priority.value < 3 && this._oIssueInformationModel.getProperty("/impactText")) {
            submitData.bitext = helper.deleteEnterFromBothSide(this._oIssueInformationModel.getProperty("/impactText"));
        }
        return submitData;
    };

    /**
     * @description usage: create a draft, update a draft.
     */
    CaseCreationCard.prototype.updateDraft = function() {
        return this.updateCase(this._oIssueInformationModel.getProperty("/pointer"),false,this.getSubmitData())
            .then(data => {
                // Save in _oIssueInformationModel will be clear up. So save in context
                if (data?.Pointer) {
                    this._oIssueInformationModel.setProperty("/pointer",data.Pointer);
                }
            },e => {
                throw new Error(e);
            });
    };

    /**
     * Load Qualtrics Service
     * must call initFeedBackSurvey() to compose Qualtrics parameters before call this function
     */
    CaseCreationCard.prototype.openQualtricsIntercept = function() {
        // this.getLanguage ().then (preferredLanguage => {  //closing parenthesis at end of this function
        const surveyUrl = "https://zncwifqo8baxlukrv-sapinsights.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_3RhlAhK4QHYAyJD";
        // const surveyUrl = "https://zncwifqo8baxlukrv-sapinsights.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_cwifqO8baXLukRv&Q_DEBUG";
        QualtricsService.initQualtricsSurvey(surveyUrl, this).then(() => {
            if (this.hasInterceptLoaded) {
                window.QSI.API.unload();
                // QSI.isDebug = true;
                window.QSI.API.load().done(window.QSI.API.run());
            }
        });
    };

    CaseCreationCard.prototype.getLanguage = function() {
        return jQuery.ajax("/backend/raw/common/Settings", {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
        }).then(data => data["PREFERENCES.LANGUAGE"]);
    };

    CaseCreationCard.prototype.isSolvedProblemDialog = function() {
        if ( this._oIssueInformationModel.getProperty("/isRecommendedContentShown") === true) {
            sap.m.MessageBox.confirm(`${this._i18n.getText("case_creation_exit_message")}`, {
                title: `${this._i18n.getText("case_creation_exit_title")}`,
                onClose: this.closeSolveProblemMessageBox.bind(this),
                styleClass: "exitProcessClass",
                actions: [`${this._i18n.getText("yes")}`,`${this._i18n.getText("no")}`,`${this._i18n.getText("cancel")}`],
                emphasizedAction:`${this._i18n.getText("yes")}`,
                initialFocus: null,
                textDirection: sap.ui.core.TextDirection.Inherit
            });
        } else {
            clearInterval(this.timer);
            this.coveoUtil.sendCoveoAnalytics("CreateCase", "CloseSolved", {...this._oIssueInformationModel.getData(),isSolveProblem:true}, true, this.fragmentControllers.BasicInformationStep.data);
            this.deleteDraft();
            this.swaServiceEvent.swaCaseCreationExit();
            this._navToNextWithoutEvent();
        }
    };

    CaseCreationCard.prototype.isSaveDraftDialog = function() {
        sap.m.MessageBox.confirm(`${this._i18n.getText("case_creation_save_draft_message")}`, {
            title: `${this._i18n.getText("case_creation_exit_if_save_draft_title")}`,
            onClose: this.closeSaveDraftCaseMessageBox.bind(this),
            styleClass: "exitProcessClass",
            actions: [`${this._i18n.getText("yes")}`,`${this._i18n.getText("no")}`],
            emphasizedAction:`${this._i18n.getText("yes")}`,
            initialFocus: null,
            textDirection: sap.ui.core.TextDirection.Inherit
        });
    };

    CaseCreationCard.prototype.submitFailedDialog = function(scenario = "") {
        const htmlText = scenario ? this._i18n.getText("case_creation_upload_failed_error_cic") : this._i18n.getText("case_creation_create_failed_error_cic");
        const cicBtnText = this._i18n.getText("case_creation_contact_cic_btn");
        sap.m.MessageBox.warning(
            new FormattedText({htmlText: htmlText}),
            {
                icon: MessageBox.Icon.WARNING,
                actions: [cicBtnText, MessageBox.Action.CANCEL],
                emphasizedAction: cicBtnText,
                initialFocus: cicBtnText,
                styleClass: "sapUiSizeCompact",
                onClose: (sAction) => {
                    if (sAction === cicBtnText) {
                        sap.m.URLHelper.redirect("https://support.sap.com/en/contact-us.html", true);
                    }
                }
            }
        );
    };

    CaseCreationCard.prototype.closeSolveProblemMessageBox = function(selectedName) {
        // Call Qualtrics Survey
        this.initFeedBackSurvey("SCENARIO2",selectedName === `${this._i18n.getText("yes")}`);
        if (selectedName === `${this._i18n.getText("yes")}`) {
            clearInterval(this.timer);
            this.coveoUtil.sendCoveoAnalytics("CreateCase", "CloseSolved", {...this._oIssueInformationModel.getData(),isSolveProblem:true}, true, this.fragmentControllers.BasicInformationStep.data);
            this.swaServiceEvent.exitDialogReply("YES");
            this.deleteDraft();
            this.swaServiceEvent.swaCaseCreationExit();
            this._navToNextWithoutEvent();
            this.openQualtricsIntercept();
        } else if (selectedName === `${this._i18n.getText("no")}`) {
            this.coveoUtil.sendCoveoAnalytics("CreateCase", "CloseUnsolved", {...this._oIssueInformationModel.getData(),isSolveProblem:false}, true, this.fragmentControllers.BasicInformationStep.data);
            this.swaServiceEvent.exitDialogReply("NO");
            let isContinueBtnEnabled = this._oContinueButtonModel.getProperty("/isContinueButtonEnabled");
            if (this._oCurrentProcess === this._oProcessBarIssueStepIndex ) {
                if (isContinueBtnEnabled) {
                    // all mandatory fileds are filled in step one , then ask if save draft
                    this.isSaveDraftDialog();
                } else {
                    this.swaServiceEvent.swaCaseCreationExit();
                    // the mandatory fields are not filled, don't save a draft
                    this._navToNextWithoutEvent();
                    this.openQualtricsIntercept();
                }
            } else {
                this.isSaveDraftDialog();
            }
        }
    };

    CaseCreationCard.prototype.closeSaveDraftCaseMessageBox = function(selectedName) {
        clearInterval(this.timer);
        switch (selectedName) {
            case `${this._i18n.getText("yes")}`:
                this.saveDraftAndNav();
                this.swaServiceEvent.draftSavedEvent("YES");
                break;
            case `${this._i18n.getText("no")}`:
                // delete the draft when this case is not a draft case
                if (!this._oIssueInformationModel.getProperty("/isDraftCase")) {
                    this.deleteDraft();
                }
                this.swaServiceEvent.draftSavedEvent("NO");
                this._navToNextWithoutEvent();
                this.openQualtricsIntercept();
                break;
        };
        this.swaServiceEvent.swaCaseCreationExit();
    };

    CaseCreationCard.prototype.saveDraftAndNav = function() {
        this.coveoUtil.sendCoveoAnalytics("CreateCase", "SaveDraft", this._oIssueInformationModel.getData(), false);
        this.updateDraft().then(() => {
            const route = {
                name: "caseDetail",
                arguments:{
                    // create a normal case rather than change draft to normal case, it need to fetch pointer again.
                    caseKey: this._oIssueInformationModel.getProperty("/pointer"),
                    section: "overview"
                }
            };
            this._navToNextWithoutEvent(route);
        },() => {
            this.submitFailedDialog();
        });
    };

    /**
     * @description usage: create draft, create normal case (will not enter this situation, beacuse it will create a draft before enter last step), update draft, change draft to normal case
     *
     * @param pointer   - draft pointer
     * @param isSubmit  - whether it is submit time
     * @param data      - other data to submit
     *
     * @return promise of update case result
     */
    CaseCreationCard.prototype.updateCase = function(pointer, isSubmit, data) {
        let method = "POST";
        if (!pointer && !isSubmit) {
            // create draft
            data.action = "SAVE";
        } else if (!pointer && isSubmit) {
            // submit normal case
            data.action = "SEND2SAP";
        } else if (pointer && !isSubmit) {
            // update draft
            method = "PUT";
            data.pointer = pointer;
            data.draftFlag = "X";
            data.action = "SAVE";
        } else {
            // change draft to normal case
            method = "PUT";
            data.pointer = pointer;
            data.draftFlag = "";
            data.action = "SEND2SAP";
        }
        this._oCaseContactCreationController.updateRecentlyUsedContact();
        return this.callUpdateBackendAPI(method,data);
    };

    CaseCreationCard.prototype.callUpdateBackendAPI = function(sMethod, sData) {
        if (sData.long_text) {
            sData.long_text = sData.long_text.replaceAll("\n", "<br>");
        }
        return new Promise((resolve, reject) => {
            jQuery.ajax("/backend/raw/support/CaseUpdateW7Verticle", {
                method: sMethod,
                contentType: "application/json",
                data: JSON.stringify(sData),
                success: (result) => {
                    resolve(result);
                },
                error: (error) => {
                    reject(error);
                }
            });
        });
    };

    /**
     * There are 3 cases:
     * prefill case - router pointer is 0 with search query, like 'createIssue/0/overview?sysnr=123456789'
     * draft case - router pointer is a draft case pointer, like 'createIssue/123456789/overview'
     * normal case - router pointer is 0, like 'createIssue/0/overview'
     */
    CaseCreationCard.prototype.getCaseCreationMode = function() {
        const pointer = this.getContext()?.attributes.draftCasePointer;
        if (pointer !== "0" && pointer) {
            return Constants.CASE_CREATION_CASE_MODE.DRAFT;
        }
        const prefillMode = PrefillHelper.checkSearchParams();
        if (prefillMode) {
            return prefillMode;
        }
        return Constants.CASE_CREATION_CASE_MODE.NORMAL;
    };

    CaseCreationCard.prototype.trackBasicInfoStepCChange = function(eventSubType, cName, rankingIndex) {
        if (!this.fragmentControllers.BasicInformationStep.data.component.visible || this._oCurrentProcess !== this._oProcessBarIssueStepIndex) {
            return;
        }
        let cFieldShownBecause,pName,pModelNum;
        if (!this.fragmentControllers.BasicInformationStep.data.product.visible) {
            cFieldShownBecause = "No Product";
        } else {
            if (!this.fragmentControllers.BasicInformationStep.data.productFunction.visible) {
                cFieldShownBecause = "No Product Function for the selected product";
            }
            // pName = this._oIssueInformationModel.getProperty("/product/DisplayName");
            // pModelNum = this._oIssueInformationModel.getProperty("/product/ModelNumber");
            pName = this.fragmentControllers.BasicInformationStep.data.product.info?.DisplayName;
            pModelNum = this.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber;
        }
        this.swaServiceEvent.swaBasicInfoStepDeterminedC(eventSubType, cName, rankingIndex, cFieldShownBecause,pName,pModelNum);
    };

    /** ************************************************************************************** */
    /*               Router functions to add onBeforeRouterLeave lifecycle                    */
    /** ************************************************************************************** */
    /**
     * common method to attach route matched event listeners
     * @private
     */
    CaseCreationCard.prototype._addRoutePatternMatchedListener = function() {
        if (this._oRoutePatternMatchedListener) {
            return;
        }
        // set router event listener
        this._oRoutePatternMatchedListener = (oEvent) => {
            const fromRoute = this._oRouter.getRouteInfoByHash(this._currentHash);
            const toRoute = oEvent.getParameters();
            // native nav from shell router
            // if nav without event, go to next route directly
            if (this._oRouter.withoutEvent) {
                this._oRouter.withoutEvent = false;
                this._navToNextWithoutEvent(toRoute);
                return;
            }
            const toHash = oEvent.getSource().getHashChanger().getHash();
            if (this._currentHash !== toHash) {
                this._toRoute = toRoute;
                this._oRouter.navTo(fromRoute.name, fromRoute.arguments, null, true);
                return;
            }
            this.onBeforeRouterLeave(fromRoute, this._toRoute, this._navToNextWithoutEvent.bind(this));
        };
        this._oRouter.attachRoutePatternMatched({}, this._oRoutePatternMatchedListener, this);
    };

    /**
     * This method is called when leave the router
     * To simplify usage, this method is implemented in this._navToNextWithoutEvent function
     * @private
     */
    CaseCreationCard.prototype._removeRouterMatchedListener = function() {
        this._oRouter.detachRoutePatternMatched(this._oRoutePatternMatchedListener, this);
        this._oRoutePatternMatchedListener = null;
        this.isNavByRouterEvent = false;
        this.clearData();
    };

    /**
     * @typedef {Object} RouteInfo
     * @property {string} name
     * @property {Object<string, string>} arguments
     */
    /**
     * There's route matched event handler in case creation card
     * So we need to use this method to navTo another page which will not call the event handler
     * @param {RouteInfo=} to
     */
    CaseCreationCard.prototype._navToNextWithoutEvent = function(to) {
        this._removeRouterMatchedListener();
        to ? this._oRouter.navTo(to.name, to.arguments) : this._oRouter.navTo(this._toRoute.name, this._toRoute.arguments);
    };
    /** ************************************************************************************** */
    /*                               Router functions end                                     */
    /** ************************************************************************************** */

    CaseCreationCard.prototype.isUseStep0 = function() {

        if (this.getCaseCreationMode() !== Constants.CASE_CREATION_CASE_MODE.NORMAL) {
            return false;
        }
        const userName = SharedModels.getUser()?.userName;
        return userName.substring(userName.length - 2, userName.length) < 50;
    };

    CaseCreationCard.prototype.formatFileAnalysisReportFragmentDisplay = function(currentStepName, alertListLength) {
        return currentStepName === "CaseCreationAttachmentStep" && alertListLength > 0;
    };

    CaseCreationCard.prototype.isShowTrendingTag = function(tag) {
        return JSON.stringify(tag).indexOf("Trending") !== -1;
    };

    CaseCreationCard.prototype.isShowHotTag = function(tag) {
        return JSON.stringify(tag).indexOf("Hot") !== -1;
    };

    /** ************************************************************************************** */
    /*                               API Call Collections                                      */
    /** ************************************************************************************** */

    CaseCreationCard.prototype.getAllProductList = function(systemNbr) {
        return jQuery.ajax(`/backend/raw/support/CaseCreateProductAndProductFunctionW7?$filter=SystemNumber eq '${systemNbr}' and UseCaseID eq 'S4MSupportCreate'`, {
            method: "GET",
            contentType: "application/json",
            cache: true
        });
    };

    CaseCreationCard.prototype.getPredictedProduct = function(systemNbr) {
        return jQuery.ajax("/backend/raw/support/CaseCreateProductPrediction", {
            method: "GET",
            contentType: "application/json",
            data: {
                $filter: `SystemNumber eq '${systemNbr}'`,
                shortDescription: this.fragmentControllers.BasicInformationStep.data.shortDesc || this.fragmentControllers.Step0.data.shortDesc,
                installationNbr: this.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr,
                customerNumber: this.selectedCutAndSuserInfo.customerNum
            },
            cache: true
        });
    };

    return CaseCreationCard;
}, /* bExport= */true);

/* eslint-disable linebreak-style */
sap.ui.define([
    "../library",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/me/support/model/formatter",
    "sap/me/support/utils/Constants",
    "sap/me/support/utils/helper",
    "sap/me/support/fragments/CaseContactEditController"
], function(
    library,
    CardComposite,
    deepEqual,
    formatter,
    Constants,
    helper,
    CaseContactEditController,
) {
    "use strict";

    let ContactsSectionCard = CardComposite.extend("sap.me.support.cards.ContactsSectionCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: false, group: "Designtime"},
                growingThreshold: {type: "int", defaultValue: 8, group: "Designtime"},
                showRowCount: {type: "boolean", defaultValue: true, group: "Designtime"}
            }
        },
        formatter: formatter,
        _CONSTANTS: Constants
    });

    ContactsSectionCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
    };

    ContactsSectionCard.prototype._setCompositeAggregation = function() {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
    };

    ContactsSectionCard.prototype.setContext = async function(oContext) {
        let oOldContext = this.getContext(), oCard = this.oCard;
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        // oCard.authorizationCheck(oContext.authorization, ["READM"], ["READM_INST"], ["ANLEG"], ["GOSAP"]);
        oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);
        oCard.getTable().bindProperty("visible", "{= ${$this>/intrinsicWidth} > ${$this.sizes>/M} }");

        await helper.currentUserPermission(this._oContext.attributes.caseKey, this);

        this._oCaseContactEditController = new CaseContactEditController(this);
        return this;
    };

    /** ************************************************************************************** */
    /*                                         Event Handlers                                 */
    /** ************************************************************************************** */

    ContactsSectionCard.prototype.onContactAddBtnPressed = function() {
        this._oCaseContactEditController.onContactAddBtnPressed();
    };

    ContactsSectionCard.prototype.onContactDeleteBtnPressed = function(oEvent) {
        this._oCaseContactEditController.onContactDeleteBtnPressed(oEvent);
    };

    ContactsSectionCard.prototype.onDefaultContactSelected = function(oEvent) {
        this._oCaseContactEditController.onDefaultContactSelected(oEvent);
    };

    ContactsSectionCard.prototype.onContactListValueHelpPressed = function(oEvent) {
        this._oCaseContactEditController.onContactListValueHelpPressed(oEvent);
    };

    ContactsSectionCard.prototype.onProfileEditBtnPressed = function() {
        this._oCaseContactEditController.onProfileEditBtnPressed();
    };

    ContactsSectionCard.prototype.onProfileDialogSubmitted = function() {
        this._oCaseContactEditController.onProfileDialogSubmitted();
    };

    ContactsSectionCard.prototype.onProfileDialogClosed = function() {
        this._oCaseContactEditController.onProfileDialogClosed();
    };

    ContactsSectionCard.prototype.onProfileTimeFormatChanged = function(oEvent) {
        this._oCaseContactEditController.onProfileTimeFormatChanged(oEvent);
    };

    ContactsSectionCard.prototype.onEditBU = function(oEvent) {
        this._oCaseContactEditController.onEditBU(oEvent);
    };

    ContactsSectionCard.prototype.onBUSubmit = function(oEvent) {
        this._oCaseContactEditController.onBUSubmit(oEvent);
    };

    ContactsSectionCard.prototype.onBUCancel = function(oEvent) {
        this._oCaseContactEditController.onBUCancel(oEvent);
    };

    /** ************************************************************************************** */
    /*                                          format method                                 */
    /** ************************************************************************************** */
    ContactsSectionCard.prototype.formatIsDisplayAddContactBtn = function(sCanWrite, sCaseStatus) {
        return CaseContactEditController.prototype.formatIsDisplayAddContactBtn(sCanWrite, sCaseStatus);
    };

    ContactsSectionCard.prototype.formatIsDisplayValueHelperIcon = function(sRole, sCanWrite, sCaseStatus) {
        return CaseContactEditController.prototype.formatIsDisplayValueHelperIcon(sRole,sCanWrite, sCaseStatus);
    };

    ContactsSectionCard.prototype.formatIsDisplayDeleteIcon = function(sRole, sContact, sCanWrite, sPriority, sCaseStatus) {
        return CaseContactEditController.prototype.formatIsDisplayDeleteIcon(sRole,sContact,sCanWrite,sPriority, sCaseStatus);
    };

    ContactsSectionCard.prototype.formatIsDisplayDefaultCheckbox = function(sRole, sContact, sCanWrite) {
        return CaseContactEditController.prototype.formatIsDisplayDefaultCheckbox(sRole,sContact,sCanWrite);
    };

    ContactsSectionCard.prototype.formatIsDisplayEditIcon = function(sUserId, sCanWrite, sCaseStatus) {
        return CaseContactEditController.prototype.formatIsDisplayEditIcon(sUserId, sCanWrite, sCaseStatus);
    };

    ContactsSectionCard.prototype.formatIsAddDialogSubmitBtnEnable = function(sContactName,sRole) {
        return CaseContactEditController.prototype.formatIsDisplayEditIcon(sContactName,sRole);
    };

    ContactsSectionCard.prototype.formatIsNoPhoneWarningVisible = function(sPriority,sMobile,sTelephone,sRole,sContact) {
        return CaseContactEditController.prototype.formatIsNoPhoneWarningVisible(sPriority,sMobile,sTelephone,sRole,sContact);
    };

    ContactsSectionCard.prototype.formatIsDisplayBUEditIcon = function(sRole, bCanWrite, sCaseStatus) {
        return CaseContactEditController.prototype.formatIsDisplayBUEditIcon(sRole, bCanWrite, sCaseStatus);
    };

    ContactsSectionCard.prototype.formatRoleToolTip = function(sRole) {
        return CaseContactEditController.prototype.formatRoleToolTip(sRole);
    };

    ContactsSectionCard.prototype.formatTimezoneDescription = function(timezoneKey, timezoneList) {
        return CaseContactEditController.prototype.formatTimezoneDescription(timezoneKey, timezoneList);
    };

    return ContactsSectionCard;
}, /* bExport= */true);

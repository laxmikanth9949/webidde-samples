sap.ui.define([
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/me/support/model/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel"
], function(CardComposite, deepEqual, formatter, JSONModel, ResourceModel) {
    "use strict";

    const SupportNewsCard = CardComposite.extend("sap.me.support.cards.SupportNewsCard", {
        metadata: {
            properties: {
                growing: {type: "boolean", defaultValue: true, group: "Designtime"}
            }
        },
        formatter: formatter
    });

    SupportNewsCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
    };

    SupportNewsCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.getTable().setGrowingThreshold(3);
    };

    SupportNewsCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        CardComposite.prototype.setContext.call(this, oContext, false);

        let that = this;
        // get category:https://news.sap.com/wp-json/wp/v2/categories?page=2&key=239847rifj__
        // req param:https://developer.wordpress.org/rest-api/
        $.ajax("https://news.sap.com/wp-json/wp/v2/posts", {
            method: "GET",
            contentType: "application/json",
            data: {
                categories : ["5602440"],
                _fields : ["date","title","link","excerpt"],
                per_page : 30
            }
        }).done(function(data) {
            let list = [];
            for (let i = 0; i < data.length; i++) {
                let item = data[i];
                list[i] = {
                    title:item.title.rendered,
                    excerpt:item.excerpt.rendered,
                    link:item.link,
                    date:item.date
                };
            }
            that.getCard().setModel(new JSONModel({data:list}),"SupportNews");
        });
        return this;
    };

    SupportNewsCard.prototype._onPressNewsLink = function(oEvent) {
        oEvent.getSource().addStyleClass("sapMeSupportNews-newsLink-click");
    };

    return SupportNewsCard;
}, true);

sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/core/Fragment",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/me/support/model/formatter",
    "sap/me/shared/Models",
    "../utils/Constants",
    "sap/ui/model/resource/ResourceModel",
    "../utils/helper",
    "sap/ui/core/routing/Router",
    "sap/m/MessageToast",
    "sap/me/support/fragments/CreateNewServiceRequestDialog",
    "sap/me/support/utils/InfoExchange"
], function(
    library,
    jQuery,
    CardComposite,
    deepEqual,
    Fragment,
    ODataModel,
    JSONModel,
    Filter,
    FilterOperator,
    MessageBox,
    formatter,
    SharedModels,
    Constants,
    ResourceModel,
    helper,
    Router,
    MessageToast,
    CreateNewServiceRequestDialog,
    InfoExchange,
) {
    "use strict";


    let ServicesRequestsOverviewCard = CardComposite.extend("sap.me.support.cards.ServicesRequestsOverviewCard", {
        metadata: {library: "sap.me.support"},

        _oBindingContext: null,
        formatter: formatter,
        _CONSTANTS: Constants,
    });

    ServicesRequestsOverviewCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this._oRouter = Router.getRouter("shellRouter");
    };

    ServicesRequestsOverviewCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
    };

    ServicesRequestsOverviewCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        this.oCard.setModel(this._oODataModel = SharedModels.getODataModel("support"), "$" + this.alias + ".odata");

        this._serviceRequestCreate = false;
        if (oContext.authorization.exists("SRV_CREA") || oContext.authorization.exists("SRV_REQ") || oContext.authorization.exists("SRV_BIL_AD")) {
            this._serviceRequestCreate = true;
        }
        this.setModel(new JSONModel({enabled: this._serviceRequestCreate}), "isCanCreate");
        helper.getServiceRequestReleased(this);
        this._createSrDialog = new CreateNewServiceRequestDialog(this);

        this.getCard().getHeader()._getTitle().attachBrowserEvent("click", this.onHeaderPressed.bind(this));

        this.getCard().getHeader().getMenuItems()[2].setVisible(false);
        this.getCard().getHeader()._getTitle().addStyleClass("sapMeServicesRequestsOverviewCardName");

        return this;
    };


    /** ************************************************************************************** */
    /*                                      Event Handlers                                    */
    /** ************************************************************************************** */

    ServicesRequestsOverviewCard.prototype.onStatusPressed = function(oEvent) {
        InfoExchange.cacheStatusText("cacheStatusText", oEvent.getSource().getTitle());
        this.onHeaderPressed();
    };

    ServicesRequestsOverviewCard.prototype._openCreateServiceRequestDialog = function() {
        this._createSrDialog.open();
    };

    ServicesRequestsOverviewCard.prototype.onHeaderPressed = function() {
        this._oRouter.navTo("dashboard", {
            nameOrId: "servicessupport",
            section: "servicerequests"
        });
    };

    ServicesRequestsOverviewCard.prototype.isCanClickStatusItem = function(count) {
        let flag = "Inactive";
        if (count !== "0") {
            flag = "Active";
        }
        return flag;
    };

    return ServicesRequestsOverviewCard;
}, /* bExport= */true);

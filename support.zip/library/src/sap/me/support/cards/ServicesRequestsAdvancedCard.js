/* eslint-disable no-undef */
/**
 * @class
 * @name sap.me.support.cards.ServicesRequestsAdvancedCard
 */
sap.ui.define([
    "../library",
    "sap/base/util/deepEqual",
    "sap/m/MessageToast",
    "sap/me/cards/CardComposite",
    "sap/me/support/utils/helper",
    "sap/me/shared/Models",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/Sorter",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "sap/me/cards/library",
    "sap/me/shared/util/getShellComponent",
    "sap/ui/core/routing/Router",
    "sap/m/FormattedText",
    "sap/m/FlexBox",
    "sap/m/Image",
    "sap/m/Title",
    "sap/m/ToolbarSpacer",
    "sap/m/Button",
    "../utils/Constants",
    "sap/me/support/model/formatter",
    "../fragments/CreateNewServiceRequestDialog",
    "sap/me/support/utils/InfoExchange",
    "../fragments/ClosedServiceRequestDialog",
    "sap/m/IllustratedMessage",
    "sap/m/IllustratedMessageType",
    "sap/m/library"
], function(library, deepEqual, MessageToast, CardComposite, helper, SharedModels, Filter, FilterOperator, Sorter, ResourceModel, JSONModel, Fragment, libraryForCardState, getShellComponent, Router, FormattedText, FlexBox, Image, Title, ToolbarSpacer, Button, Constants, formatter, CreateNewServiceRequestDialog, InfoExchange, ClosedServiceRequestDialog, IllustratedMessage, IllustratedMessageType, sapLibrary) {
    "use strict";

    let mServicesrequests = {};

    let ServicesRequestsAdvancedCard = CardComposite.extend("sap.me.support.cards.ServicesRequestsAdvancedCard", {
        library: "sap.me.support",
        formatter: formatter,
        _CONSTANTS: Constants,
    });

    ServicesRequestsAdvancedCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this._oModelServicesRequests = new JSONModel({
            CustomerContractType: null,
            ServicesRequestsClassicCardVisible: true,
            ServicesRequestsAdvancedCardVisible: true
        });
        this._oStatusFilter = this.byId("serviceRequestByStatusFilterSelect");
    };

    ServicesRequestsAdvancedCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
    };

    ServicesRequestsAdvancedCard.prototype._onOpenPasswordSharing = function(oEvent) {
        let oButton = oEvent.getSource(),
            oDataContext = oButton.getBindingContext("$this.odata");

        if (!this.passwordSharing) {
            this.passwordSharingPromise = Fragment.load({
                id: this._sPasswordSharingPopoverDialogId = (this.getId() + "-sPasswordSharingPopoverDialogId"),
                name: "sap.me.support.fragments.PasswordSharingPopoverDialog",
                controller: this
            }).then(function(oFrg) {
                this.oCard.addDependent(oFrg);
                this.passwordSharing = oFrg;
                this.passwordSharing.setModel(this._oModelServicesRequests, "$" + this.alias + ".raw");
                return oFrg;
            }.bind(this));
        }
        this.passwordSharingPromise.then(() => {
            // this.passwordSharing.bindElement("$this.odata>" + oDataContext.getPath());
            this._oModelServicesRequests.setData({
                ...this._oModelServicesRequests.getData(),
                SelectedService: oDataContext.getObject()
            });
            this.passwordSharing.openBy(oButton);
            this._retriveStoredPasswords(oDataContext.getObject());
        });
    };

    ServicesRequestsAdvancedCard.prototype._onPressClosePasswordsSharingDialog = function() {
        this.passwordSharing.close();
    };

    ServicesRequestsAdvancedCard.prototype.setPasswordsSharingModel = function(aPasswords) {
        this._oModelServicesRequests.setData({
            ...this._oModelServicesRequests.getData(),
            PasswordsSharing: aPasswords
        });
        this.setModel(this._oModelServicesRequests, "$this.raw");
        this._oModelServicesRequests.updateBindings();
    };

    ServicesRequestsAdvancedCard.prototype.onPressButtonShowPasswordsSharing = function(oEvent) {
        let oInputHBox = oEvent.getSource().getParent().getItems();
        oInputHBox.forEach(item => {
            if (item.getMetadata().getName() === "sap.m.Input") {
                if (item.getType() === "Text") {
                    oEvent.getSource().setIcon("sap-icon://show");
                    item.setType(sap.m.InputType.Password);
                } else {
                    oEvent.getSource().setIcon("sap-icon://hide");
                    item.setType(sap.m.InputType.Text);
                }
            }
        });
    };

    ServicesRequestsAdvancedCard.prototype.onPressButtonCopyPassword = function(oEvent) {
        let oButton = oEvent.getSource(),
            oInputHBox = oButton.getParent().getItems(),
            sPasswordCopy = null;
        oInputHBox.forEach(item => {
            if (item.getMetadata().getName() === "sap.m.Input") {
                sPasswordCopy = item.getValue();
                this.copyTextToClipboard(sPasswordCopy);
                this.passwordSharing.focus();
            }
        });
    };

    ServicesRequestsAdvancedCard.prototype.copyTextToClipboard = function(text) {
        let input = document.createElement("textarea");
        input.innerHTML = text;
        document.body.appendChild(input);
        input.select();
        document.execCommand("copy");
        document.body.removeChild(input);
        MessageToast.show(this._i18n.getText("servicesRequests_PasswordCopied"));
    };

    ServicesRequestsAdvancedCard.prototype._retriveStoredPasswords = function(oServiceRequest) {
        let sRequestParam = "?SystemNumber=" + oServiceRequest.systemNumber + "&Users=" + oServiceRequest.userPasswordList, sPasswordsSharing = "PasswordsSharing";
        mServicesrequests[sPasswordsSharing] = jQuery.get(this._CONSTANTS.HEC_CUSTOMER_STORED_PASSWORD + sRequestParam);
        mServicesrequests[sPasswordsSharing].then(sPasswordsSharing => {
            this.setPasswordsSharingModel(sPasswordsSharing);
        });
    };

    ServicesRequestsAdvancedCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext(),
            oCard = this.oCard;
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        // set filter JSONModel
        this._allFilters = new Map();
        // uncomment below line for e2e testing
        // oCard.setModel(this._oODataModel = this._createODataModel(), "$" + this.alias + ".odata");

        // set filter header
        this._setAllFilterHeader();

        // oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);
        // set Required Authorization text
        oCard._sRequiredAuthorizationsText = this._i18n.getText("servicesRequests_AuthorizationsText");
        oCard.getTable().bindProperty("visible" ,"{= ${$this>/intrinsicWidth} > ${$this.sizes>/M} }");
        this._serviceRequestDisply = false;
        this._serviceRequestCreate = false;
        if (oContext.authorization.exists("SRV_CREA") || oContext.authorization.exists("SRV_REQ") || oContext.authorization.exists("SRV_BIL_AD")) {
            this._serviceRequestDisply = true;
            this._serviceRequestCreate = true;
        }
        oCard.setModel(this._oODataModel = SharedModels.getODataModel("support"), "$" + this.alias + ".odata");

        this._setServicesRequestsAdvancedBindingAggregation();
        // create button enabled
        this.setModel(this._createServiceRequestModel = new JSONModel({enabled: this._serviceRequestCreate}), "isCanCreate");
        // default header filter enabled
        this.setModel(this._displayServiceRequestModel = new JSONModel({enabled: this._serviceRequestDisply}), "isCanFilter");
        this.oCard.attachUpdateStarted((oEvent) => {
            this.oCard.getCardContent()?.setBusy(true);
        });
        this._noDataDisply(this._serviceRequestDisply);
        helper.getServiceRequestReleased(this);
        this._createSrDialog = new CreateNewServiceRequestDialog(this);
        this._closedSrDialog = new ClosedServiceRequestDialog(this);
        InfoExchange.cacheServiceRequestStatusFilter("serviceRequestStatusFilter", this._oStatusFilter);

        return this;
    };

    ServicesRequestsAdvancedCard.prototype.onFilterServiceRequest = function(oEvent) {
        const sQuery = oEvent.getParameter("query");
        let cacheFilter;
        if (sQuery) {
            const properties = ["id", "area", "entity", "title", "chargeableService", "topic", "createdOnISO", "createdBy", "startsAtISO", "status", "requestFor"];
            cacheFilter = new Filter({
                filters: properties.map(columnProperty => {
                    return new Filter({path: columnProperty, operator: FilterOperator.Contains, value1: sQuery , caseSensitive: false});
                }),
                and: false
            });
        }
        this._setUpCommonFilter("searchField", cacheFilter);
    };

    ServicesRequestsAdvancedCard.prototype.onAreaChange = function(oEvent) {
        let cacheFilter;
        /**
         * area filter
         */
        let areaList = oEvent.getSource().getSelectedKeys();
        if (areaList.length > 0) {
            this._selectAreaHeaderBut.setText(this._i18n.getText("filterClear"));
            let areaListFilters = areaList.map(areaValue => new Filter({
                path: "area",
                operator: "EQ",
                value1: areaValue
            }));
            cacheFilter = new Filter({filters: areaListFilters, and: false});
        } else {
            this._selectAreaHeaderBut.setText(this._i18n.getText("filterSelectAll"));
        }
        this._setUpCommonFilter("area", cacheFilter);
    };

    ServicesRequestsAdvancedCard.prototype.onStatusChange = function(oEvent) {
        let cacheFilter;
        /**
         * status filter
         */
        let statusList = oEvent.getSource().getSelectedKeys();
        if (statusList.length > 0) {
            this._selectStatusHeaderBut.setText(this._i18n.getText("filterClear"));
            let statusListFilters = statusList.map(statusValue => new Filter({
                path: "status",
                operator: "EQ",
                value1: statusValue
            }));
            cacheFilter = new Filter({filters: statusListFilters, and: false});
        } else {
            this._selectStatusHeaderBut.setText(this._i18n.getText("filterSelectAll"));
        }
        this._setUpCommonFilter("status", cacheFilter);
    };

    ServicesRequestsAdvancedCard.prototype._setHeaderSelector = function(oId,filterText) {
        let oSource = this.byId(oId);
        let oPicker = oSource.createPicker("popover").addStyleClass("sapMeServiceRequestPopover");
        const button = new Button({
            type: "Transparent",
            text: this._i18n.getText("filterSelectAll"),
            press: (oEvent) => {
                if (oEvent.getSource().getText() === this._i18n.getText("filterClear")) {
                    oSource.setSelectedKeys([]);
                    button.setText(this._i18n.getText("filterSelectAll"));
                } else if (oEvent.getSource().getText() === this._i18n.getText("filterSelectAll")) {
                    let aAllKeys = oSource.getItems().map((oItem) => oItem.getKey());
                    oSource.setSelectedKeys(aAllKeys);
                    button.setText(this._i18n.getText("filterClear"));
                }
                oSource.fireSelectionChange();
            }
        });
        switch (filterText) {
            case "filterByArea":
                this._selectAreaHeaderBut = button;
                break;
            case "filterByStatus":
                this._selectStatusHeaderBut = button;
                break;
        }

        let aPreparedToolbarControls = [
            new Title({
                text: this._i18n.getText(filterText)
            }),
            new ToolbarSpacer(),
            button
        ];
        let oToolbar = oPicker.getContent()[0].getHeaderToolbar();
        if (oToolbar) {
            oToolbar.getContent()[0].setVisible(false); // Hide default Select All checkbox
            oToolbar.addContent(aPreparedToolbarControls[0].addStyleClass("sapUiSmallMarginBegin"));
            oToolbar.addContent(aPreparedToolbarControls[1]);
            oToolbar.addContent(aPreparedToolbarControls[2].addStyleClass("sapUiTinyMarginEnd"));
        }
    };

    ServicesRequestsAdvancedCard.prototype._setAllFilterHeader = function() {
        this._setHeaderSelector("serviceRequestByAreaFilterSelect","filterByArea");
        this._setHeaderSelector("serviceRequestByStatusFilterSelect","filterByStatus");
    };

    ServicesRequestsAdvancedCard.prototype._noDataDisply = function(displyAuthFlag) {
        this.oCard.attachEvent("updateFinished", function(oEvent) {
            this.oCard.getCardContent()?.setBusy(false);
            let advanceCard = oEvent.getSource();
            const catchErrorMessage = oEvent.getSource()?.getBinding("items")?.aContexts[0]?.sPath ?? "";
            const isInSearchFilterResult = this.isInSearchFilter();
            if (catchErrorMessage.indexOf("srErrorMessage") !== -1) {
                this._setUpNoItemView(this.oCard, this._i18n.getText("noData_errorTitle"), this._i18n.getText("noData_errorSubTitle"), "error");
                //when service request return error then remove row count
                this.oCard.setTitle(this.oCard.getTitle().split("(")[0]);
                return;
            }
            if (displyAuthFlag) {
                // no data
                if (advanceCard.getItems().length === 0) {
                    if (isInSearchFilterResult) {
                        this._setUpNoItemView(advanceCard, this._i18n.getText("noData_noSearchDataTitle"), this._i18n.getText("noData_noSearchDataSubTitle"), "search");
                    } else {
                        this._setUpNoItemView(advanceCard, this._i18n.getText("noData_noSrDataTitle"), this._i18n.getText("noData_noSrDataSubTitle"), "nodata");
                    }
                } else {
                    this.oCard.setState(libraryForCardState.CardState.Content);
                }
            } else {
                // no permission
                this._setUpNoItemView(advanceCard, this._i18n.getText("noPermission_noDataTitle"), this._i18n.getText("noPermission_noDataSubTitle"), "nopermission");
            }
        }.bind(this));

    };

    ServicesRequestsAdvancedCard.prototype._setUpNoItemView = function(oTableCard, sNoDataTitle, sNoDataSubTitle, mesgType) {
        oTableCard.setState(libraryForCardState.CardState.NoData);
        this._getNoDataContent(oTableCard, sNoDataTitle, sNoDataSubTitle, mesgType);
    };

    ServicesRequestsAdvancedCard.prototype._getNoDataContent = function(oTableCard, sNoDataTitle, sNoDataSubTitle, mesgType) {
        let aItems = [];
        const mesg = new IllustratedMessage({
            illustrationSize: sapLibrary.IllustratedMessageSize["Spot"],
            illustrationType: this._getillustrationType(mesgType),
            enableVerticalResponsiveness: false
        });
        mesg.setTitle(sNoDataTitle);
        mesg.setDescription(sNoDataSubTitle);
        if (mesgType === "error") {
            mesg.addAdditionalContent(new Button({
                type: "Transparent",
                text: this._i18n.getText("noData_noSrDataReload"),
                press: () => {
                    // reload
                    this._oODataModel.refresh();
                }
            }));
        }
        aItems.push(mesg);

        oTableCard.setAggregation("_noDataContent", new FlexBox({
            height: "100%",
            width: "100%",
            direction: sap.m.FlexDirection.Column,
            alignContent: sap.m.FlexAlignContent.Center,
            alignItems: sap.m.FlexAlignItems.Center,
            justifyContent: sap.m.FlexJustifyContent.Center,
            items: aItems
        }).addStyleClass("sapMeCardStateNoData sapMeNoDataContent"));

    };

    ServicesRequestsAdvancedCard.prototype._getillustrationType = function(mesgType) {
        let illustrationType = sapLibrary.IllustratedMessageType.NoFilterResults;
        if (mesgType === "search") {
            illustrationType = sapLibrary.IllustratedMessageType.SearchFolder;
        } else if (mesgType === "nodata") {
            illustrationType = sapLibrary.IllustratedMessageType.SimpleEmptyList;
        } else if (mesgType === "error") {
            illustrationType = sapLibrary.IllustratedMessageType.SimpleError;
        }
        return illustrationType;
    };


    ServicesRequestsAdvancedCard.prototype._getServiceRequestDetails = function(sId, isClassic) {
        if (sId) {
            if (isClassic) {
                return "/servicerequest/overview/requestid/" + sId;
            } else if (helper.isDev === true || helper.isLocal === true) {
                return this._CONSTANTS.HEC_ADVANCED_DEEP_LINK_DEV + sId;
            } else if (helper.isTest === true) {
                return this._CONSTANTS.HEC_ADVANCED_DEEP_LINK_TEST + sId;
            }
            return this._CONSTANTS.HEC_ADVANCED_DEEP_LINK_PROD + sId;

        }
        return new String();
    };

    ServicesRequestsAdvancedCard.prototype._formatClassicStatusTooltip = function(status) {
        const oClassicStatusMap = {
            New: "Service Request Created",
            "In Progress": "Service Request In Process / Service Request (Reopened) / Cancellation Requested",
            "Awaiting Info": "Customer Interaction Required / Service Provided",
            Scheduled: "Service Scheduled",
            "New Service Request": "New Service Request",
            "Service failed": "Service failed",
            "To be Reviewed": "To be Reviewed",
            "Closed Confirmed": "Service Request confirmed",
            "Closed Confirmed Automatically": "Service Request confirmed automatically",
            "Closed Cancelled": "Cancelled"
        };
        return oClassicStatusMap[status];
    };
    ServicesRequestsAdvancedCard.prototype._formatCreatedBy = function(number,name) {
        // Frank Guentner (S0020013345), SAP Agent, S0024147531 => Frank Guentner (S0020013345)
        if (number && name) {
            const isNameInCludingICDNumber = name.match(/[I|C|D][\d]{5,}/gi);
            const isNumberCludingICDNumber = number.match(/[I|C|D][\d]{5,}/gi);
            if (isNameInCludingICDNumber || isNumberCludingICDNumber) {
                return "SAP Agent";
            }

            const isNameInCludingSNumber = name.match(/S[\d]{10}/gi);
            const isNumberInCludingSNumber = number.match(/S[\d]{10}/gi);
            return isNameInCludingSNumber ? name : (!isNumberInCludingSNumber ? name : name + "(" + number + ")");
        }
        return name;
    };

    ServicesRequestsAdvancedCard.prototype._formatRequestFor = function(requestFor, createByNumber, createByName) {
        const finalCreateBy = this._formatCreatedBy(createByNumber, createByName);

        if (requestFor) {
            const isCludingICDNumber = requestFor.match(/[I|C|D][\d]{5,}/gi);
            requestFor = isCludingICDNumber ? "SAP Agent" : requestFor;
        } else {
            requestFor = finalCreateBy;
        }
        return requestFor;
    };

    ServicesRequestsAdvancedCard.prototype._formatChargeableState = function(sText) {
        switch (sText) {
            case "CHARGEABLE":
                return "Error";
            case "FREE":
                return "Success";
            default:
                return "Success";
        }
    };
    ServicesRequestsAdvancedCard.prototype._formatChargeableText = function(sText) {
        switch (sText) {
            case "FREE":
                return "NO";
            case "CHARGEABLE":
                return "YES";
            default:
                return "NO";
        }
    };

    ServicesRequestsAdvancedCard.prototype._onChoseServiceRequestType = function(oEvent) {
        let v = oEvent.getSource().getSelectedKey();
        let cacheFilter;
        if (v === "MyServicesRequests") {
            const userNumber = this._oContext.user.simulatedUser ? this._oContext.user.simulatedUser : this._oContext.user.userName;
            const createByFilter = new Filter({
                path: "createdBy",
                operator: FilterOperator.EQ,
                value1: userNumber
            });
            const requestForFilter = new Filter({
                path: "requestForNumber",
                operator: FilterOperator.EQ,
                value1: userNumber
            });
            cacheFilter = new Filter({filters: [createByFilter, requestForFilter], or: true});
        }
        this._setUpCommonFilter("createdBy", cacheFilter);
    };

    ServicesRequestsAdvancedCard.prototype.isInSearchFilter = function() {
        const newArea = this.byId("serviceRequestByAreaFilterSelect").getSelectedKeys();
        const newStatus = this.byId("serviceRequestByStatusFilterSelect").getSelectedKeys();
        const newSearchResult = this.byId("searchServiceRequest").getValue();
        const myOpenRequests = this.byId("servicesRequestsTypeButton").getSelectedKey();

        if (newArea.length > 0 || newStatus.length > 0 || newSearchResult || myOpenRequests === "MyServicesRequests") {
            return true;
        }
        return false;

    };

    ServicesRequestsAdvancedCard.prototype._setUpCommonFilter = function(filterFlag,filterModel) {
        let aFilter = [];
        this._allFilters.set(filterFlag,filterModel);
        this._allFilters.forEach(function(value) {
            if (value) {
                aFilter.push(value);
            }
        });
        this.oCard.getCardContent()?.setBusy(true);
        this.oCard.setCustomFilters(aFilter);
    };

    ServicesRequestsAdvancedCard.prototype._setServicesRequestsAdvancedBindingAggregation = function() {
        let oBindingInfo = this.oCard.getBindingInfo("items");
        oBindingInfo.parameters = {
            $count: true
        };
        oBindingInfo.sorter = [new Sorter({
            path: "createdOnISO",
            descending: true
        })];
    };

    ServicesRequestsAdvancedCard.prototype._openCreateServiceRequestDialog = function() {
        this._createSrDialog.open();
    };

    ServicesRequestsAdvancedCard.prototype._openClosedServiceRequestDialog = function() {
        this._closedSrDialog.open();
    };



    return ServicesRequestsAdvancedCard;
}, /* bExport= */true);

sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/dom/includeStylesheet",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/me/support/utils/icsConverter",
    "sap/ui/core/Fragment",
    "sap/me/support/utils/DateTimeUtil",
    "../utils/TextEditor",
    "../utils/UpdateFailedDialog",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/me/support/utils/SAEHelper",
    "sap/ui/core/format/DateFormat",
    "sap/me/support/model/formatter",
    "sap/ui/unified/DateRange",
    "sap/ui/core/date/UI5Date",
    "sap/base/util/deepClone"
], function(library, jQuery, CardComposite, deepEqual, JSONModel, ResourceModel, ODataModel, includeStylesheet, Filter, FilterOperator, icsConverter, Fragment, DateTimeUtil, TextEditor, UpdateFailedDialog, MessageToast, MessageBox, SAEHelper, DateFormat, Formatter, DateRange, UI5Date, deepClone) {
    "use strict";

    let CaseScheduleAnExpertCard = CardComposite.extend("sap.me.support.cards.CaseScheduleAnExpertCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: false, group: "Designtime"}
            }
        },
        _oSelectedTimeSlot: null,
        _oSelectedSlot: {selectedDate: "",
            selectedTime: ""}
    });

    CaseScheduleAnExpertCard.prototype.SAEHelper = SAEHelper;

    CaseScheduleAnExpertCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        oCard.setModel(this._oModel = new JSONModel({
        }), "$" + this.alias + ".odata");
        oCard.setModel(this._oModel1 = new JSONModel({
        }), "$" + this.alias + ".oBookSAEdata");
        oCard.setModel(this._oModel2 = new JSONModel({
        }), "$" + this.alias + ".oBookSAEdata2");
        oCard.setModel(this._oModel3 = new JSONModel({
        }), "$" + this.alias + ".pastAppointments");
        oCard.setModel(this._oModel4 = new JSONModel({
        }), "$" + this.alias + ".SAEavailableData");
        //        oCard.setModel(this._oModel5 = new JSONModel({
        //        }), "$" + this.alias + ".userTimezone");
        oCard.setModel(this._oSlotToSave = new JSONModel({
        }), "$" + this.alias + ".oSlotToSave");

        const timePeriodOptionsSample = deepClone(SAEHelper.getTimePeriodOptions());

        oCard.setModel(this._oappointmentInformationSAEModel = new JSONModel({
            isAppointmentInformationVisible: false,
            isNoAppointmentButtonVisible: false,
            dayList: [],
            timePeriodOptions: timePeriodOptionsSample,
            selectedTimeList: [],
            selectedTimeItem: {},
            totalCount: 0,
            timezone: "",
            localTimezone: "",
            selectedDay: -1,
            selectedTimeIndex: 0,
            weekDayFormat: "EE",
            monthFormat: "MMM",
            dateFormat: "d",
        }), "$this.appointmentInformationSAE");

        oCard.setModel(this._disabledDatesModel = new JSONModel({
            disabled: [
                {
                    // disable all past dates
                    end: new Date()
                },{
                    // disable the dates after 10 valid dates
                    start: this.getOffsetDate(14),
                    end: this.getOffsetDate(365)
                }
            ]
        }), "$this.disabledDates");
    };

    CaseScheduleAnExpertCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        this._oEventBus = sap.ui.getCore().getEventBus();
        this._fragment = sap.ui.core.Fragment;
        //        this._sResourceUri = sap.ui.require.toUrl("sap/me/support");
        //        includeStylesheet(this._sResourceUri + "/css/SAE-SAM.css", {
        //            id: "CalendarGrid"
        //        });
        this.oCard.setModel(new JSONModel({
            "sap.me.support": this._sResourceUri = sap.ui.require.toUrl("sap/me/support")
        }), "binding"); // model for binding paths

    };

    CaseScheduleAnExpertCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext(), oCard = this.getCard();
        // var cardVisible = false;

        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        this._pointer = `${oContext.attributes.caseKey}`;
        // this._pointer = "002075126000001616642023";
        // oCard.authorizationCheck(oContext.authorization, ["READM"], ["READM_INST"], ["ANLEG"], ["GOSAP"]);
        oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);

        const oModel2 = new ODataModel({
            serviceUrl: "/backend/odata/support/",
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        });

        this.getCard().setModel(this._oODataModel2 = oModel2, "$" + this.alias + ".userTimezone");

        this._updatefaildialog = new UpdateFailedDialog(this.getCard());

        this._oEventBus.subscribe("sap.me.support.cards.CaseScheduleAnExpertCard", "appointmentChange", () => {
            this.byId("SaeVBox").setBusy(true);
            this._oODataModel.refresh();
            this.noDataInSectionReset();
            this.setListContexts();
        });

        this.getUserTimeZone();
        this.getAvailableSessions();

        return this;
    };

    CaseScheduleAnExpertCard.prototype.getOffsetDate = function(dateOffset = 0) {
        const date = new Date();
        date.setDate(date.getDate() + dateOffset);
        return date;
    };

    CaseScheduleAnExpertCard.prototype.getUserTimeZone = function() {
        this.oTimeZoneDataHolder = this.byId("timeZoneDataHolder");
        let oHolderBinding = this.oTimeZoneDataHolder.getBinding("items");
        oHolderBinding.attachDataReceived((oEvent) => {
            const oHolderContexts = oEvent.getSource().getCurrentContexts();
            if (oHolderContexts.length > 0 && typeof (oHolderContexts[0]) !== "undefined") {
                this._userTimezone = Formatter.formatTimezoneList(oHolderContexts[0].getProperty("timeZoneDescription"), oHolderContexts[0].getProperty("timeZoneUTCsign"), oHolderContexts[0].getProperty("timeZoneUTCdiff"));
                this._timeZoneUTCdiffHrs = parseInt(oHolderContexts[0].getProperty("timeZoneUTCdiff").substring(2, 4));
                this._timeZoneUTCdiffMins = parseInt(oHolderContexts[0].getProperty("timeZoneUTCdiff").substring(5, 7));
                this._timeZoneUTCdiffSecs = parseInt(oHolderContexts[0].getProperty("timeZoneUTCdiff").substring(8, 10));
                this._timeZoneUTCsign = oHolderContexts[0].getProperty("timeZoneUTCsign");
            }
            this.setListContexts();
        });
    };

    CaseScheduleAnExpertCard.prototype.addWeekendDisabledDays = function(disabledDates) {
        // calculate for future 14 days and add to disabledDates
        for (let i = 0; i <= 14; i++) {
            let date = new Date();
            date.setDate(date.getDate() + i);
            if (date.getDay() % 6 === 0) {
                disabledDates.push({start: date});
            }
        }
        return disabledDates;
    };

    CaseScheduleAnExpertCard.prototype.getAvailableSessions = function() {
        let that = this;

        this.getChannelRecommenderData().then(data => {
            let saeData = data.find(o => o.ChannelID === "SAE");
            that.checkReceivedData(saeData);
            const serviceTimezone = JSON.parse(saeData.ChannelData).slots?.TimezoneUTC ?? "UTC";
            const {result, isTotalAvailable} = SAEHelper.formatTimeToLocalTimezone(JSON.parse(saeData.ChannelData).slots.DAYS, serviceTimezone);

            // add disabled dates to calendar
            const disabledDates = this._disabledDatesModel.getProperty("/disabled"); // [{end: Date.now()}]
            result.forEach(dayItem => {
                if (!dayItem.isAvailable) {
                    const disabledDay = new Date(dayItem.Date.slice(0, 4), dayItem.Date.slice(4, 6) - 1, dayItem.Date.slice(6, 8));
                    disabledDates.push({start: disabledDay});
                }
            });
            this.addWeekendDisabledDays(disabledDates);
            this._disabledDatesModel.setProperty("/disabled", disabledDates);

            this._oappointmentInformationSAEModel.setProperty("/isTotalAvailable", isTotalAvailable);
            this._oappointmentInformationSAEModel.setProperty("/dayList", result);
            this._oappointmentInformationSAEModel.setProperty("/userProfileTimezone", serviceTimezone);
            this._oappointmentInformationSAEModel.setProperty("/localTimezone", sap.ui.core.Configuration.getTimezone());

            that._oReceivedChannelData = saeData;
            // automatically select the first available day and period session
            this.selectAppointmentDay(result);
        }).catch(oError => {
            console.log("channelRecommender error: " + oError.responseText);
            that.byId("BookSAEButton").setVisible(false);
        });


    };

    CaseScheduleAnExpertCard.prototype.getChannelRecommenderData = function() {
        let pointer = this._pointer;

        return new Promise((resolve, reject) => {
            jQuery.ajax(`/backend/raw/support/ChannelRecommender?$filter=CasePointer eq '${pointer}' and UseCaseID eq 'S4MSupportDisplay'`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                success:(data) => {
                    resolve(data); // /////////////////////remove[4] for live data
                },
                error: (error) => {
                    reject(error);
                },
                complete: () => {

                }
            });
        });
    };

    CaseScheduleAnExpertCard.prototype.checkReceivedData = function(oData) {

        if (oData) {

            let cActive = oData.Status;
            let oDetails, bNoDetails;
            try {
                oDetails = JSON.parse(oData.ChannelData).details;
            } catch {
                bNoDetails = true;
            }

            if (cActive !== "A" || bNoDetails) {
                this.setNoDataTextAndToolTip(this._i18n.getText("Rule1"), "invisible");
            } else {
                this.byId("BookSAEButton").setVisible(true);

                if (oDetails.BOOKED === false) {
                    this.setNoDataTextAndToolTip(this._i18n.getText("Rule3"), "enabled");
                } else {
                    if (oDetails.PRIO !== true) {
                        this.setNoDataTextAndToolTip(this._i18n.getText("Rule4"), "disabled");
                    }
                    if (oDetails.PS !== true) {
                        this.setNoDataTextAndToolTip(this._i18n.getText("Rule2"), "disabled");
                    }
                    if (oDetails.PRIO === true && oDetails.PS === true) {
                        if (oDetails.STATUS !== true) {
                            this.setNoDataTextAndToolTip(this._i18n.getText("Rule2"), "disabled");
                        } else if (oDetails.SLOTS !== true) {
                            this.setNoDataTextAndToolTip(this._i18n.getText("Rule5"), "disabled");
                        } else {
                            this.setNoDataTextAndToolTip(this._i18n.getText("bookAppointmentText"), "enabled");
                        }
                    }

                }
            }
        } else {
            this.setNoDataTextAndToolTip(this._i18n.getText("SAEUnavailable"), "invisible");
        }
    };

    CaseScheduleAnExpertCard.prototype.setListContexts = function() {
        let sQueryParams = "?pointer=" + this._pointer + "&type=SAE";

        let oModel = new ODataModel({
            serviceUrl: `/backend/odata/support/${sQueryParams}`,
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        });

        this.getCard().setModel(this._oODataModel = oModel, "$" + this.alias + ".odata");

        this.oCaseAppointmentsList = this.byId("caseAppointmentsList");

        let oBinding = this.oCaseAppointmentsList.getBinding("items");
        let aFilter = [];
        let sQuery = "sae";

        aFilter.push(new Filter("type", FilterOperator.Contains, sQuery));
        oBinding.filter(aFilter);

        oBinding.attachDataReceived((oEvent) => {
            let bookedDate;
            let currentDate = new Date();
            this.noDataInSectionReset();

            let oContexts = oEvent.getSource().getCurrentContexts();
            if (oContexts[0] !== undefined) {
                for (let i = 0, j = this.oCaseAppointmentsList.getItems().length; i < j; i++) {
                    bookedDate = new Date(oContexts[i].getProperty("startTime"));
                    if (currentDate.getTime() > bookedDate.getTime() || oContexts[i].getProperty("status") === "cancelled") {
                        this.oCaseAppointmentsList.getItems()[i].destroy();
                        j = this.oCaseAppointmentsList.getItems().length;
                        i = 0;
                    }
                }

                if (this.oCaseAppointmentsList.getItems().length === 0) {
                    this.noDataInSection();
                }

                this.oCasePastAppointmentsList = this.byId("casePastAppointmentsList");
                let oBindingPast = this.oCasePastAppointmentsList.getBinding("items");
                oBindingPast.filter(aFilter);
                oBindingPast.attachDataReceived((oEvent) => {
                    const oContextsPast = oEvent.getSource().getCurrentContexts();

                    for (let k = 0, l = this.oCasePastAppointmentsList.getItems().length; k < l; k++) {
                        bookedDate = new Date(oContextsPast[k].getProperty("startTime"));
                        if (this.oCasePastAppointmentsList.getItems()[k].getProperty("status") === "cancelled") {
                            this.oCasePastAppointmentsList.getItems()[k].getContent()[0].getItems()[0].getItems()[0].getItems()[0].addStyleClass("sapMeCaseSessionCancelled");
                        }
                        if (currentDate.getTime() < bookedDate.getTime() || !(this.oCasePastAppointmentsList.getItems()[k].getProperty("status") === "cancelled")) {
                            this.oCasePastAppointmentsList.getItems()[k].destroy();
                            l = this.oCasePastAppointmentsList.getItems().length;
                            k = 0;
                        }
                    }
                }, this);

                this.noDataInSectionReset();
                this.byId("SaeVBox").setBusy(false);
                this.bHasItems = true;

            } else if (!this.bHasItems) {
                this.noDataInSection();
                this.byId("SaeVBox").setBusy(false);
            }
        }, this);

    };

    CaseScheduleAnExpertCard.prototype.getCaseNumber = function(sPointer) {
        let number = sPointer.substr(0, this._pointer.length - 4);
        number = number.slice(number.lastIndexOf(0) + 1, number.length);
        let year = this._pointer.substr(this._pointer.length - 4);
        let caseString = number + "/" + year;
        return caseString;
    };

    CaseScheduleAnExpertCard.prototype.buildDescLink = function() {
        return `${window.location.origin}/case/${this._pointer}/appointments`;
    };

    /** ************************************************************************************** */
    /*                                         Event Handlers                                 */
    /** ************************************************************************************** */

    CaseScheduleAnExpertCard.prototype.downloadPress = function(oEvent) {
        const saeEvent = {};
        saeEvent.title = `Appointment for Case ${this._pointer}`;
        saeEvent.start = this.convertTimezone(oEvent.getSource().getBindingContext("$this.odata").getProperty("startTime")).replace(" ", "T");
        saeEvent.meetingUrl = oEvent.getSource().getBindingContext("$this.odata").getProperty("teamsUrl");
        saeEvent.type = oEvent.getSource().getBindingContext("$this.odata").getProperty("type");
        saeEvent.end = this.convertTimezone(oEvent.getSource().getBindingContext("$this.odata").getProperty("endTime")).replace(" ", "T");
        saeEvent.additionalInfo = oEvent.getSource().getBindingContext("$this.odata").getProperty("additionalInfo");
        saeEvent.description = "SAE Details" + "\n\n" + this.buildDescLink() + "\n\nMeeting link: \n" + saeEvent.meetingUrl + "\n\n Additional Details: " + saeEvent.additionalInfo;

        icsConverter.saveTimelineEventAsCalendarFile(saeEvent);
    };

    /**
     * convert to user local timezone
     * @param {string} sDate UTC time
     */
    CaseScheduleAnExpertCard.prototype.convertTimezone = function(sDate) {
        if (!sDate) {
            return;
        }
        const oDateFormatUTC = DateFormat.getDateTimeWithTimezoneInstance({pattern: "yyyy-MM-dd HH:mm:ss"});
        const timestamp = oDateFormatUTC.parse(sDate, "UTC")?.[0].getTime();
        return oDateFormatUTC.format(new Date(timestamp), Intl.DateTimeFormat().resolvedOptions().timeZone);
    };

    CaseScheduleAnExpertCard.prototype.toggleHistory = function() {
        let list = this.byId("casePastAppointmentsList");
        this.byId("casePastAppointmentsList").setVisible(!list.getVisible());
        // add the dividing line
        if (list.getVisible() && list.getItems().length > 0) {
            this.byId("historyTabBar").addStyleClass("sapFlexboxBottomDivLine");
        } else {
            this.byId("historyTabBar").removeStyleClass("sapFlexboxBottomDivLine");
        }
    };

    CaseScheduleAnExpertCard.prototype.onPressViewEvent = function() {
        if (window.location.hostname.startsWith("test")) {
            sap.m.URLHelper.redirect( "https://test.me.sap.com/calendar", true);
        } else {
            sap.m.URLHelper.redirect( "https://me.sap.com/calendar", true);
        }

    };

    CaseScheduleAnExpertCard.prototype.onPressCancelSession = function(oEvent) {
        this.saeStartDateToCancel = oEvent.getSource().getBindingContext("$this.odata").getProperty("startTime").replace(/-|T|:|\.| /g,"");
        sap.m.MessageBox.warning(this._i18n.getText("CancelSaEAppointmentText"), {
            title: this._i18n.getText("CancelSaEAppointmentTitle"),
            styleClass: "sapUiSizeCompact",
            actions: ["Confirm","Cancel"],
            emphasizedAction: "Confirm",
            initialFocus: null,
            textDirection: sap.ui.core.TextDirection.Inherit,
            onClose: function(sAction) {
                if (sAction === "Confirm") {
                    this.onConfirmDeleteSession();
                }
            }.bind(this)
        });
    };

    CaseScheduleAnExpertCard.prototype.onCancelDeleteSession = function() {
        this._oCancelSessionDialog.close();
    };

    CaseScheduleAnExpertCard.prototype.onConfirmDeleteSession = function() {
        this.byId("SaeVBox").setBusy(true);
        let oChannelData = JSON.parse(this._oReceivedChannelData.ChannelData);
        jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({
                action: "SEND2SAP",
                pointer: this._pointer,
                long_text: "Appointment for Case to be cancelled",
                sae_duration:30,
                sae_start_time: this.saeStartDateToCancel,
                rep_case:"1",
                component:oChannelData.case.component,
                status: "SEND2SAP",
                sae_action:"delete"
            })
        }).done(() => {
            this.byId("SaeVBox").setBusy(true);
            this._oODataModel.refresh();
            this._oEventBus.publish("sap.me.support.cards.CaseScheduleAnExpertCard", "appointmentChange");
            MessageToast.show(`${this._i18n.getText("SAESessionCancelled")}`);
        }).fail(() => {
            this._updatefaildialog.open();
        });
    };

    CaseScheduleAnExpertCard.prototype.noDataInSection = function() {
        this.byId("showHistoryButton").setVisible(false);
        this.byId("noDataMessagePage").setVisible(true);
        this.byId("caseAppointmentsList").setVisible(false);
    };

    CaseScheduleAnExpertCard.prototype.noDataInSectionReset = function() {
        this.byId("showHistoryButton").setVisible(true);
        this.byId("noDataMessagePage").setVisible(false);
        this.byId("caseAppointmentsList").setVisible(true);
    };

    CaseScheduleAnExpertCard.prototype.setNoDataTextAndToolTip = function(sMessage, buttonState) {
        let oSaeButton = this.byId("BookSAEButton");
        this.byId("noDataMessagePage").setDescription(sMessage);

        switch (buttonState) {
            case "invisible":
                oSaeButton.setVisible(false);
                break;
            case "enabled":
                oSaeButton.setEnabled(true);
                oSaeButton.setTooltip(sMessage);
                break;
            case "disabled":
                oSaeButton.setEnabled(false);
                oSaeButton.setTooltip(sMessage);
                break;
            default:
                oSaeButton.setEnabled(true);
        }
    };

    /** ************************************************************************************** */
    /*                            Book a Session Event Handlers                               */
    /** ************************************************************************************** */
    CaseScheduleAnExpertCard.prototype.scheduleASessionPress = function() {
        if (!this._oSAEBookingDialog) {
            Fragment.load({
                id: this._sSAEBookingDialogId = (this.getId() + "-sSAEBookingDialog"),
                name: "sap.me.support.fragments.ScheduleAnExpertBookingDialog",
                controller: this
            }).then(function(oSAEBookingDialog) {
                this._oSAEBookingDialog = oSAEBookingDialog;
                this.oCard.addDependent(this._oSAEBookingDialog);
                this.setDialogContext();
                this._oSAEBookingDialog.open();
            }.bind(this));
        } else {
            this.setDialogContext();
            this._oSAEBookingDialog.open();
        }

    };

    CaseScheduleAnExpertCard.prototype.onCloseBookSAEDialog = function() {
        this._oSAEBookingDialog.close();
    };

    CaseScheduleAnExpertCard.prototype.setDialogContext = function() {

        let oChannelData = JSON.parse(this._oReceivedChannelData.ChannelData);
        this.getCard().setModel(this._oCGModel = new JSONModel(oChannelData.slots),
            "$" + this.alias + ".calendarGrid");
        this._pointerForAppointment = this._oReceivedChannelData.CasePointer;
        this._componentForAppointment = oChannelData.case.component;
        if (oChannelData.case.title) {
            this._oModel2.setData({incidentTitle: oChannelData.case.title});
        }
    };

    CaseScheduleAnExpertCard.prototype.onPressAppointmentDay = function(oEvent) {

        const selectedDateObj = oEvent.getSource().getSelectedDates()[0].getStartDate();
        const year = selectedDateObj.getFullYear();
        const month = selectedDateObj.getMonth() + 1;
        const day = selectedDateObj.getDate();
        const dateStr = `${year}${month < 10 ? "0" + month : month}${day < 10 ? "0" + day : day}`;

        const dayItem = this._oappointmentInformationSAEModel.getProperty("/dayList")?.find(day => day.Date == dateStr);

        if (dayItem?.Date === this._oappointmentInformationSAEModel.getProperty("/selectedDay")) {
            return;
        }
        this.selectAppointmentDay([dayItem]);
        this._fragment.byId(this._sSAEBookingDialogId, "SAESaveAndContinue").setEnabled(false);
    };

    CaseScheduleAnExpertCard.prototype.selectAppointmentDay = function(dayList) {
        // select first available day
        const firstAvailableDay = dayList?.find(v => v?.isAvailable);
        if (!firstAvailableDay) {
            return;
        }

        const timePeriodOptions = SAEHelper.getAvailableTimeList(firstAvailableDay.SLOTS, this._oappointmentInformationSAEModel.getProperty("/timePeriodOptions"));
        const availableCount = timePeriodOptions.reduce((acc, cur) => [...acc, ...cur.timeList], []).filter(item => item.isAvailable)?.length;
        const firstAvailableItem = timePeriodOptions.find(v => v.timeList.find(t => t.isAvailable));

        this._oappointmentInformationSAEModel.setProperty("/selectedDay", firstAvailableDay.Date);
        this._oappointmentInformationSAEModel.setProperty("/timePeriodOptions", timePeriodOptions);
        this._oappointmentInformationSAEModel.setProperty("/availableCount", availableCount);
        this._oappointmentInformationSAEModel.setProperty("/selectedTimeList", timePeriodOptions[firstAvailableItem.key].timeList);
        this._oappointmentInformationSAEModel.setProperty("/selectedTimeIndex", firstAvailableItem.key);
        this._oappointmentInformationSAEModel.setProperty("/selectedTimeItem", {});
        this._oappointmentInformationSAEModel.setProperty("/selectedDate", this.parseDate(firstAvailableDay.Date).toDateString());
    };

    CaseScheduleAnExpertCard.prototype.onPressAppointmentTimeIconSAE = function(oEvent) {
        const key = oEvent.getSource().getBindingContext("$this.appointmentInformationSAE").getProperty("key");
        if (key === this._oappointmentInformationSAEModel.getProperty("/selectedTimeIndex")) {
            return;
        }

        const timePeriodOptions = this._oappointmentInformationSAEModel.getProperty("/timePeriodOptions");

        this._oappointmentInformationSAEModel.setProperty("/selectedTimeIndex", key);
        this._oappointmentInformationSAEModel.setProperty("/selectedTimeList", timePeriodOptions[key].timeList);
        this._oappointmentInformationSAEModel.setProperty("/selectedTimeItem", {});
        this._fragment.byId(this._sSAEBookingDialogId, "SAESaveAndContinue").setEnabled(false);
    };

    CaseScheduleAnExpertCard.prototype.onPressTimeItem = function(oEvent) {
        const selectedTimeItem = oEvent.getSource().getBindingContext("$this.appointmentInformationSAE").getObject();

        if (!selectedTimeItem.isAvailable) {
            return;
        }
        this._oappointmentInformationSAEModel.setProperty("/selectedTimeItem", selectedTimeItem);
        this._fragment.byId(this._sSAEBookingDialogId, "SAESaveAndContinue").setEnabled(true);
    };

    CaseScheduleAnExpertCard.prototype.onSaveAndContinue = function() {
        this._oSlotToSave.setProperty("/selectedDate", this._oSelectedSlot.selectedDate);
        this._oSlotToSave.setProperty("/selectedTime", this._oSelectedSlot.selectedTime);
        this._fragment.byId(this._sSAEBookingDialogId, "firstInfoVBox").setVisible(false);
        this._fragment.byId(this._sSAEBookingDialogId, "secondInfoVBox").setVisible(true);
    };

    CaseScheduleAnExpertCard.prototype.onBackSelected = function() {
        this._fragment.byId(this._sSAEBookingDialogId, "firstInfoVBox").setVisible(true);
        this._fragment.byId(this._sSAEBookingDialogId, "secondInfoVBox").setVisible(false);
    };

    CaseScheduleAnExpertCard.prototype.onDetailedDescriptionChanged = function(oEvent) {
        const value = oEvent.getSource().getValue();
        this._oSlotToSave.setProperty("/enteredAdditionalInfo", value);
    };

    CaseScheduleAnExpertCard.prototype.onBookSession = function() {
        this._oSAEBookingDialog.setBusy(true);


        jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
            method: "PUT",
            contentType: "application/json",
            data: JSON.stringify({
                event: "SAE",
                action: "SEND2SAP",
                pointer: this._pointerForAppointment,
                long_text: this._oSlotToSave.getProperty("/enteredAdditionalInfo") || this._i18n.getText("SAEUpdatedDefaultText"),
                sae_duration:30,
                sae_start_time: this._oappointmentInformationSAEModel.getProperty("/selectedTimeItem/value"),
                rep_case:"1",
                component:this._componentForAppointment,
                status: "SEND2SAP"})
        }).done(() => {
            let that = this;
            setTimeout(function() { // delay call to display new data to give backend time to update
                that.byId("SaeVBox").setBusy(true);
                that.noDataInSectionReset();
                that._oEventBus.publish("sap.me.support.cards.CaseScheduleAnExpertCard", "appointmentChange");
                that._oODataModel.refresh();
                that.byId("BookSAEButton").setVisible(false);
                that._oSAEBookingDialog.setBusy(false);
                that.onCloseBookSAEDialog();
                MessageToast.show(`${that._i18n.getText("SAESubmittedSuccess")}`);
                // after submit clear content
                that._oEditor.setValue("");
            }, 3000);

        }).fail(() => {
            this._oSAEBookingDialog.setBusy(false);
            this._updatefaildialog.open();
        });
    };

    /** ************************************************************************************** */
    /*                                         Formatters                                     */
    /** ************************************************************************************** */

    CaseScheduleAnExpertCard.prototype._formatDateTime = function(sDate) {
        return sDate.replace(/[, ]+/g, ` ${this._i18n.getText("case_discussion_dateTimeConjunction")} `);
    };

    CaseScheduleAnExpertCard.prototype._formatNoDataInSection = function() {
        this.byId("caseAppointmentsList").setShowNoData(false);
        this.byId("noDataMessagePage").setVisible(true);
    };

    CaseScheduleAnExpertCard.prototype._formatSessionsText = function(sText) {
        return sText + " (" + this.byId("casePastAppointmentsList").getItems().length + ")";
    };

    CaseScheduleAnExpertCard.prototype._formatToUserTZone = function(sLocalDate) {

        let toMilliseconds = (hrs,min,sec) => (hrs * 60 * 60 + min * 60 + sec) * 1000;

        let diffToMilli = (toMilliseconds(this._timeZoneUTCdiffHrs, this._timeZoneUTCdiffMins , this._timeZoneUTCdiffSecs));

        let localStartDate = new Date(sLocalDate);
        let startTime = localStartDate.getTime();

        let startTimeInUserTZone;

        if (this._timeZoneUTCsign === "+") {
            startTimeInUserTZone = startTime + diffToMilli;
        } else {
            startTimeInUserTZone = startTime - diffToMilli;
        }


        let userStartDate = new Date(startTimeInUserTZone);

        return userStartDate.toString().substr(0, 25) + this._userTimezone;
    };
    /** ****************************************************************************************** */
    /*                                  Book A Session Formatters                                 */
    /** ****************************************************************************************** */

    CaseScheduleAnExpertCard.prototype.parseDate = function(sDate) {
        return new Date(sDate.substr(0,4), parseInt(sDate.substr(4,2)) - 1, sDate.substr(6,2));
    };

    CaseScheduleAnExpertCard.prototype._formatCancelledTextVisible = function(sStatus) {
        return sStatus === "cancelled";
    };

    CaseScheduleAnExpertCard.prototype._formatTodayTextVisible = function(sStartTime) {
        let parsedDate = this._formatToUserTZone(sStartTime);
        return parsedDate.slice(0, 15) == window.Date().slice(0, 15);
    };

    CaseScheduleAnExpertCard.prototype._formatMenuItemVisible = function(sStatus) {
        if ( sStatus === "cancelled" ) {
            return false;
        }
        if ( sStatus === "completed" ) {
            return false;
        }
        return true;
    };

    return CaseScheduleAnExpertCard;
}, /* bExport= */true);

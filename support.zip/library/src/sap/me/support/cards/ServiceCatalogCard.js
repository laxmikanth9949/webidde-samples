sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "../utils/Constants",
    "sap/base/util/deepEqual",
    "sap/ui/model/resource/ResourceModel"
], function(library, jQuery, CardComposite, JSONModel, Device, Constants, deepEqual, ResourceModel) {
    "use strict";

    let mServiceCatalog = {};

    let ServiceCatalog = CardComposite.extend("sap.me.support.cards.ServiceCatalogCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                contractType: {type: "int"}
            }
        },
        _CONSTANTS: Constants
    });

    ServiceCatalog.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
        // this card uses an own OData model (the Example Model, so initialize the model and set it to the card)
        oCard.setModel(this._oModel = new JSONModel({
            CustomerContractType: null,
            serviceCatalogCardVisible: false
        }), "$" + this.alias + ".serviceCatalogCard");
    };

    ServiceCatalog.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        let cardVisible = false;
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        let sCustomerContractType;

        if (!sCustomerContractType) {
            sCustomerContractType = "CustomerContractType";
        }

        if (sCustomerContractType) {
            if (!mServiceCatalog[sCustomerContractType]) {
                mServiceCatalog[sCustomerContractType] = jQuery.get(this._CONSTANTS.HEC_CUSTOMER_CONTRACT_TYPE);
            }
            mServiceCatalog[sCustomerContractType].then(sCustomerContractType => {
                this._oModel.setProperty("/CustomerContractType", sCustomerContractType);
                cardVisible = (sCustomerContractType !== 10) ? true : false;
                this._oModel.setProperty("/serviceCatalogCardVisible", cardVisible);
            });
        }
        return this;
    };

    ServiceCatalog.prototype._handlePress = function() {
        if (this._oModel.oData.CustomerContractType === 0) {
            const classic = "https://launchpad.support.sap.com/#/hec/servicerequest";
            sap.m.URLHelper.redirect(classic, true);
        } else if (this._oModel.oData.CustomerContractType === 1) {
            const advanced = " https://itsm.services.sap/srm";
            sap.m.URLHelper.redirect(advanced, true);
        }
    };

    ServiceCatalog.prototype.onsapenter = ServiceCatalog.prototype._handlePress;
    if (Device.support.touch) {
        ServiceCatalog.prototype.ontap = ServiceCatalog.prototype._handlePress;
    } else {
        ServiceCatalog.prototype.onclick = ServiceCatalog.prototype._handlePress;
    }

    return ServiceCatalog;
}, /* bExport= */true);

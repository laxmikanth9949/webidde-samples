sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "../utils/Constants",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel"
], function(library, jQuery, CardComposite, deepEqual, Constants, JSONModel, ResourceModel) {
    "use strict";

    let CaseScheduleAManager = CardComposite.extend("sap.me.support.cards.CaseScheduleAManager", {
        library: "sap.me.support",
        metadata: {
            properties: {
                growing: {type: "boolean", defaultValue: false, group: "Designtime"}
            }
        },
        _CONSTANTS: Constants
    });

    let mCaseScheduleAManager = {};

    CaseScheduleAManager.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
    };

    CaseScheduleAManager.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(this._oModel = new JSONModel({
        }), "$" + this.alias + ".odata");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
    };

    CaseScheduleAManager.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext(), oCard = this.oCard, sCaseScheduleAManager = "CaseSchedule";
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._oContext = oContext;
        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        // oCard.authorizationCheck(oContext.authorization, ["READM"], ["READM_INST"], ["ANLEG"], ["GOSAP"]);
        oCard.authorizationCheck(oContext.authorization, ["READM", "READM_INST", "ANLEG", "GOSAP"], false);

        if (!mCaseScheduleAManager[sCaseScheduleAManager]) {
            mCaseScheduleAManager[sCaseScheduleAManager] = jQuery.get(this._CONSTANTS.CASE_SCHEDULE_A_MANAGER_MOCK);
        }

        mCaseScheduleAManager[sCaseScheduleAManager].then(oResult => {
            this._oModel.setData({
                CaseSchedule: oResult
            });
            this.setModel(this._oModel, "$" + this.alias + ".odata");
            this._oModel.refresh();
        });

        return this;
    };

    CaseScheduleAManager.prototype.onPressButtonRead = function(oEvent) {
        sap.m.URLHelper.redirect(oEvent.getSource().getText(), true);
    };

    return CaseScheduleAManager;
}, /* bExport= */true);

sap.ui.define([
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/me/cards/model/models",
    "jquery.sap.global",
    "sap/me/support/fragments/RequestExtendedSupportDialogue"
], function(CardComposite, deepEqual, ResourceModel, JSONModel, MessageToast, models, jQuery, RequestExtendedSupportDialogue) {
    "use strict";
    let RequestExtendedSupportEntranceCard = CardComposite.extend("sap.me.support.cards.RequestExtendedSupportEntranceCard", {
        metadata: {library: "sap.me.support"}
    });

    RequestExtendedSupportEntranceCard.prototype.init = function() {
        this.byId("sapMeRequestExtendedSupportEntranceCard").attachBrowserEvent("click", () => this.handleRequestExtendedSupportPress());
        this.oCard = this.getCard();
    };

    RequestExtendedSupportEntranceCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        this.oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");

        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);
        return this;
    };

    RequestExtendedSupportEntranceCard.prototype.handleRequestExtendedSupportPress = function() {
        this.setBusy(true);
        jQuery.ajax("/backend/raw/support/CustomerInfoVerticle", {
            method: "GET",
            contentType: "application/json"
        }).done(res => {
            // fix the prototype pollution issue
            let customers = Object.create(null);
            const customersResult = Object.create(null);
            Object.assign(customersResult, res);
            Object.keys(customersResult).forEach(customerNumber => {
                // fix the prototype pollution issue
                if (customerNumber === "__proto__" || customerNumber === "constructor" || customerNumber === "prototype") {
                    return;
                }
                let customerType = customersResult[customerNumber]["Type"];
                let customerName = customersResult[customerNumber]["CustomerName"];
                if (customerType) {
                    switch (customerType) {
                        case "SU": customerType = this._i18n.getText("requestExtendedSupport_suCustomer"); break;
                        case "OC": customerType = this._i18n.getText("requestExtendedSupport_ocCustomer"); break;
                    }
                    customers[customerNumber] = `${customerName} - ${customerType}`;
                } else {
                    customers[customerNumber] = customerName;
                }
            });
            if (!this.oRequestExtendedSupportDialogue) {
                this.oRequestExtendedSupportDialogue = new RequestExtendedSupportDialogue(this.getCard());
            }
            this.oRequestExtendedSupportDialogue.setCustomerData(customers);
            this.oRequestExtendedSupportDialogue.open();
        }).always(() => {
            this.setBusy(false);
        });
    };



    return RequestExtendedSupportEntranceCard;
}, /* bExport= */true);

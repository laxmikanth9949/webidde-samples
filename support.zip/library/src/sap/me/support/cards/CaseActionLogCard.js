sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/me/support/model/formatter",
    "sap/ui/model/resource/ResourceModel",
    "sap/me/shared/Models",
    "sap/m/FlexBox",
    "sap/m/IllustratedMessage",
    "sap/m/IllustratedMessageType",
    "sap/m/library"
], function(
    library,
    feLibrary,
    jquery,
    CardComposite,
    deepEqual,
    ODataModel,
    formatter,
    ResourceModel,
    SharedModels,
    FlexBox,
    IllustratedMessage,
    IllustratedMessageType,
    sapLibrary,
) {
    "use strict";

    let CardState = feLibrary.CardState;
    let CaseActionLogCard = CardComposite.extend("sap.me.support.cards.CaseActionLogCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: true, group: "Designtime"},
                growingThreshold: {type: "int", defaultValue: 5, group: "Designtime"},
                showRowCount: {type: "boolean", defaultValue: false, group: "Designtime"}
            }
        },
        formatter: formatter
    });

    CaseActionLogCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this.oCard.getTable().setNoData(new FlexBox({
            height: "100%",
            width: "100%",
            direction: sap.m.FlexDirection.Column,
            alignContent: sap.m.FlexAlignContent.Center,
            alignItems: sap.m.FlexAlignItems.Center,
            justifyContent: sap.m.FlexJustifyContent.Center,
            items: [this._getMessageViewer(this._i18n.getText("action_log_noLogTitle"), this._i18n.getText("action_log_noLogText"), "sapIllus-EmptyList")]
        }));
    };

    CaseActionLogCard.prototype._getMessageViewer = function(oTitle, oSubTitle, illustrationType) {
        const view = new IllustratedMessage({
            illustrationSize: sapLibrary.IllustratedMessageSize["Spot"],
            illustrationType: illustrationType,
            enableVerticalResponsiveness: false
        });
        view.setTitle(oTitle);
        view.setDescription(oSubTitle);
        if (illustrationType === sapLibrary.IllustratedMessageType.SimpleError) {
            view.addAdditionalContent(new Button({
                type: "Transparent",
                text: this._i18n.getText("noData_noSrDataReload"),
                press: () => {
                    this.fetchNotesWithProcessing();
                }
            }));
        }
        return view;
    };

    CaseActionLogCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
    };

    CaseActionLogCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        CardComposite.prototype.setContext.call(this, oContext, false);

        const sQueryParams = `?pointer=${oContext.attributes.caseKey}`;
        const oModel = new ODataModel({
            serviceUrl: `/backend/odata/support/${sQueryParams}`,
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        });

        this.oCard.setModel(this._oODataModel = oModel, "$" + this.alias + ".odata");

        return this;
    };

    return CaseActionLogCard;
}, true);

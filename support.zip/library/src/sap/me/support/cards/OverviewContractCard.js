sap.ui.define([
    "../library",
    "sap/me/cards/CardComposite",
    "sap/base/util/deepEqual",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/Button",
    "sap/m/Toolbar",
    "sap/m/Title",
    "sap/m/ToolbarSpacer",
    "sap/ui/model/resource/ResourceModel"
], function(
    library,
    CardComposite,
    deepEqual,
    ODataModel,
    JSONModel,
    Filter,
    FilterOperator,
    Button,
    Toolbar,
    Title,
    ToolbarSpacer,
    ResourceModel,
) {
    "use strict";

    const OverviewContractCard = CardComposite.extend("sap.me.support.cards.OverviewContractCard", {
        metadata: {
            library: "sap.me.support",
            properties: {
                growing: {type: "boolean", defaultValue: true, group: "Designtime"},
                growingThreshold: {type: "int", defaultValue: 5, group: "Designtime"}
            }
        }
    });

    OverviewContractCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);
        this.oCard = this.getCard();
        this.contractTypeSelect = this.byId("sapMeOverviewContractTypeSelect");
    };

    OverviewContractCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        oCard.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
    };

    OverviewContractCard.prototype.setContext = function(oContext) {
        let oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        CardComposite.prototype.setContext.call(this, oContext, false);

        const oModel = new ODataModel({
            serviceUrl: "/backend/odata/support/",
            synchronizationMode: "None",
            groupId: "$direct",
            operationMode: "Server"
        });

        this.oCard.setModel(this._oODataModel = oModel, "$" + this.alias + ".odata");

        this.setupContractTypeSelect();

        return this;
    };

    OverviewContractCard.prototype.setupContractTypeSelect = function() {
        this.oCard.setModel(this.stateModel = new JSONModel({clean: true}), "typeFilterState");
        this.contractTypeSelect.getBinding("items").attachDataReceived(function() {
            const oPicker = this.contractTypeSelect.createPicker("popover");
            oPicker.addStyleClass("sapMeOverviewContractPopover");
            oPicker.getContent()[0].setHeaderToolbar(new Toolbar({
                content: [
                    new Title({
                        text: "{$this.i18n>overviewContract_filterByType}"
                    }),
                    new ToolbarSpacer(),
                    this._oSelectAllOrClearButton = new Button({
                        type: "Transparent",
                        text: "{= ${typeFilterState>/clean} ? ${$this.i18n>overviewContract_selectAll} : ${$this.i18n>overviewContract_clear} }",
                        press: () => {
                            if (this.stateModel.getProperty("/clean")) {
                                this.contractTypeSelect.setSelectedKeys(this.contractTypeSelect.getKeys());
                            } else {
                                this.contractTypeSelect.setSelectedKeys([]);
                            }
                            this.onContractTypeSelectChange();
                        }
                    })
                ]
            }));
        }.bind(this));
    };

    OverviewContractCard.prototype.setIsFavorite = function(oSource, bIsFavorite) {
        const oBindingContext = oSource.getBindingContext("$this.odata");
        oBindingContext.setProperty(oBindingContext.getPath() + "/isFavorite", bIsFavorite);
    };

    /** ************************************************************************************** */
    /*                                         Formatters                                     */
    /** ************************************************************************************** */

    OverviewContractCard.prototype.formatContractPeriod = function(startDate, endDate) {
        return `
            ${this._i18n.getText("overviewContract_contractPeriodFrom")} \
            ${startDate} \
            ${this._i18n.getText("overviewContract_contractPeriodTo")} \
            ${endDate}
        `;
    };

    OverviewContractCard.prototype.formatContractTypeSelectText = function(label, total) {
        return `${label} (${total})`;
    };

    /** ************************************************************************************** */
    /*                                         Event Handlers                                 */
    /** ************************************************************************************** */

    OverviewContractCard.prototype.onFavoriteIconPressed = function(oEvent) {
        const oSource = oEvent.getSource();
        if (oSource.getBindingContext("$this.odata").getObject("isFavorite")) {
            this.setIsFavorite(oSource, false);
        } else {
            this.setIsFavorite(oSource, true);
        }
    };

    OverviewContractCard.prototype.navigateToContractDetailPage = function() {
    };

    OverviewContractCard.prototype.onContractTypeSelectChange = function() {
        const selectedKeys = this.contractTypeSelect.getSelectedKeys();
        this.stateModel.setProperty("/clean", !selectedKeys.length);
        this.oCard.setCustomFilters(selectedKeys.map(key => new Filter("contractTypeID", FilterOperator.EQ, key)));
    };

    return OverviewContractCard;
}, true);

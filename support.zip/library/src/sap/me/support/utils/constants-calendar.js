
sap.ui.define([
    "../library",
], function(library) {
    const i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.calendar");
    const eventPropertyName = "name";
    const limitModelSettingsSize = 200;
    const cardMediumSize = "M";
    const cardExtraSmallSize = "XS";
    const color = {
        BLACK: "#000000",
        BLUE: "#5899da",
        GREEN: "#7ca10c",
        PURPLE: "#925ace",
        RED: "#ee6868",
        YELLOW: "#e38b16",
        GRAY: "#8497a4",
    };

    const colorPickerSettings = {
        colorsPerRow: 4,
        accentColors: ["#E38B16", "#EE6868", "#DB1F77", "#C0399F", "#6367DE", "#5899DA", "#13A4B4", "#7CA10C", "#925ACE", "#8497A4"],
    };

    const eventType = {
        CAC: {
            type: "cac.planned_downtime",
            description: i18n.getText("eventTypes.cac.description"),
            tooltip: i18n.getText("eventTypes.cac.tooltip"),
        },
        LICENSE_KEY: {
            type: "licence_key.planned_expiration",
            description: i18n.getText("eventTypes.licenseKey.description"),
            tooltip: i18n.getText("eventTypes.licenseKey.tooltip"),
        },
        EXPERT_SESSION: {
            type: "expert_session",
            description: i18n.getText("eventTypes.expertSession.description"),
            tooltip: i18n.getText("eventTypes.expertSession.tooltip"),
        },
        MAINTENANCE_DELIVERY: {
            type: "schedule.maintenance_deliveries",
            description: i18n.getText("eventTypes.maintenanceDelivery.description"),
            tooltip: i18n.getText("eventTypes.maintenanceDelivery.tooltip")
        },
        MANUAL_EVENT_SECURITY_PATCH: {
            type: "manual_event.security_patch",
            description: i18n.getText("eventTypes.manualEvent.securityPatch.description"),
            tooltip: i18n.getText("eventTypes.manualEvent.securityPatch.tooltip"),
        },
        MANUAL_EVENT_UPDATES: {
            type: "manual_event.updates",
            description: i18n.getText("eventTypes.manualEvent.updates.description"),
            tooltip: i18n.getText("eventTypes.manualEvent.updates.tooltip"),
        },
        NEXT_GENERATION_CLOUD_DELIVERY_WEBINARS: {
            type: "manual_event.next_generation_cloud_delivery_webinars",
            description: i18n.getText("eventTypes.nextGenerationCloudDelivery.description"),
            tooltip: i18n.getText("eventTypes.nextGenerationCloudDelivery.tooltip"),
        },
    };

    const internalEventType = {
        CMP_EVENT: "_CMPMaintenance",
    };

    const queryParams = {
        eventType: "eventType",
        startMonth: "startMonth",
        endMonth: "endMonth",
    };

    const calendarViewKeys = {
        dayView: "DAY",
        weekView: "WEEK",
        monthView: "MONTH",
    };

    const userSettings = {
        preferredView: "CALENDAR.PREFERRED_VIEW",
        legend: "CALENDAR.LEGEND",
        preferredLocale: "CALENDAR.PREFERRED_LOCALE",
    };

    const dashboardNameToCapabilityAreaMapping = {
        portfolio: "Portfolio & Products",
        FinanceLegal: "Finance & Legal",
        SystemProvisioning: "Systems & Provisioning",
        myLearnings: "Knowledge & Learning",
        SupportMaintenance: "Maintenance & Support",
        contacts: "Users & Contacts",
    };

    return {
        color, colorPickerSettings, eventType, internalEventType, queryParams, eventPropertyName, calendarViewKeys,
        userSettings, limitModelSettingsSize, dashboardNameToCapabilityAreaMapping, cardMediumSize, cardExtraSmallSize
    };
});

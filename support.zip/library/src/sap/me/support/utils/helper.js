/* eslint-disable no-undef */
sap.ui.define([
    "jquery.sap.global",
    "sap/base/Log",
    "sap/m/InstanceManager"
], function(jQuery, Log, InstanceManager) {
    "use strict";
    let helper = new Object();

    helper.isInChina = window.location.hostname === "me.sap.cn";
    helper.isOnFactory = helper.isInChina || window.location.hostname === "me.sap.com";
    helper.isOnTrial = window.location.hostname === "try-me.sap.com";
    helper.isOnCanary = window.location.hostname.startsWith("forme.internal") || window.location.hostname.startsWith("stage.");
    helper.isLocal = window.location.hostname.startsWith("localhost");
    helper.isDev = window.location.hostname.startsWith("forme-dev.internal") || window.location.hostname.startsWith("dev.");
    helper.isTest = window.location.hostname.startsWith("forme-test.internal") || window.location.hostname.startsWith("test.");

    helper.isPublic = helper.isOnFactory || helper.isOnTrial;
    helper.isInternal = !helper.isPublic;
    helper.isExperimental = helper.isInternal && !helper.isOnCanary;
    helper.isTrial = window.location.hostname.endsWith("try-me.sap.com");
    helper.isPartnerView = window.location.pathname.split("/")[2] === "partner";
    helper.SACNonLeafSingleQuestionPrefix = "sapMeSACNonLeafSingleQuestionIdNo_";
    helper.SACLeafSingleQuestionPrefix = "sapMeSACLeafSingleQuestionIdNo_";
    helper.SACFreeTextQuestionPrefix = "sapMeSACFreeTextQuestionIdNo_";

    helper.validateURL = function(str) {
        const pattern = new RegExp("^(https?:\\/\\/)" // protocol
            + "([a-z\\d][a-z\\d-]{0,62}(\\.[a-z\\d][a-z\\d-]{0,62})+\\.?|" // domain name
            + "((\\d{1,3}\\.){3}\\d{1,3}))" // OR ip (v4) address
            + "(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*" // port and path
            + "(\\?[;&a-z\\d%_.~+=-]*)?" // query string
            + "(\\#[-a-z\\d_]*)?$", "i"); // fragment locator
        return !!pattern.test(str);
    };

    // TODO Find out if still needed (no calls found in frontend repo)
    helper.initializeUniversalId = function() {
        if (!helper.isTrial && window["universalID"] && !universalID.initialized) {
            universalID.initRegFlow({
                landscape: helper.isPublic ? "prod" : "qa",
                callback: () => {
                    universalID.initialized = true;
                }
            });
        }
    };

    // TODO: maybe switch to CSS only fades in future
    helper.fadeIn = function(oElement, vDuration, fnComplete) {
        let oElement$ = oElement.$(), fnDone = () => {
            oElement.removeStyleClass("sapMeHidden");
            fnComplete && fnComplete(); // eslint-disable-line no-unused-expressions
        };

        if (oElement$.length) {
            oElement$.fadeIn(vDuration, fnDone);
        } else {
            fnDone();
        }
    };
    helper.fadeOut = function(oElement, vDuration, fnComplete) {
        let oElement$ = oElement.$(), fnDone = () => {
            oElement.addStyleClass("sapMeHidden");
            fnComplete && fnComplete(); // eslint-disable-line no-unused-expressions
        };

        if (oElement$.length) {
            oElement$.fadeOut(vDuration, fnDone);
        } else {
            fnDone();
        }
    };
    /**
     * Closes all open (mobile) popups, original implementation from sap.m.routing.TargetHandler
     *
     * Old implementation based on the Popup.blStack was deprecated in favour of this, this one might not be working
     * for popups not based on the mobile library (possibly the Popup.blStack could be utilized again if needed)
     */
    helper.closeAllOpenPopups = function() {
        // close open popovers
        if (InstanceManager.hasOpenPopover()) {
            InstanceManager.closeAllPopovers();
        }

        // close open dialogs
        if (InstanceManager.hasOpenDialog()) {
            InstanceManager.closeAllDialogs();
        }

        // close open light boxes
        if (InstanceManager.hasOpenLightBox()) {
            InstanceManager.closeAllLightBoxes();
        }
    };

    helper.getI18n = function() {
        if (!helper._i18n) {
            helper._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.cards");
        }
        return helper._i18n;
    };

    // add further card libraries here, in order for them to be available in the admin tool
    helper.getLibraries = function() {
        return ["sap.me.cards", "sap.me.cards.common", "sap.me.cards.example", "sap.me.cards.system", "sap.me.cards.systemdetail", "sap.me.cards.calendar", "sap.me.cards.finance", "sap.me.cards.partner", "sap.me.cards.license_compliance", "sap.me.cards.ecs"];
    };

    /**
     * @description loads ui5 contributing libraries
     * @param {string[]|undefined} aLibraryNames libraries (optional)
     * @param {boolean|undefined} bAsync load libraries asynchronously
     * @returns {Promise<Object<string,Object>>} Promise containing an Object : {[libraryName: libObject]}
     */
    helper.loadLibraries = async function(aLibraryNames, bAsync) {
        let oCore = sap.ui.getCore(),
            aLibraries = aLibraryNames ?? helper.getLibraries();
        return Promise.all(aLibraries.map(sLibrary => {
            try {
                return oCore.loadLibrary(sLibrary, {async: bAsync ?? false});
            } catch (e) {
                return e;
            }
        })).then(libs => Object.fromEntries(libs.map(lib => [lib.name, lib])));
    };

    helper.replaceKeys = function(object, searchValue, newValue) {
        if (Array.isArray(object)) {
            return object.map((oItem) => helper.replaceKeys(oItem, searchValue, newValue));
        } else if (object && typeof object === "object") {
            return Object.fromEntries(Object
                .entries(object)
                .map(([k, v]) => [
                    k.replace(searchValue, newValue),
                    helper.replaceKeys(v, searchValue, newValue)])
            );
        }
        return object;

    };

    let currentPermission;

    helper.currentUserPermission = async function(pointer, oCard) {
        // when user change to another case detail page , the validation check should be triggered again
        if (!currentPermission || (!!currentPermission && pointer !== currentPermission.Pointer)) {
            oCard._oContextModel.setProperty("/isCanWrite", false);
            oCard._oContextModel.setProperty("/isCanRead", false);
            oCard._oContextModel.setProperty("/isCanClose", false);
            const data = await helper.getValidationResult(pointer);
            if (!data) {
                return;
            }
            currentPermission = data;
            currentPermission.Pointer = pointer;
            oCard._oContextModel.setProperty("/isCanWrite", data.CanWrite);
            oCard._oContextModel.setProperty("/isCanRead", data.CanRead);
            oCard._oContextModel.setProperty("/isCanClose", data.CanClose);
            oCard._oContextModel.setProperty("/Message", data.Message);
            oCard._oContextModel.setProperty("/RespITSM", data.RespITSM);
            oCard._oContextModel.setProperty("/infoDoc", data.InfoDoc);
        } else {
            oCard._oContextModel.setProperty("/isCanWrite", currentPermission.CanWrite);
            oCard._oContextModel.setProperty("/isCanRead", currentPermission.CanRead);
            oCard._oContextModel.setProperty("/isCanClose", currentPermission.CanClose);
            oCard._oContextModel.setProperty("/Message", currentPermission.Message);
            oCard._oContextModel.setProperty("/RespITSM", currentPermission.RespITSM);
            oCard._oContextModel.setProperty("/infoDoc", currentPermission.InfoDoc);
        }
    };

    helper.getValidationResult = async function(pointer) {
        try {
            return await jQuery.ajax("/backend/raw/support/CaseValidationVerticle", {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                data:{
                    pointer : pointer
                },
            });
        } catch (e) {
            console.error("fail to get validation result");
        }

    };

    helper.getServiceRequestReleased = function(oCard) {
        oCard._oContextModel.setProperty("/createServiceRequestCase", undefined);
        jQuery.ajax("/backend/raw/support/ServiceRequestReleased", {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            async: false,
            success:(data) => {
                oCard._oContextModel.setProperty("/createServiceRequestCase", data.situation);
            },
            error:() => {
                Log.info("Something wrong with ServiceRequestReleasedVerticle");
            }
        });
    };

    let timeholder = {};
    helper.debounce = function(func, type, wait = 1000) {
        return (...args) => {
            clearTimeout(timeholder[type]);
            timeholder[type] = setTimeout(() => {
                func.apply(this, args);
            }, wait);
        };
    };

    /**
     * Get the selectedKey of the tab which has data in List (left to right), only for IconTabBar with List
     * @param {string} defaultKey
     * @param {object} oIconTabBar the IconTabBar instance
     * @returns {string} selectedKey
     */
    helper.getTabDefaultSelectKey = function(defaultKey, oIconTabBar) {
        if (!oIconTabBar) {
            return defaultKey;
        }

        const tabItems = oIconTabBar.getItems() || [];

        for (const item of tabItems) {
            const key = item.getProperty("key");
            const oBinding = item.getContent()[0].getBinding("items");
            if (oBinding && oBinding.oList?.length) {
                return key;
            }
        }

        return defaultKey;
    };

    helper.dateConstructedID = function() {
        const iRandomTail = Math.floor(Math.random() * 10) + "" + Math.floor(Math.random() * 10) + "" + Math.floor(Math.random() * 10);
        return new Date().getTime() + "-" + iRandomTail;
    };

    helper.formatPriorityLevelToText = function(level) {
        switch (level) {
            case "1":
                return "Very High";
            case "2":
                return "High";
            case "3":
                return "Medium";
            default:
                return "Low";
        }
    };

    helper.generateUUID = function() {
        let d = new Date().getTime();
        if (typeof performance !== "undefined" && typeof performance.now === "function") {
            d += performance.now();
        }
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
            const r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === "x" ? r : (r & 0x3 | 0x8)).toString(16);
        });
    };

    /**
     * @param {boolean} isSetClass true --> add "forbiddenClick" class to elements. false --> remove "forbiddenClick" class
     */
    helper.isForbidClickModal = function(isSetClass) {
        const elements = ["#sap-ui-blocklayer-popup", ".sapMPageHeader", "#__xmlview0--shellContent", "#__xmlview0--shellFooter"];
        elements.forEach(e => {
            isSetClass ? jQuery(e).addClass("forbiddenClick") : jQuery(e).removeClass("forbiddenClick");
        });
    };

    helper.getEnvironment = function() {
        if (helper.isDev) {
            return "dev";
        }
        if (helper.isTest) {
            return "test";
        }
        if (helper.isLocal) {
            return "local";
        }
        return "prod";
    };

    /**
     * remove <p> </p>\n tag from string begining and remove \n<p> </p> from end
     * @param {*} str <i>AD<\/i><br><p> </p>\n<p> </p>\n<p>test bi</p>\n<p> </p>\n<p>   </p>
     * @returns <p>test bi</p>
     */
    helper.deleteEnterFromBothSide = function(str) {
        const regStr = /(^(<p>\s*<\/p>\n)*)|((\n<p>\s*<\/p>)*$)/g;
        // business impact content
        const regBIText = /^(<i>.*?<\/i>(<br>)+)/;
        let bIMatchStr = "";
        if (regBIText.test(str)) {
            bIMatchStr = str.match(regBIText)[0];
            str = str?.replace(bIMatchStr, "");
        }
        return bIMatchStr + str?.replace(regStr, "");
    };

    return helper;
});

sap.ui.define([
    "sap/ui/model/Filter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/me/cards/model/models",
    "sap/base/util/deepClone",
    "sap/ui/base/Object",
    "sap/me/support/utils/ContactRoleType",
], function(
    Filter,
    JSONModel,
    FilterOperator,
    MessageToast,
    models,
    deepClone,
    BaseObject,
    ContactRoleType,
) {
    const ContactHelper = BaseObject.extend("sap.me.support.utils.ContactHelper", {

        constructor: function() {},

        /** ************************************************************************************** */
        /*                                   public method                                        */
        /** ************************************************************************************** */
        initContacts : function(oContext) {
            if (!this.oContactModel) {
                this.oContactModel = new JSONModel({ContactsSectionCard:[]});
            }
            this._oContext = oContext ?? this._oContext;
            if (!this._oContext.sPointer) {
                this.buildPredefinedContacts([]);
                return true;
            }
            if (!this._sQueryContactUrl) {
                this._sQueryContactUrl = "/backend/odata/support/CaseContacts?pointer=" + this._oContext.sPointer;
            }
            jQuery.ajax(this._sQueryContactUrl,{
                async:false,
                timeout:2000,
                success: (data) => {
                    if (data?.value) {
                        this._setContactModel(data.value);
                    }
                    this.buildPredefinedContacts(this._getContactList());
                },
                error: () => {
                    console.error("ContactHelper:get contact error");
                    this._setContactModel([]);
                }
            });
            return this;
        },

        getDefaultContact : async function() {
            try {
                const caseSettings = await jQuery.ajax("/backend/raw/common/Settings/CASE");
                const defaultContact = caseSettings["CASE.DEFAULT_CONTACT"];
                if (!defaultContact[0]) {
                    return;
                }
                return Object.fromEntries(JSON.parse(defaultContact[0]));
            } catch (e) {
                console.log("query default contact fail");
                return;
            }
        },

        /**
         * usage: replace specific role contact, or create a specific role contact
         *
         * @param sRole
         * @param oData - Must use format as current list
         */
        buildContactWithData : function(sRole,oData) {
            const aCurrentContacts = this._getContactList();
            const aFilterResultList = aCurrentContacts.filter(oContact => oContact.role === sRole);
            // It is not better to use assign. Because target will override with "";
            const assignContact = (target,source) => {
                target.contact = source.contact;
                target.email = source.email;
                target.mobile = source.mobile;
                target.telephone = source.telephone;
                target.timezone = source.timezone;
                target.userId = source.userId;
            };
            if (aFilterResultList.length > 0) {
                aFilterResultList.map(oContact => {
                    assignContact(oContact,oData);
                });
            } else {
                const oNewContact = this._buildEmptyContact(ContactHelperFactory.ROLE_MAP[sRole]);
                assignContact(oNewContact,oData);
                aCurrentContacts.push(oNewContact);
                this._setContactModel(aCurrentContacts);
            }
        },

        buildPredefinedContacts : async function(aExistContactList) {
            const aContacts = aExistContactList ? aExistContactList : [],aExistRoleList = [];
            aContacts.forEach(oContact => {
                if (!aExistRoleList.includes(oContact.role)) {
                    aExistRoleList.push(oContact.role);
                }
                if (oContact.role === ContactRoleType.BUSINESS_USER) {
                    // 4me NOT_SEND_TO_SAP case only have userId
                    // LP SEND_TO_SAP case only have contact
                    oContact.userId = oContact.contact = oContact.userId ? oContact.userId.trim() : oContact.contact ? oContact.contact.trim() : "";
                }
            });
            for (const key of Object.keys(ContactHelperFactory.ROLE_MAP)) {
                const oRole = ContactHelperFactory.ROLE_MAP[key];
                aContacts.filter(oContact => oContact.role === key).map(oContact => {
                    oContact.order = oRole.order;
                    oContact.available = this._setAvailable(oContact.contact,oContact.role);
                    oContact.displayRole = oRole.displayRole;
                });
                if (aExistRoleList.includes(key) || !oRole.predefined) {
                    continue;
                }

                aContacts.push(this.buildPredefinedContact(key));
            }


            // get default contact if there is one
            const oDefaultContact = await this.getDefaultContact();

            if(oDefaultContact){
                // Logic for listing default contact on case create screen
                if (!aContacts.find(o => o.email === oDefaultContact.email && o.telephone === oDefaultContact.telephone) && !this._oContext.oView) {
                    aContacts.push(oDefaultContact);
                    this.oContactModel.setProperty("/defaultContact", oDefaultContact);
                }

                // Logic for listing default contact on case details screen
                const oListedDefaultContact = aContacts.find(o => o.email === oDefaultContact.email && o.mobile === oDefaultContact.telephone && o.telephone === oDefaultContact.mobile);
                if(this._oContext.oView && oListedDefaultContact){
                    oListedDefaultContact.default_contact = true;
                }
            }

            this._setContactModel(aContacts);
        },

        buildPredefinedContact : function(sRole) {
            return this._buildEmptyContact(ContactHelperFactory.ROLE_MAP[sRole]);
        },

        refreshContactListV2 : async function() {
            try {
                const data = await jQuery.ajax(this._sQueryContactUrl);
                this._setContactModel(!data?.value ? [] : data.value);
                this.buildPredefinedContacts(this._getContactList());
                this._oContext.oView.getModel("$this.caseContacts").refresh();
            } catch (e) {
                MessageToast.show("ContactHelper - query contact fail, try again");
            }
        },

        addContact : function(oContact) {
            const aContacts = this._getContactList();
            aContacts.push(oContact);
            this._setContactModel(aContacts);
        },

        deleteContact : function(sIndex) {
            const aContacts = this._getContactList();
            const oContact = aContacts[sIndex];
            const oRole = ContactHelperFactory.ROLE_MAP[oContact.role] ?? oContact;
            if (oRole?.replaceWithEmpty) {
                aContacts.splice(sIndex, 1, this._buildEmptyContact(oRole,oContact.ID));
            } else {
                aContacts.splice(sIndex, 1);
            }
            this._setContactModel(aContacts);
        },

        replaceWithEmpty : function(sIndex) {
            const aContacts = this._getContactList();
            const oContact = aContacts[sIndex];
            const oRole = ContactHelperFactory.ROLE_MAP[oContact.role] ?? oContact;
            aContacts.splice(sIndex, 1, this._buildEmptyContact(oRole,oContact.ID));
            this._setContactModel(aContacts);
        },

        deleteContactByRole : function(sRole) {
            const iIndex = this._getContactList().findIndex((item) => item.role === sRole);
            if (iIndex >= 0) {
                this.deleteContact(iIndex);
            }
        },

        updateContact : function(oContact,sIndex) {
            if (sIndex < 0 || !oContact) {
                return;
            }
            oContact.available = this._setAvailable(oContact.contact,oContact.role);
            this._setDisplayRole(oContact);
            const aContacts = this._getContactList();
            aContacts.splice(sIndex, 1, oContact);
            this._setContactModel(aContacts);
        },

        getContact : function(sRole) {
            const contactList = this._getContactList();
            return !sRole ? contactList : contactList.filter(contact => contact.role === sRole);
        },

        findIndexById : function(sId) {
            return this._getContactList().findIndex((item) => item.ID === sId);
        },

        getContactDetailByUserId : function(sUserId) {
            return new Promise((res,rej) => {
                jQuery.ajax("/backend/raw/support/CaseContactsW7Verticle?$filter=(UserId eq '" + sUserId + "')", {
                    method: "GET",
                    contentType: "application/json",
                    success: data => {
                        res(data);
                    },
                    error: () => rej()
                });
            });
        },

        replaceAll : function(aContacts) {
            this._setContactModel(aContacts);
        },

        getContactModel : function() {
            if (!this.oContactModel) {
                this.oContactModel = new JSONModel();
            }
            return this.oContactModel;
        },

        /** ************************************************************************************** */
        /*                                   private method                                       */
        /** ************************************************************************************** */

        _buildEmptyContact : function(oRole, sId) {
            return {
                role:oRole.role,
                displayRole:oRole.displayRole,
                userId:"",
                contact:"",
                mobile:"",
                telephone:"",
                email:"",
                available:this._setAvailable("",oRole.role),
                timezone:"",
                order:oRole.order,
                ID:sId ? sId : this._generateUUID()
            };
        },

        _generateUUID : function() {
            return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
                (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
            );
        },

        _setAvailable : function(sContactName,sRole) {
            return !(!sContactName && ContactHelperFactory.ROLE_MAP[sRole]?.predefined);
        },

        _setContactModel : function(aContacts) {
            // both add and refresh should check displayRole,available,ID should not be blank.
            aContacts = aContacts.map(oContact => {
                if (!oContact.displayRole) {
                    this._setDisplayRole(oContact);
                }
                if (!oContact.available) {
                    oContact.available = this._setAvailable(oContact.contact,oContact.role);
                }
                if (!oContact.ID) {
                    oContact.ID = this._generateUUID();
                }
                if (!oContact.order) {
                    oContact.order = ContactHelperFactory.ROLE_MAP[oContact.role]?.order;
                }
                return oContact;
            }).sort((item1,item2) => {
                // if different role, then sort by order; otherwise sort by contact
                return item1.role !== item2.role ? (item1.order ?? 99) - (item2.order ?? 99) : (item1.contact?.localeCompare(item2.contact ?? "") ?? 1);
            });
            this.oContactModel.setData({ContactsSectionCard:aContacts});
        },

        _getContactList : function() {
            return !this.oContactModel ? [] : this.oContactModel.getData().ContactsSectionCard;
        },

        _setDisplayRole: function(oContact) {
            if (!oContact.role) {
                oContact.role = ContactRoleType.INCIDENT_CONTACT;
            }
            const oRole = ContactHelperFactory.ROLE_MAP[oContact.role];
            oContact.displayRole = oRole ? oRole.displayRole : oContact.role;
        },

        /** ************************************************************************************** */
        /*                                Deprecated method                                       */
        /** ************************************************************************************** */
        // Deprecated. see ContactBaseValueHelpController
        handleContactsValueHelpSearch : function(oEvent) {
            const value = oEvent.getParameter("value");
            const aSearchFields = ["contact", "email", "userId"];
            const aSearchFilters = [];
            if (value) {
                for (let i = 0; i < aSearchFields.length; i++) {
                    const oTempFilter = new Filter(aSearchFields[i], FilterOperator.Contains, value);
                    aSearchFilters.push(oTempFilter);
                }
            }
            const oItems = oEvent.getSource().getBinding("items");
            if (oItems) {
                oItems.filter([new Filter(aSearchFilters, false)]);
            }
        },

    });

    const i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");

    const ContactHelperFactory = {
        ROLE_MAP : {
            Reporter:{role:ContactRoleType.REPORTER,displayRole:i18n.getText("CreateContact_Role_Reporter"),order:0,predefined:false,alias:[ContactRoleType.REPORTER,"REPORTER"],replaceWithEmpty:false,hideDeleteIcon:true,hideValueHelpIcon:true},
            "Created By":{role:ContactRoleType.CREATED_BY,displayRole:i18n.getText("CreateContact_Role_Create_By"),order:1,predefined:false,alias:[ContactRoleType.CREATED_BY,"CREATED BY","CREATED_BY"],replaceWithEmpty:false,hideDeleteIcon:true,hideValueHelpIcon:true},
            "Business User":{role:ContactRoleType.BUSINESS_USER,displayRole:i18n.getText("CreateContact_Role_Business_User"),order:2,predefined:false,alias:[ContactRoleType.BUSINESS_USER,"CBUSER"],replaceWithEmpty:false,hideValueHelpIcon:true},
            "Primary Contact":{role:ContactRoleType.PRIMARY_CONTACT,displayRole:i18n.getText("CreateContact_Role_Primary_Contact"),order:3,predefined:true,alias:[ContactRoleType.PRIMARY_CONTACT,"24HOUR","24H CONTACT","24TH CONTACT"],replaceWithEmpty:true},
            "Secondary Contact":{role:ContactRoleType.SECONDARY_CONTACT,displayRole:i18n.getText("CreateContact_Role_Secondary_Contact"),order:4,predefined:true,alias:[ContactRoleType.SECONDARY_CONTACT,"SECONDARY","SECONDARY CONTACT"],replaceWithEmpty:true},
            "System Opener":{role:ContactRoleType.SYSTEM_OPENER,displayRole:i18n.getText("CreateContact_Role_System_Opener"),order:5,predefined:true,alias:[ContactRoleType.SYSTEM_OPENER,"SYSTEM_OPENER","SYSTEM OPENER"],replaceWithEmpty:true},
            "Incident Contact":{role:ContactRoleType.INCIDENT_CONTACT,displayRole:i18n.getText("CreateContact_Role_Incident_Contact"),order:6,predefined:false,alias:[ContactRoleType.INCIDENT_CONTACT,"CONTACT"],replaceWithEmpty:false},
            "Key User":{role:ContactRoleType.KEY_USER,displayRole:i18n.getText("CreateContact_Role_Key_User"),order:7,predefined:false,alias:[ContactRoleType.KEY_USER,"KEYUSER"],replaceWithEmpty:false}
        }
    };

    ContactHelperFactory.contactHelperHolder = {};

    ContactHelperFactory.getContactHelper = function(type,oContext) {
        let contactHelperInstance = this.contactHelperHolder[type];
        if (!contactHelperInstance) {
            contactHelperInstance = new ContactHelper();
            this.contactHelperHolder[type] = contactHelperInstance;
            contactHelperInstance.initContacts(oContext);
        }
        return contactHelperInstance;
    };

    ContactHelperFactory.isRoleDuplicate = function(sRole) {
        // const aUniqueRoles = Object.keys(ContactHelperFactory.ROLE_MAP)
        //             .map(k=>ContactHelperFactory.ROLE_MAP[k])
        //             .map(config=>config.role)
        //             .filter(role=>!(role==="Incident Contact"||role==="System Opener"))
        //             .map(role=>role.toUpperCase());
        const aUniqueRoles = Object.keys(ContactHelperFactory.ROLE_MAP).map(role => role.replace(/\s+/g,"").toUpperCase());
        return !sRole ? false : aUniqueRoles.includes(sRole.trim().toUpperCase());
    };

    return ContactHelperFactory;

},true);

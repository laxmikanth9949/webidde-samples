sap.ui.define([
    "sap/ui/base/Event",
    "sap/m/CustomListItem",
    "sap/me/support/fragments/CreateSelectComponentDialog",
    "sap/me/shared/Models",
    "sap/me/support/model/formatter",
    "sap/me/support/utils/Constants",
    "sap/me/support/utils/engineerMemo/index"
], function(Event, CustomListItem, CreateSelectComponentDialog, SharedModels, formatter, Constants, engineerMemo) {
    const {ComponentMemoUtil} = engineerMemo;

    /**
    * Prefill Workflow:
    *
    * 1. Check if the URL contains a system number.
    * 2. If the system number is present, validate it for the current user.
    * 3. If the system number is valid, retrieve the related customer details.
    *    - If the system number is invalid, open the customer select dialog as usual.
    * 4. If the customer is not supported, fill out the customer info.
    *    - If the customer is supported, open the S-user select dialog.
    *       - Fill out the customer info once the S-user is selected.
    * 5. After the customer is filled out, retrieve system details.
    * 6. Fill out the system info.
    * 7. If the URL contains a component name, retrieve the component details.
    * 8. If the component is valid, fill out the component info.
    *    - If the component is invalid, do nothing.
    * 9. Map out the product/product function after the component is filled.
    */
    return {
        caseCreationCard: null,
        systemNumber: null,
        componentName: null,
        _oEventBus: sap.ui.getCore().getEventBus(),
        userInfo: {},
        isComponentValid: false,
        prefilledSystemData: null,

        init(caseCreationCard) {
            this.caseCreationCard = caseCreationCard;
            this.userInfo = SharedModels.getUserModel().getData();
            const prefillMode = this.checkSearchParams();
            this.initEventBus();

            if (prefillMode === Constants.CASE_CREATION_CASE_MODE.SYS_PREFILL) {
                this.checkSystemValid();
            } else if (prefillMode === Constants.CASE_CREATION_CASE_MODE.COMP_PREFILL) {
                this.prefillComponentInfo(prefillMode);
            }
        },
        initEventBus() {
            this._oEventBus.subscribeOnce("sap.me.support.utils.PrefillHelper", "selectedSUser", () => {
                if (this.prefilledSystemData) {
                    this.prefillCustomer();
                }
            });
        },
        clearPrefillData() {
            this.systemNumber = null;
            this.componentName = null;
            this.isComponentValid = false;
            this.prefilledSystemData = null;
            this.isPrefillOpened = false;
        },
        checkSearchParams() {
            const searchParams = new URLSearchParams(window.location.search);
            const systemNumber = searchParams.get("sysnr");
            const componentName = searchParams.get("comp_name");

            this.systemNumber = systemNumber;
            this.componentName = componentName;
            if (this.systemNumber) {
                return Constants.CASE_CREATION_CASE_MODE.SYS_PREFILL;
            }
            if (this.componentName) {
                return Constants.CASE_CREATION_CASE_MODE.COMP_PREFILL;
            }
            return null;
        },
        async checkSystemValid() {
            if (!this.systemNumber) {
                return;
            }
            this.caseCreationCard.currentCardPageView.setBusy(true);
            let results;
            try {
                results = await jQuery.ajax(`/backend/raw/support/CaseSystemSet?sysnr=${this.systemNumber}`, {
                    method: "GET",
                    contentType: "application/json",
                    dataType: "json",
                });
            } catch (e) {
                this.openCustomerSelectDialog();
                return;
            }

            const systemInfo = results[0];
            if (!systemInfo || systemInfo.Uname !== this.userInfo.userName) {
                // system is not valid for current user
                this.openCustomerSelectDialog();
                return;
            }
            this.prefilledSystemData = systemInfo;
            this.getCustomerDetailInfo();
        },
        getCustomerDetailInfo() {
            const filterText = `Type eq 'CUSTOMER' and Uname eq '${this.userInfo.userName}'`;

            jQuery.ajax(`/backend/raw/support/CaseF4HelpW7Verticle?$filter=${filterText}`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                success:(oCustomerCollection) => {
                    const customerData = oCustomerCollection?.find(v => v.Name === this.prefilledSystemData.Customer);
                    if (!customerData) {
                        this.openCustomerSelectDialog();
                        return;
                    }
                    const customListItem = new CustomListItem();
                    customListItem.setBindingContext({
                        getObject: () => customerData
                    }, "selectionList");
                    const pressEvent = new Event("press", customListItem, customerData);
                    this.caseCreationCard._selectCustomerDialog.onSelectedCustomerItem(pressEvent);
                    // if it is supported customer
                    if (this.caseCreationCard._selectCustomerDialog.getIsSupportCustomer()) {
                        // show the s-user select dialog
                        this.openSuserSelectDialog();
                        return;
                    }
                    this.prefillCustomer();
                },
                error:() => {
                    this.openCustomerSelectDialog();
                }
            });
        },
        prefillCustomer() {
            this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", "newCaseCreated");
            this.prefillSystemInfo();
        },
        prefillSystemInfo() {
            const sUserNumber = this.caseCreationCard._selectSuserDialog.getSuserModel()?.getData().suserNumber ?? this.userInfo.userName;
            const filterText = `$count=true&$filter=uname eq '${sUserNumber}' and customerNumber eq '${this.prefilledSystemData.Customer}' and searchText eq '${this.prefilledSystemData.SystemNumber}'`;
            this.caseCreationCard.currentCardPageView.setBusy(true);
            jQuery.ajax(`/backend/odata/support/SystemSearch?${filterText}`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json"
            }).then(async results => {
                this.caseCreationCard.currentCardPageView.setBusy(false);
                const systemDetailInfo = results?.value?.find(v => v.systemNumber === this.prefilledSystemData.SystemNumber);
                if (!systemDetailInfo) {
                    return;
                }
                const currentDisplayName = formatter.formatSystemDisplayName(`${systemDetailInfo.systemId} - ${systemDetailInfo.systemName}`);
                this.caseCreationCard.fragmentControllers.BasicInformationStep.data.system.info = {
                    currentDisplayName,
                    systemNumber: systemDetailInfo.systemNumber,
                    installationNbr: systemDetailInfo.installationNumber ,
                    dataProcessRestriction: systemDetailInfo.dataProcessRestriction,
                    systemId: systemDetailInfo.systemId,
                    systemName: systemDetailInfo.systemName
                };
                this.caseCreationCard._systemSelectDialog.handleSelectedSystemData(systemDetailInfo);
                await this.caseCreationCard._systemSelectDialog.callSystemInfo(systemDetailInfo);
                this.caseCreationCard._systemSelectDialog._checkIsAttachmentBlockedAndClassified();
                this.caseCreationCard._systemSelectDialog.checkSystemAvailability();
                this.caseCreationCard.sendSAPHanaCloudProductChange();
                return this.getProductList(this.prefilledSystemData.SystemNumber);
            }).always(() => {
                this.caseCreationCard.initSystemSelectDialogInfo();
            }).then(async() => {
                this.caseCreationCard.setCompAllNeedsModel();
                await this.prefillComponentInfo();
            }).catch(() => {
                this.caseCreationCard.currentCardPageView.setBusy(false);
            });
        },
        async prefillComponentInfo(prefillCompMode) {
            if (!this.componentName) {
                return;
            }
            this.caseCreationCard.currentCardPageView.setBusy(true);
            try {
                const data = await jQuery.ajax("/backend/raw/support/CaseCreateCompProductSearchSetW7", {
                    method: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    data: {
                        $filter: `CompName eq '${this.componentName}'`
                    }
                });
                const componentInfo = data ? data[0] : {};
                // if current search parameter only has comp_name, open the customer dialog
                if (prefillCompMode) {
                    this.openCustomerSelectDialog();
                }
                // K is "X" means the component is selectable
                if (componentInfo?.K !== "X") {
                    return;
                }
                this.isComponentValid = true;
                this.caseCreationCard.selectComponent = {
                    ...componentInfo,
                    selectionMethod: "URL",
                    submitStepEventInfo : {systemAction:"URL"}
                };
                // if current comp_name is valid and only has comp_name in search param, reset the first step data
                // TODO reset system and short description
                if (!this.caseCreationCard._componentSelectDialog) {
                    this.caseCreationCard._componentSelectDialog = new CreateSelectComponentDialog(this.caseCreationCard);
                }
                if (!this.isPrefillOpened) {
                    this.caseCreationCard._componentSelectDialog._requestProductByComp("url").then((data) => {
                        if (prefillCompMode) {
                            this.caseCreationCard.trackBasicInfoStepCChange("System (URL)", componentInfo.CompName, undefined);
                        }
                        this.caseCreationCard.processPPFCSelectionRecordsArr(ComponentMemoUtil.normalUrl(this.componentName));
                        this.caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info = this.caseCreationCard.selectComponent;
                        this.caseCreationCard._componentSelectDialog._handleProductPartAfterRequest(data.data, data.method);
                        this.caseCreationCard.handleProcessAfterProSelection();
                    }).catch(()=>{
                        // means prevent. change component status
                        this.isComponentValid = false;
                    });
                }

            } finally {
                this.caseCreationCard.currentCardPageView.setBusy(false);
            }
            this.isPrefillOpened = true;
        },
        // if prefill data check is not valid, show customer select dialog like normal case flow
        openCustomerSelectDialog() {
            this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", "openCustomerSelectDialog");
            this.caseCreationCard.currentCardPageView.setBusy(false);
        },
        // if prefill system's customer is support customer, show s-user select dialog
        openSuserSelectDialog() {
            this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", "openSuserSelectDialog");
            this.caseCreationCard.currentCardPageView.setBusy(false);
        },
        getProductList(systemNr) {
            if (!systemNr) {
                return;
            }
            return this.caseCreationCard.getAllProductList(systemNr).then(data => {
                const transferArrayToArraySet = this.caseCreationCard._systemSelectDialog.transferArrayToArraySet;
                const productList = data.product;
                if (productList.length) {
                    this.caseCreationCard._oProductModel.setProperty("/allData", productList);
                    this.caseCreationCard._oProductModel.setProperty("/productFilters", transferArrayToArraySet(productList, "DisplayName"));
                    this.caseCreationCard._oProductModel.setProperty("/softerFilters", transferArrayToArraySet(productList, "SoftwareProduct"));
                    this.caseCreationCard._oProductModel.setProperty("/relationshipTypeFilters", transferArrayToArraySet(productList, "RelationshipType"));
                    // filter for product recent data according userprofile recent data
                    this.caseCreationCard._oProductModel.setProperty("/rec",
                        productList.filter(item => this.caseCreationCard._oUserProfileInfoModel.getProperty("/recentProductList").includes(item.ModelNumber)));
                    //
                    this.caseCreationCard._oProductFunctionModel.setProperty("/allProductFunctions", data.productFunction);
                    this.caseCreationCard.setTextDescriptionModel("case_creation_issue_system_product_description","case_creation_issue_system_product_description_reminder");
                } else {
                    this.caseCreationCard.setTextDescriptionModel("case_creation_issue_system_component_description","case_creation_issue_system_component_description_reminder");
                }
                this.caseCreationCard.fragmentControllers.BasicInformationStep.handleProcessAfterSysSelection();
                this.caseCreationCard.swaServiceEvent.systemSelected("System (URL)", productList, "Step Basic Information");
            });
        }
    };
});

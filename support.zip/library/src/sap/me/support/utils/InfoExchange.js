sap.ui.define([
], function() {
    "use strict";
    if (!infoExchange) {
        var infoExchange = new Object();
    }
    if (!infoExchange._allItems) {
        infoExchange._allItems = new Map();
    }
    const allItems = infoExchange._allItems;
    infoExchange.initInfoExchange = function(OriginItem, exchangeSymbol) {
        allItems.set(exchangeSymbol, OriginItem);
    };

    infoExchange.getDataBySymbol = function(exchangeSymbol) {
        return allItems.get(exchangeSymbol);
    };

    /** ************************************************************************************** */
    /*                               Case Creation Handlers' Functions                        */
    /** ************************************************************************************** */

    // get current case creation step
    infoExchange.getCurrentIssueStep = function(exchangeSymbol) {
        return allItems.get(exchangeSymbol).fragmentControllers.BasicInformationStep.getFinishProgress();
    };

    infoExchange.showExitMessageBox = function(exchangeSymbol) {
        return allItems.get(exchangeSymbol).isSolvedProblemDialog();
    };

    // call the qualtrics exit survey when customer exits without creating a case
    infoExchange.showQualtricsExitSurvey = function(exchangeSymbol) {
        return allItems.get(exchangeSymbol).initFeedBackSurvey("SCENARIO2");
    };

    // cache router listener index
    infoExchange._routerEventIndex = undefined;

    /** ************************************************************************************** */
    /*                                Service Requests Functions                              */
    /** ************************************************************************************** */

    // for service requests card to cache status filter
    infoExchange.cacheServiceRequestStatusFilter = function(exchangeSymbol, statusFilter) {
        if (allItems.get("cacheStatusText")) {
            statusFilter.setSelectedKeys([allItems.get("cacheStatusText")]);
            statusFilter.fireSelectionChange();
            allItems.delete("cacheStatusText");
        }
        allItems.set(exchangeSymbol, statusFilter);
    };

    // for service requests overview card to cache status text and to operate service requests card status filter
    infoExchange.cacheStatusText = function(exchangeSymbol, Text) {
        if (allItems.get("serviceRequestStatusFilter")) {
            const statusFilter = allItems.get("serviceRequestStatusFilter");
            statusFilter.setSelectedKeys([Text]);
            statusFilter.fireSelectionChange();
        } else {
            allItems.set(exchangeSymbol, Text);
        }
    };

    return infoExchange;
});



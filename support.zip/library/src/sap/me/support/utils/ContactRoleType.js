sap.ui.define([], function() {

    "use strict";

    const oConstants = {
        REPORTER : "Reporter",
        CREATED_BY : "Created By",
        BUSINESS_USER : "Business User",
        PRIMARY_CONTACT : "Primary Contact",
        SECONDARY_CONTACT : "Secondary Contact",
        SYSTEM_OPENER : "System Opener",
        INCIDENT_CONTACT : "Incident Contact",
        KEY_USER : "Key User",
    };

    return Object.freeze(oConstants);

});

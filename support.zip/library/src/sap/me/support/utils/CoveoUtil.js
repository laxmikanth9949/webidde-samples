// Document: https://wiki.one.int.sap/wiki/pages/viewpage.action?spaceKey=MTH&title=Coveo+Get+Support+POC+Setup
sap.ui.define([
    "sap/ui/base/Object",
    "sap/me/shared/util/getCoveoEngine",
    "jquery.sap.global",
    "sap/ui/dom/includeScript",
    "sap/me/shared/FeatureToggles",
    "sap/me/support/utils/CreationHelper",
    "sap/base/Log",
    "sap/me/shared/util/getAdobeSessionId",
    "sap/me/shared/util/getAdobeVisitorId",
    "sap/me/shared/util/getApplicationInstanceId",
    "sap/me/shared/util/getBrowserTabId",

], function(BaseObject, CoveoEngine, jQuery, includeScript, FeatureToggles, CreationHelper, Log, getAdobeSessionId, getAdobeVisitorId, getApplicationInstanceId, getBrowserTabId) {
    return BaseObject.extend("sap.me.support.utils.CoveoUtil", {
        constructor: function(oCard) {
            this.oCard = oCard;
            this.coveoAnalyticsEnable = this.isCoveoAnalyticsEnabled();
        },

        isCoveoAnalyticsEnabled: function() {
            try {
                return window["_satellite"]?.getVar("isConsentEnabled")("usageanalytics.coveo.com", 1);
            } catch (e) {
                return false;
            }
        },

        sendCoveoAnalytics: function(event, type, meta, include_case_meta = false, setupData = {}) {
            try {
                if (!this.coveoAnalyticsEnable) {
                    return;
                }
                this.setCoveoContext(this.coveoContext, true);

                let selectedPartnerType = this.getSelectedPartnerType();
                let adobeSessionID = getAdobeSessionId();
                let adobeVisitorID = getAdobeVisitorId();
                let appInstanceID = getApplicationInstanceId("coveo");
                let browserTabID = getBrowserTabId();

                const {logCustomEvent} = CoveoHeadless.loadGenericAnalyticsActions(this.oCard.searchEngine);
                let payload_meta = {
                    case_sim_cat_knowledge: meta?.SimCatKnowledgePressedItem,
                    case_ism_knowledge_pressed: meta?.ISMKnowledgePressedItem ,
                    case_sac_knowledge_pressed: meta?.SACKnowledgePressedItem,
                    case_exit_solve_problem:meta?.isSolveProblem,

                    context_selectedPartnerType: selectedPartnerType,
                    context_adobeSessionID: adobeSessionID,
                    context_adobeVisitorID: adobeVisitorID,
                    context_appInstanceID: appInstanceID,
                    context_browserTabID: browserTabID,
                };

                for (let context in this.oUserContext) {
                    payload_meta["context_" + context] = this.oUserContext[context];
                }

                if (include_case_meta) {
                    Object.assign(payload_meta, {
                        context_case_id: meta?.pointer,
                        case_component: setupData.component.info ? setupData.component.info.CompName : "",
                        case_priority: setupData.priority.value,
                        case_product_function_display_name: setupData.productFunction.info ? setupData.productFunction.info.DisplayName : "",
                        case_product_function_full_name: setupData.productFunction.info ? setupData.productFunction.info.FullName : ""
                    });
                }
                const payload = {
                    evt: event,
                    type: type,
                    meta: payload_meta
                };

                this.oCard.searchEngine.dispatch(logCustomEvent(payload));
            } catch (err) {
                Log.error(
                    err
                );
            }
        },

        initCoveoSearch: function() {
            this.getUserContext().then(oResponse => {
                if (oResponse) {
                    this.oUserContext = this.buildUserContext(oResponse);
                }

                CoveoEngine("get support").then(engine => {
                    if (engine) {
                        this.oCard.searchEngine = engine;
                        this.buildSearchBox();
                        this.buildResultList();
                        this.coveoContext = this.buildCoveoContext();
                        this.setCoveoContext(this.coveoContext);
                        this.buildConfigurationAction();
                        this.buildFieldFilterAction();
                        this.parameterManager = this.buildParameterManager();
                    }
                });
            },e => console.log(e));

        },

        buildSearchBox: function() {
            const searchBoxOptions = {
                id: "main-searchBox",
            };
            this.searchBox = CoveoHeadless.buildSearchBox(this.oCard.searchEngine, {
                options: searchBoxOptions
            });
        },

        buildResultList: function() {
            if (!FeatureToggles.get("feature-support-coveo-search")) {
                return;
            }
            this.resultList = CoveoHeadless.buildResultList(this.oCard.searchEngine);
            CoveoHeadless.buildResultsPerPage(this.oCard.searchEngine, {
                initialState: {
                    numberOfResults: 5
                }
            });
            this.resultList.subscribe(() => {
                const oEngine = this.oCard.searchEngine?.state;

                if (!oEngine.search.isLoading && this.oContext?.short_description != "") {
                    const coveoResponse = oEngine.search?.response;
                    let hotTag = {};
                    // if (!coveoResponse.results?.length) {
                    //     this.oCard.getModel("coveoRecommendationList").setProperty("/isShow", this.oCard.getModel("hotAndTrendingList").getProperty("/isShow"));
                    //     this.oCard.getModel("coveoRecommendationList").setProperty("/all", this.oCard.getModel("hotAndTrendingList").getProperty("/all"));
                    // } else {
                    const data = coveoResponse.results.map((r, i) => {
                        if (r.raw.mh_id && r.raw.mh_id == oEngine.context?.contextValues.mh_id) {
                            hotTag = {tag: "Hot"};
                        } else {
                            hotTag = {tag: ""};
                        }
                        let tags = [];
                        tags.push(hotTag);
                        return {
                            raw: r,
                            __metadata:
                                {
                                    id: r.uri,
                                    uri: r.uri,
                                    type: r.raw.mh_type?.[0]
                                },
                            UseCaseID: "S4MSupportCreate",
                            ModelNumber: "",
                            ComponentKey: "",
                            ComponentName: r.raw.mh_app_component?.[0],
                            SystemNumber: "",
                            URL: r.uri,
                            Title: r.title,
                            Summary: r.excerpt,
                            Category: r.raw.documenttype,
                            KMNumber: "",
                            Domain: r.raw.documenttype,
                            SortOrder: i,
                            Score: "0",
                            Type: r.raw.mh_type?.[0],
                            Subtype: "",
                            Tag: tags
                        };
                    });
                    this.oCard.getModel("coveoRecommendationList").setProperty("/isShow",true);
                    this.oCard.getModel("coveoRecommendationList").setProperty("/all",data);
                    // }
                }
            });
        },

        buildCoveoContext: function() {
            return CoveoHeadless.buildContext(this.oCard.searchEngine);
        },

        setCoveoContext: function(oCoveoContext, isCustomEvent = false) {
            if (!oCoveoContext) {
                return;
            }
            if (isCustomEvent) {
                oCoveoContext.set({});
                return;
            }
            const shortDescription = this.oCard.fragmentControllers?.BasicInformationStep?.data?.shortDesc;
            const product = this.oCard.fragmentControllers?.BasicInformationStep?.data?.product?.info;
            const productFn = this.oCard.fragmentControllers?.BasicInformationStep?.data?.productFunction?.info;

            const component = this.oCard.fragmentControllers?.BasicInformationStep?.data?.component?.info;
            const hotAndTrending = this.oCard.getModel("hotAndTrendingList").getProperty("/all");
            const hotArticles = hotAndTrending.find(a => a.Tag.includes("Hot") && a.KMNumber);
            const selectedPartnerType = this.getSelectedPartnerType();
            const adobeSessionID = getAdobeSessionId();
            const adobeVisitorID = getAdobeVisitorId();
            const appInstanceID = getApplicationInstanceId("coveo");
            const browserTabID = getBrowserTabId();

            let caseContext = {
                short_description: shortDescription,
                product: product?.Name,
                product_function: productFn?.DisplayName,
                component: component?.CompName,
                mh_id: hotArticles?.KMNumber.replace(/^0*/g, ""),
                selectedPartnerType: selectedPartnerType,
                adobeSessionID: adobeSessionID,
                adobeVisitorID: adobeVisitorID,
                appInstanceID: appInstanceID,
                browserTabID: browserTabID,
            };
            oCoveoContext.set(Object.assign(caseContext, this.oUserContext));
        },

        getUserContext: function() {
            return Promise.resolve(jQuery.getJSON("/backend/raw/coveo/UserContext"));
        },

        buildUserContext: function(oResponse) {
            let oUserContext = {};
            const sInitialLetter = oResponse.userBaseConfig?.initialLetter;
            sInitialLetter && (oUserContext.initialLetter = sInitialLetter);
            const sUserLanguage = oResponse.userBaseConfig?.userLanguage;
            sUserLanguage && (oUserContext.userLanguage = sUserLanguage);
            const customer = oResponse.userBaseConfig?.customer;
            customer && (oUserContext.customer = customer);
            const bPartner = oResponse.userBaseConfig?.partner;
            typeof bPartner === "boolean" && (oUserContext.partner = bPartner);

            return oUserContext;
        },

        getSelectedPartnerType: function() {
            if (this.oUserContext.partner) {
                if (CreationHelper.selectedCustomerIsSupported()) {
                    return "VARD";
                } else if (CreationHelper.selectedCustomerIsServiced()) {
                    return "SPU";
                } 
                return;
                
            }
        },

        buildConfigurationAction: function() {
            const ConfigurationActionCreators = CoveoHeadless.loadConfigurationActions(this.oCard.searchEngine);
            const action = ConfigurationActionCreators.updateAnalyticsConfiguration({
                originContext: "CaseCreation"
            });
            this.oCard.searchEngine.dispatch(action);
        },

        buildFieldFilterAction: function() {
            const FieldActionCreators = CoveoHeadless.loadFieldActions(this.oCard.searchEngine);
            const action = FieldActionCreators.registerFieldsToInclude(["@foldingcollection","@foldingparent","@foldingchild","source","mh_id","documenttype","mh_product","mh_product_function","mh_app_component","mh_description","author","language","filetype","mh_tag","mh_alt_url","mh_best_answer","mh_category","mh_comments","mh_country","mh_created","mh_likes","mh_opened","mh_permissions","mh_priority","mh_product_category","mh_product_version","mh_released","mh_release_status","mh_responsible","mh_security_patch_day","mh_short_description","mh_software_component","mh_software_component_version","mh_source","mh_space","mh_subtitle","mh_support_package","mh_system","mh_updated","mh_views","mh_flagged_documents","urihash","collection","date","outlookformacuri","outlookuri","connectortype","mh_other_documents","uri","objecttype","permanentid"]);
            this.oCard.searchEngine.dispatch(action);
        },

        buildParameterManager: function() {
            return CoveoHeadless.buildSearchParameterManager(this.oCard.searchEngine, {initialState: {parameters: {}}});
        },

        coveoSearch: function() {
            this.setCoveoContext(this.coveoContext);
            // this.searchBox.updateText(sValue | "");
            this.searchBox?.submit();
        },

        trackClickEvent: function(sValue) {
            this.setCoveoContext(this.coveoContext);
            const props = {options: {result: sValue}};
            CoveoHeadless.buildInteractiveResult(this.oCard.searchEngine, props).select();
        },

    });
});

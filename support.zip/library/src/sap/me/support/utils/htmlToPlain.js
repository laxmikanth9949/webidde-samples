sap.ui.define([
    "../library",
], function(library) {
    /**
     * @param {!Number} level
     * @returns {!String}
     */
    function indent(level) {
        if (level < 0) {
            return "";
        }

        return "\t".repeat(level);
    }

    /**
     * @param {!Number} level
     * @returns {!String}
     */
    function newline(level) {
        return `\n${indent(level)}`;
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processNodeToPlain(node, indentLevel) {
        if (node.nodeType === Node.TEXT_NODE) {
            return ` ${node.nodeValue.trim()} `;
        }

        if (node.nodeType !== Node.ELEMENT_NODE) {
            return "";
        }

        switch (node.nodeName) {
            case "A":
                return processAnchorNode(node, indentLevel);
            case "ABBR":
                return processAbbrNode(node, indentLevel);
            case "BR":
            case "P":
            case "PRE":
                return processBlockNode(node, indentLevel);
            case "LI":
            case "DD":
                return processListItemNode(node, indentLevel, "*");
            case "DT":
                return processDTNode(node, indentLevel);
            case "BLOCKQUOTE":
                return processBlockquoteNode(node, indentLevel);
            case "H1":
                return processHeadingNode(node, indentLevel, "#", 1);
            case "H2":
                return processHeadingNode(node, indentLevel, "#", 2);
            case "H3":
                return processHeadingNode(node, indentLevel, "#", 3);
            case "H4":
                return processHeadingNode(node, indentLevel, "#", 4);
            case "H5":
                return processHeadingNode(node, indentLevel, "#", 5);
            case "H6":
                return processHeadingNode(node, indentLevel, "#", 6);
            case "CODE":
            case "EM":
            case "CITE":
            case "STRONG":
            case "SPAN":
            case "U":
                return processInlineNode(node, indentLevel);
            case "UL":
            case "OL":
            case "DL":
                return processListNode(node, indentLevel);
            default:
                return "";
        }
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processNodeSiblings(node, indentLevel) {
        return Array
            .from(node.childNodes.values())
            .map((node) => processNodeToPlain(node, indentLevel))
            .join("");
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @param {!String} delimiter
     * @param {!Number} delimiterCount
     * @returns {!String} plain text
     */
    function processHeadingNode(node, indentLevel, delimiter, delimiterCount) {
        const heading = processNodeSiblings(node, indentLevel);
        return heading.trim().length !== 0 ? `${newline(indentLevel)}${delimiter.repeat(delimiterCount)}${heading}${newline(indentLevel)}` : newline(indentLevel);
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processDTNode(node, indentLevel) {
        const newLevel = Math.max(0, indentLevel - 1);
        return `${newline(newLevel)}${processNodeSiblings(node, newLevel)}${newline(indentLevel)}`;
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processBlockNode(node, indentLevel) {
        return `${newline(indentLevel)}${processNodeSiblings(node, indentLevel)}${newline(indentLevel)}`;
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processInlineNode(node, indentLevel) {
        return `${indent(indentLevel)}${processNodeSiblings(node, indentLevel)}`;
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processListNode(node, indentLevel) {
        const newLevel = indentLevel + 1;
        return `${newline(newLevel)}${processNodeSiblings(node, newLevel)}${newline(indentLevel)}`;
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @param {!String} delimiter
     * @returns {!String} plain text
     */
    function processListItemNode(node, indentLevel, delimiter) {
        return `${newline(indentLevel)}${delimiter}${processNodeSiblings(node, indentLevel)}${newline(indentLevel)}`;
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processBlockquoteNode(node, indentLevel) {
        const newLevel = indentLevel + 1;
        return `${newline(newLevel)}${processNodeSiblings(node, newLevel)}${newline(indentLevel)}`;
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processAnchorNode(node, indentLevel) {
        const inner = processNodeSiblings(node, indentLevel).trim();
        const href = (node.getAttribute("href") || "").trim();

        if (inner.length === 0 && href.length === 0) {
            return "";
        }

        if (inner.length === 0) {
            return `${indent(indentLevel)}${href}`;
        }

        if (href.length === 0) {
            return `${indent(indentLevel)}${inner}`;
        }

        return `${indent(indentLevel)}${inner} (${href})`;
    }

    /**
     * @param {!Node} node
     * @param {!Number} indentLevel
     * @returns {!String} plain text
     */
    function processAbbrNode(node, indentLevel) {
        const inner = processNodeSiblings(node, indentLevel).trim();
        const title = (node.getAttribute("title") || "").trim();

        if (inner.length === 0) {
            return "";
        }

        if (inner.length === 0 && title.length === 0) {
            return "";
        }

        if (title.length === 0) {
            return `${indent(indentLevel)}${inner}`;
        }

        return `${indent(indentLevel)}${inner} (${title})`;
    }

    /**
     * @param {!String} plain text to cleanup plain
     * @returns {!String}
     */
    function normalize(plain) {
        return plain
            .trimEnd()
            .replace(/^\s*\n(.*)/g, "$1") // remove leading whitespace before the first newline
            .replace(/\n\s*\n/g, "\n") // no 2 consecutive line breaks
            .replace(/^(.*?)\s*$/gm, "$1") // no line trailing whitespace
            .replace(/^(\t*) \s*(.*)$/gm, "$1$2") // no leading user whitespace
            .replace(/(\S)[\t ]+(\S)/gm, "$1 $2"); // remove multiple tabs and spaces between words
    }

    /**
     * Acceptable tags
     *   a, abbr, blockquote, br, cite, code,
     *   em, h1, h2, h3, h4, h5, h6, p, pre,
     *   strong, span, u, dl, dt, dd, ul, ol, li
     *
     * @param {!String} html
     * @returns {!String} plain text
     */
    function convert(html) {
        if (typeof html !== "string") {
            return "";
        }

        const rootElement = document.createElement("DIV");
        rootElement.innerHTML = html;

        return normalize(processNodeSiblings(rootElement, 0));
    }

    return {convert, normalize};
});

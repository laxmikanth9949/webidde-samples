
sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/routing/Router"
], function(
    BaseObject,
    Router,
) {

    const Helper = BaseObject.extend("sap.me.support.utils.RouterHelper", {

        navToCreationDashboard(sDraftCasePointer) {
            const name = "createIssue";
            const params = {
                // when no pointer given, it should be an new case with pointer "0", otherwise it should be a draft case
                draftCasePointer: sDraftCasePointer ? sDraftCasePointer : "0",
                section: "overview"
            };
            if (sDraftCasePointer) {
                Router.getRouter("shellRouter").navTo(name, params, null, true);
            } else {
                Router.getRouter("shellRouter").navTo(name, params);
            }
        },

    });
    if (!Helper.prototype.instance) {
        Helper.prototype.instance = new Helper();
    }
    return Helper.prototype.instance;
});

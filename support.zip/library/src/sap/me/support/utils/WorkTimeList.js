sap.ui.define([], function() {

    "use strict";

    let oWorkTimes = [[
        {value: "00:00", key: "0"},
        {value: "01:00", key: "1"},
        {value: "02:00", key: "2"},
        {value: "03:00", key: "3"},
        {value: "04:00", key: "4"},
        {value: "05:00", key: "5"},
        {value: "06:00", key: "6"},
        {value: "07:00", key: "7"},
        {value: "08:00", key: "8"},
        {value: "09:00", key: "9"},
        {value: "10:00", key: "10"},
        {value: "11:00", key: "11"},
        {value: "12:00", key: "12"},
        {value: "13:00", key: "13"},
        {value: "14:00", key: "14"},
        {value: "15:00", key: "15"},
        {value: "16:00", key: "16"},
        {value: "17:00", key: "17"},
        {value: "18:00", key: "18"},
        {value: "19:00", key: "19"},
        {value: "20:00", key: "20"},
        {value: "21:00", key: "21"},
        {value: "22:00", key: "22"},
        {value: "23:00", key: "23"}],
    [
        {value: "12:00 am", key: "0"},
        {value: "01:00 am", key: "1"},
        {value: "02:00 am", key: "2"},
        {value: "03:00 am", key: "3"},
        {value: "04:00 am", key: "4"},
        {value: "05:00 am", key: "5"},
        {value: "06:00 am", key: "6"},
        {value: "07:00 am", key: "7"},
        {value: "08:00 am", key: "8"},
        {value: "09:00 am", key: "9"},
        {value: "10:00 am", key: "10"},
        {value: "11:00 am", key: "11"},
        {value: "12:00 pm", key: "12"},
        {value: "01:00 pm", key: "13"},
        {value: "02:00 pm", key: "14"},
        {value: "03:00 pm", key: "15"},
        {value: "04:00 pm", key: "16"},
        {value: "05:00 pm", key: "17"},
        {value: "06:00 pm", key: "18"},
        {value: "07:00 pm", key: "19"},
        {value: "08:00 pm", key: "20"},
        {value: "09:00 pm", key: "21"},
        {value: "10:00 pm", key: "22"},
        {value: "11:00 pm", key: "23"}]];

    return Object.freeze(oWorkTimes);

});

sap.ui.define([
    "sap/ui/base/Object"
], function(BaseObject) {

    /**
     * @class
     */
    const LongTextParser = BaseObject.extend("sap.me.support.utils.LongTextParser", {
        constructor: function(longText) {
            this.longText = longText;
            this.parseResult = {};
        }
    });

    LongTextParser.prototype.longText = "";
    LongTextParser.prototype.replacePattern = {
        "<div>": "",
        "</div>": "",
        "<br>": "<br />",
        "<br/>": "<br />",
        "</br>": "<br />"
    };

    /**
     * @typedef {'pf'|'sac'|'description'|'stepsToReproduce'|'noteToSAP'} BlockEnum
     */
    /**
     * [User selected] [product]: xxx ([Recommended]) => [tags] [name]: xxx ([flags])
     * [--- Description ---] => [blocks]
     * @type {{blocks: {sac: string, pf: string, description: string, noteToSAP: string, stepsToReproduce: string}, flags: {componentChange: string, pf: string, recommend: string, support: string, url: string}, tags: {prefill: string, userSelect: string}}}
     */
    LongTextParser.prototype.separator = {
        tags: {
            prefill: "Predicted",
            userSelect: "User selected",
        },
        flags: {
            support: "Support Assistant",
            componentChange: "Component Change",
            recommend: "Recommended",
            url: "URL",
            pf: "Product Function"
        },
        blocks: {
            pf: "-{3} Product/Function -{3}",
            aribaga: "-{3} Ariba Guided Answer -{3}",
            sac: "-{3} Support Assistant -{3}",
            description: "-{3} Description -{3}",
            stepsToReproduce: "-{3} Steps to Reproduce -{3}",
            tagID:"-{3} TagID/AreaID -{3}",
            noteToSAP: "\\*Note To SAP",
            issueTime: "-{3} Issue Date \\(UTC\\) -{3}",
            oldIssueTime: "Issue Date\\(UTC\\):",
        }
    };

    /**
     * TODO: parse the block content for future usage
     * @type {{component: {name: string, flags: string[], tags: string[]}, product: {name: string, flags: string[], tags: string[]}, pf: {name: string, flags: string[], tags: string[]}}}
     */
    LongTextParser.prototype.matcher = {
        component: {
            name: "component",
            tags: ["prefill", "userSelect", "normal"],
            flags: ["support", "recommend", "pf", "normal", "recent"]
        },
        product: {
            name: "product",
            tags: ["prefill", "userSelect", "normal"],
            flags: ["support", "recommend", "componentChange", "url", "normal", "recent", "recomemended&recent"]
        },
        pf: {
            name: "product function",
            tags: ["prefill", "userSelect", "normal"],
            flags: ["support", "recommend", "componentChange", "url", "normal", "recent", "recomemended&recent"]
        },
        checkResult: {
            name: "Entitlement check text: "
        }
    };

    /**
     * clean the data from server, raw data is: <div>xxxx<br /> xxxx <br> ..... </div>
     * @return {string}
     * @private
     */
    LongTextParser.prototype._clearText = function() {
        let cleanText = new DOMParser().parseFromString(this.longText, "text/html").documentElement.textContent;
        for (let i = 0; i <= 3; i++) {
            cleanText = new DOMParser().parseFromString(cleanText, "text/html").body.innerHTML;
        }
        for (const replaceText in this.replacePattern) {
            const replaceValue = this.replacePattern[replaceText];
            const reg = new RegExp(replaceText, "g");
            cleanText = cleanText.replace(reg, replaceValue);
        }
        return cleanText;
    };

    /**
     * get the block type from the string, raw data is --- Description ---
     * @param str
     * @return {null|BlockEnum}
     * @private
     */
    LongTextParser.prototype._getBlocker = function(str) {
        for (const key in this.separator.blocks) {
            const blockFlag = this.separator.blocks[key];
            const reg = new RegExp(blockFlag.toLowerCase(), "g");
            if (reg.test(str.toLowerCase())) {
                return key;
            }
        }
        return null;
    };

    /**
     *
     * @param {string[]} parseArr
     * @return {Array<Array<string>>}
     * @private
     */
    LongTextParser.prototype._getBlockTextArr = function(parseArr) {
        const blockIndex = [];

        // handle different blocks e.g: --- Description ---
        for (let i = 0; i < parseArr.length; i++) {
            const blocker = this._getBlocker(parseArr[i]);
            if (blocker) {
                blockIndex.push(i);
            }
        }
        const blockTextArr = [];
        for (let i = 0; i < blockIndex.length; i++) {
            blockTextArr.push(parseArr.slice(blockIndex[i], blockIndex[i + 1]));
        }

        return blockTextArr;
    };

    /**
     *
     * @return {{sac?: string, pf?: string, description?: string, noteToSAP?: boolean, stepsToReproduce?: string, tagI?: object}}
     */
    LongTextParser.prototype.parse = function() {
        const cleanText = this._clearText();
        const parseArr = cleanText.split("<br />");
        const blockTextArr = this._getBlockTextArr(parseArr);

        // handle different blocks e.g: --- Description ---
        for (const blockText of blockTextArr) {
            this._parseBlocker(blockText);
        }
        return this.parseResult;
    };

    /**
     *
     * @return {[No predicted product...Predicted component: XX-PART-GKS-OCP (Product Function), Partner Handover:1]}
     */
    LongTextParser.prototype.parseCheckResultMatcher = function(pfText) {
        return pfText.split(this.matcher.checkResult.name);
    };

    LongTextParser.prototype.parseResult = {};

    /**
     * handle different blocks e.g: --- Description ---
     * @param {string[]} blockerArr
     * @private
     */
    LongTextParser.prototype._parseBlocker = function(blockerArr) {
        const type = this._getBlocker(blockerArr[0]);
        switch (type) {
            case "noteToSAP":
                this.parseResult[type] = true;
                break;
            case "pf":
                // extract entitlment
                const pfValue = blockerArr.slice(1).join("<br />");
                const memoResult = this.parseCheckResultMatcher(pfValue);
                this.parseResult["pf"] = memoResult[0];
                if(memoResult.length > 1) {
                    this.parseResult["checkResult"] = memoResult[1];
                }
                break;
            case "sac":
            case "description":
            case "stepsToReproduce":
            case "aribaga":
                const value = blockerArr.slice(1).join("<br />");
                this.parseResult[type] = value;
                break;
            case "issueTime":
                this.parseResult[type] = blockerArr.slice(1)[0];
                break;
            case "tagID":
                const tagId = blockerArr.slice(1)[0] = "TagID: " ? "" : blockerArr.slice(1)[0];
                const areaId = blockerArr.slice(1)[1] = "AreaID: " ? "" : blockerArr.slice(1)[1];
                const idObj = {tagID: tagId, areaID : areaId};
                this.parseResult[type] = idObj;
                break;
            case "oldIssueTime":
                // to support old format
                const issueTimeValue = blockerArr.slice(0)[0].substring(17);
                this.parseResult["issueTime"] = issueTimeValue;
                break;
        }
    };

    return LongTextParser;
});

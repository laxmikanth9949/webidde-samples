sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/me/support/fragments/CreateSelectCustomerDialog",
    "sap/me/support/fragments/CreateSelectSUserDialog",
    "sap/me/cards/model/models",
    "sap/me/support/cards/caseCreationCards/CaseCreationContactStep",
    "sap/me/support/model/formatter",
    "sap/ui/core/Fragment",
    "sap/me/support/utils/LongTextParser",
    "sap/me/support/utils/AaEPService"
], function(JSONModel, CustomerModel, SuserModel, models, CaseCreationContactStep, formatter, Fragment,LongTextParser, AaEPService) {

    const OpenDraftHelper = new Object();

    OpenDraftHelper.init = function(oCard) {
        // when first load, keep the oCreationCard cache here
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        this.oCreationCard = oCard;
        this.setUpDraftCase(this.oCreationCard.getContext()?.attributes.draftCasePointer);
        this.isSimulate = models.getUserModel().getData().simulatedUser ? true : false;
    };

    OpenDraftHelper.setUpDraftCase = function(sPointer) {
        if (sPointer !== "0") {
            this.pointer = sPointer;
            this.oCreationCard._oIssueInformationModel.setProperty("/pointer",sPointer);
            this.inputDraftCaseInfoInDetailPage();
        }
    };

    OpenDraftHelper.inputDraftCaseInfoInDetailPage = function() {
        this.getDataFromBackendService("CaseDetailsW7Verticle?isPass=Y&pointer=" + this.pointer).then(data => {
            this.basicInfoData = data;
            if (this.basicInfoData.DraftFlag !== "X" || (this.isSimulate && this.basicInfoData.DssClassified === "X")) {
                // todo when the current case is not a draft case, maybe show something ?
                return;
            }
            this.setHeaderPartData();
            this.setUpDraftData();
        }).catch(() => {});
    };

    OpenDraftHelper.setHeaderPartData = function() {
        // reset the customer info via the Model's prototype function
        CustomerModel.prototype.setCustomerModel(new JSONModel({
            customerName:  this.basicInfoData.CustomerTxt,
            customerNum: this.basicInfoData.Customer,
        }));
        SuserModel.prototype.setSuserModel(new JSONModel({
            suserName: this.basicInfoData.ReporterTxt,
            suserNumber: this.basicInfoData.Reporter
        }));
        this.oCreationCard.selectedCutAndSuserInfo = {customerNum: this.basicInfoData.Customer, suserNumber: this.basicInfoData.Reporter};
        // reset the header part
        sap.ui.getCore().getEventBus().publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", "forbidHeaderChange");
    };

    OpenDraftHelper.setUpDraftData = async function() {
        this.setUpShortDescription();
        this.oCreationCard.fragmentControllers.BasicInformationStep.data.language = this.basicInfoData.Sprsl;
        this.oCreationCard._oIssueInformationModel.setProperty("/isDraftCase",true);
        await this.setUpSystemInfo();
        this.oCreationCard.currentCardPageView.setBusy(false);
        this.setDataProcessingAndClassifiedContent();
        this.setUpProductAndProductFunction();
        this.setUpPriorityAndBusinessImpact();
        this.setUpDetailInfoAndReproduceStep();
        this.setUpContacts();
        this.setUpAttachments().then(() => {
            // if is a aaep draft
            if (this.basicInfoData.AaEPDraftFlag && this.basicInfoData.AaEPQuesStatus === "UNRESOLVED") {
                this.oCreationCard.deleteDraft(this.oCreationCard.updateDraft.bind(this.oCreationCard));
            }
        });
    };

    OpenDraftHelper.setUpShortDescription = function() {
        this.oCreationCard.fragmentControllers.BasicInformationStep.data.shortDesc = formatter.replaceHtmlTagsInText(this.basicInfoData.Stext);
    };

    OpenDraftHelper.setUpSystemInfo = async function() {
        sap.ui.getCore().byId("BasicInformationStepFragment--sapMeCreationSystemInputControl").setEditable(false);
        this.oCreationCard.fragmentControllers.BasicInformationStep.data.system.info = {
            currentDisplayName: this.basicInfoData.SystemTxt,
            systemNumber: this.basicInfoData.SystemNumber,
            SystemNbr: this.basicInfoData.SystemNumber,
            installationNbr:this.basicInfoData.Installation,
            dataProcessRestriction: this.basicInfoData.DataProtection,
            SWType:this.basicInfoData.SWType || "",
            Swkla:this.basicInfoData.Swkla || "",
            SystemName: this.basicInfoData.SystemName || this.basicInfoData.SystemTxt || "",
            Uname: this.oCreationCard._oUserModel.getData().userName
        }
        this.oCreationCard.currentCardPageView.setBusy(true);
        await this.setUpSystemDetails();
    };

    OpenDraftHelper.setUpSystemDetails = async function() {
        const selectedSystem = this.oCreationCard.fragmentControllers.BasicInformationStep.data.system.info;
        this.oCreationCard.handleSystemInformationVisibility(true);
        this.oCreationCard.getInstallationData();
        this.oCreationCard._systemSelectDialog.systemSelectionInformationSetVisible();

        this.oCreationCard._systemSelectDialog.getRampUpFlag(selectedSystem.systemNumber);
        if (selectedSystem?.SWType === "ONPREM") {
            await this.oCreationCard._systemSelectDialog.setSystemText(selectedSystem);
        }
        await this.getSystemInfoInDraft().then(result => {
            this.oCreationCard._systemSelectDialog.setCloudSystemDetailVisible(!result.isSystemCloud);
            selectedSystem.leadingProduct = result.leadingProduct;
        });
        this.oCreationCard._systemSelectDialog.handleSelectedSystemData(selectedSystem);
        this.oCreationCard._systemSelectDialog.checkSystemAvailability();
    };

    OpenDraftHelper.getSystemInfoInDraft = async function() {
        const data = await jQuery.ajax(`/backend/odata/support/SystemSearch?$filter=systemNumber eq '${this.basicInfoData.SystemNumber}'&$format=json`, {
            method: "GET",
            contentType: "application/json",
            datatype: "json",
        });
        const [isSystemCloud, leadingProduct] = [data.value[0]?.isSystemCloud === "X", data.value[0]?.leadingProduct];
        this.setDataProcessgingRestrictionLabelinDraft(data.dataProcessRestriction || this.basicInfoData.DataProtection);
        return {isSystemCloud: isSystemCloud, leadingProduct: leadingProduct};
    };

    OpenDraftHelper.setDataProcessgingRestrictionLabelinDraft = function(dataProcessRestriction) {
        // set data processing
        if (dataProcessRestriction && dataProcessRestriction !== "NONE") {
            this.oCreationCard._oSystemInformationModel.setProperty("/isSystemDProcessRestrictionVisible", true);
            this.oCreationCard._oSystemInformationModel.setProperty("/sProcessRestrictionData", dataProcessRestriction);
        } else {
            this.oCreationCard._oSystemInformationModel.setProperty("/isSystemDProcessRestrictionVisible", false);
            this.oCreationCard._oSystemInformationModel.setProperty("/sProcessRestrictionData", "");
        }
    };

    OpenDraftHelper.setUpProductAndProductFunction = function() {
        // p or pf -> fetch all list and find match
        let ppmsid = this.basicInfoData.PPath_ID,
            productId = this.basicInfoData.ProductSelected;

        this.getDataFromBackendService(`CaseCreateProductAndProductFunctionW7?$filter=SystemNumber eq '${this.basicInfoData.SystemNumber}' and UseCaseID eq 'S4MSupportCreate'`).then(data => {
            // find the matched value from the all list, assign to the needed obj
            let productFunction = ppmsid ? data.productFunction.find(item => item.ModelNumber == ppmsid) : {};
            let product = productId ? data.product.find(item => item.ModelNumber == productId) : {}; 
    

            if (ppmsid || productId) {
                // if any p pf related info is valid, run the entitlement check
                const checkEntitledArr = [productFunction, product];
                let checkResult = {};
                checkEntitledArr.some(item => {
                    checkResult = this.oCreationCard.handleEntitlementCheck(item.CheckResult);
                    return true;
                });
                this.oCreationCard.checkResultTxt = this.oCreationCard.checkResultTxtStore;

                // if the p or pf is prevented on the entitlement check
                if(checkResult.prevent) {
                    if (ppmsid) {
                        this.oCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.visible = true;
                        this.showProductModel = "P&PF";
                    } else if (productId) {
                        this.oCreationCard.fragmentControllers.BasicInformationStep.data.component.visible = true;
                        this.showProductModel = "P&C";
                    }
                    this.oCreationCard.fragmentControllers.BasicInformationStep.data.product.visible = true;
                    this.setUpInitTableDataForProductAndProductFunction(productFunction, product);
                    return;
                };

                // if the entitlement check passed
                if (ppmsid) {
                    // shows product and product function
                    this.oCreationCard.fragmentControllers.BasicInformationStep.data.product.visible = true;
                    this.oCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.visible = true;
                    this.showProductModel = "P&PF";
                    this.oCreationCard.adobeProductFunctionSelectedType();
                    this.oCreationCard.trackProductFunctionChange("System (Draft)", productFunction);
                } else if (productId) {
                    // shows product and component
                    this.oCreationCard.fragmentControllers.BasicInformationStep.data.product.visible = true;
                    this.oCreationCard.fragmentControllers.BasicInformationStep.data.component.visible = true;
                    this.showProductModel = "P&C";
                };
            } else {
                // return nothing, just show the component info
                this.oCreationCard.fragmentControllers.BasicInformationStep.data.component.visible = true;
                this.showProductModel = "C";
            };

            this.oCreationCard.fragmentControllers.BasicInformationStep.data.product.info = product;
            this.oCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.info = productFunction;
    
            // there is always need to install component info
            const reg = /Component selected \(([\w ]+)\)/;
            const selectionMethod = reg.exec(this.basicInfoData.LastText);
            this.oCreationCard.fragmentControllers.BasicInformationStep.data.component.info = {
                CompName : this.basicInfoData.Component,
                CompKey : this.basicInfoData.CompKey,
                CompDesc : this.basicInfoData.ComponentTxt.substring(0,this.basicInfoData.ComponentTxt.indexOf("(" + this.basicInfoData.Component + ")")).trim(),
                selectionMethod : selectionMethod ? selectionMethod[1] : "Manual Selection",
                submitStepEventInfo : {systemAction:"Draft"}
            };
            this.oCreationCard.trackBasicInfoStepCChange("System (Draft)", this.basicInfoData.Component, undefined);
            
            // load the selection data in each Input control
            this.setUpInitTableDataForProductAndProductFunction(productFunction, product);
            this.oCreationCard.setCompAllNeedsModel();
            this.setUpTrendingColumn();
        });
    };

    OpenDraftHelper.setUpPriorityAndBusinessImpact = function() {
        const formattedBizImpact = this.formatHtmlText(this.basicInfoData.BusinessImpactTxt);
        this.oCreationCard.fragmentControllers.BasicInformationStep.data.priority.visible = true;
        this.oCreationCard.fragmentControllers.BasicInformationStep.data.priority.value = this.basicInfoData.Priority;
        this.oCreationCard._oIssueInformationModel.setProperty("/impactText",formattedBizImpact);

        // setup for PriorityAndImpact controller
        this.oCreationCard._oPriorityAndImpactCreateController.reConstructFragment(new JSONModel({
            pointer: this.pointer,
            priority: this.basicInfoData.PriorityTxt,
            impactText: formattedBizImpact
        }));

        if (this.basicInfoData.BusinessImpactTxt) {
            // Very High or High should show the business impact text
            this.oCreationCard._oPriorityAndImpactCreateController.createRichTextEditor();
            this.oCreationCard._oPriorityAndImpactCreateController.setImpactVisibility(true);
        } else {
            this.oCreationCard._oPriorityAndImpactCreateController.setImpactVisibility(false);
        }

        // Very High should show contact
        this.oCreationCard._oPriorityAndImpactCreateController.setContactVisibility("1" === this.basicInfoData.Priority);
    };

    OpenDraftHelper.setUpInitTableDataForProductAndProductFunction = async function(productFunction = null, product = null) {
        const basicInformation = this.oCreationCard.fragmentControllers.BasicInformationStep;
        let componentInfo;
        switch (this.showProductModel) {
            case "P&PF":
                await this.loadProductSelectData();
                this.loadProdFunctionSelectData();
                break;
            case "P&C":
                this.loadProductSelectData();
                this.loadComponentSelectData();
                break;
            case "C":
                // no need to load the component list
                await this.loadProductSelectData();
                this.loadProdFunctionSelectData();
                await this.loadComponentSelectData();
                componentInfo = this.oCreationCard._oComponentModel.getProperty("/all").find(item => item.CompName === this.basicInfoData.Component);
                break;
        };
        const prioLimit = productFunction?.DefaultCompPrioLimit || product?.DefaultCompPrioLimit || componentInfo?.PrioLimit || "";
        // For loading draft case, the first step is not completed for p/pf entitlement prevent or 100%
        basicInformation.updateTimelineProgress();
        this.oCreationCard._oContinueButtonModel.setProperty("/isContinueButtonEnabled", basicInformation.data.isProgressFinished);
        this.oCreationCard._oPriorityAndImpactCreateController.prioritySelectLimit(prioLimit);
    };

    OpenDraftHelper.loadProductSelectData = function() {
        return this.oCreationCard.getAllProductList(this.basicInfoData.SystemNumber).then(data => {
            // all list in productFrg model
            const productList = data.product;
            this.oCreationCard.getCard().setModel(this.oCreationCard._oProductModel = new JSONModel({
                allData: productList,
                productFilters: this.oCreationCard._systemSelectDialog.transferArrayToArraySet(productList, "DisplayName"),
                softerFilters: this.oCreationCard._systemSelectDialog.transferArrayToArraySet(productList, "SoftwareProduct"),
                relationshipTypeFilters: this.oCreationCard._systemSelectDialog.transferArrayToArraySet(productList, "RelationshipType"),
                rec: productList.filter(item =>
                    this.oCreationCard._oUserProfileInfoModel.getProperty("/recentProductList").includes(item.ModelNumber))
            }),"productList");
            this.oCreationCard._oProductFunctionModel.setProperty("/allProductFunctions", data.productFunction);
            this.oCreationCard.swaServiceEvent.systemSelected("System (Draft)", productList, "Step Basic Information");
        }).catch(() => {});
    };

    OpenDraftHelper.loadProdFunctionSelectData = function() {
        const productNumber = this.oCreationCard.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber;
        this.oCreationCard.getProductFunctionTree(productNumber);
        this.loadProductFunctionSuggestions();
    };

    OpenDraftHelper.loadProductFunctionSuggestions = function() {
        const productNumber = this.oCreationCard.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber;
        const listTypePFData = this.oCreationCard.fragmentControllers.BasicInformationStep.formatProductFunctionsToListType(productNumber);
        this.oCreationCard.productFunctionPredictor(productNumber, listTypePFData, "draft");
    };

    OpenDraftHelper.loadComponentSelectData = function() {
        const instNumber = this.basicInfoData.Installation;
        return this.getDataFromBackendService(`CaseCreateComponentW7?$filter=Category eq 'LEVEL1' and Installation eq '${instNumber}'&resultType=CompF4Help`).then(data => {
            this.oCreationCard._oComponentModel.setProperty("/all", data);
        }).catch(() => {});
    };

    OpenDraftHelper.setUpDetailInfoAndReproduceStep = function() {
        if (!this.basicInfoData.LastText) {
            this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.timeLineItem.completeRatePercentage = 0;
            this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.timeLineItem.completeRateText = "0/1";
            return;
        }

        // use longTextParser to parse longText
        let parseLongTextIntoObject = new LongTextParser(this.basicInfoData.LastText).parse();
        const detailModel = this.oCreationCard.getCard().getModel("$this.detailedInformation");
        if (Object.keys(parseLongTextIntoObject).length > 0) {
            if (parseLongTextIntoObject.sac) {
                detailModel.setProperty("/sacInfo/visible", true);
                detailModel.setProperty("/sacInfo/value", parseLongTextIntoObject.sac);
                this.oCreationCard.isSupportAssistantUsed = true;
            }
            this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.data.stepsToReproduce = parseLongTextIntoObject.stepsToReproduce;
            detailModel.setProperty("/isStepsToReproduceReminderSelected", parseLongTextIntoObject.noteToSAP);
            this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription = parseLongTextIntoObject.description;
            if (parseLongTextIntoObject.tagID) {
                detailModel.setProperty("/TagID", parseLongTextIntoObject.tagID.tagID);
                detailModel.setProperty("/AreaID", parseLongTextIntoObject.tagID.areaID);
            }
            this.oCreationCard._oSelectionMethodRecordsTxt = parseLongTextIntoObject.pf;
            // this.oCreationCard.checkResultTxt = parseLongTextIntoObject.checkResult || "";
            this.oCreationCard._draftPointer = this.pointer;
            this.oCreationCard._aribaGATxt = parseLongTextIntoObject.aribaga;
            if (parseLongTextIntoObject.issueTime) {
                // issueTime is a date or a date range
                let issueStartTime = "";
                let issueEndTime = "";
                if (parseLongTextIntoObject.issueTime.includes(" - ")) {
                    [issueStartTime, issueEndTime] = parseLongTextIntoObject.issueTime.split(" - ");
                } else {
                    issueStartTime = parseLongTextIntoObject.issueTime;
                }
                // for issue time is a utc time, transfer utc("2024-02-05T00:46:44Z") to local time
                const formatUTCDate2Local = (dateStr) => {
                    if (dateStr) {
                        const utcDate = dateStr.replace(" ", "T") + "Z";
                        return formatter.mediumDateFromUI5Date(utcDate, "yyyy/MM/dd HH:mm:ss", false);
                    }
                    return "";
                };
                detailModel.setProperty("/issueHappenedStartTime", formatUTCDate2Local(issueStartTime));
                detailModel.setProperty("/issueHappenedEndTime", formatUTCDate2Local(issueEndTime));
            }
        } else {
            // Create by launchpad side, do not have detail description and step to reproduce
            const desc = this.formatHtmlText(this.basicInfoData.LastText);
            this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription = desc;
        }


        // if no description, set the progress bar to 0/1 else to 1/1
        const detailedDescription = this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription;
        const currentStep = detailedDescription ? 1 : 0;
        this.setAaEPTranscriptText(detailModel);
        this.oCreationCard.getRecommendedSolutionList();
        this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.completeRatePercentage = currentStep / 1 * 100;
        this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.completeRateText = `${currentStep}/1`;
    };

    OpenDraftHelper.setAaEPTranscriptText = async function(detailModel) {
        const searchParams = new URLSearchParams(window.location.search);
        const sessionID = searchParams.get("aaepuuid");
        if (!sessionID) {
            return;
        }
        const aaEPService = new AaEPService(this.oCreationCard);
        const {AaEPMessageText} = await aaEPService.getChatDetailByQuesUUid(sessionID);
        if (!AaEPMessageText) {
            return;
        }
        this.oCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription += AaEPMessageText;
    };

    OpenDraftHelper.setUpContacts = function() {
        this.oCreationCard.fragmentControllers.CaseCreationContactStep.contactCreationController._constructorContactList();
    };

    OpenDraftHelper.setUpAttachments = function() {
        return this.getDataFromBackendService("CaseAttachmentsW7Verticle?isPass=Y&pointer=" + this.pointer).then(data => {
            if (data) {
                const attachmentsInfo = this.formatAttachmentInfo(data);
                this.oCreationCard.attachmentService.attachmentsInfo = attachmentsInfo;
                this.oCreationCard.fragmentControllers.CaseCreationAttachmentStep._fileDataModel.setProperty("/attachmentList", attachmentsInfo);
                this.oCreationCard.fragmentControllers.CaseCreationAttachmentStep.timeLineItem.fileText = `${attachmentsInfo.length} ${this._i18n.getText("case_creation_attachment_files")}`;
            }
        },() => {});
    };

    OpenDraftHelper.formatAttachmentInfo = function(aAttachments) {
        return aAttachments.map(e => {
            return {
                name : e.Filename,
                size : e.FilelengthTxt,
                description : this.formatAttachmentDesc(e.Text),
                pcdChecked: "X" === e.Cpocd,
                euDataChecked: "EUDP" === e.Dprest,
                cnDataChecked: "CNDP" === e.Dprest,
                fileType: e.Type,
                isDescriptionVisible: false,
                fileStatus: "uploaded",
                fileURL: e.Url,
                analysisStatus: 0
            };
        });
    };

    OpenDraftHelper.formatAttachmentDesc = function(sText) {
        // hidden default description (same with the function in CaseAttachmentsCard)
        // if it is default text, then clear it, in the submit step it would be reconstructed
        if (!sText
            || sText.toString().search((new RegExp("^[A-Z]\\d{10}\\s\\-\\s[1-9][0-2]*\\/[0-3][0-9]\\/[0-9]{4}\\,\\s[0-2]*[0-9]\\:[0-6][0-9]\\:[0-6][0-9]\\s[AP][M]$"))) === 0) {
            return "";
        }
        return sText;
    };

    /**
     * Use Dom Parser to parse html text
     * This function will remove div tags firstly and then format them
     * @param {string} sText
     * @returns {string}
     */
    OpenDraftHelper.formatHtmlText = function(sText) {
        sText = this.removeUnnecessaryDivTags(sText);
        return new DOMParser().parseFromString(sText, "text/html").documentElement.textContent;
    };

    /**
     * Remove div tags
     * Caution! This function will remove all div tags!!!
     * @param {string} str
     * @returns {string}
     */
    OpenDraftHelper.removeUnnecessaryDivTags = function(str) {
        const startTag = new RegExp("&lt;div>", "g");
        const endTag = new RegExp("&lt;/div>", "g");
        str = str.replace(startTag, "");
        str = str.replace(endTag, "");
        return str;
    };

    OpenDraftHelper.getDataFromBackendService = function(sPath) {
        return new Promise((resolve, reject) => {
            jQuery.ajax("/backend/raw/support/" + sPath, {
                method: "GET",
                contentType: "application/json"
            }).done((data) => {
                resolve(data);
            }).fail(() => {
                reject();
            });
        });
    };

    OpenDraftHelper.setDataProcessingAndClassifiedContent = function() {
        // the max length of systemNumber is 10
        const sysN = this.basicInfoData.SystemNumber;
        const sysNumber = sysN.substring(sysN.length - 10, sysN.length);
        this.getDataFromBackendService(`CaseMessageDSSW7Verticle?customerId=${this.basicInfoData.Customer}&installationNumber=${this.basicInfoData.Installation}&sysNumber=${sysNumber}`).then(data => {
            const DataProtection = this.basicInfoData.DataProtection;
            const hasNoDataProtection = DataProtection === "" || DataProtection === "NONE";
            // check DataProcessing And Classified show or not
            // this.oCreationCard._oSystemInformationModel.setProperty ("/SystemInformationVBox", !(!data.classifiedFlag && hasNoDataProtection));
            // check DataProcessing show or not
            this.oCreationCard._oSystemInformationModel.setProperty("/isSystemDProcessRestrictionVisible", !hasNoDataProtection);
            this.oCreationCard._oSystemInformationModel.setProperty("/sProcessRestrictionData", DataProtection);
            // check Classified show or not
            this.oCreationCard._oSystemInformationModel.setProperty("/isClassifiedContentButtonVisible", data.classifiedFlag);
            this.oCreationCard._oSystemInformationModel.setProperty("/isClassifiedContentButtonEnabled", false);
            this.oCreationCard.fragmentControllers.BasicInformationStep.data.dss_classified = this.basicInfoData.DssClassified === "X";

        }).catch(() => {});
    };

    OpenDraftHelper.setUpTrendingColumn = function() {
        const trendingModelNum = this.basicInfoData.PPath_ID || this.basicInfoData.ProductSelected || "";
        this.oCreationCard.getHotAndTrending(trendingModelNum, false, "TRUE");
    };

    return OpenDraftHelper;

},true);

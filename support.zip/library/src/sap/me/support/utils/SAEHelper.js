sap.ui.define([
    "sap/me/support/utils/DateTimeUtil",
    "sap/ui/core/LocaleData",
    "sap/ui/core/format/DateFormat"
], function(DateTimeUtil, LocaleData, DateFormat) {
    const _i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
    const _sResourceUri = sap.ui.require.toUrl("sap/me/support");
    const _oLocaleData = LocaleData.getInstance(sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale());
    // 09:00 - 12:00
    const morningTimeOptions = [
        {
            text: "09:00 - 09:30",
            startTime: "09:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "09:30 - 10:00",
            startTime: "09:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "10:00 - 10:30",
            startTime: "10:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "10:30 - 11:00",
            startTime: "10:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "11:00 - 11:30",
            startTime: "11:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "11:30 - 12:00",
            startTime: "11:30",
            isAvailable: false,
            value: "",
        }
    ];
    // 12:00 - 17:00
    const afternoonTimeOptions = [
        {
            text: "12:00 - 12:30",
            startTime: "12:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "12:30 - 13:00",
            startTime: "12:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "13:00 - 13:30",
            startTime: "13:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "13:30 - 14:00",
            startTime: "13:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "14:00 - 14:30",
            startTime: "14:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "14:30 - 15:00",
            startTime: "14:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "15:00 - 15:30",
            startTime: "15:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "15:30 - 16:00",
            startTime: "15:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "16:00 - 16:30",
            startTime: "16:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "16:30 - 17:00",
            startTime: "16:30",
            isAvailable: false,
            value: "",
        }
    ];
    // 17:00 - 21:00
    const eveningTimeOptions = [
        {
            text: "17:00 - 17:30",
            startTime: "17:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "17:30 - 18:00",
            startTime: "17:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "18:00 - 18:30",
            startTime: "18:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "18:30 - 19:00",
            startTime: "18:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "19:00 - 19:30",
            startTime: "19:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "19:30 - 20:00",
            startTime: "19:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "20:00 - 20:30",
            startTime: "20:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "20:30 - 21:00",
            startTime: "20:30",
            isAvailable: false,
            value: "",
        }
    ];

    // 09:00 - 12:00
    const samMorningTimeOptions = [
        {
            text: "09:00 - 09:15",
            startTime: "09:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "09:15 - 09:30",
            startTime: "09:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "09:30 - 09:45",
            startTime: "09:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "09:45 - 10:00",
            startTime: "09:45",
            isAvailable: false,
            value: "",
        },
        {
            text: "10:00 - 10:15",
            startTime: "10:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "10:15 - 10:30",
            startTime: "10:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "10:30 - 10:45",
            startTime: "10:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "10:45 - 11:00",
            startTime: "10:45",
            isAvailable: false,
            value: "",
        },
        {
            text: "11:00 - 11:15",
            startTime: "11:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "11:15 - 11:30",
            startTime: "11:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "11:30 - 11:45",
            startTime: "11:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "11:45 - 12:00",
            startTime: "11:45",
            isAvailable: false,
            value: "",
        }
    ];
    // 12:00 - 17:00
    const samAfternoonTimeOptions = [
        {
            text: "12:00 - 12:15",
            startTime: "12:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "12:15 - 12:30",
            startTime: "12:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "12:30 - 12:45",
            startTime: "12:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "12:45 - 13:00",
            startTime: "12:45",
            isAvailable: false,
            value: "",
        },
        {
            text: "13:00 - 13:15",
            startTime: "13:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "13:15 - 13:30",
            startTime: "13:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "13:30 - 13:45",
            startTime: "13:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "13:45 - 14:00",
            startTime: "13:45",
            isAvailable: false,
            value: "",
        },
        {
            text: "14:00 - 14:15",
            startTime: "14:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "14:15 - 14:30",
            startTime: "14:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "14:30 - 14:45",
            startTime: "14:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "14:45 - 15:00",
            startTime: "14:45",
            isAvailable: false,
            value: "",
        },
        {
            text: "15:00 - 15:15",
            startTime: "15:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "15:15 - 15:30",
            startTime: "15:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "15:30 - 16:00",
            startTime: "15:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "16:00 - 16:15",
            startTime: "16:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "16:15 - 16:30",
            startTime: "16:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "16:30 - 16:45",
            startTime: "16:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "16:45 - 17:00",
            startTime: "16:45",
            isAvailable: false,
            value: "",
        }
    ];
    // 17:00 - 21:00
    const samEveningTimeOptions = [
        {
            text: "17:00 - 17:15",
            startTime: "17:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "17:15 - 17:30",
            startTime: "17:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "17:30 - 17:45",
            startTime: "17:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "17:45 - 18:00",
            startTime: "17:45",
            isAvailable: false,
            value: "",
        },
        {
            text: "18:00 - 18:15",
            startTime: "18:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "18:15 - 18:30",
            startTime: "18:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "18:30 - 18:45",
            startTime: "18:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "18:45 - 19:00",
            startTime: "18:45",
            isAvailable: false,
            value: "",
        },
        {
            text: "19:00 - 19:15",
            startTime: "19:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "19:15 - 19:30",
            startTime: "19:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "19:30 - 19:45",
            startTime: "19:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "19:45 - 20:00",
            startTime: "19:45",
            isAvailable: false,
            value: "",
        },
        {
            text: "20:00 - 20:15",
            startTime: "20:00",
            isAvailable: false,
            value: "",
        },
        {
            text: "20:15 - 20:30",
            startTime: "20:15",
            isAvailable: false,
            value: "",
        },
        {
            text: "20:30 - 20:45",
            startTime: "20:30",
            isAvailable: false,
            value: "",
        },
        {
            text: "20:45 - 21:00",
            startTime: "20:45",
            isAvailable: false,
            value: "",
        }
    ];
    function getTimePeriodOptions(source) {
        return [
            {
                titleText: _i18n.getText("case_creation_appointment_info_morning_time"),
                subText: formatTimeTextByLocale("9:00 - 12:00"),
                icon: "morning.svg",
                selectedIcon: "morning_selected.svg",
                key: 0,
                timeList: source === "SAM" ? samMorningTimeOptions : morningTimeOptions
            },
            {
                titleText: _i18n.getText("case_creation_appointment_info_afternoon_time"),
                subText: formatTimeTextByLocale("12:00 - 17:00"),
                icon: "afternoon.svg",
                selectedIcon: "afternoon_selected.svg",
                key: 1,
                timeList: source === "SAM" ? samAfternoonTimeOptions : afternoonTimeOptions
            },
            {
                titleText: _i18n.getText("case_creation_appointment_info_evening_time"),
                subText: formatTimeTextByLocale("17:00 - 21:00"),
                icon: "evening.svg",
                selectedIcon: "evening_selected.svg",
                key: 2,
                timeList: source === "SAM" ? samEveningTimeOptions : eveningTimeOptions,
            }
        ];
    }

    function appointmentDateFormatter(sDate, formatPattern = "d") {
        return DateTimeUtil.parseFormatDateTime(sDate, {pattern: "yyyyMMdd"}, {pattern: formatPattern});
    }

    /**
     * first day of month will return true
     */
    function appointmentMonTextVisible(sDate) {
        return DateTimeUtil.parseFormatDateTime(sDate, {pattern: "yyyyMMdd"}, {pattern: "d"}) === "1";
    }

    /**
     * get available time list by checking if slots start time is in time list
     */
    function getAvailableTimeList(slots = [], timePeriodOptions) {
        return timePeriodOptions.map(function(item) {
            item.timeList = item.timeList.map(function(timeItem) {
                const findItem = slots.find(v => v.StartTime === timeItem.startTime);
                timeItem.isAvailable = !!findItem;
                timeItem.value = findItem ? findItem.TimeStamp : "";
                return timeItem;
            });
            return item;
        });
    }

    function getExpertCountText(count) {
        return `${count} ${count > 1 ? _i18n.getText("case_creation_appointment_info_expert_sessions") : _i18n.getText("case_creation_appointment_info_expert_session")}`;
    }

    function getManagerCountText(count) {
        return `${count} ${count > 1 ? _i18n.getText("case_creation_appointment_info_manager_sessions") : _i18n.getText("case_creation_appointment_info_manager_session")}`;
    }

    function appointmentTimeIconFormatter(selectedIndex, key, source) {
        if (!Number.isInteger(key)) {
            return "";
        }
        const timePeriodOptions = getTimePeriodOptions(source);
        const paths = key === selectedIndex ? timePeriodOptions[key].selectedIcon : timePeriodOptions[key].icon;
        return `${_sResourceUri}/resources/${paths}`;
    }

    function getDayIsAvailable(SLOTS) {
        const allOptions = morningTimeOptions.concat(afternoonTimeOptions, eveningTimeOptions);

        return SLOTS.some((slotItem) => {
            return allOptions.find(v => slotItem.StartTime === v.startTime);
        });
    }

    /**
     * Define a function to calculate milliseconds from a timezone string
     * UTC-13.75 means 13 hours and 45 minutes behind UTC
     * UTC+8 means 8 hours ahead of UTC
     * UTC+5.5 means 5 hours and 30 minutes ahead of UTC
     * @param {string} timezoneString eg: "UTC+8" "UTC-8" "UTC-13.45"
     * @returns {number} milliseconds offset base on utc
     */
    function calculateMillisecondsFromTimezone(timezoneString) {
        if (timezoneString === "UTC") {
            return 0;
        }
        // Split the timezone string into its sign, hours, and minutes components
        const matches = timezoneString?.match(/(UTC)([+-])(\d+)(?:\.(\d+))?/);
        const sign = matches[2];
        const hours = parseInt(matches[3]);
        let minPercent = matches[4] ? parseFloat(matches[4]) : 0;
        if (minPercent < 10) {
            minPercent = minPercent * 10;
        }
        const minutes = (minPercent / 100) * 60;

        // Calculate the milliseconds offset based on the sign, hours, and minutes
        const timezoneOffset = ((hours * 60) + minutes) * 60 * 1000;
        const totalOffset = sign === "+" ? -timezoneOffset : timezoneOffset;

        return totalOffset;
    }


    /**
     * we need to convert service timezone (base on user profile setting) to user browser timezone (base on user machine)
     * @param {Array} dayList sae available time
     * @param {string} timezoneString eg: "UTC+8" "UTC-8" "UTC-13.45"
     * @returns SAE available DayList base on user browser timezone
     */
    function formatTimeToLocalTimezone(dayList, timezoneString) {
        if (!Array.isArray(dayList)) {
            return [];
        }

        const allTimeItems = [];
        const oDateFormatUTC = DateFormat.getDateTimeWithTimezoneInstance({pattern: "yyyyMMdd,HH:mm"});
        const oDateFormatDay = DateFormat.getDateTimeInstance({pattern: "yyyyMMdd"});
        const oDateFormatTime = DateFormat.getDateTimeInstance({pattern: "HH:mm"});
        const oDateFormatWeekDay = DateFormat.getDateTimeInstance({pattern: "EE"});

        for (const dayItem of dayList) {
            const sDate = dayItem.Date;
            dayItem.SLOTS.map((slotItem) => {
                const timestamp = oDateFormatUTC.parse(`${sDate},${slotItem.StartTime}`, "UTC")[0].getTime() + calculateMillisecondsFromTimezone(timezoneString);
                const oLocalDate = new Date(timestamp);

                allTimeItems.push({
                    StartTime: oDateFormatTime.format(oLocalDate),
                    TimeStamp: slotItem.TimeStamp,
                    Date: oDateFormatDay.format(oLocalDate),
                    Timezone: slotItem.Timezone,
                    WeekDay: oDateFormatWeekDay.format(oLocalDate),
                });
            });
        }

        const newDayList = dayList.map(v => ({...v, SLOTS: []}));

        for (const timeItem of allTimeItems) {

            const findItem = newDayList.find(v => v.Date === timeItem.Date);
            if (findItem) {
                findItem.SLOTS.push(timeItem);
            } else {
                newDayList.push({
                    Date: timeItem.Date,
                    WeekDay: timeItem.WeekDay,
                    SLOTS: [timeItem]
                });
            }
        }
        const result = newDayList.map(v => ({...v, isAvailable: getDayIsAvailable(v.SLOTS)})).slice(0, 10);
        const isTotalAvailable = result.filter(v => v.isAvailable)?.length !== 0;

        return {result, isTotalAvailable};
    }

    /**
     * format time text by user preference, 24h or 12h
     * @param {string} timeText
     */
    function formatTimeTextByLocale(timeText) {
        const oDateFormatTime = DateFormat.getDateTimeInstance({pattern: "HH:mm"});
        const oLocalTimeFormat = DateFormat.getDateTimeInstance({pattern:  _oLocaleData.getTimePattern("short")});
        const textArr = timeText.split(" - ");

        return `${oLocalTimeFormat.format(oDateFormatTime.parse(textArr[0]))} - ${oLocalTimeFormat.format(oDateFormatTime.parse(textArr[1]))}`;
    }

    return {
        getTimePeriodOptions,
        appointmentDateFormatter,
        appointmentMonTextVisible,
        getExpertCountText,
        getManagerCountText,
        appointmentTimeIconFormatter,
        formatTimeToLocalTimezone,
        getAvailableTimeList,
        calculateMillisecondsFromTimezone,
        formatTimeTextByLocale
    };
});

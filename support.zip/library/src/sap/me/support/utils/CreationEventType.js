sap.ui.define([], function() {

    "use strict";

    const oConstants = {
        SAP_HANA_CLOUD_PRODUCT_CHANGE : "SAPHanaCloudProductChange",
        SUPPORTED_USER_CHANGE : "supportedUserChange",
    };

    return Object.freeze(oConstants);

});

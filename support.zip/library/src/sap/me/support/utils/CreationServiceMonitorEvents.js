sap.ui.define([
    "sap/me/support/utils/helper",
    "sap/me/support/model/formatter"
], function(helper,formatter) {

    let events = new Object();

    events.eventName = {
        CaseCreationStart: "CaseCreationStart",
        CaseCreationExit: "CaseCreationExit",
        ExitDialogReply: "ExitDialogReply",
        ProductPredictedHasValue: "ProductPredictedHasValue",
        ProductPredictedNoValue: "ProductPredictedNoValue",
        ProductValueChanged: "ProductChanged",
        ProductFunctionPredictedHasValue: "ProductFunctionPredictedHasValue",
        ProductFunctionPredictedNoValue: "ProductFunctionPredictedNoValue",
        ProductFunctionValueChanged: "ProductFunctionChanged",
        ChannelsSuggestedList: "ChannelsSuggestedList",
        ChannelsSuggestedPressed: "ChannelsSuggestedPressed",
        DetailedDescriptionChanged: "DetailedDescriptionChanged",
        SimCatKnowledgeEntries: "SimCatKnowledgeEntries",
        SimCatKnowledgePressed: "SimCatKnowledgePressed",
        ISMKnowledgePressed: "ISMKnowledgePressed",
        TopSuggestionPressed: "TopSuggestionPressed",
        AlternativeChannelList: "AlternativeChannelList",
        AlternativeChannelPressed: "AlternativeChannelPressed",
        SubmitCase: "SubmitCase",
        ATLDialogOpen: "ATLDialogOpen",
        ATLSubscribePressed: "ATLSubscribePressed",
        ATLCaseCreationPressed: "ATLCaseCreationPressed",
        ATLReturnToDashboard: "ATLReturnToDashboard",
        CriticalKBADialogOpen: "CriticalKBADialogOpen",
        CriticalKBADialogClick: "CriticalKBADialogClick",
        CriticalKBADialogSubscribe: "CriticalKBADialogSubscribe",
        CriticalKBADialogOK: "CriticalKBADialogOK",
        ExpertChatCreateCase: "ExpertChatCreateCase",
        ExpertChatCancel: "ExpertChatCancel",
        ConnectToExpert: "ConnectToExpert",
        ValueHelperRecommendations: "ValueHelperRecommendations",
        GuidedAnswerPresentation: "GuidedAnswerPresentation",
        GuidedAnswerEngaged: "GuidedAnswerEngaged",
        GuidedAnswerSolved: "GuidedAnswerSolved",
        GuidedAnswerCase: "GuidedAnswerCase",
        BasicInfoStepDeterminedComponent : "BasicInfoStepDeterminedComponent",
        SubmitStepDeterminedComponent : "SubmitStepDeterminedComponent",
        AaepStart: "AaepStart",
        SubmitCaseError: "SubmitCaseError",
        BookAnAppointment: "BookAnAppointment",
        NoSuitableAppointments: "NoSuitableAppointments",
        SystemSelected: "SystemSelected",
        SLASave: "SLASave",
        SLASolutionClicked: "SLASolutionClicked",
        SLAAnalyzeFilesCompleted : "SLAAnalyzeFilesCompleted",
        SLASuggestedFiles: "SLASuggestedFiles",
        SLAAttachFiles: "SLAAttachFiles",
        SANodeClicked: "SANodeClicked",
        PriorityChanged: "PriorityChanged",
        SANodeDisplayed: "SANodeDisplayed",
        DraftSaved: "DraftSaved"
    };

    events.eventType = {
        Click: "Click",
        System: "System",
        Input: "Input",
        Error: "Error",
    };

    events.initConfig = function(oCard) {
        this.swaService = oCard.swaService;
        this._oTrackingData = oCard._oTrackingData;
        this.creationCard = oCard;
        return events;
    };

    /** ************************************************************************************** */
    /*                            Product Event Handlers                                      */
    /** ************************************************************************************** */

    events.listenProductValueChange = function(eventType,oProduct) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ProductValueChanged,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:eventType,
                a6:oProduct?.ModelNumber,
                a7:oProduct?.DisplayName,
                a8:oProduct?.selectedType ?? "",
                a9:oProduct?.rankIndex ?? "",
                a10:oProduct?.determinedBy ?? "",
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                         swa ATL subscribe click Event Handlers                         */
    /** ************************************************************************************** */

    events.swaATLSubscribePressed = function(leadingProduct, chosenSystem) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ATLSubscribePressed,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5: "Leading Product ##" + leadingProduct,
                a6: "EventID ##" + chosenSystem.eventId,
                a7: "EventStartTime ##" + chosenSystem.originalEventTime,
                a8: "Type ##" + chosenSystem.cloudOutageTypeCode,
                a9: "TypeText ##" + chosenSystem.cloudOutageType,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaATLCaseCreationPressed = function(leadingProduct) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ATLCaseCreationPressed,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5: "Leading Product ##" + leadingProduct,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaATLDialogOpen = function(leadingProduct, chosenSystem) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ATLDialogOpen,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5: "Leading Product ##" + leadingProduct,
                a6: "EventID ##" + chosenSystem.eventId,
                a7: "EventStartTime ##" + chosenSystem.originalEventTime,
                a8: "Type ##" + chosenSystem.cloudOutageTypeCode,
                a9: "TypeText ##" + chosenSystem.cloudOutageType,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                            Case creation Event Handlers                                */
    /** ************************************************************************************** */

    events.swaCaseCreationStart = function(openDraft) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.CaseCreationStart,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"openDraftFromCaseList ##" + openDraft,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaCaseCreationExit = function() {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:true,
                eventName:this.eventName.CaseCreationExit,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.exitDialogReply = function(option) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:true,
                eventName:this.eventName.ExitDialogReply,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:option,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.draftSavedEvent = function(option) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:true,
                eventName:this.eventName.DraftSaved,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:option,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaSimCatKnowledgeEntries = function(data) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SimCatKnowledgeEntries,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5: "SimCat number of entries ##" + data.length,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaSimCatKnowledgePressed = function(hotAndTrending,position,tagNames) {
        this.creationCard.coveoUtil.sendCoveoAnalytics("CreateCase", "SimCatKnowledgePressed",
            {...this.creationCard._oIssueInformationModel.getData(),
                SimCatKnowledgePressedItem:{
                    url: hotAndTrending?.URL,
                    docType: hotAndTrending?.Type,
                    modelNumber:hotAndTrending?.ModelNumber,
                    title:hotAndTrending?.Title
                }
            }, false);

        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SimCatKnowledgePressed,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"URL ##" + hotAndTrending?.URL,
                a6:"Position ##" + position,
                a7:"DocType ##" + hotAndTrending?.Type,
                a8:"DocTags ##" + tagNames,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaISMKnowledgePressed = function(recommendSolution,position,tagNames,productName,modelNumber) {
        this.creationCard.coveoUtil.sendCoveoAnalytics("CreateCase", "ISMKnowledgePressed",
            {...this.creationCard._oIssueInformationModel.getData(),
                ISMKnowledgePressedItem:{
                    url: recommendSolution?.external_url,
                    docType:recommendSolution?.type,
                    title:recommendSolution?.title
                }
            }, false);
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ISMKnowledgePressed,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"URL ##" + recommendSolution?.external_url,
                a6:"Position ##" + position,
                a7:"DocType ##" + recommendSolution?.type,
                a8:"DocTags ##" + tagNames,
                a9:"PF Name ##" + productName,
                a10:"PF ##" + modelNumber,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaSACKnowledgePressed = function(sacContentRecommendation,position, treeNodeId, currentNodeId) {
        this.creationCard.coveoUtil.sendCoveoAnalytics("CreateCase", "SACKnowledgePressed",
            {...this.creationCard._oIssueInformationModel.getData(),
                SACKnowledgePressedItem:{
                    url: sacContentRecommendation?.url,
                    docType:sacContentRecommendation?.type,
                    title:sacContentRecommendation?.title,
                    treeStartNode:sacContentRecommendation?.treeStartNode
                }
            }, false);
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ISMKnowledgePressed,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"SAC question content recommendation url ##" + sacContentRecommendation?.url,
                a6:"SAC question content recommendation pressed position ##" + position,
                a7:"Document Type ##" + sacContentRecommendation?.type,
                a8:"Document Tags ##" + "",
                a9:"SAC Tree Node Id ##" + treeNodeId,
                a10:"SAC Current Node Id ##" + currentNodeId,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaTopSuggestionPressed = function(topSuggestion,position,stepIdx,productName,modelNumber) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.TopSuggestionPressed,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Top Three Suggestion Url ##" + topSuggestion.external_url,
                a6:"Top Three Suggestion pressed position ##" + position,
                a7:"Document Type ##" + topSuggestion.type,
                a8:stepIdx,
                a9:"PF Name ##" + productName,
                a10:"PF ##" + modelNumber,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.detailedDescriptionChanged = function(charCount, stepIdx) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.DetailedDescriptionChanged,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:charCount,
                a8:stepIdx,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.SANodeClicked = function(treeId,treeTitle,treeText, nodeID, nodeText) {
        this.swaService.populateAdobeLayer({
            isTriggerPageView:false,
            eventName:this.eventName.SANodeClicked,
            a1:this._oTrackingData.page_url,
            a2:this.eventType.Click,
            a3:this._oTrackingData.user_type,
            a4:formatter.transferDateFormating(new Date()),
            a5:treeId,
            a6:treeTitle,
            a7:treeText,
            a8:nodeID,
            a9:nodeText,
            a11:this._oTrackingData.session_id ,
            a12:this._oTrackingData.page_id
        });
    };

    events.SANodeDisplayed = function(treeId,treeTitle,treeText) {
        this.swaService.populateAdobeLayer({
            isTriggerPageView:false,
            eventName:this.eventName.SANodeDisplayed,
            a1:this._oTrackingData.page_url,
            a2:this.eventType.Click,
            a3:this._oTrackingData.user_type,
            a4:formatter.transferDateFormating(new Date()),
            a5:treeId,
            a6:treeTitle,
            a7:treeText,
            a11:this._oTrackingData.session_id ,
            a12:this._oTrackingData.page_id
        });
    };

    events.criticalKBADialogOpen = function({productFunction, KBAnumber}) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.CriticalKBADialogOpen,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"PF Name ##" + productFunction?.FullName,
                a6:"PF ##" + productFunction?.ModelNumber,
                a7:"KBA Number ##" + KBAnumber,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.criticalKBADialogClick = function({productFunction, KBAnumber}) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.CriticalKBADialogClick,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"PF Name ##" + productFunction?.FullName,
                a6:"PF ##" + productFunction?.ModelNumber,
                a7:"KBA Number ##" + KBAnumber,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.criticalKBADialogSubscribe = function({productFunction, KBAnumber}) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.CriticalKBADialogSubscribe,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"PF Name ##" + productFunction?.FullName,
                a6:"PF ##" + productFunction?.ModelNumber,
                a7:"KBA Number ##" + KBAnumber,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.criticalKBADialogOK = function({productFunction, KBAnumber}) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.CriticalKBADialogOK,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"PF Name ##" + productFunction?.FullName,
                a6:"PF ##" + productFunction.ModelNumber,
                a7:"KBA Number ##" + KBAnumber,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.submitCaseError = function(errorMsg, correlationId) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SubmitCaseError,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Error Message ##" + errorMsg,
                a6:correlationId ? "Correlation id##" + correlationId : "",
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaSubmitCase = function() {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SubmitCase,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Submit Case pointer ##" + this.creationCard._oIssueInformationModel.getProperty("/pointer"),
                a6:"Case Priority ##" + this.creationCard.fragmentControllers.BasicInformationStep.data.priority.value,
                a7:"Product Function ID ##" + this.creationCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber,
                a8:"Component Key ##" + this.creationCard.fragmentControllers.BasicInformationStep.data.component.info?.CompKey,
                a9:"Component Name ##" + this.creationCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName,
                a10:"PF##" + this.creationCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.FullName,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaConnectToExpert = function() {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ConnectToExpert,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5: "Wait Time ##" + this.creationCard.departmentInChannelData.ESTWAITTIME,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaExpertChatCancel = function() {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ExpertChatCancel,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaPriorityChanged = function(priority, oSource) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.PriorityChanged,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Selected Priority ##" + priority,
                a6:"Triggered by ##" + oSource,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                            Channel Recommended Event Handlers                          */
    /** ************************************************************************************** */

    events.swaChannelsSuggestedList = function(channelListData, method) {
        const caseData = channelListData.find(channel => channel.ChannelID === "CASE");
        const chatData = channelListData.find(channel => channel.ChannelID === "CHAT");
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ChannelsSuggestedList,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Ordered list of suggested channels ##" + JSON.stringify(channelListData.map(item => item.ChannelID)),
                a6:"Scenario ##" + method,
                a7:"TagID ##" + caseData?.TagID,
                a8:"AreaID ##" + caseData?.AreaID,
                a9:chatData?.ChannelData ? ("Etimated waiting time ##" + JSON.parse(chatData.ChannelData).ESTWAITTIME) : "",
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaChannelsSuggestedPressed = function(channelText) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ChannelsSuggestedPressed,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"customer selected channel ID ##" + this.creationCard.getChannelIDByText(channelText) ,
                a6:"customer selected channel name ##" + channelText,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaAlternativeChannelPressed = function(channelText) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.AlternativeChannelPressed,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Alternative channel selected ID ##" + this.creationCard.getChannelIDByText(channelText) ,
                a6:"Alternative channel selected name ##" + channelText,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaAlternativeChannelList = function(oText) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.AlternativeChannelList,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Alternative channel List ##" + oText,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                            Product function Event Handlers                             */
    /** ************************************************************************************** */

    events.listenProductFunctionValueChange = function(eventType,oProductFunction) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ProductFunctionValueChanged,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:eventType,
                a6:oProductFunction?.ModelNumber,
                a7:oProductFunction?.FullName,
                a8:oProductFunction?.selectedType ?? "",
                a9:oProductFunction?.rankIndex ?? "",
                a10:oProductFunction?.determinedBy ?? "",
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaValueHelperRecommendations = function(subEventType, recommendList = []) {
        const recommendValues = new Array(10).fill("").map((item, index) => {
            const isOdd = index % 2 !== 0;
            if (recommendList[index]) {
                return (isOdd ? ";" : "") + recommendList[index];
            }
            return "";

        });

        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.ValueHelperRecommendations,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:subEventType,
                a6: recommendValues[0] + recommendValues[1],
                a7: recommendValues[2] + recommendValues[3],
                a8: recommendValues[4] + recommendValues[5],
                a9: recommendValues[6] + recommendValues[7],
                a10: recommendValues[8] + recommendValues[9],
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                            Component function Event Handlers                             */
    /** ************************************************************************************** */
    events.swaBasicInfoStepDeterminedC = function(eventSubType,cName,index,cFieldShownBecause,pName,pModelNum) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.BasicInfoStepDeterminedComponent,
                a1:this._oTrackingData.page_url,
                a2:eventSubType.startsWith("User") ? this.eventType.Click : this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:eventSubType,
                a6:cName,
                a7:index,
                a8:cFieldShownBecause,
                a9:pName,
                a10:pModelNum,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaSubmitStepDeterminedC = function(eventSubType,cName,index,determinedBy,pName,pModelNum) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SubmitStepDeterminedComponent,
                a1:this._oTrackingData.page_url,
                a2:eventSubType.startsWith("User") ? this.eventType.Click : this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:eventSubType,
                a6:cName,
                a7:index,
                a8:determinedBy,
                a9:pName,
                a10:pModelNum,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                            Ariba Guided Answer Event Handlers                          */
    /** ************************************************************************************** */

    events.aribaGAPresentation = function(flowID, shortDesc) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.GuidedAnswerPresentation,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Flow ID ##" + flowID,
                a6:"Short Description ##" + shortDesc,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.aribaGAEngaged = function(flowID, shortDesc, buttonID) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.GuidedAnswerEngaged,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Flow ID ##" + flowID,
                a6:"Short Description ##" + shortDesc,
                a7:"Button ID ##" + buttonID,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.aribaGASolved = function(flowID, shortDesc) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.GuidedAnswerSolved,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Flow ID ##" + flowID,
                a6:"Short Description ##" + shortDesc,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.aribaGACase = function(flowID, shortDesc) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.GuidedAnswerCase,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Flow ID ##" + flowID,
                a6:"Short Description ##" + shortDesc,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                                     Aaep Event Handlers                                 */
    /** ************************************************************************************** */

    events.aaepStart = function(channelName) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.AaepStart,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"DirectlyChannel ##" + channelName,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                                     SAE Event Handlers                                 */
    /** ************************************************************************************** */
    events.bookAnAppointment = function(pointer) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.BookAnAppointment,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Pointer ##" + pointer,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.noSuitableppointment = function() {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.NoSuitableAppointments,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Component ##" + this.creationCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName,
                a6:"Product ID##" + this.creationCard.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber,
                a7:"Product Function ID##" + this.creationCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.systemSelected = function(eventSubType, productData, stepIdx) {
        const productSimcatNumber = [], productWithoutSimcatNumber = [];
        if (Array.isArray(productData)) {
            productData.forEach(item => {
                if (Number.isNaN(Number(item.ModelNumber))) {
                    productWithoutSimcatNumber.push(item.ModelNumber);
                } else {
                    productSimcatNumber.push(item.ModelNumber);
                }
            });
        }
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SystemSelected,
                a1:this._oTrackingData.page_url,
                a2:eventSubType.startsWith("User") ? this.eventType.Click : this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Event Subtype##" + eventSubType,
                a6:"Product Data##" + (productData === "notAvailable" ? "NotAvailable" : productData?.length ? "yes" : "no"),
                a8:stepIdx,
                a9:"All Products with Simcat##" + JSON.stringify(productSimcatNumber.slice(0, 10)),
                a10:"All Products without Simcat##" + JSON.stringify(productWithoutSimcatNumber.slice(0, 10)),
                a11:this._oTrackingData.session_id,
                a12:this._oTrackingData.page_id
            }
        );
    };

    /** ************************************************************************************** */
    /*                                     SLA Event Handlers                                 */
    /** ************************************************************************************** */

    events.slaSave = function(alertIds) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SLASave,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Alert IDs##" + alertIds,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.slaSolutionClicked = function(oEvent) {
        const bindingData = oEvent.getSource().getBindingContext("$this.fileAnalyzeAlerts");
        const trackingData = bindingData.getProperty(bindingData.sPath);
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SLASolutionClicked,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Solution URL##" + (trackingData.solutionsLink || trackingData.LINK),
                a6:"Alert ID##" + (trackingData.alertId || trackingData["ALERT_HEADER.ALERT_ID"]),
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.SLAAnalyzeFilesCompleted = function(analyzeFileEscapeTime, alertsNumber) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SLAAnalyzeFilesCompleted,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:alertsNumber || "0",
                a6:analyzeFileEscapeTime,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaSLASuggestedFiles = function(totalFilesNum, component) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SLASuggestedFiles,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Total number of Files Suggested ##" + totalFilesNum,
                a6:"Component ##" + component,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.swaSLAAttachFiles = function(totalFilesNum, totalSuggstedNum, totalAnalyzableNum) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:false,
                eventName:this.eventName.SLAAttachFiles,
                a1:this._oTrackingData.page_url,
                a2:this.eventType.System,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"Total number of Files Attached ##" + totalFilesNum,
                a6:"Total number of Files Suggested ##" + totalSuggstedNum,
                a7:"Total number of Files Can be processed ##" + totalAnalyzableNum,
                a11:this._oTrackingData.session_id ,
                a12:this._oTrackingData.page_id
            }
        );
    };

    return events;
});

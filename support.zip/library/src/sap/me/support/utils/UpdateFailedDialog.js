sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment"
], function(Object,Fragment) {
    "use strict";
    return Object.extend("sap.me.support.utils.UpdateFailedDialog", {
        constructor : function(oView) {
            this._oView = oView;
        },

        open : function() {
            return this._oDialog ? this._oDialog.open() : Fragment.load({
                id: this._sUpdateFailedDialogId = (this._oView.getId() + "-sUpdateFailedDialog"),
                name:"sap.me.support.fragments.UpdateFailedDialog",
                controller:this
            }).then(function(Dialog) {
                this._oDialog = Dialog;
                this._oView.addDependent(this._oDialog);
                this._oDialog.open();
            }.bind(this));
        },

        close : function() {
            this._oDialog.close();
        }
    });
});
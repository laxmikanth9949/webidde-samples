/* eslint-disable quote-props */
/**
 * ServiceMonitor
 *
 * @desc	Frontend Service to create and save logs to the Web Analytics Realtime Platform,
 *			trigger notifications to persons responsible.
 *
 *			On instantiation, log level and mode can be set.
 *			Log levels can be of type: SILENT, ERROR, WARNING, DEBUG, INFO
 * @example	var SM = new ServiceMonitor();
 */

sap.ui.define([], function() {

    /**
	 * Constructor for service monitor
	 */
    const ServiceMonitor = function({eventPrefix} = {}) {
        this.eventPrefix = eventPrefix ?? "SFM-CaseForm-";
        /**
         * The reason for creating an event queue is the limitation that Adobe events cannot be sent at the same time,
         * with a minimum 100ms interval between each event.
         */
        this.eventQueue = [];
        this.timerID = null;
        this.startEventQueue = () => {
            if (this.timerID) {
                // if there is a event queue already, no need to start a new queue
                return;
            }
            this.timerID = setInterval(() => {
                if (this.eventQueue.length === 0) {
                    clearInterval(this.timerID);
                    this.timerID = null;
                } else {
                    const func = this.eventQueue.shift();
                    func?.();
                }
            }, 150);
        };
    };

    /*
    event name
        incidentStart: On start of incident, ticket, or support case
        incidentCreate: On creation of incident, ticket, or support case

    */
    const populateIncidentEventLayer = function(eventName,id) {
        try {
            window.adobeDataLayer = window.adobeDataLayer || [];
            window.adobeDataLayer.push({
                "event": eventName,
                "incident": {
                    "getSupportID":id
                }
            });
        } catch (err) {
            console.error(err);
        }

    };

    /* paramObject example:
    {
        'eventName': 'special blog view',
        'attribute1': 'valueId: 12345'
    }*/
    // params: isTriggerPageView,eventName,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12
    const populateAdobeLayer = function(params) {
        try {
            window.adobeDataLayer = window.adobeDataLayer || [];
            window.adobeDataLayer.push({
                "event": "wildcardEvent1",
                "wildcard": {
                    "eventName": this.eventPrefix + params.eventName || "",
                    "attribute1":params.a1 ?? window.location.href,
                    "attribute2":params.a2 ?? "",
                    "attribute3":params.a3 ?? "",
                    "attribute4":params.a4 ?? "",
                    "attribute5":params.a5 ?? "",
                    "attribute6":params.a6 ?? "",
                    "attribute7":params.a7 ?? "",
                    "attribute8":params.a8 ?? "",
                    "attribute9":params.a9 ?? "",
                    "attribute10":params.a10 ?? "",
                    "attribute11":params.a11 ?? "",
                    "attribute12":params.a12 ?? ""
                }
            });
            params.isTriggerPageView ? triggerAdobePageView() : triggerAdobeNonPageView();
        } catch (err) {
            console.error(err);
        }
    };

    // if the event results in a page reload (ie, a separate confirmation page), then a single s.t() beacon ready event should be fired
    const triggerAdobePageView = function() {
        try {
            if (typeof adobeDataLayer !== "undefined") {
                (window.adobeDataLayer || []).push({
                    "event": "stBeaconReady"
                });
            }
        } catch (err) {
            console.error(err);
        }
    };

    // if the action within a modal and does not reload the page, a s.tl() beacon event should be fired to send
    const triggerAdobeNonPageView = function() {
        try {
            if (typeof adobeDataLayer !== "undefined") {
                (window.adobeDataLayer || []).push({
                    "event": "stlBeaconReady"
                });
            }
        } catch (err) {
            console.error(err);
        }
    };
    const enqueueEvent = function(callback) {
        return function(...args) {
            const context = this;
            this.eventQueue.push(callback.bind(context, ...args));
            this.startEventQueue();
        };
    };

    ServiceMonitor.prototype = {
        // Public Function
        populateAdobeLayer: enqueueEvent(populateAdobeLayer),
        triggerAdobePageView: enqueueEvent(triggerAdobePageView),
        triggerAdobeNonPageView: enqueueEvent(triggerAdobeNonPageView),
        populateIncidentEventLayer: enqueueEvent(populateIncidentEventLayer)
    };

    return ServiceMonitor;
});

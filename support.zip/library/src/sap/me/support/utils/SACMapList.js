sap.ui.define([
    "sap/ui/base/Object"
], function(BaseObject) {
    "use strict";

    return BaseObject.extend("sap.me.support.me.SACMapList", {
        constructor : function() {
            this.clear();
        },

        /**
         * Separate the two actions of "putting questions into questionsMap" and "putting answers into questionsMap".
         * So that we can record the order of answer
         */
        putQuestion : function(idStr, question, leafNodeCheck) {
            if (!idStr || !question) {
                throw new Error("question not exist");
            }
            this.questionsMap[idStr] = {
                question: question,
                answers: undefined,
                isLeaf: leafNodeCheck,
            };
            this.questionIdsList.push(idStr);
        },

        /**
         * Just put the answer into questionsMap
         * Will not change the position of answers
         */
        putAnswer: function(idStr, answers) {
            this.questionsMap[idStr].answers = answers;
        },

        /**
         * Delete the nodes between the selected node's next node and the last node.
         * @param id id of selected node
         */
        clearById : function(id) {
            const selectIndex = this.questionIdsList.findIndex(i => i === id);
            if (selectIndex < 0) {
                return;
            }
            const questionIdsListLength = this.questionIdsList.length;
            if (selectIndex + 1 < questionIdsListLength) {
                // clear node in list and clear node in map
                this.questionIdsList.splice(selectIndex + 1, questionIdsListLength - 1 - selectIndex).forEach(i => {
                    delete this.questionsMap[i];
                });
            }
        },

        isQustionsEmpty : function() {
            return this.questionIdsList.length === 0;
        },

        isAnswerEmpty : function() {
            for (const i in this.questionsMap) {
                if (this.questionsMap[i].answers) {
                    return false;
                }
            }
            return true;
        },

        getQuestionsMap : function() {
            return this.questionsMap;
        },

        clear : function() {
            this.questionsMap = {};
            this.questionIdsList = [];
        },
    });
});

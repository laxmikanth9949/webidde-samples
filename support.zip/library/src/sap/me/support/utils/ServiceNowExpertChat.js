sap.ui.define([
    "sap/ui/base/Object",
    "sap/me/support/utils/helper",
    "sap/me/support/utils/Constants",
    "sap/me/support/model/formatter",
    "jquery.sap.global",
    "sap/me/support/utils/QualtricsService",
    "sap/me/shared/FeatureToggles",
    "sap/me/support/utils/engineerMemo/index"
], function(ObjectBase, Helper, Constants, formatter, jQuery, QualtricsService, FeatureToggles, engineerMemo) {
    "use strict";
    const DEV_SCRIPT_URL = "https://dev.itsm.support.sap.com/sn_csm_ec.custom_em_script.jsdbx";
    const DEV_MODULE_ID = "https://dev.itsm.support.sap.com/#e0a529291b2c7154bcc075939b4bcbb4";

    const TEST_SCRIPT_URL = "https://test.itsm.support.sap.com/sn_csm_ec.custom_em_script.jsdbx";
    const TEST_MODULE_ID = "https://test.itsm.support.sap.com/#e0a529291b2c7154bcc075939b4bcbb4";

    const PROD_SCRIPT_URL = "https://prod.itsm.support.sap.com/sn_csm_ec.custom_em_script.jsdbx";
    const PROD_MODULE_ID = "https://prod.itsm.support.sap.com/#e0a529291b2c7154bcc075939b4bcbb4";

    const env = Helper.getEnvironment();
    const SCRIPT_URL = {
        local: DEV_SCRIPT_URL,
        dev: DEV_SCRIPT_URL,
        test: TEST_SCRIPT_URL,
        prod: PROD_SCRIPT_URL
    }[env];
    const MODULE_ID = {
        local: DEV_MODULE_ID,
        dev: DEV_MODULE_ID,
        test: TEST_MODULE_ID,
        prod: PROD_MODULE_ID
    }[env];

    const {MemoAction} = engineerMemo;

    return ObjectBase.extend("sap.me.support.utils.ServiceNowExpertChat", {
        constructor: function(oCard) {
            this.oCard = oCard;
            this.loadScript();
            this.requestNotificationFlag();
        },

        loadScript() {
            const script = document.createElement("script");
            script.src = SCRIPT_URL;
            script.onerror = function() {
                console.error("Failed to load external script:", script.src);
            };
            document.body.appendChild(script);
        },

        requestNotificationFlag() {
            return jQuery.ajax("/backend/raw/support/CaseNotification", {
                data: {
                    $filter: this.oCard._oIssueInformationModel.getData().priority === "1" ? "1" : ""
                },
                success: (data) => {
                    this.emailNotification = data.Email;
                }
            });
        },

        chatInit() {
            this.controlBackground(true);
            window.SN_CSM_EC.init({
                moduleID: MODULE_ID,
                loadFeature: this.chatFeatureContext(),
            });
            window.SN_CSM_EC.onLoginCustom();
            this.oCard.coveoUtil.sendCoveoAnalytics("CreateCase", "OpenExpertChat", this.oCard._oIssueInformationModel.getData(), true, this.oCard.fragmentControllers.BasicInformationStep.data);
            this.oCard.swaServiceEvent.swaConnectToExpert();
            this.messageListener();
        },

        chatFeatureContext() {
            if (window?.FOR_SNO_CHAT_TEST?.chatFeatureContext) {
                return window?.FOR_SNO_CHAT_TEST?.chatFeatureContext();
            }
            return {
                feature: "CHAT",
                openOnLoad: false,
                params: !FeatureToggles.get("feature-support-expertchat-send-truncated-data") ? this.getInitParamsInOldWay() : this.getInitParamsInNewWay(),
            };
        },

        getInitParamsInOldWay : function () {
            const userInfo = this.oCard._oUserModel.getData();
            const necessaryParams = {
                sysparm_requester_session_language: this.formatSelectLanguage(this.oCard.sSelectedKey),
                sysparm_load_active_only: true,
                sysparm_ec_chat_endpoint: "sap for me - portal",
                sysparm_ec_business_unit: "PS",
                sysparm_ec_launchpad_session_id: this.oCard._oTrackingData.session_id,
                sysparm_ec_send_transcript: this.emailNotification ? "ON" : "OFF",
                sysparm_queue: this.oCard.departmentInChannelData?.CHAT_QUEUE_ID,
                sysparm_ec_component_id: this.oCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName ?? "",
                sysparm_ec_product_function_id: this.oCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber ?? "",
                sysparm_ec_customer_id: this.oCard.selectedCutAndSuserInfo.customerNum,
                sysparm_ec_suser_id: this.oCard._selectSuserDialog.getSuserModel()?.getData().suserNumber ?? userInfo.userName,
                sysparm_ec_installation_number: this.oCard.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr,
                sysparm_ec_system_number: this.oCard.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber,
                sysparm_ec_priority_id: this.oCard.fragmentControllers.BasicInformationStep.data.priority.value,
                sysparm_ec_sold_product: this.oCard.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber ?? "",
                sysparm_ec_subject: this.oCard.fragmentControllers.BasicInformationStep.data.shortDesc,
                sysparm_ec_firstname: userInfo.firstName,
                sysparm_ec_lastname: userInfo.lastName,
            };
            const option1Params = {
                sysparm_ec_product_function: this.oCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.Name ?? "",
                sysparm_ec_detailed_description: this.getDetailedDescription(),
            };
            const option2Params = {
                sysparm_ec_business_impact: this.oCard._oIssueInformationModel.getProperty("/impactText") ?? "",
            };
            const option3Params = {
                sysparm_ec_steps_to_reproduce: this.oCard.fragmentControllers?.CaseCreationDetailedInformationStep?.data?.stepsToReproduce
            };
            return this.formatParameters(necessaryParams, option1Params, option2Params, option3Params);
        },

        /**
         *
         * @param {Object} parma1 necessary params
         * @param {Object} parma2 pf&detail description
         * @param {Object} parma3 business impact
         * @param {Object} parma4 steps to reproduce
         * @returns object needs to send to sno
         */
        formatParameters: function(parma1, parma2, parma3, parma4) {
            const existKeys = new Set();
            const qsParams = new URLSearchParams();
            function sliceToValidQSWithMaxLength(encodeStr, length) {
                try {
                    return decodeURI(encodeStr.substring(0, length));
                } catch (error) {
                    return sliceToValidQSWithMaxLength(encodeStr, length - 1);
                }
            }

            function queryStringToObject(qsStr) {
                const qsParam = new URLSearchParams(decodeURI(qsStr));
                const obj = {};
                let previousKey = "";
                Array.from(qsParam.entries()).forEach(([key, value]) => {
                    if (!existKeys.has(key)) {
                        obj[previousKey] = obj[previousKey] + "&" + key + value;
                    } else {
                        previousKey = key;
                        obj[key] = value;
                    }
                })
                return obj;
            }

            /**
             *
             * @param qsStr {string}
             * @param oldQSParams {URLSearchParams}
             */
            function resetParamsByQueryString(qsStr, oldQSParams) {
                const newParams = queryStringToObject(qsStr);
                for (const newKey in newParams) {
                    oldQSParams.set(newKey, encodeURI(newParams[newKey]));
                }
            }

            /**
             * @param params {object} params to be appended to qsParams
             * @param maxLength {number} max length of query string
             * @param suffix {string} if larger than maxLength, slice to valid query string with max length and append suffix to the end
             * @returns {boolean} can append next param, true is not larger than max length
             */
            function appendParams(params, maxLength, suffix) {
                for (const key in params) {
                    qsParams.set(key, encodeURI(params[key]));
                    existKeys.add(key); // record the param key
                    const str = decodeURI(qsParams.toString());
                    if (str.length >= maxLength) {
                        qsParams.delete(key);
                        let qsStr = sliceToValidQSWithMaxLength(str, maxLength);
                        qsStr += suffix;
                        resetParamsByQueryString(qsStr, qsParams);
                        return false;
                    }
                }
                return true;
            }
            // param1 > 2000, slice the query string to 2000
            const canAppendParam2 = appendParams(parma1, 2000, "...(truncated)");
            if (!canAppendParam2) {
                return queryStringToObject(qsParams.toString());
            }

            // here, param1 < 2000, append param2
            // 2param > 2000, slice the string to 2000
            const canAppendParam3 = appendParams(parma2, 2000, "...(truncated)");
            if (!canAppendParam3) {
                return queryStringToObject(qsParams.toString());
            }

            // here, param1 + param2 < 2000, append param3
            // 3param > 2014, slice the string to 2014
            const canAppendParam4 = appendParams(parma3, 2014, "BI");
            if (!canAppendParam4) {
                return queryStringToObject(qsParams.toString());
            }

            // here, param1 + param2 + param3 < 2014, append param4
            // 4param > 2017, slice the string to 2017
            const canAppendParam5 = appendParams(parma4, 2017, "RETRO");
            // no parameter need to be appended, return the object
            return queryStringToObject(qsParams.toString());
        },

        getInitParamsInNewWay : function () {
            const userInfo = this.oCard._oUserModel.getData();
            const params = {
                sysparm_requester_session_language: this.formatSelectLanguage(this.oCard.sSelectedKey),
                sysparm_load_active_only: true,
                sysparm_ec_chat_endpoint: "sap for me - portal",
                sysparm_ec_business_unit: "PS",
                sysparm_ec_launchpad_session_id: this.oCard._oTrackingData.session_id,
                sysparm_ec_send_transcript: this.emailNotification ? "ON" : "OFF",
                sysparm_queue: this.oCard.departmentInChannelData?.CHAT_QUEUE_ID,
                sysparm_ec_component_id: this.oCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName ?? "",
                sysparm_ec_product_function_id: this.oCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber ?? "",
                sysparm_ec_customer_id: this.oCard.selectedCutAndSuserInfo.customerNum,
                sysparm_ec_suser_id: this.oCard._selectSuserDialog.getSuserModel()?.getData().suserNumber ?? userInfo.userName,
                sysparm_ec_installation_number: this.oCard.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr,
                sysparm_ec_system_number: this.oCard.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber,
                sysparm_ec_priority_id: this.oCard.fragmentControllers.BasicInformationStep.data.priority.value,
                sysparm_ec_sold_product: this.oCard.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber ?? "",
                sysparm_ec_subject: this.oCard.fragmentControllers.BasicInformationStep.data.shortDesc,
                sysparm_ec_firstname: userInfo.firstName,
                sysparm_ec_lastname: userInfo.lastName,
                sysparm_ec_product_function: this.oCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.Name ?? "",
                //specific value for mapping specific case in SNO chat
                sysparm_ec_detailed_description: this.getDetailedDescription(),
                sysparm_ec_business_impact: this.oCard._oIssueInformationModel.getProperty("/impactText") ?? "",
                sysparm_ec_steps_to_reproduce: this.oCard.fragmentControllers?.CaseCreationDetailedInformationStep?.data?.stepsToReproduce??"",
            };

            function paramsToQueryString (params){
                let queryString = "";
                for (const key in params) {
                    queryString += "&" + key + "=" + encodeURIComponent(params[key]);
                }
                return queryString;
            }

            function truncateDetailDescription (html, maxLength) {
                const encodedHtml = encodeURIComponent(html);
                let truncatedEncodedHtml = encodedHtml.substring(0, maxLength);

                //delete unless html entity
                const lastPercentSignIndex = truncatedEncodedHtml.lastIndexOf("%");
                if(truncatedEncodedHtml.length - 1 - lastPercentSignIndex < 2){//xxx%, xxx%1
                    truncatedEncodedHtml = truncatedEncodedHtml.substring(0,lastPercentSignIndex);
                }

                //can not recognize text after the last open tag. such as: <10, <strong, we don't know whether it is the content or a unless html tag,so it won't handle
                return decodeURIComponent(truncatedEncodedHtml) + "...(truncated)";
            }

            //At SNO side, they used to check if the URL length (2048 bytes).
            //So we make sure our parameters is less than 1948 bytes, and keep reserved 100 bytes (such as: other params,host,port,path)
            const encodeStr = paramsToQueryString(params);
            const maxLength = 1948;
            const isExceed = encodeStr.length > maxLength;
            if(isExceed){
                params.sysparm_ec_steps_to_reproduce = "noData";
                params.sysparm_ec_business_impact = "noData";

                //handle detail description. It can't tran to "noData", because it shows in the chat greeting. Need to show to user, truncated and send.
                const encodeStrWithNoData = paramsToQueryString(params);
                if(encodeStrWithNoData.length > maxLength){ //it means long description exceeds
                    const detailDescription = this.getDetailedDescription();
                    const detailDescriptionMaxLength = encodeURIComponent(detailDescription).length - (encodeStrWithNoData.length - maxLength);
                    params.sysparm_ec_detailed_description = truncateDetailDescription(detailDescription, detailDescriptionMaxLength);
                }
            }
            this.initParamsExcced = isExceed;
            return params
        },

        formatSelectLanguage: function(sSelectedKey = "en-us") {
            return {
                "en-us": "en",
                "fr-fr": "fr",
                "de-de": "de",
                "it-it": "it",
                "ja-jp": "ja",
                "ko-kr": "ko",
                "pt-br": "pb",
                "ru-ru": "ru",
                "zh-cn": "zh",
                "es-es": "es",
                "zh-tw": "zt"
            }[sSelectedKey];
        },

        getDetailedDescription: function() {
            const isSACText = this.formatSACDisplay(this.oCard._oCaseCreationSAC?.getSACQuestionAndAnswer());
            const detailedDescription = this.oCard.fragmentControllers?.CaseCreationDetailedInformationStep?.data?.detailedDescription;
            const preSacText = isSACText ? Constants.SAP4MEP_SAC_QUESTION + "\n" + isSACText : "";
            const preDetailedDescription = detailedDescription ? formatter.formatHtmlTag(detailedDescription) + "\n\n" : "";
            if (this.oCard?._componentSelectDialog?.getExpertChatSpecialMessageFlag()) {
                return preDetailedDescription + preSacText + "\n\n" + "Manually selected component: " + this.oCard.fragmentControllers?.BasicInformationStep?.data?.component?.info?.CompName;
            }
            return preDetailedDescription + preSacText;
        },

        formatSACDisplay: function(sacMap) {
            if (!sacMap) {
                return "";
            }
            let sacList = Object.values(sacMap);
            let notLeafList = sacList.filter(item => !item?.isLeaf);
            let leafList = sacList.filter(item => item?.isLeaf);
            let contentText = "";

            notLeafList.forEach(item => {
                contentText += "Q: " + (item?.question || "") + "\n" + "A: " + (item?.answers || "") + "\n\n";
            });

            leafList.forEach(item => {
                contentText += "Q: " + (item?.question || "") + "\n" + "A: " + (item?.answers || "") + "\n\n";
            });
            return contentText;
        },

        messageListener: function() {
            window.addEventListener("message", this.messageListenerFun.bind(this), false);
        },

        messageListenerFun: function(oEvent) {
            if (oEvent.origin === "https://dev.itsm.support.sap.com" || oEvent.origin === "https://test.itsm.support.sap.com" || oEvent.origin === "https://prod.itsm.support.sap.com") {
                // end chat
                if (oEvent.data?.type === "CONVERSATION_CHAT_END") {
                    this.oCard.swaServiceEvent.swaExpertChatCancel();
                    this.controlBackground(false);
                    // no matter chat be answered or not, chat widget should destory
                    if (FeatureToggles.get("feature-support-sno-chat-qualtrics")) {
                        window.SN_CSM_EC.destroy();
                    }
                    // means chat was answered, and interaction record create in Now
                    if (oEvent.data.number && this.interactionNumber !== oEvent.data.number) {
                        // event will be listened more than once
                        this.interactionNumber = oEvent.data.number;
                        // delete draft, open qualtrics and back to case list
                        this.oCard.deleteDraft();
                        if (FeatureToggles.get("feature-support-sno-chat-qualtrics")) {
                            this.oCard._navToNextWithoutEvent({
                                name: "application",
                                arguments: {
                                    name: "cl"
                                }
                            });
                            this.openQualtricsIntercept();
                        } else {
                            this.oCard._navToNextWithoutEvent({
                                name: "dashboard",
                                arguments: {
                                    nameOrId: "servicessupport"
                                }
                            });
                        }
                    }
                } else if(oEvent.data === "CONVERSATION_CHAT_START" && FeatureToggles.get("feature-support-expertchat-send-truncated-data") && this.initParamsExcced){
                    this.sendRestPayload(0);
                }
            }
        },

        sendRestPayload : async function (count) {
            if(count > 3){
                return;
            } else {
                count++;
            }
            const data = {
                sessionId:this.oCard._oTrackingData.session_id,
                longDescription:encodeURIComponent(this.getDetailedDescription()),
                businessImpact:encodeURIComponent(this.oCard._oIssueInformationModel.getProperty("/impactText") ?? ""),
                stepToReproduce:encodeURIComponent(this.oCard.fragmentControllers?.CaseCreationDetailedInformationStep?.data?.stepsToReproduce??""),
            }

            try{
                await jQuery.ajax("/backend/raw/support/ExpertChatData",{
                    method : "POST",
                    contentType : "application/json",
                    data : JSON.stringify(data)
                })
            }catch (e){
                await this.sendRestPayload(count).catch(()=>{});
            }
        },

        openQualtricsIntercept: function() {
            let surveyUrl = "https://zn9ma3cctce2betig-sapinsights.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_9mA3cctCE2BEtIG";
            if (env === "prod") {
                surveyUrl = "https://zn1idyhsur1vdkhnk-sapinsights.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_1IdYhSur1VdkhNk";
            }
            QualtricsService.initQualtricsSurvey(surveyUrl, this).then(() => {
                if (window.QLT_MMI2S_PARAM) {
                    delete window.QLT_MMI2S_PARAM;
                }
                if (window.QLT_MMI1S_PARAM) {
                    delete window.QLT_MMI1S_PARAM;
                }
                if (window.QLT_LAUNCHPAD_PARAM) {
                    delete window.QLT_LAUNCHPAD_PARAM;
                }

                window.ChatSessionID = this.interactionNumber;

                if (this.hasInterceptLoaded) {
                    window.QSI.API.unload();
                    window.QSI.API.load().done(window.QSI.API.run());
                }
            });
        },

        /**
         * @param {Boolean} isAddMask add mask when chat start  |  remove mask when end chat
         */
        controlBackground: function(isAddMask) {
            const elementClass = document.querySelector("#shell").classList;
            if (isAddMask) {
                elementClass.add("addBlackBackground");
            } else {
                elementClass.remove("addBlackBackground");
            }
        },

    });
});

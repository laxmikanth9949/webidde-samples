sap.ui.define([
    "sap/me/support/model/formatter",
    "sap/m/MessageBox",
    "sap/m/Text",
    "../utils/helper",
    "sap/me/support/utils/RemoteSupportLogAssistant",
    "sap/me/support/requests/AttachmentRequest",
    "sap/me/support/utils/CreationAttachmentEvent",
    "sap/base/Log",
], function(formatter, MessageBox, Text, helper, RemoteSupportLogAssistant, AttachmentRequest, CreationAttachmentEvent, Log) {
    const DPREST_EUDP = "EUDP";
    const DPREST_CNDP = "CNDP";
    const DPREST_NONE = "NONE";
    const ANALYZE_STATUS = {
        NOT_CHECK: -1,
        CANNOT_ANALYZE: 0,
        READY_ANALYZE: 1,
        ANALYZE_COMPLETE: 2,
        ANALYZE_CANCELLED: 3,
        ANALYZING: 4,
        CHECKING_FILE_CONTENT: 5,
        CHECKING_ZIPPED_CONTENT: 6,
        READY_ZIPPED_ANALYZE: 7,
        ZIPPED_CONTENT_PARTIALLY_ANALYZED: 8,
        GENERATE_PDF: 9
    };
    const FILE_UPLOAD_STATUS = {
        UPLOADING: "uploading",
        FAILED: "failed",
        SUCCESS: "uploaded"
    };

    const AttachmentHelper = function(oController) {
        this.oController = oController; // controller could be case creation or case detail
        this.attachmentsInfo = []; // all the files displayed in uploading panel
        this.formattedAttachments = []; // to record the attachments infomation after upload
        this.allowFileTypes = [];
        this.analyzableFiles = [];
        this.uploadPdfAttachments = []; // the files has be generate pdf report
        this._i18n = this.oController?._i18n;
        this.MAXIMUM_ATTACHMENT_SIZE = 250;
        this.uploadedAllFiles = [];// except for ZIP file;
        this.uploadedAllZippedFiles = [];
    };

    AttachmentHelper.prototype.clearAll = function() {
        this.attachmentsInfo = [];
        this.formattedAttachments = [];
        this.analyzableFiles = [];
        this.uploadPdfAttachments = [];
        this.uploadedAllFiles = [];
        this.uploadedAllZippedFiles = [];
    };

    AttachmentHelper.prototype.addAttachment = function(newFileList) {
        const list = Array.isArray(newFileList) ? newFileList : [newFileList];
        newFileList = this.formatFileData(list);
        this.attachmentsInfo.push(...newFileList);
        return newFileList;
    };

    /**
     * After user choose files, format the file data so that it can be displayed in the view.
     * and set analysisStatus for analyze file..zip file except display, it can be encode to many single file to analyze
     * if there is duplicate file name, add a number to the end of the file name
     * @param {*} newFileList  The file list that user choose
     * @returns {Array} The formatted file data
     */
    AttachmentHelper.prototype.formatFileData = function(newFileList) {
        const nameList = this.attachmentsInfo.map(item => item.name);

        return newFileList.map((item) => {
            const fileInfo = {
                file: item,
                name: nameList.includes(item.name) ? this.renameDuplicateFile(item.name) : item.name,
                size: formatter.formatFileSize(item.size),
                description: "",
                pcdChecked: false, // personal & confidential data
                euDataChecked: false,
                cnDataChecked: false,
                fileType: this.getFileExtension(item.name),
                isDescriptionVisible: false,
                fileStatus: FILE_UPLOAD_STATUS.UPLOADING,
                fileURL: "",
                analysisStatus: ANALYZE_STATUS.NOT_CHECK
            };
            fileInfo.UUID = (fileInfo.name + item.size + item.lastModified).replace(/[^0-9a-zA-Z]/g, "");
            return fileInfo;
        });
    };

    /**
     * Get file Extension from file name
     * "" => ""
     * "name" => ""
     * "name.txt" => "txt"
     * "name.txt.zip" => "zip"
     * ".txt" => ""
     * @param {string} fileName
     * @returns {string} The file Extension
     */
    AttachmentHelper.prototype.getFileExtension = function(fileName) {
        return fileName?.slice((fileName.lastIndexOf(".") - 1 >>> 0) + 2);
    };

    /**
     * Rename file name if there is duplicate file name
     * @param {string} fullFileName
     * @returns {string} new file name
     */
    AttachmentHelper.prototype.renameDuplicateFile = function(fullFileName) {
        const typeIndex = fullFileName.lastIndexOf(".");
        const fileName = fullFileName.substring(0, typeIndex);
        const ext = fullFileName.slice(typeIndex);
        const duplicateArr = this.attachmentsInfo.filter(v => v.name.includes(fileName));

        return `${fileName} (${duplicateArr.length})${ext}`;
    };

    AttachmentHelper.prototype.changeDescriptionVisible = function(oAttachment) {
        const index = this.attachmentsInfo.findIndex(function(aEntry) {
            return aEntry.name === oAttachment.name;
        });
        if (index !== -1) {
            this.attachmentsInfo[index].isDescriptionVisible = !this.attachmentsInfo[index].isDescriptionVisible;
        }
    };

    /**
     * Delete the attachment from the list by attachment name
     * @param {*} oAttachment
     */
    AttachmentHelper.prototype.deleteAttachment = function(oAttachment) {
        /**
         * @param {*} fileObject the file in the object need to be delete
         * @param {*} fileName compare name
         */
        const deleteFun = (fileObject, fileName) => {
            const deletedIndex = fileObject.findIndex(aEntry => aEntry.name === fileName);
            deletedIndex !== -1 && fileObject.splice(deletedIndex, 1);
        };
        // delete attachment in analyze model
        // if zip file has analyzable file then find them in analyzableFiles and delete. else check if the file can be analyze and delete
        if (this.isZippedFile(oAttachment)) {
            // delete in analyzableFiles
            if (oAttachment.analyzableFileCount > 0) {
                for (let i = this.analyzableFiles.length - 1; i >= 0; i--) {
                    if (oAttachment.UUID === this.analyzableFiles[i].zipUUID) {
                        // delete attachment in generated pdf files
                        deleteFun(this.uploadPdfAttachments, this.analyzableFiles[i].name);
                        this.analyzableFiles.splice(i, 1);

                    }
                }
                deleteFun(this.analyzableFiles, oAttachment.name);
            }
            // delete in all zip files
            for (let i = this.uploadedAllZippedFiles.length - 1; i >= 0; i--) {
                if (oAttachment.UUID === this.uploadedAllZippedFiles[i].zipUUID) {
                    this.uploadedAllZippedFiles.splice(i, 1);
                }
            }
        } else if (!this.isZippedFile(oAttachment) && oAttachment.analysisStatus !== ANALYZE_STATUS.CANNOT_ANALYZE && oAttachment.analysisStatus !== ANALYZE_STATUS.NOT_CHECK) {
            const analyzableIndex = this.analyzableFiles.findIndex(item => item.UUID === oAttachment.UUID);
            if (analyzableIndex !== -1) {
                this.analyzableFiles.splice(analyzableIndex, 1);
                // delete attachment in generated pdf files
                oAttachment.analysisStatus === ANALYZE_STATUS.GENERATE_PDF && deleteFun(this.uploadPdfAttachments, oAttachment.name);
            }
        }
        // delete attachment in add dialog
        deleteFun(this.attachmentsInfo, oAttachment.name);

        this.changeSuggestedFileIcon("delete",oAttachment);
    };

    /**
     * 1、Uploading file to server get file URL
     * 2、Calculating to the AttxStr
     * 3、Sending those parameters to server, updated to case/incident
     */
    AttachmentHelper.prototype.updateToBackend = async function({pointer, sRespITSM, caseInstallationNum, status, userInfo}) {
        // 1、Uploading file to server get file URL
        await this.fetchAttachmentsUrl(pointer, sRespITSM, caseInstallationNum);
        // 2、Calculating to the AttxStr
        const formattedAttachments = this.formatAttachments();
        const attxstr = this.getAttachmentStringList(formattedAttachments, pointer, userInfo, caseInstallationNum);
        const params = JSON.stringify({
            action : "SEND2SAP",
            pointer: pointer,
            long_text: "Attachment uploaded",
            attxstr: attxstr,
            status: status
        });
        // 3、Sending those parameters to server, updated to case/incident
        return AttachmentRequest.updateAttachmentToCase(params);
    };

    AttachmentHelper.prototype.getDataProcessRestrictionFlag = function(item, dataProcessRestriction) {
        if (!item.pcdChecked) {
            return DPREST_NONE;
        }
        let euDataChecked = item.euDataChecked,
            cnDataChecked = item.cnDataChecked;
        // from case creation
        if (dataProcessRestriction) {
            euDataChecked = dataProcessRestriction === DPREST_EUDP ? item.euDataChecked : false;
            cnDataChecked = dataProcessRestriction === DPREST_CNDP ? item.cnDataChecked : false;
        }

        return euDataChecked ? DPREST_EUDP : cnDataChecked ? DPREST_CNDP : DPREST_NONE;
    };

    /**
     * Before send attachments to server, we need to format the file data
     * @param {String} dataProcessRestriction The data process restriction EUDP/CNDP/NONE
     * @returns
     */
    AttachmentHelper.prototype.formatAttachments = function(dataProcessRestriction) {
        // Filter attachments based on uploaded status
        const uploadedAttachments = this.attachmentsInfo.filter(attachment => attachment.fileStatus === FILE_UPLOAD_STATUS.SUCCESS);

        return this.formattedAttachments = uploadedAttachments.map((item) => {
            const Dprest = this.getDataProcessRestrictionFlag(item, dataProcessRestriction);

            return {
                Hash: "",
                Filename: item.name,
                Type: item.fileType,
                UUID: item.UUID,
                FilelengthTxt: formatter.formatFileSize(item.size),
                Text: item.description,
                Cpocd: item.pcdChecked ? "X" : "",
                Dprest: Dprest,
                AnalysisStatus: item.analysisStatus,
                CreatedOn: Date.now(),
                Isurl: "X",
                Url: item.fileURL
            };
        });
    };


    /**
     * Get the attachment array for SAE
     */
    AttachmentHelper.prototype.getAttachmentSetForSaE = function(dataProcessRestriction) {
        return this.attachmentsInfo.filter(v => v.fileStatus === FILE_UPLOAD_STATUS.SUCCESS).map((item) => {
            const Dprest = this.getDataProcessRestrictionFlag(item, dataProcessRestriction);

            return {
                Cpocd: item.pcdChecked ? "X" : "",
                Dprest: Dprest,
                Filename: item.name,
                Filesize: formatter.formatFileSize(item.size),
                Hash: "",
                Isurl: "X",
                Text: item.description,
                Type: item.fileType,
                Url: item.fileURL
            };
        });
    };


    /**
     * fetch attachment url form document service
     */
    AttachmentHelper.prototype.fetchAttachmentsUrl = async function(
        pointer = "",
        sRespITSM,
        installationNum
    ) {
        const needUploadFiles = this.attachmentsInfo.filter(v => v.fileStatus === FILE_UPLOAD_STATUS.UPLOADING);
        if (needUploadFiles.length === 0) {
            return;
        }
        const formData = new FormData();
        const sRespItsm = sRespITSM === "SNO" ? "SN" : "";

        formData.append("_charset_", "UTF-8");
        formData.append("pointer", pointer);
        formData.append("installation", installationNum);
        formData.append("uploadCollection-data", "");

        // from case detail
        if (pointer) {
            formData.append("owning_system", sRespItsm);
        }

        needUploadFiles.forEach(item => {
            formData.append("uploadCollection[]", item.file);
        });

        try {
            const result = await AttachmentRequest.uploadFiles(formData);
            const attachmentURLArr = Array.isArray(result) ? result : [result];
            if (attachmentURLArr.length !== needUploadFiles.length) {
            // The result URL does not match the uploaded files, which means that one of them may have failed to upload.
                throw new Error();
            }
            needUploadFiles.forEach((item, index) => {
                item.fileURL = attachmentURLArr[index];
                item.fileStatus = FILE_UPLOAD_STATUS.SUCCESS;
            });
        } catch (error) {
            needUploadFiles.forEach(item => {
                item.fileStatus = FILE_UPLOAD_STATUS.FAILED;
            });
            throw new Error(error);
        }

    };

    /**
     * convert attachments data structure, which fit for backend
     * @param {Array} data attachments
     * @param {Number} pointer
     * @param {Object} userInfo
     * @param {Number} installationNbr
     */
    AttachmentHelper.prototype.getAttachmentStringList = function(data, pointer, userInfo, installationNbr) {
        const aAttachment = data || [];
        const aResult = aAttachment.map((oItem) => {
            const sIsNewlyUploaded = oItem.Hash40 ? (oItem.IsNewlyUploaded || "") : "X",
                oItemR = {};
            oItemR.pointer = pointer || "";
            oItemR.installation = installationNbr || "";
            oItemR.file_name = oItem.Filename || "";
            oItemR.description = oItem.Text || "";
            oItemR.data = oItem.Url || "";
            oItemR.CPOCD = oItem.Cpocd || "";
            oItemR.DPREST = oItem.Dprest || "";
            oItemR.Internal = "";
            oItemR.CreatedBy = userInfo.userName;
            oItemR.CreatedOn = oItem.CreatedOn || "";
            oItemR.IsNewUpCreatedOnloaded = sIsNewlyUploaded;

            return oItemR;
        });
        return aResult;
    };

    /**
     * Get the file type list which allow to upload
     * @returns {Array} The file type list
     */
    AttachmentHelper.prototype.getAttachmentFileTypeList = async function() {
        if (this.allowFileTypes.length > 0) {
            return this.allowFileTypes;
        }

        const result = await AttachmentRequest.getAllowedTypes();
        this.allowFileTypes = result.FileType;
        return this.allowFileTypes;
    };

    AttachmentHelper.prototype.checkDropFileSizeAndType = function(file) {
        if (!file) {
            return false;
        }

        const fileSize = file.size / 1024 / 1024;
        const fileExtension = this.getFileExtension(file.name);

        if (fileSize > this.MAXIMUM_ATTACHMENT_SIZE) {
            this.showError(file.name, "fileSizeExceed");
            return false;
        }

        if (!this.allowFileTypes.includes(fileExtension.toUpperCase())) {
            this.showError(file.name, "typeMissmatch");
            return false;
        }

        return true;
    };

    AttachmentHelper.prototype.showError = function(fileName, errorType) {
        // Get all the text for the error from the I18N file.
        const sSizeErrorMessage = this._i18n.getText("attachments_add_attachments_size_message_error_v1", fileName);
        const sTypeErrorMessage = this._i18n.getText("attachments_add_attachments_type_message_error_v1", fileName);
        const sTypeErrorLink = this._i18n.getText("attachments_add_attachments_type_message_link");
        const isTypeMissMatched = errorType === "typeMissmatch";
        // Define the container for the error
        const oVBox = new sap.m.VBox({
            items: [
                new Text({
                    text: isTypeMissMatched ? sTypeErrorMessage : sSizeErrorMessage
                })
            ]
        });
        // Create a link to display note 1277146 for allowed file types.
        if (isTypeMissMatched) {
            oVBox.addItem(new sap.m.Link({
                text: sTypeErrorLink,
                href: "/notes/1277146",
                target: "_blank"
            }));
        }

        const oLayout = new sap.ui.layout.form.SimpleForm({
            content: [
                oVBox
            ]
        });
        // Display the error in a Message Box.
        MessageBox.error(
            oLayout, {
                icon: MessageBox.Icon.ERROR,
                actions: [sap.m.MessageBox.Action.CLOSE]
            }
        );
    };

    /**
     *
     * @param {*} SLA service
     */
    AttachmentHelper.prototype.initialSLAServer = async function() {
        this.slaService = await RemoteSupportLogAssistant.getInstance;
        this.gdb_session_id = helper.dateConstructedID();
        this.slaService.initialize({
            sla_url: RemoteSupportLogAssistant.host,
            gdb_session_id: this.gdb_session_id,
            backend_connector: "/backend/raw/support/QuerySLAObjectVerticle"
        });
    };

    /** ********************************************************************
      * ********************************************************************
      * ZIP FILE
      * ********************************************************************
      * ********************************************************************/

    /**
     * @desc is zip file or not
     * @param {Object} oFile
     * @returns {Boolean}
     */
    AttachmentHelper.prototype.isZippedFile = function(oFile) {
        return this.getFileExtension(oFile.name) === "zip";
    };

    /**
     * @desc request SLA service to decompression zip file  and initilize count of parent zip file and set file analyze status
     * @param {Object} oZipFileInfo
     */
    AttachmentHelper.prototype.decompressionAndCheckZippedFiles = async function(oZipFileInfo) {
        const unZippedFile = [];
        if (oZipFileInfo.analysisStatus !== ANALYZE_STATUS.NOT_CHECK) {
            return;
        }
        try {
            const zipEntries = await this.getZipEntries(oZipFileInfo.file);
            if (!zipEntries) {
                return;
            }

            for (let i = 0; i < zipEntries.length; i++) {
                const blobFile = this.convertBlob(zipEntries[i]);
                const formattedBlobFile = {
                    file: blobFile,
                    zipUUID: oZipFileInfo.UUID,
                    analysisStatus: ANALYZE_STATUS.NOT_CHECK,
                    name: (oZipFileInfo.name + zipEntries[i].zipFolder + "/" + blobFile.name).replace(/\s+/g, "") // to ensure name is unique
                };
                unZippedFile.push(formattedBlobFile);
            }
            // set zipFile
            oZipFileInfo.contentFileCount = zipEntries.length;
            oZipFileInfo.checkedFileCount = 0;
            oZipFileInfo.analyzableFileCount = 0;
            oZipFileInfo.analyzedFileCount = 0;

            const allPromise = [];
            const files = [];
            for (const item of unZippedFile) {
                files.push(item);
                allPromise.push(this.getFileTypeAndAnalysisStatus(item));
            }
            await Promise.allSettled(allPromise).then(() => {
                files.forEach(item => {
                    this.uploadedAllZippedFiles.push(item);
                });
            });
        } catch (error) {
            console.error("Error with psLogAssistant.getZipEntries" + error);
        }

        Log.info("Zipped file detected");
    };

    /**
         * Formats a blob to have the same properties as a file object
         * Be used after unzip. handle the unzip file format
         * @param {theBlob}
         * @returns {oBlob}
         */
    AttachmentHelper.prototype.convertBlob = function(theBlob) {
        const oBlob = theBlob.fileObject;
        oBlob.name = theBlob.fileName;
        oBlob.filename = theBlob.fileName;
        oBlob.lastModifiedDate = theBlob.lastModified;
        oBlob.lastModified = theBlob.lastModified.getTime();
        oBlob.size = theBlob.fileObject.size;
        return oBlob;
    };

    /** ********************************************************************
      * ********************************************************************
      * FILE STATUS
      * ********************************************************************
      * ********************************************************************/

    AttachmentHelper.prototype.getAnalyzeStatusByTypeFiles = function() {
        const uploadingFileModel = this.oController._fileDataModel.getProperty("/attachmentList");
        // get all unZipped files
        uploadingFileModel.forEach(item => {
            this.isZippedFile(item)
                ? this.decompressionAndCheckZippedFiles(item)
                : this.getFileTypeAndAnalysisStatus(item);
        });
    };

    /**
         * Function to get file type and analysis status
         * Analysing files acts independently of suggestedFiles.
         * Each file has 6 possible statuses
         * -1 : Not Checked For Analysis
         *  0 : Cannot be Analysed
         *  1 : Ready for Analysis
         *  2 : Analysis Complete
         *  3 : Analysis Cancelled
         *  4 : Currently Analysing
         *  5 : Checking File Content
         *  6 : Checking Zipped Content
         *  7 : Content Ready for Analysis
         *  8 : partly zip sub-file has been analyzed
         * @param {fileInfo}
         */
    AttachmentHelper.prototype.getFileTypeAndAnalysisStatus = async function(oFile) {
        let analysisStatus = ANALYZE_STATUS.CANNOT_ANALYZE;
        if (oFile.analysisStatus !== ANALYZE_STATUS.NOT_CHECK) {
            return;
        }
        try {
            const [aList, sChar] = await this.getFileType(oFile.file.name, oFile.file);
            if (aList.length > 0) {
                oFile.file["charEncoding"] = sChar;
                oFile.file["file_types"] = aList;
                const res = this.slaService.getFileTypeInfo(aList);
                if (res[0]?.RULE_COUNT) {
                    analysisStatus = ANALYZE_STATUS.READY_ANALYZE;
                }
                this.changeSuggestedFileIcon("add",oFile);
            }
            this.updateFileModelAnalysisStatus(oFile, analysisStatus);
        } catch (error) {
            this.updateFileModelAnalysisStatus(oFile, analysisStatus);
        }
    };

    AttachmentHelper.prototype.findAttachmentIndexByName = function(oFile) {
        const uploadingFileModel = this.oController._fileDataModel.getProperty("/attachmentList");
        return uploadingFileModel.findIndex(item => item.name === oFile.name);
    };

    AttachmentHelper.prototype.getParentZipFile = function(oFile) {
        const uploadingFileModel = this.oController._fileDataModel.getProperty("/attachmentList");
        return uploadingFileModel.find(item => item.UUID === oFile.zipUUID);
    };

    // update file status
    AttachmentHelper.prototype.updateFileModelAnalysisStatus = function(oFile, oStatus) {
        let finalStatus, index;
        if (oFile.zipUUID) {
            const parentZipFile = this.getParentZipFile(oFile);
            parentZipFile.checkedFileCount++;
            oFile.analysisStatus = oStatus;
            index = this.findAttachmentIndexByName(parentZipFile);
            if (oStatus === ANALYZE_STATUS.READY_ANALYZE) {
                parentZipFile.analyzableFileCount++;
            }
            if (oStatus === ANALYZE_STATUS.ANALYZE_COMPLETE) {
                parentZipFile.analyzedFileCount++;
            }
            // set zip file status according to parentZipfile count
            finalStatus = this.determineFinalStatus(parentZipFile, oStatus);
        } else {
            // if not zip. set property directly
            index = this.findAttachmentIndexByName(oFile);
            finalStatus = oStatus;
        }

        // this method only works for un-zip file
        if (
            oStatus > ANALYZE_STATUS.CANNOT_ANALYZE
            && oStatus < ANALYZE_STATUS.CHECKING_ZIPPED_CONTENT
            && !this.isZippedFile(oFile)
        ) {
            this.updateAnalyzableArray(oFile);
        }

        this.oController._fileDataModel.setProperty("/attachmentList/" + index + "/analysisStatus", finalStatus);
    };

    AttachmentHelper.prototype.determineFinalStatus = function(parentZipFile, oStatus) {
        if (parentZipFile.checkedFileCount < parentZipFile.contentFileCount) {
            return ANALYZE_STATUS.CHECKING_ZIPPED_CONTENT;
        }
        if (parentZipFile.analyzableFileCount === 0) {
            return ANALYZE_STATUS.CANNOT_ANALYZE;
        }
        if (parentZipFile.analyzedFileCount === 0 && parentZipFile.analyzableFileCount > 0) {
            return ANALYZE_STATUS.READY_ZIPPED_ANALYZE;
        }
        if (parentZipFile.analyzedFileCount <= parentZipFile.analyzableFileCount) {
            return ANALYZE_STATUS.ZIPPED_CONTENT_PARTIALLY_ANALYZED;
        }
        return oStatus;
    };

    // find object in array and sync analyzableFiles
    AttachmentHelper.prototype.updateAnalyzableArray = function(oFile) {
        const index = this.analyzableFiles.findIndex(item => item.name === oFile.name);
        if (index !== -1) {
            // replace origin file
            this.analyzableFiles.splice(index, 1, oFile);
            return;
        }
        this.analyzableFiles.push(oFile);
        this.oController._fileDataModel.setProperty("/analysisList", this.analyzableFiles);
    };

    /** ********************************************************************
      * ********************************************************************
      * FILE ANALYZE
      * ********************************************************************
      * ********************************************************************/

    /**
     * @desc set all files can be analyzed from list
     * @param {file | null} oFile
     */
    AttachmentHelper.prototype.syncFileAnalysis = function(oFile) {
        this.SupportLogAssistantUsed = true;
        this.currentClickedFile = oFile;
        this.currentAnalyzeFiles = [];
        // if analyze single file , set current file or unZipped file.
        // if the second param is null, analyze all
        if (oFile && !this.isZippedFile(oFile)) {
            this.currentAnalyzeFiles.push(oFile);
        } else if (oFile && this.isZippedFile(oFile) && oFile.analyzableFileCount) {
            this.currentAnalyzeFiles.push(...this.analyzableFiles.filter(item => item.zipUUID === oFile.UUID));
        } else {
            this.currentAnalyzeFiles.push(...this.analyzableFiles);
        }
        // be used in process
        this.currentTotalFileSize = this.getTotalFileAnalyzableSize(this.currentAnalyzeFiles);
        this.analyzeFile(0);
    };

    AttachmentHelper.prototype.getAnalyzedFilesSize = function(fileList) {
        return fileList.reduce((preValue, curValue) => {
            return curValue.analysisStatus === ANALYZE_STATUS.ANALYZE_COMPLETE && !this.isZippedFile(curValue)
                ? preValue + curValue.jsonFileInfo.file_object.size
                : preValue;
        }, 0);
    };

    AttachmentHelper.prototype.getTotalFileAnalyzableSize = function(fileList) {
        return fileList.reduce((preValue, curValue) => {
            return curValue.analysisStatus === ANALYZE_STATUS.READY_ANALYZE || curValue.analysisStatus === ANALYZE_STATUS.ANALYZE_COMPLETE || curValue.analysisStatus === ANALYZE_STATUS.ANALYZE_CANCELLED
                ? preValue + curValue.file.size
                : preValue;
        }, 0);
    };

    /**
     * Analyzes a file at the specified index.
     * @param {number} index The index of the file to analyze.
     */
    AttachmentHelper.prototype.analyzeFile = function(index) {
        // end the loop
        if (index === this.currentAnalyzeFiles.length) {
            this.endAnalysis();
            return;
        }
        const oFile = this.currentAnalyzeFiles[index];
        const startCondition = oFile.analysisStatus === ANALYZE_STATUS.READY_ANALYZE || oFile.analysisStatus === ANALYZE_STATUS.ANALYZE_CANCELLED;
        const finishedCondition = oFile.jsonResult?.analysis_data && (oFile.analysisStatus === ANALYZE_STATUS.ANALYZE_COMPLETE || oFile.analysisStatus === ANALYZE_STATUS.GENERATE_PDF);

        if (finishedCondition) {
            this.handleAlertsContent(oFile, oFile.jsonResult.analysis_data.alerts);
            // loop next
            this.analyzeFile(index + 1);
        }
        if (startCondition) {
            this.initiateFileAnalysis(oFile, index);
        }
    };

    AttachmentHelper.prototype.initiateFileAnalysis = function(oFile, index) {
        const analyzeStartTime = new Date().getTime();
        this.slaService.analyzeFile(oFile.file, oFile.file.charEncoding, oFile.file.file_types, {
            onProgress: (jsonFileInfo, jsonAnalysis) => this.analyzeFileOnProgress(oFile, index, jsonFileInfo, jsonAnalysis),
            onComplete: (jsonFileInfo, jsonResult) => {
                this.analyzeFileOnComplete(oFile, index, jsonFileInfo, jsonResult);
                CreationAttachmentEvent.fireFileAnalysisCompleteOnce(new Date().getTime() - analyzeStartTime,jsonResult?.analysis_data?.alerts?.length);
            },
            onCancel: (jsonFileInfo, jsonResult) => {
                this.analyzeFileOnCancel(oFile, jsonFileInfo, jsonResult);
                return;
            }
        });
    };

    AttachmentHelper.prototype.endAnalysis = function() {
        this.oController._fileAnalyzeAlertsDataModel.setProperty("/busyText", this._i18n.getText("case_form_sla_analysing_files_generate"));
        this.oController._fileAnalyzeAlertsDataModel.setProperty("/fileAnalysisBusy", false);
        this.oController._fileAnalyzeAlertsDataModel.setProperty("/fileAnalysisHideSaveButton", false);
    };


    /**
    * Handles the progress of file analysis.
    * @param {Object} oFile - The file being analyzed.
    * @param {number} index - The index of the file being analyzed.
    * @param {Object} jsonFileInfo - Information about the file.
    * @param {Object} jsonAnalysis - Analysis results.
    */
    AttachmentHelper.prototype.analyzeFileOnProgress = function(oFile, index, jsonFileInfo, jsonAnalysis) {
        oFile.analysisStatus = ANALYZE_STATUS.ANALYZING;

        // Get analyzed data and starting position from cancelled analysis if any
        this.mergeCancelledAnalysisData(oFile, jsonAnalysis);

        // Update the analysis progress UI
        this.updateAnalysisProgressUI(oFile, index, jsonAnalysis);

        // Update the file model analysis status
        this.updateFileModelAnalysisStatus(oFile, ANALYZE_STATUS.ANALYZING);

        // Check if analysis cancellation has been triggered
        this.checkForAnalysisCancellation(oFile, jsonFileInfo);
    };

    AttachmentHelper.prototype.mergeCancelledAnalysisData = function(oFile, jsonAnalysis) {
        if (oFile.jsonResult?.analysis_data?.startLine) {
            jsonAnalysis.startLine = oFile.jsonResult.analysis_data.startLine;
            jsonAnalysis.startPos = oFile.jsonResult.analysis_data.startPos;

            jsonAnalysis.alerts.push(...oFile.jsonResult.analysis_data.alerts);
            jsonAnalysis.matches.push(...oFile.jsonResult.analysis_data.matches);

            oFile.jsonResult.analysis_data.startLine = 0;
            oFile.jsonResult = null;
        }
    };

    AttachmentHelper.prototype.updateAnalysisProgressUI = function(oFile, index, jsonAnalysis) {
        const remainingFileSize = this.currentTotalFileSize - (this.getAnalyzedFilesSize(this.currentAnalyzeFiles) + jsonAnalysis.startPos);
        const remainingPercentage = Math.floor((remainingFileSize / this.currentTotalFileSize) * 100);
        const percentageAnalyzed = 100 - remainingPercentage;

        this.oController._fileAnalyzeAlertsDataModel.setProperty("/busyText",
            `${this._i18n.getText("case_form_sla_analysing_files_title")} (${percentageAnalyzed}%)`);

        const processingText = `${this._i18n.getText("case_form_sla_analysing_files_processing")} (${index + 1}/${this.currentAnalyzeFiles.length}): ${oFile.name}`;
        this.oController._fileAnalyzeAlertsDataModel.setProperty("/fileProcessing", processingText);
    };

    AttachmentHelper.prototype.checkForAnalysisCancellation = function(oFile, jsonFileInfo) {
        if (this.oController.analyzeFilesDialog?._cancelCurrent) {
            jsonFileInfo.cancel_analysis = true;
            this.updateFileModelAnalysisStatus(oFile, ANALYZE_STATUS.ANALYZE_CANCELLED);
        }
    };

    AttachmentHelper.prototype.analyzeFileOnComplete = function(oFile, index, jsonFileInfo, jsonResult) {
        oFile.jsonFileInfo = jsonFileInfo;
        oFile.jsonResult = jsonResult;
        oFile.analysisStatus = ANALYZE_STATUS.ANALYZE_COMPLETE;
        // handle alert content
        if (jsonResult.analysis_data) {
            this.handleAlertsContent(oFile, jsonResult.analysis_data.alerts);
        }
        this.updateFileModelAnalysisStatus(oFile, ANALYZE_STATUS.ANALYZE_COMPLETE);
        // excute this function again to promise progress truely set
        this.analyzeFile(index + 1);
    };

    AttachmentHelper.prototype.analyzeFileOnCancel = function(oFile, jsonFileInfo, jsonResult) {
        oFile.analysisStatus = ANALYZE_STATUS.ANALYZE_CANCELLED;
        if (jsonResult.analysis_data) {
            oFile.jsonFileInfo = jsonFileInfo;
            oFile.jsonResult = jsonResult;
        }
        this.oController._fileAnalyzeAlertsDataModel.setProperty("/fileAnalysisBusy", false);
    };

    /** ********************************************************************
      * ********************************************************************
      * FILE ANALYZE ALERT AND SOLUTIONS
      * ********************************************************************
      * ********************************************************************/

    /**
    * Adds alerts to the alert list when they are found. And show solutions if have. And Set alert prioty
    */
    AttachmentHelper.prototype.handleAlertsContent = function(oFile, oAlertsArray) {
        const aFileAnalysisAlertsList = this.oController._fileAnalyzeAlertsDataModel.getProperty("/alertList");
        if (oAlertsArray && oAlertsArray.length) {
            // set alert and solution coontent
            oAlertsArray.forEach(item => {
                const alertContent = this.formatAlertSolutions(item.solutions);
                const oAlert = {
                    UUID: oFile.UUID || oFile.zipUUID,
                    filename: oFile.name,
                    title: item.TITLE,
                    message: item.MESSAGE.replace(/(\r\n|\n|\r)/gm, "").replace(/\x2a/g, ""),
                    priority: item.PRIORITY,
                    solutionsText: alertContent?.sText,
                    solutionsLink: alertContent?.sLink, // only set for one solution, if no link,show all solutionsText; if have link show open link text
                    solutionsType: alertContent?.sType, // only set for one solution, if no type,show all solutionsText; if have link show open link text
                    solutionsArray: item.solutions,
                    type: item.MESSAGE.length > 180 || item.solutions.length > 1 ? "Navigation" : "Inactive",
                    alertId: item.ALERT_ID
                };
                this.setAlertsPriorityCount(item.PRIORITY);
                aFileAnalysisAlertsList.push(oAlert);
            });
            this.oController._fileAnalyzeAlertsDataModel.setProperty("/alertList", aFileAnalysisAlertsList);
        }
    };

    AttachmentHelper.prototype.formatAlertSolutions = function(oSolutions) {
        const returnValue = {
            sText: "",
            sLink: "",
            sType: ""
        };
        if (oSolutions?.length) {
            const sText = this._i18n.getText("case_form_sla_analysing_files_single_solution_1");
            if (oSolutions.length > 1) {
                let sourceNumbers = [];
                oSolutions.slice(0, 3).forEach((item) => {
                    sourceNumbers.push(this.slaService.getResourceTypeWithNumber(item));
                });
                returnValue.sText = sText + " " + sourceNumbers.join(", ") + ", ...";
            } else {
                returnValue.sText = sText + oSolutions[0].DESCRIPTION;
                returnValue.sLink = oSolutions[0].LINK;
                returnValue.sType = oSolutions[0].TYPE;
            }
        }
        return returnValue;
    };

    AttachmentHelper.prototype.setAlertsPriorityCount = function(priority) {
        const fileAnalysisAlertsPriorityCount = this.oController._fileAnalyzeAlertsDataModel.getProperty("/fileAnalysisAlertsPriorityCount");
        switch (priority) {
            case 1:
                fileAnalysisAlertsPriorityCount[0] += 1;
                break;
            case 2:
                fileAnalysisAlertsPriorityCount[1] += 1;
                break;
            case 3:
                fileAnalysisAlertsPriorityCount[2] += 1;
                break;
        }
        fileAnalysisAlertsPriorityCount[3] = fileAnalysisAlertsPriorityCount[0] > 0 || fileAnalysisAlertsPriorityCount[1] > 0 || fileAnalysisAlertsPriorityCount[1] > 0 ? true : false;
        this.oController._fileAnalyzeAlertsDataModel.setProperty("/fileAnalysisAlertsPriorityCount", fileAnalysisAlertsPriorityCount);
    };

    /** ********************************************************************
      * ********************************************************************
      * HANDLE PDF AND DOWNLOAD
      * ********************************************************************
      * ********************************************************************/

    AttachmentHelper.prototype.base64ToArrayBuffer = function(sBlob) {
        const oData = sBlob.replace("data:application/pdf;base64,", "");
        const sBinaryString = window.atob(oData);
        if (window.TextEncoder) {
            const encoder = new TextEncoder();
            return encoder.encode(sBinaryString);
        }
        const iBinaryLen = sBinaryString.length;
        const sBytes = new Uint8Array(iBinaryLen);
        for (let i = 0; i < iBinaryLen; i++) {
            const cAscii = sBinaryString.charCodeAt(i);
            sBytes[i] = cAscii;
        }
        return sBytes;
    };

    /**
       * transfer String Blob to displayed filetype
       */
    AttachmentHelper.prototype.convertStringBlobToObjectFile = function(sBlob) {
        let oBlob = sBlob;
        let arrBuffer;
        // in case of generate pdf use the backend service
        // backend service will return base64, js will return blob
        if (!(sBlob instanceof Blob)) {
            arrBuffer = this.base64ToArrayBuffer(sBlob);
            oBlob = new Blob([arrBuffer], {
                type: "application/pdf"
            });
        }

        const originControllerName = this.isTriggeredByCreation() ? "create" : "edit";
        oBlob.lastModifiedDate = new Date();
        oBlob.lastModified = new Date().getTime();
        oBlob.name = originControllerName === "edit"
            ? "AnalysisReport(EditCase)_" + Date.now() + ".pdf"
            : "AnalysisReport_" + Date.now() + ".pdf";
        this.saveFile(oBlob.name, "application/pdf", arrBuffer || oBlob);

        return this.analysisReport = {
            name: oBlob.name,
            size: formatter.formatFileSize(oBlob.size),
            UUID: (oBlob.name + oBlob.size + oBlob.lastModified).replace(/[^0-9a-zA-Z]/g, ""),
            analysisStatus: 0,
            file: new File([oBlob], oBlob.name, {type: "application/pdf", lastModified: oBlob.lastModified}),
            fileStatus: FILE_UPLOAD_STATUS.UPLOADING,
            isDescriptionVisible: false,
            cnDataChecked: false,
            euDataChecked: false,
            pcdChecked: false,
            description: "",
            fileType: "pdf",
            fileURL: ""
        };
    };

    AttachmentHelper.prototype.generateFileAnalysisPdfContent = function() {
        // append file need to be generate pdf report
        this.currentClickedFile ? this.uploadPdfAttachments.push(...this.currentAnalyzeFiles) : this.uploadPdfAttachments = this.currentAnalyzeFiles;
        const param = [];
        this.uploadPdfAttachments.forEach(oFile => {
            param.push({
                file_info: {
                    name: oFile.name,
                    lastModified: oFile.file.lastModified,
                    size: oFile.file.size,
                },
                file_types: oFile.file.file_types,
                analysis_return_values: {
                    file_info: oFile.jsonFileInfo,
                    results: oFile.jsonResult
                }
            });
        });
        try {
            const blob = this.slaService.generatePdfReport(param);
            // if analysis report has been exist in list and can find it
            // exist -> get index. delete and re-generate it... not exist -> generate it
            if (this.analysisReport) {
                const index = this.attachmentsInfo.findIndex(item => item.name === this.analysisReport.name);
                index !== -1 && this.attachmentsInfo.splice(index, 1);
            }
            const objectBlob = this.convertStringBlobToObjectFile(blob);
            this.attachmentsInfo.push(objectBlob);
            this.oController._fileDataModel.setProperty("/attachmentList", this.attachmentsInfo);
            // if analyze icon click, set current item file status, else set all analyzed files status to 9
            // set analyzed icon enabled
            // update upload pdf attachment file model
            this.oController._fileDataModel.setProperty("/uploadPdfAttachments", this.uploadPdfAttachments);
            if (this.currentClickedFile) {
                const index = this.findAttachmentIndexByName(this.currentClickedFile);
                this.oController._fileDataModel.setProperty("/attachmentList/" + index + "/analysisStatus", ANALYZE_STATUS.GENERATE_PDF);
            } else {
                // set all analyzed icon to disabled
                this.attachmentsInfo.forEach(item => {
                    if (item.analysisStatus === ANALYZE_STATUS.ANALYZE_COMPLETE || item.analysisStatus === ANALYZE_STATUS.ZIPPED_CONTENT_PARTIALLY_ANALYZED) {
                        item.analysisStatus = ANALYZE_STATUS.GENERATE_PDF;
                    }
                });
                this.oController._fileDataModel.setProperty("/attachmentList", this.attachmentsInfo);
            }
        } catch (error) {
            MessageBox.show(this._i18n.getText("case_form_sla_upload_item_error_report"), {
                icon: MessageBox.Icon.ERROR,
                title: "Support Log Assistant Error",
                actions: [MessageBox.Action.OK]
            });
        }
        // event tracking of case creation when click 'save' btn
        if (this.isTriggeredByCreation()) {
            const alertIds = this.oController._fileAnalyzeAlertsDataModel.getProperty("/alertList").map(item => item.alertId);
            this.oController.oCard.swaServiceEvent.slaSave(JSON.stringify(alertIds));
            this.oController.updateFileUrl();
        }
    };

    /**
       * @desc Function to download PDF when to local machine when save is clicked.
       * @param {sName} Name of file
       * @param {sType} File type
       * @param {sData} Blob Data
       */
    AttachmentHelper.prototype.saveFile = function(sName, sType, sData) {
        if (sData && navigator.msSaveBlob) { // IE browser support
            return navigator.msSaveBlob(sData,sName);
        }
        const aHtmlReference = document.createElement("a");
        const sUrl = sData instanceof Blob ? URL.createObjectURL(sData) : sData;
        aHtmlReference.href = sUrl;
        aHtmlReference.download = sName;
        /* eslint-enable */
        aHtmlReference.click();
        window.URL.revokeObjectURL(sUrl);
        aHtmlReference.remove();
    };

    /** ********************************************************************
      * ********************************************************************
      * SUGGESTED FILE
      * ********************************************************************
      * ********************************************************************/

    AttachmentHelper.prototype.getSuggestionList = function(compName) {
        return this.slaService.getSuggestedFilesInfo(compName);
    };

    /** ********************************************************************
      * ********************************************************************
      * TRIGGER SERVER MODE
      * ********************************************************************
      * ********************************************************************/
    /**
       * Called at the time of case creation/edit, calls the functions from the remote support log assistant object to do server side analysis
       *
       * @param {object} oController
       * @returns {void}
       */
    AttachmentHelper.prototype.performServerSideAnalysis = function(oController) {
        // 1. If there are attachments, call the function addServerQueue for server side analysis of the attachments
        const aAttachments = this.formattedAttachments.filter(item => !item.Cpocd && item.Dprest === "NONE").map(item => {
            return {
                OBJECT_ID: item.UUID,
                FILENAME: item.Filename,
                URL: item.Url,
                SECURE: false,
                CONFIDENTIAL: false
            };
        });
        const isCaseCreation = oController.getMetadata().getName().includes("CaseCreationCard");
        const oKmData = {
            sPointer: isCaseCreation ? oController._oIssueInformationModel.getProperty("/pointer") : oController._oPointer,
            sComponent: isCaseCreation ? oController.fragmentControllers.BasicInformationStep.data.component.info?.CompName : oController?._caseDetailInfo?.componentName,
            sProductPath: isCaseCreation ? oController.fragmentControllers.BasicInformationStep.data.product.info?.FullName : "",
            sProductFunctionPath: isCaseCreation ? oController.fragmentControllers.BasicInformationStep.data.productFunction.info?.FullName : "",
            SupportAssistantUsed: isCaseCreation ? oController.isSupportAssistantUsed : false,
            SupportLogAssistantUsed: this.SupportLogAssistantUsed || false,
            sSource: isCaseCreation ? "NEW" : "EDIT",
            gbdSessionId: this.gdb_session_id
        };
        try {
            const messageFromRSLA = this.slaService.addServerQueue({
                INCIDENT_NO: oKmData.sPointer,
                CONTRACT_TYPE: "ES", // //need to populate correctly
                COMPONENT: oKmData.sComponent,
                ATTACHMENTS: aAttachments
            });
            console.error(messageFromRSLA.message + "with Queue ID " + messageFromRSLA.queue_id);
        } catch (oError) {
            console.error("Error with RemoteSLA.addServerQueue: " + oError);
        }

        // 2. Call the function addUsageAnalytics for server side usage analysis
        try {
            this.slaService.addUsageAnalytics({
                POINTER: oKmData.sPointer,
                SA_USED: oKmData.SupportAssistantUsed,
                SLA_USED: oKmData.SupportLogAssistantUsed,
                ATTACHMENTS_NUMBER: this.formattedAttachments.length,
                PRODUCT_AREA: oKmData.sProductPath,
                PRODUCT_FUNCTION: oKmData.sProductFunctionPath,
                GDB_SESSION_ID: oKmData.gbdSessionId,
                SOURCE: oKmData.sSource,
                COMPONENT: oKmData.sComponent
            });
        } catch (oError) {
            console.error("Error with RemoteSLA.addUsageAnalytics: " + oError);
        }
        // reset used value
        this.SupportLogAssistantUsed = false;
    };

    AttachmentHelper.prototype.changeSuggestedFileIcon = function(sAction,sFile) {
        // record the files in uploadedAllFiles arr in case adding/deleting/resetting files
        if (sAction === "add") {
            this.uploadedAllFiles.push(sFile);
        }

        if (sAction === "delete") {
            if (sFile.fileType === "zip") {
                // if delete the zip file, should also delete its node file
                this.uploadedAllFiles = this.uploadedAllFiles.filter(item => item.zipUUID !== sFile.UUID);
            } else {
                this.uploadedAllFiles = this.uploadedAllFiles.filter(item => item.name !== sFile.name);
            }
        }

        // the suggestedList attached flag will be reset at first
        const suggestedList = this.oController._fileDataModel.getProperty("/suggestedList") || [];
        suggestedList.forEach(item => item.isAttached = false);
        this.uploadedAllFiles.forEach(file => {
            suggestedList.forEach(suggestedFileItem => {
                if (file.file.file_types.includes(suggestedFileItem.FILE_TYPE_ID)) {
                    suggestedFileItem.isAttached = true;
                }
            });
        });
        this.oController._fileDataModel.setProperty("/suggestedList", suggestedList);
        // refresh the model in order to render in the UI
        this.oController._fileDataModel.refresh();
    };

    AttachmentHelper.prototype.isTriggeredByCreation = function() {
        return this.oController.getMetadata().getName().includes("CaseCreationAttachmentStep");
    };



    //  -------------   Convert slaService functions to promises   --------------- //
    /**
    * Checks if the file/blob is a ZIP archive and tries to extract the entries contained in the archive
    * @param {file} fileObject
    */
    AttachmentHelper.prototype.getZipEntries = function(fileObject) {
        return new Promise((resolve, reject) => {
            this.slaService.getZipEntries(fileObject, resolve, reject);
        });
    };

    /**
    * @param {string} [filename]
    * @param {file|blob} fileObject - If the filename was __not__ provided, then this parameter must be a file object. Otherwise, this can be a blob object.
    */
    AttachmentHelper.prototype.getFileType = function(filename, fileObject) {
        return new Promise((resolve, reject) => {
            this.slaService.getFileType(filename, fileObject, (...args) => {
                resolve(args)
            }, reject);
        });
    };

    /**
     *
     * @returns all uploaded normal files, doesn't include the zip file
     */
    AttachmentHelper.prototype.getAllNormalFiles = function() {
        return this.attachmentsInfo.filter(file => !this.isZippedFile(file) && file.fileStatus === "uploaded");
    };

    return AttachmentHelper;
});

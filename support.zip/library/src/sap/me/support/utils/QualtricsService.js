sap.ui.define([
    "sap/base/Log"
], function(Log) {
    let qualtricsService = new Object();

    qualtricsService.initQualtricsSurvey = function(sUrl,detailHeader) {
        let surveyUrl = sUrl;
        let surveyDetailHeader = detailHeader;
        return new Promise(function(resolve, reject) {

            let g = function(e, h, f, g) {
                this.get = function(a) {
                // eslint-disable-next-line no-redeclare
                    for (var a = a + "=", c = document.cookie.split(";"), b = 0, e = c.length; b < e; b++) {
                        for (var d = c[b];
                            " " === d.charAt(0);) {
                            d = d.substring(1, d.length);
                        }
                        if (0 === d.indexOf(a)) {
                            return d.substring(a.length, d.length);
                        }
                    }
                    return null;
                };
                this.set = function(a, c) {
                    var b = "",
                        // eslint-disable-next-line no-redeclare
                        b = new Date;
                    b.setTime(b.getTime() + 6048E5);
                    b = "; expires=" + b.toGMTString();
                    document.cookie = a + "=" + c + b + "; path=/; ";
                };
                this.check = function() {
                    let a = this.get(f);
                    if (a) {
                        a = a.split(":");
                    } else if (100 !== e) {
                        if ("v" === h) {
                            e = Math.random() >= e / 100 ? 0 : 100;
                        }
                        a = [h, e, 0];
                        this.set(f, a.join(":"));
                    } else {
                        return !0;
                    }
                    let c = a[1];
                    if (100 === c) {
                        return !0;
                    }
                    switch (a[0]) {
                        case "v":
                            return !1;
                        case "r":
                            return c = a[2] % Math.floor(100 / c), a[2]++, this.set(f, a.join(":")), !c;
                    }
                    return !0;
                };
                this.go = function() {
                    if (this.check()) {
                        let a = document.createElement("script");
                        a.type = "text/javascript";
                        a.src = g;
                        return document.body && document.body.appendChild(a);
                    }
                };
            };
            let that = surveyDetailHeader;

            window.addEventListener("qsi_js_loaded", function(e) {
                let logs = e;
                that.hasInterceptLoaded = !!(window.QSI && window.QSI.API);
                resolve();
            }, false);

            // eslint-disable-next-line no-redeclare
            let sUrl = surveyUrl;
            let sID = "QSI_S_" + sUrl.slice(sUrl.indexOf("/?Q_ZID=") + 8);
            try {
                (new g(100, "r", sID, sUrl)).go();
            } catch (error) {
                Log.error("Failed to initialize the Qualtrics Intercept!" + error);
                reject(error);
            }
        });
    };

    return qualtricsService;
});

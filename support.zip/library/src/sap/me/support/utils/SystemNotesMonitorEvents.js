sap.ui.define([
    "sap/me/support/utils/ServiceMonitor",
    "sap/me/shared/util/getBrowserTabId",
    "sap/me/shared/Models",
    "sap/me/shared/util/getApplicationInstanceId",
    "sap/me/support/model/formatter"
], function(ServiceMonitor, getBrowserTabId, SharedModels, getApplicationInstanceId, formatter) {
    let events = new Object();

    events.initConfig = function() {
        const _oCustomerModel = SharedModels.getCustomerModel();

        this.swaService = new ServiceMonitor({eventPrefix:"SFM-PredictiveContent-"});
        this._oTrackingData = {
            session_id: getApplicationInstanceId("predictiveContent",true),
            page_id: getBrowserTabId(),
            page_url: window.location.href,
            event_name: {
                SolutionRecommendationClicked: "SolutionRecommendationClicked",
                ThumbUpDownClicked: "ThumbUpDownClicked"
            },
            event_type: {
                Click: "Click",
                System: "System",
                Input: "Input",
                Error: "Error",
            },
            user_type: _oCustomerModel.getData().type
        };
        return events;
    };


    events.swaSolutionRecommendationClicked = function({
        // eslint-disable-next-line no-unused-vars
        systemID, productName, componentKey, contentType, contentCategory, contentURL
    }) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:true,
                eventName:this._oTrackingData.event_name.SolutionRecommendationClicked,
                a1:this._oTrackingData.page_url,
                a2:this._oTrackingData.event_type.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"",
                a6:productName,
                a7:componentKey,
                a8:contentType,
                a9:contentCategory,
                a10:contentURL,
                a11:this._oTrackingData.session_id,
                a12:this._oTrackingData.page_id
            }
        );
    };

    events.thumbUpNDownClicked = function({
        // eslint-disable-next-line no-unused-vars
        systemID, productName, contentType, contentURL, feedbackScore
    }) {
        this.swaService.populateAdobeLayer(
            {
                isTriggerPageView:true,
                eventName:this._oTrackingData.event_name.ThumbUpDownClicked,
                a1:this._oTrackingData.page_url,
                a2:this._oTrackingData.event_type.Click,
                a3:this._oTrackingData.user_type,
                a4:formatter.transferDateFormating(new Date()),
                a5:"",
                a6:productName,
                a7:contentType,
                a8:contentURL,
                a9:feedbackScore,
                a11:this._oTrackingData.session_id,
                a12:this._oTrackingData.page_id
            }
        );
    };

    return events;
});

sap.ui.define([
    "sap/me/shared/util/getShellComponent",
    "sap/ui/model/json/JSONModel",
], function(
    getShellComponent,
    JSONModel,
) {
    // This file is only for Detail page cache model
    const DetailPageCacheUtil = {
        getShellComponent
    };
    /**
     * model types
     * @enum {string}
     */
    DetailPageCacheUtil.CacheModelTypes = {
        CaseDetail: "CaseDetail", // this will store case detail cache model data
        CaseDetailConnection: "CaseDetailConnection" // this will store case connection cache model data
    };

    /**
     * EventType
     * @enum {string}
     */
    DetailPageCacheUtil.EventType = {
        Clear: "Clear",
        Change: "Change"
    };

    DetailPageCacheUtil._eventHandlers = {};

    /**
     * clear all cache model for detail page
     * cache model name: modelPrefix-pointer
     * cache model location: shell component
     * @param pointer {string}
     */
    DetailPageCacheUtil.clearAllDetailCaches = function(pointer) {
        const oShellComponent = this.getShellComponent();
        for (const key of Object.keys(this.CacheModelTypes)) {
            oShellComponent.setModel(null, `${key}-${pointer}`);
            this.fireModelChange(this.EventType.Clear, this.CacheModelTypes[key], pointer);
        }
    };

    /**
     *
     * @param modelType {CacheModelTypes}
     * @param pointer {string}
     * @param data {object}
     */
    DetailPageCacheUtil.updateDetailCache = function(modelType, pointer, data) {
        const cacheModel = this.getCacheModel(modelType, pointer);
        if (cacheModel) {
            cacheModel.setData(data);
            this.fireModelChange(this.EventType.Change, modelType, pointer, data);
        }
    };

    DetailPageCacheUtil.getCacheDetailModel = function(pointer) {
        const oShellComponent = this.getShellComponent();
        const cacheDetailModel = oShellComponent.getModel(`${this.CacheModelTypes.CaseDetail}-${pointer}`);
        if (!cacheDetailModel) {
            const detailModel = new JSONModel();
            oShellComponent.setModel(detailModel, `${this.CacheModelTypes.CaseDetail}-${pointer}`);
            return detailModel;
        }
        return cacheDetailModel;
    };

    DetailPageCacheUtil.getCacheConnectionModel = function(pointer) {
        const oShellComponent = this.getShellComponent();
        const cacheConnectionModel = oShellComponent.getModel(`${this.CacheModelTypes.CaseDetailConnection}-${pointer}`);
        if (!cacheConnectionModel) {
            const connectionModel = new JSONModel();
            oShellComponent.setModel(connectionModel, `${this.CacheModelTypes.CaseDetailConnection}-${pointer}`);
            return connectionModel;
        }
        return cacheConnectionModel;
    };

    /**
     * get cache model by type and pointer
     * @param modelType {CacheModelTypes}
     * @param pointer {string}
     */
    DetailPageCacheUtil.getCacheModel = function(modelType, pointer) {
        const modelName = `${modelType}-${pointer}`;
        const oShellComponent = this.getShellComponent();
        const cacheModel = oShellComponent.getModel(modelName);
        if (!cacheModel) {
            const model = new JSONModel();
            oShellComponent.setModel(model, modelName);
            return model;
        }
        return cacheModel;
    };

    /**
     * refresh the model data
     * @param modelType {CacheModelTypes}
     * @param pointer {string}
     * @param [sysNum] {string}
     */
    DetailPageCacheUtil.refreshModelData = async function(modelType, pointer, sysNum) {
        let modelData;
        switch (modelType) {
            case this.CacheModelTypes.CaseDetail:
                modelData = await this.getCaseDetailData(pointer);
                break;
            case this.CacheModelTypes.CaseDetailConnection:
                modelData = await this.getCaseDetailConnectionData(pointer, sysNum);
                break;
        }
        this.updateDetailCache(modelType, pointer, modelData);
        return modelData;
    };

    DetailPageCacheUtil.getCaseDetailData = async function(pointer) {
        try {
            const res = await jQuery.ajax(`/backend/odata/support/CaseDetails('${pointer}')?pointer=${pointer}`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
            });
            return res;
        } catch {
            return null;
        }
    };

    DetailPageCacheUtil.getCaseDetailConnectionData = async function(pointer, sysNum) {
        try {
            const data = await jQuery.ajax("/backend/raw/support/CaseSystemAllInfo", {
                method: "GET",
                data: {
                    systemNumber: sysNum,
                    pointer
                }
            });
            return data;
        } catch {
            return null;
        }
    };

    DetailPageCacheUtil.attachCacheChange = function(pointer, fnCallback) {
        if (!this._eventHandlers[pointer]) {
            this._eventHandlers[pointer] = [];
        }
        this._eventHandlers[pointer].push(fnCallback);
    };

    DetailPageCacheUtil.detachCacheChange = function(pointer, fnCallback) {
        const handlers = this._eventHandlers[pointer] || [];
        const index = handlers.indexOf(fnCallback);
        if (index > -1) {
            handlers.splice(index, 1);
        }
    };

    /**
     * trigger the event when model data change
     * @param type {EventType}
     * @param model {CacheModelTypes}
     * @param pointer {string}
     * @param data {object}
     */
    DetailPageCacheUtil.fireModelChange = function(type, model, pointer, data = null) {
        if (!type || !model || !pointer) {
            return;
        }
        const handlers = this._eventHandlers[pointer] || [];
        for (const handler of handlers) {
            const eventData = {
                type,
                modelName: `${model}-${pointer}`,
                modelType: model,
                pointer,
                data
            };
            handler(eventData);
        }
    };

    return DetailPageCacheUtil;
});

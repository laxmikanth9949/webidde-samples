sap.ui.define([], function() {
    const CreationAttachmentEvent = {};
    const eventBus = sap.ui.getCore().getEventBus();
    const channelName = "sap.me.support.creation.AttachmentEvent";

    CreationAttachmentEvent.EventType = {
        FileAnalysisCompleteOnce: "FileAnalysisCompleteOnce",
    };

    CreationAttachmentEvent.attachFileAnalysisCompleteOnce = function(fnCallback) {
        eventBus.subscribe(channelName, CreationAttachmentEvent.EventType.FileAnalysisCompleteOnce, fnCallback);
    };

    CreationAttachmentEvent.detachFileAnalysisCompleteOnce = function(orginFnCallBackRef) {
        eventBus.unsubscribe(channelName,CreationAttachmentEvent.EventType.FileAnalysisCompleteOnce, orginFnCallBackRef);
    };

    CreationAttachmentEvent.fireFileAnalysisCompleteOnce = function(analyzeFileEscapeTime, alertsNumber) {
        eventBus.publish(channelName,CreationAttachmentEvent.EventType.FileAnalysisCompleteOnce, {analyzeFileEscapeTime, alertsNumber});
    };

    return CreationAttachmentEvent;
});

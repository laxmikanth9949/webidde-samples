sap.ui.define([
    "sap/me/shared/Models",
    "sap/me/support/utils/helper",
    "sap/me/shared/util/getShellComponent",
    "sap/ui/core/routing/Router",
    "sap/me/support/model/formatter"
], function(SharedModels, Helper, getShellComponent, Router, formatter) {
    const RTM_URL = "https://app.directly.com/widgets/rtm/embed.js";
    const WIDGET_ID = Helper.isDev || Helper.isLocal || Helper.isTest ? "2c99829d75f87bc701762b6b75a03bdd" : "8a28122f58b4b6fd0158b617384307ae";

    /**
     *
     * @param {*} caseCreationCard Object(case creation) | null(case detail)
     * @param {*} pointer
     * @param {*} AaEPQuesUUID
     */
    const AaEP = function(caseCreationCard, pointer, AaEPQuesUUID) {
        this.caseCreationCard = caseCreationCard;
        this.userInfo = SharedModels.getCustomerModel()?.getData();
        this.currentExpertSessionUUID = null;
        this.AaEPQuesUUID = AaEPQuesUUID;
        this._rootController = getShellComponent()?.getRootControl()?.getController();
        this._oRouter = Router.getRouter("shellRouter");
        this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        this.RTMConfig = null;
        if (!pointer) {
            return;
        }
        this.loadAaEP(pointer);
        this.addCallbacks();
    };

    AaEP.prototype.loadAaEP = function(pointer) {
        this.setBusy(true);
        this.removeOldDirectlyScript();
        this._pointer = pointer;
        if (!$("#directlyRTMScript").attr("id")) {
            (function(d, i, r, e, c, t, l, y) {
                i[r] = i[r] || function() {
                    (i[r].cq = i[r].cq || []).push(arguments);
                };
                l = d.createElement("script");
                l.id = "directlyRTMScript";
                l.src = e;
                l.async = 1;
                y = d.head || d.getElementsByTagName("head")[0];
                if (d.readyState === "complete" || d.readyState === "loaded" || d.readyState === "interactive") {
                    y.appendChild(l);
                } else if (i.addEventListener) {
                    i.addEventListener("DOMContentLoaded", function() {
                        y.appendChild(l);
                    });
                } else {
                    i.attachEvent("onload", function() {
                        y.appendChild(l);
                    });
                }
            })(document, window, "DirectlyRTM", RTM_URL);
        }

        window.DirectlyRTM("config", this.RTMConfig = this._getInitialConfig());
        this.caseCreationCard?.swaServiceEvent.aaepStart(this.caseCreationCard?._oBestActionModel.getProperty("/AaEPChannel").SOURCE);
    };

    /**
     * Don't add callback multiple times, otherwise callback will be called multiple times
     */
    AaEP.prototype.addCallbacks = function() {
        window.DirectlyRTM("onReady", this.onReadyCallback.bind(this));
        window.DirectlyRTM("onAskQuestion", this.onAskQuestionCallback.bind(this));
        window.DirectlyRTM("onSolved", this.onSolvedCallback.bind(this));
        window.DirectlyRTM("onRejection", this.onRejectionCallback.bind(this));
        window.DirectlyRTM("onReroute", this.onRerouteCallback.bind(this));
        window.DirectlyRTM("onNavigate", this.onNavigateCallback.bind(this));
        window.DirectlyRTM("onMessage", this.onMessageCallback.bind(this));
    };

    AaEP.prototype._getInitialConfig = function() {
        const oInitialConfig = {
            id: WIDGET_ID,
            displayAskQuestion: false,
            userName: this.userInfo.firstname + " " + this.userInfo.lastname,
            userEmail: this.userInfo.email,
            i18n: {
                en: {
                    text: {
                        route_your_question_to_company_part_1: "If you are not happy with the support you are receiving, you can",
                        route_your_question_to_company_part_2: "continue receiving support",
                        route_your_question_to_company_part_3: "by going back to SAP For Me."
                    }
                }
            }
        };

        return oInitialConfig;
    };

    AaEP.prototype.removeOldDirectlyScript = function() {
        const directlyInstances = document.getElementsByClassName("directly-rtm");
        if (!directlyInstances) {
            return;
        }
        for (let i = 0; i < directlyInstances.length; i++) {
            directlyInstances[i].remove();
        }
    };

    AaEP.prototype.checkWindowHeight = function() {
        const directlyInstances = document.getElementsByClassName("directly-rtm");
        if (!directlyInstances) {
            return;
        }
        // make sure height of directly widget is set from css class
        if (directlyInstances[0]?.style?.height !== "") {
            directlyInstances[0].style.height = "";
        }
    };

    AaEP.prototype.setBusy = function(bBusy) {
        this.caseCreationCard && this.caseCreationCard.currentCardPageView.setBusy(bBusy);
    };

    // Save relationship of incident pointer and question uuid
    AaEP.prototype.onAskQuestionCallback = function(questionData) {
        this.currentExpertSessionUUID = questionData.questionUuid;
        jQuery.ajax("/backend/raw/support/CaseCreationAaEP?action=SAVE", {
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            async: true,
            data: JSON.stringify({
                CreationDate: questionData.dateCreated,
                Email: this.userInfo.email,
                IncidentID: this._pointer,
                QuestionUUID: questionData.questionUuid,
                "sap-language": "en"
            }),
            complete: () => {
                this.getStateCallback((params) => {
                    // if session is not active or 403 error happens, remove black background
                    if (params.session) {
                        return;
                    }
                    // KNGMHM02-28921 - Allow customer to use SAP For Me while waiting for an Expert response
                    // this.removeBackground();
                });
            }
        });
    };

    AaEP.prototype.onMessageCallback = function(messageData) {
        if (messageData.messageType === "Answer") {
            this.currentExpertSessionUUID = null;
        }
    };

    AaEP.prototype.onNavigateCallback = function(data) {
        let oCaseCreation = this.caseCreationCard;

        if (data.path === "/minimized" && this.currentExpertSessionUUID && oCaseCreation) {
            this.getStateCallback((params) => {
                if (params.questions?.totalOpen > 0) {
                    // KNGMHM02-29074 - Remove Cancellation Pop-Up when users click on the top right X in Widget
                    // this.showCancelConfirmMessageBox();
                }
            });
        }
        if (data.path.includes("/question")) {
            this.checkWindowHeight();
        }
    };

    AaEP.prototype.getStateCallback = function(callback) {
        if (!this.isSessionReady || !callback) {
            return;
        }
        window.DirectlyRTM("getState", callback);
    };

    AaEP.prototype.showCancelConfirmMessageBox = function() {
        sap.m.MessageBox.confirm(this._i18n.getText("case_creation_aaep_cancel_dialog_content"), {
            title: this._i18n.getText("case_creation_aaep_cancel_dialog_title"),
            onClose: (oEvent) => {
                if (oEvent === this._i18n.getText("case_creation_aaep_cancel_dialog_cancel")) {
                    this.updateAaEPStatus(this.currentExpertSessionUUID, "REROUTED", new Date().toISOString());
                    this.closeSession();
                    this.caseCreationCard?.convertAaEPToCreateACase();
                }
            },
            actions: [this._i18n.getText("case_creation_aaep_cancel_dialog_cancel"), this._i18n.getText("case_creation_aaep_cancel_dialog_continue")],
            emphasizedAction: this._i18n.getText("case_creation_aaep_cancel_dialog_continue"),
            textDirection: sap.ui.core.TextDirection.Inherit
        });
    };

    AaEP.prototype.addBackground = function() {
        $( "#" + this._rootController?.byId("shellPage")?.getParent()?.getId()).addClass("addBlackBackground");
    };

    AaEP.prototype.removeBackground = function() {
        $( "#" + this._rootController?.byId("shellPage")?.getParent()?.getId()).removeClass("addBlackBackground");
    };

    AaEP.prototype.onReadyCallback = function(data) {
        this.isSessionReady = true;
        this.setBusy(false);
        if (!this.caseCreationCard) {
            window.DirectlyRTM("navigate", `/question/${this.AaEPQuesUUID}`);
            if (!data.session) {
                // if session is not active or 403 error happens
                this.reconnectSession?.();
            } else {
                this.currentExpertSessionUUID = this.AaEPQuesUUID;
            }
            return;
        }
        // KNGMHM02-28921 - Allow customer to use SAP For Me while waiting for an Expert response
        // this.addBackground();
        const sQuestion = this.caseCreationCard.fragmentControllers.BasicInformationStep.data.shortDesc + "\n" + this.caseCreationCard.fragmentControllers.CaseCreationDetailedInformationStep.data.detailedDescription;
        const channelName = this.caseCreationCard._oBestActionModel.getProperty("/AaEPChannel").SOURCE;
        this.askQuestion({
            question: formatter.formatHtmlTag(sQuestion),
            userName: this.userInfo.firstname + " " + this.userInfo.lastname,
            userEmail: this.userInfo.email,
            questionCategory: this.caseCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.DisplayName,
            incidentID: this._pointer,
            product: channelName,
            productFunctionPath: this.caseCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber,
            componentKey: this.caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info?.CompKey,
            returnUrl: window.location.origin + `/case/${this._pointer}`,
        });
        this.caseCreationCard._navToNextWithoutEvent();
    };

    AaEP.prototype.startNewSession = function(metadata, AaEPMessageText) {
        if (!metadata) {
            return;
        }

        this.askQuestion({
            question: metadata.conversation.subject + "\n" + formatter.formatHtmlTag(AaEPMessageText),
            userName: this.userInfo.firstname + " " + this.userInfo.lastname,
            userEmail: this.userInfo.email,
            questionCategory: metadata.metadata.category,
            incidentID: this._pointer,
            product: metadata.metadata.product,
            productFunctionPath: metadata.metadata.private.path_id,
            componentKey: metadata.metadata.private.component_key,
            returnUrl: window.location.origin + `/case/${this._pointer}`,
        });
    };

    AaEP.prototype.onSolvedCallback = function(solvedData) {
        this.closeSession();
        this.getChatDetailByQuesUUid(solvedData.questionUuid).then(({expirationDate, AaEPMessageText}) => {
            this.updateAaEPStatus(solvedData.questionUuid, "RESOLVED", expirationDate, AaEPMessageText);
            if (this.caseCreationCard) {
                // from case creation
                this.openIssueConfirmDialog(AaEPMessageText);
            }
        });
    };

    AaEP.prototype.onRejectionCallback = function(rejectionData) {
        this.closeSession();
        this.getChatDetailByQuesUUid(rejectionData.questionUuid).then(({expirationDate}) => {
            this.updateAaEPStatus(rejectionData.questionUuid, "REJECTED", expirationDate);
        });
    };

    AaEP.prototype.onRerouteCallback = function(rerouteData) {
        this.closeSession();
        this.getChatDetailByQuesUUid(rerouteData.questionUuid).then(({expirationDate, AaEPMessageText}) => {
            // no reroutedByPoster
            if (!rerouteData.reroutedByPoster) {
                this.updateAaEPStatus(rerouteData.questionUuid, "REROUTED", expirationDate, AaEPMessageText);
                if (this.caseCreationCard) {
                    this.openIssueConfirmDialog(AaEPMessageText);
                }
                return;
            }
            // has reroutedByPoster but no caseCreationCard
            if (!this.caseCreationCard) {
                this._oRouter.navTo("createIssue", {
                    draftCasePointer: this._pointer,
                    section: "overview"
                });
                return;
            }

            // open the draft of the AaEP in a new tab since user is in SAP4ME when link in AaEP is selected
            sap.m.URLHelper.redirect(window.location.origin + "/createIssue/" + this._pointer + "/overview" + "?aaepuuid=" + rerouteData.questionUuid, true);
            //* ************Coding for when closing AaEP did not redirect to service support main page********************************//
            //            // has reroutedByPoster and has caseCreationCard
            //            this.caseCreationCard.aaepClosedByPoster = true;
            //            // set channel to create a case and go to step 3
            //            clearInterval(this.caseCreationCard.timer);
            //            this.caseCreationCard.convertAaEPToCreateACase();
            //            this.caseCreationCard.resetBestActionModel();
            //            this.caseCreationCard.dynamicCreateUIForCaseBestAction();
            //            this.caseCreationCard.updateAaEPChatToDetailDescription(AaEPMessageText);
            //            // update case status not aaep => delete aaep draft and create a new normal draft
            //            this.caseCreationCard.deleteDraft(this.caseCreationCard.updateDraft.bind(this.caseCreationCard));
            //* *********************************************************************************************************************//
        });
    };

    AaEP.prototype.openIssueConfirmDialog = function(AaEPMessageText) {
        sap.m.MessageBox.confirm(this._i18n.getText("case_creation_aaep_confirm_dialog_content"), {
            title: this._i18n.getText("case_creation_aaep_confirm_dialog_title"),
            onClose: (oEvent) => {
                this.caseCreationCard.updateAaEPChatToDetailDescription(AaEPMessageText);
                if (oEvent === this._i18n.getText("yes")) {
                    this.caseCreationCard.updateDraft();
                    this.caseCreationCard._navToNextWithoutEvent({
                        name: "application",
                        arguments: {
                            name: "cl",
                            "rest*": "?tab=aaepCase"
                        }
                    });
                } else {
                    this.caseCreationCard.convertAaEPToCreateACase();
                }
            },
            actions: [this._i18n.getText("yes"), this._i18n.getText("no")],
            emphasizedAction: this._i18n.getText("yes"),
            textDirection: sap.ui.core.TextDirection.Inherit
        });
    };

    /**
	* Start AaEP Session
	* @param {Object} mParam - Parameters to start a AaEP session
	* @param {string} mParam.question - Initial question text.
	* @param {string} mParam.questionCategory - Question text - to distribute question to expert.
	* @param {string} mParam.userName - Name of questioner.
	* @param {string} mParam.userEmail - Email of questioner.
	* @param {string} mParam.incidentID - Pointer of draft incident created for this session.
	* @param {object} mCallback - functions to be called when RTM events triggered.
	*/
    AaEP.prototype.askQuestion = function(mParam) {
        // AaEP session cannot start without an incident
        if (!mParam.incidentID || !mParam.userEmail) {
            return;
        }

        const questionObj = {
            questionText: mParam.question,
            name: mParam.userName,
            email: mParam.userEmail,
            metadata: {
                incidentID: mParam.incidentID,
                product: mParam.product,
                category: mParam.questionCategory,
                private: {
                    path_id: mParam.productFunctionPath,
                    component_key: mParam.componentKey
                },
                rtm: {
                    returnUrl: mParam.returnUrl
                }
            }
        };

        // navigate to ask form to stop heartbeat
        window.DirectlyRTM("navigate", "/ask");
        window.DirectlyRTM("askQuestion", questionObj);
    };

    /**
     * Get chat detail by question uuid
     */
    AaEP.prototype.getChatDetailByQuesUUid = async function(QuesUUid) {
        this.setBusy(true);
        const failResult = {expirationDate: new Date().toISOString(), AaEPMessageText: this._i18n.getText("case_creation_aaep_transcript_failed_msg")};
        try {
            const result = await jQuery.ajax("/backend/raw/support/CaseCreateDirectlyRTM", {
                method: "GET",
                contentType: "application/json",
                data: {
                    uuid: QuesUUid,
                    userEmail: this.userInfo.email
                },
                dataType: "json"
            });
            this.setBusy(false);
            const data = result?.data;
            if (!data) {
                return failResult;
            }

            // expirationDate means the time when session is closed by customer or expert
            const expirationDate = data.state.dateClosed ? data.state.dateClosed : data.state.rerouteStatus.dateRerouted;
            const AaEPMessageText = this.formatAaEPMessages(data.conversation.responses?.[0]?.messages ?? []);
            return {expirationDate, AaEPMessageText, sessionData: data};
        } catch (error) {
            this.setBusy(false);
            return failResult;
        }
    };

    AaEP.prototype.closeSession = function() {
        this.currentExpertSessionUUID = null;
        this.isSessionReady = false;
        window.DirectlyRTM("logout");
        window.DirectlyRTM("minimize");
        // KNGMHM02-28921 - Allow customer to use SAP For Me while waiting for an Expert response
        // this.removeBackground();
        this._removeRouterMatchedListener();
    };

    /**
     * Update AaEP Status
     * @param {string} questionUuid
     * @param {string} questionStatus RESOLVED/EXPIRED/REJECTED/REROUTED
     * @param
     */
    AaEP.prototype.updateAaEPStatus = function(questionUuid, questionStatus, expirationDate, AaEPMessageText) {
        jQuery.ajax("/backend/raw/support/CaseCreationAaEP?action=UPDATE", {
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({
                AaEPUISessionStatus: "Completed Sessions",
                QuestionUUID: questionUuid,
                QuestionStatus: questionStatus,
                IncidentID: this._pointer,
                ExpireDate: expirationDate
            }),
            complete: () => {
                this.completeSessionCallback?.(AaEPMessageText);
            }
        });
    };

    /**
    * Format AaEP conversation messages with HTML format
    * @param {object} oMessages - AaEP conversation messages
    * @param {string} sAaEPQuesStatus - AaEP question status
    * @returns {void}
    */
    AaEP.prototype.formatAaEPMessages = function(oMessages) {
        if (!oMessages) {
            return "";
        }
        const AaEPHeaderText = "***Expert Peer Session Transcript***";
        let sMessages = "<br /><br />" + AaEPHeaderText,
            sAuthor = "",
            sDateCreated = "";

        if (oMessages.length) {
            for (const i in oMessages) {
                let oMessage = oMessages[i];
                if (oMessage.type === "MESSAGE") {
                    sAuthor = oMessage.author.name;
                    sDateCreated = formatter.mediumDateFromDateNumberAndString(oMessage.dateCreated);
                    sMessages = sMessages + "<br />" + sAuthor + " - " + sDateCreated;
                    sMessages = sMessages + "<br />" + oMessage.bodyHtml;
                }
            }
        } else {
            sMessages = sMessages.replace(AaEPHeaderText, "");
        }
        return sMessages;
    };

    AaEP.prototype._addRoutePatternMatchedListener = function() {
        if (this._oRoutePatternMatchedListener) {
            return;
        }
        this._oRoutePatternMatchedListener = () => {
            this.closeSession();
        };
        this._oRouter.attachRoutePatternMatched({}, this._oRoutePatternMatchedListener, this);
    };

    AaEP.prototype._removeRouterMatchedListener = function() {
        this._oRouter.detachRoutePatternMatched(this._oRoutePatternMatchedListener, this);
        this._oRoutePatternMatchedListener = null;
    };

    return AaEP;
});

sap.ui.define([
    "sap/ui/model/json/JSONModel"
],function(JSONModel) {

    let AdvancedJSONModel = JSONModel.extend("sap.me.support.utils.AdvancedJSONModel", {});

    AdvancedJSONModel.prototype.setProperty = function(sPath, oValue, oContext, bAsyncUpdate) {
        JSONModel.prototype.setProperty.apply(this, arguments);
        let findPath = false;
        for (const binding of this.getBindings()) {
            if (binding.getPath() === sPath) {
                findPath = true;
                break;
            }
        }
        if (!findPath) {
            this.firePropertyChange({
                reason: sap.ui.model.ChangeReason.Change,
                path: sPath,
                value: oValue,
                context: oContext
            });
        }
    };

    return AdvancedJSONModel;
});


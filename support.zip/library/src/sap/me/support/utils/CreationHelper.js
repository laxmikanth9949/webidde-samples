sap.ui.define([
    "sap/me/shared/Models",
    "sap/me/support/fragments/CreateSelectCustomerDialog",
    "sap/me/shared/FeatureToggles",
    "sap/m/MessageBox"
], function(SharedModels,CreateSelectCustomerDialog, FeatureToggles, MessageBox) {
    const helper = new Object();
    const _i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");


    /** -------------------------------------------------SUSER/CUSTOMER------------------------------------------------- */

    /**
     * @returns selected custoemr is supported
     */
    helper.selectedCustomerIsSupported = () => {
        return CreateSelectCustomerDialog.prototype.getCustomerModel()?.getData().customerType === "SUPPORTED";
    };

    /**
     * @returns selected custoemr is serviced
     */
    helper.selectedCustomerIsServiced = () => {
        return CreateSelectCustomerDialog.prototype.getCustomerModel()?.getData().customerType === "SERVICED";
    };



    /** -------------------------------------------------PRODUCT------------------------------------------------- */
    /**
     * product and product function sort rules
     */
    helper.productCompare = function(a,b) {
        if (a?.Recommended && a?.Recently && b?.Recommended && !b?.Recently || a?.Recommended && a?.Recently && !b?.Recommended && !b?.Recently || a?.Recommended && a?.Recently && !b?.Recommended && b?.Recently) {
            return -1; // a is ahead of b
        }
        if (a?.Recommended && !a?.Recently && !b?.Recommended && b?.Recently || a?.Recommended && !a?.Recently && !b?.Recommended && !b?.Recently) {
            return -1; // a is ahead of b
        }
        if (a?.Recently && !a?.Recommended && !b?.Recently && !b?.Recommended) {
            return -1; // a is ahead of b
        }
        if (a?.Recommended && a?.Recently && b?.Recommended && b?.Recently) {
            // node_score only for product function
            if (a?.node_score && b?.node_score) {
                return b?.node_score - a?.node_score;
            }
            if (a?.RecommendedIndex && b?.RecommendedIndex) {
                return a?.RecommendedIndex - b?.RecommendedIndex;
            }
        }
        if (a?.Recommended && !a?.Recently && b?.Recommended && !b?.Recently) {
            // node_score only for product function
            if (a?.node_score && b?.node_score) {
                return b?.node_score - a?.node_score;
            }
            if (a?.RecommendedIndex && b?.RecommendedIndex) {
                return a?.RecommendedIndex - b?.RecommendedIndex;
            }
        }
        if (!a?.Recommended && !a?.Recently && !b?.Recommended && !b?.Recently) {
            return b?.SortOrder - a?.SortOrder;
        }
        if (a?.Recently && !a?.Recommended && b?.Recently && !b?.Recommended) {
            return b?.SortOrder - a?.SortOrder;
        }
        return 1; // a comes after b
    };

    /**
     * @param {Json String} checkResult
     *  checkResult.outcome = 1 entitled
     *  checkResult.outcome = 2 not entitled
     *  checkResult.action = 0 do nothing
     *  checkResult.action = 1 append text to long description
     *  checkResult.action = 2 prevent to select this product
     *
     * @returns returnValue {text: "", prevent: boolean}
     *
     */
    helper.ppfCheck = function(checkResultStr) {
        const returnValue = { text: "", prevent: false };
        if(!FeatureToggles.get("feature-support-entitlement-check")) {
            return returnValue;
        }
        try {
            const checkResult = JSON.parse(checkResultStr);
            if(checkResult.outcome === "1" || checkResult.outcome === "2") {
                switch(checkResult.action) {
                    case "1":
                        returnValue.text = checkResult.text;
                    break;
                    case "2":
                        returnValue.prevent = FeatureToggles.get("feature-support-entitlement-prevent") || false;
                    break;
                }
            }
        } catch (error) {}
        return returnValue;
    };

    helper.showWarningMessageBox = function() {
        MessageBox.warning(_i18n.getText("CheckResultPreventMessage"), {
            styleClass: "sapUiSizeCompact"
        });
    };

    return helper;

},true);

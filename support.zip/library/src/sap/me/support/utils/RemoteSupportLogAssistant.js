function getScript(url) {
    return jQuery.ajax({
        dataType: "script",
        cache: true,
        url: url
    });
}

sap.ui.define([
    "sap/me/support/utils/helper",
    "sap/me/support/utils/Constants",
], function(helper, Constants) {
    const {isLocal, isDev, isTest, isOnCanary, isOnFactory} = helper;
    let host = Constants.DEV_SLA;
    if (isLocal || isDev) {
        host = Constants.DEV_SLA;
    }
    if (isTest) {
        host = Constants.TEST_SLA;
    }
    if (isOnCanary) {
        host = Constants.PROD_SLA;
    }
    if (isOnFactory) {
        host = Constants.FACTORY_SLA;
    }

    jQuery.sap.registerModulePath("sap.productsupport.sla_tool", host + "library/");
    sap.ui.loader.config({
        shim: {
            "sap/productsupport/sla_tool/ps-sla/SupportLogAssistant": {
                amd: true,
                exports: "psLogAssistant"
            },
            "sap/productsupport/sla_tool/thirdparty/jspdf.plugin.autotable": {
                amd: true,
                exports: "jsPDF"
            },
            "sap/productsupport/sla_tool/thirdparty/jschardet": {
                amd: true,
                exports: "jschardet"
            },
            "sap/productsupport/sla_tool/thirdparty/jszip": {
                amd: true,
                exports: "JSZip"
            },
            "sap/productsupport/sla_tool/thirdparty/jspdf": {
                amd: true,
                exports: "jsPDF"
            },
        }
    });

    try {
        if (window.QUnit) {
            throw "this is test env";
        }
        // jQuery.sap.require("sap/productsupport/sla_tool/ps-sla/SupportLogAssistant");
        // jQuery.sap.require("sap/productsupport/sla_tool/thirdparty/jspdf");
        // jQuery.sap.require({modName: "sap/productsupport/sla_tool/thirdparty/jspdf", type: "plugin.autotable"});
        // jQuery.sap.require("sap/productsupport/sla_tool/thirdparty/jschardet");
        // jQuery.sap.require("sap/productsupport/sla_tool/thirdparty/jszip");
        const SupportLogAssistant = host + "library/ps-sla/SupportLogAssistant.js";
        const jspdf = host + "library/thirdparty/jspdf.js";
        const jspdfPlugin = host + "library/thirdparty/jspdf.plugin.autotable.js";
        const jschardet = host + "library/thirdparty/jschardet.js";
        const jszip = host + "library/thirdparty/jszip.js";

        const load = Promise.allSettled([
            getScript(SupportLogAssistant),
            getScript(jspdf),
            getScript(jschardet),
            getScript(jszip)
        ]).then(() => {
            return getScript(jspdfPlugin);
        }).then(() => {
            return psLogAssistant;
        });

        return {
            host: host,
            getInstance : load
        };
    } catch (err) {
        return {
            getInstance : Promise.resolve({
                initialize: function() {
                    return null;
                },
                getSuggestedFiles: function() {
                    return null;
                },
                getFileType: function() {
                    return null;
                },
                getFileTypeInfo: function() {
                    return null;
                },
                analyzeFile: function() {
                    return null;
                },
                generatePdfReport: function() {
                    return null;
                },
                getZipEntries: function() {
                    return null;
                },
                getSuggestedFilesInfo: function() {
                    return null;
                },
                addServerQueue: function() {
                    return null;
                },
                addUsageAnalytics: function() {
                    return null;
                },
                setDateFilter: function() {}
            }),
            host: ""
        };
    }

});

sap.ui.define([
    "sap/ui/model/Filter",
    "sap/ui/core/format/DateFormat",
    "sap/base/Log"
], function(Filter, DateFormat, Log) {
    "use strict";
    const GLOBAL_LOCALE_OVERRIDE = new sap.ui.core.Locale("en");

    function parseDateTime(sValue, oInputParams) {
        try {
            let oInputDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance(oInputParams);
            return oInputDateFormat.parse(sValue);
        } catch (e) {
            Log.error(["Couldn't parse DateTime", sValue, oInputParams].join(", "));
            return null;
        }
    }

    function formatDateTime(oDate, oOutputParams) {
        try {
            let oOutputDateFormat;
            if (GLOBAL_LOCALE_OVERRIDE) {
                oOutputDateFormat = DateFormat.getDateTimeInstance(oOutputParams, GLOBAL_LOCALE_OVERRIDE);
            } else {
                oOutputDateFormat = DateFormat.getDateTimeInstance(oOutputParams);
            }
            return oOutputDateFormat.format(oDate);
        } catch (e) {
            Log.error(["Couldn't format DateTime", oDate, oOutputParams].join(", "), e);
            return "";
        }
    }

    function parseFormatDateTime(sValue, oInputParams, oOutputParams) {
        return this.formatDateTime(this.parseDateTime(sValue, oInputParams), oOutputParams);
    }

    return {
        parseDateTime: parseDateTime,
        formatDateTime: formatDateTime,
        parseFormatDateTime: parseFormatDateTime,
    };

});

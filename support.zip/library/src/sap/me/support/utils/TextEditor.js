sap.ui.define([
    "sap/ui/richtexteditor/RichTextEditor",
    "sap/base/Log"
], function(RTE, Log) {
    "use strict";

    let textEditorObject = {
        /**
         * Creates a RichTextEditor control with a given id and optional parameters
         *
         * Available params are:
         *  	editable = true|false	- Not Required
         *  	value 	 = ""  |string	- Not Required
         *		change	 = function		- Not Required
         *  	readOnly = true|false	- Not Required
         *      statusbar = true|false	- Not Required
         *      height =  ?px default height:240px - Not Required
         * @param {object} bId
         * @param {object} oParams - Optional Parameters
         * @returns {object} new sap.ui.richtexteditor.RichTextEditor
         */
        createRichTextEditor : function(bId,oParams, reCallFunc) {
            this._reCallFunc = reCallFunc;
            this._bId = bId;
            this._oParams = oParams;
            // 1.Default configuration
            let oConfigParams = {
                editable: true,
                value: "",
                change: null,
                readOnly: false,
                scope: null,
                statusbar: false,
                height: 240
            };
            // 2. Check if custom params exist to prevent breakages
            if (oParams) {
                oConfigParams.editable = typeof this._oParams.editable !== "undefined" ? this._oParams.editable : true;
                oConfigParams.value = typeof this._oParams.value !== "undefined" ? this._oParams.value : "";
                oConfigParams.readOnly = typeof this._oParams.readOnly !== "undefined" ? this._oParams.readOnly : false;
                oConfigParams.scope = typeof this._oParams.scope !== "undefined" ? this._oParams.scope : null;
                oConfigParams.change = typeof this._oParams.change !== "undefined" ? this._oParams.change : null;
                oConfigParams.statusbar = typeof this._oParams.statusbar !== "undefined" ? this._oParams.statusbar : false;
                oConfigParams.height = typeof this._oParams.height !== "undefined" ? this._oParams.height : 240;
            }
            // 3. Create the actual RTE
            this._oRichTextEditor = new RTE(this._bId, {
                editorType: sap.ui.richtexteditor.EditorType.TinyMCE6,
                width: "100%",
                height: "240px",
                customToolbar: false,
                showGroupFont: false,
                showGroupLink: false,
                showGroupInsert: false,
                editable: oConfigParams.editable,
                value: oConfigParams.value,
                change: oConfigParams.change
            });
            // 4.2 Attach Config
            this._oRichTextEditor.attachBeforeEditorInit(function(oEvent) {
                // Get the current config
                // 4. Set Config of RTE
                // 4.1 Toolbar & Plugins
                let sToolbar = [" ","cut copy paste pastetext removeformat | undo redo | bold underline italic | outdent indent | bullist numlist | inserttable | link "," "];
                // "cut copy paste pastetext removeformat | undo redo | bold underline | outdent indent | bullist numlist | inserttable | link ";
                let sPlugins = ["autolink"];
                let oConfig = oEvent.getParameter("configuration");
                // Create a local config object
                let oLocalConfig = {
                    entity_encoding: "raw",
                    toolbar: sToolbar,
                    plugins: [...oConfig.plugins, ...sPlugins],
                    // paste_data_images: false,
                    valid_elements: "#p,b,strong,u,br,ol,ul,li,table,tr,td,code,a[href|target|title],i,em",
                    paste_preprocess: function(plugin, args) {
                        let oRegExpStart = new RegExp(/<\s*span.*?>/g);
                        let oRegExpEnd = new RegExp(/<\s*\/\s*span\s*.*?>/g);
                        if (args.content && args.content.replace) {
                            args.content = args.content.replace(oRegExpStart, "<u>").replace(oRegExpEnd, "</u>");
                        }
                    },
                    formats: {
                        underline: {
                            inline: "u",
                            exact: true
                        }
                    },
                    default_link_target: "_blank",
                    link_default_protocol: "https",
                    force_br_newlines: true,
                    forced_root_block: false,
                    convert_urls: true,
                    statusbar: oConfigParams.statusbar,
                    branding: false,
                    min_height: oConfigParams.height,
                    elementpath: false,
                };

                // Merge local congig into real config
                jQuery.extend(oConfig, oLocalConfig);
            });

            this._oRichTextEditor.attachReady(function(oEvent) {
                let style = oEvent.getSource().getDomRef().querySelector("textarea").attributes.style.value;
                if (style.indexOf("hidden") !== -1 || style.indexOf("none") !== -1) {
                    this._reCallFunc && this._reCallFunc();
                }
            });

            // Change State Functionality
            this._oRichTextEditor.setState = {
                none: function() {
                    try {
                        // eslint-disable-next-line no-undef
                        oRichTextEditor.getDomRef().childNodes[0].style.border = "1px solid #c5c5c5";
                    } catch (oError) {
                        Log.error("Text Editor Not Found!");
                    }
                },
                warning: function() {
                    try {
                        // eslint-disable-next-line no-undef
                        oRichTextEditor.getDomRef().childNodes[0].style.border = "1px solid orange;";
                    } catch (oError) {
                        Log.error("Text Editor Not Found!");
                    }
                },
                error: function() {
                    try {
                        // eslint-disable-next-line no-undef
                        oRichTextEditor.getDomRef().childNodes[0].style.border = "1px solid red;";
                    } catch (oError) {
                        Log.error("Text Editor Not Found!");
                    }
                }
            };

            this._oRichTextEditor.onTinyMCEChange = function(oCurrentInst) {
                let sPrevValue = this.getValue(),
                    sContent = oCurrentInst.getContent(),
                    // sNewValue = this.getSanitizeValue() ? sanitizeHTML(sContent) : sContent;
                    sNewValue = sContent;

                if ((sPrevValue !== sNewValue) && !this.bExiting) {
                    this.setProperty("value", sNewValue, true); // suppress rerendering
                    this.fireChange({oldValue: sPrevValue, newValue: sNewValue});
                }
            };

            this._oRichTextEditor.setValue = function(sValue) {
                // null and undefined are escaped and stringified with the code below.
                // That's why we need to ensure these are handled properly as empty values
                sValue = (sValue === null || sValue === undefined) ? "" : sValue;

                // if (this.getSanitizeValue()) {
                // 	Log.trace("sanitizing HTML content for " + this);
                // 	// images are using the URL validator support
                // 	sValue = sanitizeHTML(sValue);
                // }

                if (sValue === this.getValue()) {
                    return this;
                }

                this.setProperty("value", sValue, true);
                sValue = this.getProperty("value");
                this.setValueTinyMCE(sValue);
                return this;
            };

            return this._oRichTextEditor;
        }
    };

    return textEditorObject;
});

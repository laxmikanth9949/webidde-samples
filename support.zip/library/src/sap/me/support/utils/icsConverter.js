sap.ui.define([
    "../library",
    "sap/ui/core/util/File",
    "sap/me/support/utils/htmlToPlain",
    "sap/me/support/utils/constants-calendar"
], function(library, File, htmlToPlain, constants) {
    /**
     * This method persists a timeline event in an .ics file.
     * The data which is persisted is almost the same as the one present in the timeline object, with the following alterations:
     *  - The dates are formatted from ISO String to a UTC string by removing the '-', ':' and '.' characters
     *  - Also the milliseconds part from the date string is removed
     * @param {JSON} timelineEvent - The timeline event which contains the details that will be exported to an .ics file.
     */
    const saveTimelineEventAsCalendarFile = (timelineEvent) => {
        const content = getIcsContentFromTimelineEvent(timelineEvent);
        File.save(content, timelineEvent.title, "ics", "text/calendar", "UTF-8");
    };

    /**
     * This method creates the string content that will be exported to an .ics file.
     * @param {JSON} timelineEvent - The timeline event which contains the details that will be exported to an .ics file.
     * @return {string} Processed string to be used for .ics export file.
     */
    const getIcsContentFromTimelineEvent = (timelineEvent) => {
        const currentDateIsoString = new Date().toISOString();
        const uuid = uuidv4();
        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        const dtStamp = currentDateIsoString.replace(/\.[0-9]{3}/, "");
        const dtStampIcsFormat = getDateInUTCFormatForIcs(dtStamp);
        const dtStartIcsFormat = getDateInUTCFormatForIcs(timelineEvent.start);
        const dtEndIcsFormat = getDateInUTCFormatForIcs(timelineEvent.end);
        const lastModifiedIcsFormat = dtStampIcsFormat;
        let seeMoreLink = "";
        let locationUrl = timelineEvent.targetSystemUrl || "";
        let description = timelineEvent.description;
        if (timelineEvent.type === constants.eventType.EXPERT_SESSION.type) {
            locationUrl = timelineEvent.meetingUrl || locationUrl;
            if (timelineEvent.meetingUrl && timelineEvent.targetSystemUrl) {

                seeMoreLink = `</br><a href='${timelineEvent.targetSystemUrl}'></a>`;
                description = description + "\n" + seeMoreLink;
            }

        }

        return "BEGIN:VCALENDAR\n"
            + "VERSION:2.0\n"
            + "METHOD:PUBLISH\n"
            + "BEGIN:VTIMEZONE\n"
            + `TZID:${timeZone}\n`
            + "END:VTIMEZONE\n"
            + "BEGIN:VEVENT\n"
            + `UID:${uuid}\n`
            + `DTSTAMP:${dtStampIcsFormat}\n`
            + `DTSTART;TZID='${timeZone}':${dtStartIcsFormat}\n`
            + `DTEND;TZID='${timeZone}':${dtEndIcsFormat}\n`
            + `LAST-MODIFIED:${lastModifiedIcsFormat}\n`
            + `SUMMARY:${timelineEvent.title}\n`
            + `DESCRIPTION:${toIcsText(htmlToPlain.convert(description))}\n`
            + `LOCATION: ${locationUrl}\n`
            + "SEQUENCE:0\n"
            + "BEGIN:VALARM\n"
            + "ACTION:DISPLAY\n"
            + "TRIGGER;RELATED=START:-PT00H15M00S\n"
            + "END:VALARM\n"
            + "END:VEVENT\n"
            + "END:VCALENDAR\n";
    };

    /**
     * This method converts a date which is in ISO string format to a UTC date: yyyyMMddTHHmmssZ
     * The format is obtained by removing all the occurences of the '-' and ':' characters.
     * @param {string} dateInISOString - Date string obtained from a JavaScript date object in ISO string format (by calling the .toISOString)
     */
    const getDateInUTCFormatForIcs = (dateInISOString) => {
        return dateInISOString.replace(/[-:]/g, "");
    };

    /**
     * This method returns a UUIDv4. We have used this in order to avoid importing a 3rd party library
     * It makes use of the Crypto API for generating random values. The Crypto api was preferred instead of
     * the Math.Random in order to avoid collisions. This is because of the Math.random implementation.
     * Implementation is taken from the following repository: https://gist.github.com/jed/982883
     */
    const uuidv4 = () => {
        return (`${1e7}-${1e3}-${4e3}-${8e3}-${1e11}`).replace(/[018]/g, c =>
            (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    };

    /**
     * @param {!String} plain
     * @return {!String} ics friendly text
     */
    const toIcsText = (plain) => {
        return plain
            .replace(/\t/g, "    ")
            .replace(/([\\;,])/g, "\\$1")
            .replace(/\r?\n/g, "\\n")
            .replace(/(.{40})/g, "$1\n ");
    };

    return {
        uuidv4, saveTimelineEventAsCalendarFile, getIcsContentFromTimelineEvent, toIcsText
    };
});

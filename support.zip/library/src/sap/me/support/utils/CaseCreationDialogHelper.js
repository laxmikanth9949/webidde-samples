sap.ui.define([], function() {

    const dialogHelper = new Object();

    dialogHelper.showMsgBox = function(sMsgBoxTitle, sMsgBoxDesc) {
        return new Promise((resolve, reject) => {
            sap.m.MessageBox.confirm(sMsgBoxDesc, {
                title: sMsgBoxTitle,
                styleClass: "sapUiSizeCompact",
                actions: ["Cancel", "Confirm"],
                emphasizedAction: "Confirm",
                initialFocus: null,
                textDirection: sap.ui.core.TextDirection.Inherit,
                onClose: (sAction) => {
                    resolve(sAction);
                }
            });
        });
    };

    return dialogHelper;
});

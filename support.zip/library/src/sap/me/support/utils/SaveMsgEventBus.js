sap.ui.define([
    "sap/ui/base/Object"
], function(
    BaseObject
) {
    "use strict";


    /**
     * Purpose: Fix eventbus shortcoming.
     * Sovle Problem:
     *  1.Subscribing event and publish msg concurrently, msg will get lost when msg is published faster
     *  2.In some cases, it need to consume previous msg when subscription was bulit. Such as switch overview card to contact card in case detail, msg was published in overview cardsu, it won't publish again when bscription was bulit in contact card.
     */
    let SaveMsgEventBus = BaseObject.extend("sap.me.support.SaveMsgEventBus", {

        constructor: function() {
            this._oEventBus = sap.ui.getCore().getEventBus();
            this._oLatestMsgProvider = {};
        }

    });

    let instance = new SaveMsgEventBus();

    SaveMsgEventBus.prototype.subscribe = function(sChannelId, sEventId, fnFunction, oListener) {
        // subcription just build once. so it will always consume the latest msg.
        let oLatestMsg = this._oLatestMsgProvider[sChannelId + "|" + sEventId];
        if (oLatestMsg) {
            fnFunction.call(oListener || this, sChannelId, sEventId, oLatestMsg);
        }

        this._oEventBus.subscribe(sChannelId, sEventId, fnFunction, oListener);
        return this;
    };

    SaveMsgEventBus.prototype.unsubscribe = function(sChannelId, sEventId, fnFunction, oListener) {
        this._oEventBus.unsubscribe(sChannelId, sEventId, fnFunction, oListener);
        return this;
    };

    SaveMsgEventBus.prototype.publish = function(sChannelId, sEventId, oData) {
        this.setLatestMsg(sChannelId, sEventId, oData);
        this._oEventBus.publish(sChannelId, sEventId, oData);
    };

    SaveMsgEventBus.prototype.setLatestMsg = function(sChannelId, sEventId, oData) {
        const oLastLatestMsg = this._oLatestMsgProvider[sChannelId + "|" + sEventId];
        oData.timestamp = Date.now();
        if (!oLastLatestMsg || oData.timestamp - oLastLatestMsg.timestamp > 0) {
            this._oLatestMsgProvider[sChannelId + "|" + sEventId] = oData;
        }
    };

    /**
     * use in test
     */
    SaveMsgEventBus.prototype.restore = function() {
        SaveMsgEventBus.instance = new SaveMsgEventBus();
        this._oEventBus.destroy();
    };

    return instance;

});

sap.ui.define([
    "./library",
    "sap/ui/core/mvc/View",
    "sap/ui/core/mvc/Controller",
    "sap/me/shared/BackendException",
    "sap/me/shared/UnauthorizedException",
    "sap/me/shared/util/getShellComponent",
    "sap/me/shared/util/ElementMap",
    "./utils/helper",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/utils/DetailPageCacheUtil",
], function(library, View, Controller, BackendException, UnauthorizedException, getShellComponent, ElementMap, helper, JSONModel, DetailPageCacheUtil) {
    "use strict";

    this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
    function getAuthCheckResult(pointer) {
        return jQuery.ajax("/backend/raw/support/CaseClassifiedCheckW7Verticle?pointer=" + pointer, {
            method: "GET",
            contentType: "application/json",
            dataType: "json",
        }).then((data) => {
            const res = {
                data,
                checkStatus: "authorized"
            };
            // 1. check authority
            if (data?.isAuthorized === false) {
                res.checkStatus = "unauthorized";
            }
            if (data?.isUserSimulating) {
                // 2. check classified
                if (data?.DssClassified === "X") {
                    res.checkStatus = "unauthorized";
                }
                // 3. check DataProtection
                if (data?.DataProtection === "CNDP" || data?.DataProtection === "EUDP" || data?.DataProtection === "SCDP") {
                    res.checkStatus = "unauthorized";
                }
            }
            return res;
        });
    }

    // because of the service now limitation,
    // and with split card in detail page
    // we need to cache the data to the dashboard model
    // this will decrease the request times and improve the performance
    // DO NOT add any event listener to the model, it will cause memory leak!
    async function cacheDataToDashboard(oShellComponent, pointer, section) {
        const detailData = await cacheDetailModel(oShellComponent, pointer);
        //        switch(section) {
        //            case "overview":
        //                break;
        //            case "attachments":
        //                break;
        //            case "details":
        //                // cache the system connection data
        // todo Time series problem, it will be triggered after the card loaded
        await cacheConnectionModel(oShellComponent, pointer, detailData?.systemNumber);
        //                break;
        //            case "solutions":
        //                break;
        //            case "contacts":
        //                break;
        //            case "actionplan":
        //                break;
        //            case "appointments":
        //                break;
        //            case "actionlog":
        //                break;
        //        }

    }

    function checkModelDataExist(model) {
        if (!model || !model.getData() || jQuery.isEmptyObject(model.getData())) {
            return false;
        }
        return true;
    }

    async function cacheDetailModel(oShellComponent, pointer) {
        const cacheDetailModel = DetailPageCacheUtil.getCacheDetailModel(pointer);
        const isModelDataExist = checkModelDataExist(cacheDetailModel);
        if (isModelDataExist) {
            return cacheDetailModel.getData();
        }
        const detailData = await DetailPageCacheUtil.refreshModelData(DetailPageCacheUtil.CacheModelTypes.CaseDetail, pointer);
        return detailData;
    }

    async function cacheConnectionModel(oShellComponent, pointer, systemNumber) {
        const cacheConnectionModel = DetailPageCacheUtil.getCacheConnectionModel(pointer);
        const isModelDataExist = checkModelDataExist(cacheConnectionModel);
        if (isModelDataExist) {
            return cacheConnectionModel.getData();
        }
        if (!systemNumber) {
            return;
        }
        const connectionData = await DetailPageCacheUtil.refreshModelData(DetailPageCacheUtil.CacheModelTypes.CaseDetailConnection, pointer, systemNumber);
        return connectionData;
    }

    return async(oDashboard) => {
        const oShellComponent = getShellComponent();
        const mArguments = oShellComponent.getRouter().getRouteInfoByHash(oShellComponent.getRouter().getHashChanger().getHash()).arguments;

        const checkValidation = async(pointer) => {
            const shellContent = oShellComponent.getRootControl().byId("shellContent");
            const detailPagePart = shellContent.getFlexContent();
            try {
                detailPagePart.setBusy(true);
                const res = await getAuthCheckResult(pointer);
                detailPagePart.setBusy(false);
                if (res.checkStatus === "unauthorized") {
                    return "unauthorized";
                }
                if (res.data?.caseStatus === "1") {
                    oDashboard.sections = oDashboard.sections.filter((i) => {
                        return i.name !== "appointments";
                    });
                }
                return null;
            } catch {
                detailPagePart.setBusy(false);
                return "error";
            }
        };

        const attachRouterEvent = () => {
            // add listener for case detail, check permissions every time enter the case detail page
            oShellComponent.getRouter().attachBeforeRouteMatched({}, async(oEvent) => {
                const params = oEvent.getParameters()?.arguments;
                if (params?.caseKey === mArguments.caseKey) {
                    const res = await checkValidation(params?.caseKey);
                    // const redirectHash = `case%2F${mArguments.caseKey}%2F${mArguments.section}`;
                    switch (res) {
                        case "error":
                            oShellComponent.getRouter().navTo("error");
                            break;
                        case "unauthorized":
                            oShellComponent.getRouter().navTo("unauthorized");
                            break;
                        default: {
                            await cacheDataToDashboard(oShellComponent, params.caseKey, params.section);
                            break;
                        }
                    }
                }
            }, this);
        };

        // false is not exist
        const checkCaseIsExist = async(pointer) => {
            return jQuery.ajax("/backend/raw/support/CasePermissionW7Verticle?action=COMPLETE&pointer=" + pointer, {
                method: "GET",
                contentType: "application/json"
            }).then(permissionCheck => {
                if (permissionCheck?.ResultTxt.indexOf("Incident not found") !== -1) {
                    return false;
                }
                return true;
            }).catch(e => {
                console.error(e);
            });
        };

        if (oDashboard.name === "caseDetail") {

            if (!mArguments.caseKey) {
                return Promise.reject("No Pointer!");
            }
            // when user in try-me if case pointer not exist in case list then should show error
            const mockList = ["002028376700055690902023", "002028376700056216442023", "002028376700056616282024", "002028376700056618622024", "002028376700056618712024", "002028376700056623952024", "002075129200000076822024"];
            if (helper.isTrial && mockList.indexOf(mArguments.caseKey) === -1) {
                return Promise.reject("Pointer not in Trial List!");
            }
            // check validation result
            const caseIsExist = await checkCaseIsExist(mArguments.caseKey);
            if (!caseIsExist) {
                return Promise.reject(new UnauthorizedException({message: `${this._i18n.getText("case_detail_not_found_message")} <a href=\"/cl\" target='_self' class=\"sapMLnk\">${this._i18n.getText("case_detail_not_found_link")}</a>`,
                    title: this._i18n.getText("case_detail_not_found"),
                    image: "/resources/sap/me/support/themes/img/NotFound.png"
                }));
            }
            const res = await checkValidation(mArguments.caseKey);
            switch (res) {
                case "error":
                    return Promise.reject(new BackendException("call validation failed", 500, {}));
                case "unauthorized":
                    return Promise.reject(new UnauthorizedException());
                default:
                    attachRouterEvent();
                    await cacheDataToDashboard(oShellComponent, mArguments.caseKey, mArguments.section);
                    return Promise.resolve();
            }

        }
    };
});


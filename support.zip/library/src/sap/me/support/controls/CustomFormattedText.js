/* eslint-disable no-undef */
sap.ui.define([
    "../library",
    "sap/m/FormattedText"
], function(library, FormattedText) {
    "use strict";

    const CustomFormattedText = FormattedText.extend("sap.me.support.controls.CustomFormattedText", {
        renderer: "sap.m.FormattedTextRenderer"
    });

    CustomFormattedText.prototype._renderingRules.ELEMENTS["table"] = 1;
    CustomFormattedText.prototype._renderingRules.ELEMENTS["td"] = 1;
    CustomFormattedText.prototype._renderingRules.ELEMENTS["tr"] = 1;
    CustomFormattedText.prototype._renderingRules.ELEMENTS["th"] = 1;
    CustomFormattedText.prototype._renderingRules.ELEMENTS["i"] = 1;
    CustomFormattedText.prototype._renderingRules.ELEMENTS["div"] = 1;
    return CustomFormattedText;

}, true);

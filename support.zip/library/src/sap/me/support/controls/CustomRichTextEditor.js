/* eslint-disable no-undef */
sap.ui.define([
    "../library",
    "sap/ui/richtexteditor/RichTextEditor"
], function(library, RichTextEditor) {

    const CustomRichTextEditor = RichTextEditor.extend("sap.me.support.controls.CustomRichTextEditor", {
        renderer: "sap.ui.richtexteditor.RichTextEditorRenderer",
        metadata: {
            library: "sap.me.support",
            properties: {
                statusbar: {type: "boolean", defaultValue: false},
                minHeight: {type: "int", defaultValue: 0},
                placeholder: {type: "string", defaultValue: ""},
            },
            events: {
                oninput: {
                    parameters: {
                        value: {
                            type: "string",
                        },
                        oldValue: {
                            type: "string",
                        },
                        id: {
                            type: "string",
                        }
                    }
                },
            }
        }
    });

    CustomRichTextEditor.prototype.init = function() {
        RichTextEditor.prototype.init.call(this);
        const linkPluginConfig = {
            link_default_target: "_blank", // tinymce >= 6
            default_link_target: "_blank",
            link_default_protocol: "https",
        }
        this.attachBeforeEditorInit((oEvent) => {
            // Get the current config
            // 4. Set Config of RTE
            // 4.1 Toolbar & Plugins
            const minHeight = this.getMinHeight();
            const statusbar = this.getStatusbar();
            const placeholder = this.getPlaceholder();
            const sToolbar = [" ","cut copy paste pastetext removeformat | undo redo | bold underline italic | outdent indent | bullist numlist | inserttable | link "," "];
            // "cut copy paste pastetext removeformat | undo redo | bold underline | outdent indent | bullist numlist | inserttable | link ";
            const sPlugins = ["autolink"];
            const oConfig = oEvent.getParameter("configuration");
            // Create a local config object
            const oLocalConfig = {
                content_style: ".mce-content-body[data-mce-placeholder] {position: relative;white-space: pre-line;font-style: italic;}",
                entity_encoding: "raw",
                toolbar: sToolbar,
                plugins: [...oConfig.plugins, ...sPlugins],
                // paste_data_images: false,
                valid_elements: "#p,b,strong,u,br,ol,ul,li,table,tr,td,code,a[href|target|title],i,em",
                paste_preprocess: function(plugin, args) {
                    const oRegExpStart = new RegExp(/<\s*span.*?>/g);
                    const oRegExpEnd = new RegExp(/<\s*\/\s*span\s*.*?>/g);
                    if (args.content && args.content.replace) {
                        args.content = args.content.replace(oRegExpStart, "<u>").replace(oRegExpEnd, "</u>");
                    }
                },
                formats: {
                    underline: {
                        inline: "u",
                        exact: true
                    }
                },
                ...linkPluginConfig,
                force_br_newlines: true,
                forced_root_block: false,
                convert_urls: true,
                statusbar: statusbar,
                branding: false,
                min_height: minHeight,
                placeholder: placeholder,
                elementpath: false,
            };

            // Merge local congig into real config
            jQuery.extend(oConfig, oLocalConfig);
        });

        this.attachEvent("change", (oEvent) => {
            const reg = /(<\/?p>)|(\n)|(\s)/gm;
            let value = oEvent.getParameters();
            for (const val in value) {
                if (val != "id") {
                    value[val] = value[val].replaceAll(reg, "");
                }
            }
            if (value.newValue !== value.oldValue) {
                this.fireEvent("oninput", oEvent.getParameters());
            }
        });
    };

    CustomRichTextEditor.prototype.onTinyMCEChange = function(oCurrentInst) {
        let sPrevValue = this.getValue(),
            sContent = oCurrentInst.getContent(),
            // sNewValue = this.getSanitizeValue() ? sanitizeHTML(sContent) : sContent;
            sNewValue = sContent;

        if ((sPrevValue !== sNewValue) && !this.bExiting) {
            this.setProperty("value", sNewValue, true); // suppress rerendering
            this.fireChange({oldValue: sPrevValue, newValue: sNewValue});
        }
    };

    CustomRichTextEditor.prototype.setValue = function(sValue) {
        try {
            let oEditorMapping = {};

            // default
            oEditorMapping[RichTextEditor.EDITORTYPE_TINYMCE] = RichTextEditor.EDITORTYPE_TINYMCE6;

            // other versions
            oEditorMapping[RichTextEditor.EDITORTYPE_TINYMCE4] = RichTextEditor.EDITORTYPE_TINYMCE4;
            oEditorMapping[RichTextEditor.EDITORTYPE_TINYMCE5] = RichTextEditor.EDITORTYPE_TINYMCE5;
            oEditorMapping[RichTextEditor.EDITORTYPE_TINYMCE6] = RichTextEditor.EDITORTYPE_TINYMCE6;

            // null and undefined are escaped and stringified with the code below.
            // That's why we need to ensure these are handled properly as empty values
            sValue = (sValue === null || sValue === undefined) ? "" : sValue;

            // if (this.getSanitizeValue()) {
            // 	Log.trace("sanitizing HTML content for " + this);
            // 	// images are using the URL validator support
            // 	sValue = sanitizeHTML(sValue);
            // }

            if (sValue === this.getValue()) {
                return this;
            }

            this.setProperty("value", sValue, true);
            sValue = this.getProperty("value");
            if (oEditorMapping[this.getEditorType()]) {
                this.setValue(sValue);
            } else {
                this.reinitialize();
            }
            return this;
        } catch (error) {
            console.error(error);
        }
    };

    CustomRichTextEditor.prototype.onAfterRendering = function() {
        RichTextEditor.prototype.onAfterRendering.call(this);
        console.log("RTE container id: ", this.getId());
        console.log("RTE dom: ", this.getDomRef());
        console.log("RTE should load tinymce: ", this._shouldLoadTinyMCE());
        console.log("RTE editor: ", this._oEditor);
    };


    return CustomRichTextEditor;

}, true);

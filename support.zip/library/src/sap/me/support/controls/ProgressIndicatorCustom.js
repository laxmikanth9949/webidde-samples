/* eslint-disable no-undef */
sap.ui.define([
    "../library",
    "sap/m/ProgressIndicator"
], function(library, ProgressIndicator) {
    "use strict";

    let ProgressIndicatorCustom = ProgressIndicator.extend("sap.me.support.controls.ProgressIndicatorCustom", {
        metadata: {
            library: "sap.me.support",
            properties: {
                toolTipSeparator: {
                    type: "boolean",
                    defaultValue: true
                },
                daysUsed: {
                    type: "string",
                    defaultValue: null
                },
                daysAvailable: {
                    type: "string",
                    defaultValue: null
                }
            },
            events: {
                press: {
                    parameters: {
                        daysUsed: {
                            type: "string"
                        },
                        daysAvailable: {
                            type: "string"
                        }
                    }
                },
                pressDaysUsed: {
                    parameters: {
                        daysUsed: {
                            type: "string"
                        }
                    }
                },
                pressDaysAvailable: {
                    parameters: {
                        daysAvailable: {
                            type: "string"
                        }
                    }
                }
            }
        },
        init: function() {
            ProgressIndicator.prototype.init.apply(this, arguments);
            this.attachBrowserEvent("click", function() {
                if (!this.getToolTipSeparator()) {
                    this.firePress({
                        daysUsed: this.getDaysUsed(),
                        daysAvailable: this.getDaysAvailable()
                    });
                }
            });
        },
        renderer: "sap.m.ProgressIndicatorRenderer"
    });

    ProgressIndicatorCustom.prototype.onAfterRendering = function() {
        let arrEventsBar = jQuery._data($("#" + this.getId() + "-bar")[0], "events");
        let arrEventsRemainingBar = jQuery._data($("#" + this.getId() + "-remainingBar")[0], "events");
        if (this.getToolTipSeparator()) {
            if (!arrEventsBar || arrEventsBar["click"].length === 0) {
                $("#" + this.getId() + "-bar").click(function() {
                    this.firePressDaysUsed({
                        daysUsed: this.getDaysUsed()
                    });
                }.bind(this));
            }
            if (!arrEventsRemainingBar || arrEventsRemainingBar["click"].length === 0) {
                $("#" + this.getId() + "-remainingBar").click(function() {
                    this.firePressDaysAvailable({
                        daysAvailable: this.getDaysAvailable()
                    });
                }.bind(this));
            }
        }
        this._updateHoverableScenario();
        this._registerResizeHandler(ProgressIndicator.RESIZE_HANDLER_ID.SELF, this, this._onResize.bind(this));
    };

    return ProgressIndicatorCustom;

}, true);

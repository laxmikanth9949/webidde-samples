/* eslint-disable no-undef */
sap.ui.define([
    "../library",
    "sap/ui/core/Icon"
], function(library, Icon) {

    const CustomIcon = Icon.extend("sap.me.support.controls.CustomConnectionIcon", {
        renderer: "sap.ui.core.IconRenderer",
        metadata: {
            library: "sap.me.support",
            properties: {
                iconType : {type: "string", defaultValue: ""},
                connectionOpen: {type: "boolean", defaultValue: false},
                accessDataError: {type: "string", defaultValue: ""},
                accessDataAuthorized: {type: "boolean", defaultValue: false},
                accessDataMaintained: {type: "boolean", defaultValue: false}
            },
        }
    });

    CustomIcon.prototype.onBeforeRendering = function(oEvent) {
        Icon.prototype.onBeforeRendering.call(this, oEvent);
        let src, color = "";
        switch (this.getIconType()) {
            case "connection":
                src = this.getConnectionOpen() ? "sap-icon://connected" : "sap-icon://disconnected";
                color = this.getConnectionOpen() ? "Neutral" : "Critical";
                break;
            case "access":
                if (!this.getAccessDataError() && this.getAccessDataAuthorized() && this.getAccessDataMaintained()) {
                    src = "sap-icon://unlocked";
                    color = "Neutral";
                } else {
                    src = "sap-icon://locked";
                    color = "Critical";
                }
                break;
        }
        this.setSrc(src);
        this.setColor(color);
    };


    return CustomIcon;

}, true);

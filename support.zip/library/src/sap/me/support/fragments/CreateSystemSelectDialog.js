sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/me/cards/model/models",
    "sap/m/FormattedText",
    "../utils/helper",
    "../utils/Constants",
    "sap/me/support/model/formatter",
    "../utils/CreationHelper",
    "sap/me/support/utils/engineerMemo/index"
], function(BaseObject, Fragment, JSONModel, Filter, FilterOperator, models, FormattedText, helper, Constants, formatter, CreationHelper, engineerMemo) {
    "use strict";
    const {ProductMemoUtil} = engineerMemo;

    return BaseObject.extend("sap.me.support.fragments.CreateSystemSelectDialog", {

        formatter: formatter,

        constructor: function(that) {
            this.creationCard = that;
            this._oView = that.getCard();
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this.currentLoginUser = this.creationCard._oUserModel.getData();
            this.currentLoginCustomer = this.creationCard._oCustomerModel.getData();
            this.iconTabBarModel = new JSONModel({
                selectedKey: "recent"
            });
            this.systemSelectionFilterItems = new JSONModel({
                systemType: "",
                leadingProduct: "",
                dataCenterText: "",
                dataProcessRestriction: "",
                isFavorite: [{
                    keyValue: "all",
                    textValue: this._i18n.getText("all")
                }, {
                    keyValue: "true",
                    textValue: this._i18n.getText("yes")
                }, {
                    keyValue: "false",
                    textValue: this._i18n.getText("no")
                }],
                // X means included
                notSelectable: [{
                    keyValue: "all",
                    textValue: this._i18n.getText("all")
                }, {
                    keyValue: "",
                    textValue: this._i18n.getText("included")
                }, {
                    keyValue: "X",
                    textValue: this._i18n.getText("excluded")
                }],
                selectedKeys: {
                    systemType: "all",
                    leadingProduct: "all",
                    dataCenterText: "all",
                    dataProcessRestriction: "all",
                    isFavorite: "all",
                    notSelectable: "all",
                }
            });

        },

        /**
         * @description handle too many results
         */
        formatSystemNumber: function(oSystemNumber, oIsOutOfRange) {
            if (!oSystemNumber) {
                return;
            }
            const showWarning = this.creationCard.fragmentControllers.BasicInformationStep.data.system.system2manyResultsWarningVisible;
            // judge by isOutOfRange is true and systemNumber equals 0
            if (oIsOutOfRange && oSystemNumber === "0") {
                this.creationCard.fragmentControllers.BasicInformationStep.data.system.system2manyResultsWarningVisible = true;
                return;
            }
            // set the messageStrip false
            if (showWarning) {
                this.creationCard.fragmentControllers.BasicInformationStep.data.system.system2manyResultsWarningVisible = false;
            }
            return oSystemNumber.replace(/^0*/g, "");
        },

        onSearch: function() {
            this.getFilters();
            this.getSelectionFilterItemsData();
            this.systemIconTab.getItems().forEach((item, index) => {
                if (index < 2) {
                    item.getContent()[0].getBinding("items")?.filter(this.recAndFavTabFilters);
                }
            });
            this.systemTable.filter(this.allTabFilters);
        },

        onPressFavoriteForSystem: function(oEvent) {
            const oSystem = oEvent.getSource().getBindingContext("$this.odata")?.getObject() || oEvent.getSource().getBindingContext("systemSelectionList")?.getObject();
            const selectItem = oEvent.getSource().getParent();

            if (oSystem.notSelectable || oSystem.NotSelectFlag) {
                sap.m.MessageBox.error(this._i18n.getText("createIssueSysSelect_add_favorite_error"));
                return;
            }
            if (CreationHelper.selectedCustomerIsSupported()) {
                sap.m.MessageBox.error(this._i18n.getText("createIssueSysSelect_supported_add_favorite_error"));
                return;
            }
            selectItem.setBusy(true);
            $.ajax("/backend/odata/support/SystemSearch", {
                method: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    systemNumber: oSystem.systemNumber || oSystem.Name,
                    isFavorite: !oSystem.isFavorite
                })
            }).done(() => {
                this.systemTable.getBinding("items").refresh();
                this.getRecentAndFavList();
                sap.m.MessageToast.show(this._i18n.getText(
                    oSystem.isFavorite ? "createIssueSysSelect_remove_favorite"
                        : "createIssueSysSelect_add_favorite"
                ));
            }).fail(() => {
                sap.m.MessageBox.error(this._i18n.getText(
                    oSystem.isFavorite ? "createIssueSysSelect_remove_favorite_error"
                        : "createIssueSysSelect_add_favorite_error"
                ));
            }).always(() => {
                selectItem.setBusy(false);
            });
        },

        getFilters: function() {
            this.recAndFavTabFilters = [];
            this.allTabFilters = [];
            this.allTabFilters.push(new Filter({
                filters: [
                    // for mock data using "S0018132425" for the following condition
                    new Filter({
                        path: "uname",
                        operator: FilterOperator.EQ,
                        value1: this.creationCard.selectedCutAndSuserInfo.suserNumber
                    }),
                    new Filter({
                        path: "customerNumber",
                        operator: FilterOperator.EQ,
                        value1: this.creationCard.selectedCutAndSuserInfo.customerNum
                    })
                ],
                and: true
            }));

            // searchBox filter
            const sQuery = this.searchTxtFilterValue = this.searchBoxModel.getProperty("/value").trim();
            if (sQuery) {
                const aCustomerFilter = new Filter({
                    path: "searchText",
                    operator: FilterOperator.EQ,
                    value1: sQuery
                });
                const recTabFilterProperties = ["Value", "Name", "Desc1"];
                const aCustomerOtherTabFilters = recTabFilterProperties.map(item => new Filter({
                    path: item,
                    operator: FilterOperator.Contains,
                    value1: sQuery,
                    caseSensitive: false
                }));
                this.allTabFilters.push(aCustomerFilter);
                this.recAndFavTabFilters.push(new Filter({
                    filters: aCustomerOtherTabFilters,
                    and: false
                }));
            }


            // selection filter items
            const tabKey = this.iconTabBarModel.getProperty("/selectedKey");
            if (tabKey === "all") {
                const selectedKeys = this.systemSelectionFilterItems.getProperty("/selectedKeys");

                const aFilterItemsSelection = Object.entries(selectedKeys)
                    .map(([key, value]) => {
                        if (value === "all") {
                            return null;
                        } else if (value === "" && key === "notSelectable") {
                            return new Filter({
                                path: key,
                                operator: FilterOperator.NE,
                                value1: "X",
                                caseSensitive: true
                            });
                        }
                        return new Filter({
                            path: key,
                            operator: FilterOperator.EQ,
                            value1: value,
                            caseSensitive: true
                        });

                    })
                    .filter(filter => filter !== null);

                if (aFilterItemsSelection.length !== 0) {
                    this.allTabFilters.push(new Filter({
                        filters: aFilterItemsSelection,
                        and: true
                    }));
                }
            }
        },

        // get selection filter items data
        getSelectionFilterItemsData: function() {
            // mock condition filter
            // let queryData = "?$filter=uname eq 'S0018132425' and customerNumber eq '0001208936'"
            let queryData = `?$filter=uname eq '${this.creationCard.selectedCutAndSuserInfo.suserNumber}' and customerNumber eq '${this.creationCard.selectedCutAndSuserInfo.customerNum}'`;
            if (this.searchTxtFilterValue) {
                queryData = queryData + ` and searchText eq '${this.searchTxtFilterValue}'`;
            }
            $.ajax("/backend/raw/support/SystemSearchFilterItemsVerticle" + queryData, {
                method: "GET",
                contentType: "application/json"
            }).done((result) => {
                const data = this.systemSelectionFilterItems.getData();
                const requestData = {
                    systemType: result.filter(item => {
                        return item.systemType;
                    })[0].systemType,
                    leadingProduct: result.filter(item => {
                        return item.leadingProduct;
                    })[0].leadingProduct,
                    dataCenterText: result.filter(item => {
                        return item.dataCenterText;
                    })[0].dataCenterText,
                    dataProcessRestriction: result.filter(item => {
                        return item.dataProcessRestriction;
                    })[0].dataProcessRestriction,
                };
                // add request data to json model data
                Object.assign(data, requestData);
                this.systemSelectionFilterItems.setData(data);
            });
        },

        // get recent and favorite list data
        getRecentAndFavList: function() {
            let queryData = `?$filter=Uname eq '${this.creationCard.selectedCutAndSuserInfo.suserNumber}' and Type eq 'SYSTEM_RECENT'`;
            $.ajax("/backend/raw/support/CaseF4HelpW7Verticle" + queryData, {
                method: "GET",
                contentType: "application/json"
            }).done((result) => {
                const customerNum = this.creationCard.selectedCutAndSuserInfo.customerNum || "";
                const filterResults = result.filter(item => item.CustomerNbr === customerNum);

                const favList = filterResults.filter(item => item.Category === "FAVORITE");
                const recentList = filterResults.filter(item => item.Category === "RECENT").map(v => {
                    return {
                        isFavorite: !!favList.find(i => i.Name === v.Name),
                        ...v
                    };
                });

                this._oView.setModel(new JSONModel({
                    rec: recentList,
                    fav: favList
                }), "systemSelectionList");

                if (this.recAndFavTabFilters?.length) {
                    this.systemIconTab.getItems().forEach((item, index) => {
                        if (index < 2) {
                            item.getContent()[0].getBinding("items")?.filter(this.recAndFavTabFilters);
                        }
                    });
                }
            }).always(() => {});
        },

        onPressItem: function(oEvent) {
            const selectedKey = this.iconTabBarModel?.getProperty?.("/selectedKey");
            const sPreviousValue = this.creationCard.fragmentControllers.BasicInformationStep.data.system.info;
            const bindingKey = selectedKey === "all" ? "$this.odata" : "systemSelectionList";
            const systemInfo = oEvent.getSource().getBindingContext(bindingKey).getObject();
            const selectedSystemNumber = systemInfo.systemNumber || systemInfo.Name;
            const shortDesc = this.creationCard.fragmentControllers.BasicInformationStep.data.shortDesc || this.creationCard.fragmentControllers.Step0.data.shortDesc;
            // if selected system is the same as previous one, close dialog
            if (sPreviousValue && sPreviousValue.systemNumber === selectedSystemNumber) {
                this._oDialog.close();
                return;
            }

            const commonSystem = this.handleSelectedSystemData(systemInfo);
            const currentDisplayName = formatter.formatSystemDisplayName(`${commonSystem.systemId} - ${commonSystem.systemName}`);
            const installationNbr = commonSystem.installationNbr;
            const dataProcessRestriction = systemInfo?.dataProcessRestriction ? systemInfo.dataProcessRestriction : systemInfo.Desc2;

            const sNewValue = {
                currentDisplayName,
                systemNumber: commonSystem.systemNumber,
                installationNbr: installationNbr,
                dataProcessRestriction: dataProcessRestriction,
                systemId: commonSystem.systemId,
                systemName: commonSystem.systemName,
                systemURL: commonSystem.systemURL,
                isSystemCloud: commonSystem.isSystemCloud,
                leadingProduct : commonSystem.leadingProduct
            };
            // should be invoke after confirm system
            const afterSystemSelectedHook = () => {
                // when system is cloud system ,should disable the systemdetail
                this.getShowSystemDetailFlag(selectedKey).then((isShowSystemDetail) => {
                    if (isShowSystemDetail) {
                        this.callSystemInfo(systemInfo);
                    }
                }).catch(() => console.log("fail to get data from SystemTypeSet"));
                this.setDataProcessingRestrictionLabel();
                this.setSystemURLLabel();
                this.creationCard.resetTimeLineAfterStepOneValueChanged();
                this._checkIsAttachmentBlockedAndClassified();
                this.creationCard.deleteDraft();
                this.creationCard.sendSAPHanaCloudProductChange();
                this.cancelSelectSystemDialog();
            };
            const openWarningHook = () => {
                return !this.creationCard.compURLPrefillMode && (this.creationCard.fragmentControllers.BasicInformationStep.data.product.info || this.creationCard.fragmentControllers.BasicInformationStep.data.component.info);
            };
            const afterConfirmHook = () => {
                this.setCloudSystemDetailVisible(false);
                this.creationCard.fragmentControllers.BasicInformationStep.data.system.info = sNewValue;
                // clear product and product function and component input value
                this.creationCard.clearInputAfterSysOrProOrProFuncChange("system");
                this.creationCard._constructCompModel(this._oView);
                // must be executed after cleanup
                this.requestForProductAllList(true, shortDesc);
                afterSystemSelectedHook();
                this.creationCard.setCompAllNeedsModel();
            };
            const prefillAfterConfirmHook = () => {
                this.creationCard.fragmentControllers.BasicInformationStep.data.system.info = sNewValue;
                if (shortDesc.trim()) {
                    this.creationCard._constructCompModel(this._oView);
                    this.creationCard.setPrioritySelectLimit();
                    this.creationCard.handleIssuePriorityInputVisibility(true);
                    // if filled short description and system, then request system information and component data
                    this.creationCard.setCompAllNeedsModel();
                }
                afterSystemSelectedHook();
                this.creationCard.handleProcessAfterProSelection();
            };
            const afterCancelHook = () => {
                this.creationCard.fragmentControllers.BasicInformationStep.data.system.info = sPreviousValue;
            };
            this.creationCard.setSelectedValue(openWarningHook, this.creationCard.compURLPrefillMode ? prefillAfterConfirmHook : afterConfirmHook, afterCancelHook,
                this._i18n.getText("case_creation_input_change_warn_dialogue_title_issueInformation"),
                this._i18n.getText("short_desc_change_preview_warning_text"));
        },

        getShowSystemDetailFlag: async function(selectedKey) {
            if (selectedKey === "all") {
                const isSystemCloud = this.creationCard.fragmentControllers.BasicInformationStep.data.system.info.isSystemCloud === "X";
                return !isSystemCloud;
            }
            // if is recently or suggest should get iscloud form systemsearch
            const data = await jQuery.ajax(`/backend/raw/common/SupportProxy/odata/svt/systemdatasrv/SystemTypeSet('${this.chosenSystemBasicInfo.systemNumber}')?$format=json`, {
                method: "GET",
                contentType: "application/json",
                datatype: "json",
            });
            const isSystemCloud = data?.d?.type !== "On-Premise";
            return !isSystemCloud;
        },

        setCloudSystemDetailVisible: function(visible) {
            // if is clould system, shoud disable system detail
            this.creationCard._oSystemInformationModel.setProperty("/isMessageStripVisible", visible);
            this.creationCard._oSystemInformationModel.setProperty("/isSystemAccessDataVisible", visible);
            this.creationCard._oSystemInformationModel.setProperty("/isSystemConnectionVisible", visible);
            this.creationCard.handleSystemInformationVisibility(true);
        },

        callSystemInfo: async function(systemInfo) {
            this.creationCard.handleSystemInformationVisibility(true);
            let oPreparedSystem = this.prepareSystemDataForSelectionHandling(systemInfo);
            this.creationCard.fragmentControllers.BasicInformationStep.data.system.info.installationNbr = oPreparedSystem.InstallationNbr;
            this.creationCard.getInstallationData();
            this.systemSelectionInformationSetVisible();
            this.getRampUpFlag(oPreparedSystem.SystemNbr);
            if (oPreparedSystem?.SWType === "ONPREM") {
                await this.setSystemText(oPreparedSystem);
            }
        },

        systemSelectionInformationSetVisible: function() {
            // change the visibility according to the software class type
            const swType = this.creationCard._oIssueInformationModel.getProperty("/installationData")?.SWType || "";
            switch (swType) {
                case "GIGYA":
                    this.creationCard._oSystemInformationModel.setProperty("/isSystemAccessDataVisible", true);
                    this.creationCard._oSystemInformationModel.setProperty("/isSystemConnectionVisible", true);
                    this.creationCard._oSystemInformationModel.setProperty("/isMessageStripVisible", false);
                    break;
                case "ONPREM":
                    this.creationCard._oSystemInformationModel.setProperty("/isSystemAccessDataVisible", true);
                    this.creationCard._oSystemInformationModel.setProperty("/isSystemConnectionVisible", true);
                    this.creationCard._oSystemInformationModel.setProperty("/isMessageStripVisible", true);
                    break;
                case "SFSF":
                case "CALLIDUS":
                case "CLOUD":
                case "ARIBA":
                case "QUALTRICS":
                    this.creationCard._oSystemInformationModel.setProperty("/isSystemAccessDataVisible", false);
                    this.creationCard._oSystemInformationModel.setProperty("/isSystemConnectionVisible", false);
                    this.creationCard._oSystemInformationModel.setProperty("/isMessageStripVisible", false);
                    break;
                default:
                    this.creationCard._oSystemInformationModel.setProperty("/isSystemAccessDataVisible", true);
                    this.creationCard._oSystemInformationModel.setProperty("/isSystemConnectionVisible", true);
                    this.creationCard._oSystemInformationModel.setProperty("/isMessageStripVisible", false);
                    break;
            }
        },

        setDataProcessingRestrictionLabel: function() {
            // set data processing
            const dataProcessRestriction = this.creationCard.fragmentControllers.BasicInformationStep.data.system.info?.dataProcessRestriction;
            if (dataProcessRestriction && dataProcessRestriction !== "NONE") {
                this.creationCard._oSystemInformationModel.setProperty("/isSystemDProcessRestrictionVisible", true);
                this.creationCard._oSystemInformationModel.setProperty("/sProcessRestrictionData", dataProcessRestriction);
            } else {
                this.creationCard._oSystemInformationModel.setProperty("/isSystemDProcessRestrictionVisible", false);
                this.creationCard._oSystemInformationModel.setProperty("/sProcessRestrictionData", "");
            }
        },

        // KNGMHM02-29124 - System Selection - show URL in Basic Info
        setSystemURLLabel: function() {
            // set systemURL
            const systemURL = this.creationCard.fragmentControllers.BasicInformationStep.data.system.info?.systemURL || "";
            const isSystemURLVisible = typeof systemURL === "string" && systemURL !== "";
            this.creationCard._oSystemInformationModel.setProperty("/isSystemURLVisible", isSystemURLVisible);
            this.creationCard._oSystemInformationModel.setProperty("/sSystemURL", systemURL);

        },


        getRampUpFlag: function(systemNum) {
            $.ajax("/backend/raw/support/CaseCreationRampUpSet?SystemNumber=" + systemNum, {
                method: "GET",
                contentType: "application/json"
            }).done((res) => {
                this.creationCard._oSystemInformationModel.setProperty("/RampUpFlagVisible", res.RampUpFlag === "X");
            }).fail(() => {
                this.creationCard._oSystemInformationModel.setProperty("/RampUpFlagVisible", false);
            });
        },

        setSystemText: async function(systemInfo) {
            let oData;
            try {
                oData = await $.ajax("/backend/raw/support/CaseSystemInfoVerticle?SystemNumber=" + systemInfo.SystemNbr, {
                    method: "GET",
                    contentType: "application/json",
                });
            } catch (e) {
                this._setTextAccessConnectionInfo();
                return;
            }

            let bVisible = this.creationCard._oIssueInformationModel.getProperty("/installationData").SWType === "ONPREM";
            if (!oData.AccessDataMaintained || !oData.ConnectionOpen) {
                this.creationCard._oSystemInformationModel.setProperty("/isMessageStripVisible", bVisible);
            } else {
                this.creationCard._oSystemInformationModel.setProperty("/isMessageStripVisible", false);
            }
            let oAccessConnectionValueObject = this.getAccessConnectionInfoValueObject(oData);
            oData.smaintainedconnections = "";
            oData.suploadedconnection = "";
            let connectiondata = JSON.parse(oData.ConnectionJSON);
            let today = new Date();
            today.setMonth(today.getMonth() + 1);
            let todaysdate = today.getFullYear() + this.formatTimetoString(today.getMonth()) + this.formatTimetoString(
                today.getDay()) + this.formatTimetoString(today.getHours()) + this.formatTimetoString(today.getMinutes())
                + this.formatTimetoString(today.getSeconds());

            if (connectiondata.length !== 0) {
                oData.textSystemConnection = "case_creation_system_info_incident_system_status_opened_json";
                let formatuploadedconnection = String(connectiondata[0].UPLOADTS); // formatter.formatTimestamp (String (connectiondata[0].UPLOADTS), "DATE");
                oData.suploadedconnection = this._i18n.getText("case_creation_system_info_incident_system_status_connection_datauploaded", formatuploadedconnection);
                for (let i = 0; i < connectiondata.length; i++) {
                    let closetext = "case_creation_system_info_incident_system_status_connection_closedeat";
                    if (Number(todaysdate) < connectiondata[i].TOTS) {
                        closetext = "case_creation_system_info_incident_system_status_connection_closeat";
                    }
                    let validto = String(connectiondata[i].TOTS); // formatter.formatTimestamp (String (connectiondata[i].TOTS), "DATE");
                    oData.smaintainedconnections += this._i18n.getText(closetext, [connectiondata[i].OPENCON, validto]);
                }
            }
            oData.sHrefAccessData = "/seca/" + oData.Sysnr;
            oData.sHrefSystemConnection = "/remoteconnectivity/" + oData.Sysnr;
            oData.systemDetailLink = "/systemdetail/" + oData.Sysnr;
            this._setTextAccessConnectionInfo(
                this._i18n.getText(oAccessConnectionValueObject.textAccessData),
                this._i18n.getText(oAccessConnectionValueObject.panel_systemInformation_link_accessData),
                this._i18n.getText(oAccessConnectionValueObject.textSystemConnection),
                this._i18n.getText(oAccessConnectionValueObject.panel_systemInformation_link_systemConnection),
                oData
            );
        },

        formatTimetoString: function(stime) {
            return (stime < 10 ? "0" : "") + stime;
        },

        prepareSystemDataForSelectionHandling: function(oSystemRaw) {
            // 1. Create and populate the system object
            let oSystem = {
                SystemNbr: oSystemRaw.SystemNumber || oSystemRaw.SystemNbr || oSystemRaw.Name || oSystemRaw.systemNumber || "",
                SystemId: typeof oSystemRaw.SystemId === "undefined" && typeof oSystemRaw.systemId === "undefined" ? oSystemRaw.Value.split("-")[0].replace(/(\s*$)/g, "") : oSystemRaw.SystemId || oSystemRaw.systemId,
                LongSystemID: oSystemRaw.LongSystemID,
                CustomerNbr: oSystemRaw.CustomerNbr || oSystemRaw.Customer || oSystemRaw.customerNumber || "",
                DPRest: oSystemRaw.DPRest || oSystemRaw.Desc2 || oSystemRaw.EUDPFlag || "",
                InstallationNbr: oSystemRaw.InstallationNbr || oSystemRaw.KeyValue || oSystemRaw.Installation || oSystemRaw.installationNumber || "",
                SWClass: oSystemRaw.SWClass || oSystemRaw.softwareClass,
                LeadingProduct: oSystemRaw.leadingProduct || oSystemRaw.Desc1 || oSystemRaw.productText,
            };

            // 2. Add Software type to system object
            if (oSystemRaw.SWType || oSystemRaw.softwareType) {
                oSystem.SWType = (oSystemRaw.SWType === "SF" || oSystemRaw.softwareType === "SF") ? "SFSF" : oSystemRaw.SWType || oSystemRaw.softwareType;
            } else if (oSystemRaw.Swkla) {
                oSystem.SWType = (oSystemRaw.Swkla === "SF") ? "SFSF" : oSystemRaw.Swkla;
            } else {
                oSystem.SWType = "";
            }

            // 3. Add System Name to system object
            if (oSystemRaw.SystemName || oSystemRaw.systemName) {
                oSystem.SystemName = oSystemRaw.SystemName || oSystemRaw.systemName;
            } else if (oSystemRaw.SystemTxt) {
                oSystem.SystemName = oSystemRaw.SystemTxt.split("-").length > 1 ? oSystemRaw.SystemTxt.split("-")[1].trim() : oSystemRaw
                    .SystemTxt;
            } else if (oSystemRaw.Value) {
                oSystem.SystemName = oSystemRaw.Value.split("-").length > 1 ? oSystemRaw.Value.split("-")[1].trim() : oSystemRaw.Value;
            } else {
                oSystem.SystemName = "";
            }

            // 3. Return the prepared system
            return oSystem;
        },

        _setTextAccessConnectionInfo: function(sTextAccessData, sLinkAccessData, sTextSystemConnection, sLinkSystemConnection, oData) {
            this.creationCard._oSystemInformationModel.setProperty("/sTextAccessData", sTextAccessData || "");
            this.creationCard._oSystemInformationModel.setProperty("/sLinkAccessData", sLinkAccessData || "");
            this.creationCard._oSystemInformationModel.setProperty("/sHrefAccessData", oData?.sHrefAccessData || "");
            this.creationCard._oSystemInformationModel.setProperty("/sTextSystemConnection", sTextSystemConnection || "");
            this.creationCard._oSystemInformationModel.setProperty("/sLinkSystemConnection", sLinkSystemConnection || "");
            this.creationCard._oSystemInformationModel.setProperty("/sHrefSystemConnection", oData?.sHrefSystemConnection || "");
            this.creationCard._oSystemInformationModel.setProperty("/smaintainedconnections", oData?.smaintainedconnections || "");
            this.creationCard._oSystemInformationModel.setProperty("/suploadedconnection", oData?.suploadedconnection || "");
            this.creationCard._oSystemInformationModel.setProperty("/systemDetailLink", oData?.systemDetailLink || "");
            this.creationCard._oSystemInformationModel.setProperty("/accessDataMaintained", oData?.AccessDataMaintained || "");
            this.creationCard._oSystemInformationModel.setProperty("/connectionOpen", oData?.ConnectionOpen || "");
        },

        getAccessConnectionInfoValueObject: function(oData) {
            let oValueObject = {
                textAccessData: "",
                panel_systemInformation_link_accessData: "",
                accessDataIsVisible: true,
                textSystemConnection: "",
                panel_systemInformation_link_systemConnection: "",
                statusTypeAccess: "Success",
                statusTypeConnection: "Success",
                statusCode: 0
            };
            if (oData.AccessDataError.length > 0) {
                oValueObject.accessDataIsVisible = false;
                oValueObject.statusType = "Error";
            } else {
                switch (oData.AccessDataAuthorized) {
                    case true:
                        // Access data maintained
                        if (oData.AccessDataMaintained) {
                            oValueObject.textAccessData = "case_creation_system_info_incident_system_status_maintained";
                            oValueObject.panel_systemInformation_link_accessData = "case_creation_system_info_clickToOpen";
                            oValueObject.statusTypeAccess = "Success";
                            oValueObject.statusCode = 1;
                        } else {
                            oValueObject.textAccessData = "case_creation_system_info_incident_system_status_missing";
                            oValueObject.panel_systemInformation_link_accessData = "case_creation_system_info_clickToMaintain";
                            oValueObject.statusTypeAccess = "Error";
                            oValueObject.statusCode = 2;
                        }
                        break;
                    case false: // No authorization
                        if (!oData.AccessDataMaintained) {
                            oValueObject.textAccessData = "case_creation_system_info_incident_system_status_missing_no_auth";
                            oValueObject.statusTypeAccess = "Success";
                            oValueObject.statusCode = 3;
                        } else {
                            oValueObject.textAccessData = "case_creation_system_info_incident_system_status_maint_no_auth";
                            oValueObject.statusTypeAccess = "Error";
                            oValueObject.statusCode = 3;
                        }
                        break;
                    default:
                        oValueObject.accessDataIsVisible = false;
                        oValueObject.statusTypeAccess = "Error";
                        break;
                }
            }

            oValueObject.textSystemConnection = oData.ConnectionOpen ? "case_creation_system_info_incident_system_status_opened" : "case_creation_system_info_incident_system_status_closed";
            oValueObject.panel_systemInformation_link_systemConnection = oData.ConnectionOpen ? "case_creation_system_info_clickToOpenConnection" : "case_creation_system_info_clickToMaintain";

            if (oData.ConnectionOpen) {
                oValueObject.statusTypeConnection = "Success";
            } else {
                oValueObject.statusTypeConnection = "Error";
            }

            return oValueObject;
        },

        handleSelectedSystemData: function(systemInfo) {
            return this.chosenSystemBasicInfo = {
                customerNumber: systemInfo.customerNumber || systemInfo.CustomerNbr || "",
                suserId: systemInfo.uname || systemInfo.Uname,
                systemId: systemInfo.systemId || systemInfo.Value?.split("-")[0].trim(),
                systemNumber: systemInfo.systemNumber || systemInfo.Name,
                systemName: systemInfo.systemName || systemInfo.Value?.split("(")[0].substring(5).trim() || "",
                systemType: systemInfo.systemType || systemInfo.Value?.substring(0, systemInfo.Value.length - 1).split("(")[1].trim(),
                systemURL: systemInfo.cloudURL || systemInfo.CloudUrl || "",
                installationNbr: systemInfo.installationNumber || systemInfo.KeyValue,
                leadingProduct: systemInfo.leadingProduct || systemInfo.Desc1,
                isSystemCloud: systemInfo.isSystemCloud || ""
            };
        },

        initData: function() {
            this.getRecentAndFavList();
            this.getFilters();
            this.getSelectionFilterItemsData();
            this.systemTable.filter(this.allTabFilters);
            this.setDefaultTabKey();
        },

        openSystemDialog: function() {
            if (this._oDialog) {
                this._oDialog.open();
                this.searchBoxModel.setProperty("/value", "");
                this.initData();
                // clear the previous system info
                delete this.chosenSystemBasicInfo;
                delete this.chosenSystemAvaInfo;
            } else {
                const dialog = Fragment.byId("CreateSystemSelectDialogFragment", "CreateSystemSelectDialog");
                if (dialog) {
                    dialog.setVisible(false);
                    this._oView.removeDependent(dialog);
                    dialog.destroy();
                }
                return Fragment.load({
                    id: "CreateSystemSelectDialogFragment",
                    name: "sap.me.support.fragments.CreateSystemSelectDialog",
                    controller: this
                }).then(Dialog => {
                    this._oDialog = Dialog;
                    this._oView.addDependent(this._oDialog);
                    // dialog : [2] element - "IconTabBarSystem"
                    //          [2] item - "All" tab
                    //          [2] element - "systemSelectionTable"
                    this.systemTable = this._oDialog.getContent()[2].getItems()[2].getContent()[2];
                    this.systemIconTab = this._oDialog.getContent()[2];
                    this._oDialog.open();
                    this._oDialog.setModel(this.searchBoxModel = new JSONModel({
                        value : ""
                    }), "$this.searchBox");
                    this._oDialog.setModel(this.iconTabBarModel, "$this.iconTabBar");
                    this._oDialog.setModel(this.systemSelectionFilterItems, "systemSelectionFilterItems");
                    this.initData();
                });
            }
        },

        getDefaultTabKey: function() {
            const systemSelectionListModel = this._oView.getModel("systemSelectionList");
            const data = systemSelectionListModel.getData();
            if (data?.rec?.length) {
                return "recent";
            }
            if (data?.fav?.length) {
                return "favorite";
            }
            return "all";
        },

        setDefaultTabKey: function() {
            const selectedKey = this.getDefaultTabKey();
            this.iconTabBarModel.setProperty("/selectedKey", selectedKey);
        },

        cancelSelectSystemDialog: function() {
            if (this.chosenSystemBasicInfo) {
                this.checkSystemAvailability();
            }
            this._oDialog?.close();
        },

        checkSystemAvailability: function() {
            this.creationCard.oCard.getContent().getItems()[2].setBusy(true);

            // hide the warning msg script at the beginning
            this.creationCard.fragmentControllers.BasicInformationStep.data.system.systemMsgStripVisible = false;
            $.ajax("/backend/odata/support/CloudSystemStatus?$filter=(uName eq '" + this.chosenSystemBasicInfo.suserId + "' and systemNumber eq '" + this.chosenSystemBasicInfo.systemNumber + "')", {
                method: "GET",
                contentType: "application/json"
            }).done((result) => {
                // returns nothing means this system status is good, no error events occur
                if (result.value.length > 0) {
                    let eventTime = this.formatSystemAffectedEventTime(result.value[0].eventStartTime);
                    this.chosenSystemAvaInfo = {
                        cloudOutageType: result.value[0].typeText,
                        cloudOutageTypeCode: result.value[0].type,
                        eventId: result.value[0].eventID,
                        eventTime: eventTime,
                        originalEventTime: result.value[0].eventStartTime,
                        date: eventTime.toLocaleDateString(),
                        time: eventTime.toLocaleTimeString(),
                    };
                    this.showChosenSystemWarningPerformance();
                    // swa ATL dialog open
                    this.creationCard.swaServiceEvent.swaATLDialogOpen(this.chosenSystemBasicInfo.leadingProduct, this.chosenSystemAvaInfo);
                }
            }).fail(() => {
                // do nothing just let it go
            }).always(() => {
                this.creationCard.oCard.getContent().getItems()[2].setBusy(false);
            });
        },

        showChosenSystemWarningPerformance : async function() {
            // show warning the msg script of the chosen system above the selection label
            this.creationCard.fragmentControllers.BasicInformationStep.data.system.systemMsgStripVisible = true;
            const systemName  = this.creationCard._oIssueInformationModel.getProperty("/isDraftCase") ? this.creationCard.fragmentControllers.BasicInformationStep.data.system.info.currentDisplayName : this.chosenSystemBasicInfo.systemId + "-" + this.chosenSystemBasicInfo.systemName;
            const cacLink = `<a href='/systemsprovisioning/availability' target='_blank' rel="noopener noreferrer">${this._i18n.getText("createIssueSysSelect_msgStripCAC")}</a>`;
            const warningText = this._i18n.getText("createIssueSysSelect_msgStrip", [
                this.chosenSystemAvaInfo.cloudOutageType,
                systemName,
                this.chosenSystemAvaInfo.date,
                this.chosenSystemAvaInfo.time,
                cacLink
            ]);
            this.creationCard.fragmentControllers.BasicInformationStep.data.system.systemMsgStripText = warningText;


            // open a msg Box for warning
            const msgBoxText = this._i18n.getText("createIssueSysSelect_msgBoxText", [
                systemName,
                this.chosenSystemAvaInfo.cloudOutageType,
                this.chosenSystemAvaInfo.date,
                this.chosenSystemAvaInfo.time,
                cacLink
            ]);
            const action = await this.alertSystemDownTimeMessage(msgBoxText);
            switch (action) {
                case "Subscribe":
                    this.checkSystemSubscribe();
                    // swa ATL subscribe click
                    this.creationCard.swaServiceEvent.swaATLSubscribePressed(this.chosenSystemBasicInfo.leadingProduct, this.chosenSystemAvaInfo);
                    break;
                case "ReportDifferentIssue":
                    // swa ATL Create case report a different issue
                    this.creationCard.swaServiceEvent.swaATLCaseCreationPressed(this.chosenSystemBasicInfo.leadingProduct);
                    break;
            }
        },

        alertSystemDownTimeMessage : function(msgBoxText) {
            return new Promise((resolve,reject) => {
                sap.m.MessageBox.alert(new sap.m.FormattedText({
                    htmlText: msgBoxText
                }), {
                    title: `${this._i18n.getText("createIssueSysSelect_msgBoxTitle",[this.chosenSystemBasicInfo.systemName])}`,
                    styleClass: "sapMeSystemMessageBox",
                    actions: [this._i18n.getText("createIssueSysSelect_msgBoxReportDifferentIssue"),
                        this._i18n.getText("createIssueSysSelect_msgBoxSubscribeToOutage")
                    ],
                    emphasizedAction: this._i18n.getText("createIssueSysSelect_msgBoxSubscribeToOutage"),
                    initialFocus: null,
                    textDirection: sap.ui.core.TextDirection.Inherit,
                    onClose: (sAction) => {
                        resolve(sAction === this._i18n.getText("createIssueSysSelect_msgBoxSubscribeToOutage") ? "Subscribe" : "ReportDifferentIssue");
                    }
                });
            });
        },

        formatSystemAffectedEventTime: function(oTime) {
            return new Date(oTime.substring(0, 4), parseInt(oTime.substring(4, 6)) - 1, oTime.substring(
                6, 8), oTime.substring(8, 10), oTime.substring(10, 12), oTime.substring(12, 14));
        },

        checkSystemSubscribe: function() {
            this.creationCard.oCard.getContent().getItems()[2].setBusy(true);
            $.ajax("/backend/raw/support/CaseSystemSubscribeVerticle", {
                method: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    EmailEnabled: true,
                    SmsEnabled: false,
                    TenantId: this.chosenSystemBasicInfo.systemNumber,
                    Contacts: [{
                        ContactId: this.currentLoginUser.userName.substring(1)
                    }],
                    Events: [{
                        EventId: this.chosenSystemAvaInfo.eventId
                    }]
                })
            }).done(() => {
                this.showSubscribeMessageBox("success");
            }).fail(() => {
                this.showSubscribeMessageBox("exit");
            }).always(() => {
                this.creationCard.oCard.getContent().getItems()[2].setBusy(false);
            });
        },

        /**
         * @description subscribe messageBox
         * @param {*} status: success | exit
         */
        showSubscribeMessageBox: function(status) {
            let link = `<a href='/systemsprovisioning/getNotified' rel="noopener noreferrer" target='_blank'>${this._i18n.getText("createIssueSysSelect_subscribe_here")}</a>`;
            const message = {
                success: {
                    title: this._i18n.getText("createIssueSysSelect_subscribe_successMsgTitle"),
                    text: this._i18n.getText("createIssueSysSelect_subscribe_successMsgText", [
                        this.currentLoginUser.firstName + " " + this.currentLoginUser.lastName,
                        models.getCustomerModel().getData().email,
                        link
                    ])
                },
                exit: {
                    title: this._i18n.getText("createIssueSysSelect_subscribe_existMsgTitle"),
                    text: this._i18n.getText("createIssueSysSelect_subscribe_existMsgText", [
                        this.currentLoginUser.firstName + " " + this.currentLoginUser.lastName,
                        models.getCustomerModel().getData().email,
                        link
                    ])
                }
            };
            const {
                title,
                text
            } = message[status];
            sap.m.MessageBox.alert(new FormattedText({
                htmlText: text
            }), {
                title: title,
                styleClass: "sapMeSystemMessageBox",
                actions: [this._i18n.getText("createIssueSysSelect_subscribe_return")],
                onClose: () => {}
            });
        },

        defineEventTrackTypeForSysSelected: function() {
            return {
                recent: "User (Recently Used)",
                favorite: "User (Favorite)",
                all: "User (All)"
            }[this.iconTabBarModel.getProperty("/selectedKey")];
        },

        // products
        requestForProductAllList: function(shouldSendAdobe, shortDesc) {
            if (!this.isSystemAndShortDesInput(shortDesc)) {
                shouldSendAdobe && this.creationCard.swaServiceEvent.systemSelected(this.defineEventTrackTypeForSysSelected(), "notAvailable", "Step Basic Information");
                return;
            }
            const systemNr = this.creationCard.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber;
            this.creationCard._constructProductModel(this.creationCard.oCard);
            this.creationCard.oCard.getContent().getItems()[2].setBusy(true);
            this._productAllListRequest = this.creationCard.getAllProductList(systemNr).then(data => {
                this.creationCard.oCard.getContent().getItems()[2].setBusy(false);
                const productList = data.product;
                if (productList?.length > 0) {
                    this.tagRecentlyUsedProducts(productList);
                    productList.sort(CreationHelper.productCompare);
                    this.creationCard._oProductModel.setProperty("/allData", productList);
                    this.creationCard._oProductModel.setProperty("/productFilters", this.transferArrayToArraySet(productList, "DisplayName"));
                    this.creationCard._oProductModel.setProperty("/softerFilters", this.transferArrayToArraySet(productList, "SoftwareProduct"));
                    this.creationCard._oProductModel.setProperty("/relationshipTypeFilters", this.transferArrayToArraySet(productList, "RelationshipType"));
                    // put all product functions into the model
                    this.creationCard._oProductFunctionModel.setProperty("/allProductFunctions", data.productFunction);
                    this.creationCard.handleIssueProductInputVisibility(true);

                    // request for product suggest
                    this.requestForProductSuggestList(productList);

                    this.creationCard.setTextDescriptionModel("case_creation_issue_system_product_description", "case_creation_issue_system_product_description_reminder");
                } else {
                    this.creationCard.handleIssueProductInputVisibility(false);
                    this.creationCard.setTextDescriptionModel("case_creation_issue_system_component_description", "case_creation_issue_system_component_description_reminder");
                }
                this.creationCard.fragmentControllers.BasicInformationStep.handleProcessAfterSysSelection();
                shouldSendAdobe && this.creationCard.swaServiceEvent.systemSelected(this.defineEventTrackTypeForSysSelected(), productList, "Step Basic Information");
            });
        },

        transferArrayToArraySet: function(array, key) {
            return Array.from(new Set(array.map(item => item[key]))).map(keyItem => {
                if (keyItem) {
                    return {textValue: keyItem};
                }
            });
        },

        tagRecentlyUsedProducts: function(resAllList) {
            const recentProductList = this.creationCard._oUserProfileInfoModel.getProperty("/recentProductList");
            resAllList.forEach(item => {
                item.Recently = recentProductList.includes(item.ModelNumber) && item.RelationshipType !== "Service";
            });
        },

        requestForProductSuggestList: function(productAllList) {
            this.creationCard._oProductModel.setProperty("/productInputBusy", true);
            const systemNbr = this.creationCard.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber;
            this._productPredictedRequest = this.creationCard.getPredictedProduct(systemNbr).then((resp) => {
                this.creationCard._oProductModel.setProperty("/productInputBusy", false);
                const res = resp?.results;
                const flagThreshold = resp?.conf_threshold_met;
                let productDisplayName = "";
                if (res?.length) {
                    this.tagRecommendedProducts(productAllList,res);
                    const suggestProduct = productAllList.find(item => item.ModelNumber === res[0].product_simcat_node_id);
                    // Recommended should be top of list
                    productAllList.sort(CreationHelper.productCompare);
                    this.creationCard._oProductModel.setProperty("/allData", productAllList);
                    // set the first suggested data for product box if product has no data
                    if (!this.creationCard.fragmentControllers.BasicInformationStep.data.product.info && flagThreshold === true) {
                        // should check entitlment, and if product is prevent,should show warning pop up
                        const checkResult = this.creationCard.handleEntitlementCheck(suggestProduct.CheckResult);
                        if(checkResult.prevent) {
                            return;
                        }

                        this.creationCard.trackProductChange("System(Predicted)",suggestProduct,0,"");
                        // this.creationCard._oIssueInformationModel.setProperty("/product",suggestProduct);
                        this.creationCard.fragmentControllers.BasicInformationStep.data.product.info = suggestProduct;
                        productDisplayName = suggestProduct.DisplayName;
                        this.creationCard.handleProcessAfterProSelection();
                        this.creationCard.getHotAndTrending(suggestProduct.ModelNumber);
                        this.creationCard.getProductFunctionList(suggestProduct.ModelNumber);
                    }
                }
                this.creationCard.processPPFCSelectionRecordsArr(productDisplayName ? ProductMemoUtil.predictNormal(productDisplayName) : ProductMemoUtil.noPredictProduct());
                this.setRecommendValueInOrder(productAllList,res);
            }).fail(() => {
                this.creationCard._oProductModel.setProperty("/productInputBusy", false);
                this.creationCard.processPPFCSelectionRecordsArr(ProductMemoUtil.noPredictProduct());
            });
        },

        tagRecommendedProducts: function(productAllList,suggestList) {
            let sugList = suggestList.map(item => item?.product_simcat_node_id);
            this.creationCard._oTrackingData.init_select_data.proudctSuggestList = sugList.filter(i => i && i?.trim());
            productAllList.forEach(item => {
                item.Recommended = sugList.includes(item.ModelNumber);
                if (item.Recommended) {
                    item.RecommendedIndex = sugList.findIndex(v => v === item.ModelNumber) + 1;
                }

            });
        },

        setRecommendValueInOrder: function(productAllList = [], suggestList = []) {
            const sugList = productAllList.filter(item => item?.ModelNumber && item.Recommended).map(item => item?.ModelNumber);
            const productPredictList = suggestList.filter(item => sugList.includes(item?.product_simcat_node_id)).map(item => item.product_simcat_node_id);
            this.creationCard._oProductModel.setProperty("/recommendedModelNumbers", productPredictList);
        },

        isSystemAndShortDesInput: function(shortDesc) {
            // only if system and shortDescription both have value then send Product request
            return !!this.creationCard.fragmentControllers.BasicInformationStep.data.system.info && !!shortDesc.trim();
        },

        _checkIsAttachmentBlockedAndClassified: function() {
            if (this.chosenSystemBasicInfo) {
                // the max length of systemNumber is 10
                let sysN = this.chosenSystemBasicInfo.systemNumber;
                let sysNumber = sysN.substring(sysN.length - 10, sysN.length);
                jQuery.ajax(`/backend/raw/support/CaseMessageDSSW7Verticle?customerId=${this.chosenSystemBasicInfo.customerNumber}&installationNumber=${this.chosenSystemBasicInfo.installationNbr}&sysNumber=${sysNumber}`, {
                    method: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    async: true,
                    success: (result) => {
                        // check is attachment blocked
                        const blockFlag = result.blockAttachmentsFlag;
                        // if yes, show the warnings and enable attachment upload file and show a warning messgae
                        // if no, able attachment upload file
                        // this.creationCard.fragmentControllers.CaseCreationAttachmentStep.timeLineItem.isFileTextVisible = !blockFlag;
                        this.creationCard._oSystemInformationModel.setProperty("/isMessageStripAttachVisible", blockFlag);

                        this.creationCard.fragmentControllers.CaseCreationAttachmentStep.blockFlagCheck(blockFlag);

                        // check show classified content or not
                        this.creationCard._oSystemInformationModel.setProperty("/isClassifiedContentButtonVisible", result.classifiedFlag);
                        this.creationCard._oSystemInformationModel.setProperty("/isClassifiedContentButtonEnabled", true);
                    }
                });
            }
        },

        formatDataProcessRestrictionText : function(dataProcessRestriction) {
            switch (dataProcessRestriction) {
                case "EUDP": return this._i18n.getText("createIssueSysSelect_Eu_data_processing");
                case "CNDP": return this._i18n.getText("createIssueSysSelect_Cn_data_processing");
                case "SCDP": return this._i18n.getText("createIssueSysSelect_Sc_data_processing");
                default: return "";
            }
        }
    });
});

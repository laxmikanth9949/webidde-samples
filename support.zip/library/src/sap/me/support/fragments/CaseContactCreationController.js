sap.ui.define([
    "sap/me/support/fragments/CaseContactController",
    "sap/ui/model/json/JSONModel",
    "sap/me/cards/model/models",
    "sap/me/support/utils/SaveMsgEventBus",
    "sap/me/support/utils/CreationEventType",
    "sap/me/support/utils/ContactRoleType",
    "sap/m/MessageBox"
], function(
    CaseContactController,
    JSONModel,
    models,
    SaveMsgEventBus,
    CreationEventType,
    ContactRoleType,
    MessageBox
) {

    "use strict";

    /**
     * @class
     */
    return CaseContactController.extend("sap.me.support.fragments.CaseContactCreationController", {

        /** ************************************************************************************** */
        /*                                    public method                                       */
        /** ************************************************************************************** */
        init : function() {
            this._oAttributeModel.setProperty("/isCanWrite",true);
            this.destory();
            SaveMsgEventBus.subscribe("sap.me.support.fragments.CreateReportAnIssueHeaderController", CreationEventType.SUPPORTED_USER_CHANGE, this._sUserChangeHandler = this._sUserChangeHandlerFunction.bind(this));
            SaveMsgEventBus.subscribe("sap.me.support.cards.CaseCreationCard", CreationEventType.SAP_HANA_CLOUD_PRODUCT_CHANGE, this._sapHanaCloudProductChangeHandler = this._sapHanaCloudProductChangeHandlerFunction.bind(this));
        },

        handleProfileDialogSubmitted : async function(changedProfile) {
            let changedUserProfile = changedProfile;
            if (changedProfile.timezoneTxt) {
                // update timezone in preference
                const preferenceTimezone = { "PREFERENCES.TIMEZONE": changedProfile.timezoneTxt };
                // set up data for user profile, no timezoneTxt
                changedUserProfile = Object.assign({}, changedProfile);
                delete changedUserProfile.timezoneTxt;
                await jQuery.ajax("/backend/raw/common/Settings",{
                    type: "PUT",
                    data:JSON.stringify(preferenceTimezone),
                });
            }
            await jQuery.ajax("/backend/raw/support/UserProfile",{
                type:"PUT",
                contentType: "application/json",
                data:JSON.stringify({profile: changedUserProfile}),
            });
            // update contact list display
            const changedContacts = this._getContactsAfterProfileChanged(changedProfile);
            if (changedContacts.length === 0) {
                return;
            }
            if (changedUserProfile.timezone) {
                MessageBox.information(this._i18n.getText("CaseTimeZoneUpdateSucessTip"));
            }

            this._oContactHelper._setContactModel(changedContacts);
            this.cardCtrl.oCard.updateDraft();
        },

        /**
         * transfer the timezone can be saved in w7, should use this._oContactHelper._getContactList() after
         * @returns {ContactList []}
         */
        setUpContactList: function() {
            // return this._oContactHelper._getContactList();
            return this._oContactHelper._getContactList().map((contact) => ({...contact, timezone: this.formatTimeZoneToUpdateContact(contact.timezone)}));
        },

        getContactHelperType : function() {
            return this.getPointer() ? "DRAFT_LOADING_CONTACT_" + this.getPointer() : "CREATION_CONTACT";
        },

        getBUInitValue : function() {
            if (this.getContactHelperType().startsWith("DRAFT")) {
                const filterList = this._oContactHelper.getContact(ContactRoleType.BUSINESS_USER);
                return filterList.length > 0 ? filterList[0].contact : "";
            }
            return "";
        },

        clearData : function() {
            this._oContactHelper.initContacts();
        },

        destory : function() {
            this._sUserChangeHandler && SaveMsgEventBus.unsubscribe("sap.me.support.fragments.CreateReportAnIssueHeaderController", CreationEventType.SUPPORTED_USER_CHANGE, this._sUserChangeHandler);
            this._sapHanaCloudProductChangeHandler && SaveMsgEventBus.unsubscribe("sap.me.support.cards.CaseCreationCard", CreationEventType.SAP_HANA_CLOUD_PRODUCT_CHANGE, this._sapHanaCloudProductChangeHandler);
        },

        getPointer : function() {
            return this.cardCtrl.oCard._oIssueInformationModel.getProperty("/pointer");
        },

        getView : function() {
            return this.cardCtrl.oCard.getCard();
        },

        setBusy : function(busy) {
            this.getView().getCardContent().setBusy(busy);
        },

        updateContact : async function(updateFunction) {
            updateFunction.call();
        },

        /** ************************************************************************************** */
        /*                                    format method                                       */
        /** ************************************************************************************** */
        isDisplayRoleRequired : function(sRole,sPriority) {
            return (sPriority === "1" && sRole === ContactRoleType.PRIMARY_CONTACT) || sRole === ContactRoleType.REPORTER || sRole === ContactRoleType.CREATED_BY;
        },

        /** ************************************************************************************** */
        /*                                    handler method                                      */
        /** ************************************************************************************** */
        _sUserChangeHandlerFunction : function(pListener, identifier, oData) {
            // In draft case, we will get reporter and create-by from database.
            // At that time, it also forbids changing customer or s-user and "supported" in customer model is invalid, so it need to distinguish draft case.
            if (!this.getContactHelperType().startsWith("DRAFT")) {
                this._buildReporter(oData);
                this._buildCreatedBy(oData);
            }
        },

        _sapHanaCloudProductChangeHandlerFunction : function(pListener, identifier, systemData) {
            this._updateBU(systemData);
        },

        /** ************************************************************************************** */
        /*                                    private method                                      */
        /** ************************************************************************************** */
        /**
        * call after system changed
        * show business user if one of system product is S/4HANA Cloud
        */
        _updateBU : async function(systemData) {
            const results = await this._querySystemDetail(systemData?.systemNumber);
            const isS4HANACloudLeadingProduct = results?.find(v => v.ProdNumber === "67837800100800007389");
            const aContacts = this._oContactHelper.getContact();
            const iIndex = aContacts.findIndex(contact => contact.role === ContactRoleType.BUSINESS_USER);

            if (iIndex > -1 && !isS4HANACloudLeadingProduct) {
                const oBU = aContacts[iIndex];
                if (oBU.userId) {
                    this._oLastBU = {...oBU};
                }
                this._oContactHelper.deleteContact(iIndex);
            } else if (iIndex === -1 && isS4HANACloudLeadingProduct) {
                this._oContactHelper.addContact(this._oLastBU ? this._oLastBU : this._oContactHelper.buildPredefinedContact(ContactRoleType.BUSINESS_USER));
            }
        },

        _querySystemDetail : async function(sysNum) {
            try {
                if (!sysNum) {
                    return [];
                }
                const systemDetail = await jQuery.ajax("/backend/raw/common/SupportProxy/odata/svt/systemdatasrv/SystemSoftWS4MSet", {
                    method: "GET",
                    data: {
                        $filter: `SYSNR eq '${sysNum}'`,
                        $format: "json"
                    }
                });
                return systemDetail?.d.results || [];
            } catch (e) {
                console.error(e);
            }
        },

        _buildReporter : async function(sUser) {
            // when s-user is empty, it means maybe it is doing something which will make s-user clean up.
            // don't worry about the delete action, it will create again when assign another s-user
            if (Object.keys(sUser.value ?? {}).length === 0) {
                this._oContactHelper.deleteContactByRole(ContactRoleType.REPORTER);
                this._oContactHelper.getContactModel().refresh();
                return;
            }

            // when s-user is not empty, it means it is initializing s-user or user want to change s-user.
            let reporter;
            if (!sUser.isSupported) {
                const profile = await this.getProfile();
                const userPreference = await this.getPreference();
                reporter = this._profileFormat2ContactFormat(profile, userPreference);
            } else {
                reporter = await jQuery.ajax("/backend/raw/support/CaseContactsW7Verticle",{
                    method:"GET",
                    data : {
                        $filter: `UserId eq '${sUser.value.suserNumber}'`
                    }
                }).then(result => result[0]);
            }
            this._oContactHelper.buildContactWithData(ContactRoleType.REPORTER,reporter);
            this._oContactHelper.getContactModel().refresh();

        },

        _buildCreatedBy : async function(sUser) {
            if (sUser.isSupported) {
                const profile = await this.getProfile();
                const userPreference = await this.getPreference();
                const createBy = this._profileFormat2ContactFormat(profile, userPreference);
                this._oContactHelper.buildContactWithData(ContactRoleType.CREATED_BY,createBy);
            } else {
                this._oContactHelper.deleteContactByRole(ContactRoleType.CREATED_BY);
            }
            this._oContactHelper.getContactModel().refresh();
        },

        _profileFormat2ContactFormat : function(oProfile, userPreference) {
            return {
                userId: this._getUserId(),
                contact: oProfile.userName,
                mobile: oProfile.secPhone,
                telephone: oProfile.phone,
                email: oProfile.email,
                available: true,
                timezone: userPreference["PREFERENCES.TIMEZONE"] || "",
            };
        },

        _getUserId : function() {
            const oCurrentUserInfo = models.getUserModel().getData();
            return oCurrentUserInfo.simulatedUser ?? oCurrentUserInfo.userName;
        },

    });
});

sap.ui.define([
    "sap/me/support/fragments/CaseContactController",
    "sap/me/support/utils/SaveMsgEventBus",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/utils/ContactRoleType",
    "sap/me/support/utils/DetailPageCacheUtil",
    "sap/m/MessageBox"
], function(
    CaseContactController,
    SaveMsgEventBus,
    Fragment,
    JSONModel,
    ContactRoleType,
    DetailPageCacheUtil,
    MessageBox
) {

    "use strict";

    const CaseContactEditController = CaseContactController.extend("sap.me.support.fragments.CaseContactEditController", {

        /** ************************************************************************************** */
        /*                                    public method                                        */
        /** ************************************************************************************** */
        init : function() {
            this.oContext.bUpdateAfterChanged = true;

            this._oCaseDetail = DetailPageCacheUtil.getCacheDetailModel(this.getPointer());
            this.getView().setModel(this._oCaseDetail, "CacheDetailModel");
            this.handleCaseDetailChange(this._oCaseDetail.getData());
            DetailPageCacheUtil.attachCacheChange(this.getPointer(), (data) => {
                this.handleCaseDetailChange(data.data);
            });
        },

        handleProfileDialogSubmitted : async function(changedProfile) {
            const changedContacts = this._getContactsAfterProfileChanged(changedProfile);
            if (changedProfile.timezoneTxt) {
                // update timezone in preference
                const preferenceTimezone = { "PREFERENCES.TIMEZONE": changedProfile.timezoneTxt };
                delete changedProfile.timezoneTxt;
                await jQuery.ajax("/backend/raw/common/Settings",{
                    type: "PUT",
                    data:JSON.stringify(preferenceTimezone),
                });
            }
            const payload = {profile: changedProfile};
            if (changedContacts.length > 0 ) {
                payload.caseInfo = {
                    action: "SEND2SAP",
                    pointer: this.getPointer(),
                    long_text: this._i18n.getText("ContactsSectionCard_defaultReplyText"),
                    contacts: changedContacts,
                    status: this.status
                };
            }

            await jQuery.ajax("/backend/raw/support/UserProfile",{
                type:"PUT",
                contentType: "application/json",
                data:JSON.stringify(payload),
            });
            if (changedContacts.length > 0) {
                this._oContactHelper._setContactModel(changedContacts);
            }
            if (changedProfile.timezone) {
                MessageBox.information(this._i18n.getText("CaseTimeZoneUpdateSucessTip"));
            }
        },

        getContactHelperType : function() {
            return "EDIT_CONTACT_" + this.getPointer();
        },

        getBUInitValue : function() {
            const filterList = this._oContactHelper.getContact(ContactRoleType.BUSINESS_USER);
            return filterList.length > 0 ? filterList[0].contact : "";
        },

        getPointer: function() {
            return this.cardCtrl._oContext.attributes.caseKey;
        },

        getView : function() {
            return this.cardCtrl.getCard();
        },

        setBusy : function(busy) {
            this.getView().getCardContent().setBusyIndicatorDelay(0);
            this.getView().getCardContent().setBusy(busy);
        },

        getStatus : function() {
            return this.status;
        },

        updateContact : async function(updateFunction) {
            try {
                this.setBusy(true);
                if (updateFunction) {
                    updateFunction.call();
                }
                await jQuery.ajax("/backend/raw/support/CaseUpdateVerticle",{
                    method : "PUT",
                    contentType: "application/json",
                    data :JSON.stringify({
                        action: "SEND2SAP",
                        pointer: this.getPointer(),
                        long_text: "Contact updated.",
                        contacts: this._oContactHelper.getContactModel().getData().ContactsSectionCard ?? [],
                        status: this.getStatus()
                    })
                });
                this._oContactHelper.getContactModel().refresh();
            } catch (e) {
                this._oUpdateFailDialog.open();
            } finally {
                this.setBusy(false);
            }
        },

        /** ************************************************************************************** */
        /*                                    handler method                                      */
        /** ************************************************************************************** */
        handleCaseDetailChange: async function(data) {
            if (!data) {
                return;
            }
            this.status = data.status;
            await this._oContactHelper.refreshContactListV2();
            this._oCaseDetail.setData(data);

            await this._buildBU(data);
        },

        onEditBU : function() {
            this._oEditBUContactDialog ? this._oEditBUContactDialog.open() : Fragment.load({
                name: "sap.me.support.fragments.EditBUContactDialog",
                controller: this
            }).then((oDialog) => {
                this.getView().addDependent(oDialog);
                this._oEditBUContactDialog = oDialog;
                oDialog.open();
            });
        },

        onContactDeleteBtnPressed: function(oEvent) {
            const oContact = oEvent.getSource().getBindingContext("$this.caseContacts").getObject();
            if (oContact.role === ContactRoleType.BUSINESS_USER) {
                const sIndex = this._oContactHelper.findIndexById(oContact.ID);
                this.updateContact(() => {
                    this._oContactHelper.replaceWithEmpty(sIndex);
                });
            } else {
                CaseContactController.prototype.onContactDeleteBtnPressed.call(this, oEvent);
            }
        },

        onBUSubmit : function() {
            this.updateContact().then(() => this._oEditBUContactDialog.close());
        },

        onBUCancel : function() {
            this._oEditBUContactDialog.close();
        },

        /** ************************************************************************************** */
        /*                                    private method                                      */
        /** ************************************************************************************** */
        // version compatible: case have been created couldn't filled the business user in case detail page.
        _buildBU : async function(caseDetail) {
            if (this._oContactHelper.getContact().find(contact => contact.role === ContactRoleType.BUSINESS_USER)) {
                return;
            }
            if (!caseDetail || !caseDetail.systemNumber) {
                return;
            }
            try {
                const data = await jQuery.ajax("/backend/raw/common/SupportProxy/odata/svt/systemdatasrv/SystemSoftWS4MSet", {
                    method: "GET",
                    data: {
                        $filter: `SYSNR eq '${caseDetail.systemNumber}'`,
                        $format: "json"
                    }
                });
                const isS4HANACloudLeadingProduct = data?.d?.results?.find(v => v.ProdNumber === "67837800100800007389");
                if (!isS4HANACloudLeadingProduct) {
                    return;
                }
                this._oContactHelper.addContact(this._oContactHelper.buildPredefinedContact(ContactRoleType.BUSINESS_USER));
            } catch {
                console.log("CaseCreateCompMapToProductW7 query fail, could not build BU");
            }
        },

    });

    /** ------------------------------- prototype method ------------------------------------ */

    /** ************************************************************************************** */
    /*                                    format method                                       */
    /** ************************************************************************************** */
    CaseContactEditController.prototype.formatIsDisplayAddContactBtn = function(sCanWrite, sCaseStatus) {
        return !!sCanWrite && !!sCaseStatus && "18Z".indexOf(sCaseStatus) < 0;
    };

    CaseContactEditController.prototype.formatIsDisplayValueHelperIcon = function(sRole, sCanWrite, sCaseStatus) {
        return CaseContactController.prototype.formatIsDisplayValueHelperIcon.call(this, sRole, sCanWrite) && !!sCaseStatus && "18Z".indexOf(sCaseStatus) < 0;
    };

    CaseContactEditController.prototype.formatIsDisplayDeleteIcon = function(sRole, sContact, bCanWrite, sPriority, sCaseStatus) {
        return CaseContactController.prototype.formatIsDisplayDeleteIcon.call(this, sRole, sContact, bCanWrite, sPriority) && !!sCaseStatus && "18Z".indexOf(sCaseStatus) < 0;
    };

    CaseContactEditController.prototype.formatIsDisplayDefaultCheckbox = function(sRole, sContact, sCaseStatus) {
        return CaseContactController.prototype.formatIsDisplayDefaultCheckbox.call(this, sRole, sContact) && !!sCaseStatus && "18Z".indexOf(sCaseStatus) < 0;
    };

    CaseContactEditController.prototype.formatIsDisplayEditIcon = function(sUserId, bCanWrite, sCaseStatus) {
        return CaseContactController.prototype.formatIsDisplayEditIcon.call(this, sUserId, bCanWrite) && !!sCaseStatus && "18Z".indexOf(sCaseStatus) < 0;
    };

    CaseContactEditController.prototype.formatIsDisplayBUEditIcon = function(sRole, bCanWrite, sCaseStatus) {
        return sRole === ContactRoleType.BUSINESS_USER && !!sCaseStatus && "18Z".indexOf(sCaseStatus) < 0;
    };

    CaseContactEditController.prototype.formatRoleToolTip = function(sRole) {
        return sRole === "Business User" ? this._i18n.getText("ContactsSectionCard_BUToolTip") : "";
    };

    return CaseContactEditController;
});

sap.ui.define([
    "../library",
    "sap/ui/base/Object",
    "sap/me/support/utils/ContactHelperFactory",
    "sap/me/support/fragments/ContactAddDialogValueHelpController",
    "sap/me/support/fragments/ContactListValueHelpController",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/utils/WorkTimeList",
    "sap/me/support/utils/UpdateFailedDialog",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/odata/v4/ODataModel",
    "sap/me/cards/model/models",
    "sap/ui/core/Fragment",
    "sap/me/support/utils/helper",
    "sap/me/support/utils/ContactRoleType",
    "sap/me/support/model/formatter",
    "sap/me/support/fragments/AddContactController",
    "sap/m/MessageBox"
], function(
    library,
    BaseObject,
    ContactHelperFactory,
    ContactAddDialogValueHelpController,
    ContactListValueHelpController,
    JSONModel,
    WorkTimeList,
    UpdateFailedDialog,
    ResourceModel,
    ODataModel,
    models,
    Fragment,
    helper,
    ContactRoleType,
    Formatter,
    AddContactController,
    MessageBox,
) {

    "use strict";

    const instance = BaseObject.extend("sap.me.support.fragments.CaseContactController", {

        constructor: function(cardCtrl) {
            this.cardCtrl = cardCtrl;
            this._constructorConstants();
            this._constructorContactList();
            this._constructorModel();
            this.init();
            this.getTimezoneList();
            this.addContactCtrl = new AddContactController(this);
        },

        /** ************************************************************************************** */
        /*                                    init method                                         */
        /** ************************************************************************************** */
        _constructorContactList: function() {
            this._oContactHelper = ContactHelperFactory.getContactHelper(this.getContactHelperType(), this.oContext = {
                sPointer: this.getPointer(),
                oView: this.getView(),
            });
            this.getView().setModel(this._oContactHelper.getContactModel(), "$this.caseContacts");
        },

        _constructorConstants: function() {
            this._oUpdateFailDialog = new UpdateFailedDialog(this.getView());
        },

        _constructorModel: function() {
            this.getView().setModel(this._oAttributeModel = new JSONModel(),"$this._oContactAttribute");
            this._oAttributeModel.setProperty("/profileHint", this._i18n.getText("UserProfileEditDialog_tips", ["#", "'"]));
            this.getView().setModel(this._oTimezones = new JSONModel({TimezoneCollection: []}), "$this._oTimezones");
            this.getView().setModel(this._oWorkTimeList = new JSONModel(), "$this._oProfileWorkTimeList");
            this.getView().setModel(new JSONModel({
                TimeFormatCollection: [
                    {key: "0", textKey: this._i18n.getText("userProfile_24HFormatText")},
                    {key: "1", textKey: this._i18n.getText("userProfile_12HFormatText")}
                ]
            }), "$this._oProfileTimeFormat");
            this.getView().setModel(new ResourceModel({
                bundle: this._i18n,
                supportedLocales: [""],
                fallbackLocale: ""
            }), "$this.i18n");
            this.getView().setModel(new ODataModel({
                serviceUrl: "/backend/odata/support/",
                synchronizationMode: "None",
                groupId: "$direct",
                operationMode: "Server"
            }), "$this.odata");
            this.getView().setModel(this._oUserProfileData = new JSONModel(), "$this._oProfileDataModel");
        },

        getTimezoneList: function() {
            // if timezone list exist
            if (this._oTimezones.getProperty("/TimezoneCollection").length !== 0) {
                return;
            }

            jQuery.ajax("/backend/raw/common/SupportProxy/odata/sfm/timezones", {
                method: "GET",
                contentType: "application/json",
                dataType: "json"
            }).then(timezones => {
                this._oTimezones.setProperty("/TimezoneCollection", timezones);
            });
        },

        formatTimezoneDescription: function(timezoneKey, timezoneList = []) {
            let timezone = timezoneList.filter(item => (item.IANATZONE === timezoneKey || item.TZONE === timezoneKey));
            // to compatiable with old timezone data
            // prefer use Etc/GMT as default timezone for old data, if no Etc/GMT data like CET, use first one
            return timezone.length === 1 ? timezone[0].IANATZONE : timezoneKey;
        },

        getProfile: async function() {
            return jQuery.ajax("/backend/raw/support/UserProfile");
        },

        getPreference: function() {
            return jQuery.ajax("/backend/raw/common/Settings/PREFERENCES");
        },

        /**
         * To compile old data and w7 logic, need to save tomezone like 'UTC' in backend
         * can delete this method when w7 is ready
         */
        formatTimeZoneToUpdateContact: function(zoneArea) {
            if(zoneArea){
                const tz = this._oTimezones.getProperty("/TimezoneCollection").find(item => item.IANATZONE === zoneArea);
                return tz?.TZONE || zoneArea;
            }
            return zoneArea;
        },

        /** ************************************************************************************** */
        /*                                    event handler                                       */
        /** ************************************************************************************** */
        onContactAddBtnPressed: function() {
            let defaultContact = this.getView().getModel("$this.caseContacts").getData().ContactsSectionCard.find(o => o.default_contact === true);
            if (defaultContact) {
                var defaultRecentlyUsed = this.addContactCtrl.addDialogModel.getProperty("/recentlyUsedContacts").find(o => o.email === defaultContact.email);
            }
            if (defaultRecentlyUsed) {
                defaultRecentlyUsed.default_recent_contact = true;
            }

            this.addContactCtrl.openDialog(this.getView().getModel("$this.caseContacts").getData().ContactsSectionCard);
        },

        onContactDeleteBtnPressed: function(oEvent) {
            let contactObj = oEvent.getSource().getBindingContext("$this.caseContacts").getObject();
            const index = this._oContactHelper.findIndexById(contactObj.ID);

            if (contactObj.default_contact) {
            this.displayConfirmDeleteContactPopup(contactObj, index);
            }
            else{
                this.updateContact(() => {
                    this._oContactHelper.deleteContact(index);
                });
            }

        },

        onDefaultContactSelected: function(oEvent) {
            let contactObj = oEvent.getSource().getBindingContext("$this.caseContacts").getObject();
            if(oEvent.getSource().getSelected()){
                MessageBox.warning(this._i18n.getText("DefaultContact_warning_message"), {
                    title: this._i18n.getText("DefaultContact_warning_title"),
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === "OK") {
                                contactObj.default_contact = true;
                                const index = this._oContactHelper.findIndexById(contactObj.ID);
                                let aContacts = this.addContactCtrl.addDialogModel.getProperty("/contact_list");
                                if(aContacts){
                                    let oContact = aContacts.find(o => o.default_contact === true && o.ID !== contactObj.ID);
                                    if(oContact){
                                        delete oContact.default_contact;
                                        let defaultRecentlyUsed = this.addContactCtrl.addDialogModel.getProperty("/recentlyUsedContacts").find(o => o.email === oContact.email);
                                        if (defaultRecentlyUsed) {
                                            defaultRecentlyUsed.default_recent_contact = false;
                                        }
                                    };
                                }
                                this.addContactCtrl.saveDefaultContact(contactObj);
                                this.getView().getModel("$this.caseContacts").refresh();
                            } else{
                                oEvent.getSource().setSelected(false);
                            }
                    }.bind(this)
                });
            }else{
                MessageBox.warning(this._i18n.getText("Remove_defaultContact_warning_message"), {
                    title: this._i18n.getText("Remove_defaultContact_warning_title"),
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === "OK") {
                            this.addContactCtrl.removeDefaultContact();
                            contactObj.default_contact = false;
                            let defaultRecentlyUsed = this.addContactCtrl.addDialogModel.getProperty("/recentlyUsedContacts").find(o => o.email === contactObj.email);
                            if (defaultRecentlyUsed) {
                                defaultRecentlyUsed.default_recent_contact = false;
                            }
                            this.getView().getModel("$this.caseContacts").refresh();
                        } else{
                            oEvent.getSource().setSelected(true);
                        }
                    }.bind(this)
                });
            }
        },

        displayConfirmDeleteContactPopup: function(contactObj, index){
            var that = this;
        			MessageBox.warning(this._i18n.getText("ConfirmDeleteContact_warning_message"), {
        			    title: this._i18n.getText("ConfirmDeleteContact_warning_title"),
        				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
        				emphasizedAction: MessageBox.Action.OK,
        				onClose: function (sAction) {
        				          if (sAction === "OK") {
                                    that.confirmDeleteDefaultContact(contactObj, index);
        							}
        				}
        			});


        },

        confirmDeleteDefaultContact: function(contactObj, index){
            let defaultRecentlyUsed = this.addContactCtrl.addDialogModel.getProperty("/recentlyUsedContacts").find(o => o.email === contactObj.email);
            if (defaultRecentlyUsed) {
                defaultRecentlyUsed.default_recent_contact = false;
            }

            this.addContactCtrl.removeDefaultContact();

            this.updateContact(() => {
                this._oContactHelper.deleteContact(index);
            });
        },

        onContactListValueHelpPressed: function(oEvent) {
            if (!this._oListValueHelpController) {
                this._oListValueHelpController = new ContactListValueHelpController(this);
            }
            const oSelectedContact = oEvent.getSource().getBindingContext("$this.caseContacts").getObject();
            this._oListValueHelpController.handleContactValueHelpOpen({ID: oSelectedContact.ID, role: oSelectedContact.role});
        },

        onProfileEditBtnPressed: async function() {
            // user profile data has timezone infomation(eg: UTC) of user
            const profile = await this.getProfile();
            // get information from preference, has timezone area information(eg: America/Bahia_Banderas or ETC/GMT)
            const userPreference = await this.getPreference();
            this._oPreviousUserProfile = {...profile, timezoneTxt: userPreference["PREFERENCES.TIMEZONE"] || ""};
            this._oUserProfileData.setData({...this._oPreviousUserProfile});

            this._oWorkTimeList.setProperty("/WorkTimeCollection", WorkTimeList[profile.timeFormat]);

            if (!this._oProfileDialog) {
                const frag = await Fragment.load({
                    name: "sap.me.support.fragments.UserProfileEditDialog",
                    controller: this
                });
                this.getView().addDependent(frag);
                this._oProfileDialog = frag;
            }
            this._oProfileDialog.open();
        },

        onProfileTimeFormatChanged: function(oEvent) {
            this._oWorkTimeList.setProperty("/WorkTimeCollection", WorkTimeList[oEvent.getSource().getSelectedKey()]);
        },

        onProfileDialogClosed: function() {
            this._oProfileDialog.close();
        },

        onProfileDialogSubmitted: async function() {
            const changedProfile = this._getProfileChanged();
            if (!changedProfile) {
                this._oProfileDialog.close();
                return;
            }
            this._oProfileDialog.setBusy(true);
            await this.handleProfileDialogSubmitted(changedProfile);
            this._oProfileDialog.setBusy(false);
            this._oProfileDialog.close();
        },

        onBUChange : function(oEvent) {
            const contactList = this._oContactHelper._getContactList();
            contactList.forEach(oContact => {
                if (oContact.role === ContactRoleType.BUSINESS_USER) {
                    const sNewValue = oEvent.mParameters?.newValue;
                    const finalValue = sNewValue === "" ? "" : (!/^C[CB][a-zA-Z0-9]{10}/.test(sNewValue) ? this._slastBUValue ?? this.getBUInitValue() : this._slastBUValue = sNewValue);
                    oContact["contact"] = finalValue;
                    oContact["userId"] = finalValue;
                }
            });
            this._oContactHelper._setContactModel(contactList);
        },

        onTimezoneSelectChange: function(oEvent) {
            const oNewTimezone = oEvent.getParameters().selectedItem.getBindingContext("$this._oTimezones").getObject();
            this._oUserProfileData.setProperty("/timezone", oNewTimezone.TZONE);
        },

        /** ************************************************************************************** */
        /*                                    public method                                       */
        /** ************************************************************************************** */
        updateRecentlyUsedContact : function() {
            if (!this.addContactCtrl) {
                return;
            }
            const rucc = this.addContactCtrl.calcRecentlyUsedContactCandidate();
            if (rucc.length > 0) {
                this.addContactCtrl.saveNewRecentlyUsedContact(rucc);
            }
        },


        /** ************************************************************************************** */
        /*                                    private method                                      */
        /** ************************************************************************************** */
        _getProfileChanged: function() {
            const changedProfile = {};
            const oCurrentUserProfile = this._oUserProfileData.getData();
            for (const k in oCurrentUserProfile) {
                if (oCurrentUserProfile[k] !== this._oPreviousUserProfile[k]) {
                    changedProfile[k] = oCurrentUserProfile[k];
                }
            }
            return changedProfile;
        },

        _getContactsAfterProfileChanged: function(changedProfile) {
            if (!changedProfile) {
                return [];
            }

            const needChangedFields = {};
            if (changedProfile.phone) {
                needChangedFields.telephone = changedProfile.phone;
            }
            if (changedProfile.secPhone) {
                needChangedFields.mobile = changedProfile.secPhone;
            }
            if (changedProfile.timezone || changedProfile.timezoneTxt) {
                // in case creation, save timezone like UTC formatter. in case detail, save timezone area like "Asia/Shanghai".
                // should delete after w7 fixed.
                if (this.cardCtrl.getMetadata().getName().includes("CaseCreation")) {
                    needChangedFields.timezone = changedProfile.timezone;
                } else {
                    needChangedFields.timezone = changedProfile.timezoneTxt;
                }
            }

            if (Object.keys(needChangedFields).length === 0) {
                return [];
            }

            const changedContacts = this._oContactHelper.getContact().map(item => {
                if (models.getCustomerModel().getData().userName === item.userId) {
                    Object.assign(item, needChangedFields);
                }
                return item;
            });
            return changedContacts;
        },

    });

    /** ------------------------------- prototype method ------------------------------------ */

    /** ************************************************************************************** */
    /*                                    format method                                       */
    /** ************************************************************************************** */
    // When constructing CaseEditContactController, it will set model to the view, and it will refresh view, then it will call format method. If format method is an instance method, it will throw error. Because instance doesn't construct finish, so format method need to be prototype method.
    instance.prototype.formatIsAddDialogSubmitBtnEnable = function(sContactName, sRole) {
        return !!sContactName && !ContactHelperFactory.isRoleDuplicate(sRole);
    };

    instance.prototype.formatIsDisplayValueHelperIcon = function(sRole, sCanWrite) {
        return !ContactHelperFactory.ROLE_MAP[sRole]?.hideValueHelpIcon && sCanWrite;
    };

    instance.prototype.formatIsDisplayDeleteIcon = function(sRole, sContact, bCanWrite, sPriority) {
        const bIsPrimaryAndPriorityIsNotVH = sRole !== ContactRoleType.PRIMARY_CONTACT || (!!sPriority && sPriority !== "Very High" && sPriority !== "1");
        return !ContactHelperFactory.ROLE_MAP[sRole]?.hideDeleteIcon
            && (!!sContact && !!sContact.trim())
            && bCanWrite
            && bIsPrimaryAndPriorityIsNotVH;
    };

    instance.prototype.formatIsDisplayDefaultCheckbox = function(sRole, sContact, bCanWrite) {
        const bIsNotprefilledRole = sRole !== ContactRoleType.PRIMARY_CONTACT && sRole !== ContactRoleType.SECONDARY_CONTACT && sRole !== ContactRoleType.SYSTEM_OPENER;
        return !ContactHelperFactory.ROLE_MAP[sRole]?.hideDeleteIcon
            && (!!sContact && !!sContact.trim())
            && bCanWrite
            && bIsNotprefilledRole;
    };

    instance.prototype.formatIsDisplayEditIcon = function(sUserId, bCanWrite) {
        const sIsCurrentLoginUser = models.getCustomerModel().getData().userName === sUserId;
        return sIsCurrentLoginUser && bCanWrite;
    };

    instance.prototype.formatIsNoPhoneWarningVisible = function(sPriority, sMobile, sTelephone, sRole, sContact) {
        const bIsVHPriority = sPriority === "Very High" || sPriority === "1";
        const bIsPhoneBlank = !sMobile && !sTelephone;
        const bIsPrimaryOrSecondary = sRole === ContactRoleType.SECONDARY_CONTACT || sRole === ContactRoleType.PRIMARY_CONTACT;
        return bIsVHPriority && bIsPhoneBlank && bIsPrimaryOrSecondary && !!sContact;
    };

    instance.prototype._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");

    return instance;
});

sap.ui.define([
    "../library",
    "sap/ui/base/Object",
    "sap/ui/core/routing/Router",
    "sap/me/shared/util/getShellComponent",
    "sap/me/shared/Models",
    "sap/m/MessageToast",
    "sap/me/support/utils/Constants",
    "sap/me/support/utils/helper",
    "sap/ui/model/resource/ResourceModel",
    "sap/m/MessageBox",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/utils/UpdateFailedDialog",
    "sap/me/support/utils/QualtricsService",
    "sap/me/support/fragments/PriorityAndImpactEditController",
    "sap/me/support/model/formatter",
    "sap/m/FormattedText",
    "sap/me/support/utils/AaEPService",
    "sap/me/support/fragments/CaseDetailReplyDialog",
    "sap/me/shared/util/getBrowserTabId",
    "sap/me/shared/util/getApplicationInstanceId",
    "sap/me/shared/util/getPreferredLanguage",
    "sap/ui/core/date/UI5Date",
    "sap/ui/core/format/DateFormat",
    "sap/me/support/requests/RequestLibrary",
    "sap/me/support/utils/DetailPageCacheUtil",
    "sap/ui/core/library",
    "sap/base/Log"
], function(
    library,
    BaseObject,
    Router,
    getShellComponent,
    SharedModels,
    MessageToast,
    Constants,
    helper,
    ResourceModel,
    MessageBox,
    Fragment,
    JSONModel,
    UpdateFailedDialog,
    QualtricsService,
    PriorityAndImpactEditController,
    formatter,
    FormattedText,
    AaEPService,
    CaseDetailReplyDialog,
    getBrowserTabId,
    getApplicationInstanceId,
    getPreferredLanguage,
    UI5Date,
    DateFormat,
    Request,
    DetailPageCacheUtil,
    CoreLib,
    Log,
) {

    "use strict";

    // the header controller does not actually need to be a fully fledged MVC controller! it is enough to be an
    // object that we can instantiate, e.g. inherited from UI5s sap.ui.base.Object prototype.
    return BaseObject.extend("sap.me.support.fragments.CaseDetailHeaderController", {

        _CONSTANTS: Constants,

        formatter: formatter,

        _oUserModel: SharedModels.getUserModel(),

        constructor : function(oDashboardController) {
            BaseObject.apply(this);

            // when being constructed (at the time the header is loaded), you will get access to the dashboard controller!
            this._oDashboardController = oDashboardController;
            this._oView = getShellComponent().getRootControl();
            this._oRouter = Router.getRouter("shellRouter");
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._oCustomerModel = SharedModels.getCustomerModel();
            /*
             * the static text must come from partner repo, not from frontend.
             * The header is still only a fragment that is loaded into shell so i18 is the model set from frontend
             */
            getShellComponent().getRootControl().setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "i18nSupport");

            // this._sResourceUri = sap.ui.require.toUrl("sap/me/support");

            this._oODataModel = SharedModels.getODataModel("support");
            this._oView.setModel(this._oView.getModel("i18nSupport"), "$this.i18n");

            this._failedDialog = new UpdateFailedDialog(this._oView);

            this._oPointer = this._oRouter.mMatchedRouteArguments.caseKey;




            /*
             *  load auth for case edit/delete
             */
            this._oView.setModel(this._oView._oContextModel = new JSONModel(), "$this.context");
            // this._oView.setModel(this._oView._ConnectionModel = new JSONModel(), "$this.connection");

            helper.currentUserPermission(this._oPointer,this._oView).then(() => {
                if (this._oView._oContextModel.getProperty("/isCanClose")) {
                    this.initFeedBackSurvey();
                }
            });
            this.dashboardId = this._oView.byId(this._oView.getId() + "--shellContent").getFlexContent();



            this._oEventBus = sap.ui.getCore().getEventBus();
            this._oEventBus.subscribe("sap.me.support.cards.CaseDiscussionCard", "overruleChange", () => {
                this._oODataModel.refresh();
            });
            this._oEventBus.subscribe("sap.me.support.cards.CaseDetailBusinessImpactCard", "editPriority", this.handleEditPriority.bind(this));
            this._oODataModel.attachDataReceived((oEvent) => {
                console.log("Data received from OData model", oEvent);
                // skip the logic if header object is not on current page
                if (!window.location.href.includes(this._oPointer)) {
                    return;
                }
                if (oEvent.getSource().getPath()?.includes("/CaseDetails")) {
                    helper.currentUserPermission(this._oPointer,this._oView);
                    oEvent.getSource().requestObject().then((data) => {
                        DetailPageCacheUtil.updateDetailCache(DetailPageCacheUtil.CacheModelTypes.CaseDetail, this._oPointer, data);
                        document.title = `Case ${data.incidentNumber}/${data.incidentYear} - ${data.subject} - SAP For Me`;
                    });
                }
            });

            this.setCacheModels();
            DetailPageCacheUtil.attachCacheChange(this._oPointer, (data) => {
                this.setCacheModels();
                switch (data.type) {
                    case DetailPageCacheUtil.EventType.Change:
                        this.handleCaseDetailChange(data.data);
                        break;
                }
            });
        },

        handleCaseDetailChange(data) {
            if (!data) {
                return;
            }
            this.refreshStatus(data.status, data.statusTxt, data.reporterId, data.incidentSource);
            // Priority and impact fragment intialization
            this._oPriority = data.priority;
            this._oImpactText = data.businessImpact;
            this._componentName = data.componentName;
            this._checkAaEPCase(data);
        },

        setCacheModels: function() {
            this.cacheDetailModel = DetailPageCacheUtil.getCacheDetailModel(this._oPointer);
            this._oView.setModel(this.cacheDetailModel, "CaseDetailHeader");
            this.cacheConnectionModel = DetailPageCacheUtil.getCacheConnectionModel(this._oPointer);
            this._oView.setModel(this.cacheConnectionModel, "CaseDetailConnection");
        },

        /** ************************************************************************************** */
        /*                                         Event Handlers                                 */
        /** ************************************************************************************** */

        handleEditPriority: function(oListener, identifier, data) {
            if (data.pointer === this._oPointer) {
                this.onPressEditPriorityAndImpact();
            }
        },

        onPressEditPriorityAndImpact: function() {
            // dialog model initial settings
            this._sViewHeaderFragmentId = this.dashboardId.sId;

            if (this._oPriorityAndImpactFragment) {
                this._oPriorityAndImpactEditController.reConstructFragment(new JSONModel({
                    pointer: this._oPointer,
                    priority: this._oPriority,
                    impactText: this._oImpactText
                }));
            }
            this.setPrioritySelectLimit();
        },

        closePriorityImpactEdit: function() {
            if (this._oPriorityAndImpactDialog) {
                this._oPriorityAndImpactDialog.close();
                this._oPriorityAndImpactEditController._priorityAndImpactModel.setProperty("/bizImpactText", "");
                this._oPriorityAndImpactEditController._oEditor.setValue("");
            }
        },

        openPriorityAndImpactDialog: function() {
            if (this._CaseDetailReplyDialog) {
                this._CaseDetailReplyDialog.closeDialog();
            }
            // initial change dialog loading
            if (this._oPriorityAndImpactDialog) {
                return this._oPriorityAndImpactDialog.open();
            }
            return Fragment.load({
                id: this._sPriorityAndImpactDialogId = ((this._sViewHeaderFragmentId ? this._sViewHeaderFragmentId : this._oView.getId()) + "-sPriorityAndImpactDialog"),
                name:"sap.me.support.fragments.PriorityAndImpactDialog",
                controller:this
            }).then((Dialog) => {
                this._oPriorityAndImpactDialog = Dialog;
                this._oView.addDependent(this._oPriorityAndImpactDialog);

                this._oPriorityAndImpactDialog.open();

                this._oPriorityAndImpactEditController = new PriorityAndImpactEditController(
                    this._oView,
                    this._oPriorityAndImpactDialog.getContent()[0],
                    new JSONModel({
                        pointer: this._oPointer,
                        priority: this._oPriority,
                        impactText: this._oImpactText
                    }));

                return Fragment.load({
                    id: this._oPriorityAndImpactFragmentId = this._sPriorityAndImpactDialogId + "-PriorityAndImpactFragment",
                    name: "sap.me.support.fragments.PriorityAndImpact",
                    controller: this._oPriorityAndImpactEditController
                });
            }).then((_oFragment) => {

                this._oPriorityAndImpactFragment = _oFragment;
                this._oView.addDependent(this._oPriorityAndImpactFragment);

                this._oPriorityAndImpactDialog.getContent()[0].addItem(_oFragment);

                this._oPriorityAndImpactEditController.createRichTextEditor();

                this._oPriorityAndImpactEditController.prioritySelectLimit(this._oPriorityLimit);
            });
        },

        setPrioritySelectLimit: async function() {
            if (!this._oPriorityLimit) {
                this._oPriorityLimit = await this.getPriorityLimit(this._componentName).then(data => data?.PrioLimit);
                this.openPriorityAndImpactDialog();
                return;
            }
            this._oPriorityAndImpactEditController.prioritySelectLimit(this._oPriorityLimit);
            this.openPriorityAndImpactDialog();
        },

        getPriorityLimit : async function(componentName) {
            try {
                return await jQuery.ajax("/backend/raw/support/CaseComponentW7Verticle", {
                    method: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    data : {
                        componentName : componentName
                    },
                });
            } catch (e) {
                console.log("fail to get priority limit");
            }
        },

        savePriorityImpactEdit: function() {
            // check input
            if (this._oPriorityAndImpactEditController.checkMandatoryInput()) {
                return MessageToast.show(`${this._i18n.getText("editPriority_inputValueCheckInfo")}`);
            }

            // deep copy
            let cacheContactsList = this._oPriorityAndImpactEditController.getContactsList();
            // prepare update data
            this._oPriorityAndImpactEditController.prepareSendingContactsData();
            this._oPriorityAndImpactDialog.setBusy(true);
            // prepare biz impact text
            let bitext = this._oPriorityAndImpactEditController.getBizImpactText();
            const priority = this._oPriorityAndImpactEditController._priorityAndImpactModel.getProperty("/priority");
            // send update
            return jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify({
                    action : "SEND2SAP",
                    pointer: this._oPointer,
                    bitext: bitext,
                    long_text: this._i18n.getText("editPriority_priority") + " " + priority + "<p/>" + this._i18n.getText("editBusiness_business") + " " + bitext,
                    priority: this._oPriorityAndImpactEditController.getFormattedPriorityLevel(),
                    contacts: this._oPriorityAndImpactEditController.getContacts(),
                    status: this._oSimpleStatus
                })
            }).then(() => {
                MessageToast.show(`${this._i18n.getText("editPriority_updateSuccess")}`);
                this._oEventBus.publish("sap.me.support.fragments.CaseDetailHeaderController", "statusChange", {status: this._oSimpleStatus ,priority: this._oPriorityAndImpactEditController.getPriority()});
                // TODO add refresh flag and refresh model in onAfterRendering
                this._oODataModel.refresh();
                this._oPriorityAndImpactDialog.close();
                this._oPriorityAndImpactEditController.refreshSubmitPriorityAndImpact();
                this._oPriorityAndImpactDialog.setBusy(false);
            }).catch(() => {
                this.failedDialogOpen();
                this._oPriorityAndImpactEditController.refreshFailPriorityAndImpact(cacheContactsList);
                this._oPriorityAndImpactDialog.setBusy(false);
            });
        },
        // close case or delete draft
        onPressCloseCase: function() {
            const data = this.cacheDetailModel.getData();
            this._subject = data.subject;
            this._component = data.component;
            this._priority = data.priority;
            this._status = data.status;
            this._createdAt = data.createdAt;
            this._caseSource = data.incidentSource;

            if (this._CaseDetailReplyDialog) {
                this._CaseDetailReplyDialog.closeDialog();
            }
            /*
            *  initial load feedback survey
            */
            MessageBox.show(this._oSimpleStatus === "1" ? `${this._i18n.getText("CreateDeleteDraft_message_content")}` : new FormattedText({htmlText: this._i18n.getText("caseCloseTipText",["#"])}), {
                title: this._oSimpleStatus === "1" ? this._i18n.getText("CreateDeleteDraft_message_title1") : this._i18n.getText("caseCloseTipTitle"),
                actions: [this._oSimpleStatus === "1" ? this._i18n.getText("delete") : "YES", this._oSimpleStatus === "1" ? MessageBox.Action.CANCEL : "NO"],
                onClose: (sAction) => {
                    if (sAction === "YES") {
                        this.closeCase();
                    } else if (sAction === this._i18n.getText("delete")) {
                        this.deleteDraft();
                    }
                }
            });
        },

        onPressExportPDF: function() {
            if (this._oPointer) {
                sap.m.URLHelper.redirect(this._CONSTANTS.PROD_CASE_EXPORT_TO_PFD + this._oPointer, true);
            }
        },

        onPressReplyBtn: function() {
            if (!this._CaseDetailReplyDialog) {
                this._CaseDetailReplyDialog = new CaseDetailReplyDialog(this);
            }
            this._CaseDetailReplyDialog.open();
        },

        navToSupport: function() {
            getShellComponent().getRouter()?.navTo("dashboard", {nameOrId: "servicessupport"});
        },

        onFavoriteCaseIconPressed: function(oEvent) {
            let oSource = oEvent.getSource();
            oSource.setBusy(true);
            const isFavourite = this.cacheDetailModel.getProperty("/isFavorite");
            Request.caseDetail.updateCaseDetail(this._oPointer, {isFavorite: !isFavourite}).then(() => {
                this.cacheDetailModel.setProperty("/isFavorite", !isFavourite);
            });
            this._updateUserModel().then(() => {
                oSource.setBusy(false);
            }).catch(() => {
                oSource.setBusy(false);
            });
        },

        onPressEditCaseInformation : function() {
            Router.getRouter("shellRouter").navTo("createIssue", {
                draftCasePointer: this._oPointer,
                section: "overview"
            });
        },

        /** ************************************************************************************** */
        /*                                    Handlers'  Functions                                */
        /** ************************************************************************************** */

        closeCase : function() {
            this._oView.setBusy(true);
            return jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify({
                    action: "CONFIRM",
                    pointer: this._oPointer,
                    long_text: this._i18n.getText("caseHaseBeenClosed"),
                    status: this._oSimpleStatus
                })
            }).then(() => {
                this._oView._oContextModel.setProperty("/isCanWrite", false);
                this._oView._oContextModel.setProperty("/isCanClose", false);
                this._oView.setBusy(false);
                MessageToast.show(`${this._i18n.getText("caseCloseSuccess")}`);
                this._oODataModel.refresh();
                this._oEventBus.publish("sap.me.support.fragments.CaseDetailHeaderController", "statusChange", {status: "Confirmed"});
                this.showFeedBackSurvey();
            }).catch(() => {
                this._oView.setBusy(false);
                this._failedDialog.open();
            });
        },

        deleteDraft : function() {
            this._oView.setBusy(true);
            jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify({
                    action: "COMPLETE",
                    pointer: this._oPointer,
                    draft_flag: "X"
                }),
                success: () => {
                    MessageToast.show(`${this._i18n.getText("CreateDeleteDraftSuccess")}`);
                    this._oView.setBusy(false);
                    this.navToSupport();
                },
                error: () => {
                    this._oView.setBusy(false);
                    this._failedDialog.open();
                }
            });
        },

        processLanguageCode : function() {
            let preferredLang = getPreferredLanguage();
            let lang = preferredLang ? preferredLang.toUpperCase() : sap.ui.core.Configuration.getLanguage().toUpperCase();
            let qualtricsLangList = {
                DE: "DE",
                JA: "JA",
                "ZH-CN": "ZH-S",
                ZH_CN:"ZH-S",
                "ZH-S": "ZH-S",
                FR : "FR",
                ES : "ES",
                PT : "PT"
            };
            return qualtricsLangList[lang] || "EN";
        },

        initFeedBackSurvey: function() {
            $.ajax("/backend/raw/support/CaseQualtricsAuthW7?pointer=" + this._oPointer, {
                method: "GET",
                contentType: "application/json"
            }).done((url) => {
                if (url) {
                    QualtricsService.initQualtricsSurvey(url, this);
                }
            }).fail(() => {
                // do nothing just let it go
            });
        },

        showFeedBackSurvey: function() {
            if (this._surveyUrl.w7pUrl) {
                this.openQualtricsIntercept();
            }
            if (this._surveyUrl.proUrl) {
                this.openProcessorSurvey();
            }
        },

        openQualtricsIntercept : function() {
        //    this.getLanguage ().then (preferredLanguage => {
            this.session_id = getApplicationInstanceId("getSupport",true);
            this.page_id = getBrowserTabId();
            let mParams = {
                CrmCustomerID: this._oCustomerModel.getProperty("/crmcustomernumber"),
                CaseId: +this._oPointer.slice(10, 20) + "/" + this._oPointer.slice(-4),
                Pointer: this._oPointer,
                Language: this.processLanguageCode(),
                source: "SIS",
                CaseSource: this._caseSource,
                Subject: this._subject,
                Component:this._component,
                CasePriority: this._priority,
                Status: this._status,
                OpenedDate: this._createdAt,
                Country: this._oCustomerModel.getProperty("/country"),
                CustomerEmail: this._oCustomerModel.getProperty("/email"),
                CustomerPhoneNumber: this._oCustomerModel.getProperty("/phone"),
                CompanyName: this._oCustomerModel.getProperty("/companyname"),
                UserName: this._oCustomerModel.getProperty("/userName"),
                APP_INSTANCE_ID: this.session_id,
                BROWSER_TAB_ID: this.page_id
            };
                // if window.QLT_MMI2S_PARAM clear it
            if (window.QLT_MMI2S_PARAM) {
                delete window.QLT_MMI2S_PARAM;
            }
            // if window.QLT_MMI1S_PARAM clear it
            if (window.QLT_MMI1S_PARAM) {
                delete window.QLT_MMI1S_PARAM;
            }

            window.QLT_LAUNCHPAD_PARAM = mParams;

            if (this.hasInterceptLoaded) {
                window.QSI.API.unload();
                // QSI.isDebug = true;
                window.QSI.API.load().done(window.QSI.API.run());
            }
            // });
        },

        getLanguage : function() {
            return jQuery.ajax("/backend/raw/common/Settings", {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
            }).then(data => data["PREFERENCES.LANGUAGE"]);
        },

        openProcessorSurvey : function() {
            let info = {
                Pointer: this._oPointer,
                Subject: this._subject,
                Info: "Sap For Me",
                Source: "Sap For Me",
                CaseID: +this._oPointer.slice(10, 20) + "/" + this._oPointer.slice(-4),
            };


            window.QLT_SN_CASE_PARAM = info;


            if (this.hasInterceptLoaded) {
                window.QSI.API.unload();
                window.QSI.API.load().done(window.QSI.API.run());
            }
        },

        _updateUserModel: function() {
            return jQuery.ajax("/backend/raw/core/User", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify(this._oUserModel.getData())
            }).fail(function() {
                Log.info("Could not update user model.");
            });
        },

        failedDialogOpen: function() {
            // load failed update dialog and copy the i18n model to the common one
            this._failedDialog = new UpdateFailedDialog(this._oView);
            this._oView.setModel(this._oView.getModel("i18nSupport"), "$this.i18n");
            this._failedDialog.open();
        },

        /**
         * if it is an open AaEP session, then load AaEP service
         */
        _checkAaEPCase: function(data) {
            if (data.aaEPDraftFlag !== "X" || data.aaEPSessStatus !== "Open / Running Sessions" || this.AaEPService) {
                return;
            }

            this.AaEPService = new AaEPService(null, this._oPointer, data.aaEPQuesUUID);
            this.AaEPService.setBusy = this._oView.setBusy.bind(this._oView);
            this.AaEPService.completeSessionCallback = (AaEPMessageText) => {
                this._oODataModel.refresh();
                if (!AaEPMessageText) {
                    return;
                }
                this._oEventBus.publish("sap.me.support.fragments.CaseDetailHeaderController", "AaEPCaseUpdated", {
                    AaEPMessageText,
                    priority: this.formatPriorityLevel(data.priority),
                    component: data.componentName,
                    subject: data.subject
                });
            };
            this.AaEPService.reconnectSession = async() => {
                const {AaEPMessageText} = await this.AaEPService.getChatDetailByQuesUUid(data.aaEPQuesUUID);
                // no need to update if get chat message failed
                if (AaEPMessageText === this._i18n.getText("case_creation_aaep_transcript_failed_msg")) {
                    return;
                }
                this.AaEPService.completeSessionCallback(AaEPMessageText);
                // this.AaEPService.startNewSession(sessionData, AaEPMessageText);
            };
        },



        /** ************************************************************************************** */
        /*                                          Formatters                                    */
        /** ************************************************************************************** */
        /**
             * @description status mapping statusTxt
             *      1: Not Set to SAP
             *      8: CONFIRM
             *      Z: Confirmed Automatically
             */
        refreshStatus: function(status, statusTxt, oCreater, incidentSource) {
            this._oSimpleStatus = status;
            // When its Incident Source is '019', means it was created in ByD or C4C no edit and close auth
            if (status === "1" || status === "8" || status === "Z" || incidentSource === "019") {
                this._oEventBus.publish("sap.me.support.fragments.CaseDetailHeaderController", "statusInit", {status: "Confirmed"});
                this._oView._oContextModel.setProperty("/isCanWrite", false);
                // Users can delete their own draftCase
                const currentUser = this._oUserModel.getData().userName;
                if (status === "1" && currentUser === oCreater) {
                    this._oView._oContextModel.setProperty("/isCanClose", true);
                } else {
                    this._oView._oContextModel.setProperty("/isCanClose", false);
                }
            } else {
                this._oEventBus.publish("sap.me.support.fragments.CaseDetailHeaderController", "statusInit", {status});
            }
            return statusTxt;
        },

        isEnablePriorityEdit: function(oStatus,isCanWrite) {
            // When a case is NOT in status of 'SAP Proposed Solution', 'Customer Action', 'Partner-Customer Action'
            // Then the priority & Business Impact should be read-only for customer.
            // should return the string "true" or "false" to consider the editable for priority
            const canEdit = ["3", "5", "N"].includes(oStatus) && isCanWrite;
            return `${canEdit}`;
        },
        // same as in CasePreviewDialog.js (regenerateCanClose)
        isEnableCloseButton: function(oStatus,isCanClose, infoDoc, respItsm) {
            if (infoDoc) {
                return false;
            }
            if (respItsm === "BCP") {
                if (oStatus === "1") {
                    return true;
                }
                return ["3","5","N"].includes(oStatus) && isCanClose;
            }
            return isCanClose;

        },

        isShowCloseButton: function(oStatus, isCanDeleteDraft, aaEPFlag, aaEPSessStatus) {
            // aaep draft can't be deleted when aaep session is open
            // normal draft can't delete when status is 'Confirmed' and 'Confirmed Automatically'
            if (aaEPFlag === "X") {
                return aaEPSessStatus !== "Open / Running Sessions" && isCanDeleteDraft;
            }
            return (!["8", "Z"].includes(oStatus)) && isCanDeleteDraft;
        },

        formatPriorityLevel: function(priority) {
            switch (priority) {
                case "Very High":
                    return "1";
                case "High":
                    return "2";
                case "Medium":
                    return "3";
                default:
                    return "4";
            }
        },

        openMaintainDetailLink: function() {
            sap.m.URLHelper.redirect(`/seca/${this.cacheDetailModel.getData().systemNumber}/${this._oPointer}`,true);
        },

        openConnectionLink: function() {
            sap.m.URLHelper.redirect(`/remoteconnectivity/${this.cacheDetailModel.getData().systemNumber}`,true);
        },

        formatBreadcrumbsText: function(incidentNumber, incidentYear, lastChanged, creator) {
            const incident = `${incidentNumber}/${incidentYear}`;
            const date = UI5Date.getInstance(Number(lastChanged));
            const dateFormatter = DateFormat.getDateTimeInstance({pattern: "dd/MM/yyy'||'h:mm a"});
            const [formattedDate, formattedTime] = dateFormatter.format(date).split("||");

            const textWithoutCreator = this._i18n.getText("case_detail_header_breadcrumbs_without_creator", [incident, formattedDate, formattedTime]);
            if (!creator) {
                return textWithoutCreator;
            }
            if (creator.indexOf("ServiceNow") !== -1) {
                this._oODataModel.refresh();
                return textWithoutCreator;
            }
            const textWithCreator = this._i18n.getText("case_detail_header_breadcrumbs", [incident, formattedDate, formattedTime, creator]);
            return textWithCreator;
        },

        priorityGenericTagFormatter: function(priorityText) {
            if (priorityText === "Very High" || priorityText === "High") {
                return CoreLib.ValueState.Error;
            }
            return CoreLib.ValueState.None;
        },

        formatterAutoConfirmDateText: function(days) {
            return this._i18n.getText("autoConfirmWarningText2", [days]);
        },

        formatterShowAutoConfirmBanner: function(status, countDownOfAutoConfirm, componentName, incidentSource, swClass) {
            if (["019", "018", "020"].includes(incidentSource) || componentName?.includes("XX-AMS") || swClass === "XM") {
                return false;
            }
            if ((status === "5" || status === "3" || status === "N") && !!countDownOfAutoConfirm) {
                return true;
            }
            return false;
        },

        formatCreatorName: function(creator) {
            const userId = creator.split("(")[1];
            const LimitList = ["I", "D", "C"];
            LimitList.forEach(item => {
                if (userId?.indexOf(item) !== -1) {
                    creator = "SAP";
                }
            });
            return creator;
        }

    });
});

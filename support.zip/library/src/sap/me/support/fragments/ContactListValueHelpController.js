sap.ui.define([
    "sap/me/support/fragments/ContactBaseValueHelpController",
    "sap/ui/core/Fragment"
], function(
    ContactBaseValueHelpController,
    Fragment,
) {

    "use strict";

    return ContactBaseValueHelpController.extend("sap.me.support.fragments.ContactListValueHelpController", {

        /** ************************************************************************************** */
        /*                                    public method                                        */
        /** ************************************************************************************** */
        subHandleContactValueHelpClose : function(oSelectedContact) {
            Object.assign(oSelectedContact,this._oClickData);
            this.contactCtrl.updateContact(() => {
                this.contactCtrl._oContactHelper.updateContact(oSelectedContact,this.contactCtrl._oContactHelper.findIndexById(oSelectedContact.ID));
            });
        },

        handleContactValueHelpOpen : function(oClickData) {
            this._oClickData = oClickData;
            this._oListValueHelp ? this._oListValueHelp.open() : Fragment.load({
                name: "sap.me.support.fragments.ContactInputDialog",
                controller: this
            }).then((oDialog) => {
                this.contactCtrl.getView().addDependent(oDialog);
                this._oListValueHelp = oDialog;
                oDialog.open();
            });
        },
    });
});

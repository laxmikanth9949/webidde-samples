sap.ui.define([
    "sap/me/support/fragments/ContactBaseValueHelpController"
], function(
    ContactBaseValueHelpController
) {

    "use strict";

    return ContactBaseValueHelpController.extend("sap.me.support.fragments.ContactAddDialogValueHelpController", {

        /** ************************************************************************************** */
        /*                                    public method                                    */
        /** ************************************************************************************** */
        subHandleContactValueHelpClose : function(selectedContact) {
            const addDialogModel = this.contactCtrl.getView().getModel("$this.addDialogModel");
            const oAddDialogData = addDialogModel.getProperty("/newContactData");
            addDialogModel.setProperty("/newContactData", Object.assign(oAddDialogData, {...selectedContact, isCreatedByFreeStyle:false}));
            addDialogModel.setProperty("/newContactAttribute/isAddDialogInputEditable", false);
        },
    });
});

sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/me/support/fragments/CreateSelectCustomerOrSuserBaseDialog",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"

], function(JSONModel, CreateSelectCustomerOrSuserBaseDialog, Filter, FilterOperator) {
    "use strict";

    let selectedCustomerModel;
    let isSupportCustomer;
    return CreateSelectCustomerOrSuserBaseDialog.extend("sap.me.support.fragments.CreateSelectCustomerDialog", {

        onSelectedCustomerItem : function(oEvent) {
            let oValues = oEvent.getSource().getBindingContext("selectionList");
            isSupportCustomer = oValues.getObject().Desc2 === "SUPPORTED";
            if (!selectedCustomerModel) {
                selectedCustomerModel = new JSONModel(); 
            }
            const inputValues = {
                customerName: oValues.getObject().Value,
                customerNum: oValues.getObject().Name,
                isMultipleCustomer: true,
                isSupportCustomer: isSupportCustomer,
                customerType: oValues.getObject().Desc2
            };
            selectedCustomerModel.setData(inputValues);
            this.setCustomerModel(selectedCustomerModel);
        },

        setDialogType: function() {
            this._oType = "customer";
            this._name = "sap.me.support.fragments.CreateSelectCustomerDialog";
        },

        getCustomerModel : function() {
            return selectedCustomerModel;
        },

        setCustomerModel : function(oCustomerModel) {
            selectedCustomerModel = oCustomerModel;
        },

        getIsSupportCustomer : function() {
            return isSupportCustomer;
        },

        getCustomerNumber : function() {
            return selectedCustomerModel?.getProperty("/customerNum") || null;
        },

        getCustomerName : function() {
            return selectedCustomerModel?.getProperty("/customerName");
        },

        customerNumSetToInt: function(oCustomerNumber) {
            return JSON.stringify(parseInt(oCustomerNumber));
        },

        customerValueSetToSubValue: function(oCustomerValue) {
            return oCustomerValue.substring(oCustomerValue.indexOf("-") + 2 , oCustomerValue.length);
        },

        customerDescSetToUpperCase: function(oCustomerDesc) {
            return oCustomerDesc.toUpperCase();
        },

        clearStaticModel: function() {
            selectedCustomerModel = null;
            isSupportCustomer = null;
        },

        /**
         * @override
         * @returns string
         */
        getQueryData: function() {
            return "?$filter=Uname eq '" + this._userName + "' and Type eq 'CUSTOMER'";
        },

        getFilters: function(sQuery) {
            this.aFilters.push(new Filter({
                filters: [
                    new Filter({path: "Value", operator: FilterOperator.Contains, value1: sQuery}),
                    new Filter({path: "Name", operator: FilterOperator.Contains, value1: sQuery}),
                    new Filter({path: "Desc1", operator: FilterOperator.Contains, value1: sQuery})
                ],
                and: false
            }));
            return this.aFilters;
        },

        // set favorite icon status
        onPressFavCustomerButton: function(oEvent) {
            let oSource = oEvent.getSource();
            this.updateFavFlagForCustomer(oEvent);
            if (oSource.getIcon() === "sap-icon://unfavorite") {
                oSource.setIcon("sap-icon://favorite");
            } else {
                oSource.setIcon("sap-icon://unfavorite");
            }
        },

        updateFavFlagForCustomer: function(oEvent) {
            const oCustomer = oEvent.getSource().getBindingContext("selectionList").getObject();
            jQuery.ajax("/backend/raw/support/CaseF4HelpW7Verticle", {
                method: oCustomer.isFavorite ? "DELETE" : "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    CustomerNbr:oCustomer.Name
                })
            }).done(async() => {
                sap.m.MessageToast.show(this._i18n.getText(
                    oCustomer.isFavorite ? "createIssueCustomerSelect_remove_favorite"
                        : "createIssueCustomerSelect_add_favorite"
                ));
                await this._setListData();
                this.iconTabBarModel.setProperty("/selectedKey", "allCustomer");
            }).fail(() => {
                sap.m.MessageBox.error(this._i18n.getText(
                    oCustomer.isFavorite ? "createIssueCustomerSelect_remove_favorite_error"
                        : "createIssueCustomerSelect_add_favorite_error"
                ));
            }).always(() => {
            });
        },

        setSelectKey : function() {
            const rec = this._oView.getModel("selectionList").getProperty("/rec");
            const fav = this._oView.getModel("selectionList").getProperty("/fav");
            this.iconTabBarModel.setProperty("/selectedKey", rec.length > 0 ? "recentCustomer" : fav.length > 0 ? "favoriteCustomer" : "allCustomer");
        },
    });
});

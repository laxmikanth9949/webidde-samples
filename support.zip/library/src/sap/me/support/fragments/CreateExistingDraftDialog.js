sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/me/shared/Models",
    "sap/m/MessageToast",
    "sap/me/support/model/formatter",
    "sap/m/MessageBox",
    "sap/ui/core/routing/Router",
    "sap/me/support/utils/RouterHelper",
    "sap/me/support/utils/InfoExchange"
], function(BaseObject, Fragment, JSONModel, SharedModels, MessageToast, formatter, MessageBox,Router,RouterHelper,InfoExchange) {
    "use strict";
    return BaseObject.extend("sap.me.support.fragments.CreateExistingDraftDialog", {
        formatter: formatter,
        constructor: function(oView) {
            this._oRouter = Router.getRouter("shellRouter");
            this._oView = typeof (oView.getCard) === "undefined" ? oView._oView : oView.getCard();
            this._oController = oView;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._oUserModel = SharedModels.getUserModel();
            this.userId = this._oUserModel.getData().simulatedUser || this._oUserModel.getData().userName;
            this._oView.setModel(this._draftListModel = new JSONModel({
                item: [],
                allItem:[],
                myDraftItem:[],
                otherDraftItem:[],
                selectedKey:"my-draft-btn",
                userId: this.userId,
                currentSelectDraftInfo:{
                    productVisible: false,
                    productFunctionVisible: false
                },
            }), "draftList");
        },

        getModelList: function(key = "my-draft-btn") {
            this._oDialogVBox.setBusy(true);
            let url = "/backend/raw/support/CaseList?filter=((Status eq '1') and (LastUpdate eq 'ALL'))";
            if (key === "my-draft-btn") {
                url = `/backend/raw/support/CaseList?filter=((Status eq '1') and (LastUpdate eq 'ALL') and (Reporter eq '${this.userId}'))`;
            }
            this.draftListRequest = jQuery.ajax(url, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                async: true,
            }).done(data => {
                this._oDialogVBox.setBusy(false);
                if (key == "my-draft-btn") {
                    // MyDrafts scenario
                    this._draftListModel.setProperty("/myDraftItem", data.slice(0, 3));
                } else {
                    // OtherDrafts scenario (deprived from AllDrafts API data)
                    if (data.length === 0) {
                        this.reportNewCase();
                    } else {
                        this.setOtherDraftItem(data);
                    }
                }
                this.loadItem();
            }).fail(() => {
                this._oDialogVBox.setBusy(false);
            });
        },

        onDraftTabBarChange: function(oEvent) {
            const selectedKey = oEvent.getSource().getSelectedKey();
            this._draftListModel.setProperty("/selectedKey", selectedKey);
            if (selectedKey === "other-draft-btn" && this._draftListModel.getProperty("/otherDraftItem").length === 0) {
                this.getModelList(selectedKey);
            }
            this.loadItem();
        },

        loadItem:function() {
            let selected = this._draftListModel.getProperty("/selectedKey");
            if (selected === "my-draft-btn") {
                this._draftListModel.setProperty("/item",this._draftListModel.getProperty("/myDraftItem"));
            } else {
                this._draftListModel.setProperty("/item",this._draftListModel.getProperty("/otherDraftItem"));
            }
        },

        setOtherDraftItem: function(data) {
            let otherItemFilterInfo;
            otherItemFilterInfo = data.filter((i) => {
                return i.Reporter !== this.userId;
            }).slice(0, 3);
            this._draftListModel.setProperty("/otherDraftItem",otherItemFilterInfo);
        },

        open: function(simulatedUser) {
            if (simulatedUser) {
                this._draftListModel.setProperty("/userId",simulatedUser);
            }
            return this._oDialog ? (() => {
                this._oDialog.open();
                this.getModelList();
            })() : Fragment.load({
                name: "sap.me.support.fragments.CreateExistingDraftDialog",
                controller: this
            }).then((Dialog) => {
                this._oDialog = Dialog;
                this._oDialogVBox = Dialog.getContent()[1];
                this._oView.addDependent(this._oDialog);
                this._oDialog.open();
                this.getModelList();
            });
        },

        onPressCancelButton: function() {
            this.closeExistingDraftDialog();
            this._oController.navToSupport();
        },

        closeExistingDraftDialog:function() {
            // change status of existing draft dialog so that it can't open when force-pull case creation page
            this._oDialog.close();
        },

        reportNewCase:function() {
            this.draftListRequest?.abort();
            this.closeExistingDraftDialog();
            this._oController.handleReportAnIssuePress();
        },

        openDraft : function(oEvent) {
            this.closeExistingDraftDialog();
            this._oController._oRouter.withoutEvent = true;
            window.adobeOpenDraftParams = {
                session_id : InfoExchange._allItems.get("caseCreationInfoExchange")._oTrackingData.session_id,
            };
            RouterHelper.navToCreationDashboard(oEvent.getSource().getBindingContext("draftList").getObject().Pointer);
        },

        deleteDraft: function(draftPointer) {
            this._oDialog.setBusy(true);
            jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify({
                    action: "COMPLETE",
                    pointer: draftPointer,
                    draft_flag: "X"
                }),
                success: () => {
                    MessageToast.show(`${this._i18n.getText("CreateDeleteDraftSuccess")}`);
                    this._oDialog.setBusy(false);
                    this.getModelList();
                },
                error: () => {
                    this._oDialog.setBusy(false);
                }
            });
        },

        isDeleteDraft : async function(oEvent) {
            const draftPointer = oEvent.getSource().getBindingContext("draftList").getObject().Pointer;
            const permissionCheck = await jQuery.ajax("/backend/raw/support/CasePermissionW7Verticle?action=COMPLETE&pointer=" + draftPointer, {
                method: "GET",
                contentType: "application/json"
            }).catch(e => {
                console.error(e);
            });
            if (permissionCheck?.AuthResult !== "PASS") {
                MessageToast.show(`${this._i18n.getText("CreateDeleteDraftNoPermission")}`);
                return;
            }
            MessageBox.confirm(this._i18n.getText("CreateDeleteDraft_message_content"), {
                title: this._i18n.getText("CreateDeleteDraft_confirm_title"),
                styleClass: "",
                actions: [this._i18n.getText("yes"), this._i18n.getText("no")],
                emphasizedAction: this._i18n.getText("yes"),
                onClose: (sAction) => {
                    if (sAction === this._i18n.getText("yes")) {
                        this.deleteDraft(draftPointer);
                    }
                }

            });
        },

        showInfo : function(oEvent) {
            let selectedObject = oEvent.getSource().getBindingContext("draftList").getObject();
            selectedObject.productVisible = false;
            selectedObject.productFunctionVisible = false;
            this._draftListModel.setProperty("/currentSelectDraftInfo", selectedObject);

            let oButton = oEvent.getSource();
            // create popover
            if (!this._pPopover) {
                return Fragment.load({
                    name: "sap.me.support.fragments.createExistingDraftPopoverInfo",
                    controller: this
                }).then(oPopover => {
                    this._pPopover = oPopover;
                    this._oView.addDependent(oPopover);
                    oPopover.openBy(oButton);
                    this.getPopoverProductAndProductionFunction();
                });
            }

            this._pPopover.openBy(oButton);
            this.getPopoverProductAndProductionFunction();


        },

        getPopoverProductAndProductionFunction : function() {
            let currentSelected = this._draftListModel.getProperty("/currentSelectDraftInfo");
            if (currentSelected.SystemNumber && currentSelected.CompKey) {
                this._pPopover.setBusy(true);
                jQuery.ajax(`/backend/raw/support/CaseCreateCompMapToProductW7?$top=1&$filter=SystemNumber eq '${currentSelected.SystemNumber}' and CompName eq '${currentSelected.CompKey}' and UseCaseID eq 'S4MSupportCreate'`, {
                    method: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    async: true,
                }).done(data => {
                    if (data.length > 0) {
                        let dataJson = data[0];
                        if (dataJson.ModelCategory === "Product") {
                            currentSelected.productVisible = true;
                            currentSelected.productName = dataJson.DisplayName;
                        } else if (dataJson.ModelCategory === "Product Function") {
                            currentSelected.productVisible = true;
                            currentSelected.productFunctionVisible = true;
                            currentSelected.productName = dataJson.FullName.substring(0,dataJson.FullName.indexOf(">"));
                            currentSelected.productFunctionName = dataJson.DisplayName;
                        }
                        this._draftListModel.setProperty("/currentSelectDraftInfo", currentSelected);
                    }
                    this._pPopover.setBusy(false);
                }).fail(() => {
                    this._pPopover.setBusy(false);
                });
            }
        },

        customerValueSetToSubValue: function(customerText,customerNum) {
            return customerText.substring(customerText.indexOf("-") + 2 , customerText.length) + " (" + customerNum + ")";
        },

        systemValueConcat: function(systemName, systemNumber) {
            return formatter.formatSystemDisplayName(systemName + " (" + systemNumber.substring(9) + ")");
        },

        formatDraftMessage: function(draftList) {
            return this._i18n.getText("SelectExistingDraft_latest_draft", [draftList?.length]);
        },

        toLocalDate: function(timestamp) {
            let subStringTimeStamp = timestamp.substring(timestamp.indexOf("(") + 1,timestamp.indexOf(")"));
            return `${this._i18n.getText("SelectExistingDraft_updated_at")} ${formatter.mediumDateFromDateNumberAndString(subStringTimeStamp)}`;
        },

        navToCaseList: function() {
            sap.m.URLHelper.redirect("/cl?tab=draftCase", true);
        }

    });
});

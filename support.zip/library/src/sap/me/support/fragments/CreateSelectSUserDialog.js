sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/me/support/fragments/CreateSelectCustomerOrSuserBaseDialog",
    "sap/me/cards/model/models",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function(JSONModel, CreateSelectCustomerOrSuserBaseDialog, models, Filter, FilterOperator) {
    "use strict";
    let selectedSuserModel;

    let sUserNumber = models.getCustomerModel().getData().userName;
    const {firstname, lastname} = models.getCustomerModel().getData();

    return CreateSelectCustomerOrSuserBaseDialog.extend("sap.me.support.fragments.CreateSelectSUserDialog", {

        onSelectedSuserItem : function(oEvent) {
            let oValues = oEvent.getSource().getBindingContext("selectionList");
            let selectedSuserNumber = oValues.getObject().Name;
            let selectedSuserName = this.formatDisplayValue(oValues.getObject().Value);
            if (!selectedSuserModel) {
                selectedSuserModel = new JSONModel();
            }
            const inputValues = {
                suserName: selectedSuserName ?? `${firstname} ${lastname} (${sUserNumber})`,
                suserNumber: selectedSuserNumber ? selectedSuserNumber : sUserNumber
            };
            selectedSuserModel.setData(inputValues);
            this.setSuserModel(selectedSuserModel);
        },

        setDialogType: function() {
            this._oType = "suser";
            this._name = "sap.me.support.fragments.CreateSelectSUserDialog";
        },

        getSuserModel : function() {
            return selectedSuserModel;
        },

        setSuserModel : function(oSuserModel) {
            selectedSuserModel = oSuserModel;
        },

        clearStaticModel: function() {
            selectedSuserModel = null;
        },

        /**
         * @override
         * @returns string
         */
        getQueryData: function(selectedCustomerNumber) {
            return "?$filter=KeyValue eq '" + selectedCustomerNumber + "' and Type eq 'USER'";
        },

        getFilters: function(sQuery) {
            this.aFilters.push(new Filter({
                filters: [
                    new Filter({path: "Value", operator: FilterOperator.Contains, value1: sQuery}),
                    new Filter({path: "Uname", operator: FilterOperator.Contains, value1: sQuery})
                ],
                and: false
            }));
            return this.aFilters;
        },

        // cancel button, only works for create an issue header part
        cancelCustomerDialogAndSuserDialog: function() {
            this.close();
            // open customer dialog & rollBack to the previous customer
            if (this._oController) {
                // open customer dialog & rollBack to the previous customer
                this._oController.setAllDataToPrevious();
            }
            this._oController.openDialog("customer");
        },

        formatDisplayValue: function(oValue) {
            return oValue.split("(")[0];
        },

        setSelectKey : function() {
            const rec = this._oView.getModel("selectionList").getProperty("/rec");
            this.iconTabBarModel.setProperty("/selectedKey", rec.length > 0 ? "recent" : "all");
        },

        avatarFormat: function(oValue) {
            const name = oValue.split("(")[0];
            return typeof name === "string" ? name.replace(/\(\w+\)/, "").match(/\b\w/g)?.join("").substring(0, 2) : "";
        }
    });

});

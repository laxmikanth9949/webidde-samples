sap.ui.define([
    "jquery.sap.global",
    "../utils/helper",
    "../utils/SACMapList",
    "sap/me/support/utils/Constants",
    "sap/m/VBox",
    "sap/m/HBox",
    "sap/m/Select",
    "sap/ui/core/ListItem",
    "sap/m/FormattedText",
    "sap/m/Input",
    "sap/ui/core/Icon",
    "sap/ui/core/Fragment"
], function(
    jQuery,
    helper,
    SACMapList,
    Constants,
    VBox,
    HBox,
    Select,
    ListItem,
    FormattedText,
    Input,
    Icon,
    Fragment,
) {
    "use strict";

    const caseCreationSAC = new Object();

    // Added single choice questions
    let oSelectList = [];
    // Is first time
    caseCreationSAC.firstTimeIn = true;
    caseCreationSAC._recommendedComponent = "";
    caseCreationSAC._compChangedCurrentNodeId = "";
    caseCreationSAC._knowledgePressedCurrentNodeId = "";
    caseCreationSAC._knowledgePressedTreeNodeId = "";

    caseCreationSAC.oTrendingList = [];

    const ID_SAP_ME_SAC_QUESTION_LIST_BOX = "CaseCreationDetailedInformationStep--sapMeSACQuestionListBox";
    const ID_SAP_ME_SAC_QUESTION_LEAF_NODE_LIST_BOX = "CaseCreationDetailedInformationStep--sapMeSACQuestionLeafNodeListBox";

    caseCreationSAC._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");

    caseCreationSAC.getRecommendedComponent = function() {
        return this._recommendedComponent;
    };

    caseCreationSAC.getCompChangedCurrentNodeId = function() {
        return this._compChangedCurrentNodeId;
    };

    caseCreationSAC.getKnowledgePressedCurrentNodeId = function() {
        return this._knowledgePressedCurrentNodeId;
    };

    caseCreationSAC.getKnowledgePressedTreeNodeId = function() {
        return this._knowledgePressedTreeNodeId;
    };

    caseCreationSAC.setRecommendedComponent = function(componentName, nodeId) {
        if (!componentName) {
            // clear the recommended component
            this._recommendedComponent = "";
            this._compChangedCurrentNodeId = "";
        } else {
            if (this._recommendedComponent?.CompName === componentName) {
                return;
            }
            this.getRecommendedComponentInfo(componentName).then(data => {
                // K is "X" means the component is selectable
                if (data?.K !== "X") {
                    return;
                }
                this._compChangedCurrentNodeId = nodeId;
                this._recommendedComponent = data;
                this.creationController.checkSACRecommendedComponent();
            });
        }
    };

    caseCreationSAC.getRecommendedComponentInfo = function(componentName) {
        return new Promise((resolve, reject) => {
            jQuery.ajax(`/backend/raw/support/CaseCreateCompProductSearchSetW7?$filter=CompName eq '${componentName}'`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                success: data => {
                    resolve(data ? data[0] : {});
                },
                error : () => {
                    reject();
                }
            });
        });
    };

    caseCreationSAC.callSACServiceForNode = async function(isInitialcall, SACQuestionNum) {

        let param = "?requestType=";

        if (isInitialcall) {
            let ppmsid = this.creationController.fragmentControllers.BasicInformationStep.data.product.info?.SoftwareProductNumber;
            let path = this.creationController.fragmentControllers.BasicInformationStep.data.productFunction.info?.ModelNumber;
            if (!ppmsid || !path) {
                this.setDetailInformationUI();
                return;
            }
            param += "initialCall&ppmsid=" + ppmsid + "&productFunctionPath=" + path;
        } else {
            // non-leaf node handle
            // No need to reset the selectMap if it's not initial call
            this.resetOSelectMap(SACQuestionNum);
            this.setDetailInformationUI({isLeaf:false});

            let nodeId = this.getSelectKeyFromOSelectList(SACQuestionNum);
            // if user select a empty node, then do nothing.
            if (!nodeId) {
                return;
            }
            param += "treeNode&nodeId=" + nodeId;
        }
        param += "&sessionid=" + this.creationController._oTrackingData.session_id;

        try {
            const data = await jQuery.ajax("/backend/raw/support/CaseCreationSACVerticle" + param, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
            });

            this.reloadNextQuestionOrText(SACQuestionNum, data);
            this.setDetailInformationUI(data);
            this._cacheSACQuestion(data);
        } catch (e) {
            this.clearSACNodes();
        }
    };
    // cache questions for ISM solution
    caseCreationSAC._cacheSACQuestion = function(data) {
        if (this.creationController && Object.keys(data).length !== 0) {
            this.creationController._cacheSacQuestionList.push(data);
        }
    };

    // remove former question elements from both 'html' and 'oSelectList' by SACQuestionNum
    caseCreationSAC.resetOSelectMap = function(SACQuestionNum) {

        let startIndex = SACQuestionNum + 1;
        for (let l = startIndex; l < oSelectList.length; l++) {
            sap.ui.getCore().byId(ID_SAP_ME_SAC_QUESTION_LIST_BOX).removeItem(oSelectList[l]);
            oSelectList[l].destroy(true);
        }
        if (SACQuestionNum === -1) {
            sap.ui.getCore().byId(ID_SAP_ME_SAC_QUESTION_LIST_BOX).destroyItems();
        }

        sap.ui.getCore().byId(ID_SAP_ME_SAC_QUESTION_LEAF_NODE_LIST_BOX).destroyItems();
        oSelectList.splice(startIndex);

        // clear former questions from mapList
        this.mapList.clearById(helper.SACNonLeafSingleQuestionPrefix + SACQuestionNum);
    };

    caseCreationSAC.reloadNextQuestionOrText = function(SACQuestionNum, oData) {
        // tree start node
        this.treeStartNodeId;
        this.treeStartNodeTitle;
        if (!oData || Object.keys(oData).length === 0) {
            return;
        }
        // used by qualtricsService
        this.creationController.isSupportAssistantUsed = true;
        // make data a pure node
        if (oData && oData.treeStartNode) {
            this.treeStartNodeId = oData.treeStartNode.nodeId;
            this.treeStartNodeTitle = oData.treeStartNode.nodeTitle;
            this._knowledgePressedTreeNodeId = this.treeStartNodeId;
            oData = oData.treeStartNode;
        }
        this.setRecommendedComponent(oData.recommendedComponent, oData.nodeId);
        this._knowledgePressedCurrentNodeId = oData.nodeId;

        this.displaySACtrendingContent(oData);

        // if non-leaf, then question's type must be single choice
        if (!oData.isLeaf) {
            // container of single choice questions
            const oUpperBox = sap.ui.getCore().byId(ID_SAP_ME_SAC_QUESTION_LIST_BOX);
            const oVBox = this.generateSingleChoice(++SACQuestionNum, {
                isLeaf:oData.isLeaf,
                label:oData.prompt,
                items: oData.edges,
                treeId:oData.nodeId,
                treeTitle:oData.nodeTitle
            });
            oUpperBox.addItem(oVBox);
            oSelectList.push(oVBox);
            this.creationController.swaServiceEvent.SANodeDisplayed(oData.nodeId,oData.nodeTitle,oData.prompt);
            return;
        }

        // leaf
        this.generateLeafQuestionByType(oData);
    };

    caseCreationSAC.generateLeafQuestionByType = function(oQuestions) {
        if (!oQuestions?.topicSpecificQuestions) {
            return;
        }

        const oLeafBox = sap.ui.getCore().byId(ID_SAP_ME_SAC_QUESTION_LEAF_NODE_LIST_BOX);
        oQuestions.topicSpecificQuestions.forEach((oSpecQeustion,iIndex) => {
            const moreinfoLink = oSpecQeustion.link && oSpecQeustion.link.url && oSpecQeustion.link.title ? `<br><a href=${oSpecQeustion.link.url}>${oSpecQeustion.link.title}</a>` : "";
            switch (oSpecQeustion.type) {
                case "sap.m.ComboBox":
                    oLeafBox.addItem(this.generateSingleChoice(iIndex,{
                        isLeaf:oQuestions.isLeaf,
                        label:oSpecQeustion.label + moreinfoLink,
                        items: oSpecQeustion.options.items,
                        treeId:oQuestions.nodeId,
                        treeTitle:oQuestions.nodeTitle,
                        treeText : oSpecQeustion.label,
                    }));
                    break;
                case "sap.m.TextArea":
                    oSpecQeustion.label += moreinfoLink;
                    oLeafBox.addItem(this.generateTextArea(oSpecQeustion,iIndex));
                    break;
            }
            this.creationController.swaServiceEvent.SANodeDisplayed(oQuestions.nodeId+"",oQuestions.nodeTitle,oSpecQeustion.label);
        });
    };

    caseCreationSAC.generateTextArea = function(oSpecQuestion, iQuestionNum) {
        const oVBox = this.createVBoxElement();
        // question label
        const oHBox = this.createHBoxElement();
        let oLabelHBox = oHBox.addItem(this.createFormattedTextElement({htmlText: oSpecQuestion.label}).addStyleClass("sapUiTinyMarginEnd"));
        if (oSpecQuestion.moreinfo) {
            oLabelHBox = oHBox.addItem(
                new Icon({
                    src: "sap-icon://information",
                    tooltip: oSpecQuestion.moreinfo,
                    press: (oEvent) => {
                        this.openPopOver(oEvent, oSpecQuestion.moreinfo);
                    }
                })

            );
        }
        oVBox.addItem(oLabelHBox);
        // input part
        oVBox.addItem(this.createInputElement({
            placeholder: caseCreationSAC._i18n.getText("case_creation_detail_provide_input"),
            tooltip: oSpecQuestion.moreinfo ? oSpecQuestion.moreinfo : "",
            change: function(oEvent) {
                if (oEvent.mParameters.newValue) {
                    caseCreationSAC.mapList.putAnswer(helper.SACFreeTextQuestionPrefix + iQuestionNum,oEvent.mParameters.newValue);
                }
            }
        }));

        this.mapList.putQuestion(helper.SACFreeTextQuestionPrefix + iQuestionNum, oSpecQuestion.label, true);
        return oVBox;
    };

    caseCreationSAC.generateSingleChoice = function(iQuestionNum, oQuestion) {
        const isleaf = oQuestion.isLeaf;
        // const treeOptions = oQuestion.items;
        const idStr = (isleaf ? helper.SACLeafSingleQuestionPrefix : helper.SACNonLeafSingleQuestionPrefix) + iQuestionNum;
        const oVBox = this.createVBoxElement();
        // question label
        const oLabelHBox = this.createHBoxElement().addItem(this.createFormattedTextElement({htmlText: oQuestion.label}));
        oVBox.addItem(oLabelHBox);
        // select part
        const oSelect = this.createSelectElement({
            id: idStr,
            tooltip: isleaf ? oQuestion.moreinfo : "",
            changeFunc: (oEvent) => {
                const selectedItem = oEvent.getParameters().selectedItem;
                const sAnswer = selectedItem.getProperty("text");
                if (sAnswer) {
                    this.mapList.putAnswer(idStr, sAnswer);
                    this.creationController.updateDraft().catch(() => {});
                }

                if (!isleaf) {
                    const key = selectedItem.getProperty("key");
                    this.callSACServiceForNode(false, iQuestionNum);
                    this.creationController.swaServiceEvent.SANodeClicked(oQuestion.treeId+"",oQuestion.treeTitle,oQuestion.label, key+"",sAnswer);
                }else{
                    this.creationController.swaServiceEvent.SANodeClicked(oQuestion.treeId+"",oQuestion.treeTitle,oQuestion.treeText, "",sAnswer);
                }
            }
        });
        oSelect.createPicker("Popover").setContentWidth("1px").addStyleClass("sapMeCaseCreationCardSACSelect");
        oSelect.addItem(this.createSelectListItemElement());
        oQuestion.items?.forEach((item,index) =>
            oSelect.addItem(this.createSelectListItemElement({
                text: isleaf ? item.value : item.prompt,
                key: isleaf ? index : item.target,
                additionalText: isleaf ? "" : item.moreInfo
            }))
        );
        oVBox.addItem(oSelect);

        this.mapList.putQuestion(idStr, oQuestion.label,isleaf);
        return oVBox;
    };

    caseCreationSAC.getSelectKeyFromOSelectList = function(SACQuestionNum) {
        return oSelectList[SACQuestionNum].mAggregations.items[1].mProperties.selectedKey;
    };

    caseCreationSAC.clearSACNodes = function() {
        sap.ui.getCore().byId(ID_SAP_ME_SAC_QUESTION_LIST_BOX).destroyItems();
        sap.ui.getCore().byId(ID_SAP_ME_SAC_QUESTION_LEAF_NODE_LIST_BOX).destroyItems();
        // reset cache questions for ISM solution
        if (this.creationController) {
            this.creationController._cacheSacQuestionList = [];
            this.creationController._cacheSACAnswerMap = {};
            this.creationController?._componentSelectDialog?.resetExpertChatSpecialMessageFlag();
        }
        if (this.creationDetailStepController) {
            this.creationDetailStepController.data.isStaticPartVisible = true;
        }
    };

    caseCreationSAC.onSACDialogOpen = function(caseCreationCard) {
        this.creationController = caseCreationCard;
        this.creationDetailStepController = caseCreationCard.fragmentControllers.CaseCreationDetailedInformationStep;

        try {
            if (this.firstTimeIn || this.mapList?.isQustionsEmpty()) {
                this.firstTimeIn = false;

                // clear former data
                this.clearSACNodes();
                this.creationDetailStepController.data.isStaticPartVisible = false;
                oSelectList = [];
                this.mapList = new SACMapList();
                this.creationController._cacheSACAnswerMap = this.mapList;
                this.callSACServiceForNode(true, -1);
                caseCreationSAC.oTrendingList = [];
            }
        } catch (e) {
            this.clearSACNodes();
        }
    };

    caseCreationSAC.restoreQuestionIntoDescriptionArea = function() {

        let contentText = "";
        let pathInfo = "";
        let questionsAnswers = "";
        if (!this.mapList || this.mapList.isQustionsEmpty() || this.mapList.isAnswerEmpty()) {
            return contentText;
        }

        const questionsMap = this.mapList.getQuestionsMap();
        for (const key in questionsMap) {
            const obj = questionsMap[key];
            if (obj && obj.answers) {
                if (obj.isLeaf) {
                    questionsAnswers += "Q: " + obj.question + "<br />";
                    questionsAnswers += "A: " + obj.answers + "<br />";
                } else {
                    pathInfo += obj.answers + "<br />";
                }
            }
        }

        contentText += Constants.CASE_CREATION_SAC_BLOCK.PATH + pathInfo + Constants.CASE_CREATION_SAC_BLOCK.LEAF + questionsAnswers;

        return contentText;
    };

    /**
     * should adjust detail information UI, when
     *      goto step 3
     *      after a question generate
     *      after a question clear
     * @param oQuestionsInfo
     */
    caseCreationSAC.setDetailInformationUI = function(oQuestionsInfo) {
        this.checkIsShowStaticPart(oQuestionsInfo);
    };
    /**
     * undefined                            front end call
     * {}                                   can not get tree from CaseCreationSACVerticle
     * oQuestionsInfo.isLeaf                non root question
     * oQuestionsInfo.treeStartNode?.isLeaf root question
     * @param oQuestionsInfo
     */
    caseCreationSAC.checkIsShowStaticPart = function(oQuestionsInfo) {
        this.creationDetailStepController.data.isStaticPartVisible = !oQuestionsInfo || Object.keys(oQuestionsInfo).length === 0 || oQuestionsInfo.isLeaf || !!oQuestionsInfo.treeStartNode?.isLeaf;
    };

    caseCreationSAC.displaySACtrendingContent = function(oData) {
        // if the node contains valid recommendations content then pass it to the renderer
        // if the non-fisrt node doesn't contain valid content
        // use the latest previous node content as the data pass to the renderer
        if (oData.contentRecommendations) {
            const sacContentRecommendations = oData.contentRecommendations;
            sacContentRecommendations.map((i) => {
                i.treeStartNode = this.treeStartNodeId;
            });
            caseCreationSAC.oTrendingList.push(sacContentRecommendations);
            this.creationController.afterGetSACcontentRecommendations(sacContentRecommendations);
        } else if (caseCreationSAC.oTrendingList.length > 0) {
            this.creationController.afterGetSACcontentRecommendations(caseCreationSAC.oTrendingList[caseCreationSAC.oTrendingList.length - 1]);
        } else {
            this.creationController.afterGetSACcontentRecommendations("");
        }
    };

    caseCreationSAC.getSACQuestionAndAnswer = function() {
        if (this.mapList && !this.mapList?.isQustionsEmpty()) {
            return this.mapList.getQuestionsMap();
        }
        return "";
    };

    /**
     *
     *  generate HTML element
     *
     */
    caseCreationSAC.createVBoxElement = function() {
        return new VBox({}).addStyleClass("sapMeCaseCreationSACQuestionElement");
    };

    caseCreationSAC.createHBoxElement = function() {
        return new HBox({}).setWidth("100%");
    };

    caseCreationSAC.createInputElement = function(oProperties) {
        return new Input({...oProperties}).setWidth("100%");
    };

    caseCreationSAC.createSelectElement = function(oProperties) {
        const existSelect = sap.ui.getCore().byId(oProperties.id);
        if (existSelect) {
            existSelect.destroy();
        }
        return new Select({
            id: oProperties.id,
            showSecondaryValues: true,
            tooltip: oProperties.tooltip,
            wrapItemsText: true,
            change: (oEvent) => {
                oProperties.changeFunc(oEvent);
            }
        }).setWidth("100%");
    };

    caseCreationSAC.createSelectListItemElement = function(oProperties) {
        return new ListItem(oProperties ? {...oProperties} : {text: "", key: "", additionalText: ""});
    };

    caseCreationSAC.createFormattedTextElement = function(oProperties) {
        return new FormattedText({...oProperties});
    };

    caseCreationSAC.openPopOver = function(oEvent, moreInfoText) {
        const source = oEvent.getSource();
        this.creationController.getModel("$this.detailedInformation").setProperty("/sacMoreInfoText", moreInfoText);
        if (!this._pPopover) {
            return Fragment.load({
                name: "sap.me.support.fragments.SacMoreInfoPopUp",
                controller: this
            }).then(oPopover => {
                this.creationController.addDependent(oPopover);
                oPopover.openBy(source);
            });
        }
        this._pPopover.openBy(source);
    };

    return caseCreationSAC;
}, true);

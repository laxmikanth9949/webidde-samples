sap.ui.define([
    "../library",
    "sap/ui/base/Object",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/fragments/PriorityAndImpactBaseController",
], function(library, BaseObject, JSONModel, PriorityAndImpactBaseController) {

    "use strict";

    return PriorityAndImpactBaseController.extend("sap.me.support.fragments.PriorityAndImpactEditController", {

        /**
         * Needs passing current view, pointer, priority, impact text and id of this fragment
         * to constructor while constructing this fragment.
         *
         * @param {sap.ui.vk.View} _oView - Current view.
         * @param {sap.ui.core.Control} _oParentControl - Control that loads this fragment.
         * @param {JSONModel|undefined} _oCurrentDataModel - JSONModel in following format:
         *          {
         *              "pointer": Pointer,
         *              "priority": Priority,
         *              "impactText": Business Impact Text
         *          }
         */

        constructor: function(_oView, _oParentControl, _oCurrentDataModel) {
            this._oView = _oView;
            this._oParentControl = _oParentControl;

            this.reConstructFragment(_oCurrentDataModel);
        },


        /** ************************************************************************************** */
        /*                                    Public Functions                                    */
        /** ************************************************************************************** */

        refreshCancelPriorityAndImpact : function() {
            if (this.msgStrip) {
                this.msgStrip.setVisible(false);
            }
            // refresh editor textEditorChange
            this._oEditor.setValue(this._oImpactText);
            // refresh the model
            this._priorityAndImpactModel = new JSONModel();
        },

        refreshSubmitPriorityAndImpact : function() {
            if (this.msgStrip) {
                this.msgStrip.setVisible(false);
            }
            // refresh editor textEditorChange
            // keep the new value to editor
            this._oEditor.setValue(this.getBizImpactText());
            // refresh the model
            this._priorityAndImpactModel = new JSONModel();
        },

        refreshFailPriorityAndImpact : function(cacheContactsList) {
            this._oContacts = cacheContactsList;
            this._oContactHelper.replaceAll(cacheContactsList);
        },


        /** ************************************************************************************** */
        /*                                         Event Handlers                                 */
        /** ************************************************************************************** */

        prioritySelectChanged: function(oEvent) {
            this.selectedPriority = oEvent.getParameter("selectedItem").getKey();
            this.formatChangePriorityMsgStrip();
            this.prioritySelectChangedFormat();
        },


        /** ************************************************************************************** */
        /*                                    Handlers'  Functions                                */
        /** ************************************************************************************** */

        formatChangePriorityMsgStrip: function() {
            this.msgStrip = this._oParentControl.getItems()[0].getItems().find( (arr) => {
                return arr.getId().indexOf("priorityMsgStrip") !== -1;
            });

            switch (this._oPriority) {
                case "Very High":
                    if (this.selectedPriority === "High") {
                        this.msgStrip.setText(this._i18n.getText("editPriority_VH2H"));
                    } else if (this.selectedPriority === "Medium") {
                        this.msgStrip.setText(this._i18n.getText("editPriority_VH/H2M"));
                    } else if (this.selectedPriority === "Low") {
                        this.msgStrip.setText(this._i18n.getText("editPriority_VH/H2L"));
                    } else {
                        this.msgStrip.setText("");
                    }
                    break;
                case "High":
                    if (this.selectedPriority === "Medium") {
                        this.msgStrip.setText(this._i18n.getText("editPriority_VH/H2M"));
                    } else if (this.selectedPriority === "Low") {
                        this.msgStrip.setText(this._i18n.getText("editPriority_VH/H2L"));
                    } else if (this.selectedPriority === "Very High") {
                        this.msgStrip.setText(this._i18n.getText("editPriority_H2VH"));
                    } else {
                        this.msgStrip.setText("");
                    }
                    break;
                case "Medium":
                case "Low":
                    if (this.selectedPriority === "High" || this.selectedPriority === "Very High") {
                        this.msgStrip.setText(this._i18n.getText("editPriority_L/M2H/VH"));
                    } else {
                        this.msgStrip.setText("");
                    }
                    break;
                default:
                    return;
            }
            this.msgStrip.setVisible(!!this.msgStrip.getText());
        },

        /** ************************************************************************************** */
        /*                                    implement  Functions                                */
        /** ************************************************************************************** */
        getContactHelperType : function(pointer) {
            return "EDIT_CONTACT_" + pointer;
        },

    });
});

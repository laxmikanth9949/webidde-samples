sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment"
], function(
    BaseObject,
    Filter,
    FilterOperator,
    Fragment,
) {

    "use strict";

    return BaseObject.extend("sap.me.support.fragments.ContactBaseValueHelpController", {
        constructor: function(contactCtrl) {
            this.contactCtrl = contactCtrl;
        },

        /** ************************************************************************************** */
        /*                                    event handler                                       */
        /** ************************************************************************************** */
        handleContactsValueHelpSearch : function(oEvent) {
            let value = oEvent.getParameter("value");
            let aSearchFields = ["contact", "email", "userId"];
            let aSearchFilters = [];
            if (value) {
                for (let i = 0; i < aSearchFields.length; i++) {
                    let oTempFilter = null;
                    oTempFilter = new Filter(aSearchFields[i], FilterOperator.Contains, value);
                    aSearchFilters.push(oTempFilter);
                }
            }
            let oItems = oEvent.getSource().getBinding("items");
            if (oItems) {
                oItems.filter([new Filter(aSearchFilters, false)]);
            }
        },

        handleContactsValueHelpClose : function(oEvent) {
            const _oValueHelpOdataBinding = oEvent.getSource().getBinding("items");
            let oSelectedItem = oEvent.getParameter("selectedItem");
            if (oSelectedItem) {
                let oSelectedContact = undefined;
                let sUId = oSelectedItem.getAttributes()[0].getText();
                // query user info for mobile and telephone
                jQuery.ajax("/backend/raw/support/CaseContactsW7Verticle?$filter=(UserId eq '" + sUId + "')",{
                    async:false,
                    success:function(data) {
                        oSelectedContact = data[0];
                    }.bind(this),
                });
                if (!oSelectedContact) {
                    console.error("Contact value help - can not find any user info, userId = " + sUId);
                    return;
                }
                this.subHandleContactValueHelpClose(oSelectedContact);
            }
            // after all clear search
            _oValueHelpOdataBinding.filter([]);
        },

        /** ************************************************************************************** */
        /*                                    public method                                       */
        /** ************************************************************************************** */
        handleContactValueHelpOpen : function() {
            this._oValueHelpDialog ? this._oValueHelpDialog.open() : Fragment.load({
                name: "sap.me.support.fragments.ContactInputDialog",
                controller: this
            }).then((oDialog) => {
                this.contactCtrl.getView().addDependent(oDialog);
                this._oValueHelpDialog = oDialog;
                oDialog.open();
            });
        },
    });
});

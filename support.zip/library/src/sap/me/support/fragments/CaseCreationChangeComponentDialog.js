sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/me/shared/Models",
    "sap/me/support/model/formatter",
    "sap/me/support/utils/Constants"
], function(BaseObject, Fragment, JSONModel, SharedModels, formatter,Constants) {
    "use strict";
    return BaseObject.extend("sap.me.support.fragments.CaseCreationChangeComponentDialog", {
        formatter: formatter,
        constructor: function(oView) {
            this._oView = typeof (oView.getCard) === "undefined" ? oView._oView : oView.getCard();
            this._oController = oView;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._oUserModel = SharedModels.getUserModel();
            this._oView.setModel(this.componentRelatedInfoModel = new JSONModel({
                selectedComponent:{},
                list:[],
            }), "componentRelatedInfo");
        },

        open: function(newComp) {
            this.componentRelatedInfoModel.setProperty("/selectedComponent", newComp);
            this.componentRelatedInfoModel.setProperty("/list",[]);
            if (this._oDialog) {
                this._oDialog.open();
                this.addToList();
            } else {
                return Fragment.load({
                    name: "sap.me.support.fragments.CaseCreationChangeComponentDialog",
                    controller: this
                }).then(Dialog => {
                    this._oDialog = Dialog;
                    this._oView.addDependent(this._oDialog);
                    this._oDialog.open();
                    this.addToList();
                });
            }
        },

        addToList:function() {
            this._oDialog.setBusyIndicatorDelay(1);
            this._oDialog.setBusy(true);
            this.listObj = [];
            const selectedComponent = this.componentRelatedInfoModel.getProperty("/selectedComponent");
            const previousPriority = this._oController._caseCreationCard.fragmentControllers.BasicInformationStep.data.priority.value;

            if (this._oController._caseCreationCard._channelText === this._i18n.getText("case_creation_best_action_expert_session")) {
                this.listObj.push(
                    {title:this._i18n.getText("component_change_dialog_schedule_an_expert_title"),
                        detail:this._i18n.getText("component_change_dialog_schedule_an_expert_detail"),
                        warningWord:this._i18n.getText("component_change_dialog_schedule_an_expert_warning")});
            }
            this.listObj.push(
                {title:this._i18n.getText("component_change_dialog_product_title"),
                    detail:this._i18n.getText("component_change_dialog_product_detail"),
                    warningWord:this._i18n.getText("component_change_dialog_product_warning")});

            if (selectedComponent.PrioLimit === "X" && previousPriority === Constants.COMPONENT_PRIORITY.VERY_HIGH) {
                this.listObj.push(this.getPriorityDetail("high"));
            } else if (selectedComponent.PrioLimit === "XX" && (previousPriority === Constants.COMPONENT_PRIORITY.VERY_HIGH || previousPriority === Constants.COMPONENT_PRIORITY.HIGH)) {
                this.listObj.push(this.getPriorityDetail("medium"));
            } else if (selectedComponent.PrioLimit === "XXX") {
                this.listObj.push(this.getPriorityDetail("low"));
            }
            this.componentRelatedInfoModel.setProperty("/list",this.listObj);
            this._oDialog.setBusy(false);
        },

        /**
         * @param {('high'|'medium'|'low')} priority
         */
        getPriorityDetail: function(priority) {
            const warningPriorityText = this._i18n.getText(`component_change_dialog_priority_warning_${priority}`);
            return {
                title: this._i18n.getText("component_change_dialog_priority_title"),
                detail: this._i18n.getText("component_change_dialog_priority_detail"),
                warningWord: `${this._i18n.getText("component_change_dialog_priority_warning")} ${warningPriorityText}`
            };
        },

        changeComponent:function() {
            // TODO: move this part of ariba to somewhere.....
            this.close();
            this._oController._setCompValue(this.componentRelatedInfoModel.getProperty("/selectedComponent"),
            () => {
                // clear ariba Q&A data
                this._oController._caseCreationCard.fragmentControllers["CaseCreationAribaQA"].clearAribaQAData();
                this._oController._markFlagForExpertChatInitText();
                this._oController._caseCreationCard.channelRecommender("dialogChangeComp").then(() => {
                    this._oController._caseCreationCard._channelChangeCheckIfSetToCreateCase("Comp");
                    this._oController._caseCreationCard.setSubmitPageChannelModel();
                    this._oController._caseCreationCard.sendAlternativeChannelEvent();
                    this._oController.trackSubmitStepCChangeByUser();
                });
            }, true);
        },

        close:function() {
            this._oDialog.close();
        },

    });
});


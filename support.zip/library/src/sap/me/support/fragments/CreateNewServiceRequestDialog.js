sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/core/routing/Router",
    "sap/me/support/utils/helper"
],function(Object, Fragment, JSONModel, MessageToast, Router, helper) {
    "use strict";
    return Object.extend("sap.me.support.fragments.CreateNewServiceRequestDialog", {
        constructor: function(srCard) {
            this._oView = srCard.getCard();
            this._sId = srCard.getId();
            this._srCard = srCard;
            this.selectModel = 0;
        },

        open: function() {
            return this._oDialog ? this._oDialog.open() : Fragment.load({
                id: this._sId + "-sCreateNewServiceRequestDialog",
                name: "sap.me.support.fragments.CreateNewServiceRequestDialog",
                controller: this
            }).then(function(Dialog) {
                this._oDialog = Dialog;
                this._oView.addDependent(this._oDialog);
                this._oDialog.open();
            }.bind(this));
        },

        close: function() {
            this._oDialog.close();
        },

        onRadioSelected: function(oEvent) {
            this.selectModel = oEvent.getSource().getSelectedIndex();
        },
        // index 0-> Enterprise Cloud Services (ECS)
        // index 1-> Human Capital Management
        // index 2-> Partner & Other Cloud Services
        // index 3-> CRM and Customer Experience
        onConfirm: function() {
            const index = this.selectModel;
            const type = this._srCard._oContextModel.getProperty("/createServiceRequestCase");
            if (index === 0) {
                // when Service Request = Not Released and ServiceNow = Released then open ServiceNow -> 1
                // when Service Request = Released or Pilot and ServiceNow = Not Released then open SR-App -> 2
                // when Service Request = Released or Pilot and ServiceNow = Released then open ServiceNow -> 3
                // when Service Request = Not Released and ServiceNow = Not Released then show Message: Access to Service Request is not released, yet.-> 4
                switch (type) {
                    case "1":
                        this.onSnoServiceRequest(this._srCard._CONSTANTS.HEC_SERVICE_REQUEST_CATALOGS.ECS);
                        break;
                    case "2":
                        this.onNavToLaunchpadServiceRequest();
                        break;
                    case "3":
                        this.onSnoServiceRequest(this._srCard._CONSTANTS.HEC_SERVICE_REQUEST_CATALOGS.ECS);
                        break;
                    case "4":
                        MessageToast.show(`${this._srCard._i18n.getText("serviceRequestNotReleased")}`);
                        break;
                    default:
                        this.onSnoServiceRequest(this._srCard._CONSTANTS.HEC_SERVICE_REQUEST_CATALOGS.ECS);
                        break;
                }
            } else if (index === 1) {
                this.onSPMandCXSnoServiceRequest(this._srCard._CONSTANTS.HEC_SERVICE_REQUEST_CATALOGS.SPM);
            } else if (index === 2) {
                this.onNavToLaunchpadServiceRequest();
            } else {
                this.onSPMandCXSnoServiceRequest(this._srCard._CONSTANTS.HEC_SERVICE_REQUEST_CATALOGS.CX);
            }
            this.close();
        },
        onSnoServiceRequest: function(sId) {

            if (helper.isDev || helper.isLocal) {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_FOR_DEV_CREATE + sId, true);
            } else if (helper.isTest) {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_FOR_TEST_CREATE + sId, true);
            } else {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_FOR_PROD_CREATE + sId, true);
            }
        },

        // SPM and CX
        onSPMandCXSnoServiceRequest: function(sId) {
            if (helper.isDev || helper.isLocal) {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_SPM_CX_DEV_CREATE, true);
            } else if (helper.isTest) {
                // if it is on TEST landscape, use NEW link directly
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_SPM_CX_TEST_CREATE, true);
            } else {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_SPM_CX_PROD_CREATE, true);
            }
        },

        onNavToLaunchpadServiceRequest: function() {
            if (helper.isDev || helper.isLocal || helper.isTest) {
                sap.m.URLHelper.redirect("https://supportshell-tnxd3nxr8c.dispatcher.int.sap.eu2.hana.ondemand.com/#/hec/servicerequest",true);
            } else {
                sap.m.URLHelper.redirect("https://launchpad.support.sap.com/#/hec/servicerequest",true);
            }
        }

    });
});

sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/Dialog",
    "sap/m/library",
    "sap/m/Button",
    "sap/m/Text",
    "sap/m/MessageBox",
    "sap/me/support/model/formatter",
    "sap/me/support/utils/AttachmentHelper",
    "sap/m/MessageToast",
    "sap/me/support/utils/helper",
    "sap/me/support/fragments/AnalyzeFilesDialog",
    "sap/ui/core/routing/Router",
    "sap/m/FormattedText"
], function(Object, Fragment, JSONModel, Dialog, mobileLibrary, Button, Text, MessageBox, Formatter, AttachmentHelper, MessageToast, helper, AnalyzeFilesDialog, Router, FormattedText) {
    "use strict";
    const DialogType = mobileLibrary.DialogType;
    const ButtonType = mobileLibrary.ButtonType;
    const EUDP = "EUDP";
    const CNDP = "CNDP";

    return Object.extend("sap.me.support.fragments.AddAttachmentsDialog",{

        constructor: function(oCard) {
            this._oView = oCard.getCard();
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._oEventBus = sap.ui.getCore().getEventBus();
            this._oPointer = oCard.getContext().attributes.caseKey;
            this._oUser = oCard.getContext().user;
            this._oContextModel = new JSONModel();
            this._caseDetailInfo = oCard._oCaseDetail;
            this._cancelCurrent = false;
            this.attachmentService = new AttachmentHelper(this);
            helper.currentUserPermission(this._oPointer, this);
            this.attachmentService.initialSLAServer();
        },

        formatter: Formatter,

        /**
         * Initialize the dialog model
         */
        initDialogModel: function() {
            // i18n Model
            this._oDialog.setModel(this._oView.getModel("$this.i18n"),"$this.i18n");

            this._oDialog.setModel(this._dialogDataModel = new JSONModel({
                fileType: [],
                filePath: "",
                isChooseFileView: true,
                maximumFileSize: this.attachmentService.MAXIMUM_ATTACHMENT_SIZE,
                overruleAuth: this._caseDetailInfo?.overruleAuth || false,
                dataProtection: this._caseDetailInfo?.dataProtection || "",
                eudpType: EUDP,
                cndpType: CNDP,
                icon: {src: "sIcon", color: "sBGColor"},
            }), "$this.dialogData");

            this.attachmentService.getAttachmentFileTypeList().then((data) => {
                this._dialogDataModel.setProperty("/fileType", data);
            },() => {});

            // attachment model
            this._oDialog.setModel(this._oAttachmentModel = new JSONModel({
                filePath: "",
                isContinueToAddButtonVisible: false,
                isContinueToAddButtonEnabled: true,
                fileTypeList: [],
                maximumFileSize: this.attachmentService.MAXIMUM_ATTACHMENT_SIZE,
                icon: {src: "sIcon", color: "sBGColor"},
                isFileUploaderEnabled: true,
                isWarningAttachmentMessage: false
            }), "$this.attachment");

            // file data model
            this._oDialog.setModel(this._fileDataModel = new JSONModel({
                attachmentList: [],
                analysisList: [],
                uploadPdfAttachments: [],
                suggestedList: [],
                suggestedPopOverInfo: {}
            }), "$this.fileData");

            // analyze alerts data model
            this.setInitialAnalyzeModel();
        },

        setInitialAnalyzeModel: function() {
            this._oDialog.setModel(this._fileAnalyzeAlertsDataModel = new JSONModel({
                alertList: [],
                fileAnalysisAlertsPriorityCount: [0, 0, 0, false], // [error count, warning count, information count, show button or not]
                fileAnalysisBusy: true,
                priority: 0,
                busyText: "",
                fileProcessing: "",
                fileAnalysisHideSaveButton: true,
                fileAnalysisDetailVisible: false
            }), "$this.fileAnalyzeAlerts");
        },

        open: function() {
            if (!this._oDialog) {
                this._oDialog = new Fragment({
                    type: "XML",
                    fragmentName: "sap.me.support.fragments.AddAttachmentsDialog",
                    oController: this,
                });
                this.initDialogModel();
            }
            this.resetDialogValue();
            this._oDialog.open();
        },

        close: function() {
            this.attachmentService.clearAll();
            this._oDialog.close();
        },

        resetDialogValue: function() {
            this.attachmentService.clearAll();
            this._dialogDataModel.setProperty("/isChooseFileView", true);
            this._dialogDataModel.setProperty("/filePath", "");
            this._fileDataModel.setProperty("/attachmentList", []);
            this._fileDataModel.setProperty("/analysisList", []);
            this._fileDataModel.setProperty("/uploadPdfAttachments", []);
        },

        /**
         * Triggered when the user Drag and Drop files into the drop zone
         * @param {*} event
         */
        onDropFile: function(event) {
            event.preventDefault();

            const browserEvent = event.getParameters().browserEvent;
            const uploaderFileList = Array.from(browserEvent.dataTransfer.files) || [];
            const filterFileList = uploaderFileList.filter((file) => this.attachmentService.checkDropFileSizeAndType(file));
            if (filterFileList.length === 0) {
                return;
            }

            this.attachmentService.addAttachment(filterFileList);
            this._dialogDataModel.setProperty("/isChooseFileView", false);
            this._fileDataModel.setProperty("/attachmentList", this.attachmentService.attachmentsInfo);
            this._dialogDataModel.setProperty("/filePath", "");
            this.attachmentService.getAnalyzeStatusByTypeFiles();
        },

        /**
         * Trigger when user adds new attachments
         * @param {*} oControlEvent
         */
        onAttachmentChange: function(oControlEvent) {
            const uploaderFileList = Array.from(oControlEvent.getParameters().files) || [];
            this.attachmentService.addAttachment(uploaderFileList);

            this._dialogDataModel.setProperty("/isChooseFileView", false);
            this._fileDataModel.setProperty("/attachmentList", this.attachmentService.attachmentsInfo);
            this._dialogDataModel.setProperty("/filePath", "");
            this.attachmentService.getAnalyzeStatusByTypeFiles();
        },

        onTypeOrSizeError: function(oEvent) {
            const aFileNames = oEvent.getParameter("fileName");
            const sErrorId = oEvent.getId();
            this.attachmentService.showError(aFileNames, sErrorId);
        },

        onSaveUploadPressed: async function() {
            this._oDialog.setBusy(true);

            await this.attachmentService.updateToBackend({
                pointer: this._oPointer,
                sRespITSM: this._oContextModel.getProperty("/sRespITSM"),
                status: this._caseDetailInfo.status,
                caseInstallationNum: this._caseDetailInfo.installationNum,
                userInfo: this._oUser,
            }).then(() => {
                this.attachmentService.performServerSideAnalysis(this);
                this._oView.getModel("$this.odata").refresh();
                this._oEventBus.publish("sap.me.support.fragments.AddAttachmentsDialog", "attachmentAdded");
                this._oDialog.setBusy(false);
                this.close();
                MessageToast.show(this._i18n.getText("attachments_add_attachments_upload_success_message"));
            }).catch((oError) => {
                this._fileDataModel.setProperty("/attachmentList", this.attachmentService.attachmentsInfo);
                this._oDialog.setBusy(false);
                const cicBtnText = this._i18n.getText("case_creation_contact_cic_btn");
                sap.m.MessageBox.warning(
                    new FormattedText({htmlText: this._i18n.getText("case_creation_upload_failed_error_cic")}),
                    {
                        icon: MessageBox.Icon.WARNING,
                        actions: [cicBtnText, MessageBox.Action.CANCEL],
                        emphasizedAction: cicBtnText,
                        initialFocus: cicBtnText,
                        styleClass: "sapUiSizeCompact",
                        onClose: (sAction) => {
                            if (sAction === cicBtnText) {
                                sap.m.URLHelper.redirect("https://support.sap.com/en/contact-us.html", true);
                            }
                        }
                    }
                );
            });
        },

        onDeleteFilePressed: function(oEvent) {
            this.attachmentService.deleteAttachment(oEvent.getSource().getBindingContext("$this.fileData").getObject());
            this._fileDataModel.setProperty("/attachmentList", this.attachmentService.attachmentsInfo);
            this._fileDataModel.setProperty("/analysisList", this.attachmentService.analyzableFiles);
            this._fileDataModel.setProperty("/uploadPdfAttachments", this.attachmentService.uploadPdfAttachments);
        },

        /**
         * when click close button
         * 1、if there is no file data selected, just close
         * 2、if there is file be selected, show confirm dialog ask if close dialog
         */
        onCloseDialog: function() {
            const fileList = this._fileDataModel.getProperty("/attachmentList") || [];
            if (fileList.length === 0) {
                this.close();
                return;
            }

            if (!this._oConfirmDialog) {
                this._oConfirmDialog = new Dialog({
                    type: DialogType.Message,
                    showHeader: false,
                    content: new Text({text: this._i18n.getText("attachments_add_attachments_close_confirm_text")}),
                    beginButton: new Button({
                        text: this._i18n.getText("yes"),
                        press: function() {
                            this._oConfirmDialog.close();
                            this.close.call(this);
                        }.bind(this)
                    }),
                    endButton: new Button({
                        type: ButtonType.Emphasized,
                        text: this._i18n.getText("cancel"),
                        press: function() {
                            this._oConfirmDialog.close();
                        }.bind(this)
                    })
                });
            }
            this._oConfirmDialog.open();
        },

        /*
		 * For the ``visible``  property EUDP/CNDP checkbox in add attachments dialog
		 * @param  {Boolean}  overruleAuth - if this incident is to be overruled
		 * @param  {String}  dataProtection - the protection flag of the incident, can be NONE/EMER/EUDP/CNDP
         * @param  {String}  checkboxType - the type of the checkbox, can be EUDP/CNDP
		 * @return {Boolean} true if the checkbox should be visible
		 */
        isDataProcessingCheckboxDisplay: function(overruleAuth, dataProtection, checkboxType) {
            if (overruleAuth) {
                return false;
            }
            if (dataProtection === checkboxType) {
                return true;
            }
            return false;
        },

        onAnalyzeFilePressed: function(oEvent) {
            const isBtnClick = oEvent.getSource().getMetadata().getName().includes("Button");
            if (!isBtnClick && oEvent.getSource().getBindingContext("$this.fileData").getObject().analysisStatus === 9) {
                return;
            }
            this.setInitialAnalyzeModel();
            if (!this.analyzeFilesDialog) {
                this.analyzeFilesDialog = new AnalyzeFilesDialog(this, this.attachmentService);
                this._cancelCurrent = false;
            }
            this.analyzeFilesDialog.open();
            // if "analyze all" button click, the second param is null
            // if "analyze" icon click, the second param is current click item
            this.attachmentService.syncFileAnalysis(isBtnClick ? null : oEvent.getSource().getBindingContext("$this.fileData").getObject());
        },

    });
});

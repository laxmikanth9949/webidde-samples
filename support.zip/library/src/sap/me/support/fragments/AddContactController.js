sap.ui.define([
    "../library",
    "sap/ui/base/Object",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "sap/me/support/utils/ContactHelperFactory",
    "sap/me/support/fragments/ContactAddDialogValueHelpController",
    "sap/me/support/model/formatter",
    "sap/me/support/utils/helper",
    "sap/base/util/deepClone",
    "sap/m/MessageBox"
], function(
    library,
    BaseObject,
    JSONModel,
    Fragment,
    ContactHelperFactory,
    ContactAddDialogValueHelpController,
    Formatter,
    helper,
    deepClone,
    MessageBox,
) {

    "use strict";

    const KEY_TAB_NEW_CONTACT = "newContact";
    const KEY_TAB_RECENTLY_USED_CONTACTS = "recentlyUsedContacts";
    const RECENTLY_USED_CONTACT_MAX_SIZE = 5;

    const instance = BaseObject.extend("sap.me.support.fragments.AddContactController", {

        constructor: function(contactCtrl) {
            this.contactCtrl = contactCtrl;
            this.contactCtrl.getView().setModel(this.addDialogModel = new JSONModel({
                tabModel:{
                    selectedKey:KEY_TAB_RECENTLY_USED_CONTACTS
                },
                newContactAttribute:{
                    roleInputValueStateText:undefined,
                    roleInputValueState:"None",
                    isAddDialogInputEditable:true
                },
                newContactData:{},
                newContactIsCreating: false,
                recentlyUsedContacts:[]
            }), "$this.addDialogModel");
            this._initRecentlyContact();
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this.addDialogValueHelpController = new ContactAddDialogValueHelpController(this.contactCtrl);
        },

        openDialog : function(aContacts) {
            this.addDialogModel.setProperty("/newContactData", {});
            this.addDialogModel.setProperty("/newContactAttribute/isAddDialogInputEditable", true);
            this.addDialogModel.setProperty("/newContactAttribute/roleInputValueStateText", undefined);
            this.addDialogModel.setProperty("/newContactAttribute/roleInputValueState", "None");

            if (!this.addContactDialog) {
                this.addContactDialog = new Fragment({
                    type: "XML",
                    fragmentName: "sap.me.support.fragments.AddContactDialog",
                    oController: this
                });
                this.contactCtrl.getView().addDependent(this.addContactDialog);
            }

            if (aContacts.find(o => o.default_contact === true)) {
                this.addDialogModel.setProperty("/default_contact_exists", true);
            }
            this.addDialogModel.setProperty("/contact_list", aContacts);
            this.addContactDialog.open();
            return this;
        },

        onContactNameChanged: function() {
            this.addDialogModel.setProperty("/newContactAttribute/isAddDialogInputEditable", true);
            this.addDialogModel.setProperty("/newContactData/isCreatedByFreeStyle",true);
        },

        onContactRoleChanged: function() {
            if (ContactHelperFactory.isRoleDuplicate(this.addDialogModel.getProperty("/newContactData").role)) {
                this.addDialogModel.setProperty("/newContactAttribute/roleInputValueStateText", `${this._i18n.getText("AddContactForm_duplicate_role_warning")}`);
                this.addDialogModel.setProperty("/newContactAttribute/roleInputValueState", "Error");
            } else {
                this.addDialogModel.setProperty("/newContactAttribute/roleInputValueStateText", undefined);
                this.addDialogModel.setProperty("/newContactAttribute/roleInputValueState", "None");
            }
        },

        onDefaultContactSelected: function(oEvent) {
            this.oDefaultSwitch = oEvent.getSource();
            let oAddDialogModel = this.addDialogModel;
            let oDefaultSwitch = this.oDefaultSwitch;
            oAddDialogModel.setProperty("/newContactData/default_contact", this.oDefaultSwitch.getState());
            let aContacts = oAddDialogModel.getProperty("/contact_list");

            if (aContacts.find(o => o.default_contact === true) && this.oDefaultSwitch.getState() === true) {

			MessageBox.warning(this._i18n.getText("DefaultContact_warning_message"), {
			    title: this._i18n.getText("DefaultContact_warning_title"),
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
				          if (sAction === "CANCEL") {
                            oAddDialogModel.setProperty("/newContactData/default_contact", false);
                            oDefaultSwitch.setState(false);
							}
				}
			});

            }
        },

        onValueHelpPressed: function() {
            this.addDialogValueHelpController.handleContactValueHelpOpen();
        },

        onRecentlyUsedContactSelected: function(event) {
            this.addContactDialog.setBusy(true);
            const selected = event.getSource().getBindingContext("$this.addDialogModel").getObject();
            let aContacts = this.addDialogModel.getProperty("/contact_list");

            if (this.checkForDuplicateContact(selected, aContacts)){
                MessageBox.alert(this._i18n.getText("DuplicateContactFound"));
            } else{
                if (this.addDialogModel.getProperty("/newContactData/default_contact") ) {
                    selected.default_contact = true;
                    if (selected.userId) {
                        delete selected.userId;
                    }

                    let oContact = aContacts.find(o => o.default_contact === true);
                    if(oContact){
                        delete oContact.default_contact;
                    };

                    let defaultRecentlyUsed = this.addDialogModel.getProperty("/recentlyUsedContacts").find(o => o.default_recent_contact === true && o.email !== selected.email);

                    if (defaultRecentlyUsed) {
                        defaultRecentlyUsed.default_recent_contact = false;
                    }

                    this.saveDefaultContact(selected);
                }

                this.contactCtrl.updateContact(() => {
                    this.contactCtrl._oContactHelper.addContact(selected);
                }).then(() => {
                    this.addContactDialog.close()
                    this.addContactDialog.setBusy(false)
                });
            }
            this.addContactDialog.setBusy(false);
        },

        onNewContactAdd: async function() {
            this.addDialogModel.setProperty("/newContactIsCreating", true);
            this.addContactDialog.setBusy(true);

                helper.debounce(async function() {

                    const contactData = this.addDialogModel.getProperty("/newContactData");
                    let aContacts = this.addDialogModel.getProperty("/contact_list");

                    if (this.checkForDuplicateContact(contactData, aContacts)){
                        MessageBox.alert(this._i18n.getText("DuplicateContactFound"));
                        this.addDialogModel.setProperty("/newContactIsCreating", false);
                    } else{


                        if (Object.keys(contactData).length === 0) {
                            return;
                        }
                        contactData.createAt = Date.now();

                        if (this.addDialogModel.getProperty("/newContactData/default_contact") ) {
                            if (contactData.userId) {
                                delete contactData.userId;
                            }

                            let oContact = aContacts.find(o => o.default_contact === true);
                            if(oContact){
                                delete oContact.default_contact;
                            };

                            let defaultRecentlyUsed = this.addDialogModel.getProperty("/recentlyUsedContacts").find(o => o.default_recent_contact === true && o.email !== contactData.email);

                            if (defaultRecentlyUsed) {
                                defaultRecentlyUsed.default_recent_contact = false;
                            }


                            this.saveDefaultContact(contactData);
                        }
                        await this.contactCtrl.updateContact(() => {
                            this.contactCtrl._oContactHelper.addContact(contactData);
                        });
                        this.addContactDialog.close();
                        this.addDialogModel.setProperty("/newContactIsCreating", false);

                        // async check and update recently used contact
                        if (this.contactCtrl.getContactHelperType().startsWith("EDIT")) {
                            const rucc = this.calcRecentlyUsedContactCandidate();
                            if (rucc.length > 0) {
                                this.saveNewRecentlyUsedContact(rucc);
                            }
                        }
                    }
                    this.addContactDialog.setBusy(false);
                }.bind(this))();

        },

        checkForDuplicateContact: function(oNewContact, aList){
            return aList.some(contact => contact.email === oNewContact.email && contact.telephone === oNewContact.telephone && contact.email !== '' && contact.telephone && contact.telephone!=='')
        },

        formatTimezoneDescription: function(timezoneKey, timezoneList = []) {
            let timezone = timezoneList.filter(item => (item.IANATZONE === timezoneKey || item.TZONE === timezoneKey));
            // to compatiable with old timezone data
            // for old data, if only one value in timezoneList, use the current value
            return timezone.length === 1 ? timezone[0].IANATZONE : timezoneKey;
        },

        formatIsAddDialogSubmitBtnEnable : function(sContactName, sRole, newContactIsCreating) {
            return !!sContactName && !ContactHelperFactory.isRoleDuplicate(sRole) && !newContactIsCreating;
        },

        cancel : function() {
            this.addContactDialog.close();
        },

        // calc recently used contact candidate
        calcRecentlyUsedContactCandidate : function() {
            // nrucc : new recently used contact candidate
            let nrucc = this.contactCtrl._oContactHelper.getContact().filter(contact => contact.isCreatedByFreeStyle);
            if (!nrucc || nrucc.length === 0) {
                return [];
            }
            nrucc = this._removeDuplicateRecentlyUsedContact(nrucc)
                .sort((contact1,contact2) => contact1.createAt - contact2.createAt)
                .reverse();
            if (nrucc.length >= RECENTLY_USED_CONTACT_MAX_SIZE) {
                return nrucc.slice(0,RECENTLY_USED_CONTACT_MAX_SIZE);
            }

            // orucc: old recently used contact candidate
            const orucc = this.addDialogModel.getProperty("/recentlyUsedContacts");
            if (orucc.length === 0) {
                return nrucc;
            }

            // trucc: total recently used contact candidate
            nrucc.push(...orucc);
            const trucc = this._removeDuplicateRecentlyUsedContact(nrucc);
            return trucc.slice(0,RECENTLY_USED_CONTACT_MAX_SIZE);
        },

        saveNewRecentlyUsedContact : function(rucc) {
            if (rucc.length === 0) {
                return;
            }
            return this._saveRecentlyUsedContacts(rucc)
                .then(() => {
                    rucc.forEach(contact => {
                        contact.isCreatedByFreeStyle = false;
                    });
                    this.addDialogModel.setProperty("/recentlyUsedContacts", rucc);
                }).then(() => {
                    const list = rucc.map(contact => contact.contact + "_" + contact.email);
                    const contactList = this.contactCtrl._oContactHelper.getContact();
                    contactList.forEach(contact => {
                        const key = contact.contact + "_" + contact.email;
                        if (contact.isCreatedByFreeStyle && list.find(k => k === key)) {
                            contact.isCreatedByFreeStyle = false;
                        }
                    });
                    this.contactCtrl._oContactHelper.replaceAll(contactList);
                });
        },

        _removeDuplicateRecentlyUsedContact : function(ruc) {
            const uniqueArray = [];
            const map = new Map();
            for (const item of ruc) {
                const key = item.contact + "_" + item.email;
                if (!map.has(key)) {
                    map.set(key, true);
                    uniqueArray.push(item);
                }
            }
            return uniqueArray;
        },

        _initRecentlyContact : async function() {
            const recentlyUsedContact = await this._getRecentlyUsedContacts();
            this.addDialogModel.setProperty("/recentlyUsedContacts", recentlyUsedContact);
            if (recentlyUsedContact.length === 0) {
                this.addDialogModel.setProperty("/tabModel/selectedKey", KEY_TAB_NEW_CONTACT);
            }
        },

        _getRecentlyUsedContacts : async function() {
            try {
                const caseSettings = await jQuery.ajax("/backend/raw/common/Settings/CASE");
                const recentlyContacts = caseSettings["CASE.RECENTLY_CONTACTS"];
                if (!recentlyContacts[0]) {
                    return [];
                }
                let aRecentlyContacts = recentlyContacts.map(json=>JSON.parse(json));
                let oDefaultContact = this.contactCtrl.getView().getModel("$this.caseContacts").getProperty("/defaultContact");
                aRecentlyContacts.forEach(
                    (contact, index)=>{
                        delete aRecentlyContacts[index].default_contact;
                        if(contact.default_recent_contact && (contact.telephone !== oDefaultContact.telephone) && (contact.email !== oDefaultContact.email)){
                            delete aRecentlyContacts[index].default_recent_contact;
                        }
                    }
                    );
                return aRecentlyContacts;
            }catch(e){
                console.log("query recently contact fail");
                return [];
            }
        },

        _saveRecentlyUsedContacts : function(rucc) {
            let copy = deepClone(rucc);
            copy = copy.map(contact => {
                delete contact.isCreatedByFreeStyle;
                return JSON.stringify(contact);
            });
            return jQuery.ajax("/backend/raw/common/Settings", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify({"CASE.RECENTLY_CONTACTS":copy}),
            });
        },

        saveDefaultContact : function(defaultContact) {
        //validate defaultContact details
            this.validateDefaultContactData(defaultContact);
        // convert defaultContact object into array before sending it to backend
            let aContact = Object.keys(defaultContact).map((key) => [key, defaultContact[key]]);
            return jQuery.ajax("/backend/raw/common/Settings/CASE", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify({"CASE.DEFAULT_CONTACT": [JSON.stringify(aContact)]}),
            }).done(() => {
                if(this.oDefaultSwitch){
                    this.oDefaultSwitch.setState(false);
                }
               // this.addDialogModel.setProperty("/default_switch_tooltip", this._i18n.getText("defaultContactCheckBox_default_already_exists_tooltip"));
            }).fail((oError) => {
                console.log("Error updating default contact: " + oError);
            });
        },

        validateDefaultContactData : function(oContact){
            if(!oContact.email){
                oContact.email = "";
            }
            if(!oContact.telephone){
                oContact.telephone = "";
            }
        },

        removeDefaultContact : function() {
            return jQuery.ajax("/backend/raw/common/Settings", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify({"CASE.DEFAULT_CONTACT": [""]}),
            }).done(() => {
                if (this.oDefaultSwitch) {
                    this.oDefaultSwitch.setState(false);
                }
                this.addDialogModel.setProperty("/default_switch_tooltip", this._i18n.getText("DefaultSwitch_tooltip"));

            }).fail((oError) => {
                console.log("Error deleting default contact: " + oError);
            });
        }


    });

    return instance;
});

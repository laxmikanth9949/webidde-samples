sap.ui.define([
    "./CreateSystemSelectDialog",
    "sap/me/support/model/formatter",
], function(
    CreateSystemSelectDialog,
    formatter,
) {

    "use strict";

    const Controller = CreateSystemSelectDialog.extend("sap.me.support.fragments.Step0SystemDialog", {

        constructor: function(step0Ctrl) {
            this.step0Ctrl = step0Ctrl;
            this.productAllList = [];
            CreateSystemSelectDialog.prototype.constructor.call(this, this.step0Ctrl.oCard);
        },

        onPressItem : async function(oEvent) {
            const informationModel = this.creationCard._oIssueInformationModel;
            const oldValue = this.creationCard.fragmentControllers.BasicInformationStep.data.system.info;

            const selectedKey = this.iconTabBarModel?.getProperty?.("/selectedKey");
            const systemInfo = oEvent.getSource().getBindingContext(selectedKey === "all" ? "$this.odata" : "systemSelectionList").getObject();
            const selectedSystemNumber = systemInfo.systemNumber || systemInfo.Name;

            if (oldValue && oldValue.systemNumber === selectedSystemNumber) {
                this._oDialog.close();
                return;
            }

            const commonSystem = this.handleSelectedSystemData(systemInfo);
            const currentDisplayName = formatter.formatSystemDisplayName(`${commonSystem.systemId} - ${commonSystem.systemName}`);

            const sNewValue = {
                currentDisplayName,
                systemNumber: commonSystem.systemNumber,
                installationNbr: commonSystem.installationNbr,
                dataProcessRestriction: systemInfo?.dataProcessRestriction ? systemInfo.dataProcessRestriction : systemInfo.Desc2,
                systemId: commonSystem.systemId,
                systemName: commonSystem.systemName,
                isSystemCloud: commonSystem.isSystemCloud,
                leadingProduct : commonSystem.leadingProduct,
                systemURL: commonSystem.systemURL,
            };
            this.creationCard.fragmentControllers.BasicInformationStep.data.system.info = sNewValue;

            this.setCloudSystemDetailVisible(false);
            // when system is cloud system ,should disable the systemdetail
            this.getShowSystemDetailFlag(selectedKey)
                .then(isShowSystemDetail => isShowSystemDetail && this.callSystemInfo(systemInfo),
                    e => console.error("fetch system detail flag fail"));
            this.setDataProcessingRestrictionLabel();
            this.setSystemURLLabel();
            this._checkIsAttachmentBlockedAndClassified();

            this.creationCard.sendSAPHanaCloudProductChange();

            this.cancelSelectSystemDialog();

            // fetch the product/pf all list
            // fetch the p/pf prediction, compare
            // fetch solutions with the p info
            return Promise.allSettled([
                this.fetchAllProduct(commonSystem.systemNumber),
                this.fetchPredictedProduct(commonSystem.systemNumber)
            ]).then(res => {
                let predictP = {};
                if (this.predictedThreshold) {
                    predictP = this.productAllList?.find(item => item.ModelNumber === this.predictedProducts[0]?.product_simcat_node_id);
                };
                this.step0Ctrl.predictP = predictP;
                this.step0Ctrl.showSolutions();
            });
        },

        fetchAllProduct : function(sysNbr) {
            return this.creationCard.getAllProductList(sysNbr).then(data => {
                this.productAllList = data?.product;
                this.creationCard.swaServiceEvent.systemSelected(this.defineEventTrackTypeForSysSelected(), this.productAllList, "Setp 0");
                return;
            }).catch(err => console.log(`fetch all product failed with the error ${err?.responseText || err?.responseJSON}` ));
        },

        fetchPredictedProduct : function(sysNbr) {
            return this.creationCard.getPredictedProduct(sysNbr).then(data => {
                this.predictedProducts = data?.results;
                this.predictedThreshold = data?.conf_threshold_met;
                return;
            }).catch(err => console.log(`fetch predicted product failed with the error ${err?.responseText || err?.responseJSON}` ));
        },

        checkSystemAvailability : async function() {
            const pageItem = this.creationCard.oCard.getContent().getItems()[2];
            pageItem.setBusy(true);

            // hide the warning msg script at the beginning
            this.creationCard.fragmentControllers.BasicInformationStep.data.system.systemMsgStripVisible = false;

            try {
                const result = await $.ajax("/backend/odata/support/CloudSystemStatus", {
                    contentType: "application/json",
                    data : {
                        $filter : "(uName eq '" + this.chosenSystemBasicInfo.suserId + "' and systemNumber eq '" + this.chosenSystemBasicInfo.systemNumber + "')"
                    }
                });

                // returns nothing means this system status is good, no error events occur
                if (!result || result.value?.length <= 0) {
                    this.chosenSystemAvaInfo = undefined;
                    return;
                }

                const systemAvailabilityInfo = result.value[0];
                const eventTime = this.formatSystemAffectedEventTime(systemAvailabilityInfo.eventStartTime);
                this.chosenSystemAvaInfo = {
                    cloudOutageType: systemAvailabilityInfo.typeText,
                    cloudOutageTypeCode:systemAvailabilityInfo.type,
                    eventId: systemAvailabilityInfo.eventID,
                    eventTime: eventTime,
                    date: eventTime.toLocaleDateString(),
                    time: eventTime.toLocaleTimeString(),
                    originalEventTime: systemAvailabilityInfo.eventStartTime
                };
            } catch (e) {
                console.error("checkSystemAvailability fail");
            } finally {
                pageItem.setBusy(false);
            }
        },

        isSystemAvailable : function() {
            return !this.chosenSystemAvaInfo;
        },

    });

    return Controller;
});

sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/me/support/utils/helper",
    "sap/me/support/utils/CaseCreationDialogHelper"
], function(Object, Fragment, JSONModel, MessageToast, Filter, FilterOperator, helper, DialogHelper) {
    "use strict";
    return Object.extend("sap.me.support.fragments.CreateSelectProductFunctionDialog",{

        constructor: function(oCard) {
            this._oView = oCard.getCard();
            this._createCaseCard = oCard;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            // used for close dialog
            this.dialogResolve = () => {};
        },

        open: function(inputSource) {
            const waitForDialogClose = new Promise((resolve) => {
                this.dialogResolve = resolve;
            });
            this.afterSearchAndOpenDialogAgain();
            const suggestedList = this._createCaseCard._oProductFunctionModel.getProperty("/suggest");
            const defaultSelectKey = suggestedList.length > 0 ? "suggestProductFunction" : "allProductFunction";

            if (this._oDialog) {
                this._oDialog.getContent()[0].setValue("");
                this._createCaseCard._oProductFunctionModel.setProperty("/isProductFnSearchTabVisible", false);
                this.iconTabBarModel.setProperty("/selectedKey", defaultSelectKey);
                this._oDialog.open();
                inputSource?.setBusy(false);
            } else {
                Fragment.load({
                    name: "sap.me.support.fragments.CreateSelectProductFunctionDialog",
                    controller: this
                }).then(function(Dialog) {
                    this._oDialog = Dialog;
                    this._oView.addDependent(this._oDialog);
                    this.selectProductFunctionTabBar = this._oDialog.getContent()[1];
                    this._oDialog.setModel(this.iconTabBarModel = new JSONModel({
                        selectedKey: defaultSelectKey
                    }), "$this.iconTabBar");
                    this._oDialog.open();
                    inputSource?.setBusy(false);
                }.bind(this));
            }
            const recommendedModelNumbers = this._createCaseCard._oProductFunctionModel.getProperty("/recommendedModelNumbers");
            this._createCaseCard.swaServiceEvent.swaValueHelperRecommendations("User (Product Function)", recommendedModelNumbers);
            return waitForDialogClose;
        },

        close: function() {
            this._oDialog.close();
        },

        onTabBarChange: function(oEvent) {
            const selectedKey = oEvent.getParameters().key;
            this.iconTabBarModel.setProperty("/selectedKey", selectedKey);
        },

        afterSearchAndOpenDialogAgain: function() {
            // const productModelNumber = this._createCaseCard._oIssueInformationModel.getProperty("/product")?.ModelNumber;
            const productModelNumber = this._createCaseCard.fragmentControllers.BasicInformationStep.data.product.info?.ModelNumber;
            if (this._oSearchInput && productModelNumber !== this._oProductNumber) {
                this._createCaseCard._oProductFunctionModel.setProperty("/isProductFnSearchTabVisible", false);
            }
            this._oProductNumber = productModelNumber;
        },

        clearPreviousProduct: function() {
            this._oProductNumber = "";
        },

        onProductFunctionSelected: async function(oEvent) {
            const source = oEvent.getSource();
            const productFunctionItem = source.getBindingContext("productFunctionList").getObject();
            const productFunctionIndex = source.getParent().getItems().indexOf(source);
            if (!productFunctionItem.nodes) {
                const sPreviousValue = this._createCaseCard.fragmentControllers.BasicInformationStep.data.productFunction.info;
                if (sPreviousValue && sPreviousValue.ModelNumber === productFunctionItem.ModelNumber) {
                    this._oDialog.close();
                    return;
                }
                // should check entitlment, and if product function is prevent,should show warning pop up
                const checkResult = this._createCaseCard.handleEntitlementCheck(productFunctionItem.CheckResult);
                if(checkResult.prevent) {
                    return;
                }

                const isShowMsgBox = this._createCaseCard.timeLineLayoutControl.data.timeLineItems[this._createCaseCard._oProcessBarActionStepIndex].isStepPreviewEditEnabled;

                if (isShowMsgBox) {
                    const msgTitle = this._i18n.getText("case_creation_input_change_warn_dialogue_title_issueInformation");
                    const msgDesc = this._i18n.getText("product_function_change_preview_warning_text");
                    const sAction = await DialogHelper.showMsgBox(msgTitle, msgDesc);
                    switch (sAction) {
                        case "Confirm":
                            this.afterSelection(productFunctionItem, productFunctionIndex);
                            break;

                        case "Cancel":
                            this._createCaseCard.fragmentControllers.BasicInformationStep.data.productFunction.info = sPreviousValue;
                            break;
                    }
                } else {
                    this.afterSelection(productFunctionItem, productFunctionIndex);
                }
            }
        },

        afterSelection: function(sSelectItem, sSelectItemIndex) {
            if (this.iconTabBarModel.getProperty("/selectedKey") === "allProductFunction") {
                this.tagRecommendedLabel(sSelectItem);
            }
            this.sSelectItemIndex = sSelectItemIndex;
            this.dialogResolve(sSelectItem);
            this._oDialog.close();
        },

        onSearch: function(oEvent) {
            this._oSearchInput = oEvent.getSource();
            const searchValue = oEvent.getSource().getValue().trim();
            this._createCaseCard._oProductFunctionModel.setProperty("/isProductFnSearchTabVisible", true);
            this.selectProductFunctionTabBar.setSelectedKey("searchProductFunction");
            const searchList = this.selectProductFunctionTabBar.getItems()[2].getContent()[0];
            const allFilterList = [];
            if (searchValue.length !== 0) {
                const filterProperties = ["DisplayName", "AddSearchTerms"];
                const filterList = filterProperties.map(item => new Filter({path: item, operator: FilterOperator.Contains, value1: searchValue, caseSensitive: false}));
                allFilterList.push(new Filter({path: "DrillState", operator: FilterOperator.EQ, value1: "Leaf", caseSensitive: false}));
                allFilterList.push(new Filter({filters: filterList, and: false}));
            }
            searchList.getBinding("items").filter(allFilterList);
        },

        markRecommendProductFunction: function(modelNum) {
            return this._createCaseCard?._mostRecommendProductFunction === modelNum;
        },

        tagRecommendedLabel: function(productFunction) {
            productFunction.Recommended = this._createCaseCard._oProductFunctionModel.getProperty("/suggestModelNumber").includes(productFunction?.ModelNumber);
        },

        /**
         * for adobe event listener
         */
        adobeEventListener: function(oProductFunction) {
            const selectTab = this.selectProductFunctionTabBar.getSelectedKey();
            const productFunctionIndex = this.sSelectItemIndex;
            let trackName = "";
            switch (selectTab) {
                case "allProductFunction":
                    trackName = "User(Hierarchy)";
                    if (oProductFunction?.Recommended) {
                        trackName = "User(Recommended)";
                    }
                    break;
                case "suggestProductFunction":
                    trackName = "User(Recommended)";
                    break;
                case "searchProductFunction":
                    trackName = "User(Searched)";
                    break;
            }
            this._createCaseCard.trackProductFunctionChange(trackName,oProductFunction,productFunctionIndex,"");
        }

    });

});

sap.ui.define([
    "sap/me/support/utils/TextEditor",
    "sap/me/support/utils/helper",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/cards/caseCreationCards/BaseFragmentController"
], function(TextEditor, Helper, MessageToast, JSONModel, BaseFragmentController) {
    "use strict";
    return BaseFragmentController.extend("sap.me.support.fragments.CaseDetailReplyDialog", {
        constructor: function(oCaseDetail) {
            this.oCaseDetail = oCaseDetail;
            this._oView = oCaseDetail._oView;
            this._oSimpleStatus = oCaseDetail._oSimpleStatus;
            this._oPointer = oCaseDetail._oPointer;
            this._oEventBus = sap.ui.getCore().getEventBus();
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._oView.setModel(this.messageStripData = new JSONModel({enabled: true}), "messageStrip");
        },

        open: function() {
            if (this._oDialog) {
                this._oDialog.open();
                this.setDialogMask();
                return;
            }
            this._oDialog = this.loadFragment("sapMeCaseDetailReplyDialog", this._oView.getId(), "sap.me.support.fragments.CaseDetailReplyDialog", this);
            this._oView.addDependent(this._oDialog);
            this._oDialog.open();
            this._oDialog.attachEvent("afterClose", () => {
                this.recoverDialogMask();
            });
            this.setDialogMask();
            this._createRichTextEditor();
        },

        _createRichTextEditor: function() {
            const editorVBox = this._oDialog.getContent()[1];
            editorVBox.removeAllItems();
            this._oEditor = new TextEditor.createRichTextEditor("caseDetailRichTextEditor" + Helper.generateUUID(),{
                editable: true,
                value:"",
                readOnly: false,
                statusbar: false,
                height: "inherit",
                change: () => {}
            },this._createRichTextEditor);
            editorVBox.addItem(this._oEditor);
            this._oEditor.setHeight("inherit");
        },

        setDialogMask: function() {
            $("#sap-ui-blocklayer-popup").css("pointer-events", "none").css("visibility", "hidden");
        },

        closeDialog: function() {
            this._oDialog.close();
        },

        cancelDialog: function() {
            this._oEditor.setValue("");
            this.closeDialog();
        },

        closeMessageStrip: function() {
            this.messageStripData.setProperty("/enabled", false);
            const editorVBox = this._oDialog.getContent()[1];
            editorVBox.setHeight("100%");
        },

        recoverDialogMask: function() {
            $("#sap-ui-blocklayer-popup").css("pointer-events", "auto").css("visibility", "visible");
        },

        _onPressSubmitReply: function() {
            if (this._oEditor.getValue() !== "") {
                this._oView.setModel(this._doubleClickModel = new JSONModel({enabled: false}), "isDoubleSubmit");
                this._sendToUpdate();
            } else {
                MessageToast.show(`${this._i18n.getText("case_discussion_content_empty")}`);
            }
        },

        _sendToUpdate: function() {
            const data = {
                action: "SEND2SAP",
                pointer: this._oPointer,
                long_text: this._oEditor.getValue(),
                status: this._oSimpleStatus
            };
            this._oDialog.setBusy(true);
            return this.updateListRequest(data).then(() => {
                this._oDialog.setBusy(false);
                this.closeDialog();
                // update case header status
                this.oCaseDetail._oODataModel.refresh();
                this._doubleClickModel.setProperty("/enabled", true);
                MessageToast.show(`${this._i18n.getText("case_discussion_submit_reply_success")}`);
                this._oEventBus.publish("sap.me.support.fragments.CaseDetailReplyDialog", "newReplied");
                // after submit clear content
                this._oEditor.setValue("");
            }, () => {
                this._oDialog.setBusy(false);
                this.closeDialog();
                this.oCaseDetail._failedDialog.open();
                this._doubleClickModel.setProperty("/enabled", true);
            });
        },

        updateListRequest: function(data) {
            return jQuery.ajax("/backend/raw/support/CaseUpdateVerticle", {
                method: "PUT",
                contentType: "application/json",
                data: JSON.stringify(data)
            });
        },
    });
});

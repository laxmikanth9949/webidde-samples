sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/me/cards/model/models",
    "sap/m/FormattedText",
    "sap/ui/core/routing/Router",
    "../utils/helper",
    "../utils/Constants",
    "sap/me/support/model/formatter",
    "sap/m/MessageToast"
], function(BaseObject, Fragment, JSONModel, Filter, FilterOperator, models, FormattedText, Router, helper, Constants, formatter, MessageToast) {
    "use strict";
    return BaseObject.extend("sap.me.support.fragments.SystemSelectFromKbaFilterDialog", {

        formatter: formatter,

        constructor: function(oView) {
            this._notesCard = oView;
            this._oView = oView.getCard();
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._selectedSystemList = [];
            this._confirmSelectedSystems = [];
            this._notesCard.setModel(this._notesCard._oSelectSystemMessageStripModel = new JSONModel({
                count: 0,
                type: "Information"
            }),"messageStripInfo");
            this._oView.setModel(this.systemSelectedTokens = new JSONModel({
                tokens: []
            }), "$this.selectionToken");
        },

        openSystemDialog: function() {
            this._changeMessageStripType("Information");
            return this._oDialog ? (() => {
                this._resetSystemsForDialogList();
                this._oDialog.open();
            })() : Fragment.load({
                name: "sap.me.support.fragments.SystemSelectFromKbaFilterDialog",
                controller: this
            }).then((Dialog) => {
                this._oDialog = Dialog;
                this._oView.addDependent(this._oDialog);
                this._oDialog.setModel(this._notesCard._oSystemDataModel, "systemSelectionList");
                this._resetSystemsForDialogList();
                this._oDialog.open();
            });
        },

        closeSystemDialog: function() {
            this._oDialog.close();
            this._changeMessageStripType("Information");
        },

        onSearch: function(oEvent) {
            this._notesCard._oSystemDataModel.setProperty("/selectedKey","all");
            this._systemSearch = oEvent.getSource();
            let sQuery = oEvent.getSource().getValue();
            this._notesCard._oSystemDataModel.aBindings.filter(v => v.sPath === "/allList")[0]?.filter(this.getAllFilters(sQuery));
        },

        getAllFilters: function(sQuery) {
            let result = [];
            if (sQuery && sQuery.trim().length > 0) {
                const filterProperties = ["sysid", "sysnr", "name", "installationNumber", "installationName", "productKey", "type", "officialProdName", "officialProdNum", "sysrole"];
                const aCustomerFilters = filterProperties.map(item => new Filter({
                    path: item,
                    operator: FilterOperator.Contains,
                    value1: sQuery,
                    caseSensitive: false
                }));
                result.push(new Filter({
                    filters: aCustomerFilters,
                    and: false
                }));
            }
            return result;
        },
        /**
         * @description Because the functions provided by MultiSelect have many bugs, so I created a cache to achieve the functionality I wanted
         *  Please do not make changes unless you understand this function
         */
        onSystemSelect: function(oEvent) {
            let focusItem;
            oEvent.getSource().getItems().forEach(obj => {
                focusItem = obj.getModel("systemSelectionList").getContext(obj.getBindingContext("systemSelectionList").sPath).getObject();
                // logic for increases
                if (obj.getSelected()) {
                    if (this._selectedSystemList.indexOf(focusItem) === -1) {
                        if (this._selectedSystemList.length === 10) {
                            obj.setSelected(false);
                            this._changeMessageStripType("Warning");
                        }
                        if (this._selectedSystemList.length < 10) {
                            this._selectedSystemList.push(focusItem);
                        }
                    }
                // logic for reduce
                } else if (this._selectedSystemList.indexOf(focusItem) !== -1) {
                    this._selectedSystemList.splice(this._selectedSystemList.indexOf(focusItem), 1);
                    this._changeMessageStripType("Information");
                }
            });
            this.systemSelectedTokens.setProperty("/tokens", this._selectedSystemList);
            this._updateSelectedCount(this._selectedSystemList.length);
        },

        _updateSelectedCount: function(count) {
            if (count >= 0 && count <= 10) {
                this._notesCard._oSelectSystemMessageStripModel.setProperty("/count", count);
            }
        },

        onSystemTokenChange: function(oEvent) {
            const oRemoved = oEvent.getParameter("removedTokens")[0];
            if (!oRemoved) {
                return;
            }
            const itemKey = oRemoved.getKey();
            const selectList = sap.ui.getCore().byId("sapMeKBAMultiSelectSystemList").getItems();
            const removeItem = selectList.find(item => item.getBindingContext("systemSelectionList")?.getObject()?.sysnr === itemKey);
            if (removeItem) {
                removeItem.setSelected(false);
            }

            this._selectedSystemList = this._selectedSystemList.filter(v => v?.sysnr !== itemKey);
            this.systemSelectedTokens.setProperty("/tokens", this._selectedSystemList);
            this._changeMessageStripType("Information");
            this._updateSelectedCount(this._selectedSystemList.length);
        },

        // call favorite service to change system favorite
        _bookSystemFavorite: function(systemNum, isFav) {
            return jQuery.ajax("/backend/odata/support/SystemSearch", {
                method: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    systemNumber: systemNum,
                    isFavorite: !isFav
                })
            });
        },

        onPressFavoriteForSystem: function(oEvent) {
            if (this._blockFavoriteButton()) {
                return;
            }
            const system = oEvent.getSource().getBindingContext("systemSelectionList").getObject();
            this._bookSystemFavorite(system?.sysnr, system?.isFavorite);
            this._changeIsFavorite(system);
        },

        // change the UI behavior
        _changeIsFavorite: function(item) {
            this._notesCard._oSystemDataModel.getData().allList.forEach(obj => {
                if (obj?.sysnr === item?.sysnr) {
                    obj.isFavorite = !item.isFavorite;
                }
            });
            this._notesCard._oSystemDataModel.refresh();
        },

        // check is need to block favorite button
        _blockFavoriteButton: function() {
            if (this._notesCard._oSimulatedUser) {
                MessageToast.show(this._i18n.getText("SystemSelectFavoriteBlock"));
                return true;
            }
            return false;
        },

        getSelectedSystems: function() {
            return this._confirmSelectedSystems.map(item => this._notesCard.handleDifferentSystemObj(item));
        },

        onConfirmSystemDialog: function() {
            this._confirmSelectedSystems = this._selectedSystemList;
            this._notesCard._filterDialog.setSystemMultiInput(this.getSelectedSystems());
            this._oDialog.close();
            this._changeMessageStripType("Information");
        },

        cleanSystemDialogCache: function() {
            this._selectedSystemList = [];
            this._confirmSelectedSystems = [];
            this._notesCard._oSelectSystemMessageStripModel.setProperty("/count",0);
            // clear search
            this._notesCard._oSystemDataModel?.aBindings?.filter(v => v.sPath === "/allList")[0]?.filter([]);
            this?._systemSearch?.setValue("");
            sap.ui.getCore().byId("sapMeKBAMultiSelectSystemList")?.removeSelections();
            this.systemSelectedTokens.setProperty("/tokens", []);
        },

        _resetSystemsForDialogList: async function() {
            // step 1 clean cache
            this.cleanSystemDialogCache();
            // step 2 reset
            const inputSystems = this._notesCard._filterDialog.getSystemMultiInputSystems() ?? [];
            // sort system list
            this._notesCard._filterDialog._updateAllSystemModel(this._notesCard._oSystemDataModel.getProperty("/allList"), inputSystems);
            sap.ui.getCore().byId("sapMeKBAMultiSelectSystemList").getItems().forEach(item => {
                if (inputSystems.indexOf(item.getModel("systemSelectionList").getContext(item.getBindingContext("systemSelectionList").sPath).getObject()?.sysnr) !== -1) {
                    item.setSelected(true);
                    this._selectedSystemList.push(item.getModel("systemSelectionList").getContext(item.getBindingContext("systemSelectionList").sPath).getObject());
                    this._confirmSelectedSystems.push(item.getModel("systemSelectionList").getContext(item.getBindingContext("systemSelectionList").sPath).getObject());
                    this._updateSelectedCount(this._selectedSystemList.length);
                }
            });
            this.systemSelectedTokens.setProperty("/tokens", this._selectedSystemList);
            this._scrollToTop();
        },

        _scrollToTop: function() {
            sap.ui.getCore().byId("sap4meKbaNotesSelectedSystemScroll")?.scrollTo(0,1);
        },

        onResetPress: function() {
            this.cleanSystemDialogCache();
            this._notesCard._filterDialog.setSystemMultiInput([]);
            this._changeMessageStripType("Information");
        },

        _changeMessageStripType: function(type) {
            this._notesCard._oSelectSystemMessageStripModel.setProperty("/type",type);
        }
    });
});

sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/me/support/utils/helper",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/me/support/fragments/CaseCreationChangeComponentDialog",
    "sap/me/shared/FeatureToggles",
    "sap/me/support/utils/engineerMemo/index",
    "sap/me/support/utils/Constants"
], function(ObjectBase, Fragment, helper, JSONModel, MessageBox, CaseCreationChangeComponentDialog, FeatureToggles, engineerMemo, Constants) {
    "use strict";
    const {ProductMemoUtil, ProductFunctionMemoUtil, ComponentMemoUtil} = engineerMemo;
    return ObjectBase.extend("sap.me.support.fragments.CreateSelectComponentDialog",{

        constructor: function(oCard) {
            this._oView = oCard.getCard();
            this._caseCreationCard = oCard;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._confirmText = this._i18n.getText("comp_change_message_box_keep_change");
        },

        open: function() {
            if (this._oDialog) {
                this.iconTabBarModel.setProperty("/selectedKey", helper.getTabDefaultSelectKey("allComponent", this._oDialog.getContent()[1]));
                this._oDialog.open();
            } else {
                Fragment.load({
                    name: "sap.me.support.fragments.CreateSelectComponentDialog",
                    controller: this
                }).then(function(Dialog) {
                    this._oDialog = Dialog;
                    this._oIconTabFilters = this._oDialog.getContent()[1];
                    this._oIconTabFilters.setSelectedKey("recentlyUsedComponent");
                    this._oView.addDependent(this._oDialog);
                    this._oDialog.open();
                    this._oDialog.setModel(this.iconTabBarModel = new JSONModel({
                        selectedKey: helper.getTabDefaultSelectKey("allComponent", this._oDialog.getContent()[1])
                    }), "$this.iconTabBar");
                }.bind(this));
            }
            const componentSuggestList = this._caseCreationCard._oComponentModel.getProperty("/suggest");
            this._caseCreationCard.swaServiceEvent.swaValueHelperRecommendations("User (Component)", componentSuggestList.map(v => v.CompKey));
        },

        onTabBarChange: function(oEvent) {
            const selectedKey = oEvent.getParameters().key;

            this.iconTabBarModel.setProperty("/selectedKey", selectedKey);
        },

        close: function() {
            this._oDialog.getContent()[0].setValue("");
            this._caseCreationCard._oComponentModel.setProperty("/isSearchTabVisible", false);
            this._oIconTabFilters.setSelectedKey("suggestedUsedComponent");
            this._oDialog.close();
        },

        formatCompNameDesc: function(compName, compDesc) {
            return compName + " (" + compDesc + ")";
        },

        formatCompDescName: function(compName, compDesc) {
            return compDesc + " (" + compName + ")";
        },

        formatComponentItemTreeType: function(compNotSelectable) {
            return compNotSelectable === "" ? "Active" : "Inactive";
        },

        formatComponentItemTreeVisible: function(compCategory, compNotSelectable, compHasChild) {
            return !((compCategory === "LEVEL1") && (compHasChild === "") && (compNotSelectable === "X"));
        },

        onSearch: function(oEvent) {
            this._oIconTabFilters.setBusy(true);
            let searchValue = oEvent.getSource().getValue();
            let installationNbr = this._caseCreationCard.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr;
            let SWType = this._caseCreationCard._oIssueInformationModel.getProperty("/installationData").SWType;
            jQuery.ajax(`/backend/raw/support/CaseCreateComponentW7?$filter=(SWType eq '${SWType}' and SearchText eq '${searchValue}' and AllComp eq ' ' and Installation eq '${installationNbr}')&resultType=CompSearchSetList`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                success: data => {
                    this._caseCreationCard._oComponentModel.setProperty("/search", data);
                    this._caseCreationCard._oComponentModel.setProperty("/isSearchTabVisible", true);
                    this._oIconTabFilters.setSelectedKey("searchComponent");
                    this._oIconTabFilters.setBusy(false);
                }
            });
        },

        onComponentSelected: function(oEvent) {
            const sPreviousValue = this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info;
            const sNewValue = {...oEvent.getSource().getBindingContext("componentList").getObject(), selectionMethod: "Manual Selection"};
            // tag Recommended and Recent label for component
            sNewValue.Recommended = this._caseCreationCard._oComponentModel.getProperty("/suggestNameList")?.includes(sNewValue?.CompName);
            sNewValue.Recently = this._caseCreationCard._oComponentModel.getProperty("/recentNameList")?.includes(sNewValue?.CompName);
            if (!sPreviousValue && !sNewValue) {
                return;
            }
            // if selected component is same as previous component, just close dialog
            if (sPreviousValue && sPreviousValue.CompKey === sNewValue.CompKey) {
                this._oDialog.close();
                return;
            }

            // get suggested files list
            this._caseCreationCard.fragmentControllers.CaseCreationAttachmentStep.resetSuggestFileTypeList(sNewValue.CompName);

            // step 6, just change component
            if ((this._oCurrentProcess = this._caseCreationCard._oCurrentProcess) === this._caseCreationCard._oProcessBarSubmitStepIndex) {
                this.openComponentChangedDialog(sNewValue);
                this._cSelectedEvent = oEvent;
                return;
            }

            // step 1, show warning dialog when best action were selected. Otherwise, just other action
            const openWarningHook = () => {
                return this._caseCreationCard.timeLineLayoutControl.data.timeLineItems[this._caseCreationCard._oProcessBarActionStepIndex].isStepPreviewEditEnabled;
            };
            const afterComponentSelectedHook = () => {
                this._setCompValue(sNewValue, () => {
                    this.trackBasicInfoStepCChangeByUser(oEvent);
                    // reset time line
                    this._caseCreationCard.resetTimeLineAfterStepOneValueChanged();
                });
            };
            const afterConfirmHook = () => {
                // comp_url prefill situation
                if (this._caseCreationCard.compURLPrefillMode) {
                    return afterComponentSelectedHook();
                }
                this.componentChangeShowMessageBox(sNewValue,sPreviousValue,afterComponentSelectedHook);
            };
            const afterCancelHook = () => {
                this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info = sPreviousValue;
            };
            this._caseCreationCard.setSelectedValue(openWarningHook,afterConfirmHook,afterCancelHook,
                this._i18n.getText("case_creation_input_change_warn_dialogue_title_issueInformation"),
                this._i18n.getText("product_function_change_preview_warning_text"));
            if (FeatureToggles.get("feature-support-coveo-search")) {
                this._caseCreationCard.coveoUtil.coveoSearch();
            }
        },

        openComponentChangedDialog:function(sNewValue) {
            if (!this._selectChangeComponentDialog) {
                this._selectChangeComponentDialog = new CaseCreationChangeComponentDialog(this);
            }
            this._selectChangeComponentDialog.open(sNewValue);
        },

        onToggleOpenStateComp: function(oEvent) {
            const currentCompName = oEvent.getParameter("itemContext").getProperty("CompName");
            const currentCompIndex = this._getIndexArrayByCompName(this._caseCreationCard._oComponentModel.getProperty("/all"), currentCompName);
            const currentComp = this._caseCreationCard._oComponentModel.getProperty("/all")[currentCompIndex];
            this._oCompTree = sap.ui.getCore().byId(oEvent.getSource().getId());
            const level = this._oCompTree.getItems()[oEvent.getParameter("itemIndex")].getLevel();
            const itemIndex = oEvent.getParameter("itemIndex");
            const expanded = oEvent.getParameter("expanded");

            if (typeof currentComp !== "undefined") {
                if (expanded && (typeof currentComp.nodes === "undefined") && (level === 0)) {
                    // This steps will hide the undefined nodes
                    // 1. collapse the node
                    // 2. request the data with loading
                    // 3. expand the node
                    const subTree = oEvent.getSource();
                    subTree.collapse(itemIndex);
                    this._getNextLevelComponentTree(currentCompName, currentComp, () => {
                        subTree.expand(itemIndex);
                    });
                }
            }
        },

        _getIndexArrayByCompName: function(comp, compName) {
            let hasParent = false;
            for (var i = 0; i < comp.length; i++) {
                if (comp[i].CompName === compName) {
                    hasParent = true;
                    break;
                }
            }
            return hasParent === true ? i : -1;
        },

        _getNextLevelComponentTree: function(currentCompName, currentComp, callback) {
            this._oDialog.setBusyIndicatorDelay(30);
            this._oDialog.setBusy(true);
            const installationNbr = this._caseCreationCard.fragmentControllers.BasicInformationStep.data.system.info?.installationNbr;

            jQuery.ajax(`/backend/raw/support/CaseCreateComponentW7?$filter=(SWType eq '' and SearchText eq '${currentCompName}-*' and AllComp eq 'X' and Installation eq '${installationNbr}')&resultType=CompSearchSetTree`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                success: data => {
                    delete currentComp.__metadata;
                    currentComp.nodes = data;
                    this._oCompTree.getBinding("items").refresh();
                    this._oDialog.setBusy(false);
                    if (typeof callback === "function") {
                        callback();
                    }
                }
            });
        },

        markRecommendComponent: function(oCompKey) {
            return this._caseCreationCard._mostRecommendComponent ? this._caseCreationCard._mostRecommendComponent === oCompKey : false;
        },

        /**
         * @description set component value and check recall channel recommend and to get product and product function of a component
         */
        _setCompValue: function(newComp,callback,isUserChanged) {
            this._caseCreationCard.selectComponent = newComp;
            this._requestProductByComp("compchange").then((data) => {
                this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info = newComp;
                this._caseCreationCard._slaFilesEventSentModel.setProperty("/isSent", false);
                this._caseCreationCard.processPPFCSelectionRecordsArr(ComponentMemoUtil.userChangeOrSelect(isUserChanged, newComp, this.iconTabBarModel.getProperty("/selectedKey")));
                this._handleProductPartAfterRequest(data.data, data.method);
                this._caseCreationCard.setPrioritySelectLimit();
                this._caseCreationCard.attachmentService.changeSuggestedFileIcon("reset");
                this._caseCreationCard.handleProcessAfterProSelection();
                callback && callback();
                this.close();
            }).catch(() => {
                // means prevent.
                // in frist step, do nothing
                // todo in last step, should remember current valid value, open warning and set it back when user click submit
            });
        },

        _compChangeWarningMessageBox: function(nextHook) {
            MessageBox.warning(this._i18n.getText("comp_change_warning_message"), {
                title: this._i18n.getText("comp_change_message_box_title"),
                onClose: nextHook.bind(this),
                actions: [this._confirmText,
                    this._i18n.getText("cancel")],
                emphasizedAction: this._confirmText,
                initialFocus: null,
                textDirection: sap.ui.core.TextDirection.Inherit
            });
        },

        componentChangeShowMessageBox: function(newComp, oldComp, nextHook) {
            // if chose same component do nothing
            if (newComp?.CompKey === oldComp?.CompKey) {
                return;
            }
            // if first time choose a component then just set value
            // if step 2 is not Enabled then component change just set value and doesnt need to show messageBox
            const status = this._caseCreationCard.timeLineLayoutControl.data.timeLineItems[this._caseCreationCard._oProcessBarActionStepIndex].isStepPreviewEditEnabled;
            if (!oldComp || !status) {
                nextHook.call();
                return;
            }

            this._compChangeWarningMessageBox((oEvent) => {
                if (oEvent === this._confirmText ) {
                    nextHook.call();
                }
            });
        },

        _requestProductByComp: async function(method) {
            this._caseCreationCard.currentCardPageView.setBusy(true);

            const issueData = this._caseCreationCard.fragmentControllers.BasicInformationStep.data;
            const systemNum = this._caseCreationCard.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber;
            const componentName = this._caseCreationCard.selectComponent.CompName;
            let filterModelNumberTxt = issueData.productFunction.info?.ModelNumber || issueData.product.info?.ModelNumber || "";

            if (filterModelNumberTxt) {
                filterModelNumberTxt =  ` and ModelNumber eq '${filterModelNumberTxt}'`;
            }

            try {
                const data = await jQuery.ajax("/backend/raw/support/CaseCreateCompMapToProductW7", {
                    method: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    data: {
                        $top: 1,
                        $filter: `SystemNumber eq '${systemNum}' and CompName eq '${componentName}' and UseCaseID eq 'S4MSupportCreate'` + filterModelNumberTxt
                }});
                this._caseCreationCard.currentCardPageView.setBusy(false);
                if(data.length) {
                    const checkResult = this._caseCreationCard.handleEntitlementCheck(data[0].CheckResult, method);
                    if(checkResult.prevent) {
                        return Promise.reject(Constants.ERROR_NOT_ENETITLEMENT);
                    }
                }
                return Promise.resolve({data, method});
            } catch (error) {
                this._handleProductPartAfterRequest([], method);
                this._caseCreationCard.currentCardPageView.setBusy(false);
                return Promise.resolve();
            }
        },

        _handleProductPartAfterRequest: function(data, method) {
            if (data.length >= 1) {
                const result = data[0];
                const modelNumber = result?.ModelNumber;
                const subIndex = modelNumber?.indexOf("-");
                // if '-' exist it means have product and product function else it means only have product
                if (subIndex !== -1) {
                    // use this product and product function
                    this._handleProductPartAfterComponentChange("pp",result, method);
                } else {
                    // use this product and component
                    this._handleProductPartAfterComponentChange("pc",result, method);
                }
                // there is no product and product function found then use component
            } else {
                // use component and hide product and pf
                this._handleProductPartAfterComponentChange("c",{}, method);
                // add the no mapping record if return empty data
                this._caseCreationCard.processPPFCSelectionRecordsArr(ComponentMemoUtil.noPFMapping());
            }

        },

        _handleProductPartAfterComponentChange: function(action,result, method) {
            // if compURLPrefillMode is true, then it means user don't need to show product and product function after check entitlement
            if(this._caseCreationCard.compURLPrefillMode) {
                return;
            }
            let oProduct = this._caseCreationCard.fragmentControllers.BasicInformationStep.data.product.info;
            let oProductFunction = this._caseCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.info;
            let oComponent = this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName;
            // clear cache data and reset again
            this._clearFirstStepProductPart();
            this._caseCreationCard.fragmentControllers.BasicInformationStep.handleProcessAfterSysSelection();
            switch (action) {
                // show product and product function
                case "pp":
                    const product = this._setUpProductData(result);
                    this._caseCreationCard.adobeProductFunctionSelectedType();
                    this._caseCreationCard.trackProductChange(this._handleEventTrackName(method), product, 0, this._handleEventTrackDeterminedText(method));
                    this._caseCreationCard.handleIssueProductInputVisibility(true);
                    this._caseCreationCard.fragmentControllers.BasicInformationStep.data.product.info = product;
                    this._caseCreationCard.getProductFunctionTree(product.ModelNumber);
                    this._caseCreationCard.handleIssueProductFunctionInputVisibility(true);
                    this._caseCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.info = result;
                    this._caseCreationCard.getHotAndTrending(result.ModelNumber, false, "TRUE");
                    this._reCallProductFunctionList(product.ModelNumber, method);
                    this._caseCreationCard.processPPFCSelectionRecordsArr(ProductMemoUtil.normalRelyComp(product.DisplayName, this._caseCreationCard._oSelectionMethodRecords));
                    this._caseCreationCard.processPPFCSelectionRecordsArr(ProductFunctionMemoUtil.normalRelyComp(result.FullName, this._caseCreationCard._oSelectionMethodRecords));
                    this._caseCreationCard.trackProductFunctionChange(this._handleEventTrackName(method), result, 0, this._handleEventTrackDeterminedText(method));
                    break;
                // show product and component
                case "pc":
                    this._caseCreationCard.trackProductChange(this._handleEventTrackName(method), result, 0, this._handleEventTrackDeterminedText(method));
                    if (oProductFunction) {
                        this._caseCreationCard.adobeProductFunctionSelectedType();
                        this._caseCreationCard.trackProductFunctionChange(this._handleEventTrackName(method),{},0,this._handleEventTrackDeterminedText(method));
                    }
                    this._caseCreationCard.handleIssueProductInputVisibility(true);
                    this._caseCreationCard.fragmentControllers.BasicInformationStep.data.product.info = result;
                    this._caseCreationCard.handleIssueProductFunctionInputVisibility(false);
                    this._caseCreationCard.getHotAndTrending(result.ModelNumber, false, "TRUE");
                    this._caseCreationCard.processPPFCSelectionRecordsArr(ProductMemoUtil.normalRelyComp(result.SoftwareProduct, this._caseCreationCard._oSelectionMethodRecords));
                    break;
                // show component
                case "c":
                    const bIsIssueStep = this._oCurrentProcess === this._caseCreationCard._oProcessBarIssueStepIndex;
                    if (bIsIssueStep && oProduct?.ModelNumber) {
                        // if the user stays in the BasicInfo step and has a product selected, then show the product also
                        this._caseCreationCard.fragmentControllers.BasicInformationStep.data.product.visible = true;
                        this._caseCreationCard.fragmentControllers.BasicInformationStep.data.product.info = oProduct;
                        this._caseCreationCard.getHotAndTrending(oProduct?.ModelNumber, false, "TRUE");
                    } else {
                        // if the component is changed in SAC or submit step dialog, and there is no mapped product returned, hide the product input box
                        this._caseCreationCard.fragmentControllers.BasicInformationStep.data.product.visible = false;
                        this._caseCreationCard._oHotAndTrendingModel.setProperty("/isShow", false);
                        this._caseCreationCard.trackProductChange(this._handleEventTrackName(method), result, 0, this._handleEventTrackDeterminedText(method));
                        this._caseCreationCard.updateISMresult(oComponent);
                    }
                    this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.visible = true;

                    if (oProductFunction) {
                        this._caseCreationCard.adobeProductFunctionSelectedType();
                        this._caseCreationCard.trackProductFunctionChange(this._handleEventTrackName(method),{},0,this._handleEventTrackDeterminedText(method));
                    }
                    break;
            }
            this._caseCreationCard.checkResultTxt = this._caseCreationCard.checkResultTxtStore;
            if (method === "url") {
                this._caseCreationCard.trackBasicInfoStepCChange("System (URL)", this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName, undefined);
            }
            this._caseCreationCard.handleIssuePriorityInputVisibility(true);
        },

        _setUpProductData: function(data) {
            const product = Object.assign({}, data);
            const fullName = data.FullName;
            const modelNumber = data.ModelNumber;
            const productName = fullName.substring(0,fullName.indexOf(">"));
            product.ModelNumber = modelNumber.substring(0,modelNumber.indexOf("-"));
            product.ModelCategory = "Product";
            product.DisplayName = productName;
            product.FullName = productName;
            product.name = productName;
            product.Level = "1 ";
            product.ParentModelNumber = "";
            return product;
        },

        _clearFirstStepProductPart: function() {
            this._caseCreationCard.fragmentControllers.BasicInformationStep.data.product.info = null;
            this._caseCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.info = null;
            this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.visible = false;
            this._caseCreationCard.fragmentControllers.BasicInformationStep.data.product.visible = false;
            this._caseCreationCard.fragmentControllers.BasicInformationStep.data.productFunction.visible = false;
            this._caseCreationCard.fragmentControllers.BasicInformationStep.data.priority.visible = false;
            this._caseCreationCard._oTextDescriptionModel.setProperty("/isShowCompWarning", false);
            this._caseCreationCard._oProductFunctionModel.setProperty("/suggest", []);
            this._caseCreationCard._oProductFunctionModel.setProperty("/rec", []);
        },

        _reCallProductFunctionList: function(modelNumber, method) {
            const listTypePFData = this._caseCreationCard.fragmentControllers.BasicInformationStep.formatProductFunctionsToListType(modelNumber);
            this._caseCreationCard.productFunctionPredictor(modelNumber,listTypePFData, method);
            this._caseCreationCard.tagRecentlyUsedProductFunction(listTypePFData);
        },

        /**
         * for adobe event listener
         */
        _handleEventTrackName: function(method) {
            switch (method) {
                case "compchange":
                    return "System(User selected Component)";
                case "sac":
                    return "System(Support Assistant)";
            }
        },

        _handleEventTrackDeterminedText: function(method) {
            switch (method) {
                case "compchange":
                    return "Component Name:" + this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName;
                case "sac":
                    return "Support Assistant:" + this._caseCreationCard._oTrackingData.init_select_data.sac_node_id + ",Component Name:" + this._caseCreationCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName;
            }
        },

        trackBasicInfoStepCChangeByUser : function(oEvent) {
            const {eventSubType, cName, rankingIndex} = this.getCChangeInfoByUser(oEvent);
            this._caseCreationCard.trackBasicInfoStepCChange(eventSubType, cName, rankingIndex);
        },

        trackSubmitStepCChangeByUser : function() {
            const {eventSubType, cName, rankingIndex} = this.getCChangeInfoByUser(this._cSelectedEvent);
            this._caseCreationCard.fragmentControllers.SubmitStep.trackSubmitStepCChangeByUser(eventSubType, cName, rankingIndex);
        },

        getCChangeInfoByUser : function(oEvent) {
            const cListBindingContext = oEvent.getSource().getBindingContext("componentList");
            const path = cListBindingContext.getPath().substring(1);
            let rankingIndex = "", eventSubType;
            if (path.startsWith("suggest")) {
                rankingIndex = path.split("/").reverse()[0];
                eventSubType = "User (Recommended)";
            } else if (path.startsWith("rec")) {
                eventSubType = "User (Recently Used)";
            } else if (path.startsWith("all")) {
                eventSubType = "User (Hierarchy)";
            } else {
                rankingIndex = path.split("/").reverse()[0];
                eventSubType = "User (Searched)";
            }
            const selectedC = cListBindingContext.getObject();
            return {eventSubType:eventSubType, cName:selectedC.CompName, rankingIndex:rankingIndex};
        },

        // if there have sac questions and user manually select component in last step then should set flag true
        _markFlagForExpertChatInitText : function() {
            if (this._caseCreationCard._oProcessBarSubmitStepIndex === this._caseCreationCard._oCurrentProcess) {
                if (this._caseCreationCard._oCaseCreationSAC?.getSACQuestionAndAnswer().length !== 0) {
                    this._manualSelectComponentAfterSACFlag = true;
                }
            }
        },

        getExpertChatSpecialMessageFlag : function() {
            return this._manualSelectComponentAfterSACFlag;
        },

        resetExpertChatSpecialMessageFlag : function() {
            this._manualSelectComponentAfterSACFlag = undefined;
        }

    });
});

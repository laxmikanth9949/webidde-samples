sap.ui.define([
    "sap/me/support/cards/caseCreationCards/BaseFragmentController",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/me/cards/model/models"
], function(BaseFragmentController, Fragment, JSONModel, models) {
    "use strict";

    return BaseFragmentController.extend("sap.me.support.fragments.CreateSelectCustomerOrSuserBaseDialog", {
        constructor : function(oView) {
            this._oView = typeof (oView.getCard) === "undefined" ? oView._oView : oView.getCard();
            this._oController = oView;
            this._userName = models.getCustomerModel().getData().userName;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this.setDialogType();// customer or suser
            this.iconTabBarModel = new JSONModel({
                selectedKey: ""
            });
        },

        setDialogType: function() {},


        open: function(selectedCustomerNumber) {
            // public model used by suser&customer dialog binding
            // clear the former data first when opening the another one
            // clear former dependents (suser/customer dialog)
            if (this._oView.getDependents().length > 0) {
                this._oView.getDependents().filter((e) => {
                    return e.getTitle() === this._i18n.getText("CreateSelectACustomer") || e.getTitle() === this._i18n.getText("CreateSelectSUser");
                })?.forEach((e) => {
                    this._oView.removeDependent(e);
                });
            }
            this._oDialog = this.loadFragment("CreateCustomerDialog", this._oView.getId(), this._name, this);
            this._oView.setModel(new JSONModel({
                all: [],
                rec: [],
                fav: []
            }), "selectionList");
            this._oView.addDependent(this._oDialog);
            this._setListData(selectedCustomerNumber);
            this.setSelectKey();
            this._oDialog.open();
        },

        onTabBarChange: function(oEvent) {
            const selectedKey = oEvent.getParameters().key;
            this.iconTabBarModel.setProperty("/selectedKey", selectedKey);
        },

        close: function() {
            this._oDialog.close();
        },

        onSearch: function(oEvent) {
            // add filter for search
            this.aFilters = [];
            let sQuery = oEvent.getSource().getValue();
            let iconTabBarContent = this._oDialog.getContent()[1];
            // if search item is empty, then show all result data
            if (sQuery && sQuery.trim().length > 0) {
                this.aFilters = this.getFilters(sQuery);
            }
            iconTabBarContent?.getItems().forEach(items =>
                items.getContent()[0].getBinding("items")?.filter(this.aFilters)
            );
        },

        /**
         * @abstract
         * @param {*} selectedCustomerNumber || null
         */
        getQueryData:function() {
            return undefined;
        },

        _setListData: function(selectedCustomerNumber) {
            const selectionItems = this._oDialog.getContent()[1].getItems();
            selectionItems.forEach(item => item.getContent()[0].setBusy(true));
            const queryData = this.getQueryData(selectedCustomerNumber);

            return $.ajax("/backend/raw/support/CaseF4HelpW7Verticle" + queryData, {
                method: "GET",
                contentType: "application/json"
            }).done((result) => {
                selectionItems.forEach(item => item.getContent()[0].setBusy(false));
                let resultFavorite = result.filter(item => item.Category === "FAVORITE");
                this.markFavoriteInAll(result.filter(item => item.Category === "ALL"), resultFavorite);
                this._oView.getModel("selectionList").setProperty("/rec", result.filter(item => item.Category === "RECENT"));
                this._oView.getModel("selectionList").setProperty("/fav", resultFavorite);
                this.setSelectKey();
                this._oDialog.setModel(this.iconTabBarModel, "$this.iconTabBar");
            }).fail(() => {
                selectionItems.forEach(item => item.getContent()[0].setBusy(false));
                console.log("Request Customer/Suser List item data failed");
            });
        },

        // map favoritelist in alllist
        markFavoriteInAll: function(allList, favoriteList) {
            favoriteList.forEach((item) => {
                allList.forEach(obj => {
                    if (obj.Name.search(item.Name) !== -1) {
                        obj.isFavorite = true;
                        return;
                    }
                });
            });
            this._oView.getModel("selectionList").setProperty("/all", allList);
        },

        setSelectKey : function() {
        },

        onItemPressCustomerValueSelect : function(oEvent) {
            this._oController.onItemPressCustomerValueSelect(oEvent);
        },

        onItemPressSuserValueSelect : function(oEvent) {
            this._oController.onItemPressSuserValueSelect(oEvent);
        },

        cancelCustomerDialogAndSuserDialog: function() {
            this._oDialog.close();
            // if no customer selected before, click customer cancel btn, go to support service page
            !this._oController.previousSelectedCustomer.customerNum && this._oController.navToSupport();
        }
    });
});

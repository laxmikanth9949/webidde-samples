sap.ui.define([
    "../library",
    "sap/ui/base/Object",
    "sap/me/shared/Models",
    "sap/m/MessageToast",
    "sap/me/support/utils/TextEditor",
    "sap/me/support/utils/ContactHelperFactory",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/ui/base/Event",
    "sap/me/support/utils/ContactRoleType",
], function(library, BaseObject, SharedModels, MessageToast, TextEditor, ContactHelperFactory, ResourceModel, Fragment, JSONModel, Event, ContactRoleType,) {

    "use strict";

    return BaseObject.extend("sap.me.support.fragments.PriorityAndImpactBaseController", {

        /**
         * Needs passing current view, pointer, priority, impact text and id of this fragment
         * to constructor while constructing this fragment.
         *
         * @param {sap.ui.vk.View} _oView - Current view.
         * @param {sap.ui.core.Control} _oParentControl - Control that loads this fragment.
         * @param {JSONModel|undefined} _oCurrentDataModel - JSONModel in following format:
         *          {
         *              "pointer": Pointer,
         *              "priority": Priority,
         *              "impactText": Business Impact Text
         *          }
         */

        constructor: function(_oView, _oParentControl, _oCurrentDataModel) {
            this._oView = _oView;
            this._oParentControl = _oParentControl;

            this.constructFragment();

            this.parseData({
                pointer:_oCurrentDataModel.getProperty("/pointer"),
                priority:_oCurrentDataModel.getProperty("/priority"),
                impactText:_oCurrentDataModel.getProperty("/impactText"),
                primaryContactName:undefined,
                primaryContactMobile:undefined,
                primaryContactTelephone:undefined,
                secondaryContactName:undefined,
                secondaryContactMobile:undefined,
                secondaryContactTelephone:undefined,
                contactVisible:false,
                impactTextVisible:false
            });

            this.constructNecessaryData();
            this.constructModels();
        },

        constructFragment : function() {
            // add pointer properties only used for loading draft case, in normal detail case, there is no need of it
            this._oContactHelper = ContactHelperFactory.getContactHelper(this.getContactHelperType(this._oPointer),{sPointer:this._oPointer});
            this._oContacts = this._oContactHelper.getContact();
        },

        parseData : function({
            pointer = "",
            priority = "Medium",
            impactText = "",
            primaryContactName = "",
            primaryContactMobile = "",
            primaryContactTelephone = "",
            secondaryContactName = "",
            secondaryContactMobile = "",
            secondaryContactTelephone = "",
            contactVisible = false,
            impactTextVisible = false,
        }) {
            this._oPointer = pointer;
            this._oPriority = priority;
            this._oImpactText = impactText;
            this.oPreviousPrimaryContactName = primaryContactName;
            this._oPreviousPrimaryContactMobile = primaryContactMobile;
            this._oPreviousPrimaryContactTelephone = primaryContactTelephone;
            this._oPreviousSecondaryContactName = secondaryContactName;
            this._oPreviousSecondaryContactMobile = secondaryContactMobile;
            this._oPreviousSecondaryContactTelephone = secondaryContactTelephone;
            this._oContactVisible = contactVisible;
            this._oImpactTextVisible = impactTextVisible;
        },

        constructNecessaryData : function() {
            this.selectedPriority = this._oPriority;

            this._oImpactRequired = this._oPriority === "Very High" || this._oPriority === "High";
            this._oContactRequired = this._oPriority === "Very High";
            this._oAdditionalQuestionsRequired = this._oPriority === "Very High" && !this._oImpactText;
        },

        constructModels : function() {
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._oView.setModel(new ResourceModel({
                bundle: this._i18n,
                supportedLocales: [""],
                fallbackLocale: ""
            }), "i18nSupport");

            this._oView.setModel(this._oODataModel = SharedModels.getODataModel("support"), "$this.odata");

            this._oView.setModel(this._priorityAndImpactModel = new JSONModel({
                /**
                 * For editing priority and impact,
                 * _oPointer, _oPriority, _oImpactText, oPreviousPrimaryContactName and _oPreviousSecondaryContactName
                 * need to be pre-defined.
                 */
                pointer: this._oPointer,
                priority: this._oPriority,

                impactRequired: this._oImpactRequired,
                contactRequired: this._oContactRequired,
                bizImpactText: this._oImpactText,

                additionalQuestionsRequired: this._oAdditionalQuestionsRequired,
                bizImpactCategorySelectedKey: "None",
                bizImpactCategoryDescTextVisible:false,
                primaryContact: {
                    ContactName: this.oPreviousPrimaryContactName,
                    ContactMobile: this._oPreviousPrimaryContactMobile,
                    ContactTelephone: this._oPreviousPrimaryContactTelephone,
                },
                secondaryContact: {
                    ContactName: this._oPreviousSecondaryContactName,
                    ContactMobile: this._oPreviousSecondaryContactMobile,
                    ContactTelephone: this._oPreviousSecondaryContactTelephone,
                },

                qa: {
                    isFinancialLossQuestionInputText:"",
                    numberOfUserAffectedQuestionInputText:"",
                    sinceWhenProdDownQuestionDatePickerText:"",
                    howLongIssueBeenOccurringQuestionInputText:"",
                    numbersOfConsultantsInvolvedQuestionInputText:"",
                    whenIsTheGoLiveDateDatePickerText:"",
                    /**
                     * these 2 initial results properties should not be set default boolean value - 'false',
                     * because users can choose nothing and this could not be considered as an action of choosing false
                     * and the default status of checkboxes should not be chosen
                     */
                    isWorkAroundQuestionResult: "",
                    isFinancialLossQuestionResult:"",
                },
            }), "priorityAndImpact");

            this._oView.setModel(this._priorityAndImpactControlModel = new JSONModel({
                contactVisible: this._oContactVisible,
                impactTextVisile: this._oImpactTextVisible
            }), "priorityAndImpactControl");
        },

        /**
         * Called as public function.
         */
        createRichTextEditor: function() {
            if (sap.ui.getCore().byId("caseHeaderRichtextEditor")) {
                sap.ui.getCore().byId("caseHeaderRichtextEditor").destroy();
            }

            let impactTextVBox = this._oParentControl.getItems()[0].getItems().find( (arr) => {
                return arr.getId().indexOf("sapMeCaseImpactTextVbox") !== -1;
            });

            let editorBox = impactTextVBox.getItems().find( (arr) => {
                return arr.getId().indexOf("caseHeaderEditRichTextVBox") !== -1;
            });

            if (editorBox) {
                editorBox.addItem(this._oEditor = new TextEditor.createRichTextEditor("caseHeaderRichtextEditor",{
                    editable: true,
                    value: this._oImpactText,
                    readOnly: false,
                    statusbar: false,
                    height: 50,
                    change: this.textEditorChange.bind(this)
                }));
            }
        },


        /** ************************************************************************************** */
        /*                                           Functions                                    */
        /** ************************************************************************************** */

        reConstructFragment: function(_oCurrentDataModel) {
            this._oPointer = _oCurrentDataModel.getProperty("/pointer");
            this.constructFragment();

            this.parseData({
                pointer:_oCurrentDataModel.getProperty("/pointer"),
                priority:_oCurrentDataModel.getProperty("/priority"),
                impactText:_oCurrentDataModel.getProperty("/impactText"),
                primaryContactName:this.getSpecificContact(ContactRoleType.PRIMARY_CONTACT,"contact"),
                primaryContactMobile:this.getSpecificContact(ContactRoleType.PRIMARY_CONTACT,"mobile"),
                primaryContactTelephone:this.getSpecificContact(ContactRoleType.PRIMARY_CONTACT,"telephone"),
                secondaryContactName:this.getSpecificContact( ContactRoleType.SECONDARY_CONTACT,"contact"),
                secondaryContactMobile:this.getSpecificContact( ContactRoleType.SECONDARY_CONTACT,"mobile"),
                secondaryContactTelephone:this.getSpecificContact( ContactRoleType.SECONDARY_CONTACT,"telephone"),
                contactVisible:true,
                impactTextVisible:true
            });

            this.constructNecessaryData();
            this.constructModels();
        },

        getSpecificContact: function(oType,key) {
            let oContact = this._oContacts.filter((arr) => {
                return arr.role === oType && arr[key];
            });
            if (oContact.length > 0) {
                switch (key) {
                    case "contact":
                        return oContact[0][key].split(" (")[0];
                    case "mobile":
                    case "telephone":
                        return oContact[0][key];
                    default:
                        return "";
                }
            }
            return "";
        },

        formatSendingBizImpact: function() {
            let qaArray = [];
            // must follow the question order
            const priorityModelData = this._priorityAndImpactModel.getData();
            if (priorityModelData.priority === "Very High") {
                if (priorityModelData.bizImpactCategorySelectedKey && priorityModelData.bizImpactCategorySelectedKey !== "None") {
                    qaArray.push(this._i18n.getText("editPriority_BizImpactCategory")
                        + this._i18n.getText(`editPriority_BizImpactCategory${this.selectedBizImpactCategory}`));
                }
                if (priorityModelData.qa.isWorkAroundQuestionResult) {
                    qaArray.push(this._i18n.getText("editPriority_workAroundAnswerInBizImpact")
                        + priorityModelData.qa.isWorkAroundQuestionResult);
                }
                if (priorityModelData.qa.isFinancialLossQuestionResult) {
                    // if result is 'Yes', then add the description text, for 'No' just type 'No'
                    let answersScript = this.selectedBizImpactCategory === "Item3"
                        ? this._i18n.getText("editPriority_financialLossAnswerInBizImpact2")
                        : this._i18n.getText("editPriority_financialLossAnswerInBizImpact1");
                    answersScript += priorityModelData.qa.isFinancialLossQuestionResult;
                    if (priorityModelData.qa.isFinancialLossQuestionResult === "Yes") {
                        answersScript += ", " + priorityModelData.qa.isFinancialLossQuestionInputText;
                    }
                    qaArray.push(answersScript);
                }
                if (priorityModelData.qa.numberOfUserAffectedQuestionInputText) {
                    qaArray.push(this._i18n.getText("editPriority_numberOfUserAffectedAnswerInBizImpact")
                        + priorityModelData.qa.numberOfUserAffectedQuestionInputText);
                }
                if (priorityModelData.qa.sinceWhenProdDownQuestionDatePickerText) {
                    qaArray.push(this._i18n.getText("editPriority_sinceWhenProdDownAnswerInBizImpact")
                        + priorityModelData.qa.sinceWhenProdDownQuestionDatePickerText);
                }
                if (priorityModelData.qa.howLongIssueBeenOccurringQuestionInputText) {
                    qaArray.push(this._i18n.getText("editPriority_howLongIssueBeenOccurringAnswerInBizImpact")
                        + priorityModelData.qa.howLongIssueBeenOccurringQuestionInputText);
                }
                if (priorityModelData.qa.numbersOfConsultantsInvolvedQuestionInputText) {
                    qaArray.push(this._i18n.getText("editPriority_numbersOfConsultantsInvolvedAnswerInBizImpact")
                        + priorityModelData.qa.numbersOfConsultantsInvolvedQuestionInputText);
                }
                if (priorityModelData.qa.whenIsTheGoLiveDateDatePickerText) {
                    qaArray.push(this._i18n.getText("editPriority_whenIsTheGoLiveDateAnswerInBizImpact")
                        + priorityModelData.qa.whenIsTheGoLiveDateDatePickerText);
                }
            }

            if (qaArray.length > 0) {
                qaArray[0] = "<i>" + qaArray[0];
                qaArray[qaArray.length - 1] += "</i><br>";
            }

            qaArray.push(priorityModelData.bizImpactText);
            return qaArray.join("<br>");
        },

        prepareUpdateContactData: function(oType) {
            let previousContact,previousContactIndex,currentContact,leadingText,role;
            // figure out the contact data need to be set up
            switch (oType) {
                case "P":
                    leadingText = "/primaryContact";
                    previousContact = this.oPreviousPrimaryContactName;
                    previousContactIndex = this._oContacts.findIndex((arr) => arr.role === ContactRoleType.PRIMARY_CONTACT);
                    currentContact = this._priorityAndImpactModel.getProperty("/primaryContact/ContactName");
                    role = ContactRoleType.PRIMARY_CONTACT;
                    break;
                case "S":
                    leadingText = "/secondaryContact";
                    previousContact = this._oPreviousSecondaryContactName;
                    previousContactIndex = this._oContacts.findIndex((arr) => arr.role === ContactRoleType.SECONDARY_CONTACT);
                    currentContact = this._priorityAndImpactModel.getProperty("/secondaryContact/ContactName");
                    role = ContactRoleType.SECONDARY_CONTACT;
                    break;
            }

            if (previousContact !== currentContact) {
                const data = this._priorityAndImpactModel.getProperty(leadingText);
                let updateEntry = {
                    contact: data["ContactName"],
                    email: data["ContactEmail"],
                    mobile: data["ContactMobile"],
                    telephone: data["ContactTelephone"],
                    userId: data["ContactUserId"],
                    role: role
                };

                if (previousContact) {
                    if (currentContact) {
                        // non-null to non-null => update
                        updateEntry.ID = this._oContactHelper.getContact()[previousContactIndex].ID;
                        this._oContactHelper.updateContact(updateEntry,previousContactIndex);
                    } else {
                        // non-null to null => delete
                        this._oContactHelper.deleteContact(previousContactIndex);
                    }
                } else {
                    // null to non-null => add
                    if (previousContactIndex !== -1) {
                        // for Primary Contact, when given an empty entry without any data, then it need to be update\
                        updateEntry.ID = this._oContactHelper.getContact()[previousContactIndex].ID;
                        this._oContactHelper.updateContact(updateEntry,previousContactIndex);
                    } else {
                        // for other contacts just add the new entry
                        this._oContactHelper.addContact(updateEntry);
                    }
                }
            }
        },

        setContactVisibility : function(isVisible) {
            this._priorityAndImpactControlModel.setProperty("/contactVisible", isVisible);
        },

        setImpactVisibility : function(isVisible) {
            this._priorityAndImpactControlModel.setProperty("/impactTextVisile", isVisible);
        },

        setContactAndImpactVisibility : function(isContactVisible, isImpactVisible) {
            this.setContactVisibility(isContactVisible);
            this.setImpactVisibility(isImpactVisible);
        },


        /** ************************************************************************************** */
        /*                                    Public Functions                                    */
        /** ************************************************************************************** */

        checkMandatoryInput : function() {
            let currentPriority = this.getPriority();
            let currentImpact = this._priorityAndImpactModel.getProperty("/bizImpactText");

            if (currentPriority === "Very High"
                && (!this._priorityAndImpactModel.getProperty("/primaryContact/ContactName") || !currentImpact
                    || (!this._oImpactText && !this._priorityAndImpactModel.getProperty("/bizImpactCategory"))
                    || (!this._oImpactText && this.selectedBizImpactCategory !== "Item4" && !this._priorityAndImpactModel.getProperty("/qa/isWorkAroundQuestionResult")))) {
                return true;
            }

            if (currentPriority === "High" && !currentImpact) {
                return true;
            }

            return false;
        },

        getContactsList : function() {
            return this._oContacts.concat();
        },

        getBizImpactText : function() {
            return this.formatSendingBizImpact();
        },

        getFormattedPriorityLevel : function() {
            switch (this.getPriority()) {
                case "Very High":
                    return "1";
                case "High":
                    return "2";
                case "Medium":
                    return "3";
                default:
                    return "4";
            }
        },

        getPriority : function() {
            return this._priorityAndImpactModel.getProperty("/priority");
        },

        getContacts: function() {
            return this._oContacts;
        },

        prepareSendingContactsData: function() {
            // prepare Primary Contact and Secondary Contact
            this.prepareUpdateContactData("P");
            this.prepareUpdateContactData("S");
            this._oContacts = this._oContactHelper.getContact();
        },

        getContactHelperType : function() {
            return "default";
        },


        /** ************************************************************************************** */
        /*                                         Event Handlers                                 */
        /** ************************************************************************************** */

        /**
         * Needs Overwriting for diferent situations.
         */
        prioritySelectChanged: function(oEvent) {
            this.selectedPriority = oEvent.getParameter("selectedItem").getKey();
            this.prioritySelectChangedFormat();
        },

        textEditorChange: function(oEvent) {
            this._priorityAndImpactModel.setProperty("/bizImpactText",oEvent.getSource().getValue());
        },

        bizImpactCategoryChanged: function(oEvent) {
            // reset all biz impact category question answers
            this.resetBizImpactCategoryAnswers();
            this.selectedBizImpactCategory = oEvent.getParameter("selectedItem").getKey();
            this._priorityAndImpactModel.setProperty("/bizImpactCategory", this.selectedBizImpactCategory);
            // for "None" and "item1", there is no desc text
            if (this.selectedBizImpactCategory !== "Item1" && this.selectedBizImpactCategory !== "None") {
                this._priorityAndImpactModel.setProperty("/bizImpactCategoryDescText",this._i18n.getText("editPriority_BizImpactCategoryText" + this.selectedBizImpactCategory));
                this._priorityAndImpactModel.setProperty("/bizImpactCategoryDescTextVisible",true);
            } else {
                this._priorityAndImpactModel.setProperty("/bizImpactCategoryDescTextVisible",false);
            }
            // for "Item3" the financial loss question would be different
            if (this.selectedBizImpactCategory === "Item3") {
                this._priorityAndImpactModel.setProperty("/financialLossQuestionText",this._i18n.getText("editPriority_financialLossQuestion2"));
            } else {
                this._priorityAndImpactModel.setProperty("/financialLossQuestionText",this._i18n.getText("editPriority_financialLossQuestion1"));
            }
        },

        /**
         *
         * @param oEvent
         * @param type {"Yes"|"No"}
         */
        isWorkAroundCheckChoose: function(oEvent, type) {
            this.setBizImpactCategoryCheckBoxProperty("/qa/isWorkAroundQuestionResult",oEvent.getSource().getSelected(),type);
        },

        /**
         *
         * @param oEvent
         * @param type {"Yes"|"No"}
         */
        isFinancialLossCheckChoose: function(oEvent, type) {
            this.setBizImpactCategoryCheckBoxProperty("/qa/isFinancialLossQuestionResult",oEvent.getSource().getSelected(),type);
        },

        isWorkAroundCheckNoChoose: function(oEvent) {
            this.setBizImpactCategoryCheckBoxProperty("/qa/isWorkAroundQuestionResult",oEvent.getSource().getSelected(),"No");
        },

        isFinancialLossCheckYesChoose: function(oEvent) {
            this.setBizImpactCategoryCheckBoxProperty("/qa/isFinancialLossQuestionResult",oEvent.getSource().getSelected(),"Yes");
        },

        isFinancialLossCheckNoChoose: function(oEvent) {
            this.setBizImpactCategoryCheckBoxProperty("/qa/isFinancialLossQuestionResult",oEvent.getSource().getSelected(),"No");
        },


        /**
         *
         * @param oEvent
         * @param type {"primary"|"secondary"} primary contact or secondary contact
         * @returns {*}
         */
        handleAddContactsValueHelp: function(oEvent, type) {
            // set which type of contact is going to be chosen
            this._oValueHelpContactType = type === "primary" ? "P" : "S";
            if (!this._oContactInputDialog) {
                this._oContactInputDialog = new Fragment({
                    fragmentName:"sap.me.support.fragments.ContactInputDialog",
                    oController: this,
                    type: "XML",
                });
                this._oView.addDependent(this._oContactInputDialog);
            }
            this._oContactInputDialog.open();
        },

        handleContactsValueHelpSearch: function(oEvent) {
            this._oContactHelper.handleContactsValueHelpSearch(oEvent);
        },

        handleContactsValueHelpClose: function(oEvent) {
            let selectedItem = oEvent.getParameter("selectedItem");
            // todo It is better to split as 2 instances to hadnle Primary Contact and Secondary Contact, rather than handle it by _oValueHelpContactType.
            // It need to save in method, rather than save in "this".
            let sValueHelpContactType = this._oValueHelpContactType;
            oEvent.getSource().getBinding("items").filter([]);

            if (selectedItem) {
                return this._oContactHelper.getContactDetailByUserId(selectedItem.getAttributes()[0].getText()).then((data) => {
                    if (data.length === 0) {
                        MessageToast.show(`${this._i18n.getText("ContactsSectionCard_queryFail")}`);
                        return;
                    }
                    // load contact data to model
                    this.setSpecificContactProperties(sValueHelpContactType, data[0]);
                });
            }
            return new Promise((resolve) => resolve());
        },

        /**
         *
         * @param type {'primary' | 'secondary'} primary contact or secondary contact
         */
        onClearContactIconPressed: function(type) {
            let leadingText = type === "primary" ? "/primaryContact/" : "/secondaryContact/";
            this._priorityAndImpactModel.setProperty(leadingText + "ContactName","");
        },


        /** ************************************************************************************** */
        /*                                    Handlers'  Functions                                */
        /** ************************************************************************************** */

        formatBizImpactCategoryTooltip: function() {
            // forbid abnormal character in i18n file, do the format here
            return [this._i18n.getText("editPriority_BizImpactCategoryToolTipP1"),
                this._i18n.getText("editPriority_BizImpactCategoryToolTipP2"),
                this._i18n.getText("editPriority_BizImpactCategoryToolTipP3"),
                this._i18n.getText("editPriority_BizImpactCategoryToolTipP4"),
                this._i18n.getText("editPriority_BizImpactCategoryToolTipP5")].join("\n\r");
        },

        resetBizImpactCategoryAnswers: function() {
            const initialAnswers = {
                isFinancialLossQuestionInputText:"",
                numberOfUserAffectedQuestionInputText:"",
                sinceWhenProdDownQuestionDatePickerText:"",
                howLongIssueBeenOccurringQuestionInputText:"",
                numbersOfConsultantsInvolvedQuestionInputText:"",
                whenIsTheGoLiveDateDatePickerText:"",
                isWorkAroundQuestionResult:"",
                isFinancialLossQuestionResult: ""
            };
            this._priorityAndImpactModel.setProperty("/qa", initialAnswers);
        },

        setBizImpactCategoryCheckBoxProperty: function(oProperty,oAction,oValue) {
            if (oAction) {
                this._priorityAndImpactModel.setProperty(oProperty,oValue);
            } else {
                this._priorityAndImpactModel.setProperty(oProperty,"");
            }
        },

        setSpecificContactProperties: function(oType, contact) {
            if (!contact) {
                return;
            }
            let leadingText = oType === "P" ? "/primaryContact" : "/secondaryContact";
            // "P" Primary(24H) Contact, "S" Secondary Contact
            const data = {
                ContactName: contact["contact"],
                ContactEmail: contact["email"],
                ContactUserId: contact["userId"],
                ContactMobile: contact["mobile"],
                ContactTelephone: contact["telephone"],
            };
            this._priorityAndImpactModel.setProperty(leadingText, data);
        },

        setDefaultQuestionsInEditor: function() {
            this._oEditor.setValue([this._i18n.getText("editPriority_defaultQuestionForVhQ1"),
                this._i18n.getText("editPriority_defaultQuestionForVhQ2"),
                this._i18n.getText("editPriority_defaultQuestionForVhQ3"),
                this._i18n.getText("editPriority_defaultQuestionForVhQ4"),
                this._priorityAndImpactModel.getProperty("/bizImpactText")].join("<br><br>"));
            // manually do the model property input, setValue could not fire the editor text change event
            this._priorityAndImpactModel.setProperty("/bizImpactText",this._oEditor.getValue());
        },

        prioritySelectChangedFormat: function() {
            this._priorityAndImpactModel.setProperty("/priority", this.selectedPriority);
            this._priorityAndImpactModel.setProperty("/contactRequired", this.selectedPriority === "Very High");
            this._priorityAndImpactModel.setProperty("/additionalQuestionsRequired", this.selectedPriority === "Very High" && !this._oImpactText);
            this._priorityAndImpactModel.setProperty("/impactRequired", this.selectedPriority === "Very High" || this.selectedPriority === "High");
            // when change to VH, need biz impact category for the question mark
            if (!this._priorityAndImpactModel.getProperty("/bizImpactCategoryToolTip") && this.selectedPriority === "Very High") {
                this._priorityAndImpactModel.setProperty("/bizImpactCategoryToolTip",this.formatBizImpactCategoryTooltip());
            }
            // if the biz impact is not empty and change to VH, then create some default question in editor
            if (this.selectedPriority === "Very High" && this._oImpactText) {
                this.setDefaultQuestionsInEditor();
            }
        },

        formatNoPhoneWarningVisible: function(priority,contactName,mobile,telephone) {
            let isVHPriority = priority === "Very High";
            let isNameExists = contactName ?? "".trim();
            let isPhoneBlank = !mobile && !telephone;
            return !!isVHPriority && !!isNameExists && isPhoneBlank;
        },

        prioritySelectLimit: function(limitFlag) {
            let oSelect = this._priortySelect = this._oParentControl.getItems()[0].getItems().find( (arr) => {
                return arr.getId().indexOf("ImpactAndPriorityEdit") !== -1;
            });
            switch (limitFlag) {
                case "X":
                    if (this.selectedPriority === "Very High") {
                        oSelect.setSelectedKey("High");
                        this.prioritySelectChanged(new Event("", null, {
                            selectedItem: {
                                getKey: function() {
                                    return "High";
                                }
                            }
                        }), true);
                    }
                    oSelect.getItemByKey("Very High").setEnabled(false);
                    break;
                case "XX":
                    if (this.selectedPriority === "Very High" || this.selectedPriority === "High") {
                        oSelect.setSelectedKey("Medium");
                        this.prioritySelectChanged(new Event("", null, {
                            selectedItem: {
                                getKey: function() {
                                    return "Medium";
                                }
                            }
                        }), true);
                    }
                    oSelect.getItemByKey("Very High").setEnabled(false);
                    oSelect.getItemByKey("High").setEnabled(false);
                    break;
                case "XXX":
                    oSelect.setSelectedKey("Low");
                    oSelect.getItemByKey("Very High").setEnabled(false);
                    oSelect.getItemByKey("High").setEnabled(false);
                    oSelect.getItemByKey("Medium").setEnabled(false);
                    this.prioritySelectChanged(new Event("", null, {
                        selectedItem: {
                            getKey: function() {
                                return "Low";
                            }
                        }
                    }), true);
                    break;
                default:
                    oSelect.getItemByKey("Very High").setEnabled(true);
                    oSelect.getItemByKey("High").setEnabled(true);
                    oSelect.getItemByKey("Medium").setEnabled(true);
                    oSelect.getItemByKey("Low").setEnabled(true);
            }
        },
        _dynamicWidthForNumberOfUserAffected : function(bizImpactCategory) {
            return bizImpactCategory === "Item3" ? "32%" : "49%";
        },
    });
});

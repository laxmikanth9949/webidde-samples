sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/routing/Router",
    "sap/me/shared/util/getShellComponent",
    "sap/me/support/utils/Constants",
    "sap/ui/model/resource/ResourceModel",
    "sap/me/support/fragments/CreateSelectCustomerDialog",
    "sap/me/support/fragments/CreateSelectSUserDialog",
    "sap/ui/dom/includeStylesheet",
    "sap/m/MessageBox",
    "sap/m/FormattedText",
    "sap/me/cards/model/models",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/utils/InfoExchange",
    "sap/me/support/fragments/CreateExistingDraftDialog",
    "sap/me/support/utils/CreationEventType",
], function(
    BaseObject,
    Router,
    getShellComponent,
    Constants,
    ResourceModel,
    CreateSelectCustomerDialog,
    CreateSelectSUserDialog,
    includeStylesheet,
    MessageBox,
    FormattedText,
    models,
    JSONModel,
    InfoExchange,
    CreateExistingDraftDialog,
    CreationEventType,
) {

    "use strict";

    // the header controller does not actually need to be a fully fledged MVC controller! it is enough to be an
    // object that we can instantiate, e.g. inherited from UI5s sap.ui.base.Object prototype.
    return BaseObject.extend("sap.me.support.fragments.CreateReportAnIssueHeaderController", {

        _CONSTANTS: Constants,

        constructor : function(oDashboardController) {
            BaseObject.apply(this);

            // when being constructed (at the time the header is loaded), you will get access to the dashboard controller!
            this._oDashboardController = oDashboardController;
            this._oView = getShellComponent().getRootControl();
            this._oRouter = Router.getRouter("shellRouter");
            this._sUserNumber = models.getCustomerModel().getData().userName;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            getShellComponent().getRootControl().setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "i18nSupport");
            this._sResourceUri = sap.ui.require.toUrl("sap/me/support");
            includeStylesheet(this._sResourceUri + "/css/creatreportAnIssueheader.css", {
                id: "creatreportAnIssueheader"
            });
            this._oView.setModel(this._oView.getModel("i18nSupport"), "$this.i18n");
            if (!this._selectCustomerDialog) {
                this._selectCustomerDialog = new CreateSelectCustomerDialog(this);
            }
            this._selectSuserDialog = new CreateSelectSUserDialog(this);
            /*
             * the static text must come from partner repo, not from frontend.
             * The header is still only a fragment that is loaded into shell so i18 is the model set from frontend
             * 0 means new case
             */

            this._oView.setModel(this._headerCustomerInfoModel = new JSONModel({}), "headerCustomerInfo");
            this._oView.setModel(this._headerSuserInfoModel = new JSONModel({}), "headerSuserInfo");

            this._oEventBus = sap.ui.getCore().getEventBus();
            this.setUpEventBus();
        },

        // watch eventbus can subscribe the pointer
        setUpEventBus: function() {
            this._oEventBus.subscribe("sap.me.support.fragments.CreateReportAnIssueHeaderController", "forbidHeaderChange", () => {
                this.setSelectModel();
                this._headerCustomerInfoModel.setProperty("/isMultipleCustomer",false);
                this._headerCustomerInfoModel.setProperty("/isSupportCustomer",false);
            });
            this._oEventBus.subscribe("sap.me.support.fragments.CreateReportAnIssueHeaderController", "newCaseCreated", () => {
                this.setSelectModel();
            });
            this._oEventBus.subscribe("sap.me.support.fragments.CreateReportAnIssueHeaderController", "openCustomerSelectDialog", () => {
                this.onPressSelectCustomer();
            });
            this._oEventBus.subscribe("sap.me.support.fragments.CreateReportAnIssueHeaderController", "openSuserSelectDialog", () => {
                this.onPressSelectSuser();
            });
            // TODO-refactor: could use new Dialog().open to replace the event bus
            // in case of one key be subscribed more times
            if (!this._oEventBus._mChannels["sap.me.support.fragments.CreateReportAnIssueHeaderController"]?.mEventRegistry?.openDraftList) {
                this._oEventBus.subscribe("sap.me.support.fragments.CreateReportAnIssueHeaderController", "openDraftList", () => {
                    this._selectCustomerDialog.clearStaticModel();
                    this._selectSuserDialog.clearStaticModel();
                    this.setSelectModel();
                    this.openExistingDraftDialog();
                });
            }
        },

        openExistingDraftDialog: function() {
            if (!this._selectExistingDraftDialog) {
                this._selectExistingDraftDialog = new CreateExistingDraftDialog(this);
            }
            this._selectExistingDraftDialog.open();
        },

        setSelectModel : function() {
            const {firstname, lastname} = models.getCustomerModel().getData();

            const customerModel = this._selectCustomerDialog.getCustomerModel();
            const sUserModel = this._selectSuserDialog.getSuserModel();
            if (customerModel) {
                this._headerCustomerInfoModel.setData(customerModel.getData());
                this._headerSuserInfoModel.setData(
                    // if customerModel is empty, set suser model {}
                    // if has customerModel, susermodel empty, set suser model is current login suser, else set suser model is current selected suser
                    sUserModel ? sUserModel.getData()
                        : {
                            suserName: `${firstname} ${lastname}`,
                            suserNumber: this._sUserNumber
                        }
                );
            } else {
                // setData not work in this place, so setModel again
                this._oView.setModel(this._headerCustomerInfoModel = new JSONModel({}), "headerCustomerInfo");
                this._oView.setModel(this._headerSuserInfoModel = new JSONModel({}), "headerSuserInfo");
            }
            this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", CreationEventType.SUPPORTED_USER_CHANGE,{isSupported:this._headerCustomerInfoModel?.getProperty("/isSupportCustomer") ?? false, value:this._headerSuserInfoModel?.getData() ?? {}});
        },

        formatDisplaySUser: function(sName, sSUserNumber) {
            return sSUserNumber?.length ? `${sName} (${sSUserNumber})` : this._i18n.getText("CreateHeaderSuserPlaceholder");
        },

        // open customer dialog
        onPressSelectCustomer: function() {
            this.openDialog("customer");
        },

        openChangingCustomerOrsUserConfirmDialog: function(dialogType) {
            MessageBox.show(new FormattedText({htmlText: dialogType === "customer" ? this._i18n.getText("customer_change_preview_warning_text2") : this._i18n.getText("suser_change_preview_warning_text2")}), {
                title: dialogType === "customer" ? this._i18n.getText("CreateEditCustomer") : this._i18n.getText("CreateEditSUser"),
                actions: [`${this._i18n.getText("yes")}`,MessageBox.Action.CANCEL],
                styleClass:"editCustomerMessageBoxClass",
                emphasizedAction:`${this._i18n.getText("yes")}`,
                onClose: function(sAction) {
                    if (sAction === this._i18n.getText("yes")) {
                        dialogType === "customer" ? this.confirmChangeCustomer(true) : this.confirmChangeSuser();
                    } else if (dialogType === "customer") {
                        this._headerCustomerInfoModel.setData(this.previousSelectedCustomer);
                    } else {
                        this.setAllDataToPrevious();
                    }
                }.bind(this)
            });

        },

        // open s-user dialog
        onPressSelectSuser: function() {
            this.openDialog("suser", false);
        },

        onItemPressCustomerValueSelect : function(oEvent) {
            this._selectCustomerDialog.close();
            this._selectCustomerDialog.onSelectedCustomerItem(oEvent);
            const newCustomerNumber = this._selectCustomerDialog.getCustomerNumber();
            this._headerCustomerInfoModel.setData(this._selectCustomerDialog.getCustomerModel().getData());
            if (this.previousSelectedCustomer.customerNum) {
                if (this.previousSelectedCustomer.customerNum !== newCustomerNumber) {
                    InfoExchange.getCurrentIssueStep("caseCreationInfoExchange") > 1 ? this.openChangingCustomerOrsUserConfirmDialog("customer") : this.confirmChangeCustomer(true);
                } else {
                    // current selected customer same with before
                    this.confirmChangeCustomer(false);
                }
            } else {
                this.confirmChangeCustomer(true);
            }
        },

        /**
         * @param {Boolean} isNotifyCreationCard  if notify creation card clear data
         */
        confirmChangeCustomer: function(isNotifyCreationCard) {
            if (this._selectCustomerDialog.getIsSupportCustomer()) {
                // is support customer
                let text = this._i18n.getText("CreateSUser_message_content");
                MessageBox.warning(new FormattedText({htmlText: text}), {
                    title: this._i18n.getText("CreateSUser_message_title"),
                    actions: [this._i18n.getText("CreateSUser_message_agree"),MessageBox.Action.CANCEL],
                    emphasizedAction: this._i18n.getText("CreateSUser_message_agree"),
                    styleClass: "caseBillingInfoDialog",
                    onClose: (sAction) => {
                        if (sAction === this._i18n.getText("CreateSUser_message_agree")) {
                            this.openDialog("suser", true);
                        } else {
                            this._headerCustomerInfoModel.setData(this.previousSelectedCustomer);
                        }
                    }
                });
            } else {
                const {firstname, lastname} = models.getCustomerModel().getData();
                // when is not support customer change the Customer INFO Model
                this._headerCustomerInfoModel.setData(this._selectCustomerDialog.getCustomerModel().getData());

                this._headerSuserInfoModel.setData({
                    suserName: `${firstname} ${lastname}`,
                    suserNumber: this._sUserNumber
                });

                isNotifyCreationCard && this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", "clearAllData",{isFromHeader:true});

                this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", CreationEventType.SUPPORTED_USER_CHANGE,{isSupported:this._headerCustomerInfoModel.getProperty("/isSupportCustomer"), value:this._headerSuserInfoModel.getData()});
            }
        },

        onItemPressSuserValueSelect : function(oEvent) {
            this._selectSuserDialog.onSelectedSuserItem(oEvent);
            const newSuser = oEvent.getSource().getBindingContext("selectionList").getObject().Name;
            this._headerSuserInfoModel.setData(this._selectSuserDialog.getSuserModel().getData());
            // set suser directly when first time choose suser
            if (!this.previousSelectedSuser.suserNumber) {
                this.setSelectModel();
                this.confirmChangeSuser();
            } else if (this.previousSelectedSuser.suserNumber && this.previousSelectedSuser.suserNumber !== newSuser) {
                InfoExchange.getCurrentIssueStep("caseCreationInfoExchange") > 1 ? this.openChangingCustomerOrsUserConfirmDialog("suser") : this.confirmChangeSuser();
            } else {
                this._selectSuserDialog.close();
            }
            // only triggered by Prefill model, for normal case creation process would not do anything
            this._oEventBus.publish("sap.me.support.utils.PrefillHelper", "selectedSUser");
        },

        confirmChangeSuser: function() {
            // only when customer finish inputting both customer/suser then the model would be changed
            this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", "clearAllData",{isFromHeader:true});
            this._oEventBus.publish("sap.me.support.fragments.CreateReportAnIssueHeaderController", CreationEventType.SUPPORTED_USER_CHANGE,{isSupported:this._headerCustomerInfoModel.getProperty("/isSupportCustomer"), value:this._headerSuserInfoModel.getData()});
            this._selectSuserDialog.close();
        },

        setAllDataToPrevious: function() {
            this._headerCustomerInfoModel.setData(this.previousSelectedCustomer);
            this._headerSuserInfoModel.setData(this.previousSelectedSuser);
        },

        /**
         *
         * @param {*} oType customer or suser dialog
         * @param {*} bIsFromCustomer open suser dialog direct --> false    select customer then open suser --> true
         */
        openDialog : function(oType, bIsFromCustomer) {
            this.previousSelectedSuser = this._headerSuserInfoModel.getData();
            (oType === "customer" || !bIsFromCustomer) && (this.previousSelectedCustomer = this._headerCustomerInfoModel.getData());
            if (oType === "customer") {
                // store the customer and suser seleted before
                if (!this._selectCustomerDialog) {
                    this._selectCustomerDialog = new CreateSelectCustomerDialog(this);
                }
                this._selectCustomerDialog.open();
            }

            if (oType === "suser") {
                this._selectSuserDialog = new CreateSelectSUserDialog(this);
                this._selectSuserDialog.open(this._selectCustomerDialog.getCustomerNumber());
            }
        },

        navToSupport: function() {
            // should nav without router leave lifecycle
            if (this._oRouter) {
                this._oRouter.withoutEvent = true;
            }
            this._oRouter?.navTo("dashboard", {nameOrId: "servicessupport"});
        },

        exitPage: function() {
            InfoExchange.showExitMessageBox("caseCreationInfoExchange");
        },

        handleReportAnIssuePress : function() {
            this._oView.setBusy(true);
            // get customer list
            let sUserNumber = models.getCustomerModel().getData().userName;
            let suserName = models.getCustomerModel().getData().firstname + " " + models.getCustomerModel().getData().lastname;

            // reset model and clear static fields set by other steps
            if (!this._selectCustomerDialog) {
                this._selectCustomerDialog = new CreateSelectCustomerDialog(this);
            }
            this._selectCustomerDialog.clearStaticModel();
            if (!this._selectSuserDialog) {
                this._selectSuserDialog = new CreateSelectSUserDialog(this);
            }
            this._selectSuserDialog.clearStaticModel();

            let queryData = "?$filter=Uname eq '" + sUserNumber + "' and Type eq 'CUSTOMER'";
            $.ajax("/backend/raw/support/CaseF4HelpW7Verticle" + queryData, {
                method: "GET",
                contentType: "application/json"
            }).done((result) => {

                let customerList = result.filter(item => item.Category === "ALL");
                if (customerList.length === 1 && result[0].Desc2 !== "SUPPORTED") {
                    // if only have one customer,then jump to headerView
                    this.selectedCustomerModel = new JSONModel({
                        customerName:  result[0].Value,
                        customerNum: result[0].Name,
                        isMultipleCustomer: false,
                        isSupportCustomer: false,
                        customerType: result[0].Desc2
                    });
                    this.selectedSuserModel = new JSONModel({
                        suserName: `${suserName}`,
                        suserNumber: sUserNumber
                    });
                    this._selectCustomerDialog.setCustomerModel(this.selectedCustomerModel);
                    this._selectSuserDialog.setSuserModel(this.selectedSuserModel);
                    this.confirmChangeCustomer(true);

                } else {
                    this.openDialog("customer");
                }
            }).always(() => {
                this._oView.setBusy(false);
            });
        },
    });
});

sap.ui.define(
    [
        "sap/ui/base/Object",
        "sap/ui/core/Fragment",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/routing/Router",
        "sap/me/shared/util/getShellComponent",
        "sap/me/shared/Models",
        "sap/me/support/utils/Constants",
        "sap/me/support/utils/CaseCreationDialogHelper",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator"
    ],
    function(
        BaseObject,
        Fragment,
        JSONModel,
        Router,
        getShellComponent,
        SharedModels,
        Constants,
        DialogHelper,
        Filter,
        FilterOperator,
    ) {
        return BaseObject.extend("sap.me.support.fragments.CreateProductSelectDialog", {
            constructor: function(that) {
                this.creationCard = that;
                this._oView = that.getCard();
                this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
                // used for close dialog
                this.dialogResolve = () => {};
            },

            showSoftwareProduct: function(oProductType) {
                return oProductType !== "SERVICE";
            },

            onSearch: function(oEvent) {
                this.searchField = oEvent.getSource();
                this.onSelectionChange();
            },

            onSelectionChange: function() {
                this.getFilters();
                this.executeListFilters();
            },

            cancelSelectProductDialog: function() {
                this._oDialog.close();
            },

            // concat all filter
            getFilters: function() {
                // init filter
                this.allTabFilter = [];
                // search filter
                const sQuery = this.searchField?.getValue()?.trim();
                if (sQuery) {
                    const filterProperties = ["DisplayName", "RelationshipType", "SoftwareProduct", "compList"];
                    const aCustomerFilters = filterProperties.map(item => new Filter({path: item, operator: FilterOperator.Contains, value1: sQuery, caseSensitive: false}));
                    this.allTabFilter.push(new Filter({filters: aCustomerFilters, and: false}));
                }

                // select filter
                if (this.productFilterModel.getProperty("/productNames").length) {
                    const productNameFilters = this.productFilterModel.getProperty("/productNames").map(productName => new Filter({
                        path: "DisplayName",
                        operator: FilterOperator.EQ,
                        value1: productName
                    }));
                    this.allTabFilter.push(new Filter({filters: productNameFilters, and: false}));
                }

                if (this.productFilterModel.getProperty("/softWares").length) {
                    const softWareFilters = this.productFilterModel.getProperty("/softWares").map(softWare => new Filter({
                        path: "SoftwareProduct",
                        operator: FilterOperator.EQ,
                        value1: softWare
                    }));
                    this.allTabFilter.push(new Filter({filters: softWareFilters, and: false}));
                }

                if (this.productFilterModel.getProperty("/productTypes").length) {
                    const productTypeFilters = this.productFilterModel.getProperty("/productTypes").map(productType => new Filter({
                        path: "RelationshipType",
                        operator: FilterOperator.EQ,
                        value1: productType
                    }));
                    this.allTabFilter.push(new Filter({filters: productTypeFilters, and: false}));
                }

                if (this.productFilterModel.getProperty("/category") === "Recommended") {
                    this.allTabFilter.push(new Filter({
                        path: "Recommended",
                        operator: FilterOperator.EQ,
                        value1: true
                    }));
                }

                if (this.productFilterModel.getProperty("/category") === "Recently") {
                    this.allTabFilter.push(new Filter({
                        path: "Recently",
                        operator: FilterOperator.EQ,
                        value1: true
                    }));
                }
            },

            initFilter: function() {
                if (this.searchField?.getValue()) {
                    this.searchField.setValue("");
                }
                this.creationCard.setModel(this.productFilterModel = new JSONModel({
                    productNames: [],
                    softWares: [],
                    productTypes: [],
                    category: "All"
                }), "$this.productFilter");
                this.getFilters();
            },

            onPressItem: async function(oEvent) {
                const source = oEvent.getSource();
                const productInfo = source.getBindingContext("productList").getObject();
                const productIndex = source.getParent().getItems().indexOf(source);
                const sPreviousValue = this.creationCard.fragmentControllers.BasicInformationStep.data.product.info;
                const sNewValue = productInfo;
                if (sPreviousValue?.ModelNumber === sNewValue.ModelNumber) {
                    this._oDialog.close();
                    return;
                }
                // should check entitlment, and if product is prevent,should show warning pop up
                const checkResult = this.creationCard.handleEntitlementCheck(sNewValue.CheckResult);
                if(checkResult.prevent) {
                    return;
                }
                const productFunction = this.creationCard.fragmentControllers.BasicInformationStep.data.productFunction.info;
                const component = this.creationCard.fragmentControllers.BasicInformationStep.data.component.info;
                const isShowMsgBox = productFunction || component;
                if (isShowMsgBox) {
                    const msgTitle = this._i18n.getText("case_creation_input_change_warn_dialogue_title_issueInformation");
                    const msgDesc = this._i18n.getText("short_desc_change_preview_warning_text");
                    const sAction = await DialogHelper.showMsgBox(msgTitle, msgDesc);
                    switch (sAction) {
                        case "Confirm":
                            this.afterSelection(productInfo,productIndex);
                            break;

                        case "Cancel":
                            this.creationCard.fragmentControllers.BasicInformationStep.data.product.info = sPreviousValue;
                            break;
                    }
                } else {
                    this.afterSelection(productInfo,productIndex);
                }
            },

            afterSelection: function(sSelectItem, sSelectItemIndex) {
                this.adobeEventTrackForProductSelect(sSelectItem,sSelectItemIndex);
                // this.creationCard._oIssueInformationModel.setProperty("",sSelectItem);
                this.creationCard.fragmentControllers.BasicInformationStep.data.product.info = sSelectItem;
                this.dialogResolve(sSelectItem);
                this._oDialog.close();
            },

            openProductDialog: function(selectedSystem) {
                const waitForDialogClose = new Promise((resolve) => {
                    this.dialogResolve = resolve;
                });
                if (this._oDialog) {
                    this._oDialog.open();
                    // compare choosen system is same or not
                    // if system is same as previous, do nothing; if not, clear searchbox and reset filter
                    if (!this.selectedSystem || this.selectedSystem !== selectedSystem) {
                        this.selectedSystem = selectedSystem;
                        this.initFilter();
                        this.executeListFilters();
                    }
                } else {
                    Fragment.load({
                        name: "sap.me.support.fragments.CreateProductSelectDialog",
                        controller: this,
                    }).then((Dialog) => {
                        this._oDialog = Dialog;
                        this._oView.addDependent(this._oDialog);
                        this._oDialog.open();
                        // filter for all odata by systemnumber
                        if (!selectedSystem) {
                            return;
                        }
                        this.selectedSystem = selectedSystem;
                        this.initFilter();
                    });
                }
                const recommendedModelNumbers = this.creationCard._oProductModel.getProperty("/recommendedModelNumbers");
                this.creationCard.swaServiceEvent.swaValueHelperRecommendations("User (Product)", recommendedModelNumbers);
                return waitForDialogClose;
            },

            clearPreviousSystemInfo: function() {
                this.selectedSystem = "";
            },

            executeListFilters: function() {
                const searchList = this._oDialog.getContent()[1];
                searchList.getBinding("items").filter(this.allTabFilter);
            },

            adobeEventTrackForProductSelect: function(oProduct = {},productIndex) {
                let trackName = "";
                const sugList = this.creationCard._oTrackingData.init_select_data.proudctSuggestList;
                if (this.searchField?.getValue()?.trim()) {
                    trackName = "User(Searched,";
                } else {
                    trackName = "User(";
                }
                if (this.productFilterModel.getProperty("/productNames").length > 0
                    || this.productFilterModel.getProperty("/softWares").length > 0
                    || this.productFilterModel.getProperty("/productTypes").length > 0
                    || this.productFilterModel.getProperty("/category") !== "All") {
                    trackName += "Filtered,";
                }
                if (oProduct.Recommended && oProduct.Recently) {
                    trackName += "Recently Used & Recommended";
                } else if (oProduct.Recently) {
                    trackName += "Recently Used";
                } else if (oProduct.Recommended) {
                    trackName += "Recommended";
                } else {
                    trackName += "List";
                }
                trackName += ")";
                this.creationCard.trackProductChange(trackName,oProduct,productIndex,"");
            }

        });
    }
);

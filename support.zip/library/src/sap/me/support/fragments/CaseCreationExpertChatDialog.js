sap.ui.define([
    "../library",
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/me/support/utils/Constants",
    "sap/ui/model/json/JSONModel"
], function(
    library,
    Object,
    Fragment,
    Constants,
    JSONModel,
) {
    "use strict";

    return Object.extend("sap.me.support.fragments.CaseCreationExpertChatDialog",{

        constructor: function(oCard) {
            this.oChannelData = oCard?.departmentInChannelData;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this.oCard = oCard;
            this._oView = oCard.getCard();
            this.initLangData();
            this._oView.setModel(new JSONModel({selectedKey:"en-us"}), "$this.selectedLanguage");
        },


        redirectToPrivacyAgreementPDF : function() {
            sap.m.URLHelper.redirect(Constants.CASE_CREATION_EXPERT_CHAT_PRIVACY_AGREEMENT, true);
        },

        openPADialog : function() {
            let thisObj = this;
            if (this._oPADialog) {
                this._oPADialog.open();
            } else {
                Fragment.load({
                    name: "sap.me.support.fragments.CaseCreationExpertChatPA",
                    controller: this
                }).then(function(PADialog) {
                    thisObj._oPADialog = PADialog;
                    thisObj._oView.addDependent(thisObj._oPADialog);
                    thisObj._oPADialog.open();
                }.bind(this));
            }
        },

        agreeWithPrivacyAgreement : function() {
            this.closePADialogs();
            this.openTransDialog();
        },

        openTransDialog : function() {
            if (this._oTransDialog) {
                this._oTransDialog.open();
            } else {
                Fragment.load({
                    name: "sap.me.support.fragments.CaseCreationExpertChatTrans",
                    controller: this
                }).then(function(transDialog) {
                    this._oTransDialog = transDialog;
                    this._oView.addDependent(this._oTransDialog);
                    this._oTransDialog.open();

                    if (this.oCard.aLangData) {
                        this._oView.setModel(new JSONModel(this.oCard.aLangData), "$this.aLangData");
                    }
                }.bind(this));
            }
        },

        closePADialogs : function() {
            this._oPADialog.close();
        },


        // load translation languages asynchronously
        initLangData : function() {
            let thisObj = this;
            if (!this.oCard.aLangData) {
                jQuery.ajax("/backend/raw/support/TranslationTextsVerticle", {
                    contentType: "application/json",
                    async: false,
                    success: function(data) {
                        if (data && data.results) {
                            thisObj.oCard.aLangData = data.results;
                        }
                    }
                });
            }
        },

        changeLanguage : function(oEvent) {
            this.oCard.sSelectedKey = oEvent.mParameters?.selectedItem?.mProperties?.key;
            if (this.oCard.sSelectedKey) {
                this._oView.getModel("$this.selectedLanguage").setProperty("/selectedKey", this.oCard.sSelectedKey);
            }
        },

        startChatFromDialog : function() {
            this._oTransDialog.close();
            if (this.oCard._expertChatChannel.getProperty("/isExpertChatAvailable")) {
                clearInterval(this.oCard.timer);
                this.oCard.launchExpertChat();
            }
        },
    });
});

sap.ui.define([
    "sap/m/Button",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/utils/Constants",
    "sap/me/support/cards/caseCreationCards/BaseFragmentController",
    "sap/me/support/arch/util/ResponsiveUtil",
], function(
    Button,
    JSONModel,
    Constants,
    BaseFragmentController,
    ResponsiveUtil,
) {
    /**
     * @class
     * @augments BaseFragmentController
     */
    const Controller = BaseFragmentController.extend("sap.me.support.cards.caseCreationCards.CaseCreationAribaQA", {
        constructor: function(oCaseCreationCard) {
            BaseFragmentController.prototype.constructor.call(this, oCaseCreationCard);
            this.displayData = [];
            this.aribaInfoModel = new JSONModel();
            this.timeLineItem = {
                timeLineIcon: "sap-icon://circle-task",
                title: this.getSupportText("case_creation_time_line_guided_answer"),
                completeRatePercentage: "0",
                completeRateText: "0" + "/0",
                isStepPreviewEditEnabled: true,
                isStepVisible: false,
                isFileTextVisible: false,
                fileText: "",
                control: this.fragmentConfig.name
            };
            ResponsiveUtil.addTimelineResponsiveCapabilities(this);
        }
    });

    Controller.prototype.fragmentConfig = {
        id: "aribaGuidedAnswers",
        boxId: "aribaGuidedAnswersVBox",
        name: "sap.me.support.fragments.CaseCreationAribaQA"
    };

    Controller.prototype.onAfterRendering = function() {
        // this.renderFooter();
    };

    Controller.prototype.getTotalProgress = function() {
        return 0;
    };

    Controller.prototype.getFinishProgress = function() {
        return 0;
    };

    Controller.prototype.isInitAribaQuestions = async function() {
        this.basicInfo = this.oCard._oIssueInformationModel;

        // 2.already finished choosing, show the data
        if (this.displayData.length > 0) {
            return true;
        }

        // 3.no data returns, do not load ariba Q&A
        const data = await this.firstLoadAribaQuestions();
        this.shortDesc = this.oCard.fragmentControllers.BasicInformationStep.data.shortDesc;
        if (data) {
            data.location = 1;
            if (Array.isArray(data.responses) && data.responses.length > 0) {
                for (const response of data.responses) {
                    response.location = 1;
                }
            }
            this.displayData.push(data);
            // the event only triggered when starting the airba Q&A
            this.oCard.swaServiceEvent.aribaGAPresentation(data.flowId, this.shortDesc);
            return true;
        }
        return false;

    };

    Controller.prototype.initAribaPageUI = function() {
        // this.oFragmentView.setVisible(true);
        this.aribaInfoModel.setData({
            node : this.displayData
        });
        // data model for xml and the main card
        this.oCard.setModel(this.aribaInfoModel,"aribaQuestions");
    };

    Controller.prototype.onPressAnswerSelected = function(oEvent) {
        const button = oEvent.getSource();
        const nodeId = button.data("target");
        const location = button.data("location");
        const currentNode = this.displayData[location - 1];
        if (currentNode.responses && currentNode.responses.length) {
            for (const resp of currentNode.responses) {
                resp.active = resp.target === nodeId;
                // first question and answer should be tracking. location id = 1 should be the one
                if (resp.active && location === 1) {
                    const flowId = currentNode.flowId;
                    this.oCard.swaServiceEvent.aribaGAEngaged(flowId, this.shortDesc, resp.target);
                    this.aribaInfoModel.setProperty("/chosenFlowId",flowId);
                }
            }
        }
        this.loadAribaNodeQuestions(nodeId).then(data => {
            if (data) {
                this.refreshQuestionData(location, data);
            }
        });
    };

    Controller.prototype.refreshQuestionData = function(location, newNode) {
        this.displayData = this.displayData.filter(e => {
            return e.location <= location;
        });

        newNode.location = this.displayData.length + 1;
        if (Array.isArray(newNode.responses) && newNode.responses.length > 0) {
            for (const response of newNode.responses) {
                response.location = newNode.location;
            }
        }
        this.displayData.push(newNode);
        this.aribaInfoModel.setData({
            node : this.displayData
        });
    };

    Controller.prototype.onBackButtonPressed = function() {
        this.oFragmentView.setVisible(false);
        this.oCard.setTargetPartVisible(0);
    };

    Controller.prototype.onCaseSolvedPressed = function() {
        this.oFragmentView.setVisible(false);
        this.oCard._navToNextWithoutEvent({
            name: "dashboard",
            arguments: {
                nameOrId: "servicessupport"
            }
        });
        // the event only triggered when pressing the case solved button, only need the first question's id (flowId)
        // could not be aribaInfoModel's flowId, customer can skip over choosing
        this.oCard.swaServiceEvent.aribaGASolved(this.displayData[0].flowId, this.shortDesc);
    };

    Controller.prototype.onContinueButtonPressed = function() {
        this.oFragmentView.setBusy(true);
        // this.isCurrentPageAriba = true;
        // this.oCard.fragmentControllers.BasicInformationStep.onContinueButtonPressed();
        this.oCard.coveoUtil.sendCoveoAnalytics("CreateCase", "Start", this.oCard._oIssueInformationModel.getData(), false);
        this.oCard.channelRecommender();
        this.oCard.setIntervalToChannelRecommender();

        this.oCard._oCurrentProcess = this.oCard._oProcessBarActionStepIndex; // best action
        this.oCard.fragmentControllers.BestActionStep.timeLineItem.isStepPreviewEditEnabled = true;
        this.oCard.refreshProcessBarDisplay(this.oCard._oCurrentProcess);
        this.oCard.setTargetPartVisible(this.oCard._oCurrentProcess);
        this.oCard._oContinueButtonModel.setProperty("/isContinueButtonEnabled", true);
        this.oFragmentView.setBusy(false);
    };

    Controller.prototype.firstLoadAribaQuestions = async function() {
        const payloadData = {
            systemId: this.oCard.fragmentControllers.BasicInformationStep.data.system.info?.systemNumber,
            component : this.oCard.fragmentControllers.BasicInformationStep.data.component.info?.CompName,
            title : this.oCard.fragmentControllers.BasicInformationStep.data.shortDesc,
            customerId : this.oCard.selectedCutAndSuserInfo.customerNum,
            productId: this.oCard.fragmentControllers.BasicInformationStep.data.product.info?.SoftwareProductNumber,
            sessionId : this.oCard._oTrackingData.session_id
        };

        // duplicated request
        if (this.lastRequestPayloadData && Object.keys(this.lastRequestPayloadData).length > 0 && JSON.stringify(this.lastRequestPayloadData) === JSON.stringify(payloadData)) {
            return null;
        }

        try {
            const data = await jQuery.ajax("/backend/raw/support/CaseCreateIntentService", {
                method: "GET",
                data: payloadData
            });
            // result list
            // 1. new JsonObject -> Can not pass the Ariba product check in our BE
            // 2. without 'response' array value -> Is not a Ariba product or error from external Ariba service
            // 3. with 'response' array value -> Is a Ariba product and receive the first Q&A values
            this.lastRequestPayloadData = payloadData;
            return (Object.keys(data).length == 0 || !data.responses) ? null : data;
        } catch {
            return null;
        }
    };

    Controller.prototype.loadAribaNodeQuestions = async function(nodeId) {
        try {
            const data = await jQuery.ajax("/backend/raw/support/CaseCreateAribaGuidedAnswer", {
                method: "GET",
                data: {
                    nodeId: nodeId
                }
            });
            return (Object.keys(data).length == 0 || !data.responses) ? null : data;
        } catch {
            return null;
        }
    };

    Controller.prototype.formatText = function(sValue, sClass) {
        const sLt = "<span class=\"" + sClass + "\">";
        const sGt = "</span>";
        return sLt + sValue + sGt;
    };

    Controller.prototype.clearAribaQAData = function() {
        this.displayData = [];
        this.aribaInfoModel.setData({
            node : this.displayData
        });

        this.timeLineItem.timeLineIcon = "sap-icon://circle-task";
        this.timeLineItem.completeRatePercentage = "0";
        this.timeLineItem.completeRateText = "0/0";
        this.timeLineItem.isStepPreviewEditEnabled = true;
        this.timeLineItem.isStepVisible = false;
        this.timeLineItem.isFileTextVisible = false;
        this.timeLineItem.fileText = "";

    };

    Controller.prototype.getAribaAddOnText = function() {
        // at least, the customer should select one button label
        if (this.displayData.length < 2) {
            return "";
        }
        let aribaText = Constants.CASE_CREATION_LONG_TEXT_BLOCK.GA + Constants.CASE_CREATION_ARIBAGUIDEDANSWER_BLOCK.PATH;
        let chosenAnswer;
        this.displayData.forEach(node => {
            // main question and button selection text
            if (node.location === 1) {
                aribaText += "GA Answer Name: " + node.title + "& GA ID: " + node.flowId + "<br />";
                aribaText += Constants.CASE_CREATION_ARIBAGUIDEDANSWER_BLOCK.LEAF;
            }
            // node question and button selection text
            if (node.responses.length > 0) {
                chosenAnswer = node.responses.find(button => button.active === true);
                if (chosenAnswer) {
                    aribaText += "Q: " + new DOMParser().parseFromString(node.displayText, "text/html").documentElement.textContent + "<br />";
                    aribaText += "A: " + chosenAnswer.label + "<br />";
                }
            }
        });
        return aribaText;
    };

    Controller.prototype.clearData = function() {
        this.clearAribaQAData();
    };

    return Controller;
});

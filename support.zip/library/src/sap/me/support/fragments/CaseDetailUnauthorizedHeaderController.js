sap.ui.define([
    "../library",
    "sap/ui/base/Object",
    "sap/ui/core/routing/Router",
    "sap/me/shared/util/getShellComponent",
    "sap/me/shared/Models",
    "sap/me/support/utils/Constants",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/dom/includeStylesheet"
], function(library, BaseObject, Router, getShellComponent, SharedModels, Constants, ResourceModel, includeStylesheet) {
    "use strict";

    // the header controller does not actually need to be a fully fledged MVC controller! it is enough to be an
    // object that we can instantiate, e.g. inherited from UI5s sap.ui.base.Object prototype.
    return BaseObject.extend("sap.me.support.fragments.CaseDetailUnauthorizedHeaderController", {

        _CONSTANTS: Constants,

        _oUserModel: SharedModels.getUserModel(),

        constructor : function(oDashboardController) {
            BaseObject.apply(this);

            // when being constructed (at the time the header is loaded), you will get access to the dashboard controller!
            this._oDashboardController = oDashboardController;


            this._oView = getShellComponent().getRootControl();
            this._oRouter = Router.getRouter("shellRouter");
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");

            /*
             * the static text must come from partner repo, not from frontend.
             * The header is still only a fragment that is loaded into shell so i18 is the model set from frontend
             */
            getShellComponent().getRootControl().setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "i18nSupport");

            this._sResourceUri = sap.ui.require.toUrl("sap/me/support");
            includeStylesheet(this._sResourceUri + "/css/casedetailunauthorizedheader.css", {
                id: "casedetailunauthorizedheader"
            });
        }

    });
});
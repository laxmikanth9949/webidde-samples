sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/me/shared/util/getShellComponent",
    "sap/ui/model/resource/ResourceModel",
    "sap/me/support/utils/QualtricsService"
], function(Object, Fragment, JSONModel, getShellComponent, ResourceModel, QualtricsService) {
    "use strict";
    const tencentStore = "tencent";
    const googlePlay = "googlePlay";

    return Object.extend("sap.me.support.fragments.AppQRCodeDialog", {
        constructor: function(pointer) {
            this._oView = getShellComponent()?.getRootControl?.();
            this._pointer = pointer;
            this.initDialog();
        },

        initDialog: function() {
            const isCN = navigator.language === "zh-CN";
            this._sResourceUri = sap.ui.require.toUrl("sap/me/support");
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._oView.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
            this._oView.setModel(this.appQRCodeDialogModel = new JSONModel({
                selectedKey: isCN ? "android" : "ios",
                androidSource: isCN ? tencentStore : googlePlay,
                androidStore: "android",
                appleStore: "ios",
                qrCodeImageSrc: `${this._sResourceUri}/themes/img/${isCN ? "tencent_forme" : "apple_forme"}.png`,
            }), "$this.appQRCodeDialog");
        },

        open: function() {
            this._oDialog ? this._oDialog.open() : Fragment.load({
                name: "sap.me.support.fragments.AppQRCodeDialog",
                controller: this,
            }).then((Dialog) => {
                this._oDialog = Dialog;
                this._oView.addDependent(this._oDialog);
                this._oDialog.open();
                this._oDialog.attachEvent("afterClose", () => {
                    this.openQualtricsIntercept();
                });
            });
        },

        openQualtricsIntercept: function() {
            const surveyUrl = "https://zncwifqo8baxlukrv-sapinsights.siteintercept.qualtrics.com/SIE/?Q_ZID=ZN_3RhlAhK4QHYAyJD";
            QualtricsService.initQualtricsSurvey(surveyUrl, this).then(() => {
                if (this.hasInterceptLoaded) {
                    window.QSI.API.unload();
                    // QSI.isDebug = true;
                    window.QSI.API.load().done(window.QSI.API.run());
                }
            });
        },

        closeDialog: function() {
            this._oDialog.close();
        },

        formatQRCodeMessage: function() {
            const caseID = +this._pointer.slice(10, 20) + "/" + this._pointer.slice(-4);
            return this._i18n.getText("case_detail_qrcode_dialog_message1", caseID);
        },

        selectionChange: function(oEvent) {
            const key = oEvent.getSource().getSelectedKey();
            this.appQRCodeDialogModel.setProperty("/selectedKey", key);
            this.appQRCodeDialogModel.setProperty("/qrCodeImageSrc", this.getQRCodeImage());
        },

        getQRCodeImage: function() {
            const key = this.appQRCodeDialogModel.getProperty("/selectedKey");
            if (key === this.appQRCodeDialogModel.getProperty("/appleStore")) {
                return `${this._sResourceUri}/themes/img/apple_forme.png`;
            }
            const androidSource = this.appQRCodeDialogModel.getProperty("/androidSource");

            return `${this._sResourceUri}/themes/img/${androidSource === tencentStore ? "tencent_forme" : "google_forme"}.png`;
        },

        changeAndroidSource: function() {
            const androidSource = this.appQRCodeDialogModel.getProperty("/androidSource");
            this.appQRCodeDialogModel.setProperty("/androidSource", androidSource === tencentStore ? googlePlay : tencentStore);
            this.appQRCodeDialogModel.setProperty("/qrCodeImageSrc", this.getQRCodeImage());
        }
    });
});

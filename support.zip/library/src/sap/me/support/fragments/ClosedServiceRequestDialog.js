sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/core/routing/Router",
    "sap/me/support/utils/helper"
],function(Object, Fragment, JSONModel, MessageToast, Router, helper) {
    "use strict";
    return Object.extend("sap.me.support.fragments.ClosedServiceRequestDialog", {
        constructor: function(srCard) {
            this._oView = srCard.getCard();
            this._sId = srCard.getId();
            this._srCard = srCard;
            this.selectModel = 0;
        },

        open: function() {
            return this._oDialog ? this._oDialog.open() : Fragment.load({
                id: this._sId + "-sClosedServiceRequestDialog",
                name: "sap.me.support.fragments.ClosedServiceRequestDialog",
                controller: this
            }).then(function(Dialog) {
                this._oDialog = Dialog;
                this._oView.addDependent(this._oDialog);
                this._oDialog.open();
            }.bind(this));
        },

        close: function() {
            this._oDialog.close();
        },

        onRadioSelected: function(oEvent) {
            this.selectModel = oEvent.getSource().getSelectedIndex();
        },
        // index 0-> Enterprise Cloud Services (ECS)
        // index 1-> Human Capital Management
        // index 2-> Partner & Other Cloud Services
        // index 3-> CRM and Customer Experience
        onConfirm: function() {
            const index = this.selectModel;
            const type = this._srCard._oContextModel.getProperty("/createServiceRequestCase");
            if (index === 0) {
                // when Service Request = Not Released and ServiceNow = Released then open ServiceNow -> 1
                // when Service Request = Released or Pilot and ServiceNow = Not Released then open SR-App -> 2
                // when Service Request = Released or Pilot and ServiceNow = Released then open ServiceNow -> 3
                // when Service Request = Not Released and ServiceNow = Not Released then show Message: Access to Service Request is not released, yet.-> 4
                switch (type) {
                    case "2":
                        this.onNavToLaunchpadServiceRequest();
                        break;
                    case "4":
                        MessageToast.show(`${this._srCard._i18n.getText("serviceRequestNotReleased")}`);
                        break;
                    default:
                        this.onSnoServiceRequest();
                        break;
                }
            } else if (index === 2) {
                this.onNavToLaunchpadServiceRequest();
            } else {
                this.onSPMandCXSnoServiceRequest();
            }
            this.close();
        },
        // ECS
        onSnoServiceRequest: function() {
            if (helper.isDev || helper.isLocal) {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_FOR_DEV, true);
            } else if (helper.isTest) {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_FOR_TEST, true);
            } else {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_FOR_PROD, true);
            }
        },

        // SPM AND CX
        onSPMandCXSnoServiceRequest: function() {
            if (helper.isDev || helper.isLocal) {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_SPMANDCX_FOR_DEV, true);
            } else if (helper.isTest) {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_SPMANDCX_FOR_TEST, true);
            } else {
                sap.m.URLHelper.redirect(this._srCard._CONSTANTS.HEC_ADVANCED_CREATE_SERVICE_REQUEST_SPMANDCX_FOR_PROD, true);
            }
        },

        onNavToLaunchpadServiceRequest: function() {
            if (helper.isDev || helper.isLocal || helper.isTest) {
                sap.m.URLHelper.redirect("https://test.me.sap.com/app/serOverview",true);
            } else {
                sap.m.URLHelper.redirect("https://me.sap.com/app/serOverview",true);
            }
        }

    });
});

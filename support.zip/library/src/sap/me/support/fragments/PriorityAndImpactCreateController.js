sap.ui.define([
    "../library",
    "sap/ui/base/Object",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel",
    "sap/me/support/fragments/PriorityAndImpactBaseController",
    "sap/me/support/utils/ContactRoleType",
], function(library, BaseObject, MessageToast, JSONModel, PriorityAndImpactBaseController, ContactRoleType,) {

    "use strict";

    return PriorityAndImpactBaseController.extend("sap.me.support.fragments.PriorityAndImpactCreateController", {

        /**
         * @description Needs passing current view, pointer, priority, impact text and id of this fragment
         *              to constructor while constructing this fragment.
         *
         * @param {sap.ui.vk.View} _oView - Current view.
         * @param {Controller Object} _oParentController - Controller that loads this fragment.
         * @param {sap.ui.core.Control} _oParentControl - Control that loads this fragment.
         * @param {JSONModel|undefined} _oCurrentDataModel - JSONModel in following format:
         *          {
         *              "pointer": Pointer,
         *              "priority": Priority,
         *              "impactText": Business Impact Text
         *          }
         */

        constructor: function(_oView, _oParentController, _oParentControl, _oCurrentDataModel) {
            this._oView = _oView;
            this._oParentController = _oParentController;
            this._oParentControl = _oParentControl;
            this._oCurrentDataModel = _oCurrentDataModel;

            this.constructPriority();
        },

        constructPriority: function() {
            this.reConstructFragment(this._oCurrentDataModel);
            this._oContactVisible = false;
            this._oImpactTextVisible = false;
            this._priorityAndImpactControlModel.setProperty("/contactVisible", this._oContactVisible);
            this._priorityAndImpactControlModel.setProperty("/impactTextVisile", this._oImpactTextVisible);
        },


        /** ************************************************************************************** */
        /*                                         Event Handlers                                 */
        /** ************************************************************************************** */

        prioritySelectChanged: function(oEvent, isCauseBySystem) {
            this.selectedPriority = oEvent.getParameter("selectedItem").getKey();
            this._oParentController.setIssueContinueButtonEnabled();
            this._oParentController.fragmentControllers.BasicInformationStep.updateTimelineProgress();
            this.formatPriorityAndImpactFragment();
            let sPriorityLevel = this.getFormattedPriorityLevel();
            this._oParentController.fragmentControllers.BasicInformationStep.data.priority.value = sPriorityLevel;
            this._oParentController.setContactProcessBar();
            this._oParentController.swaServiceEvent.swaPriorityChanged(this.selectedPriority, isCauseBySystem ? "System" : "User");
        },

        onReminderViewDetailButtonPressed: function() {
            this.priorityReminderViewDetailButton = this.priorityReminderVBox.getItems().find( (arr) => {
                return arr.getId().indexOf("priorityImpactReminderViewDetailButton") !== -1;
            });

            this.priorityReminderViewDetailButton.setVisible(false);
            this.prioritySaveVBox.setVisible(true);

            this.constructFragment();
            this.oPreviousPrimaryContactName = this.getSpecificContact(ContactRoleType.PRIMARY_CONTACT,"contact");
            this._oPreviousPrimaryContactMobile = this.getSpecificContact(ContactRoleType.PRIMARY_CONTACT,"mobile");
            this._oPreviousPrimaryContactTelephone = this.getSpecificContact(ContactRoleType.PRIMARY_CONTACT,"telephone");
            this._oPreviousSecondaryContactName = this.getSpecificContact( ContactRoleType.SECONDARY_CONTACT,"contact");
            this._oPreviousSecondaryContactMobile = this.getSpecificContact( ContactRoleType.SECONDARY_CONTACT,"mobile");
            this._oPreviousSecondaryContactTelephone = this.getSpecificContact( ContactRoleType.SECONDARY_CONTACT,"telephone");
            this.setSpecificContactProperties("P",this._oContacts.filter(oContact => oContact.role === ContactRoleType.PRIMARY_CONTACT)[0]);
            this.setSpecificContactProperties("S",this._oContacts.filter(oContact => oContact.role === ContactRoleType.SECONDARY_CONTACT)[0]);

            this.setContactAndImpactVisibility(true, true);
            this.createRichTextEditor();
            this.prioritySelectChangedFormat();

            this.setPreviousTextInEditor();

            this._oParentController._oContinueButtonModel.setProperty("/isContinueButtonEnabled", false);
            this.currentAvailableSteps = [];
            for (let i = 1; i < this._oParentController.totalProcessBarStepsCount; i++) {
                if (this._oParentController.timeLineLayoutControl.data.timeLineItems[i].isStepPreviewEditEnabled) {
                    this.currentAvailableSteps.push(i);
                    this._oParentController.timeLineLayoutControl.data.timeLineItems[i].isStepPreviewEditEnabled = false;
                }
            }
        },

        onSaveViewDetailButtonPressed: function() {
            if (this.checkMandatoryInput()) {
                return MessageToast.show(`${this._i18n.getText("editPriority_inputValueCheckInfo")}`);
            }

            this.prepareSendingContactsData();

            // Save information
            this._oParentController._oIssueInformationModel.setProperty("/impactText", this.getBizImpactText());
            this._oParentController._oIssueInformationModel.setProperty("/contacts", this.getContacts());

            this.formatPriorityAndImpactFragment();
            this._oParentController.setIssueContinueButtonEnabled();
            this._oParentController.fragmentControllers.BasicInformationStep.updateTimelineProgress();
            this.currentAvailableSteps.forEach(function(i) {
                this._oParentController.timeLineLayoutControl.data.timeLineItems[i].isStepPreviewEditEnabled = true;
            }.bind(this));
        },

        textEditorChange: function(oEvent) {
            let currentValue = oEvent.getSource().getValue();
            this._priorityAndImpactModel.setProperty("/bizImpactText", currentValue);
            this._oParentController._oIssueInformationModel.setProperty("/impactText", this.getBizImpactText());
            this.setPreviousTextInEditor();
            if (this.selectedPriority === "High") {
                this._oParentController.setIssueContinueButtonEnabled();
                this._oParentController.fragmentControllers.BasicInformationStep.updateTimelineProgress();
            }
        },

        handleContactsValueHelpClose: function(oEvent) {
            return PriorityAndImpactBaseController.prototype.handleContactsValueHelpClose.call(this, oEvent).then(() => {
                if (this._oValueHelpContactType === "P") {
                    this._oParentController.setContactProcessBar();
                }
            });
        },

        onClearContactIconPressed: function(type) {
            PriorityAndImpactBaseController.prototype.onClearContactIconPressed.call(this, type);
            this._oParentController.setContactProcessBar();
        },


        /** ************************************************************************************** */
        /*                                    Handlers'  Functions                                */
        /** ************************************************************************************** */

        formatPriorityAndImpactFragment : function() {
            this.priorityReminderVBox = this._oParentControl.getItems()[0].getItems().find( (arr) => {
                return arr.getId().indexOf("priorityImpactReminderVBox") !== -1;
            });
            this.prioritySaveVBox = this._oParentControl.getItems()[0].getItems().find( (arr) => {
                return arr.getId().indexOf("priorityImpactSaveVBox") !== -1;
            });

            /**
             * Set contact & business impact & additional question area invisible.
             */
            this.setContactAndImpactVisibility(false, false);
            this._priorityAndImpactModel.setProperty("/additionalQuestionsRequired", false);
            this._priorityAndImpactModel.setProperty("/priority", this.selectedPriority);
            this._priorityAndImpactModel.setProperty("/contactRequired", false);
            this._priorityAndImpactModel.setProperty("/impactRequired", false);
            this.prioritySaveVBox.setVisible(false);
            this.priorityReminderVBox.setVisible(false);
            if (this.priorityReminderViewDetailButton) {
                this.priorityReminderViewDetailButton.setVisible(false);
            }

            switch (this.selectedPriority) {
                case "Very High":
                    this.priorityReminderVBox.setVisible(true);
                    if (this.priorityReminderViewDetailButton) {
                        this.priorityReminderViewDetailButton.setVisible(true);
                    }
                    if (!this._priorityAndImpactModel.getProperty("/primaryContact/ContactName")
                        || this._priorityAndImpactModel.getProperty("/bizImpactCategorySelectedKey") === "None"
                        || (!this._priorityAndImpactModel.getProperty("/qa/isWorkAroundQuestionResult") && this._priorityAndImpactModel.getProperty("/bizImpactCategory") !== "Item4")
                        || !this._priorityAndImpactModel.getProperty("/bizImpactText")) {
                        this.onReminderViewDetailButtonPressed();
                    }
                    break;
                case "High":
                    this.setContactAndImpactVisibility(false, true);
                    this.createRichTextEditor();
                    this.prioritySelectChangedFormat();

                    this.setPreviousTextInEditor();
                    break;
                default:
                    break;
            }

        },

        setPreviousTextInEditor : function() {
            let savedImpactText = this._priorityAndImpactModel.getProperty("/bizImpactText");
            if (savedImpactText) {
                this._oEditor.setValue(savedImpactText);
            }
        },

        // when loading a draft case, it is allowed to filled the additional biz impact questions again
        prioritySelectChangedFormat: function() {
            this._priorityAndImpactModel.setProperty("/priority", this.selectedPriority);
            this._priorityAndImpactModel.setProperty("/contactRequired", this.selectedPriority === "Very High");
            this._priorityAndImpactModel.setProperty("/additionalQuestionsRequired", this.selectedPriority === "Very High");
            this._priorityAndImpactModel.setProperty("/impactRequired", this.selectedPriority === "Very High" || this.selectedPriority === "High");
            // when change to VH, need biz impact category for the question mark
            if (!this._priorityAndImpactModel.getProperty("/bizImpactCategoryToolTip") && this.selectedPriority === "Very High") {
                this._priorityAndImpactModel.setProperty("/bizImpactCategoryToolTip",this.formatBizImpactCategoryTooltip());
            }
        },

        checkMandatoryInput : function() {
            let currentPriority = this._priorityAndImpactModel.getProperty("/priority");
            let currentImpact = this._priorityAndImpactModel.getProperty("/bizImpactText");

            if (currentPriority === "Very High") {
                if (this.prioritySaveVBox) {
                    // why redefine this method:
                    // change point: this._oImpactText (the already existed one from the backend, eg: draft case/ case detail display) => currentImpact (the user input bizImpact)
                    // in creation model, this._oImpactText always be empty; in draft model, it may be filled
                    // so the previous one could not be the condition for judgement, the current one should be taken into consideration
                    if (!this._priorityAndImpactModel.getProperty("/primaryContact/ContactName") || !currentImpact
                        || !this._priorityAndImpactModel.getProperty("/bizImpactCategory")
                        || (!this._priorityAndImpactModel.getProperty("/qa/isWorkAroundQuestionResult") && this._priorityAndImpactModel.getProperty("/bizImpactCategory") !== "Item4")) {
                        return true;
                    }
                } else {
                    // when loading draft case for the first time, there would not be a save button
                    // this only be triggered when draft case priority has not been changed again to Very High Mode
                    if (!this._priorityAndImpactModel.getProperty("/primaryContact/ContactName") || !currentImpact) {
                        return true;
                    }
                }
            }

            if (currentPriority === "High" && !currentImpact) {
                return true;
            }

            return false;
        },

        /** ************************************************************************************** */
        /*                                    implement  Functions                                */
        /** ************************************************************************************** */
        getContactHelperType : function(oPointer) {
            return oPointer ? "DRAFT_LOADING_CONTACT_" + oPointer : "CREATION_CONTACT";
        },
    });
});

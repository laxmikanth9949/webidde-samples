sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/me/cards/model/models",
    "sap/m/FormattedText",
    "sap/ui/core/routing/Router",
    "../utils/helper",
    "../utils/Constants",
    "sap/me/support/model/formatter",
    "sap/m/MessageToast"
], function(BaseObject, Fragment, JSONModel, models, FormattedText, Router, helper, Constants, formatter, MessageToast) {
    "use strict";
    return BaseObject.extend("sap.me.support.fragments.ProductKnowledgeCriticalDialog", {

        formatter: formatter,

        constructor: function(oView) {
            this.creationCard = oView;
            this._oView = oView.getCard();
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        },

        openCriticalPop: function() {
            this._oDialog ? (() => {
                this._oDialog.open();
            })() : Fragment.load({
                name: "sap.me.support.fragments.ProductKnowledgeCriticalDialog",
                controller: this
            }).then((Dialog) => {
                this._oDialog = Dialog;
                this._oView.addDependent(this._oDialog);
                this._oDialog.open();
            });

            const criticalList = this.creationCard._oHotAndTrendingModel.getProperty("/criticalList");
            this.creationCard.swaServiceEvent.criticalKBADialogOpen({
                productFunction: this.creationCard.fragmentControllers.BasicInformationStep.data.productFunction.info,
                KBAnumber: criticalList.map(v => v.KMNumber).join(";")
            });
        },

        closeCriticalPop: function() {
            this._oDialog.close();
            const criticalList = this.creationCard._oHotAndTrendingModel.getProperty("/criticalList");
            this.creationCard.swaServiceEvent.criticalKBADialogOK({
                productFunction: this.creationCard.fragmentControllers.BasicInformationStep.data.productFunction.info,
                KBAnumber: criticalList.map(v => v.KMNumber).join(";")
            });
        },

        onPressKBALink: function(oEvent) {
            const criticalKnowledge = oEvent.getSource().getBindingContext("hotAndTrendingList").getObject();
            this.creationCard.swaServiceEvent.criticalKBADialogClick({
                productFunction: this.creationCard.fragmentControllers.BasicInformationStep.data.productFunction.info,
                KBAnumber: criticalKnowledge.KMNumber
            });
        },

        formatDisplayText: function(system, productFunction) {
            return this._i18n.getText("case_creation_product_knowledge_critical_msg", [productFunction, system]);
        },

        _handleTitle: function(Title, KMNumber) {
            return KMNumber + " - " + Title;
        },

        _subscribeKbaNote: function(KMNumber, action, button) {
            return jQuery.ajax(`/backend/raw/sapnotes/NoteActions?number=${KMNumber}&action=${action}`, {
                method: "GET",
                contentType: "application/json",
                dataType: "json",
                complete: () => {
                    button.setBusy(false);
                }
            });
        },

        _handleRequestSuccess: function(data, action, button) {
            if (!data?._actionPerformed) {
                return;
            }
            switch (action) {
                case "markAsFavorite":
                    button.setText(this._i18n.getText("case_creation_product_knowledge_critical_unsubscribe"));
                    break;
                case "unmarkAsFavorite":
                    button.setText(this._i18n.getText("case_creation_product_knowledge_critical_subscribe"));
                    break;
            }
        },

        _handleRequestError: function(error, action) {
            switch (action) {
                case "markAsFavorite":
                    MessageToast.show(this._i18n.getText("case_creation_product_knowledge_critical_subscribe_error"));
                    break;
                case "unmarkAsFavorite":
                    MessageToast.show(this._i18n.getText("case_creation_product_knowledge_critical_unsubscribe_error"));
                    break;
            }
        },

        onSubscribeClick: function(oEvent) {
            const button = oEvent.getSource();
            button.setBusy(true);
            const criticalKnowledge = oEvent.getSource().getBindingContext("hotAndTrendingList").getObject();
            let action = "markAsFavorite";
            if (button.getText() === this._i18n.getText("case_creation_product_knowledge_critical_unsubscribe")) {
                action = "unmarkAsFavorite";
            } else {
                this.creationCard.swaServiceEvent.criticalKBADialogSubscribe({
                    productFunction: this.creationCard.fragmentControllers.BasicInformationStep.data.productFunction.info,
                    KBAnumber: criticalKnowledge?.KMNumber
                });
            }
            this._subscribeKbaNote(criticalKnowledge?.KMNumber, action, button).then(data => {
                this._handleRequestSuccess(data, action, button);
            }).catch(error => {
                this._handleRequestError(error, action);
            });
        }


    });
});

sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/resource/ResourceModel",
    "sap/me/support/model/formatter"
], function(Object, Fragment, Filter, FilterOperator, ResourceModel, formatter) {
    "use strict";

    return Object.extend("sap.me.support.fragments.AnalyzeFilesDialog",{
        formatter : formatter,
        constructor: function(oController, attachmentInstance) {
            // judge parent component is card or dialog
            this._oController = oController;
            this.attachmentService = attachmentInstance;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
        },

        initDialogOpen: function() {
            this._oDialog.open();
            this.setInitialModels();
        },

        setInitialModels: function() {
            this._oDialog.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}),"$this.i18n");
            this._oDialog.setModel(this._fileAnalyzeAlertsDataModel = this._oController._fileAnalyzeAlertsDataModel,"$this.fileAnalyzeAlerts");
        },

        open: function() {
            return this._oDialog ? this.initDialogOpen() : Fragment.load({
                name: "sap.me.support.fragments.AnalyzeFilesDialog",
                controller: this,
            }).then(function(Dialog) {
                this._oDialog = Dialog;
                this.initDialogOpen();
            }.bind(this));
        },

        close: function() {
            this._oDialog.close();
            // only in case detail attachment card has _cancelCurrent property (only case detail has the cancel analyze function)
            if (this._oController.analyzeFilesDialog._cancelCurrent === false) {
                this._oController.analyzeFilesDialog._cancelCurrent = true;
            }
        },

        formatFileAnalysisMessageText: function(oMessage) {
            return oMessage?.length >= 180 ? oMessage.substring(0, 180) + "..." : oMessage;
        },

        formatTotalAppender: function(sText, sTotal) {
            return sText + "(" + sTotal + ")";
        },

        formatTextAppender: function(sText1, sText2) {
            if (sText2 === "Other") {
                sText2 = this._i18n.getText("case_form_sla_analysing_files_link");
            }
            return sText1 + sText2;
        },

        /**
		 * Filter alert list based off prioirity
		 */
        filterAlertList: function(oEvent) {
            const iPriority = oEvent.getSource().getKey();
            const aFilter = [];
            if (iPriority && iPriority > 0) {
                aFilter.push(new Filter("priority", FilterOperator.EQ, iPriority));
            }
            this._oDialog.getContent()[0].getContent()[1]?.getBinding("items").filter(aFilter);
            return aFilter;
        },

        showAnalysisDetail: function(oEvent) {
            const sPath = oEvent.getSource().getBindingContext("$this.fileAnalyzeAlerts").sPath;
            const oPageContext = new sap.ui.model.Context(this._fileAnalyzeAlertsDataModel, sPath);
            this._oDialog.getContent()[1].setBindingContext(oPageContext, "$this.fileAnalyzeAlerts");
            this._fileAnalyzeAlertsDataModel.setProperty("/fileAnalysisDetailVisible", true);
        },

        backToMainPage: function() {
            this._fileAnalyzeAlertsDataModel.setProperty("/fileAnalysisDetailVisible", false);
        },

        saveAnalyzeFiles: function() {
            this.attachmentService.generateFileAnalysisPdfContent();
            this._oDialog.close();
        },

        trackSLASolutionClicked: function(oEvent) {
            if (this._oController.oCard.getMetadata().getName().includes("CaseCreationCard")) {
                this._oController.oCard.swaServiceEvent.slaSolutionClicked(oEvent);
            }
        },

    });
});

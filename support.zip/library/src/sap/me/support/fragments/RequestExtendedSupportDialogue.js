sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/core/Fragment",
    "sap/me/cards/model/models",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/core/Item",
    "sap/me/support/model/formatter"
], function(BaseObject, ResourceModel, Fragment, models, JSONModel, MessageToast, Item, formatter) {
    "use strict";

    return BaseObject.extend("sap.me.support.fragments.RequestExtendedSupportDialogue", {

        constructor : function(oView) {
            this._oView = oView;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._oView.setModel(new ResourceModel({bundle: this._i18n, supportedLocales: [""], fallbackLocale: ""}), "$this.i18n");
            this._oUserData = models.getUserModel().getData();
        },

        setCustomerData: function(customers) {
            this.customers = customers === undefined ? {} : customers;
            let oCustomerData = models.getCustomerModel().getData();
            let date = new Date();
            this.customersAmount = Object.keys(this.customers).length;
            this._getSUserName().then(function(sUserName) {
                this._oView.setModel(this.oDialogContentModel = new JSONModel({
                    isCustomerDetailsVisible: this.customersAmount === 1,
                    customerName: oCustomerData.companyname,
                    customerNumber: oCustomerData.companyid,
                    customerNumberWithout0: formatter.removeLeadingZero(oCustomerData.companyid),
                    requestedBy: sUserName + " (" + this._getSUserId() + ")",
                    requestedOn: (date.getMonth() + 1).toString() + "/" + date.getDate().toString() + "/" + date.getFullYear().toString(),
                    requestedOnSend:date.getFullYear().toString() + (date.getMonth() + 1).toString() + date.getDate().toString(),
                    selectedCustomerName: this.customers[Object.keys(this.customers)[0]],
                    selectedCustomerNumber: Object.keys(this.customers)[0],
                    targetScope: "",
                    enableSubmitBtn: this._isEnableSubmitBtn(),
                    showPartnerLabel: this.customers[Object.keys(this.customers)[0]].endsWith(this._i18n.getText("requestExtendedSupport_suCustomer"))
                }), "dialogContentData");
            }.bind(this));
        },

        onDialogOpened: function() {
            let oCustomerSelect = sap.ui.getCore().byId("sapMeRequestExtendedSupportDialogSelectCustomer");
            oCustomerSelect.destroyItems();
            Object.keys(this.customers).forEach(customerNumber => {
                oCustomerSelect.addItem(new Item(
                    {
                        key: customerNumber,
                        text: this.customers[customerNumber] + " (" + formatter.removeLeadingZero(customerNumber) + ")"
                    }
                ));
            });
            if (this.oDialogContentModel) {
                oCustomerSelect.setSelectedKey(this.oDialogContentModel.getProperty("/selectedCustomerNumber"));
            }
        },

        open: function() {
            this._oDialog ? this._oDialog.open() : Fragment.load({
                name: "sap.me.support.fragments.RequestExtendedSupportDialogue",
                controller: this
            }).then((Dialog) => {
                this._oDialog = Dialog;
                this._oView.addDependent(this._oDialog);
                this._oDialog.open();
            }, (e) => {
                console.log(e);
            });
        },

        checkMandatoryFields: function() {
            return !!this.oDialogContentModel.getProperty("/targetScope") && !!this.oDialogContentModel.getProperty("/selectedCustomerNumber");
        },

        onCancelButtonPressed: function() {
            this._oDialog.close();
        },

        onSubmitButtonPressed: function() {
            if (this.checkMandatoryFields()) {
                return this._getSUserName().then((sUserName) => {
                    return this._submitAndSave(sUserName);
                }).then(() => {
                    this._oDialog.close();
                    MessageToast.show(`${this._i18n.getText("requestExtendedSupport_submit_success_message")}`);
                },() => {
                    this._oDialog.close();
                    MessageToast.show(`${this._i18n.getText("requestExtendedSupport_submit_fail_message")}`);
                });
            } 
            MessageToast.show(`${this._i18n.getText("requestExtendedSupport_inputValueCheckInfo")}`);
            
        },

        onScope1709Chosen: function(oEvent) {
            if (oEvent.getSource().getSelected()) {
                this.oDialogContentModel.setProperty("/targetScope", "1709");
            } else {
                this.oDialogContentModel.setProperty("/targetScope", "");
            }
        },

        onScope1809Chosen: function(oEvent) {
            if (oEvent.getSource().getSelected()) {
                this.oDialogContentModel.setProperty("/targetScope", "1809");
            } else {
                this.oDialogContentModel.setProperty("/targetScope", "");
            }
        },

        onScope1909Chosen: function(oEvent) {
            if (oEvent.getSource().getSelected()) {
                this.oDialogContentModel.setProperty("/targetScope", "1909");
            } else {
                this.oDialogContentModel.setProperty("/targetScope", "");
            }
        },

        onCustomerSelectChanged: function(oEvent) {
            // initial loading should be ignored, the property would be set in 'setCustomerData'
            if (this.oDialogContentModel) {
                this.oDialogContentModel.setProperty("/selectedCustomerNumber", oEvent.getParameter("selectedItem").getKey());
                this.oDialogContentModel.setProperty("/selectedCustomerName", this.customers[oEvent.getParameter("selectedItem").getKey()]);
                this.oDialogContentModel.setProperty("/showPartnerLabel", this.customers[oEvent.getParameter("selectedItem").getKey()].endsWith(this._i18n.getText("requestExtendedSupport_suCustomer")));
            }
        },

        // private method
        _isEnableSubmitBtn: function() {
            return this._oUserData.simulatedUser ? false : true;
        },

        _getSUserName: function() {
            if (this._sSUserName) {
                return Promise.resolve(this._sSUserName);
            }
            let sSimulatedUser = this._oUserData.simulatedUser;
            if (!sSimulatedUser) {
                this._sSUserName = this._oUserData.firstName + " " + this._oUserData.lastName;
                return Promise.resolve(this._sSUserName);
            }
            return new Promise((res, rej) => {
                jQuery.ajax("/backend/raw/support/UserData?Susid=" + sSimulatedUser)
                    .then((data) => {
                        this._sSUserName = data.NameText;
                        res(this._sSUserName);
                    },() => rej());
            });
        },

        _submitAndSave: function(sUserName) {
            let sStartDate;
            switch (this.oDialogContentModel.getProperty("/targetScope")) {
                case "1709": sStartDate = "20230101"; break;
                case "1809": sStartDate = "20240101"; break;
                default: sStartDate = "20250101";
            }
            let isSendPartnerInfo = this.oDialogContentModel.getProperty("/showPartnerLabel");
            return new Promise((res,rej) => {
                jQuery.ajax("/backend/raw/support/CreateExtendRequestVerticle", {
                    method: "PUT",
                    contentType: "application/json",
                    data: JSON.stringify({
                        CustomerID:this.oDialogContentModel.getProperty("/selectedCustomerNumber"),
                        CustomerName:this.oDialogContentModel.getProperty("/selectedCustomerName")
                            .replace(" - " + this._i18n.getText("requestExtendedSupport_suCustomer"), "")
                            .replace(" - " + this._i18n.getText("requestExtendedSupport_ocCustomer"), ""),
                        SUserID:this._getSUserId(),
                        SUserName: sUserName,
                        StartDate:sStartDate,
                        Description:"SAP4Me_" + this._getSUserId() + "_"
                            + this._i18n.getText("requestExtendedSupportDialogue_target_scope_" + this.oDialogContentModel.getProperty("/targetScope") + "_date").split("\n")[0],
                        CreatedOn:this.oDialogContentModel.getProperty("/requestedOnSend"),
                        PartnerID:isSendPartnerInfo ? this.oDialogContentModel.getProperty("/customerNumber") : "",
                        PartnerName:isSendPartnerInfo ? this.oDialogContentModel.getProperty("/customerName") : ""
                    })
                }).then(data => res(data),() => rej());
            });
        },

        _getSUserId: function() {
            return this._oUserData.simulatedUser ? this._oUserData.simulatedUser : this._oUserData.userName;
        }

    });
});

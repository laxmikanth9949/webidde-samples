sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/me/support/utils/helper",
    "sap/me/support/fragments/SystemSelectFromKbaFilterDialog",
    "sap/m/Token"
], function(Object, Fragment, JSONModel, MessageToast, Filter, FilterOperator, helper, SystemSelectFromKbaFilterDialog, Token) {
    "use strict";

    return Object.extend("sap.me.support.fragments.SpecificNotesFilterDialog",{

        constructor: function(oCard) {
            this._oView = oCard.getCard();
            this._notesCard = oCard;
            this._i18n = sap.ui.getCore().getLibraryResourceBundle("sap.me.support");
            this._systemFilterDialog = new SystemSelectFromKbaFilterDialog(oCard);
            this._selectedCustomerObj = {};
        },

        open: function() {
            if (this._oDialog) {
                this._oDialog.open();
            } else {
                return Fragment.load({
                    name: "sap.me.support.fragments.SpecificNotesFilterDialog",
                    controller: this
                }).then(function(Dialog) {
                    this._oDialog = Dialog;
                    this._oView.addDependent(this._oDialog);
                    this._oDialog.setModel(this._notesCard._oSystemDataModel, "systemData");
                    this._oDialog.setModel(this._notesCard._oCustomerDataModel, "customerData");
                    this._initializeDefaultSelect();
                    this._addSystemInputListener();
                    this._oDialog.open();
                }.bind(this));
            }
        },

        close: function() {
            this._oDialog?.close();
        },

        getSelectedCustomer: function() {
            return this._selectedCustomerObj;
        },

        setDefaultCustomer: function() {
            const currentCustomer = this._notesCard._currentUseCustomer;
            this._selectedCustomerObj = currentCustomer;
            this._notesCard._oCustomerDataModel.setProperty("/selectedCustomer", currentCustomer?.Name);
        },

        /**
         * @description update system list model and sort system list
         */
        _updateAllSystemModel: function(systemList, selectedSystemsList) {
            // sort priority 1. selected systems 2.favorite systems 3.normal systems
            this._notesCard._oSystemDataModel.setProperty("/allList", systemList.sort(function(a,b) {
                if (selectedSystemsList.indexOf(a?.sysnr) !== -1 && selectedSystemsList.indexOf(b?.sysnr) !== -1) {
                    if (a?.isFavorite && !b?.isFavorite) {
                        return -1;
                    }
                }
                if (selectedSystemsList.indexOf(a?.sysnr) !== -1 && selectedSystemsList.indexOf(b?.sysnr) === -1) {
                    return -1;
                }
                if (selectedSystemsList.indexOf(a?.sysnr) === -1 && selectedSystemsList.indexOf(b?.sysnr) === -1) {
                    if (a?.isFavorite && !b?.isFavorite) {
                        return -1;
                    }
                }
                return 1;
            }));
        },

        /**
         * @description after select customer then should get all system
         */
        requestSystemForSelectedCustomer: function() {
            const that = this._notesCard;
            this.setBusyForSystemInput(true);
            return that.getAllSystem(that._oCustomerDataModel.getProperty("/selectedCustomer")).then(result => {
                this._updateAllSystemModel(result?.value ?? [],that._oSystemDataModel.getProperty("/selectedSystemList")?.map(item => item?.SystemNum) ?? []);
                this._resetSystemInputValue(result);
                this.setBusyForSystemInput(false);
            });
        },

        /**
         * @description after select customer then should reset system input based on already selected systems
         */
        _resetSystemInputValue: function(resultObj) {
            const selectedSystems = this._notesCard._oSystemDataModel.getProperty("/selectedSystemList");
            const allSystems = resultObj?.value.map(item => item?.sysnr) ?? [];
            if (selectedSystems.length === 0 || allSystems.length === 0) {
                return;
            }
            const filterSystems = selectedSystems.filter(item => allSystems.indexOf(item?.SystemNum) !== -1);
            this.setSystemMultiInput(filterSystems);
        },

        /**
         * @description when filter dialog first time open should load default select
         */
        _initializeDefaultSelect: function() {
            this.setDefaultCustomer();
            this.requestSystemForSelectedCustomer();
        },

        onCustomerSelect: function(oEvent) {
            this._selectedCustomerObj = this.getSelectedCustomerFormEvent(oEvent);
            this._notesCard._updateCurrentCustomer(this._selectedCustomerObj);
            // clear system selected
            this._systemFilterDialog?.cleanSystemDialogCache();
            this.setSystemMultiInput([]);
            // re-request system list by selected customer
            this.requestSystemForSelectedCustomer();
        },

        getSelectedCustomerFormEvent: function(oEvent) {
            return oEvent.getSource().getSelectedItem().getBindingContext("customerData").getObject();
        },

        onOpenSystemDialog: function() {
            this._systemFilterDialog.openSystemDialog();
        },

        setBusyForSystemInput: function(flag) {
            sap.ui.getCore().byId("forMeSpecificNotesSystemFilter")?.setBusy(flag);
        },

        onPressShowResults: function() {
            let selectedSystems = this._systemFilterDialog.getSelectedSystems();
            if (selectedSystems.length <= 0) {
                return;
            }
            this._notesCard._setCardLoading(true);
            this._notesCard._oSystemDataModel.setProperty("/selectedSystemList",selectedSystems);
            this._notesCard._oRequestParamsModel.setProperty("/systemNumList",selectedSystems.map(item => item?.SystemNum));
            this._notesCard?._resetCardModel();
            this._notesCard.fetchNotesWithProcessing();
            this.close();
        },

        setSystemMultiInput: function(selectedSystems) {
            sap.ui.getCore().byId("forMeSpecificNotesSystemFilter").setTokens(selectedSystems.map(item => {
                return new Token({text: item.SystemName, key: item.SystemNum});
            }));
        },

        getSystemMultiInputSystems: function() {
            return sap.ui.getCore().byId("forMeSpecificNotesSystemFilter").getTokens().map(item => item.getKey());
        },

        _addSystemInputListener: function() {
            sap.ui.getCore().byId("forMeSpecificNotesSystemFilter").attachTokenUpdate((oEvent) => {
                let selectedSystems = oEvent.getSource()?.getTokens()?.map(item => item?.getKey());
                const removedSys = oEvent?.getParameters()?.removedTokens[0]?.getKey() ?? "";
                const allSystems = this._notesCard._oSystemDataModel.getProperty("/allList");
                selectedSystems = selectedSystems.filter(item => item !== removedSys);
                this._systemFilterDialog._confirmSelectedSystems = allSystems.filter(item => selectedSystems?.indexOf(item?.sysnr) !== -1);
            });
        }
    });
});

/* eslint-env node */
const puppeteer = require("puppeteer");
process.env.CHROMIUM_BIN = puppeteer.executablePath();

module.exports = function(config) {
    "use strict";
    config.set({
        frameworks: ["ui5"],
        basePath: "./",
        type: "application",
        singleRun: true,
        captureTimeout: 300000,
        browserDisconnectTolerance: 3,
        browserDisconnectTimeout : 300000,
        browserNoActivityTimeout : 300000,
        ui5: {
            url: "http://localhost:4000",
            testpage: "test/sap/me/support/integration/opaTestLocal.qunit.html",
        },

        browsers: ["ChromiumHeadlessLargeDesktop"],
        browserConsoleLogOptions: {
            level: "error",
            format: "%b %T: %m",
            terminal: false
        },

        // you can define custom flags
        customLaunchers: {
            ChromiumHeadlessLargeDesktop: {
                base: "ChromiumHeadless",
                flags: ["--disable-web-security", "--disable-site-isolation-trials", "--window-size=1600,1200"]
            }
        },

        plugins: [
            require("karma-coverage"),
            require("karma-junit-reporter"),
            require("karma-spec-reporter"),
            require("karma-ui5"),
            require("karma-qunit"),
            require("karma-sinon"),
            require("karma-chrome-launcher"),
            require("karma-htmlfile-reporter")
        ],

        preprocessors: {
            "src/sap/me/support/cards/**/*.js": ["coverage"],
            "src/sap/me/support/fragments/**/*.js": ["coverage"]
        },
        coverageReporter: {
            includeAllSources: true,
            reporters: [
                {
                    type: "cobertura",
                    dir: "./target/jscoverage",
                    subdir: "/./",
                    file: "support-opa5-cobertura-coverage.xml"
                }
            ]
        },
        junitReporter: {
            outputDir: "./target/surefire-reports",
            outputFile: "support.opa5Tests.qunit.xml",
            suite: "",
            useBrowserName: false
        },
        htmlReporter: {
            outputFile: "./target/html/JUnit.html",
            // Optional
            pageTitle: "Test Results",
            subPageTitle: "Detailed test results for OPA5",
            groupSuites: true,
            useCompactStyle: true,
            useLegacyStyle: true,
            showOnlyFailed: false
        },
        reporters: ["progress", "coverage", "junit","html"],
    });
};

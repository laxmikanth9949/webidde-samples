/* eslint-env node */
const puppeteer = require("puppeteer");
process.env.CHROMIUM_BIN = puppeteer.executablePath();

let browser = "ChromiumHeadless",
    bSingleRun = true;
function isDebug(argument) {
    "use strict";
    return argument === "--debug";
}
if (process.argv.some(isDebug)) {
    browser = "ChromeDebugging";
    bSingleRun = false;
}

module.exports = function(config) {
    "use strict";

    config.set({
        frameworks: ["ui5", "qunit", "sinon"],
        basePath: "./",
        type: "library",
        paths: {
            src: "src/sap/me/support/cards",
            test: "test/sap/me/support/cards"
        },
        ui5: {
            mode: "script",
            config: {
                bindingSyntax: "complex",
                compatVersion: "edge",
                async: true,
                resourceroots: {
                    "sap.me.support.cards": "./base/src/sap/me/support/cards",
                    "sap.me.support.fragments": "./base/src/sap/me/support/fragments",
                    "test": "/base/test"
                }
            },
            tests: [
                "test/sap/me/support/cards/ActionPlansCardTest",
                "test/sap/me/support/cards/CaseAttachedSolutionsCardTest",
                "test/sap/me/support/cards/CaseAttachmentsCardTest",
                "test/sap/me/support/cards/CaseDiscussionCardTest",
                "test/sap/me/support/cards/ServicesRequestsAdvancedCardTest",
                "test/sap/me/support/cards/ServicesRequestsOverviewCardTest",
                "test/sap/me/support/cards/CaseScheduleAnExpertCardTest",
                "test/sap/me/support/cards/CaseScheduleAManagerCardTest",
                "test/sap/me/support/fragments/CaseDetailHeaderControllerTest",
                "test/sap/me/support/fragments/CaseDetailReplyDialogTest"
            ]
        },

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: false,

        // start these browsers
        browsers: [browser],
        browserConsoleLogOptions: {
            level: "info",
            format: "%b %T: %m",
            terminal: false
        },

        // you can define custom flags
        customLaunchers: {
            ChromiumHeadlessLargeDesktop: {
                base: "ChromiumHeadless",
                flags: ["--disable-web-security", "--disable-site-isolation-trials", "--window-size=1440,1080", "--no-sandbox"]
            },
            ChromeDebugging: {
                base: "Chrome",
                flags: [
                    "--remote-debugging-port=9333",
                    "--auto-open-devtools-for-tabs"
                ]
            }
        },

        plugins: [
            require("karma-coverage"),
            require("karma-junit-reporter"),
            require("karma-spec-reporter"),
            require("karma-ui5"),
            require("karma-qunit"),
            require("karma-sinon"),
            require("karma-chrome-launcher")
        ],
        preprocessors: {
            "src/sap/me/support/cards/**/*.js": ["coverage"],
            "src/sap/me/support/fragments/**/*.js": ["coverage"]
        },
        coverageReporter: {
            includeAllSources: true,
            reporters: [
                {
                    type: "cobertura",
                    dir: "./target/jscoverage",
                    subdir: "/./",
                    file: "support-cobertura-coverage.xml"
                },
                {"type": "text"}
            ],

        },
        junitReporter: {
            outputDir: "./target/surefire-reports",
            outputFile: "support.unitTests.qunit.xml",
            suite: "",
            useBrowserName: false
        },
        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_INFO,

        reporters: ["spec", "coverage", "junit"],
        specReporter: {
            maxLogLines: 300, // limit number of lines logged per test
            suppressFailed: false, // do not print information about failed tests
            suppressPassed: false, // do not print information about passed tests
            suppressSkipped: true, // do not print information about skipped tests
            showSpecTiming: false // print the time elapsed for each spec
        },
        singleRun: bSingleRun,
        // https://karma-runner.github.io/6.4/config/configuration-file.html#browsernoactivitytimeout
        browserNoActivityTimeout: 40000,
    });
};

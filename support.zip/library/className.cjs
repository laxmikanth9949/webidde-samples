const fs = require("fs");
const path = require("path");

const xmlFiles = [];
const cssFiles = [];
const xmlClassNames = new Set();
const cssClassNames = new Set();

const src = path.join(__dirname, "./src");

// find all xml/css/less files in src folder
function findFiles(src) {
    const files = fs.readdirSync(src);
    files.forEach((file) => {
        const filePath = path.join(src, file);
        const stat = fs.statSync(filePath);
        if (stat.isDirectory()) {
            findFiles(filePath);
            return;
        }
        if (path.extname(filePath) === ".xml") {
            xmlFiles.push(filePath);
        }
        if (path.extname(filePath) === ".css" || path.extname(filePath) === ".less") {
            cssFiles.push(filePath);
        }
    });
}

// find all class names in one xml file
function findXmlClassNames(filePath) {
    const data = fs.readFileSync(filePath, "utf-8");
    // find class="xxxx" in <button class="xxxx"/>
    const reg = /class="([^"]+)"/g;
    const res = data.match(reg);
    if (!res) {
        // console.log("no class name in xml file: ", filePath);
        return;
    }
    // get xxxx in class="xxxx"
    const classNameArr = res.map((item) => {
        const temp = item.split("=");
        return temp[1].replace(/"/g, "");
    })
    classNameArr.forEach((item) => {
        item.split(" ").forEach((item) => {
            xmlClassNames.add(item);
        });
    });
}

// find all class name in css file
function findCssClassNames(filePath) {
    const data = fs.readFileSync(filePath, "utf-8");
    // find .xxxx in .xxxx{}
    const reg = /\.([^{\s]*){/g;
    const res = data.match(reg);
    if (!res) {
        // console.log("no class name in css file: ", filePath);
        return;
    }
    // get xxxx in .xxxx
    const classNameArr = res.map((item) => {
        const temp = item.split(".");
        return temp[1];
    })
    classNameArr.forEach((item) => {
        cssClassNames.add(item.replace("{", ""));
    });
}

findFiles(src);
// collect all class name in xml files
xmlFiles.forEach((filePath) => {
    findXmlClassNames(filePath);
});
// collect all class name in css files
cssFiles.forEach((filePath) => {
    findCssClassNames(filePath);
});

const useLessClassNames = {
    sap: [],
    common: []
};
cssClassNames.forEach((item) => {
    if (!xmlClassNames.has(item)) {
        if (item.startsWith("sap")) {
            useLessClassNames.sap.push(item);
        } else {
            useLessClassNames.common.push(item);
        }
    }
})
console.log("here's the file to collect class name in less but not in xml: useLessClassNames.json");
fs.writeFileSync("./useLessClassNames.json", JSON.stringify(useLessClassNames, null, 4));

const useXmlClassNames = {
    sap: [],
    common: []
};
xmlClassNames.forEach((item) => {
    if (!cssClassNames.has(item)) {
        if (item.startsWith("sap")) {
            useXmlClassNames.sap.push(item);
        } else {
            useXmlClassNames.common.push(item);
        }
    }
});
console.log("here's the file to collect class name in xml but not in less: useXmlClassNames.json");
fs.writeFileSync("./useXmlClassNames.json", JSON.stringify(useXmlClassNames, null, 4));

console.log("Generate finished!");

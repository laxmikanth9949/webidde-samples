import path from "node:path";
import { fileURLToPath } from "node:url";
const dirname = path.dirname(fileURLToPath(import.meta.url));
import { mockData, mockRequest } from "@forme/mockserver/helper";

export default [
    // you can either mock a get request to any (JSON) file in the (mock)data sub-directory of your component
    mockRequest("example/AnyVerticle", "hello_world.json", dirname),
    // you can also define a middleware, with the method / path and use the mockData method to read the same file
    {
        method: "GET", path: "example/AnyOtherVerticle",
        handle: function(req, res) {
            res.send(mockData("hello_world.json", dirname));
        }
    },
    // or you can implement a dynamic express middleware function and handle the req / res yourself
    {
        method: "GET", path: "example/AnyThirdVerticle",
        handle: function(req, res, next) { // do NOT use a arrow function here, as the functional context will be overridden by the calling function (so this. is the session!)
            res.send({ data: "hello world" });
            return true; // do not call any next middleware
        }
    }
];
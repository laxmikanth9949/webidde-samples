package com.sap.me.example.data;

import static com.sap.me.example.api.Constants.EXAMPLE_NAMESPACE;
import static io.vertx.core.Future.succeededFuture;

import com.sap.me.example.api.Bird;

import io.neonbee.NeonBeeDeployable;
import io.neonbee.data.DataContext;
import io.neonbee.data.DataMap;
import io.neonbee.data.DataQuery;
import io.neonbee.data.DataVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonArray;

@NeonBeeDeployable(namespace = EXAMPLE_NAMESPACE)
public class StaticContentDataVerticle extends DataVerticle<JsonArray> {
    // POI 1: This is the internal name of the verticle, because the verticle is neither exposed to a third-party
    // (via the event bus) or to as a web service, it is a private name which starts with a underscore (_), which
    // indicates to NeonBee that it is a private verticle (meaning that it isn't exposed as a web service)
    private static final String NAME = "_StaticData";

    // POI 2: As we only want to access the verticle ourself via the event bus (from the BirdsDataVerticle) we don't
    // need to add the qualified name to the API part of this component and scoped the QUALIFIED_NAME package private
    static final String QUALIFIED_NAME = createQualifiedName("example", NAME);

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    @SuppressWarnings("checkstyle:magicnumber")
    public Future<JsonArray> retrieveData(DataQuery query, DataMap require, DataContext context) {
        // POI 3: Return some hard-coded / static content
        JsonArray birds = new JsonArray();
        birds.add(Bird.asJson(1, "Blackbird", "Turdidae"));
        birds.add(Bird.asJson(3, "Dove", "Columbidae"));
        return succeededFuture(birds);
    }
}

package com.sap.me.example.data;

// POI 1: We are referring to our own constants here, so the namespace and the name of the birds verticle can be
// centrally maintained and changed. If us or anyone who is using our API our verticles, they should use these constants
import static com.sap.me.example.api.Constants.EXAMPLE_BIRDS_NAME;
import static com.sap.me.example.api.Constants.EXAMPLE_NAMESPACE;
import static io.vertx.core.Future.failedFuture;
import static io.vertx.core.Future.succeededFuture;

import java.util.Collection;
import java.util.List;

import com.sap.me.example.api.Birds;

import io.neonbee.NeonBeeDeployable;
import io.neonbee.data.DataContext;
import io.neonbee.data.DataMap;
import io.neonbee.data.DataQuery;
import io.neonbee.data.DataRequest;
import io.neonbee.data.DataVerticle;
import io.vertx.core.Future;
import io.vertx.core.eventbus.MessageCodec;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;

// POI 2: The NeonBeeDeployable annotation results int his verticle being deployed in the example namespace
@NeonBeeDeployable(namespace = EXAMPLE_NAMESPACE)
public class BirdsDataVerticle extends DataVerticle<Birds> {
    @Override
    public String getName() {
        return EXAMPLE_BIRDS_NAME;
    }

    // POI 3: Instead of sending around plain JSON arrays or objects, we can tell NeonBee to use a codec for sending
    // data of this DataVerticle, meaning that if anybody requests data from this verticle, it will be provided in form
    // of a Birds object and nobody has to deal with parsing JSON, yay! (we have a little more effort setting it up
    // though, so it is only worth it if you are planning to be exposing the data in the first place)
    @Override
    public MessageCodec<Birds, Birds> getMessageCodec() {
        return Birds.CODEC;
    }

    @Override
    // POI 4: The requireData method can be used in order to tell NeonBee which data you need for further processing.
    // NeonBee will take care to request the required data and provide it to you in a DataMap in the retrieveData
    // method, which is called as soon as all required data becomes available
    public Future<Collection<DataRequest>> requireData(DataQuery query, DataContext context) {
        return succeededFuture(List.of(
                // POI 5: Reach out to the static content verticle to query for some data
                new DataRequest(StaticContentDataVerticle.QUALIFIED_NAME),
                // POI 6: Contact another verticle, to reach out to a web service to fetch data
                new DataRequest(WebContentDataVerticle.QUALIFIED_NAME, new DataQuery().addParameter("birdId", "2")),
                // POI 7: Use the DB verticle, to fetch some birds from the DB as well
                new DataRequest(DBContentDataVerticle.QUALIFIED_NAME,
                        new DataQuery().addParameter("family", "Accipitridae"))));
    }

    @Override
    public Future<Birds> retrieveData(DataQuery query, DataMap require, DataContext context) {
        // POI 8: The retrieveData method will be called after all results of the requireData method become available.
        // anyways the results might be successful or not, this method will be called in any case (e.g. because you want
        // to do check for individual errors and react accordingly here)
        if (require.failed()) {
            return failedFuture(require.cause());
        }

        // POI 9: Access the required results from the DataMap, via the qualified name again
        JsonArray staticBirds = require.resultFor(StaticContentDataVerticle.QUALIFIED_NAME);
        JsonObject webBird = require.resultFor(WebContentDataVerticle.QUALIFIED_NAME);
        JsonArray dbBirds = require.resultFor(DBContentDataVerticle.QUALIFIED_NAME);

        return succeededFuture(Birds.fromJson(new JsonArray().addAll(staticBirds).add(webBird).addAll(dbBirds)));
    }
}

package com.sap.me.example.data;

import static com.sap.me.example.api.Constants.EXAMPLE_NAMESPACE;
import static com.sap.vertx.btp.hanadb.HanaService.getHanaService;
import static io.netty.handler.codec.http.HttpResponseStatus.BAD_REQUEST;
import static io.vertx.core.Future.failedFuture;
import static java.time.Month.MAY;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Optional;

import org.jgroups.util.UUID;

import io.neonbee.NeonBeeDeployable;
import io.neonbee.data.DataContext;
import io.neonbee.data.DataException;
import io.neonbee.data.DataQuery;
import io.neonbee.data.DataVerticle;
import io.vertx.core.Future;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.json.JsonArray;
import io.vertx.sqlclient.Tuple;

@NeonBeeDeployable(namespace = EXAMPLE_NAMESPACE)
public class TypeShowcaseDataVerticle extends DataVerticle<JsonArray> {
    private static final String NAME = "TypeShowcase";

    static final String QUALIFIED_NAME = createQualifiedName("example", NAME);

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public Future<JsonArray> retrieveData(DataQuery query, DataContext context) {
        return getHanaService(vertx, "example-db").compose(hanaService -> {
            if (!query.getParameters().containsKey("id")) {
                // POI 1: for simple queries, that don't contain dynamic parameter it is ok to use .query(...)
                return hanaService.query("SELECT * FROM \"TypeShowcase\"").execute()
                        // POI 2: we can use the rowsToJsonArray helper for an easy conversion into JSON
                        .compose(hanaService::rowsToJsonArray);
            } else {
                // POI 3: for anything more complex you *must* use preparedQuery (or templates an extra Vert.x library)
                // NOTE: *NEVER!* (I cannot make this bold enough) use string concatenation in SQL queries, because it
                // introduces security vulnerabilities like SQL injection attacks!
                return hanaService
                        // POI 4: you can use the ? or numbered $1 placeholders in prepared statements
                        .preparedQuery("SELECT SINGLE * FROM \"TypeShowcase\" WHERE ID = ?")
                        .execute(Tuple.of(query.getParameter("id")))
                        .compose(hanaService::rowsToJsonArray);

            }
        });
    }

    @Override
    @SuppressWarnings("checkstyle:magicnumber")
    public Future<JsonArray> createData(DataQuery query, DataContext context) {
        return getHanaService(vertx, "example-db").compose(hanaService -> {
            return hanaService
                    .preparedQuery("INSERT INTO \"TypeShowcase\" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
                    .execute(Tuple.of(
                            // POI 5: the JDBC drivers performs an automatic conversion to the SQL data types if you use
                            // the appropriate source Java type. this list should act as a reference for you:
                            UUID.randomUUID().toString(), // UUID stored as NVARCHAR(36) on HANA, use Java's UUID class
                            true, // Boolean stored as BOOLEAN on HANA, use Java boolean
                            (byte) 42, // UInt8 stored as TINYINT on HANA, use Java byte
                            (short) 1337, // Int16 stored as SMALLINT on HANA, use Java short
                            (int) 314159, // Int32 stored as INTEGER on HANA, use Java int
                            (int) 271828, // Integer stored as INTEGER on HANA, use Java int
                            (long) 4294967296L, // Int64 stored as BIGINT on HANA, use Java long
                            (long) 1125899906842624L, // Integer64 stored as BIGINT on HANA, use Java long
                            (float) 3.1415926f, // Decimal(10, 2) stored as DECIMAL on HANA, use Java float or double
                            (double) 3.141592653589793d, // Double stored as DOUBLE on HANA, use Java double
                            LocalDate.of(2018, MAY, 4), // Date stored as DATE on HANA, use Java LocalDate or Date
                            LocalTime.of(3, 14, 15), // Time stored as TIME on HANA, use Java Local/OffsetTime
                            LocalDateTime.of(1996, 2, 11, 4, 45), // DateTime as SECONDDATE, use Local/OffsetDateTime
                            LocalDateTime.of(1977, 5, 25, 13, 37), // Timestamp as TIMESTAMP, use Local/OffsetDateTime
                            "Leeroy Jenkins", // String(100) stored as NVARCHAR(100) on HANA, use Java String
                            new byte[] { 13, 37 }, // Binary(100) stored as VARBINARY(100) on HANA, use Java byte[]
                            new byte[] { 0xA, 0xB, 0xC }, // LargeBinary stored as BLOB on HANA, use Java byte[]
                            "TL;DR" // LargeString stored as NCLOB on HANA, use Java String
            )).compose(hanaService::rowsToJsonArray);
        });
    }

    @Override
    public Future<JsonArray> updateData(DataQuery query, DataContext context) {
        if (!query.getParameters().containsKey("id")) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "parameter 'id' is missing"));
        }

        Object string = Optional.ofNullable(query.getBody()).map(Buffer::toJson)
                .filter(String.class::isInstance);
        if (string == null) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "expected JSON string as body"));
        }

        return getHanaService(vertx, "example-db").compose(hanaService -> {
            return hanaService
                    // POI 6: you can also use the ? placeholder pattern for UPDATE statements
                    .preparedQuery("UPDATE \"TypeShowcase\" SET STRING = ?, INTEGER64 = INTEGER64 + 1 WHERE ID = ?")
                    .execute(Tuple.of(string, query.getParameter("id")))
                    .compose(hanaService::rowsToJsonArray);
        });
    }

    @Override
    public Future<JsonArray> deleteData(DataQuery query, DataContext context) {
        if (!query.getParameters().containsKey("id")) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "'id' is missing"));
        }

        return getHanaService(vertx, "example-db").compose(hanaService -> {
            return hanaService
                    .preparedQuery("DELETE FROM \"TypeShowcase\" WHERE ID = ?")
                    .execute(Tuple.of(query.getParameter("id")))
                    .compose(hanaService::rowsToJsonArray);
        });
    }
}

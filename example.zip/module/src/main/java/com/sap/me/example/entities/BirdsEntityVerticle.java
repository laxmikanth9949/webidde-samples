package com.sap.me.example.entities;

import static com.sap.me.example.api.Constants.EXAMPLE_BIRDS_QUALIFIED_NAME;
import static com.sap.me.example.api.Constants.EXAMPLE_NAMESPACE;
import static com.sap.me.example.api.Constants.EXAMPLE_ODATA_SERVICE;
import static io.vertx.core.Future.failedFuture;
import static io.vertx.core.Future.succeededFuture;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.olingo.commons.api.data.Entity;
import org.apache.olingo.commons.api.data.Property;
import org.apache.olingo.commons.api.data.ValueType;
import org.apache.olingo.commons.api.edm.FullQualifiedName;

import com.google.common.annotations.VisibleForTesting;
import com.sap.me.example.api.Bird;
import com.sap.me.example.api.Birds;

import io.neonbee.NeonBeeDeployable;
import io.neonbee.data.DataContext;
import io.neonbee.data.DataMap;
import io.neonbee.data.DataQuery;
import io.neonbee.data.DataRequest;
import io.neonbee.entity.EntityVerticle;
import io.neonbee.entity.EntityWrapper;
import io.vertx.core.Future;

@NeonBeeDeployable(namespace = EXAMPLE_NAMESPACE)
public class BirdsEntityVerticle extends EntityVerticle {
    @VisibleForTesting
    static final FullQualifiedName ENTITY_NAME = new FullQualifiedName(EXAMPLE_ODATA_SERVICE, "Birds");

    @VisibleForTesting
    static final String ID_KEY = "ID";

    @VisibleForTesting
    static final String NAME_KEY = "name";

    @VisibleForTesting
    static final String FAMILY_KEY = "family";

    @Override
    public Future<Set<FullQualifiedName>> entityTypeNames() {
        // POI 1: The entity verticle has to announce, which entity/ies it returns data for
        return succeededFuture(Set.of(ENTITY_NAME));
    }

    @Override
    public Future<Collection<DataRequest>> requireData(DataQuery query, DataContext context) {
        // POI 2: Require data from the BirdsDataVerticle
        return succeededFuture(List.of(Birds.newBirdsRequest()));
    }

    @Override
    public Future<EntityWrapper> retrieveData(DataQuery query, DataMap require, DataContext context) {
        if (require.failed()) {
            return failedFuture(require.cause());
        }

        // POI 4: Create an EntityWrapper that contains the response
        return succeededFuture(new EntityWrapper(ENTITY_NAME, require.<Birds>resultFor(EXAMPLE_BIRDS_QUALIFIED_NAME)
                .stream().map(BirdsEntityVerticle::createBirdEntity).collect(Collectors.toList())));
    }

    /**
     * This method converts a given {@link Bird} object, into a OData / Olingo {@link Entity}.
     *
     * @param bird the bird to convert to a entity
     * @return a {@link Entity}
     */
    @VisibleForTesting
    static Entity createBirdEntity(Bird bird) {
        Entity entity = new Entity();
        entity.addProperty(new Property(null, ID_KEY, ValueType.PRIMITIVE, bird.getKey()));
        entity.addProperty(new Property(null, NAME_KEY, ValueType.PRIMITIVE, bird.getName()));
        entity.addProperty(new Property(null, FAMILY_KEY, ValueType.PRIMITIVE, bird.getFamily()));
        return entity;
    }
}

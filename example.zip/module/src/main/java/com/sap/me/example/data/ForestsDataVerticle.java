package com.sap.me.example.data;

import static com.sap.me.example.api.Constants.EXAMPLE_FORESTS_NAME;
import static com.sap.me.example.api.Constants.EXAMPLE_NAMESPACE;
import static com.sap.vertx.btp.hanadb.HanaService.getHanaService;
import static io.netty.handler.codec.http.HttpResponseStatus.BAD_REQUEST;
import static io.netty.handler.codec.http.HttpResponseStatus.NOT_FOUND;
import static io.vertx.core.Future.failedFuture;
import static io.vertx.core.Future.succeededFuture;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.google.common.base.Strings;

import io.neonbee.NeonBeeDeployable;
import io.neonbee.data.DataContext;
import io.neonbee.data.DataException;
import io.neonbee.data.DataMap;
import io.neonbee.data.DataQuery;
import io.neonbee.data.DataVerticle;
import io.neonbee.internal.json.ImmutableJsonArray;
import io.vertx.core.Future;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.RowSet;
import io.vertx.sqlclient.Tuple;

@NeonBeeDeployable(namespace = EXAMPLE_NAMESPACE)
public class ForestsDataVerticle extends DataVerticle<JsonObject> {
    @Override
    public String getName() {
        return EXAMPLE_FORESTS_NAME;
    }

    @Override
    public Future<JsonObject> retrieveData(DataQuery query, DataMap require, DataContext context) {
        String name = Optional.ofNullable(query.getParameter("name"))
                .map(String::trim).map(Strings::emptyToNull).orElse(null);
        if (name == null) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "Missing 'name' parameter"));
        }

        // POI 1: Similar to the DBContentDataVerticle this verticle uses the HANA service, to access content from the
        // HANA DB. However instead of accessing structured models in a relational format is uses an unstructured /
        // object store HANA JSON Document Store collection, that stores / reads unstructured content directly
        return getHanaService(vertx, "example-db").compose(hanaService -> {
            // POI 2: We can query for attributes of the JSON document, similar to how it would work on a regular table
            // note that compared to a regular table, quoting the fields of the JSON object like "name" is required!
            return hanaService.preparedQuery("SELECT * FROM \"Forests\" WHERE \"name\" = CAST(? AS NVARCHAR)")
                    .execute(Tuple.of(name)).map(RowSet::iterator).compose(rows -> {
                        if (!rows.hasNext()) {
                            return failedFuture(new DataException(NOT_FOUND.code(),
                                    "Could not find forest with name " + name));
                        }

                        Row row = rows.next(); // NOPMD: 'prematuredeclaration' necessary due to iterator
                        if (rows.hasNext()) {
                            return failedFuture(new DataException(BAD_REQUEST.code(),
                                    "Found more than one forest with name " + name));
                        }

                        // POI 3: Now instead of reading a single column / field from the table, we can access the whole
                        // "column" as a string and parse it to a JSON object instead. note that we can *not* use the
                        // Tuples "getJsonObject" method here, because JDBC will not return a JSON object but a string!
                        // XXX: in case you are dealing with very large JSON objects, consider using a blocking call
                        // here, to convert the JSON object, instead of running the code directly on the event bus!
                        return succeededFuture(new JsonObject(row.getString(0)));
                    });
        });
    }

    @Override
    public Future<JsonObject> createData(DataQuery query, DataContext context) {
        JsonObject forest = Optional.ofNullable(query.getBody()).map(Buffer::toJsonObject).orElse(null);
        if (forest == null) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "Missing body"));
        }

        if (!forest.containsKey("name")) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "Forest is missing a 'name' property"));
        }

        if (!forest.containsKey("trees")) {
            forest.put("trees", ImmutableJsonArray.EMPTY);
        } else if (!(forest.getValue("trees") instanceof JsonArray)) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "'trees' needs to be a JSON array"));
        }

        if (!forest.containsKey("birds")) {
            forest.put("birds", ImmutableJsonArray.EMPTY);
        } else if (!(forest.getValue("birds") instanceof JsonArray)) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "'birds' needs to be a JSON array"));
        }

        return getHanaService(vertx, "example-db").compose(hanaService -> {
            // POI 4: Inserting a JSON document into the HANA JSON Document Store works very similarly, instead of
            // defining the columns we would like to insert, we simply pass the whole object as a string to the
            // VALUES(...) part of the INSERT statement to HANA. Note that we have to serialize JSON to string here!
            return hanaService.preparedQuery("INSERT INTO \"Forests\" VALUES (?)")
                    .execute(Tuple.of(forest.toString())).map(forest);
        });
    }

    @Override
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public Future<JsonObject> updateData(DataQuery query, DataContext context) {
        String name = Optional.ofNullable(query.getParameter("name"))
                .map(String::trim).map(Strings::emptyToNull).orElse(null);
        if (name == null) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "Missing 'name' parameter"));
        }

        JsonObject forest = Optional.ofNullable(query.getBody()).map(Buffer::toJsonObject).orElse(null);
        if (forest == null) {
            return failedFuture(new DataException(BAD_REQUEST.code(), "Missing body"));
        }

        return getHanaService(vertx, "example-db").compose(hanaService -> {
            List<Future<?>> updates = new ArrayList<>();
            // XXX: updating the whole document fails on current HANA version, this will be fixed in a newer release
            if (forest.containsKey("trees")) {
                updates.add(hanaService
                        .preparedQuery(
                                "UPDATE \"Forests\" SET \"trees\" = PARSE_JSON(?) WHERE \"name\" = CAST(? AS NVARCHAR)")
                        .execute(Tuple.of(forest.getJsonArray("trees"), name)));
            }
            if (forest.containsKey("birds")) {
                updates.add(hanaService
                        .preparedQuery(
                                "UPDATE \"Forests\" SET \"birds\" = PARSE_JSON(?) WHERE \"name\" = CAST(? AS NVARCHAR)")
                        .execute(Tuple.of(forest.getJsonArray("birds").toString(), name)));
            }
            return Future.all(updates).mapEmpty();
        });
    }
}

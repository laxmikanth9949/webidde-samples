package com.sap.me.example.data;

import static com.sap.me.example.api.Constants.EXAMPLE_NAMESPACE;
import static com.sap.vertx.btp.hanadb.HanaService.getHanaService;

import java.util.stream.Collector;

import com.sap.me.example.api.Bird;

import io.neonbee.NeonBeeDeployable;
import io.neonbee.data.DataContext;
import io.neonbee.data.DataQuery;
import io.neonbee.data.DataVerticle;
import io.vertx.core.Future;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.SqlResult;
import io.vertx.sqlclient.Tuple;

@NeonBeeDeployable(namespace = EXAMPLE_NAMESPACE)
public class DBContentDataVerticle extends DataVerticle<JsonArray> {
    private static final String NAME = "_DBData";

    static final String QUALIFIED_NAME = createQualifiedName("example", NAME);

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public Future<JsonArray> retrieveData(DataQuery query, DataContext context) {
        // POI 1: This verticle uses the HANA service, to access content from the DB tables defined in models/db/.
        // Use the getHanaService method to access your databases. Note that accessing any other than your own
        // database, except the shared database you can access with getHanaService(vertx), is highly discouraged and
        // could result into an authorization error when being deployed to upstream landscapes
        return getHanaService(vertx, "example-db").compose(hanaService -> {
            // POI 2: We use the preparedQuery statement to fill in any parameters in the query, this allows the DB to
            // better optimize the request. We could use the hanaService::rowsToJsonArray helper to convert the result
            // POI 3: we can use the full table name example_db_Birds to access the database, however, because we
            // defined a synonym in the models/db/src/example.db.hdbsynonym file, we can also just use "Birds" here.
            // note: because "Birds" is a synonym and not a table, we must use the quoted name, instead of just Birds
            return hanaService.preparedQuery("SELECT * FROM \"Birds\" WHERE family = ?")
                    // POI 4: to map Row's into JsonObject & collect them into a JsonArray that we can return, we can
                    // use a Collector, note that using "mapping" and "collecting" is exclusive to one each other, so if
                    // you need to do both, you have to use the "collecting" interface for it
                    .collecting(Collector.of(JsonArray::new, (array, row) -> array.add(convertToBirdObject(row)),
                            (left, right) -> left.addAll(right)))
                    .execute(Tuple.of(query.getParameter("family"))).map(SqlResult::value);

            // POI 5: important note, in case of very large selects, Vert.x will use the thread that you call ".execute"
            // on in order to decode the JDBC response. in the case above, the event bus will be used. to not violate
            // Vert.x's "golden rule" [1], such request have to be wrapped in an vertx.executeBlocking(...) call
            // [1] https://vertx.io/docs/vertx-core/java/#golden_rule
        });
    }

    /**
     * This method transforms the response row from the database into a response which is compatible with the response
     * from the {@link StaticContentDataVerticle}. The database rows contain all columns upper case, e.g. "ID", "NAME",
     * "FAMILY", "LIVESINTREE_ID".
     *
     * @param row the row, as received from the database
     * @return a converted {@link JsonObject} representing a bird
     */
    private static JsonObject convertToBirdObject(Row row) {
        return Bird.asJson(row.getInteger("ID"), row.getString("NAME"), row.getString("FAMILY"),
                row.getInteger("LIVESINTREE_ID"));
    }
}

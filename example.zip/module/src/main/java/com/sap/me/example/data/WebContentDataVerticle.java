package com.sap.me.example.data;

import static com.sap.me.example.api.Constants.EXAMPLE_NAMESPACE;
import static com.sap.vertx.btp.connectivity.ConnectivityService.getConnectivityService;
import static com.sap.vertx.btp.destination.Destination.createInternetDestination;

import com.sap.me.example.api.Bird;
import com.sap.vertx.btp.connectivity.RequestOptions;
import com.sap.vertx.btp.destination.Destination;

import io.neonbee.NeonBeeDeployable;
import io.neonbee.data.DataContext;
import io.neonbee.data.DataMap;
import io.neonbee.data.DataQuery;
import io.neonbee.data.DataVerticle;
import io.vertx.core.Future;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.json.JsonObject;

@NeonBeeDeployable(namespace = EXAMPLE_NAMESPACE)
public class WebContentDataVerticle extends DataVerticle<JsonObject> {
    private static final String NAME = "_WebData";

    static final String QUALIFIED_NAME = createQualifiedName("example", NAME);

    // POI 1: The Destination that is used to fetch data from via the connectivity service
    private static final Destination BIRDS_SERVICE = createInternetDestination("https://mocki.io/");

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public Future<JsonObject> retrieveData(DataQuery query, DataMap require, DataContext context) {
        // POI 2: Create request to any web service using the destination we created in POI 1. commonly destinations are
        // configured in our environment centrally and can be retrieved from the destination service, however for the
        // ease of this example, we simply created a small mocki, that serves a single bird
        return getConnectivityService(vertx).compose(connectivityService -> {
            return connectivityService.createRequest(BIRDS_SERVICE, new RequestOptions().setMethod(HttpMethod.GET)
                    .setPath("/v1/16683cbc-08cf-46b8-9d62-b079def5eff3").setCorrelationId(context.correlationId()));
        }).compose(req -> {
            // POI 3: We can do further preparations here before we send the web request
            return req.addQueryParam("birdId", query.getParameter("birdId")).send();
        }).compose(response -> {
            // To keep this example simple, we will not handle a error response from the web service
            // POI 4: Transform the response of the web service (because the format is [purposefully] different)
            return convertToBirdObject(response.body());
        });
    }

    /**
     * This method transforms the response body from the birds service into a response which is compatible with the
     * response from the {@link StaticContentDataVerticle}.
     *
     * An example response body from the fictional birds service looks like:
     *
     * <pre>
     * {
     *   "birdId": 1337,
     *   "birdName": "Blackbird",
     *   "birdFamily": "Turdidae"
     * }
     * </pre>
     *
     * @param response the response {@link Buffer}, as received from an external service
     * @return a future to a converted {@link JsonObject} representing a bird
     */
    private Future<JsonObject> convertToBirdObject(Buffer response) {
        // POI 5: Even though for such very small conversions it is discouraged to use "executeBlocking" we wanted to
        // add it in an example in order for you to remember the Golden Rule [1] of Vert.x and *never* block the event
        // loop. In case you need to do processing of any sort, please consider wrapping your code as follows:
        // [1] https://vertx.io/docs/vertx-core/java/#golden_rule
        return vertx.executeBlocking(promise -> {
            JsonObject object = response.toJsonObject();
            promise.complete(Bird.asJson(object.getInteger("birdId"), object.getString("birdName"),
                    object.getString("birdFamily")));
        });
    }
}

package com.sap.me.example.data;

import static com.google.common.truth.Truth.assertThat;
import static com.sap.me.example.api.Constants.EXAMPLE_BIRDS_QUALIFIED_NAME;
import static com.sap.me.example.data.WebContentDataVerticleTest.ROBIN;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.sap.me.example.api.Bird;
import com.sap.me.example.api.Birds;

import io.neonbee.data.DataVerticle;
import io.neonbee.internal.json.ImmutableJsonObject;
import io.neonbee.test.base.DataVerticleTestBase;
import io.vertx.core.Verticle;
import io.vertx.core.Vertx;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.junit5.Checkpoint;
import io.vertx.junit5.Timeout;
import io.vertx.junit5.VertxTestContext;

// POI 1: We have a own test base for DataVerticles that provides some handy methods & initialization!
public class BirdsDataVerticleTest extends DataVerticleTestBase {
    public static final Bird IMPERIAL_EAGLE = new Bird(7, "Imperial Eagle", "Accipitridae");

    public static final Birds EXPECTED_BIRDS = new Birds(Lists.newArrayList(
            Iterables.concat(StaticContentDataVerticleTest.EXPECTED_BIRDS, WebContentDataVerticleTest.EXPECTED_BIRDS,
                    List.of(IMPERIAL_EAGLE))));

    private Map<Class<?>, String> deploymentIds = new HashMap<>();

    @BeforeEach
    public void setUp(TestInfo testInfo, VertxTestContext testContext) {
        // POI 2: You can use the createDummyDataVerticle functionality of the DataVerticleTestBase to create mock
        // response verticles either for some static or dynamic data queries
        DataVerticle<JsonArray> staticDummyVerticle = createDummyDataVerticle(StaticContentDataVerticle.QUALIFIED_NAME)
                .withStaticResponse(StaticContentDataVerticleTest.EXPECTED_BIRDS.toJson());
        DataVerticle<JsonObject> webDummyVerticle = createDummyDataVerticle(WebContentDataVerticle.QUALIFIED_NAME)
                .withDynamicResponse((dataQuery, dataContext) -> {
                    if (dataQuery.getParameter("birdId").equals("2")) {
                        return ROBIN.toJson();
                    } else {
                        return ImmutableJsonObject.EMPTY;
                    }
                });
        DataVerticle<JsonArray> dbDummyVerticle = createDummyDataVerticle(DBContentDataVerticle.QUALIFIED_NAME)
                .withStaticResponse(new JsonArray().add(IMPERIAL_EAGLE.toJson()));

        // POI 3: Deploy all verticles that we need for the tests to succeed (we use a checkpoint here, instead of
        // creating a composite future, this way it is way more easy to read and we know if any individual deployment
        // fails. the testContext will get completed as soon as the last checkpoint is flagged!)
        Checkpoint checkpoint = testContext.checkpoint(4);
        deployVerticle(staticDummyVerticle).onComplete(testContext.succeeding(deployment -> {
            deploymentIds.put(StaticContentDataVerticle.class, deployment.getDeploymentId());
            checkpoint.flag();
        }));
        deployVerticle(webDummyVerticle).onComplete(testContext.succeeding(deployment -> {
            deploymentIds.put(WebContentDataVerticle.class, deployment.getDeploymentId());
            checkpoint.flag();
        }));
        deployVerticle(dbDummyVerticle).onComplete(testContext.succeeding(deployment -> {
            deploymentIds.put(DBContentDataVerticle.class, deployment.getDeploymentId());
            checkpoint.flag();
        }));
        deployVerticle(new BirdsDataVerticle()).onComplete(testContext.succeeding(deployment -> checkpoint.flag()));
    }

    @Test
    @Timeout(value = 2, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should receive correct content from StaticContentDataVerticle and WebContentDataVerticle")
    void getBirdsViaDataRequest(VertxTestContext testContext) {
        // POI 4: Use the assertDataEquals method to check if the data request returns the data we expect
        assertDataEquals(requestData(Birds.newBirdsRequest()), EXPECTED_BIRDS, testContext)
                .onComplete(testContext.succeedingThenComplete());
    }

    // POI 5: We use JUnits parameterized tests, in order to test both constellations
    @ParameterizedTest(name = "should receive failure if one request to {0} fails")
    @ValueSource(
            classes = { StaticContentDataVerticle.class, WebContentDataVerticle.class, DBContentDataVerticle.class })
    @Timeout(value = 2, timeUnit = TimeUnit.SECONDS)
    void failBirdsViaDataRequest(Class<? extends Verticle> verticleClass, Vertx vertx, VertxTestContext testContext) {
        // POI 6: We undeploy the verticle classes, to force the data request to fail
        undeployVerticle(deploymentIds.get(verticleClass)).onComplete(nothing -> {
            assertDataFailure(requestData(Birds.newBirdsRequest()), exception -> {}, testContext)
                    .onComplete(testContext.succeedingThenComplete());
        });
    }

    @Test
    @Timeout(value = 5, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should be accessible via the web endpoint")
    void getBirdsViaWebEndpoint(VertxTestContext testContext) {
        // POI 7: Create a request to the web endpoint
        createRequest(HttpMethod.GET, "/raw/" + EXAMPLE_BIRDS_QUALIFIED_NAME).send(testContext.succeeding(resp -> {
            testContext.verify(() -> {
                assertThat(resp.statusCode()).isEqualTo(200);
                assertThat(resp.bodyAsJsonArray()).isEqualTo(EXPECTED_BIRDS.toJson());
            });
            testContext.completeNow();
        }));
    }
}

package com.sap.me.example.data;

import static com.google.common.truth.Truth.assertThat;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.sap.me.example.api.Bird;
import com.sap.me.example.api.Birds;

import io.neonbee.data.DataRequest;
import io.neonbee.test.base.DataVerticleTestBase;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.json.JsonArray;
import io.vertx.junit5.Timeout;
import io.vertx.junit5.VertxTestContext;

public class StaticContentDataVerticleTest extends DataVerticleTestBase {
    public static final Bird BLACKBIRD = new Bird(1, "Blackbird", "Turdidae");

    public static final Bird DOVE = new Bird(3, "Dove", "Columbidae");

    public static final Birds EXPECTED_BIRDS = new Birds(List.of(BLACKBIRD, DOVE));

    @BeforeEach
    public void setUp(VertxTestContext testContext) {
        deployVerticle(new StaticContentDataVerticle()).onComplete(testContext.succeedingThenComplete());
    }

    @Test
    @Timeout(value = 2, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should receive correct static content")
    void getBirdsViaDataRequest(VertxTestContext testContext) {
        // POI 1: request data from a DataVerticle
        this.<JsonArray>requestData(new DataRequest(StaticContentDataVerticle.QUALIFIED_NAME))
                .onComplete(testContext.succeeding(jsonArray -> {
                    // POI 2: verify asynchronous code
                    testContext.verify(() -> assertThat(jsonArray).containsExactlyElementsIn(EXPECTED_BIRDS.toJson()));
                    // POI 3: complete the test context, to signal the test runner all checks completed
                    testContext.completeNow();
                }));
    }

    @Test
    @Timeout(value = 2, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should receive correct static content")
    void getBirdsViaDataRequestAssertHelpers(VertxTestContext testContext) {
        assertDataEquals(requestData(new DataRequest(StaticContentDataVerticle.QUALIFIED_NAME)),
                EXPECTED_BIRDS.toJson(), testContext).onComplete(testContext.succeedingThenComplete());
    }

    @Test
    @Timeout(value = 2, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should not be accessible via web endpoint")
    void getBirdsViaWebEndpoint(VertxTestContext testContext) {
        createRequest(HttpMethod.GET, "/raw/" + StaticContentDataVerticle.QUALIFIED_NAME)
                .send(testContext.succeeding(resp -> {
                    testContext.verify(() -> assertThat(resp.statusCode()).isEqualTo(404));
                    testContext.completeNow();
                }));
    }
}

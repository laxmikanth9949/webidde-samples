package com.sap.me.example.entities;

import static com.google.common.truth.Truth.assertThat;
import static com.sap.me.example.api.Constants.EXAMPLE_BIRDS_QUALIFIED_NAME;
import static com.sap.me.example.entities.BirdsEntityVerticle.ENTITY_NAME;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import com.google.common.collect.Range;
import com.sap.me.example.api.Bird;
import com.sap.me.example.api.Birds;
import com.sap.me.example.data.BirdsDataVerticleTest;

import io.neonbee.data.DataVerticle;
import io.neonbee.test.base.ODataEndpointTestBase;
import io.neonbee.test.base.ODataRequest;
import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.junit5.Checkpoint;
import io.vertx.junit5.Timeout;
import io.vertx.junit5.VertxTestContext;

// POI 1: We have a ODataEndpoint test base that provides some handy methods and initialization!
public class BirdsEntityVerticleTest extends ODataEndpointTestBase {
    private String birdsDummyVerticleDeploymentId;

    @Override
    // POI 2: Declare model files that should be exposed via our test endpoint (our Gradle build tooling will take care
    // that the CSN models are actually compiled before the test code is executed)
    public List<Path> provideEntityModels() {
        try {
            return Files.walk(Path.of("./../models/dist/compiled")).filter(p -> p.toString().endsWith(".csn"))
                    .collect(Collectors.toList());
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    @BeforeEach
    public void setUp(TestInfo testInfo, Vertx vertx, VertxTestContext testContext) {
        // POI 3: Mock the BirdsDataVerticle that is being called by the BirdsEntityVerticle
        DataVerticle<Birds> birdsDummyVerticle = createDummyDataVerticle(EXAMPLE_BIRDS_QUALIFIED_NAME)
                .withStaticResponse(BirdsDataVerticleTest.EXPECTED_BIRDS);

        // POI 4: Because the BirdsDataVerticle is not deployed for real, we need to register the codec ourself
        vertx.eventBus().registerDefaultCodec(Birds.class, Birds.CODEC);

        Checkpoint checkpoint = testContext.checkpoint(2);
        deployVerticle(birdsDummyVerticle).onComplete(testContext.succeeding(deployment -> {
            birdsDummyVerticleDeploymentId = deployment.getDeploymentId();
            checkpoint.flag();
        }));
        deployVerticle(new BirdsEntityVerticle()).onComplete(testContext.succeeding(deployment -> checkpoint.flag()));
    }

    @Test
    @Timeout(value = 10, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should receive correct birds via DataRequest")
    void getBirdsViaDataRequest(VertxTestContext testContext) {
        // POI 5: Send a new OData request, the ODataEndpointTestBase helps us to send a valid OData request
        Future<HttpResponse<Buffer>> oDataResponse = requestOData(new ODataRequest(ENTITY_NAME));

        // POI 6: Validate OData response, we can use the assert methods of the test base here, this way we don't have
        // to parse any of the OData format and can simply deal with JSON data
        assertODataEntitySetContainsExactly(oDataResponse,
                BirdsDataVerticleTest.EXPECTED_BIRDS.stream().map(Bird::toJson)
                        .peek(birdJson -> birdJson.put("ID", birdJson.remove("key"))).collect(Collectors.toList()),
                testContext).onComplete(testContext.succeedingThenComplete());
    }

    @Test
    @Timeout(value = 10, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should fail if birds could not get retrieved")
    void failBirdsViaDataRequest(VertxTestContext testContext) {
        // POI 7: We undeploy the verticle the EntityVerticle draws from to force it to fail
        undeployVerticle(birdsDummyVerticleDeploymentId).onComplete(nothing -> {
            Future<HttpResponse<Buffer>> oDataResponse = requestOData(new ODataRequest(ENTITY_NAME));

            // POI 8: Assert that the HTTP response actually succeeds, but the status code signals a failure
            oDataResponse.onComplete(testContext.succeeding(response -> testContext.verify(() -> {
                assertThat(response.statusCode()).isNotIn(Range.closed(200, 399));
                testContext.completeNow();
            })));
        });
    }
}

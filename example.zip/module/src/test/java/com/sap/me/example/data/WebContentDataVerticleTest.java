package com.sap.me.example.data;

import static com.google.common.truth.Truth.assertThat;
import static com.sap.vertx.btp.connectivity.ConnectivityServiceExtension.createResponse;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import com.sap.me.example.api.Bird;
import com.sap.me.example.api.Birds;
import com.sap.vertx.btp.connectivity.ConnectivityServiceExtension;

import io.neonbee.data.DataQuery;
import io.neonbee.data.DataRequest;
import io.neonbee.test.base.DataVerticleTestBase;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.vertx.core.Future;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.junit5.Checkpoint;
import io.vertx.junit5.Timeout;
import io.vertx.junit5.VertxTestContext;

public class WebContentDataVerticleTest extends DataVerticleTestBase {
    public static final Bird ROBIN = new Bird(5, "Robin", "Muscicapidae");

    public static final Bird STARLING = new Bird(6, "Starling", "Sturnidae");

    public static final Birds EXPECTED_BIRDS = new Birds(List.of(ROBIN));

    private static Future<HttpResponse<Buffer>> buildDummyWebServiceResponse(Bird dummyBird) {
        JsonObject body = new JsonObject().put("birdId", dummyBird.getKey()).put("birdName", dummyBird.getName())
                .put("birdFamily", dummyBird.getFamily());
        return createResponse(HttpResponseStatus.OK, body.toBuffer());
    }

    // POI 1: Mock the ConnectivityService
    @RegisterExtension
    static ConnectivityServiceExtension connServiceExtension = new ConnectivityServiceExtension(request -> {
        // POI 2: Inspect request and provide some dummy data as necessary
        String id = request.queryParams().get("birdId");
        if ("5".equals(id)) {
            return buildDummyWebServiceResponse(ROBIN);
        } else {
            return buildDummyWebServiceResponse(STARLING);
        }
    });

    @BeforeEach
    public void setUp(VertxTestContext testContext) {
        deployVerticle(new WebContentDataVerticle()).onComplete(testContext.succeedingThenComplete());
    }

    private static DataRequest createDataRequest(int birdId) {
        return new DataRequest(WebContentDataVerticle.QUALIFIED_NAME,
                new DataQuery().addParameter("birdId", Integer.toString(birdId)));
    }

    @Test
    @Timeout(value = 200, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should receive correct birds by passed id")
    void getBirdsViaDataRequest(VertxTestContext testContext) {
        Checkpoint checkpoint = testContext.checkpoint(2);

        // POI 3: Verify dynamic response, we can use the assertDataEquals method with normal JSON data, this way we do
        // not need to take care of requesting / waiting for the response. Also we use a checkpoint here because we need
        // want to check for multiple asynchronous conditions
        assertDataEquals(requestData(createDataRequest(5)), ROBIN.toJson(), testContext)
                .onComplete(testContext.succeeding(result -> checkpoint.flag()));
        assertDataEquals(requestData(createDataRequest(6)), STARLING.toJson(), testContext)
                .onComplete(testContext.succeeding(result -> checkpoint.flag()));
    }

    @Test
    @Timeout(value = 2, timeUnit = TimeUnit.SECONDS)
    @DisplayName("should not be accessible via web endpoint")
    void getBirdsViaWebEndpoint(VertxTestContext testContext) {
        createRequest(HttpMethod.GET, "/raw/" + WebContentDataVerticle.QUALIFIED_NAME).addQueryParam("birdId", "5")
                .send(testContext.succeeding(resp -> {
                    testContext.verify(() -> assertThat(resp.statusCode()).isEqualTo(404));
                    testContext.completeNow();
                }));
    }
}

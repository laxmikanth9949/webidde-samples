# Changelog example

## Release v2.3.8 (2024-06-26)

### Features

- implement example card for table sorting (#59) ([781f2f17c87f8cd](https://github.wdf.sap.corp/forme/example/commit/781f2f17c87f8cdd325c219d80d36f06551f5775))
- Document how Checkmarx One can be enabled as part of our security pipelines ([87616c172c899a5](https://github.wdf.sap.corp/forme/example/commit/87616c172c899a578bfc17f8e0874ce920608fd6))
- add pagination example (#53) ([1a6c2bb97c29da7](https://github.wdf.sap.corp/forme/example/commit/1a6c2bb97c29da71025f0e3a049e9d720dc75bce))

### Bug Fixes

- file extensions ([b80f1f4db15e5d8](https://github.wdf.sap.corp/forme/example/commit/b80f1f4db15e5d85730a5c5793d9330c4c8bb5da))
- in-file extensions ([45b25ab926c0f4a](https://github.wdf.sap.corp/forme/example/commit/45b25ab926c0f4a02f57eb05c74be2bbb72b4702))

### Chores

- update changelog ([41b3de85d8f9f51](https://github.wdf.sap.corp/forme/example/commit/41b3de85d8f9f51d8ef093454b88842c4b4fcbc9))

---


## Release v2.3.7 (2024-04-08)

---


## Release v2.3.5 (2024-04-03)

### Features

- Switch to re-usable Github workflows for Checkmarx One ([de2b4335dc91525](https://github.wdf.sap.corp/forme/example/commit/de2b4335dc915258d13a0b2ddbc43f9d0af0afdc))
- switch to re-usable Github workflows for CodeQL ([be74afaa814d24f](https://github.wdf.sap.corp/forme/example/commit/be74afaa814d24f6ce804713f425c7782aa3eaf9))
- generateChangelog (#52) ([b917be30afd8298](https://github.wdf.sap.corp/forme/example/commit/b917be30afd82981abe3ba03c6f47722b9c2ad33))
- Switch to re-usable Github workflows for Checkmarx One ([255390429d644b4](https://github.wdf.sap.corp/forme/example/commit/255390429d644b42b12716a9f62b70f240e8eb95))
- switch to re-usable Github workflows for CodeQL ([84e96963444b304](https://github.wdf.sap.corp/forme/example/commit/84e96963444b3042ee2b6ebe9f80ad8947b6f0df))
- common pipeline ([b7d2d6d8419f8d3](https://github.wdf.sap.corp/forme/example/commit/b7d2d6d8419f8d39880d68723c1ba651294a1f9c))
- delete deprecated build pipeline ([28bda03f6e04750](https://github.wdf.sap.corp/forme/example/commit/28bda03f6e047504315d551f85750192218ffbd9))
- common pipeline ([5688a6228e4ed98](https://github.wdf.sap.corp/forme/example/commit/5688a6228e4ed98d11b18260932509844e5a4fec))
- Set up Checkmarx One Github Action as part of the Github Workflow of forme/example ([2459802d9438df0](https://github.wdf.sap.corp/forme/example/commit/2459802d9438df06df1fea8ba4a5f61f84e9d511))
- common pipeline ([e02c6d29ad29e2b](https://github.wdf.sap.corp/forme/example/commit/e02c6d29ad29e2b5da6317ca1c6ac43ca0518f0a))
- common pipeline ([d06c396f17f3e5d](https://github.wdf.sap.corp/forme/example/commit/d06c396f17f3e5da591b7f3532f0583ae0788762))
- common pipeline ([c759486ef4e2a64](https://github.wdf.sap.corp/forme/example/commit/c759486ef4e2a6411f095db45490c79e68693ea5))
- common pipeline ([850dfca9df18dc6](https://github.wdf.sap.corp/forme/example/commit/850dfca9df18dc69dcde4d4e251d126788d0cc66))
- common pipeline ([54b0a03a98dcad5](https://github.wdf.sap.corp/forme/example/commit/54b0a03a98dcad54428adf2b910f18f6be79e98f))
- common pipeline ([481a78b04eb7fad](https://github.wdf.sap.corp/forme/example/commit/481a78b04eb7fad19f910a40493f92bac46cc93c))
- common pipeline ([3d7ab677f644e75](https://github.wdf.sap.corp/forme/example/commit/3d7ab677f644e75d54230994cc43af83f8730d4d))
- common pipeline ([33cf026d087fc87](https://github.wdf.sap.corp/forme/example/commit/33cf026d087fc87863202bcc914374622afbcc66))
- common pipeline ([2d3ee3899b445d0](https://github.wdf.sap.corp/forme/example/commit/2d3ee3899b445d080e6111ca3bb2d59900fc8f26))
- common pipeline ([180bf3e7f4c48fb](https://github.wdf.sap.corp/forme/example/commit/180bf3e7f4c48fb1c9034c93ed0163dfce8a69c4))

### Bug Fixes

- reset changelog ([551bb5516780cbd](https://github.wdf.sap.corp/forme/example/commit/551bb5516780cbd59208faef8938551abe93aaa5))
- reset changelog ([6a22225c8ae501e](https://github.wdf.sap.corp/forme/example/commit/6a22225c8ae501ee697f3a83b7f161b583d53130))
- reset changelog ([68ae08d198b46cf](https://github.wdf.sap.corp/forme/example/commit/68ae08d198b46cfde1e338b4560898728fc8b51b))
- reset changelog ([d298e529307834e](https://github.wdf.sap.corp/forme/example/commit/d298e529307834eeebe200cce7f5d11886736c05))
- reset version ([0f905e839f96ed8](https://github.wdf.sap.corp/forme/example/commit/0f905e839f96ed8c52547d97d061850adcfea03b))
- reset version ([179a718188a154d](https://github.wdf.sap.corp/forme/example/commit/179a718188a154d3d2da2dfa19c4a38c865ccdad))
- deleting artifacts ([6b8d9c6de7bc6dd](https://github.wdf.sap.corp/forme/example/commit/6b8d9c6de7bc6dd739dba09741af91aaeaf44ba3))
- secrets inherit ([1aaa67276adc178](https://github.wdf.sap.corp/forme/example/commit/1aaa67276adc17836d9bbcf6f1e35c09c09d6b5c))

### Chores

- update changelog ([eeceabcacd97f0e](https://github.wdf.sap.corp/forme/example/commit/eeceabcacd97f0e2e42ab081dd75cf8d611be88a))
- update changelog ([3f2498f2a900d50](https://github.wdf.sap.corp/forme/example/commit/3f2498f2a900d50abcdcb0f08d48bd57a477ab3e))
- update changelog ([554f5ba32e6575f](https://github.wdf.sap.corp/forme/example/commit/554f5ba32e6575f754da7d31681da79e166d4f1c))
- update changelog ([25a6bbb6ce340c2](https://github.wdf.sap.corp/forme/example/commit/25a6bbb6ce340c25279c23c49b3843fbdc4ca625))
- update changelog ([687a198805d6064](https://github.wdf.sap.corp/forme/example/commit/687a198805d60649a12a63fc7992ea141d81b0b6))
- update changelog and set version 2.3.6-SNAPSHOT ([f862a210b9cc60f](https://github.wdf.sap.corp/forme/example/commit/f862a210b9cc60f09148f125e1e07d98133772b7))

### Tests

- version as imput ([c2139a17b6c3dea](https://github.wdf.sap.corp/forme/examplecommit/c2139a17b6c3deaa3e09dd3500a599c24a7b3946))
- publish component ([6a78351a92ae3a8](https://github.wdf.sap.corp/forme/examplecommit/6a78351a92ae3a89e12cc4d7abe5f32da91567a4))
- version as imput ([39bb9f0678b7e97](https://github.wdf.sap.corp/forme/examplecommit/39bb9f0678b7e97a5959cc879f996b0dcb3b1f32))
- version as imput ([2f47abc4c3f4c70](https://github.wdf.sap.corp/forme/examplecommit/2f47abc4c3f4c7007ffeb3436f83b910b0c3efb7))

---


## Release v2.3.4 (2024-02-27)

### Features

- update README ([ee01ddddc63994b](https://github.wdf.sap.corp/forme/example/commit/ee01ddddc63994bb727f435806474937f4896094))

---


## Release v2.3.3 (2024-02-27)

    ### Tests

            - bump to 2.3.2 ([79687c0d166c08e](https://github.wdf.sap.corp/forme/examplecommit/79687c0d166c08e7ee5f21553e493084fe59e513))

---


## Release v2.3.1 (2024-02-08)

### Features

- java 21 ([cf3be3d9d5c7c3e](https://github.wdf.sap.corp/forme/example/commit/cf3be3d9d5c7c3e8089ba50d6d5c9be3f6559dd5))
- Set up Checkmarx One Github Action as part of the Github Workflow of forme/example ([4e7d7ed896eebd9](https://github.wdf.sap.corp/forme/example/commit/4e7d7ed896eebd94ceda9e490f1ede8d79878faf))
- Set up Checkmarx One Github Action as part of the Github Workflow of forme/example ([1e939eb0b73d1dd](https://github.wdf.sap.corp/forme/example/commit/1e939eb0b73d1ddde26de3ffcda34cfa15b2b986))
- Add a CodeQL pipeline for forme/example (Add Javascript) ([7690e124e881022](https://github.wdf.sap.corp/forme/example/commit/7690e124e8810229fe3770bb0e36c7256348acb0))

### Documentation

- change CloudFoundry to Kubernetes commands ([9cac39eb7d6815f](https://github.wdf.sap.corp/forme/example/commit/9cac39eb7d6815f400fff91ecff55e9114658326))

    ### Tests

            - bump package versions ([c29d087145a6a43](https://github.wdf.sap.corp/forme/examplecommit/c29d087145a6a43e03f6aff8fa60e41ad64097c8))
            - bump to 2.3.1 ([3ed9696148f3cd5](https://github.wdf.sap.corp/forme/examplecommit/3ed9696148f3cd5996b301ae37448e272befffc8))

---


## Release v2.3.0 (2023-07-17)

### Features

- Switch to using a versionless Vert.X CodeQL query pack ([58e49d2768030f4](https://github.wdf.sap.corp/forme/example/commit/58e49d2768030f4a5056435ebf08ccf91d31b41e))
- add a LuigiView using Luigi Micro Frontend ([d7df9a666aaad09](https://github.wdf.sap.corp/forme/example/commit/d7df9a666aaad097f34784a133fac7b65022c2ba))
- add GHAS support ([cb4205064b6bf6b](https://github.wdf.sap.corp/forme/example/commit/cb4205064b6bf6bc5e1b8ba501d08e51d861ea37))
- upgrade to Gradle 8 ([e0f373b5c93308b](https://github.wdf.sap.corp/forme/example/commit/e0f373b5c93308bc0c89f8d5da573f02ef65ea01))
- add Get Assistance button to example header ([7479c13016d2f56](https://github.wdf.sap.corp/forme/example/commit/7479c13016d2f5654acfd38cf1520b590c358577))
- extend TypeShowcase by auto. generated defaults ([ea3d96b4cbf9f5d](https://github.wdf.sap.corp/forme/example/commit/ea3d96b4cbf9f5da306ddaf584316359a51214fc))
- add TypeShowcase for HANA DB ([fde9c462388b2c3](https://github.wdf.sap.corp/forme/example/commit/fde9c462388b2c3c30371a314cf98cb847c15a1a))
- add native HANA JSON Document Store example & synonyms ([7c0b563c2b83e95](https://github.wdf.sap.corp/forme/example/commit/7c0b563c2b83e95e9a8b050e825347397cd456e4))

### Bug Fixes

- UI5 / frontend versions ([c68815f72731a82](https://github.wdf.sap.corp/forme/example/commit/c68815f72731a822fb024d199f9b405b5cbe6794))
- update JSON documents on HANA DB ([2a2dab27fc770b5](https://github.wdf.sap.corp/forme/example/commit/2a2dab27fc770b514029ee08a429bdf41f6c5c04))
- parameterized hana query ([49f9ce87666d393](https://github.wdf.sap.corp/forme/example/commit/49f9ce87666d3933d3d2c2c6cf36025b0a75bf1a))

### Documentation

- add comment about large JDBC requests ([d6ac32ecd69ab54](https://github.wdf.sap.corp/forme/example/commit/d6ac32ecd69ab544dffde344b8000e7e7b3b3ae8))

### Code Refactoring

- use PreparedStatement mapping/collecting over spliterator ([0ab0ca77a7afeff](https://github.wdf.sap.corp/forme/example/commit/0ab0ca77a7afeffbf14037b04f2e91117be3c33e))

    ### Tests

            - bump node dependencies ([09f9116e32d902e](https://github.wdf.sap.corp/forme/examplecommit/09f9116e32d902eeaaf821cd0f102cabff5b989c))
            - bump frontend & gradle plugin dependencies ([6fb948e2b39e009](https://github.wdf.sap.corp/forme/examplecommit/6fb948e2b39e009c0e797f4c6414af916d5bf26f))
            - upgrade to frontend 3.0.0 ([4b8c7cec22019f7](https://github.wdf.sap.corp/forme/examplecommit/4b8c7cec22019f7e4fc69413746d107ed95e7b25))
            - bump to 2.2.1 ([a277937f0521292](https://github.wdf.sap.corp/forme/examplecommit/a277937f0521292463557c569084117522af3739))

---


## Release v2.2.0 (2023-02-27)

### Features

- enable data storage on HANA database ([61e31360349e752](https://github.wdf.sap.corp/forme/example/commit/61e31360349e7527e1401cad47acb79876331d59))
- show how to navigate using links ([fdb3f6174ca3205](https://github.wdf.sap.corp/forme/example/commit/fdb3f6174ca32053dabe75334668d4d4ef23e495))
- improve cards examples ([6a708908513ef38](https://github.wdf.sap.corp/forme/example/commit/6a708908513ef382fda65b79ec31f22871cfe5ff))
- improve example app ([e73339773e1797d](https://github.wdf.sap.corp/forme/example/commit/e73339773e1797d2d163997b0e93c08138b6157d))
- add example for shared Models class ([ab9278e2d923473](https://github.wdf.sap.corp/forme/example/commit/ab9278e2d923473c94bda025c55b1700caf117ba))

### Bug Fixes

- converting database objects ([b1e41cf29f45e4b](https://github.wdf.sap.corp/forme/example/commit/b1e41cf29f45e4b003a91801f7259d3818dc05ae))
- BirdEntityVerticleTest after model change ([88fa24cc95de1ef](https://github.wdf.sap.corp/forme/example/commit/88fa24cc95de1ef6db6fdda9374fa3be08638beb))
- issue with settings ([3ade3dca0f83e46](https://github.wdf.sap.corp/forme/example/commit/3ade3dca0f83e4687e63de3943ffe08f990cdca9))

### Code Refactoring

- adapt CDS namespace to new lower-case convention ([53e2ec36ed94bc5](https://github.wdf.sap.corp/forme/example/commit/53e2ec36ed94bc59b3c33831e3362eaffc75faef))

### Continuous Integration

- bump frontend framework to 2.3.1 ([9f01485fcdba31e](https://github.wdf.sap.corp/forme/examplecommit/9f01485fcdba31e7edf7fa92d1eb26e9baeb01f8))

    ### Tests

            - bump frontend to 2.5.14 ([08ae7cc7bb3036e](https://github.wdf.sap.corp/forme/examplecommit/08ae7cc7bb3036e7007cb6b11c524fdf40c62aec))
            - bump gradle plugin to 2.5.0 ([9e17bbcfc061736](https://github.wdf.sap.corp/forme/examplecommit/9e17bbcfc061736a3b20587c7bf156f726e9fd49))
            - bump to 2.1.2 ([dd7414909750bcc](https://github.wdf.sap.corp/forme/examplecommit/dd7414909750bccad95be83dc492934d45dcf202))

---


## Release v2.1.1 (2022-10-15)

### Bug Fixes

- use shared model instead of creating a new model ([d90a394725fda00](https://github.wdf.sap.corp/forme/example/commit/d90a394725fda001914ce0cf3d1f6dbacfbbd9ea))

    ### Tests

            - bump to 2.1.1 ([3ed582f57621b95](https://github.wdf.sap.corp/forme/examplecommit/3ed582f57621b95f61ffe22a23b727bcabad5cb0))

---


## Release v2.1.0 (2022-10-13)

### Bug Fixes

- button label in subview ([4712aaefcf9fe87](https://github.wdf.sap.corp/forme/example/commit/4712aaefcf9fe87a52b3d858ad695f6043f32724))
- Update settings.gradle ([b84ffdf9a17b9bc](https://github.wdf.sap.corp/forme/example/commit/b84ffdf9a17b9bc355fde1f788cb449aa7adee5c))
- switch to artifactory for non-SAP npm components ([be26d37d6327402](https://github.wdf.sap.corp/forme/example/commit/be26d37d6327402e44a0c9a0fb3795095f794106))
- add artifactory for non-SAP components ([61075f6c17103e4](https://github.wdf.sap.corp/forme/example/commit/61075f6c17103e44503acafdbf5593766dcbf28e))
- formatter issue in VSCode ([4e1a263b5f6bf2c](https://github.wdf.sap.corp/forme/example/commit/4e1a263b5f6bf2cf60ed892246f84e7886c82228))

### Chores

- remove snapshot repositories from settings.gradle ([aeefdd760858f2c](https://github.wdf.sap.corp/forme/example/commit/aeefdd760858f2c9e9b8e9aab337dc0b9d8822ee))

### Continuous Integration

- bump node dependencies ([931b222b79074de](https://github.wdf.sap.corp/forme/examplecommit/931b222b79074def580d3c6adcaa94967f5d2067))
- update to Gradle tooling 2.3.+ ([78764897f6ad743](https://github.wdf.sap.corp/forme/examplecommit/78764897f6ad743aad4c8ad48038e6e69e1c93be))
- switch to unprotected build status icon ([75ba5f39a841091](https://github.wdf.sap.corp/forme/examplecommit/75ba5f39a841091877a2ad0dc525ab56a6fc2c53))
- add sonarqube setup ([92ff285ded29274](https://github.wdf.sap.corp/forme/examplecommit/92ff285ded29274f668868ab2cf4287b3f06837f))
- add build status to README.md ([21ac36a2048ac6a](https://github.wdf.sap.corp/forme/examplecommit/21ac36a2048ac6aab8ebc11e75dfde872bf8ca39))

    ### Tests

            - bump to 2.1.0 and all dependencies ([7815c93944e9359](https://github.wdf.sap.corp/forme/examplecommit/7815c93944e9359349cf11b4a0f39ee2dda9ddf2))
            - bump to 2.0.1 ([4656f5e7aac4d9b](https://github.wdf.sap.corp/forme/examplecommit/4656f5e7aac4d9b7781f09a157778d00e0fbbeb3))

---


## Release v2.0.0 (2022-04-22)

### Features

- add translation ([16533f774928834](https://github.wdf.sap.corp/forme/example/commit/16533f774928834bc854a0da69ada34c589eed45))
- example how to add additional (CI only) tests ([a929aeef4aabf71](https://github.wdf.sap.corp/forme/example/commit/a929aeef4aabf71214919bfd2d574f4ba1c145e1))
- link in required frontend components in :dev / :e2e ([9ecd18f694a450f](https://github.wdf.sap.corp/forme/example/commit/9ecd18f694a450fa7b0351baae8cf290df6e4de7))
- add debug / launch configuration and tasks for VSCode ([c5ce7362ec0f997](https://github.wdf.sap.corp/forme/example/commit/c5ce7362ec0f997d9831551936acaabffce47bd9))
- adapt to latest build tooling, add api example ([a1c95a36325344a](https://github.wdf.sap.corp/forme/example/commit/a1c95a36325344ad974ef08dfe35996fd02cc770))
- rewrite BirdsEntityVerticleTestBase ([1650c823941fd51](https://github.wdf.sap.corp/forme/example/commit/1650c823941fd512ad6defeb3f78d42066833cc6))
- upgrade to vert.x 4 and use latest core libraries ([9753061320e382c](https://github.wdf.sap.corp/forme/example/commit/9753061320e382cddf9f11d14d7018b6268c36bd))

### Bug Fixes

- adapt to new Gradle plugin to fix build ([ebb8ceaea9c9aad](https://github.wdf.sap.corp/forme/example/commit/ebb8ceaea9c9aad8ec72d06416fee19f4d38d07b))
- NeonBee and logback config file for ServerVerticle ([03b9492cc189e75](https://github.wdf.sap.corp/forme/example/commit/03b9492cc189e75711cbe1d74b9fdfb9b45db09c))
- bump Node.js frontend dependencies to fix :e2e ([9d907abd360682e](https://github.wdf.sap.corp/forme/example/commit/9d907abd360682e27afcd8af9ca0d2ebdb35e3aa))

### Documentation

- conventions sections to README.md ([223f7f999598400](https://github.wdf.sap.corp/forme/example/commit/223f7f99959840033f0834dd68e91980aeff8ced))
- added TL;DR getting started guide ([1e160d0817012e6](https://github.wdf.sap.corp/forme/example/commit/1e160d0817012e6dedf9c11759a86476c192fe64))

### Code Refactoring

- migrate to frontend fw2.0 ([d5740ec1f017462](https://github.wdf.sap.corp/forme/example/commit/d5740ec1f017462cd97f611f55f7fa9831acd7d0))
- adaptions for framework 2.0 build ([1b06f6b7ed9dff6](https://github.wdf.sap.corp/forme/example/commit/1b06f6b7ed9dff68b39c06521f30a69c98f673e0))
- replace Vulp.x with NeonBee and add examples ([4ab970dd164598b](https://github.wdf.sap.corp/forme/example/commit/4ab970dd164598b1b842b24561b15a1a8247531d))

### Continuous Integration

- add commitLint example to Jenkinsfile ([c03f805ea8a71f4](https://github.wdf.sap.corp/forme/examplecommit/c03f805ea8a71f4a73e691ad3d6772894ee1d38e))
- add Jenkinsfile ([b2b12cea76ea237](https://github.wdf.sap.corp/forme/examplecommit/b2b12cea76ea2373771e6bc7732c7c7ab51e2e18))

### Tests

- raise test coverage to 100% ([71982b857110a55](https://github.wdf.sap.corp/forme/examplecommit/71982b857110a5564d6f06794f19e7c38002ab36))

    ### Tests

            - upgrade Gradle and yarn.lock ([c526c85b77b57c0](https://github.wdf.sap.corp/forme/examplecommit/c526c85b77b57c04d3b0ddf0dfe519187485e618))
            - upgrade UI5 to 1.99.0 ([242943b67b6a4a2](https://github.wdf.sap.corp/forme/examplecommit/242943b67b6a4a21dc109e2d2793e2d906ddaa7f))
            - upgrade to Gradle build tooling release ([36266cd30051ada](https://github.wdf.sap.corp/forme/examplecommit/36266cd30051adab4db5c70c3be4efa7f23677ae))

---


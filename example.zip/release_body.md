## Artifacts\n\n[Link to Build Info UI](https://int.repositories.cloud.sap/ui/builds/Release/117/1712489011422/published?buildRepo=artifactory-build-info)\n
## Changelog\n\n[Link to CHANGELOG.md](https://github.wdf.sap.corp/forme/example/blob/dev/CHANGELOG.md)\n

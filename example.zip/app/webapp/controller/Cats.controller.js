sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function(Controller) {
    "use strict";

    var CatsController = Controller.extend("sap.me.apps.example.controller.Cats", {
        handlePressNavigate: function(oEvent) {
            this.getOwnerComponent().getRouter().navTo("trees");
        }
    });

    return CatsController;
});
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/base/util/UriParameters"
], function(Controller, JSONModel, UriParameters) {
    "use strict";

    var TreesController = Controller.extend("sap.me.apps.example.controller.Trees", {
        onInit: function() {
            this.getView().setModel(this._oModel = new JSONModel({}), "state");
			this.getOwnerComponent().getRouter().getRoute("trees").attachMatched(oEvent => {
                this._oModel.setProperty("/highlightedTree", UriParameters.fromQuery(location.search).get("highlight"));
            });
        },

        handlePressNavigate: function(oEvent) {
            this.getOwnerComponent().getRouter().navTo("birds");
        }
    });

    return TreesController;
});
package com.sap.me.example.api;

import static com.google.common.truth.Truth.assertThat;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import io.neonbee.NeonBeeMockHelper;
import io.neonbee.data.DataContext;
import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.eventbus.DeliveryOptions;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.json.JsonArray;

public class BirdsTest {
    private static Bird BIRD1 = new Bird(1, "foo", "bar");

    private static Bird BIRD2 = new Bird(2, "baz", "qux");

    private static Bird BIRD3 = new Bird(3, "qox", "qax");

    @Test
    void testInitialization() {
        assertThat(new Birds(Collections.emptyList())).isEmpty();
        assertThat(new Birds(List.of(BIRD1, BIRD2, BIRD3))).isEqualTo(List.of(BIRD1, BIRD2, BIRD3));
        assertThat(new Birds(List.of(BIRD1, BIRD2))).isEqualTo(List.of(BIRD1, BIRD2));
        assertThat(new Birds(List.of(BIRD2, BIRD3))).isEqualTo(List.of(BIRD2, BIRD3));
        assertThat(new Birds(List.of(BIRD1, BIRD3))).isEqualTo(List.of(BIRD1, BIRD3));
        assertThat(new Birds(List.of(BIRD1))).isEqualTo(List.of(BIRD1));
    }

    @Test
    void testAbstractMethods() {
        assertThat(new Birds(Collections.emptyList())).hasSize(0);
        assertThat(new Birds(List.of(BIRD1, BIRD2))).hasSize(2);
        assertThat(new Birds(List.of(BIRD1, BIRD2, BIRD3))).hasSize(3);

        assertThat(new Birds(List.of(BIRD1, BIRD2, BIRD3))).containsExactly(BIRD1, BIRD2, BIRD3);
        assertThat(new Birds(List.of(BIRD1, BIRD2))).containsExactly(BIRD1, BIRD2).inOrder();
        assertThat(new Birds(List.of(BIRD2, BIRD3))).containsExactly(BIRD2, BIRD3).inOrder();
        assertThat(new Birds(List.of(BIRD1, BIRD3))).containsExactly(BIRD1, BIRD3).inOrder();
        assertThat(new Birds(List.of(BIRD1))).containsExactly(BIRD1);
    }

    @Test
    void testNonModifiable() {
        assertThrows(UnsupportedOperationException.class, () -> new Birds(new ArrayList<>()).add(BIRD1));
        assertThrows(UnsupportedOperationException.class, () -> new Birds(List.of(BIRD1)).remove(BIRD1));
    }

    @Test
    void testToJson() {
        assertThat(new Birds(Collections.emptyList()).toJson()).isEqualTo(new JsonArray());
        assertThat(new Birds(List.of(BIRD1)).toJson()).isEqualTo(new JsonArray().add(BIRD1.toJson()));
        assertThat(new Birds(List.of(BIRD1, BIRD2)).toJson())
                .isEqualTo(new JsonArray().add(BIRD1.toJson()).add(BIRD2.toJson()));
        assertThat(new Birds(List.of(BIRD1, BIRD2, BIRD3)).toJson())
                .isEqualTo(new JsonArray().add(BIRD1.toJson()).add(BIRD2.toJson()).add(BIRD3.toJson()));
    }

    @Test
    void testFromJson() {
        assertThat(Birds.fromJson(new JsonArray())).isEqualTo(new Birds(Collections.emptyList()));
        assertThat(Birds.fromJson(new JsonArray().add(BIRD1.toJson()))).isEqualTo(new Birds(List.of(BIRD1)));
        assertThat(Birds.fromJson(new JsonArray().add(BIRD1.toJson()).add(BIRD2.toJson())))
                .isEqualTo(new Birds(List.of(BIRD1, BIRD2)));
        assertThat(Birds.fromJson(new JsonArray().add(BIRD1.toJson()).add(BIRD2.toJson()).add(BIRD3.toJson())))
                .isEqualTo(new Birds(List.of(BIRD1, BIRD2, BIRD3)));
    }

    @Test
    void testBirdsRequest() {
        assertThat(Birds.newBirdsRequest().getQualifiedName()).isEqualTo(Constants.EXAMPLE_BIRDS_QUALIFIED_NAME);
        assertThat(Birds.newBirdsRequest()).isNotSameInstanceAs(Birds.newBirdsRequest());
    }

    @Test
    void testRequireBirds() {
        Vertx vertxMock = mock(Vertx.class);
        EventBus eventBusMock = mock(EventBus.class);
        when(vertxMock.eventBus()).thenReturn(eventBusMock);
        when(eventBusMock.request(anyString(), any(), any(DeliveryOptions.class))).thenReturn(Future.succeededFuture());
        NeonBeeMockHelper.registerNeonBeeMock(vertxMock);
        clearInvocations(vertxMock);

        Birds.requireBirds(vertxMock, mock(DataContext.class));
        verify(vertxMock).eventBus();

        ArgumentCaptor<String> addressCaptor = ArgumentCaptor.forClass(String.class);
        try {
            verify(eventBusMock).request(addressCaptor.capture(), any(), any(DeliveryOptions.class));
        } catch (AssertionError e) {
            verify(eventBusMock).request(addressCaptor.capture(), any(), any(DeliveryOptions.class), any());
        }

        assertThat(addressCaptor.getValue()).contains(Constants.EXAMPLE_BIRDS_QUALIFIED_NAME);
    }

    @Test
    void testCodec() {
        assertThat(Birds.CODEC.systemCodecID()).isEqualTo(-1);
        assertThat(Birds.CODEC.name()).isEqualTo("BirdsCodec");

        Birds birds = new Birds(Collections.emptyList());
        assertThat(Birds.CODEC.transform(birds)).isSameInstanceAs(birds);

        Buffer expectedBuffer = Buffer.buffer();
        Buffer encoded = birds.toJson().toBuffer();
        expectedBuffer.appendInt(encoded.length());
        expectedBuffer.appendBuffer(encoded);

        Buffer buffer = Buffer.buffer();
        Birds.CODEC.encodeToWire(buffer, birds);
        assertThat(buffer).isEqualTo(expectedBuffer);

        assertThat(Birds.CODEC.decodeFromWire(0, buffer)).isEqualTo(birds);
    }
}

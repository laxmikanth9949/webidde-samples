package com.sap.me.example.api;

import static com.google.common.truth.Truth.assertThat;
import static com.sap.me.example.api.Constants.EXAMPLE_BIRDS_NAME;
import static com.sap.me.example.api.Constants.EXAMPLE_BIRDS_QUALIFIED_NAME;
import static com.sap.me.example.api.Constants.EXAMPLE_NAMESPACE;
import static com.sap.me.example.api.Constants.EXAMPLE_ODATA_SERVICE;

import org.junit.jupiter.api.Test;

public class ConstantsTest {
    @Test
    void testConstants() {
        // this is essentially just to reach 100% line coverage
        assertThat(EXAMPLE_ODATA_SERVICE).isEqualTo("example.Service");
        assertThat(EXAMPLE_NAMESPACE).isEqualTo("example");
        assertThat(EXAMPLE_BIRDS_NAME).isEqualTo("Birds");
        assertThat(EXAMPLE_BIRDS_QUALIFIED_NAME).isEqualTo("example/Birds");
    }
}

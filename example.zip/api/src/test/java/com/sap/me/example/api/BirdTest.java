package com.sap.me.example.api;

import static com.google.common.truth.Truth.assertThat;

import org.junit.jupiter.api.Test;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import io.vertx.core.json.JsonObject;

public class BirdTest {
    @Test
    void testInitialization() {
        assertThat(new Bird(1, "foo", "bar").getKey()).isEqualTo(1);
        assertThat(new Bird(2, "baz", "qux").getName()).isEqualTo("baz");
        assertThat(new Bird(3, "qox", "qax").getFamily()).isEqualTo("qax");
        assertThat(new Bird(4, "qox", "qos").getLivesInTree()).isNull();
        assertThat(new Bird(5, "qix", "qes", 6).getLivesInTree()).isEqualTo(6);
    }

    @Test
    void testToJson() {
        assertThat(new Bird(1, "foo", "bar").toJson())
                .isEqualTo(new JsonObject().put("key", 1).put("name", "foo").put("family", "bar")
                        .putNull("livesInTree_ID"));
        assertThat(new Bird(2, "baz", "qux").toJson())
                .isEqualTo(new JsonObject().put("key", 2).put("name", "baz").put("family", "qux")
                        .putNull("livesInTree_ID"));
        assertThat(new Bird(3, "qox", "qax").toJson())
                .isEqualTo(new JsonObject().put("key", 3).put("name", "qox").put("family", "qax")
                        .putNull("livesInTree_ID"));
        assertThat(new Bird(4, "qox", "qos").toJson())
                .isEqualTo(new JsonObject().put("key", 4).put("name", "qox").put("family", "qos")
                        .putNull("livesInTree_ID"));
        assertThat(new Bird(5, "qix", "qes", 6).toJson())
                .isEqualTo(new JsonObject().put("key", 5).put("name", "qix").put("family", "qes").put("livesInTree_ID",
                        6));
    }

    @Test
    void testFromJson() {
        assertThat(Bird.fromJson(new JsonObject().put("key", 1).put("name", "foo").put("family", "bar")))
                .isEqualTo(new Bird(1, "foo", "bar"));
        assertThat(Bird.fromJson(new JsonObject().put("key", 2).put("name", "baz").put("family", "qux")))
                .isEqualTo(new Bird(2, "baz", "qux"));
        assertThat(Bird.fromJson(new JsonObject().put("key", 3).put("name", "qox").put("family", "qax")))
                .isEqualTo(new Bird(3, "qox", "qax"));
        assertThat(Bird.fromJson(new JsonObject().put("key", 4).put("name", "qox").put("family", "qos")
                .putNull("livesInTree_ID")))
                        .isEqualTo(new Bird(4, "qox", "qos"));
        assertThat(Bird
                .fromJson(new JsonObject().put("key", 5).put("name", "qix").put("family", "qes").put("livesInTree_ID",
                        6)))
                                .isEqualTo(new Bird(5, "qix", "qes", 6));
    }

    @Test
    void testAsJson() {
        assertThat(Bird.asJson(1, "foo", "bar"))
                .isEqualTo(new JsonObject().put("key", 1).put("name", "foo").put("family", "bar")
                        .putNull("livesInTree_ID"));
        assertThat(Bird.asJson(2, "baz", "qux"))
                .isEqualTo(new JsonObject().put("key", 2).put("name", "baz").put("family", "qux")
                        .putNull("livesInTree_ID"));
        assertThat(Bird.asJson(3, "qox", "qax"))
                .isEqualTo(new JsonObject().put("key", 3).put("name", "qox").put("family", "qax")
                        .putNull("livesInTree_ID"));
        assertThat(Bird.asJson(4, "qix", "qoz", 5))
                .isEqualTo(new JsonObject().put("key", 4).put("name", "qix").put("family", "qoz")
                        .put("livesInTree_ID", 5));
    }

    @Test
    void testToString() {
        assertThat(new Bird(1, "foo", "bar").toString()).isEqualTo("foo (bar)");
        assertThat(new Bird(2, "baz", "qux").toString()).isEqualTo("baz (qux)");
        assertThat(new Bird(3, "qox", "qax").toString()).isEqualTo("qox (qax)");
        assertThat(new Bird(4, "qox", "qos", 1).toString()).isEqualTo("qox (qos)");
    }

    @Test
    @SuppressFBWarnings(value = "EC_NULL_ARG", justification = "we want to test if the contract fails for null")
    void testEquals() {
        Bird bird = new Bird(1, "foo", "bar");
        assertThat(bird.equals(bird)).isTrue();
        assertThat(bird.equals(null)).isFalse();
        assertThat(bird.equals(new Object())).isFalse();
        assertThat(bird).isEqualTo(new Bird(1, "foo", "bar"));
        assertThat(bird).isNotEqualTo(new Bird(2, "foo", "bar"));
        assertThat(bird).isNotEqualTo(new Bird(1, "bar", "bar"));
        assertThat(bird).isNotEqualTo(new Bird(1, "foo", "foo"));
        assertThat(bird).isNotEqualTo(new Bird(1, "foo", "bar", 1));
    }

    @Test
    void testHashCode() {
        assertThat(new Bird(1, "foo", "bar").hashCode()).isEqualTo(new Bird(1, "foo", "bar").hashCode());
        assertThat(new Bird(1, "foo", "bar", 1).hashCode()).isEqualTo(new Bird(1, "foo", "bar", 1).hashCode());
        assertThat(new Bird(1, "foo", "bar").hashCode()).isNotEqualTo(new Bird(2, "foo", "bar").hashCode());
        assertThat(new Bird(1, "foo", "bar").hashCode()).isNotEqualTo(new Bird(1, "bar", "bar").hashCode());
        assertThat(new Bird(1, "foo", "bar").hashCode()).isNotEqualTo(new Bird(1, "foo", "foo").hashCode());
        assertThat(new Bird(1, "foo", "bar", 1).hashCode()).isNotEqualTo(new Bird(1, "foo", "bar").hashCode());
        assertThat(new Bird(1, "foo", "bar", 1).hashCode()).isNotEqualTo(new Bird(1, "foo", "bar", 2).hashCode());
    }
}

package com.sap.me.example.api;

import java.util.Objects;

import javax.annotation.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.vertx.core.json.JsonObject;

/**
 * This class is a POJO of a bird that can be converted to JSON and vice-versa.
 */
public class Bird {
    private final int key;

    private final String name;

    private final String family;

    private final Integer livesInTree;

    /**
     * Create a new JSON object.
     *
     * @param key    the key of the bird
     * @param name   the name of the bird
     * @param family the family of the bird
     * @return a new {@link JsonObject}
     */
    public static JsonObject asJson(int key, String name, String family) {
        return asJson(key, name, family, null);
    }

    /**
     * Create a new JSON object.
     *
     * @param key         the key of the bird
     * @param name        the name of the bird
     * @param family      the family of the bird
     * @param livesInTree the identifier of the tree the bird lives in, or null
     * @return a new {@link JsonObject}
     */
    public static JsonObject asJson(int key, String name, String family, @Nullable Integer livesInTree) {
        return new Bird(key, name, family, livesInTree).toJson();
    }

    /**
     * Parses {@link Bird} from a JSON object.
     *
     * @param object the {@link JsonObject} to parse
     * @return a new {@link Bird}
     */
    public static Bird fromJson(JsonObject object) {
        return object.mapTo(Bird.class);
    }

    /**
     * Initialize a new {@link Bird}.
     *
     * @param key    the key of the bird
     * @param name   the name of the bird
     * @param family the family of the bird
     */
    public Bird(int key, String name, String family) {
        this(key, name, family, null);
    }

    /**
     * Initialize a new {@link Bird}.
     *
     * @param key         the key of the bird
     * @param name        the name of the bird
     * @param family      the family of the bird
     * @param livesInTree the identifier of the tree the bird lives in, or null
     */
    public Bird(@JsonProperty("key") int key, @JsonProperty("name") String name,
            @JsonProperty("family") String family, @JsonProperty("livesInTree_ID") @Nullable Integer livesInTree) {
        this.key = key;
        this.name = name;
        this.family = family;
        this.livesInTree = livesInTree;
    }

    /**
     * Get the key of the bird.
     *
     * @return the key
     */
    public int getKey() {
        return key;
    }

    /**
     * Get the name of the bird.
     *
     * @return the name
     */

    public String getName() {
        return name;
    }

    /**
     * Get the family of the bird.
     *
     * @return the family
     */
    public String getFamily() {
        return family;
    }

    /**
     * Get the identifier of the tree the bird lives in.
     *
     * @return the identifier of the tree the bird lives in or null, if unknown
     */
    @JsonProperty("livesInTree_ID")
    public Integer getLivesInTree() {
        return livesInTree;
    }

    /**
     * Converts this bird to a JSON object representation.
     *
     * @return a new {@link JsonObject} representing the bird
     */
    public JsonObject toJson() {
        return JsonObject.mapFrom(this);
    }

    @Override
    public String toString() {
        return name + " (" + family + ")";
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        } else if (other == null) {
            return false;
        } else if (getClass() != other.getClass()) {
            return false;
        }

        Bird otherBird = (Bird) other;
        return Objects.equals(key, otherBird.key) && Objects.equals(name, otherBird.name)
                && Objects.equals(family, otherBird.family) && Objects.equals(livesInTree, otherBird.livesInTree);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key, name, family, livesInTree);
    }
}

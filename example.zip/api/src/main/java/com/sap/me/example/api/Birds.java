package com.sap.me.example.api;

import static com.sap.me.example.api.Constants.EXAMPLE_BIRDS_QUALIFIED_NAME;
import static io.neonbee.data.DataVerticle.requestData;

import java.util.AbstractList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import io.neonbee.data.DataContext;
import io.neonbee.data.DataRequest;
import io.neonbee.data.DataVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.eventbus.MessageCodec;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;

// POI 1: the Birds class is a class, that with a so called event-bus codec can be sent via the Vert.x event bus. The
// codec must get registered to the event-bus beforehand, this is being done in the BirdsDataVerticle itself
/**
 * A immutable {@link AbstractList} implementation for representing a list of {@link Bird}.
 *
 * A {@link Birds} list can be sent via the Vert.x {@link EventBus} using the {@link Birds#CODEC}.
 */
public class Birds extends AbstractList<Bird> {
    /**
     * A {@link MessageCodec} to send lists of {@link Bird} via the {@link EventBus}.
     */
    public static final MessageCodec<Birds, Birds> CODEC = new MessageCodec<>() {
        @Override
        public void encodeToWire(Buffer buffer, Birds birds) {
            Buffer encoded = birds.toJson().toBuffer();
            buffer.appendInt(encoded.length());
            buffer.appendBuffer(encoded);
        }

        @Override
        @SuppressWarnings({ "checkstyle:parameterassignment", "checkstyle:magicnumber" })
        public Birds decodeFromWire(int pos, Buffer buffer) {
            int length = buffer.getInt(pos);
            pos += 4; // NOPMD
            return fromJson(new JsonArray(buffer.slice(pos, pos + length)));
        }

        @Override
        public Birds transform(Birds birds) {
            return birds;
        }

        @Override
        public String name() {
            return Birds.class.getSimpleName() + "Codec";
        }

        @Override
        public byte systemCodecID() {
            return -1;
        }
    };

    private final List<Bird> birds;

    // POI 2: In the API library, we can define methods that others call, so instead of having everyone call
    // "DataVerticle.<Birds>requestData(...)" we offer them a little convenience method, so if they require the birds
    // they simply can call "Birds.requireBirds(...)" instead
    /**
     * Require a list of {@link Bird} from the birds example verticle.
     *
     * @param vertx   the {@link Vertx} instance to use
     * @param context the context of the request
     * @return a future to a list of {@link Bird}
     */
    public static Future<Birds> requireBirds(Vertx vertx, DataContext context) {
        return requestData(vertx, newBirdsRequest(), context);
    }

    /**
     * This a a convenience method to create a birds request. In case any other {@link DataVerticle} requires birds, the
     * following requireData call can be made:
     *
     * <pre>
     * {@code
     * public Future<Collection<DataRequest>> requireData(DataQuery query, DataContext context) {
     *     return succeededFuture(List.of(Birds.newBirdsRequest()));
     * }
     * }
     * </pre>
     *
     * @return a new data request to the birds verticle
     */
    public static DataRequest newBirdsRequest() {
        return new DataRequest(EXAMPLE_BIRDS_QUALIFIED_NAME);
    }

    /**
     * Parse a list of {@link Bird} from {@link JsonArray}.
     *
     * @param array the array to convert
     * @return the {@link Birds} list
     */
    public static Birds fromJson(JsonArray array) {
        return new Birds(array.stream().map(JsonObject.class::cast).map(Bird::fromJson).collect(Collectors.toList()));
    }

    /**
     * Create a new {@link Birds} list from a existing {@link Collection} of {@link Bird}.
     *
     * @param birds the {@link Collection} of {@link Bird}
     */
    public Birds(Collection<Bird> birds) {
        super();
        this.birds = List.copyOf(birds);
    }

    @Override
    public Bird get(int index) {
        return birds.get(index);
    }

    @Override
    public int size() {
        return birds.size();
    }

    /**
     * Convert the list to a {@link JsonArray}.
     *
     * @return the {@link JsonArray} of this list
     */
    public JsonArray toJson() {
        return new JsonArray(stream().map(Bird::toJson).collect(Collectors.toList()));
    }
}

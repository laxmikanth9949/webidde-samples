package com.sap.me.example.api;

import static io.neonbee.data.DataVerticle.createQualifiedName;

/**
 * Constants for the example API, e.g. to reach out to the verticles within the example components via their
 * full-qualified name. This is the public API, thus everyone is free to use any of the constants provided here.
 */
public final class Constants {
    /**
     * The service name of the example OData service.
     */
    public static final String EXAMPLE_ODATA_SERVICE = "example.Service";

    /**
     * The namespace of the example project.
     */
    public static final String EXAMPLE_NAMESPACE = "example";

    /**
     * The name of the birds verticle.
     */
    public static final String EXAMPLE_BIRDS_NAME = "Birds";

    /**
     * The qualified name of the birds verticle.
     */
    public static final String EXAMPLE_BIRDS_QUALIFIED_NAME =
            createQualifiedName(EXAMPLE_NAMESPACE, EXAMPLE_BIRDS_NAME);

    /**
     * The name of the forests verticle.
     */
    public static final String EXAMPLE_FORESTS_NAME = "Forests";

    /**
     * The qualified name of the forests verticle.
     */
    public static final String EXAMPLE_FORESTS_QUALIFIED_NAME =
            createQualifiedName(EXAMPLE_NAMESPACE, EXAMPLE_FORESTS_NAME);

    private Constants() {
        // cannot be initialized
    }
}

# SAP for Me Example Component

[![Build Status (dev)](https://forme.jaas-gcp.cloud.sap.corp/buildStatus/icon?job=components%2Fexample%2Fdev&subject=dev%20build)](https://forme.jaas-gcp.cloud.sap.corp/job/components/job/example/job/dev/) [![Build Status (main)](https://forme.jaas-gcp.cloud.sap.corp/buildStatus/icon?job=components%2Fexample%2Fmain&subject=main%20build)](https://forme.jaas-gcp.cloud.sap.corp/job/components/job/example/job/main/)

## [TL;DR](https://en.wikipedia.org/wiki/Wikipedia:Too_long;_didn%27t_read): I just want to get started!

Don't you worry, we got you covered! Install:

- A Java 11 JDK, we recommend [SapMachine](https://sap.github.io/SapMachine/).
- [Git](https://git-scm.com/downloads) (if your local installation doesn't already have a Git client).
- You are [free to choose any IDE](#which-ide-am-i-supposed-to-use)! We recommend [VSCode](https://code.visualstudio.com/).

  (Note that the only prerequisite is, that your IDE has basic support for Gradle)

Then go for the following to clone and run local frontend development:

```bash
git clone git@github.wdf.sap.corp:forme/example.git
cd example
./gradlew :dev
```

If you are out for backend development with full end-to-end connectivity, in addition install and get:

- The [`kubectl`](httphttps://kubernetes.io/docs/tasks/tools/) and [kubelogin](https://github.com/int128/kubelogin) to be able to sign in to development accounts.
- Use the [SMO Service Catalogue](https://sap.sharepoint.com/sites/125708/SitePages/Service-Catalogue.aspx) to:
  - Using `SMOSUSY004` request access / a development user to the `I7D` and `W7T`/`W7Q` ABAP on-prem. backend systems.
  - Using `SMOSUSY277` request access / developer rights to the SAP for Me BTP Kyma dev. and test spaces.
- Download the [`kubeconfig`](https://github.wdf.sap.corp/forme/deployment/blob/main/landscapes/dev/kubeconfig.yml) for the respective landscape (e.g. [`dev`](https://github.wdf.sap.corp/forme/deployment/blob/main/landscapes/dev/kubeconfig.yml) or [`test`](https://github.wdf.sap.corp/forme/deployment/blob/main/landscapes/test/kubeconfig.yml)). The general convention here is to use `~/.kube/kubeconfig.yml` as the location (e.g. `~/.kube/dev-kubeconfig.yml`).

To start end-to-end development, a local server and the frontend, go for:

```bash
# set the KUBECONFIG environment variable
export KUBECONFIG=~/.kube/dev-kubeconfig.yml # on Linux / Mac
$Env:KUBECONFIG="$HOME/.kube/dev-kubeconfig.yml" # on PowerShell
set KUBECONFIG=%USERPROFILE%/.kube/dev-kubeconfig.yml # on Windows Bash (remove this comment!)

./gradlew :e2e
```

Finally, if you decide to contribute:

- Request access to our [GitHub Organization](https://github.wdf.sap.corp/forme/) by dropping an email to [the architecture team](mailto:DL_5F3CE9744D3C29027E4EA7FF@global.corp.sap).
- Set up an SSH key in your GitHub account, as described [here](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent).
- Request the creation of a own component repository, as described [here](#request-the-creation-of-your-github-repositorys).
- Request the creation of a build Jenkins job, as described [here](#request-the-creation-of-component-build-jenkins-job).
- Request to add your component to deployment Jenkins job into DEV & TEST landscape, as described [here](#request-updating-deployment-pipeline-for-dev--test-landscape)


Easy as pie 🥧, wasn't it?

# Repository Documentation

## What is a component?

A component is a plug-in to our development platform for SAP for Me and allows you to develop on extensions to SAP for Me in an end-to-end fashion. The main idea being that you can develop frontend, as well as backend functionality within one repository structure, we call it the component repositories. This example repository acts as both a reference how to structure such a component repository and, as everything is held together by our Gradle build tooling, this repository will guide you through how to use the tooling we provide.

## What is part of a component?

A SAP for Me component may contain the following development artifacts:

- **API Library**: Your component may expose an API as a common Java library / JAR. This library component can be consumed by others, without having a compile time dependency or even a (local node) runtime dependency to their component. NeonBee will take care to connect the API with your verticles via the event-bus in a efficient manner-
- **Application(s)**: An (full-screen) application is a embeddable UI5 `sap.ui.core.UIComponent` that will be loaded by SAP for Me on-demand and displayed either full-screen or embedded into a dashboard. Applications can come with an own router and are fully transparent to SAP for Me.
- **(Card) Library(ies)**: Frontend (or previously only card) libraries come bundled with the core framework of SAP for Me and may contain our own variant of `sap.f.Card` called `sap.me.cards.Card` card and other frontend assets, such as dashboard headers or whole controller extensions for dashboards and applications. Cards can later on be used in the configuration of dashboards for SAP for Me or in the card catalog.
- **Module(s)**: Modules refer to NeonBee modules. NeonBee is an open-source data processing framework based on Vert.x we use as a foundation for our backend development. Modules may contain Java-based services in form of so called `DataVerticle`s or `EntityVerticle`s, but also other backend assets, such as facilitating libraries, hooks, etc.
- **Model(s)**: Models is what glues the frontend assets such as applications or cards and the backend together. Model definitions are done using CDS, as SAP-owned but open type definition language for models. Models describe the structure of your `EntityVerticle`s, as well as come with mock-data used for local frontend development.

Note how we always used the *plural* form describing the component parts. Meaning that a component may contain either combination of the above. Even not adding any of the above artifacts at all, or just developing a single-purpose component, say with one module only, is a viable option and fully supported by our build tooling. In order to add / remove either of the above pieces, just copy the existing folder to a new name in the root folder and add it to / remove it from the last line of the `settings.gradle` file.

## Which IDE am I supposed to use?

Any, literally. As our component structure fully relies on Gradle to be developed and build, you can choose any IDE. An IDE that has at last a basic form of Gradle / Java and JavaScript (preferably also NodeJS) support is recommended, but not required. It will make your life significantly easier though. Saying, sure you can use EMACs / notepad (depending on your OS) if you don't need syntax highlighting and a console, to send off all the Gradle commands, but an IDE will simply facilitate that and make it more accessible to you.

## Are there any development conventions?

No, your teams / components are self-organized. However, we do strongly recommend to follow the (very basic) development conventions that are also applied by our Gradle build tooling by default. E.g. we do provide an default .editorconfig, a pre-configured Eclipse formatter for Java, as well as a .eslintrc config for the front-end. Also (even though technically there is nothing blocking you), we strongly recommend to stay with Java, instead of going for any other Java byte-code compatible derivate, such as Kotlin or Skala. All our examples are and most help can be provided to you and your team in Java.

For the frontend / UI5 development, we recommend to give [the UI5 developer guidelines](https://github.com/SAP/openui5/blob/master/docs/guidelines.md) and the [UI5 documentation](https://sapui5untested.int.sap.eu2.hana.ondemand.com/sapui5-sdk-internal/#/topic/753b32617807462d9af483a437874b36) a good read. They provide an excellent set of guidelines to follow.

## What about naming conventions for packages?

Yes there are, because this is required for our continuous build & deployment process.Thus these rules will also be enforced by our Gradle build tooling. Your so called "component name" is the most important classifier to us. Meaning that it has to appear in:

- The package notation of your Java libraries: `com.sap.me.<component name>` (e.g. `com.sap.me.example.api.Constants`).
- The ID of your Java artifacts: `com.sap.me.comp:<component name>-<project name>` (e.g. `com.sap.me.comp:example-api`).
  
  One noteworthy exception to this rule, is for your main module artifact (so the one that is going to be deployed / imported to NeonBee). If it is named `module`, the actual ID of the artifact will take the root namespace: `com.sap.me.comp.<component name>` (e.g. `com.sap.me.comp:example`).
- The package name of your Node artifacts: `@forme/<component name>-<project name>` (e.g. `@forme/example-app`).
  
  Also here there is one noteworthy exception: Your main UI5 library, the one containing cards and other frontend assets, if named `library`, the name of the package may not be suffixed with the project name: `@forme/<component name>` (e.g. `sap.me.example`).
- The UI5 metadata name / namespace for libraries: `sap.me.libs.<component name>[library suffix]` (e.g. `sap.me.libs.example` or `sap.me.libs.exampleapi`). An optional library suffix must be chosen, in order for the library name to be unique. The suffix must only consist of lower case characters and numbers. No special characters, dashes, underscores or dots (sub-namespaces) allowed!

  Again the only exception to this rule is the project with name `library` it uses the root namespace `sap.me.<component name>` (e.g. `sap.me.example`).
- The UI5 metadata name / namespace for applications: `sap.me.apps.<component name>[app suffix]` (e.g. `sap.me.apps.example` or `sap.me.apps.example2`). Same naming conventions apply as for the UI5 metadata namespace for libraries.

Notice how your UI5 namespaces must *never* lie outside either `sap.me.<component name>`, `sap.me.libs.<component name>[library suffix]` or `sap.me.apps.[app suffix]`. Please stick to those rules, as otherwise we run into conflicts on deployment time.

## How to get started?

The only pre-requisite to get started is to have an up-to-date version of Java set-up on your local machine. We do recommend Java 11 in form of [SapMachine](https://sap.github.io/SapMachine/), an OpenJDK release maintained and supported by SAP. In case you are doing backend development, you might also want to install the [`kubectl`](httphttps://kubernetes.io/docs/tasks/tools/) and [kubelogin](https://github.com/int128/kubelogin). After that our build-tooling will take care of the rest! So lean-back and enjoy the following commands:

- `./gradlew `**`:dev`** - Starts a mocked local development environment for all frontend parts of your component. Use it to develop on applications and cards, without having to worry about any backend development yet.

- `./gradlew `**`:e2e`** - Starts an local end-to-end development set-up, so a fully-fledged backend with database connectivity tunneled to the Business Technology Platform (BTP) for establishing all the required backend connectivity. *Requires* logging on to Kyma / Kubernetes using the `kubectl` CLI first. Also depending on your network location, you might need to sign-in to the SAP network using BigIP / VPN. A connection via GlobalProtect might not be sufficient.

- `./gradlew `**`:build`** - Build all the frontend and backend assets into deployable archive artifacts and collects it into your root folders `/dist` directory.

From a development point of view we marked certain locations in the example code with a "POI" (point of interest) comment, that you maybe want to search for and check out yourself.

## How to debug?

Debugging is a simple as a piece of cake! If you launch the frontend with either `./gradlew :dev` or `./gradlew :e2e`, it starts without any minified code. Thus can can open your browsers inspect view (mostly accessible by pressing `F12`) and set a breakpoint in your UI5 / JavaScript code wherever you want to. _Tip:_ In order to set the breakpoint into your function / module, it is easiest to set a breakpoint using the "global search" which can be accessed using the _Ctrl + Shift + F_ shortcut and entering either you module name or any snippet of your code. Afterwards you can set a breakpoint and even reload the page and your breakpoints should stay in the code. _Note:_ As soon as you change your code, you will sometimes have to re-set your breakpoints.

In case you would like to debug your backend code / verticles the `./gradlew :e2e` is based on the [`JavaExec`](https://docs.gradle.org/current/dsl/org.gradle.api.tasks.JavaExec.html) task and thus supports the `--debug-jvm` switch. If you would like to debug your code, simply run your code using `./gradlew :e2e --debug-jvm` and use the remote debugging feature of your IDE, to attach to the debugger. Note, if you actually do not attach a debugger, launching the `:e2e` or `:run` task will actually halt the execution indefinitely. Another advantage to set the `--debug-jvm` flag, is that most IDEs meanwhile support the JVM hot-swap feature. Meaning that the IDE will automatically inject changed code to the running JVM and no restart will be required, when you change anything.

If you are using VSCode you can actually use the tasks and launch configurations provided, to start a debug session! Hit `Ctrl + Shift + P`, type "Run Tasks" and select any of the tasks, e.g. "Launch Frontend". In order to debug, use the pre-configured debug configurations, by starting either the "Debug Backend" or "Debug End-to-End" launch configuration in your "Run and Debug" tab, as described [here](https://code.visualstudio.com/docs/editor/debugging).

## Request the creation of your GitHub Repository(s)

**Trigger the creation of your component repository in the forme organization.**\
Request the creation of all repositories by sending an e-mail to the [SAP for Me Architecture Team Distribution List](mailto:DL_5F3CE9744D3C29027E4EA7FF@global.corp.sap), summarizing the following:
- Which repositories should be created (including the full name) and their visibility (`private`/`public`)

For each repository, specify which members should:
- have administrative rights - I/D/C user identifiers required.
- have write access - I/D/C user identifiers required.

Please **ensure that only one team member requests repository creation** for the team (ideally, the team lead or PO/PM).\
If the repository is created as public, all the other organization members will have read permissions by default. 

Here is a template that you can use as a quick start:
```text
Hello colleagues,

I am a part of team <Team_Name> and would like to request the creation of the following GitHub repositories that my team is responsible for:
  - my-awesome-sap-for-me-component (private/public)
    Administrators: D555666, C333444
    Committers: D555666, C333444, I111222, D555666, C333444, I111222
  - my-second-awesome-sap-for-me-component (public/private)
    Administrators: C333444, I111222
    Committers: D555666, C333444, I111222, D555666, C333444, I111222

Thank you for your support.

Kind regards,
<Name>
```

Once the repository is created, you will be notified and you can proceed to the next steps.

**Note:** It is likely that the following initial setup steps will require administrator privileges on the target repository.

**Initializing or moving your component repository to the forme organization.**\
If you are creating a new component use example component as template.

## Request the creation of Component Build Jenkins job
Request the creation of component build job by sending an e-mail to the [SAP for Me Architecture Team Distribution List](mailto:DL_5F3CE9744D3C29027E4EA7FF@global.corp.sap) and providing the link to your compponent repository.

## Request updating Deployment pipeline for DEV & TEST landscape
Request adding your component to deployment pipeline by sending an e-mail to the [SAP for Me Architecture Team Distribution List](mailto:DL_5F3CE9744D3C29027E4EA7FF@global.corp.sap) and providing the link to your compponent repository.
As well please indicate if your component will be included on existing cluster node (specific which one) or a seprate node will be created for it.

## Request the creation of your project in Checkmarx One

Please note that this a mandatory step if you have cloned the [forme/example](https://github.wdf.sap.corp/forme/example) repository or would like to create a new component.

Request the creation of your application by sending an e-mail to the [SAP for Me Architecture Team Distribution List](mailto:DL_5F3CE9744D3C29027E4EA7FF@global.corp.sap), summarizing the following:

Here is a template that you can use as a quick start:
```text
Hello colleagues,

I am a part of team <Team_Name> and I would like to request the creation of the following Checkmarx One project that my team is responsible for:
  - my-awesome-sap-for-me-component

Thank you for your support.

Kind regards,
<Name>
```

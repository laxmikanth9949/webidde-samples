sap.ui.define([
    "./library",
    "sap/m/library",
    "sap/ui/core/mvc/ControllerExtension",
    "sap/ui/core/mvc/OverrideExecution",
    "sap/m/HBox",
    "sap/m/Title",
    "sap/m/Button"
], function(library, mobileLibrary, ControllerExtension, OverrideExecution, HBox, Title, Button) {
    "use strict";

    // shortcut for sap.m.ButtonType
    var ButtonType = mobileLibrary.ButtonType;

    return ControllerExtension.extend("sap.me.example.ExampleExtension", {
        override: {
            onInit: function() {
                // this method will be called onInit of the dashboard controller / very early in the call stack
                // we can do all kinds of trickery here if we wish to do so!! =) (more will be added later!)

                this._oExampleBundle = sap.ui.getCore().getLibraryResourceBundle("sap.me.example");
            },

            // for instance let us override the "getGroupHeader" function and have OWN group headers in our dashboard!
            getGroupHeader: function(sId, oGroup) {
                if (oGroup.key === "example") {
                    return new HBox({
                        items: [
                            new Title({ text: this._oExampleBundle.getText("exampleGroupHeaderTitle")}),
                            new Button({
                                text: this._oExampleBundle.getText("exampleGroupHeaderButton"),
                                type: ButtonType.Transparent,
                                press: [this.handleGroupHeaderButtonPress, this]
                            })
                        ]
                    }).addStyleClass("sapMeDashboardGroupHeader sapMeExampleFancyGroupHeader");
                } else {
                    return new Title({ text: oGroup.title }).addStyleClass("sapMeDashboardGroupHeader");
                }
            }
        },

        handleGroupHeaderButtonPress: function(oEvent) {
            alert(this._oExampleBundle.getText("groovyAlert"));
        }
    });
});
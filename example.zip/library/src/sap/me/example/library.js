sap.ui.define([
    "sap/ui/Global",
    "sap/me/cards/library"
], function() {
    "use strict";

    // delegate further initialization of this library to the Core
    sap.ui.getCore().initLibrary({
        name: "sap.me.example",
        dependencies: ["sap.me.cards"],
        controls: [
            "sap.me.example.cards.ClockCard",
            "sap.me.example.cards.ExampleCard",
            "sap.me.example.cards.ExamplePaginationCard",
            "sap.me.example.cards.ExampleTableSortingCard",
            "sap.me.example.cards.ExampleOverflowToolbarCard"
        ],
        // in case your library comes without an own theming, remove the themes
        // folder and set this parameter to true, to stop looking for theme files
        noLibraryCSS: false
    });

    var thisLib = sap.me.example;

    return thisLib;
});

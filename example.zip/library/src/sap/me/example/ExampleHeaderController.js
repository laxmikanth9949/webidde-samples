sap.ui.define([
    "./library",
    "sap/ui/base/Object",
    "sap/ui/core/routing/Router",
    "sap/ui/model/resource/ResourceModel",
    "sap/me/shared/util/getShellComponent"
], function(library, BaseObject, Router, ResourceModel, getShellComponent) {
    "use strict";

    // the header controller does not actually need to be a fully fledged MVC controller! it is enough to be an
    // object that we can instantiate, e.g. inherited from UI5s sap.ui.base.Object prototype.
    return BaseObject.extend("sap.me.example.ExampleHeaderController", {
        constructor : function(oDashboardController) {
            BaseObject.apply(this);

            // when being constructed (at the time the header is loaded), you will get access to the dashboard controller!
            this._oDashboardController = oDashboardController;

            var oRootControl = getShellComponent().getRootControl();
            if (!oRootControl.getModel("i18nExample")) {
                oRootControl.setModel(new ResourceModel({
                    bundle: sap.ui.getCore().getLibraryResourceBundle("sap.me.example")
                }), "i18nExample");
            }
        },

        handleToHome: function(oEvent) {
            // in order to navigate, we can get access to the shell component and it's router via the getShellComponent function
            getShellComponent().getRouter().navTo("home");

            // alternatively you can access the shell router like so:
            Router.getRouter("shellRouter").navTo("home");
        }
    });
});
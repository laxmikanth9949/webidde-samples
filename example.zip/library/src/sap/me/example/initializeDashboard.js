sap.ui.define([
    "./library",
    "sap/me/shared/BackendException",
    "sap/me/shared/UnauthorizedException",
    "sap/me/shared/util/getShellComponent"
], function(library, BackendException, UnauthorizedException, getShellComponent) {
    "use strict";

    /**
     * This initialization module can be set in a dashboard / application definition and is loaded,
     * as soon as the dashboard / application definition is received for the first time. If multiple
     * dashboards have the same initialization module set, the module will only be loaded once. Thus
     * the coding of the module itself may only be executed once. In this case the module may return
     * any value, that will be ignored.
     *
     * Alternatively the module may return a function. This function will be called with the dashboard /
     * application definition, on every dashboard / application that is loaded. It can be used to run
     * any custom initialization logic. The function may change the provided definition at runtime, in
     * order to influence the dashboard / application. E.g. adding / removing / renaming sections
     * dynamically.
     *
     * Both the module itself, or the initialization function may return a promise. The dashboard /
     * application view will wait (either once if the module returns a promise, or for every loaded
     * dashboard / application) for the promise to resolve, before starting to load the content as it
     * the (changed) definition suggests.
     *
     * @function
     * @param {object} oDashboard The definition of the dashboard / application
     * @return {Promise<any>|any} A promise that resolves when the initialization is done
     * @private
     */
    return oDashboard => new Promise((fnResolve, fnReject) => {
        // this initialization function can be used to change the dashboard / application definition at runtime
        oDashboard.sections[0].title += ` (${Math.floor(Math.random() * 9) + 1})`;

        // in order to get access to functionalities from the shell, use:
        var oShellComponent = getShellComponent();
        if (oShellComponent) {
            // ...
        }

        // throw an error or fail the promise, in order to propagate an error to the user, the error object may
        // contain a title, message and image, that will be displayed to the user. alternatively you can throw a
        // sap/me/shared/ApplicationError exception, or use the oShellComponent.handleError(...) function
        if (false) {
            throw { title: sap.ui.getCore().getLibraryResourceBundle("sap.me.example").getText("messageDashboardLoadFail") };
        }

        // it can also be used, e.g. to perform asynchronous activities, like checking for authorizations or similar
        setTimeout(() => {
            // in case the user is not authorized to access the dashboard, you can use the throw a
            // sap/me/shared/UnauthorizedError, or again alternatively use oShellComponent.handleUnauthorized(...)
            // function, whilst again again providing title, message and image that is displayed to the user
            if (false) {
                fnReject(new UnauthorizedException({ title: sap.ui.getCore().getLibraryResourceBundle("sap.me.example").getText("messageDashboardUnauthorized") }));
                return;
            }

            // if you want to show a "not found" error, raise a BackendException with a 404 status, like so:
            // (you can again use the same attributes as above, to set a title, description or an image to display)
            if (false) {
                fnReject({ title: "¯\\_(ツ)_/¯", cause: new BackendException(404) });
                return;
            }

            // the promise should be resolved, to start loading the dashboard
            fnResolve();
        }, 2e3);
    });
});
sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "sap/me/cards/CardComposite",
    "sap/me/shared/Models",
    "sap/base/util/deepEqual"
], function(library, cardsLibrary, CardComposite, Models, deepEqual) {
    "use strict";

    // shortcut for sap.me.cards.CardState
    var CardState = cardsLibrary.CardState;

    var ExampleCard = CardComposite.extend("sap.me.example.cards.ExampleCard", {
        metadata: {
            library: "sap.me.example",
            properties: {
                text: { type: "string", defaultValue: "Default Text" }
            }
        }
    });

    ExampleCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);

        // this card uses an own OData model from the backend, use the shared Models class, in order to retrieve an instance
        // of the OData V4 model. this way, if anyone else tries to access the same model, the model is not created twice
        oCard.setModel(this._oODataModel = Models.getODataModel("example"), "$" + this.alias + ".odata");
    };

    ExampleCard.prototype.init = function() {
        CardComposite.prototype.init.apply(this, arguments);

        var oCard = this.getCard().setBusy(true);
        setTimeout(function() {
            oCard.setBusy(false);
        }, 500 + Math.random() * 3000);

        this._oExampleBundle = sap.ui.getCore().getLibraryResourceBundle("sap.me.example");
        // set text property of the card, it will be accessed via $this model in card xml control
        this.setText(this._oExampleBundle.getText("exampleCardBtnDefaultText"));

        // the Models class provides access to shared information, for instance flags to check for the landscape, or to access device,
        // user, customer data or the settings of a given namespace. device, flags, user and customer data can be accessed right away:
        Models.getUser().firstName; // also userName, lastName, etc.
        Models.getCustomer().companyid; // alternatively get access to the crmcustomernumber, or to the whole hierarchy of companyids
        Models.getFlags().isPublic; // also isInternal, isExperimental, etc.
        Models.getDevice().device.support.touch; // see sap/ui/Device

        // settings have to be loaded first by namespace and can be accessed after the promise completes or via the settings>/ model
        Models.loadSettings("EXAMPLE").then(oSettings => { // load all settings of the example namespace (needs to be created in admin tool)
            // after the promise completes, you can access the settings of that particular namespace via oSettings or via the settings API
            oSettings?.anySetting || Models.getSetting("EXAMPLE", "ANY_SETTING") || Models.getSetting("/example/anySetting");
        });
    };

    ExampleCard.prototype.setContext = function(oContext) {
        var oOldContext = this.getContext();
        if (deepEqual(oContext, oOldContext)) {
            return this;
        }

        CardComposite.prototype.setContext.call(this, oContext, false /* no invalidate, let others do it if needed */);

        var oCard = this.getCard();

        // access the translation file by getting the libraries bundle
        var oBundle = sap.ui.getCore().getLibraryResourceBundle("sap.me.cards");

        // to check for a single authorization either use the context attribute ...
        if (!oContext.authorization.check("GOSAP", "DEBITOR", "0001208936")) {
            // set the unauthorizedMessage first, incl. the authorization to request
            oCard.setUnauthorizedMessage(oBundle.getText("unauthorizedMessage", oBundle.getText("authorizationREADM")));
            oCard.transitionToState(CardState.Unauthorized);
        }

        // ... or use the convenience method of card, also to check for multiple authorizations (any of the authorizations must apply,
        // in case you'd like to check for multiple authorizations which have to be all present, use boolean "true" as a second argument)
        // this method gets varargs passed as arrays, in case the notation is ["OBJECT"] only a "exists" check will be performed,
        // otherwise the array will be used as arguments for the check method e.g. ["OBJECT", "GLOBAL"] will check for the global
        // authorization being set, ["OBJECT", "FIELD", "VALUE"] will check for the value of a authorization object. Any number of
        // arguments might be passed!
        if (!oCard.authorizationCheck(oContext.authorization, /*true, */["READM"], ["ANLEG", "INSTALL", "0020659001"])) {
            // ... do something here if required (e.g. not finish initialization, or return to not load any data)
        }

        // also add further initialization, such as setting the context OData model to the card (if required)
        // oCard.setModel(oContext.model, "$" + this.alias + ".odata");

        return this;
    };

    return ExampleCard;
});
sap.ui.define(["require", "exports"], function(require, exports) {
    "use strict";

    exports["default"] = class extends HTMLElement {
        constructor() {
            super();
            const template = document.createElement("template");

            template.innerHTML = `
            <section>
              <p>Hello World from Luigi!</p>
            </section>
          `;
            this._shadowRoot = this.attachShadow({ mode: "open", delegatesFocus: false });
            this._shadowRoot.appendChild(template.content.cloneNode(true));
            this.$paragraph = this._shadowRoot.querySelector("p");
        }

        set context(ctx) {
            if (ctx.title)
                this.$paragraph.innerHTML = ctx.title;
        }
    };

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
});
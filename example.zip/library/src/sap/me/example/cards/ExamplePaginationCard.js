sap.ui.define([
    "../library",
    "sap/me/cards/library",
    "sap/me/cards/CardComposite",
    "sap/me/shared/Models",
    "sap/base/util/deepEqual"
], function(library, cardsLibrary, CardComposite, Models, deepEqual) {
    "use strict";

    // shortcut for sap.me.cards.CardState
    var CardState = cardsLibrary.CardState;

    var ExamplePaginationCard = CardComposite.extend("sap.me.example.cards.ExamplePaginationCard", {
        metadata: {
            library: "sap.me.example",
            properties: {
                text: { type: "string", defaultValue: "Default Text" }
            }
        }
    });

    ExamplePaginationCard.prototype._setCompositeAggregation = function(oCard) {
        CardComposite.prototype._setCompositeAggregation.apply(this, arguments);

        // this card uses an own OData model from the backend, use the shared Models class, in order to retrieve an instance
        // of the OData V4 model. this way, if anyone else tries to access the same model, the model is not created twice
        oCard.setModel(this._oODataModel = Models.getODataModel("example"), "$" + this.alias + ".odata");
    };


    return ExamplePaginationCard;
});
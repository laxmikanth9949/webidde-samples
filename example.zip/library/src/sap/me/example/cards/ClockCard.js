sap.ui.define([
    "../library",
    "jquery.sap.global",
    "sap/me/cards/CardComposite",
    "sap/ui/core/Fragment",
    "sap/ui/Device"
], function(library, jQuery, CardComposite, Fragment, Device) {
    "use strict";

    var ClockCard = CardComposite.extend("sap.me.example.cards.ClockCard", {
        metadata: {
            library: "sap.me.example",
            properties: {
                pocketSize: { type: "boolean", defaultValue: false },

                timeZone: { type: "string", defaultValue: null }
            }
        }
    });

    ClockCard.prototype.onAfterRendering = function() {
        this._tick(); this._vTickInterval = setInterval(this._tick.bind(this), 1e3 / 4);
        jQuery(`#${ Fragment.createId(this.getId(), "clock") }`)
            .toggleClass("sapMePocketClock", this.getPocketSize());
    };
    ClockCard.prototype.onBeforeRendering = function() {
        if (this._vTickInterval) {
            clearInterval(this._vTickInterval);
            delete this._vTickInterval;
        }
    };

    ClockCard.prototype.setPocketSize = function(bPocketSize) {
        this.setProperty("pocketSize", bPocketSize, /*bSuppressInvalidate=*/true);
        this.setPreferredWidth(bPocketSize ? "14rem" : "28rem");
    };

    ClockCard.prototype._tick = function() {
        // as we perform transpiling using Babel you are fine using ES6+ syntax sugar like const declarations, arrow function() =>, the optional chaining operator ?. or text templates like `${ ... }`
        // (note: please DO NOT use any ES6+ classes / functions that are NOT contained in the @forme/shell polyfill.js file! also watch out for things that cannot be transpiled without a runtime! these things will break, even in modern browsers!)
        const oDate = this._getDate(), iHours = (oDate.getHours() + 11) % 12 + 1, iMinutes = oDate.getMinutes(), iSeconds = oDate.getSeconds();
        jQuery(`#${ Fragment.createId(this.getId(), "hour") }`)?.
            css("transform", `rotate(${ iHours * 30 + iMinutes / 2 + iSeconds / 120 }deg)`);
        jQuery(`#${ Fragment.createId(this.getId(), "minute") }`)?.
            css("transform", `rotate(${ iMinutes * 6 + iSeconds / 10 }deg)`);
        jQuery(`#${ Fragment.createId(this.getId(), "second") }`)?.
            css("transform", `rotate(${ iSeconds * 6 }deg)`);
    };
    ClockCard.prototype._getDate = function() {
        const sTimeZone = this.getTimeZone(), oDate = new Date();
        return sTimeZone && new Date(oDate.toLocaleString("en-US", { timeZone: sTimeZone })) || oDate;
    };

    ClockCard.prototype._handlePress = function(oEvent) {
        jQuery.get("https://api.thecatapi.com/v1/images/search", {
            "api_key": "f6c5f04f-7fdb-440d-8dac-16b788996b71", "mime_types": "jpg,png"
        }).then(aResult => {
            jQuery(`#${ Fragment.createId(this.getId(), "clock") }`)?.
                css("background-image", `linear-gradient(rgba(255, 255, 255, .7) 100%, rgba(255, 255, 255, .7) 100%), url(${ aResult[0].url })`);
        });
    };

    ClockCard.prototype.onsapenter = ClockCard.prototype._handlePress;
    if (Device.support.touch) {
        ClockCard.prototype.ontap = ClockCard.prototype._handlePress;
    } else {
        ClockCard.prototype.onclick = ClockCard.prototype._handlePress;
    }

    return ClockCard;
});
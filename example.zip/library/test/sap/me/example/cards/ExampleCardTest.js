sap.ui.define([
    "sap/me/example/cards/ExampleCard"
], function(ExampleCard) {
    "use strict";

    QUnit.moduleDone = function() { };

    QUnit.module("ExampleCard", {
        beforeEach: function() {
            this.oExampleCard = new ExampleCard();
        }
    });

    QUnit.test("Test ExampleCard", function(assert) {
        // TODO
    });
});
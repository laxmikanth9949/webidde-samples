sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("ZSPagenation.ZSPagenation.controller.View1", {
		onInit: function () {
			var that = this;

			//Stores products data and indexes data
			var oProductsModel = new JSONModel({
				productsData: [],
				isProductsDataLoading: true,
				tableData: [],
				startIndex: 0,
				endIndex: 0,
				noOfTableRows: 5,
				page: 0,
				totalPages: 0
			});
			that.getView().setModel(oProductsModel, "ProductsModel");

			//Stores Nav buttons enable properties
			var oNavModel = new JSONModel({
				firstPageBtnEnable: false,
				nextPageBtnEnable: false
			});
			that.getView().setModel(oNavModel, "NavModel");

			var oModel = that.getOwnerComponent().getModel("NorthwindModel");
			oModel.read("/Products", {
				success: function (oData) {
					//Stores the Produsts data
					that.getView().getModel("ProductsModel").setProperty("/productsData", oData.results);
					that.getView().getModel("ProductsModel").setProperty("/isProductsDataLoading", false);
					//Sets total page count
					var noOfTableRows = parseInt(that.getView().getModel("ProductsModel").getProperty("/noOfTableRows"));
					that.getView().getModel("ProductsModel").setProperty("/totalPages", Math.ceil(oData.results.length / noOfTableRows));
					//To get data for first view
					that.onFirstPress();
				},
				error: function (oError) {
					that.getView().getModel("ProductsModel").setProperty("/isProductsDataLoading", false);
				}
			});

		},

		//set first selected number of visible rows to table
		onFirstPress: function () {
			var that = this;
			var data = that.getView().getModel("ProductsModel").getProperty("/productsData");
			var noOfTableRows = parseInt(that.getView().getModel("ProductsModel").getProperty("/noOfTableRows"));
			var newData = data.slice(0, noOfTableRows);

			//To set Table Data
			that.fnSetTableData(newData, 0, noOfTableRows - 1, 1);
		},

		//set previous selected number of visible rows to table
		onPreviousPress: function () {
			var that = this;
			var data = that.getView().getModel("ProductsModel").getProperty("/productsData");
			var noOfTableRows = parseInt(that.getView().getModel("ProductsModel").getProperty("/noOfTableRows"));
			var startIndex = that.getView().getModel("ProductsModel").getProperty("/startIndex");
			var newData = data.slice(startIndex - noOfTableRows, startIndex);

			//To set Table Data
			that.fnSetTableData(newData, startIndex - noOfTableRows, startIndex - 1, that.getView().getModel("ProductsModel").getProperty(
				"/page") - 1);

		},

		//set next selected number of visible rows to table
		onNextPress: function () {
			var that = this;
			var data = that.getView().getModel("ProductsModel").getProperty("/productsData");
			var noOfTableRows = parseInt(that.getView().getModel("ProductsModel").getProperty("/noOfTableRows"));
			var endIndex = that.getView().getModel("ProductsModel").getProperty("/endIndex");
			var newData = data.slice(endIndex + 1, endIndex + 1 + noOfTableRows);

			//To set Table Data
			that.fnSetTableData(newData, endIndex + 1, endIndex + noOfTableRows, that.getView().getModel("ProductsModel").getProperty("/page") +
				1);
		},

		//set last selected number of visible rows to table
		onLastPress: function () {
			var that = this;
			var data = that.getView().getModel("ProductsModel").getProperty("/productsData");
			var noOfTableRows = parseInt(that.getView().getModel("ProductsModel").getProperty("/noOfTableRows"));
			var startIndex;
			var oIndex = data.length % noOfTableRows;
			if (oIndex === 0) {
				startIndex = data.length - noOfTableRows;
			} else {
				startIndex = data.length - oIndex;
			}
			var newData = data.slice(startIndex);

			//To set Table Data
			that.fnSetTableData(newData, startIndex, data.length, Math.ceil(data.length / noOfTableRows));
		},

		//Sets the table data
		fnSetTableData: function (newData, startIndex, endIndex, page) {
			var that = this;
			that.getView().getModel("ProductsModel").setProperty("/tableData", newData);
			that.getView().getModel("ProductsModel").setProperty("/startIndex", startIndex);
			that.getView().getModel("ProductsModel").setProperty("/endIndex", endIndex);
			//Sets Current page count
			that.getView().getModel("ProductsModel").setProperty("/page", page);
			//To Enable the nav bottons
			that.fnNavButtonsEnable();
		},

		//sets navigations buttons enable
		fnNavButtonsEnable: function () {
			var that = this;
			var data = that.getView().getModel("ProductsModel").getProperty("/productsData");
			var startIndex = that.getView().getModel("ProductsModel").getProperty("/startIndex");
			var endIndex = that.getView().getModel("ProductsModel").getProperty("/endIndex");

			//Enable or disable next and last buttons
			if (data.length > endIndex + 1) {
				that.getView().getModel("NavModel").setProperty("/nextPageBtnEnable", true);
			} else {
				that.getView().getModel("NavModel").setProperty("/nextPageBtnEnable", false);
			}

			//Enable or disable first and previous buttons
			if (startIndex === 0) {
				that.getView().getModel("NavModel").setProperty("/firstPageBtnEnable", false);
			} else {
				that.getView().getModel("NavModel").setProperty("/firstPageBtnEnable", true);
			}
		}
	});
});
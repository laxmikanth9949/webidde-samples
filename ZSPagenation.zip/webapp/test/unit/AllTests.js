sap.ui.define([
	"ZSPagenation/ZSPagenation/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
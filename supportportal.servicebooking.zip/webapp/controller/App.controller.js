sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.support.servicebooking.controller.App", {
		onInit: function () {

		},
		geti18nModel: function() {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		}
	});
});
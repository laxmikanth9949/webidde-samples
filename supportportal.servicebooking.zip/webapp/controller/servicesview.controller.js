sap.ui.define([
	"sap/support/servicebooking/controller/BaseController",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog",
	"sap/ui/model/odata/v2/ODataModel",
	'sap/m/MessageToast',
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter"
], function (BaseController, Fragment, JSONModel, ValueHelpDialog, ODataModel, MessageToast, Sorter, Filter) {
	"use strict";

	return BaseController.extend("sap.support.servicebooking.controller.servicesview", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf sap.support.ServiceBooking.view.createservicebooking
		 */
		onInit: function () {
			//checking the usertype if S user dropdown will show otherwise not enabled
			// var userType = this.getUserType();
			// if(userType === 'S'){
			// 	this.getView().byId("idSolution").setEnabled(true);
			// 	this.getView().byId("idSubSolution").setEnabled(true);
			// }else{
			// 	this.getView().byId("idSolution").setEnabled(false);
			// 	this.getView().byId("idSubSolution").setEnabled(false);
			// }
			this.oRouter = this.getOwnerComponent().getRouter();
			this.solutionModel = this.getOwnerComponent().getModel("solutionModel");
			this.getView().byId("idSolution").setModel(this.solutionModel);
			this.getView().byId("idSubSolution").setModel(this.solutionModel);
			//	this.getView().byId("idTablecreateSB").setModel(this.solutionModel);
			this.oEventBus = this.getOwnerComponent().getRouter();
			this.oEventBus.getRoute("servicesview").attachPatternMatched(this.oRoutePatternMatched, this);

		},
		oRoutePatternMatched: function (oEvent) {
			debugger;
		//	this.onClear();
		},
		onNavBackToHome: function (oEvent) {
			this.oRouter.navTo("home");
		},
		onResetFilterBar: function (oEvent) {
			debugger;
		},
		onSolutionChange: function (oEvent) {
			debugger;
			var oselectedKey = oEvent.getSource().getSelectedKey();
			var oModelData = this.getOwnerComponent().getModel("solutionModel");
			var newJsonData = new JSONModel();
			if (oselectedKey === "Human Capital Management") {
				var resultsModel = newJsonData.setData({
					"solutionresults": oModelData.getData().HumanCapitalManagement
				});
				this.getView().byId("idSubSolution").setModel(newJsonData);
			} else if (oselectedKey === "Solution A") {
				var resultsModel = newJsonData.setData({
					"solutionresults": oModelData.getData().SolutionA
				});
				this.getView().byId("idSubSolution").setModel(newJsonData);
			} else if (oselectedKey === "Solution B") {
				var resultsModel = newJsonData.setData({
					"solutionresults": oModelData.getData().SolutionB
				});
				this.getView().byId("idSubSolution").setModel(newJsonData);
			} else if (oselectedKey === "Solution C") {
				var resultsModel = newJsonData.setData({
					"solutionresults": oModelData.getData().SolutionC
				});
				this.getView().byId("idSubSolution").setModel(newJsonData);
			} else if (oselectedKey === "Solution D") {
				var resultsModel = newJsonData.setData({
					"solutionresults": oModelData.getData().subsolution
				});
				this.getView().byId("idSubSolution").setModel(newJsonData);
			} else if (oselectedKey === "Solution E") {

			}
		},
		onSubSolutionChange: function (oEvent) {
			debugger;
			var oselectedSolutionkey = this.getView().byId("idSolution").getSelectedItem().getKey();
			var oselectedsubSolutionkeys = oEvent.getSource().getSelectedKey();
			var oTable = this.getView().byId("idTablecreateSB");
			//	this.getView().byId("idTablecreateSB").setModel(this.solutionModel);
			oTable.setModel(this.solutionModel);
		//	this.getView().byId("idCreateNewSB").setEnabled(true);

		},
		onClear: function (oEvent) {
			debugger;
			this.getView().byId("idSolution").setSelectedKey("");
			this.getView().byId("idSubSolution").setSelectedItems([]);
			this.getView().byId("idSubSolution").getBinding("items").getModel().setData([]);
			this.getView().byId("idSubSolution").getBinding("items").getModel().refresh(true);

			// this.getView().byId("idTablecreateSB").getBinding("items").getModel().setData([]);
			// this.getView().byId("idTablecreateSB").getBinding("items").getModel().refresh(true);

			// this.getView().byId("idSolution").setModel(this.solutionModel);
			// this.getView().byId("idSolution").getModel().refresh(true);
			// this.getView().byId("idSolution").updateBindings(true);
		},
		onCreateSB: function (oEvent) {
			var selectedPath = this.getView().byId("idTablecreateSB").getSelectedContextPaths()[0];
		//	var selectedPath = oEvent.getSource().getBindingContextPath();
			var selectedSB = this.getView().byId("idTablecreateSB").getModel('solutionModel').getProperty(selectedPath);
			this.oRouter.navTo("servicebookingcreation", {
				"serviceID": selectedSB.id,
				"mode": "create"
			});
		},
		onupdateFinishedSBTable: function (oEvent) {
			debugger;
			var tableCount = this.getView().byId("idTablecreateSB").getBinding('items').getCount();
				this.getView().byId("idAvaialableServices").setText(tableCount);
		},
		onSelectTableSB: function (oEvent) {
			debugger;
			this.getView().byId("idCreateNewSB").setEnabled(true);
		},
		onServiceItempress: function (oEvent) {
			debugger;
			this.oEvent = oEvent;
			var oButton = oEvent.getSource();
			var oView = this.getView();
			this.oSelectedItem = this.getView().byId("idTablecreateSB").getModel('solutionModel').getProperty(oEvent.getSource().getBindingContextPath());

			var aArray = [];
			aArray.push(this.oSelectedItem);
			var oJson = new JSONModel();
			oJson.setData({
				SelectedData: {
					finalSelectData: []
				}
			});
			this.getView().setModel(oJson, "selectdData");
			this.getView().getModel("selectdData").setProperty("/SelectedData/finalSelectData", aArray);
			if (!this.oCreateSbBookingDialog) {
				this.oCreateSbBookingDialog = Fragment.load({
					name: "sap.support.servicebooking.fragments.servicedetails",
					id: this.getView().getId(),
					controller: this
				}).then(function (oDialog) {
					this.oDialog = oDialog;
					this.oDialog.setModel(this.getView().getModel("selectdData"));
					this.getView().addDependent(this.oDialog);
					this.oDialog.open();
				}.bind(this));
			} else {
				this.oDialog.setModel(this.getView().getModel("selectdData"));
				this.oDialog.open();
			}
		},
		onDialogClose: function (oEvent) {
			this.oDialog.close();
		},
		handleLoadItems: function (oEvent) {
			debugger;
			oEvent.getSource().getBinding('items').resume();
		},
		onSortTableServices: function(oEvent){
			debugger;
			if(!this.oSortServices){
				this.oSortServices = sap.ui.xmlfragment("sap.support.servicebooking.fragments.sortservicedetails", this);
				this.getView().addDependent(this.oSortServices);
			}
			this.oSortServices.open();
		},
		handleSortDialogConfirm: function(oEvent){
			debugger;
			var oTable = this.byId("idTablecreateSB"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf sap.support.ServiceBooking.view.createservicebooking
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf sap.support.ServiceBooking.view.createservicebooking
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf sap.support.ServiceBooking.view.createservicebooking
		 */
		//	onExit: function() {
		//
		//	}

	});

});
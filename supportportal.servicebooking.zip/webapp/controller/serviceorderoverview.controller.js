sap.ui.define([
"sap/support/servicebooking/controller/BaseController",
"sap/ui/model/Sorter",
"sap/ui/model/Filter"
], function (BaseController, Sorter, Filter) {
	"use strict";

	return BaseController.extend("sap.support.servicebooking.controller.serviceorderoverview", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf sap.support.servicebooking.view.serviceorderoverview
		 */
		onInit: function () {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.solutionModel = this.getOwnerComponent().getModel("solutionModel");
			
			this.getView().byId("idsoTable").setModel(this.solutionModel);
		//	this.oEventBus = this.getOwnerComponent().getRouter();
			this.oRouter.getRoute("serviceorderoverview").attachPatternMatched(this.oRoutePatternMatched());

		},
		oRoutePatternMatched: function (oEvent) {
			debugger;
		},
		pressonTableSort: function(oEvent){
			debugger;
			if(!this.oSortServices){
				this.oSortServices = sap.ui.xmlfragment("sap.support.servicebooking.fragments.sortservicedetails", this);
				this.getView().addDependent(this.oSortServices);
			}
			this.oSortServices.open();
		},
		handleSortDialogConfirm: function(oEvent){
			debugger;
			var oTable = this.byId("idsoTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},
		DateTableSort:function(oEvent){
			debugger;
				var event = oEvent.getSource();
				var oTable = this.byId("idsoTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];
				
				if(event.getText() === "Delivery Date"){
					sPath = "deldate";
					if(oTable.getBinding('items').aSorters[0].bDescending){
						bDescending = false;
					//	event.setIconFirst(true);
					}else{
						bDescending = true;
					}
				}else if(event.getText() === "Go-Live-Date"){
					sPath = "golive"
					if(oTable.getBinding('items').aSorters[0].bDescending){
						bDescending = false;
					//	event.setIconFirst(true);
					}else{
						bDescending = true;
					}
				}

		//	sPath = mParams.sortItem.getKey();
		//	bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
		

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
			
		},
		pressonTableFilter: function(oEvent){
			if(!this.oSortServices){
				this.oSortServices = sap.ui.xmlfragment("sap.support.servicebooking.fragments.SoFilterDialog", this);
				this.getView().addDependent(this.oSortServices);
			}
			this.oSortServices.open();
		},
		onUpdateFinishedTable: function(oEvent){
			var tableCount = this.getView().byId("idsoTable").getBinding('items').getCount();
				this.getView().byId("idServicesList").setText("("+tableCount+")");
		},
		onCreateServiceBooking: function(oEvent){
			this.oRouter.navTo("servicesview");
		},
		onEditServiceOrder: function(oEvent){
			this.oRouter.navTo("servicebookingcreation",{
				"serviceID":"0",
				"mode":"edit"
			});
		},
		onDisplayServiceOrder: function(oEvent){
			this.oRouter.navTo("servicebookingcreation",{
				"serviceID":"0",
				"mode":"display"
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf sap.support.servicebooking.view.serviceorderoverview
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf sap.support.servicebooking.view.serviceorderoverview
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf sap.support.servicebooking.view.serviceorderoverview
		 */
		//	onExit: function() {
		//
		//	}

	});

});
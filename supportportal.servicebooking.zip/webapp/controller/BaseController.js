/*global history */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog",
	"sap/ui/core/routing/History",
	'sap/m/MessageToast'
], function (Controller, JSONModel, ODataModel, ValueHelpDialog, History, MessageToast) {
	"use strict";

	return Controller.extend("sap.support.servicebooking.controller.BaseController", {
		_globalPointer: "",
		_NewProcessor: "",
		_NewProcessorName: "",

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		_getRemoteRoot: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			var root = oComp.sConfig.requestRemote;
			return root;
		},

		getModel: function (sName) {
			return this.getOwnerComponent().getModel(sName);
		},
		setModel: function (oModel, sName) {
			return this.getOwnerComponent().setModel(oModel, sName);
		},

		getOData: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.oData;
		},
		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getUser: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.User;
		},

		getUserType: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.UserType;
		},

		getSubstitute: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.Substitute;
		},

		onNavBack: function () {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("master", {}, true);
			}
		},

	});

});
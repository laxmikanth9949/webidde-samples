sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("sap.support.servicebooking.controller.servicebookingcreation", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf sap.support.servicebooking.view.servicebookingcreation
		 */
		onInit: function () {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oEventBus = this.getOwnerComponent().getRouter();
			this.oEventBus.getRoute("servicebookingcreation").attachPatternMatched(this.oRoutePatternMatched, this);

		},
		oRoutePatternMatched: function (oEvent) {
			debugger;
			 this.mode = oEvent.getParameter('arguments').mode;
			if(this.mode === "create"){
				this.onEditSB(oEvent);
			}else if(this.mode === "edit"){
				this.onEditSB(oEvent)            
			}else{
				this.onSaveSB(oEvent);
			}
			/*this.getView().byId("idEditSO").setVisible(false);
			this.getView().byId("idCancelSO").setVisible(false);
			this.getView().byId("idCloseSO").setVisible(false);
			this.getView().byId("idSaveSO").setVisible(true);
			this.getView().byId("idCancel").setVisible(true);
			this.getView().byId("idDisplayServiceOrderPageTitle").setObjectTitle("Create Service Order");
			
			this.getView().byId("idAdditionalTenant").setEditable(true);
			this.getView().byId("idSolutioninScope").setEditable(true);
			this.getView().byId("idMainTenant").setEditable(true);
			this.getView().byId("idRDD").setEditable(true);
			this.getView().byId("idGLD").setEditable(true);
			this.getView().byId("idContactPerson").setEditable(true);*/
		},
		onBackToServiceDetailPage: function(oEvent){
		//	this.oRouter.navTo("servicesview");
				MessageBox.show("Are you sure you want to go back Services page\n\n You may lose unsaved data. Do you want to proceed?",{
				title:"information",
				icon: MessageBox.Icon.WARNING,
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				initialFocus: MessageBox.Action.CANCEL,
				onClose: function(sActions){
					if(sActions === "OK"){
						this.oRouter.navTo("serviceorderoverview");
					}else{
						return;
					}
				}.bind(this)
			});
		},
		onNavBackToHome: function(oEvent){
			MessageBox.show("Are you sure you want to go back Home page",{
				title:"information",
				icon: MessageBox.Icon.WARNING,
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				initialFocus: MessageBox.Action.CANCEL,
				onClose: function(sActions){
					if(sActions === "OK"){
						this.oRouter.navTo("home");
					}else{
						return;
					}
				}.bind(this)
			});
			
		},
		onSaveSB: function(oEvent){
			MessageBox.success("The Service Order was successfully changed ");
				//Edit mode disabled
			this.getView().byId("idAdditionalTenant").setEditable(false);
			this.getView().byId("idSolutioninScope").setEditable(false);
			this.getView().byId("idMainTenant").setEditable(false);
			this.getView().byId("idRDD").setEditable(false);
			this.getView().byId("idGLD").setEditable(false);
			this.getView().byId("idContactPerson").setEditable(false);
			this.getView().byId("idDisplayServiceOrderPageTitle").setObjectTitle("Display Service Order");
			this.getView().byId("idEditSO").setVisible(true);
			this.getView().byId("idCancelSO").setVisible(true);
			this.getView().byId("idCloseSO").setVisible(true);
			this.getView().byId("idSaveSO").setVisible(false);
			this.getView().byId("idCancel").setVisible(false);
		},
		onEditSB: function(oEvent){
			
			if(this.mode === "create"){
			this.getView().byId("idDisplayServiceOrderPageTitle").setObjectTitle("Create Service Order");
			}else if(this.mode === "edit"){
			this.getView().byId("idDisplayServiceOrderPageTitle").setObjectTitle("Edit Service Order");
			}
			else{
			this.getView().byId("idDisplayServiceOrderPageTitle").setObjectTitle("Display Service Order");
			}
			this.getView().byId("idEditSO").setVisible(false);
			this.getView().byId("idCancelSO").setVisible(false);
			this.getView().byId("idCloseSO").setVisible(false);
			this.getView().byId("idSaveSO").setVisible(true);
			this.getView().byId("idCancel").setVisible(true);
			this.getView().byId("idAdditionalTenant").setEditable(true);
			this.getView().byId("idSolutioninScope").setEditable(true);
			this.getView().byId("idMainTenant").setEditable(true);
			this.getView().byId("idRDD").setEditable(true);
			this.getView().byId("idGLD").setEditable(true);
			this.getView().byId("idContactPerson").setEditable(true);
			
			
		},
		onCancel: function(oEvent){
			MessageBox.show("Do you want to cancel the Service Order",{
				title:"information",
				icon: MessageBox.Icon.WARNING,
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				initialFocus: MessageBox.Action.CANCEL,
				onClose: function(sActions){
					if(sActions === "OK"){
					//	this.oRouter.navTo("home");
					this.getView().byId("idEditSO").setVisible(true);
					this.getView().byId("idCancelSO").setVisible(true);
					this.getView().byId("idCloseSO").setVisible(true);
					this.getView().byId("idSaveSO").setVisible(false);
					this.getView().byId("idCancel").setVisible(false);
					this.getView().byId("idDisplayServiceOrderPageTitle").setObjectTitle("Display Service Order");
					
					//Edit mode disabled
			this.getView().byId("idAdditionalTenant").setEditable(false);
			this.getView().byId("idSolutioninScope").setEditable(false);
			this.getView().byId("idMainTenant").setEditable(false);
			this.getView().byId("idRDD").setEditable(false);
			this.getView().byId("idGLD").setEditable(false);
			this.getView().byId("idContactPerson").setEditable(false);
					
					}else{
						return;
					}
				}.bind(this)
			});
				
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf sap.support.servicebooking.view.servicebookingcreation
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf sap.support.servicebooking.view.servicebookingcreation
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf sap.support.servicebooking.view.servicebookingcreation
		 */
		//	onExit: function() {
		//
		//	}

	});

});
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/support/servicebooking/model/models",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
], function (UIComponent, Device, models, JSONModel, ODataModel, MessageBox) {
	"use strict";

	return UIComponent.extend("sap.support.servicebooking.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			var oConfig = this.getMetadata().getConfig();
			this.sConfig = oConfig;
			var oModel_userdata = new JSONModel();
			oModel_userdata.loadData(oConfig.requestRemote + "UserDataSet('ME')", {}, false, "GET");
			if (oModel_userdata.getData().d) {
				this.UserType = oModel_userdata.getData().d.UserID.substring(0, 1);
				this.User = oModel_userdata.getData().d.UserID;
				this.Substitute = oModel_userdata.getData().d.SUBSTITUTE;
				this.setModel(oModel_userdata, "Model_userdata");
				/*if (this.UserType === "S") {
					this.User = oModel_userdata.getData().d.UserID;
					this.Substitute = oModel_userdata.getData().d.SUBSTITUTE;
					this.setModel(oModel_userdata, "Model_userdata");

				} else {
					MessageBox.show("You Do not have access for this App, User Type is " + this.UserType + ". " +
						"\n Can you please get the S user access for accessing Service Booking App", {
							icon: sap.m.MessageBox.Icon.WARNING,
							title: "Authorization issue",
							actions: [sap.m.MessageBox.Action.OK]
						});
					this.setModel(oModel_userdata, "Model_userdata");
				}*/
			} else {
				MessageBox.show(
					"You do not have authorization.", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				return;
			}

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});
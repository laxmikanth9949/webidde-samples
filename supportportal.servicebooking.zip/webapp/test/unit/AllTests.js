sap.ui.define([
	"sap/support/servicebooking/test/unit/controller/App.controller"
], function () {
	"use strict";
});
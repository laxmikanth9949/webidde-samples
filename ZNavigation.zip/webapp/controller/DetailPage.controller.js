sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("ZNavigation.ZNavigation.controller.DetailPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZNavigation.ZNavigation.view.DetailPage
		 */
		onInit: function () {
			debugger;
			//	this.oModel = this.getOwnerComponent().getModel("NorthWind_V2");
				// this.oRouter = this.getOwnerComponent().getRouter();
				// this.oRouter.getRoute("DetailPage").attachMatched(this.onPatternMatched, this);
				this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.getRoute("DetailPage").attachMatched(this._onRouteMatched, this);

		},
		onPatternMatched:function(oEvent){
			debugger;
		/*	var oarguments = oEvent.getParameter("arguments");
			var prodId = oarguments.ProductID;
			this.oModel.bUseBatch = false;*/
			/*this.oModel.read("/Products("+prodId+")",{
				success:function(oData,oResponse){
					debugger;
						var oView = this.getView();
						var oArgs = oEvent.getParameter("arguments");
						oView.bindElement({
							path: "/(" + oArgs.ProductID + ")"
						});
				
				}.bind(this),error:function(oData,oResponse){
					debugger;
				}.bind(this)
			});*/
				var oView = this.getView().byId("SimpleFormDisplay480_Trial");
						var oArgs = oEvent.getParameter("arguments");
						oView.bindElement({
							path: "/Products(" + oArgs.ProductID + ")"
						});
			
		},
		onBackMainPage: function(oEvent){
			this.oRouter.navTo("Main");
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZNavigation.ZNavigation.view.DetailPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZNavigation.ZNavigation.view.DetailPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZNavigation.ZNavigation.view.DetailPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});
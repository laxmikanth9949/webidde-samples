sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("ZNavigation.ZNavigation.controller.Main", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZNavigation.ZNavigation.view.Main
		 */
		onInit: function () {
			this.oModel = this.getOwnerComponent().getModel("NorthWind_V2");
			this.getView().byId("idTable").setModel(this.oModel);
			
			this.oRouter = this.getOwnerComponent().getRouter();
		//	this.oReadData();

		},
		onPress: function(oEvent){
			debugger;
		},
		oReadData:function(oEvent){
			this.oModel.bUseBatch = false;
			this.oModel.read("/Products",{
				success:function(oData,oResponse){
					debugger;
					var oJson = new sap.ui.model.json.JSONModel(oData.results);
				//	oJson.setData(oData.results);
					this.getView().byId("idTable").setModel(oJson);
				}.bind(this),
				error:function(oData,oResponse){
					debugger;
				}.bind(this)
			});
		},
		onPressLineItem: function(oEvent){
			debugger;
			// const oSelectedItem = oEvent.getSource();
			// const oContext = oSelectedItem.getBindingContext("products");
			// const sPath = oContext.getPath();
			// const oProductDetailPanel = this.byId("productDetailsPanel");
			// oProductDetailPanel.bindElement({ path: sPath, model: "products" });
			
			var osource = oEvent.getSource();
			var oSelectedItems = this.getView().byId("idTable").getModel().getProperty(osource.getBindingContextPath());
			this.oRouter.navTo("DetailPage",{
				"ProductID":oSelectedItems.ProductID
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZNavigation.ZNavigation.view.Main
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZNavigation.ZNavigation.view.Main
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZNavigation.ZNavigation.view.Main
		 */
		//	onExit: function() {
		//
		//	}

	});

});
sap.ui.define([
	"ZTest/ZTest/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
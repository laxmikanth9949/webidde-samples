sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/support/servicemessage/model/model",
	"sap/support/servicemessage/controller/ModDialog"
], function(UIComponent, JSONModel, ODataModel, MessageBox, models, ModDialog) {
	"use strict";

	return UIComponent.extend("sap.support.servicemessage.Component", {
		metadata: {
			manifest: "json"
		},

		init: function() {
			var oConfig = this.getMetadata().getConfig();
			this.sConfig = oConfig;
			var oModel_userdata = new JSONModel();
			oModel_userdata.loadData(oConfig.requestRemote + "UserDataSet('ME')", {}, false, "GET");
			if (oModel_userdata.getData().d) {
				this.User = oModel_userdata.getData().d.UserID;
				this.UserType = oModel_userdata.getData().d.UserID.substring(0, 1);
				this.Substitute = oModel_userdata.getData().d.SUBSTITUTE;
				this.setModel(oModel_userdata, "Model_userdata");
			} else {
				MessageBox.show(
					"You do not have authorization.", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				return;
			}

			//this.errorMessageOf_es = oModel_userdata_es.getData().d.ErrorMsg;
			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);
			var oServiceMsg = new ODataModel(oConfig.requestRemote, {
				defaultOperationMode: sap.ui.model.odata.OperationMode.Client,
				useBatch: false,
				defaultUpdateMethod: sap.ui.model.odata.UpdateMethod.Put
			});
			// var oServiceMsg = new ODataModel(oConfig.requestRemote);
			// oServiceMsg.setUseBatch(false);
			this.setModel(oServiceMsg, "overall");
			// create the views based on the url/hash
			var ServiceMessageModel = new JSONModel();
			this.setModel(ServiceMessageModel, "ServiceMessageModel");

			// URL parameters     &Customer=202418&Installation=222
			this.getURLParameter();

			/*this.oModel_URLPara = new JSONModel();
			this.oModel_URLPara.setData(oData);*/
			this.setModel(models.createDeviceModel(), "device");
			
			this.getRouter().initialize();
	
			this.ModDialog = new ModDialog();
			this.initODataModel();
		},

		getURLParameter: function() {
			var sServiceType = jQuery.sap.getUriParameters().get("ServiceType");
			var sCustomerNo = jQuery.sap.getUriParameters().get("Customer");
			var sInstallationNo = jQuery.sap.getUriParameters().get("Installation");
			var sSystemID = jQuery.sap.getUriParameters().get("SystemID");
			var sSystemNo = jQuery.sap.getUriParameters().get("SystemNo");
			this.oData = {};
			this.oData.Visible = true;
			if (sServiceType) {
				this.oData.ServiceType = sServiceType;
				this.oData.Visible = false;
			}
			if (sCustomerNo) {
				this.oData.Customer = sCustomerNo;
				this.oData.Visible = false;
			}
			if (sInstallationNo) {
				this.oData.Installation = sInstallationNo;
				this.oData.Visible = false;
			}
			if (sSystemID) {
				this.oData.SystemID = sSystemID;
				this.oData.Visible = false;
			}
			if (sSystemNo) {
				this.oData.SystemNo = sSystemNo;
				this.oData.Visible = false;
			}
		},
		  initODataModel: function () {
		  	var that = this;
			var _oUserProfilModel = new sap.ui.model.odata.v2.ODataModel({
				json: true,
				useBatch: false,
				serviceUrl: "/services/odata/svt/user_profile_srv"
			});

			_oUserProfilModel.read("/Entries", {
				filters: [
					new sap.ui.model.Filter("Username", sap.ui.model.FilterOperator.EQ, this.User),
					new sap.ui.model.Filter("Attribute", sap.ui.model.FilterOperator.EQ, "TIME_FORMAT")
				],
				success: function (oData) {
					that.getModel("ModLog").setProperty("/timeformat", oData.results[0].Value);
				},
				error: function () {}
			});
		}
	});
});
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/Token"
], function(Controller, Token) {
	"use strict";

	return Controller.extend("sap.support.servicemessage.controller.App", {

		onInit: function() {
			var oView = this.getView();
			// if (oView.sViewName === "sap.support.servicemessage.view.Homepage") {
			// this.getRouter().attachRouteMatched($.proxy(function(e) {
			// 	var view = this.getView();
			// 	var model = view.getModel("overall");
			// 	this.getView().setModel(model,"overall");
			// }), this);	
//--------------------When it is multiInput----------------------------
				/*var oMultiInput_Customer = oView.byId("customer_id");
					oMultiInput_Customer.addValidator(function(args) {
					var oToken = new Token({
						key: args.text,
						text: args.text
					});
					args.asyncCallback(oToken);
					//return sap.m.MultiInput.WaitForAsyncValidation;
				});*/
//---------------------------------------------------------------------
			// }
			
		},
		onSearch: function() {
			var customer = this.getView().byId("customer_id").getTokens()[0].getKey();
			var model = this.getOwnerComponent().getModel("overall");
			model.read("/ServiceMessageSet", {
				filters: [new sap.ui.model.Filter("Customer", "EQ", customer)]
			});
			this._updateTable(model);
		},
		_updateTable: function(model) {
			var oTable = this.getView().byId("serviceMsgTable");
			oTable.setModel(model, "overall");
			this.getOwnerComponent().getModel("overall").refresh();
		},
		geti18nModel: function() {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		}

	});

});
sap.ui.define([
	"sap/support/servicemessage/controller/BaseController",
	"sap/support/servicemessage/model/model",
	"sap/support/servicemessage/model/formatter",
	"sap/m/Token"
], function (BaseController, model, formatter, Token) {
	"use strict";
	return BaseController.extend("sap.support.servicemessage.controller.Subscribe", {
		formatter: formatter,
		subscriptionData: {}, // To register dynamice data from UI
		onInit: function () {

			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("Detail", "ReloadSubscribeView", this.reloadSubscribeView, this);
			oEventBus.subscribe("Homepage", "ReloadSubscribeView", this.reloadSubscribeViewForMultiCreate, this);

			//input value model
			var oInputValueModel = model.createInputValueModel();
			this.setModel(oInputValueModel, "inputContent");

			//read subscription model
			var oEmailTokenModel = model.createEmailTokenValueModel();
			this.setModel(oEmailTokenModel, "emailTokenContent");

			//backend subscription model
			var url = this._getRemoteRoot();
			var oSubscribeMsgSetModel = model.createNewODataModel(url, false);
			this.setModel(oSubscribeMsgSetModel, "subscribeMsgSet"); // To register stable data from backend

			var oView = this.getView();
			var oMuiltiInputSendTo = oView.byId("multiInput_sendTo");
			oMuiltiInputSendTo.addValidator(function (args) {
				var email = args.text;
				return new Token({
					key: email,
					text: email
				});
			});

			/*var oMuiltiInputCcTo = oView.byId("multiInput_ccTo");
			oMuiltiInputCcTo.addValidator(function(args) {
				var email = args.text;
				return new Token({
					key: email,
					text: email
				});
			});*/
		},

		reloadSubscribeView: function (sChanel, e, oData) {
			if (oData) {
				this.subscriptionData.Pointer = oData.Pointer;
				this.subscriptionData.Auto_forwarding = "";
			}
			var oInputValueModel = this.getModel("inputContent");
			oInputValueModel.setProperty("/navButton", true);
			oInputValueModel.setProperty("/isSingle", true);
			var oModelRead = this.getModel("subscribeMsgSet");
			oModelRead.read("/SubscribeMsgSet(Pointer='" + this.subscriptionData.Pointer + "')", {
				success: function (oData) {
					this.setSubscriptionInfo(oData);
				}.bind(this),
				error: function (error) {}.bind(this)
			});
		},

		reloadSubscribeViewForMultiCreate: function (sChanel, e, oData) {
			var oInputValueModel = this.getModel("inputContent");
			model.initialInputValueModel(oInputValueModel);
			oInputValueModel.setProperty("/navButton", false);
			oInputValueModel.setProperty("/Substitute", oData.Substitute);
			var oEmailTokenModel = this.getModel("emailTokenContent");
			model.initialEmailTokenValueModel(oEmailTokenModel);
			if (oData) {
				this.subscriptionData.Auto_forwarding = oData.Pointer;
				this.subscriptionData.Pointer = "";
			}
			oInputValueModel.setProperty("/isSingle", false);
			//this.multiPointers = oData.Pointer;
			var oModelRead = this.getModel("subscribeMsgSet");
			oModelRead.read("/SubscribeMsgSet(Pointer='000000000000000000000000')", {
				async: false,
				success: function (oData) {
					oInputValueModel.setProperty("/body", oData.EmailBody);
					oInputValueModel.setProperty("/subject", oData.Subject);
					this.getModel("inputContent").refresh(true);
					this.getModel("inputContent").updateBindings(true);
				}.bind(this),
				error: function (error) {}.bind(this)
			});
		},
		onRefresh: function () {
			var oInputValueModel = this.getModel("inputContent");
			model.initialInputValueModel(oInputValueModel);
			if (this.subscriptionData.Pointer) {
				var oPointer = this.subscriptionData.Pointer;
			} else {
				oPointer = "000000000000000000000000";
			}
			var oModelRead = this.getModel("subscribeMsgSet");
			oModelRead.read("/SubscribeMsgSet(Pointer='" + oPointer + "')", {
				async: false,
				success: function (oData) {
					oInputValueModel.setProperty("/body", oData.EmailBody);
					oInputValueModel.setProperty("/subject", oData.Subject);
					if (this.getView().getId() === "__xmlview2") {
						oInputValueModel.setProperty("/navButton", false);
					} else if(this.getView().getId() === "__xmlview1"){
						oInputValueModel.setProperty("/navButton", false);
					}else{
						oInputValueModel.setProperty("/navButton", true);
					}
					oInputValueModel.setProperty("/Substitute", oData.Substitute);
					oInputValueModel.setProperty("/isSingle", false);
					this.getModel("inputContent").refresh(true);
					this.getModel("inputContent").updateBindings(true);
				}.bind(this),
				error: function (error) {
					sap.m.MessageBox.warning(JSON.parse(error.responseText).error.message.value);
					if (this.getView().getId() === "__xmlview2") {
						oInputValueModel.setProperty("/navButton", false);
					} else if(this.getView().getId() === "__xmlview1"){
						oInputValueModel.setProperty("/navButton", false);
					}else{
						oInputValueModel.setProperty("/navButton", true);
					}
				}.bind(this)
			});
		},

		removeEmailTokenFromModel: function (oEvent, sRout) {
			var oEmailTokenModel = this.getModel("emailTokenContent");
			var sKey = oEvent.getParameter("removedTokens")[0].getProperty("key");
			var aData = oEmailTokenModel.getProperty(sRout);
			for (var i = 0; i < aData.length; i++) {
				var idx;
				if (aData[i].email === sKey) {
					idx = i;
				}
			}
			aData.splice(idx, 1);
			oEmailTokenModel.setProperty(sRout, aData);
		},

		onTokenUpdate: function (oEvent) {
			var sEventType = oEvent.getParameter("type");
			var sEventControlId = oEvent.getSource().getId();
			var oEmailTokenModel = this.getModel("emailTokenContent");
			if (sEventType === "added") {
				if (sEventControlId.search(/sendTo/) !== -1) {
					if (typeof (oEmailTokenModel.getProperty("/SendTo")) === "string") {
						oEmailTokenModel.setProperty("/SendTo", [{
							email: oEvent.getParameter("addedTokens")[0].getProperty("key")
						}]);
					} else {
						oEmailTokenModel.getProperty("/SendTo").push({
							email: oEvent.getParameter("addedTokens")[0].getProperty("key")
						});
					}
				} else if (sEventControlId.search(/ccTo/) !== -1) {
					if (typeof (oEmailTokenModel.getProperty("/CCTo")) === "string") {
						oEmailTokenModel.setProperty("/CCTo", [{
							email: oEvent.getParameter("addedTokens")[0].getProperty("key")
						}]);
					} else {
						oEmailTokenModel.getProperty("/CCTo").push({
							email: oEvent.getParameter("addedTokens")[0].getProperty("key")
						});
					}
				}
			} else if (sEventType === "removed") {
				if (sEventControlId.search(/sendTo/) !== -1) {
					this.removeEmailTokenFromModel(oEvent, "/SendTo");
				} else if (sEventControlId.search(/ccTo/) !== -1) {
					this.removeEmailTokenFromModel(oEvent, "/CCTo");
				}
			}
		},

		refactSEmailToObject: function (sEmail) {
			var aEmail = sEmail.slice(0, sEmail.length - 1).split(";");
			var aEmails = [];
			for (var i = 0; i < aEmail.length; i++) {
				var oEmail = {};
				oEmail.email = aEmail[i];
				aEmails.push(oEmail);
			}
			if (aEmails[0].email === "" && aEmails.length === 1) {
				aEmails = "";
			}
			return aEmails;
		},

		/*_initEmailBodyContent: function() {
			var sHtmlValue = ""; //'<p><img src="https://www.sap.com/dam/application/shared/logos/sap-logo-svg.svg" data-sap-ui-rte-image-ratio="false" /></p>'
			return sHtmlValue;
		},*/

		setSubscriptionInfo: function (oData) {
			var oEmailTokenModel = this.getModel("emailTokenContent");
			var oInputValueModel = this.getModel("inputContent");
			var aSendToEmails = this.refactSEmailToObject(oData.SendTo);
			oEmailTokenModel.setProperty("/SendTo", aSendToEmails);
			var aCCToEmails = this.refactSEmailToObject(oData.CCTo);
			oEmailTokenModel.setProperty("/CCTo", aCCToEmails);
			oInputValueModel.setProperty("/subject", oData.Subject);
			oInputValueModel.setProperty("/has_subscription", oData.Has_Subscription);
			oInputValueModel.setProperty("/body", oData.EmailBody);
			/*var sHtmlValue = oData.EmailBody;//oData.EmailBody this._initEmailBodyContent()
			if (oInputValueModel.getProperty("/has_subscription") !== "X") {
				oInputValueModel.setProperty("/body", sHtmlValue);
			} else {
				oInputValueModel.setProperty("/body", oData.EmailBody);
			}*/
			oInputValueModel.setProperty("/Substitute", oData.Substitute);
			this.getModel("inputContent").refresh(true);
			this.getModel("inputContent").updateBindings(true);
		},

		getStringOfEMailAddress: function (sRout) {
			var oEmailTokenModel = this.getModel("emailTokenContent");
			var sEMailAddress = "";
			for (var i = 0; i < oEmailTokenModel.getProperty(sRout).length; i++) {
				var eMailAddress = oEmailTokenModel.getProperty(sRout)[i].email;
				sEMailAddress = sEMailAddress + eMailAddress + ";";
			}
			return sEMailAddress;
		},

		callMessageBoxWarning: function (sInfo) {
			sap.m.MessageBox.warning(
				sInfo, {
					icon: sap.m.MessageBox.Icon.WARNING,
					actions: [sap.m.MessageBox.Action.OK]
				});
		},

		checkSendToEntity: function (sSentTo) {
			if (!sSentTo) {
				this.callMessageBoxWarning(this.getModel("i18n").getResourceBundle().getText("warningEmptySendTo"));
				return false;
			} else {
				return true;
			}
		},

		checkSubjectEntity: function (sSubject) {
			if (!sSubject) {
				this.callMessageBoxWarning(this.getModel("i18n").getResourceBundle().getText("warningEmptySubject"));
				return false;
			} else {
				return true;
			}
		},

		checkEmailAddress: function (sSentTo, sCCTo) {
			var rexMail = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
			var aEmail;
			var aEmailConcat;
			aEmail = sSentTo.slice(0, sSentTo.length - 1).split(";");
			if (sCCTo) {
				aEmailConcat = aEmail.concat(sCCTo.slice(0, sCCTo.length - 1).split(";"));
			} else {
				aEmailConcat = aEmail;
			}
			for (var i = 0; i < aEmailConcat.length; i++) {
				if (!aEmailConcat[i].match(rexMail)) {
					this.callMessageBoxWarning(this.getModel("i18n").getResourceBundle().getText("invaildEMail"));
					return false;
				}
			}
			return true;
		},

		updateGloabsubscriptionData: function () {
			var sSendTo = this.getStringOfEMailAddress("/SendTo");
			var sCcTo = this.getStringOfEMailAddress("/CCTo");
			this.subscriptionData.SendTo = sSendTo;
			this.subscriptionData.CCTo = sCcTo;

			var oModelInputContent = this.getModel("inputContent");
			this.subscriptionData.Subject = oModelInputContent.getData().subject;
			this.subscriptionData.EmailBody = oModelInputContent.getData().body;

		},

		onSend: function () {
			this.updateGloabsubscriptionData();
			if (this.checkSendToEntity(this.subscriptionData.SendTo) && this.checkSubjectEntity(this.subscriptionData.Subject) && this.checkEmailAddress(
					this.subscriptionData.SendTo, this.subscriptionData.CCTo)) {
				var oModelCreate = this.getModel("subscribeMsgSet");
				oModelCreate.create("/SubscribeMsgSet", this.subscriptionData, {
					success: function () {
						this.getModel("inputContent").setProperty("/has_subscription", "X");
						sap.m.MessageToast.show(this.getModel("i18n").getResourceBundle().getText("msg_subscribesuccess"));
					}.bind(this),
					error: function () {
						sap.m.MessageToast.show(this.getModel("i18n").getResourceBundle().getText("msg_subscribefailed"));
					}.bind(this)
				});
			}
		},

		checkIfContentEqual: function (oSaved, oChanged) {
			var oCopySaved = oSaved;
			if (Object.keys(oCopySaved).length !== Object.keys(oChanged).length) {
				if (oCopySaved.Has_Subscription !== undefined) {
					delete oCopySaved.Has_Subscription;
				}
				if (oCopySaved.Substitute !== undefined) {
					delete oCopySaved.Substitute;
				}

			}
			var aKeys = Object.keys(oChanged);
			for (var i = 0; i < aKeys.length; i++) {
				//if (aKeys[i] !== "EmailBody") {
				if (oChanged[aKeys[i]] !== oCopySaved[aKeys[i]]) {
					return false;
				}
				// } else {
				// 	if ((oCopySaved[aKeys[i]] === "" && oChanged[aKeys[i]] !== this._initEmailBodyContent() && oChanged[aKeys[i]] !== oCopySaved[aKeys[i]]) ||
				// 		(oCopySaved[aKeys[i]] !== "" && oChanged[aKeys[i]] === this._initEmailBodyContent() && oCopySaved[aKeys[i]] !== oChanged[aKeys[i]]) || (
				// 			oCopySaved[aKeys[i]] !== "" && oChanged[aKeys[i]] !== this._initEmailBodyContent() && oCopySaved[aKeys[i]] !== oChanged[aKeys[i]])) {
				// 		return false;
				// 	}
				// }

			}
			return true;
		},

		callMessageBoxWarningBack: function (sInfo) {
			sap.m.MessageBox.warning(
				sInfo, {
					icon: sap.m.MessageBox.Icon.WARNING,
					actions: [sap.m.MessageBox.Action.OK,
						sap.m.MessageBox.Action.CANCEL
					],
					onClose: function (sAction) {
						if (sAction === "OK") {
							var oApp = this.getView().getParent().getParent();
							oApp.to(oApp.getDetailPages()[0]);
						}
					}.bind(this)
				});
		},

		onBack: function (oEvent) {
			this.updateGloabsubscriptionData();
			var oInitSubscriptionData = this.getModel("subscribeMsgSet").getProperty("/SubscribeMsgSet('" + this.subscriptionData.Pointer +
				"')");
			var bFlag = this.checkIfContentEqual(oInitSubscriptionData, this.subscriptionData);
			if (bFlag === false) {
				this.callMessageBoxWarningBack(this.getModel("i18n").getResourceBundle().getText("warningDataLoss"));
			} else {
				var oApp = oEvent.getSource().getParent().getParent().getParent();
				oApp.to(oApp.getDetailPages()[0]);
				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("Subscribe", "setGeneralPageSubscribeButton", {
					hasSubscription: this.getModel("inputContent").getProperty("/has_subscription")
				});
			}
		},

		onCancel: function (oEvent) {
			this.updateGloabsubscriptionData();
			var oInitSubscriptionData = this.getModel("subscribeMsgSet").getProperty("/SubscribeMsgSet('" + this.subscriptionData.Pointer +
				"')");
			var bFlag = this.checkIfContentEqual(oInitSubscriptionData, this.subscriptionData);
			if (bFlag === false) {
				this.callMessageBoxWarningBack(this.getModel("i18n").getResourceBundle().getText("warningDataLoss"));
				/*sap.m.MessageBox.warning(
					this.getModel("i18n").getResourceBundle().getText("warningDataLoss"), {
						icon: sap.m.MessageBox.Icon.WARNING,
						actions: [sap.m.MessageBox.Action.OK,
							sap.m.MessageBox.Action.CANCEL
						],
						onClose: function(sAction) {
							if (sAction === "OK") {
								this.reloadSubscribeView();
							}
						}.bind(this)
					});*/
			} else {
				var oApp = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
				oApp.to(oApp.getDetailPages()[0]);
				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("Subscribe", "setGeneralPageSubscribeButton", {
					hasSubscription: this.getModel("inputContent").getProperty("/has_subscription")
				});
			}
		},

		onDelete: function () {
			var oModelDelete = this.getModel("subscribeMsgSet");
			oModelDelete.remove("/SubscribeMsgSet('" + this.subscriptionData.Pointer + "')", {
				success: function () {
					this.reloadSubscribeView();
					this.getModel("inputContent").setProperty("/has_subscription", "");
					sap.m.MessageToast.show(this.getModel("i18n").getResourceBundle().getText("msg_deleteSuccess"));
				}.bind(this),
				error: function () {
					sap.m.MessageToast.show(this.getModel("i18n").getResourceBundle().getText("msg_deleteFailed"));
				}.bind(this)
			});
		}

	});

});
/*global location */
sap.ui.define([
	"sap/support/servicemessage/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/support/servicemessage/model/formatter",
	"sap/support/servicemessage/model/model"
], function (BaseController, JSONModel, History, formatter, model) {
	"use strict";

	return BaseController.extend("sap.support.servicemessage.controller.Detail", {
		_SessionContact: "",
		_processor: "",
		formatter: formatter,
		onInit: function () {
			this.getRouter().getRoute("SplitPage").attachPatternMatched(this.getGeneralText, this);

			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("Session01", "setGeneralPageFavorite", this.reSetGeneralView, this);

			oEventBus.subscribe("Subscribe", "setGeneralPageSubscribeButton", this.reSetSubscribeButton, this);

			var oDetailViewModel = model.createDetailViewModel();
			this.setModel(oDetailViewModel, "detailView");

			var url = this._getRemoteRoot();
			var oModificationLogSetModel = model.createNewODataModel(url, false);
			this.setModel(oModificationLogSetModel, "ModificationLog");
		},

		reSetSubscribeButton: function (sChanel, e, oData) {
			var oDetailViewModel = this.getModel("detailView");
			oDetailViewModel.setProperty("/hasSubscription", oData.hasSubscription);
		},

		getGeneralText: function (oEvent) {
			var ServiceMessageModel = new JSONModel();
			var GeneralTextModel = new JSONModel();
			var GeneralTextURLModel = new JSONModel();
			// Load useful Data
			var Pointer = oEvent.getParameter("arguments").Pointer;
			this._globalPointer = Pointer;
			ServiceMessageModel.loadData(this._getRemoteRoot() +
				"ServiceMessageSet('" + Pointer + "')", {}, false, "GET");
			GeneralTextModel.loadData(this._getRemoteRoot() +
				"TextSet(Pointer='" + Pointer + "',Sess_Guid='GENERAL')", {}, false, "GET");
			GeneralTextURLModel.loadData(this._getRemoteRoot() +
				"TextSet(Pointer='" + Pointer + "',Sess_Guid='GENERAL')/TextURLSet", {}, false, "GET");
			// Check auth
			if (!GeneralTextModel.getData().d) {
				return;
			}
			// Object header
			var generalText = GeneralTextModel.getData().d.General_Text;
			var indextTitle = generalText.search("</h2>");
			var ObjectName = generalText.slice(4, indextTitle);
			this.getView().byId("generalTitle").setObjectTitle(ObjectName);

			var serviceOrder = ServiceMessageModel.getData().d.CRM_Order;
			var serviceInstNo = ServiceMessageModel.getData().d.Installation;
			var serviceSystId = ServiceMessageModel.getData().d.SystemID;
			this.getView().byId("serviceOrder").setText(serviceOrder);
			this.getView().byId("systemId").setText(serviceSystId);
			this.getView().byId("instNo").setText(serviceInstNo);
			var ContactPersonName = ServiceMessageModel.getData().d.Action_User_Name;
			var ContactPersonNumber = ServiceMessageModel.getData().d.Aktion_User;
			this._SessionContact = ContactPersonNumber;
			var i18nModel = this.geti18nModel();
			var SessionContactText = i18nModel.getResourceBundle().getText("firstLineOfGeneralMessage");
			var sHtmlText01 = SessionContactText + " " + ContactPersonName + " " + ContactPersonNumber;
			this.getView().byId("serviceContact").setText(sHtmlText01);
			//var sHtmlText01 = "<p>" + SessionContactText+ "&nbsp;" + ContactPersonName + "&nbsp;" + ContactPersonNumber + "</p>";
			//var sHtmlText = "<ul>" + sHtmlText01 + GeneralTextModel.getData().d.General_Text + "</ul><br>";
			// general Text content
			var generalTextContent = generalText.slice(Number(indextTitle) + 6);
			var sHtmlText = generalTextContent + "<br>";
			/*if(!GeneralTextURLModel.getData().d){
				var sHtmlUrlName = "SAP EarlyWatch Alert";
				var sHtmlUrlHerf = "https:"+"//support.sap.com/ewa";
			}else{*/
			var sHtmlUrlName = GeneralTextURLModel.getData().d.results[0].URL_Name;
			var sHtmlUrlHerf = GeneralTextURLModel.getData().d.results[0].URL;
			/*}*/

			var embed = '<embed data-index="0">';
			var loaner = "<a href='" + sHtmlUrlHerf + "'>" + sHtmlUrlName + "</a>";
			var rHtmlText = sHtmlText.replace(embed, loaner);
			//set the text with placeholders inside
			this.getView().byId("generalString").setHtmlText(rHtmlText);
			this.getView().byId("generalString").addEventDelegate({
				onAfterRendering: $.proxy(function () {
					var children = $("#" + this.getView().byId("generalString").getId()).children();
					$(children[2].children[0]).attr('class', 'formattedTextstyle');
				}, this)
			});
			//this.getView().byId("generalString").addControl(oLink);
			/*------------------set Favorite Button------------------------------------*/
			this._initFavorite(Pointer, "favorite", "unfavorite", "generalTitle");
			/*------------------set read and compelted Button--------------------------------------*/
			var serviceMessageStatus = ServiceMessageModel.getData().d.Status;
			if (serviceMessageStatus === "2") {
				this.getView().byId("unRead").setVisible(false);
				this.getView().byId("read").setVisible(true);
				this.getView().byId("disComplete").setVisible(true);
				this.getView().byId("complete").setVisible(false);
			} else if (serviceMessageStatus === "1") {
				this.getView().byId("unRead").setVisible(true);
				this.getView().byId("read").setVisible(false);
				this.getView().byId("disComplete").setVisible(true);
				this.getView().byId("complete").setVisible(false);
			} else if (serviceMessageStatus === "3") {
				this.getView().byId("unRead").setVisible(false);
				this.getView().byId("read").setVisible(true);
				this.getView().byId("disComplete").setVisible(false);
				this.getView().byId("complete").setVisible(true);
			}
			/*---------------------set forward and status visible state------------------------------*/
			this._processor = ServiceMessageModel.getData().d.Aktion_User;
			this._setVisibleStatusOfForwardAndStatusSetIcon(this._processor);
			/*---------------------get has_subscription current_user subsctitute info------------------------------------*/
			var oDetailViewModel = this.getModel("detailView");
			oDetailViewModel.setProperty("/hasSubscription", ServiceMessageModel.getData().d.Has_Subscription);
			oDetailViewModel.setProperty("/currentUser", ServiceMessageModel.getData().d.Current_User);
			oDetailViewModel.setProperty("/substitute", ServiceMessageModel.getData().d.Substitute);
			oDetailViewModel.setProperty("/canSubscribe", ServiceMessageModel.getData().d.Can_Subscribe);
		},

		reSetGeneralView: function (sChanel, e, oData) {
			// favorite Icon
			if (oData.favorite_flag === true) {
				this.getView().byId("favorite").setVisible(true);
				this.getView().byId("unfavorite").setVisible(false);
				this.getView().byId("generalTitle").setMarkFavorite(true);
			} else if (oData.favorite_flag === false) {
				this.getView().byId("favorite").setVisible(false);
				this.getView().byId("unfavorite").setVisible(true);
				this.getView().byId("generalTitle").setMarkFavorite(false);
			}
			// new processor
			if (oData.NewProcessor !== "") {
				var i18nModel = this.geti18nModel();
				var SessionContactText = i18nModel.getResourceBundle().getText("firstLineOfGeneralMessage");
				var sHtmlText01 = SessionContactText + " " + oData.NewProcessorName + " " + oData.NewProcessor;
				this.getView().byId("serviceContact").setText(sHtmlText01);
			}
			// read Icon
			if (oData.read_flag === true) {
				this.getView().byId("unRead").setVisible(false);
				this.getView().byId("read").setVisible(true);
			} else if (oData.read_flag === false) {
				this.getView().byId("unRead").setVisible(true);
				this.getView().byId("read").setVisible(false);
			}
			// completed Icon
			if (oData.completed_flag === true) {
				this.getView().byId("disComplete").setVisible(false);
				this.getView().byId("complete").setVisible(true);
			} else if (oData.completed_flag === false) {
				this.getView().byId("disComplete").setVisible(true);
				this.getView().byId("complete").setVisible(false);
			}

			//internal user
			this._setVisibleStatusOfForwardAndStatusSetIcon(this._processor);
		},
		addFavorite: function () {
			this._addFavorite("favorite", "unfavorite", "generalTitle");
		},

		removeFavorite: function () {
			this._removeFavorite("favorite", "unfavorite", "generalTitle");
		},

		forward: function () {
			if (this._SessionContact !== this.getUser()) {
				var i18nModel = this.geti18nModel();
				var Msg = i18nModel.getResourceBundle().getText("Msg");
				var Warning = i18nModel.getResourceBundle().getText("warning");
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.warning(
					Msg, {
						title: Warning,
						icon: sap.m.MessageBox.Icon.WARNING,
						actions: [sap.m.MessageBox.Action.OK]
					});
			} else {
				this._forward("serviceContact");
			}

		},
		onBack: function () {
			//	this.getView().byId("generalString").destroyControls();
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("homepage", true);
			}
		},

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		_getRemoteRoot: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			var root = oComp.sConfig.requestRemote;
			return root;
		},

		geti18nModel: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		},
		
		onActionLog: function (oEvent) {
			this.getOwnerComponent().ModDialog.open(this.getView());
			this.loadLog();
		}

	});

});
sap.ui.require([
	"sap/support/servicemessage/controller/Subscribe.controller",
	"sap/support/servicemessage/model/model",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/ManagedObject",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
],function(Subscribe, model, Controller, ODataModel, ResourceModel, ManagedObject){
	"use strict";
	
	QUnit.module("Subscribe - Subscription Display",{
		beforeEach: function(){
			this.subscription = new Subscribe();
			this.oComponent = new ManagedObject();
			
			var oInputValueModel = model.createInputValueModel();
			this.oComponent.setModel(oInputValueModel, "inputContent");
			//read subscription model
			var oReadValueModel = model.createEmailTokenValueModel();
			this.oComponent.setModel(oReadValueModel, "emailTokenContent");
			
			var url = "test/url/";
			var oSubscribeMsgSetModel = model. createNewODataModel(url, false); 
			this.oComponent.setModel(oSubscribeMsgSetModel, "subscribeMsgSet");
			
			var oModelI18n = new ResourceModel({
				bundleName: "sap.support.servicemessage.i18n.message_bundle",
				bundleLocale: "EN"
			});
			this.oComponent.setModel(oModelI18n, "i18n");
			
			sinon.stub(this.subscription, "getOwnerComponent").returns(this.oComponent);
		},
		afterEach: function(){
			this.subscription.destroy();
			sinon.restore();
		}
	});
	
	QUnit.test("Should display correct subscribed information in UI when has subscription", function(assert){
		//Arrangement
		var oPointerData = {Pointer: "002075125200000000042018"};
		var oData = {
				CCTo:"",
				Changed_at: "",
				EmailBody: "sf1",
				Pointer: "002075125200000000042018",
				SendTo: "w@e.com;ee@er.com;gfg@s.com;",
				Subject: "test",
				Has_Subscription: "X"
		};
		this.stub(ODataModel.prototype, "read").yieldsTo("success",oData);
		var exportSendTo = [{email: "w@e.com"}, {email: "ee@er.com"}, {email: "gfg@s.com"}];
		//action
		this.subscription.reloadSubscribeView("Detail", "ReloadSubscribeView", oPointerData);    
		//Assertion
		assert.deepEqual(this.subscription.getModel("emailTokenContent").getProperty("/SendTo"), exportSendTo);
		assert.deepEqual(this.subscription.getModel("emailTokenContent").getProperty("/CCTo"), "");
		assert.deepEqual(this.subscription.getModel("inputContent").getProperty("/subject"), "test");
		assert.deepEqual(this.subscription.getModel("inputContent").getProperty("/body"), "sf1");
	});
	
	QUnit.test("Should displayte subscription template information in UI when do not have subscription", function(assert){
		//Arrangement
		var oPointerData = {Pointer: "002075125200000000042018"};
		var oData = {
				CCTo:"",
				Changed_at: "",
				EmailBody: "",
				Pointer: "002075125200000000042018",
				SendTo: "",
				Subject: "",
				Has_Subscription: ""
		};
		this.stub(ODataModel.prototype, "read").yieldsTo("success",oData);
		//action
		this.subscription.reloadSubscribeView("Detail", "ReloadSubscribeView", oPointerData);    
		//Assertion
		assert.deepEqual(this.subscription.getModel("inputContent").getProperty("/body"), "");
	});
	
	QUnit.test("Should display correct CCTo email address of subscription with Token in UI when CCTo email address is not empty", function(assert){
		//Arrangement
		var oPointerData = {Pointer: "002075125200000000042018"};
		var oData = {
				CCTo:"w@e.com;ee@er.com;",
				Changed_at: "",
				EmailBody: "",
				Pointer: "",
				SendTo: "w@e.com;ee@er.com;gfg@s.com;",
				Subject: "test"
		};
		this.stub(ODataModel.prototype, "read").yieldsTo("success",oData);
		var exportCCTo = [{email: "w@e.com"}, {email: "ee@er.com"}];
		//action
		this.subscription.reloadSubscribeView("Detail", "ReloadSubscribeView", oPointerData);    
		//Assertion
		assert.deepEqual(this.subscription.getModel("emailTokenContent").getProperty("/CCTo"), exportCCTo);
	});
	
	QUnit.test("Should display warning message when user click the save button and email 'To' address is empty", function(assert){
		//Arrangement
		this.subscription.getModel("inputContent").setProperty("/subject", "Test subject");
		this.subscription.getModel("inputContent").setProperty("/body", "test body");
		this.stub(ODataModel.prototype, "create");
		var oStubMsg = this.stub(sap.m.MessageBox, "warning");
		
		//Action
		this.subscription.onSend();
		
		//Assertion
		assert.strictEqual(oStubMsg.callCount, 1);
	});
	
	QUnit.test("Should display warning message when user click the save button and subject is empty", function(assert){
		//Arrangement
		this.subscription.getModel("emailTokenContent").setProperty("/SendTo", [{email: "test1@sap.com"}, {email: "test2@sap.com"}]);
		this.subscription.getModel("inputContent").setProperty("/body", "test body");
		this.stub(ODataModel.prototype, "create");
		var oStubMsg = this.stub(sap.m.MessageBox, "warning");
		
		//Action
		this.subscription.onSend();
		
		
		//Assertion
		assert.deepEqual(oStubMsg.callCount, 1);
	});
	
	QUnit.test("Should send all user input data for subscription when user click the save button", function(assert){
		//Arrangement
		this.subscription.getModel("emailTokenContent").setProperty("/SendTo", [{email: "test1@sap.com"}, {email: "test2@sap.com"}]);
		this.subscription.getModel("inputContent").setProperty("/subject", "Test subject");
		this.subscription.getModel("inputContent").setProperty("/body", "test body");
		this.stub(ODataModel.prototype, "create");
		
		//Action
		this.subscription.onSend();
		
		//Assertion
		assert.deepEqual(ODataModel.prototype.create.getCall(0).args[1], 
		this.subscription.subscriptionData, "Send the right data");
	});
	
	/*QUnit.test("Should add one 'send to' email adress into email model when add one token in 'To' field ", function(assert){
		//Arrangement
		this.subscription.getModel("emailTokenContent").setProperty("/SendTo", [{email: "test1@sap.com"}, {email: "test2@sap.com"}]);
		this.subscription.getModel("inputContent").setProperty("/subject", "Test subject");
		this.subscription.getModel("inputContent").setProperty("/body", "test body");
		this.stub(ODataModel.prototype, "create");
		
		//Action
		this.subscription.onTokenUpdate(oEvent);
		
		//Assertion
		assert.deepEqual(ODataModel.prototype.create.getCall(0).args[1], 
		this.subscription.subscriptionData, "Send the right data");
	});*/
	
	
});
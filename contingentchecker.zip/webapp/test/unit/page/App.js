sap.ui.require([
	"sap/support/supportportalegiregtool/controller/App.controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/Input",
	"sap/ui/base/Event",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(AppController, JSONModel, Input, Event) {
	"use strict";
	QUnit.module("App Unit Test", {
		beforeEach: function(){
		this.oController=new AppController();
		},
		afterEach: function(){
        this.oController.destroy();
		}
	});
	/*QUnit.test("Have authority both esa and expert should dispaly 3 table", function(assert){
		var esa="X";
		var expert="X";
	    var sAct = this.oController.CheckAuthority(esa,expert); 
		assert.strictEqual(sAct, 3, "The number of table was correct");
	});
	QUnit.test("Only have expert authority should dispaly 3 table", function(assert){
		var esa=" ";
		var expert="X";
	    var sAct = this.oController.CheckAuthority(esa,expert); 
		assert.strictEqual(sAct, 3, "The number of table was correct");
	});
	QUnit.test("Only have esa authority should dispaly 1 table", function(assert){
		var esa="X";
		var expert=" ";
	    var sAct = this.oController.CheckAuthority(esa,expert); 
		assert.strictEqual(sAct, 1, "The number of table was correct");
	});
   	QUnit.test("Have Nothing input should get Null result", function(assert){
		var UserID="";
		var CustomerNum="";
		var Check=false;
		var Date_from="2017-01-01";
		var Date_to="2017-12-31";
		var sAct_inital= {     UserID: UserID,
			                   CustomerNum: CustomerNum,
			                   Check: Check,
			                   Date_from:Date_from,
			                   Date_to: Date_to };
	    var sAct = this.oController.getUserInput(UserID,CustomerNum,Check,Date_from,Date_to); 
		assert.deepEqual(sAct,sAct_inital, "The number of table was correct");
	});
	QUnit.test("Input CustomerNum should get right result", function(assert){
		var UserID="";
		var CustomerNum="202418";
		var Check=false;
		var Date_from="2017-01-01";
		var Date_to="2017-12-31";
		var sAct_inital= {     UserID: UserID,
			                   CustomerNum: CustomerNum,
			                   Check: Check,
			                   Date_from:Date_from,
			                   Date_to: Date_to };
	    var sAct = this.oController.getUserInput(UserID,CustomerNum,Check,Date_from,Date_to); 
		assert.deepEqual(sAct,sAct_inital, "The number of table was correct");
	});
	QUnit.test("Input all content should get right struct result", function(assert){
		var UserID="S000315119";
		var CustomerNum="202418";
		var Check=true;
		var Date_from="2017-01-01";
		var Date_to="2017-12-31";
		var sAct_inital= {    
		                   UserID: UserID,
		                   CustomerNum: CustomerNum,
		                   Check: Check,
		                   Date_from:Date_from,
		                   Date_to: Date_to 
	                    	};
	    var sAct = this.oController.getUserInput(UserID,CustomerNum,Check,Date_from,Date_to); 
		assert.deepEqual(sAct,sAct_inital, "The number of table was correct");
	});*/
	QUnit.test("Input time should get right Time format", function(assert){
		var myDate=new Date();
		myDate.setFullYear(2017,10,3);
	    var sAct = this.oController._timeRefactor(myDate); 
		assert.strictEqual(sAct,"20171103", "Input time get right  time format");
	});

	/*QUnit.test("The first day of this year should display right", function(assert){
		var myDate=new Date();
	    var year=myDate.getFullYear(); 
		var fisrtday=year+"-01-01";
		var lastday =year+"-12-31";
		var Day={
			time_from:fisrtday,
			time_to:lastday
		};
		var sAct = this.oController.getTimeInput();
		assert.deepEqual(sAct,Day, "The first day of this year display right");
	});*/
	
	/*QUnit.test("This year should display right", function(assert){
		var myDate=new Date();
	    var year=myDate.getFullYear(); 
		var sAct = this.oController.getYearInput();
		
		assert.deepEqual(sAct,year, "This year display right");
	});*/
	
	/*QUnit.test("contingents should show correct", function(assert){
		var result=3;
	    var used_contingents= "0.000 ";
	    var total_contingents="0.000 ";
		var sAct = this.oController._contingentsShow(result,used_contingents,total_contingents);
		var contingent={
				          	showUsedContingents:true,
				          	timeused:true,
				          	UsedContingents:true,
				          	showTotalTable:true,
				          	timetotal:true,
				          	TotalTable:true
				          };
		assert.deepEqual(sAct,contingent, "This year display right");
	});*/
	//-----------------------new---------------------------------------------
	QUnit.module("URL for search", {
		beforeEach: function() {
			this.oController = new AppController();
			this.oView = new sap.ui.core.mvc.View({});
			sinon.stub(this.oController, "getView").returns(this.oView);
			this.oView.setModel(new sap.ui.model.json.JSONModel(), "custNoModel");
		},
		afterEach: function() {
			this.oView.destroy();
			this.oController.destroy();
		}
	});

	function URLSearch(customer_no) {
		var uriPara = new jQuery.sap.getUriParameters();
		this.stub(jQuery.sap, "getUriParameters").returns(uriPara);
		this.stub(uriPara, "get").returns(customer_no);
		this.stub(this.oController, "onSearch");
		this.oController.triggerURLSearch();
	}

	QUnit.test("Should see customer number in input field and search results when add customer number in URL", function(assert) {
		URLSearch.call(this, "202418");
		assert.strictEqual(this.oView.getModel("custNoModel").getData().Customer, "202418");
		assert.strictEqual(this.oController.onSearch.calledOnce, true);
	});

	QUnit.test("Should be empty in customer number input field and search results when without customer number in URL", function(assert) {
		URLSearch.call(this, null);
		assert.deepEqual(this.oView.getModel("custNoModel").getData().Customer, undefined);
		assert.strictEqual(this.oController.onSearch.calledOnce, false);
	});
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	QUnit.module("Enable X delete in Input field", {
		beforeEach: function() {
			this.oController = new AppController();
			this.oView = new sap.ui.core.mvc.View({});
			sinon.stub(this.oController, "getView").returns(this.oView);
			this.s_UserInput = new Input("S-UserID", {
				value: "S0000315119",
				showValueHelp: true,
				valueHelpRequest: "onDelete"
			});
			this.custInput = new Input("Number", {
				value: "202418",
				showValueHelp: true,
				valueHelpRequest: "onDelete"
			});
		},
		afterEach: function() {
			this.custInput.destroy();
			this.s_UserInput.destroy();
			this.oView.destroy();
			this.oController.destroy();
		}
	});

	QUnit.test("Should see 'Cancal' incon in Input controller", function(assert) {
		this.stub(this.oView, "byId").returns(this.s_UserInput);
		this.oController.changeInputIcon();
		assert.strictEqual(this.s_UserInput._getValueHelpIcon().getSrc(), "sap-icon://sys-cancel");
	});
	
	QUnit.test("S-User Input field text should be delete", function(assert) {
		this.stub(this.oView, "byId").returns(this.s_UserInput);
		var oEvent = new Event(null, this.s_UserInput, null);
		this.oController.onDelete(oEvent);
		assert.strictEqual(this.s_UserInput.getValue(), "");
	});
	
	QUnit.test("Customer Input field text should be delete", function(assert) {
		this.stub(this.oView, "byId").returns(this.custInput);
		var oEvent = new Event(null, this.custInput, null);
		this.oController.onDelete(oEvent);
		assert.strictEqual(this.custInput.getValue(), "");
	});

});
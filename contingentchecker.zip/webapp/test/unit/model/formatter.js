sap.ui.require([
	"sap/support/supportportalegiregtool/model/Formatter"
],function (Formatter) {
		"use strict";
		QUnit.module("Formatter - Column with formatter");
		function endterTestCase(oOptions){
			// Act
			var sStr = Formatter.enter(oOptions.str);
			// Assert
			oOptions.assert.strictEqual(sStr, oOptions.expected, "The string was correct");
		}
		QUnit.test("Should format the string from '@' to 'enter' ", function (assert) {
			endterTestCase.call(this, {
				assert: assert,
				str: "0111222 2017@Item EGI Unit test",
				expected: "0111222 2017\r\nItem EGI Unit test"
			});
		});
		QUnit.test("Should return empty string when input null", function (assert) {
			endterTestCase.call(this, {
				assert: assert,
				str: null,
				expected: undefined
			});
		});
		
	}
);
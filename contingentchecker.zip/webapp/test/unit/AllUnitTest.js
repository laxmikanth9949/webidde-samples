sap.ui.define([
	"sap/support/supportportalegiregtool/test/unit/model/formatter",
	"sap/support/supportportalegiregtool/test/unit/page/App"
], function() {
	"use strict";
});
sap.ui.require([
	"sap/support/supportportalegiregtool/controller/App.controller"
], function(AppController){
	"use strict";
	
	QUnit.module("App Controller Test", {
		beforeEach: function(){
			this.oController = new AppController();
		},
		afterEach: function(){
			this.oController.destroy();
		}
	});
	
	QUnit.test("1", function(assert){
		var oRes = this.oController.getUserInput();
		assert.strictEqual(oRes, {
			UserID: "Ixxxxxxx",
		    CustomerNum: "", 
		    Check: "",
		    Date_from: "",
			Date_to: ""});
	});
});
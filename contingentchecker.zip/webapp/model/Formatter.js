sap.ui.define([], function() {
	"use strict";
	return {
		enter: function(str) {
			var i;
			if(str !== null){
				i = str.replace(/@/g, "\r\n");
			}
			return i;
		}
	};
});
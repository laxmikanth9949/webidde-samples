sap.ui.define([
	'sap/ui/model/json/JSONModel',
	'sap/ui/Device'
], function (JSONModel, MessageBox, Device) {
	"use strict";

	return {
		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		/*createContingentsModel: function(){
			var oContingentsModel = new JSONModel();
			return oContingentsModel;
		},*/
		createViewModel: function(){
			var oViewModel = new JSONModel({
				visible: true
			});
			return oViewModel;
		}
	};

});
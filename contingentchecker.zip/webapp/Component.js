sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/support/supportportalegiregtool/model/models",
	"sap/m/MessageToast"
], function(UIComponent, ODataModel, JSONModel,models, MessageToast) {
	"use strict";
	return UIComponent.extend("sap.support.supportportalegiregtool.Component", {
		metadata: {
			manifest: "json"
		},
		init: function() {
	/*		var oConfig = this.getMetadata().getConfig();
			this.sConfig = oConfig;
			var EgiRegmodel = new ODataModel(oConfig.requestRemote, {
				useBatch: false
			});
			var that =this;
			  	EgiRegmodel.read("/UserDataSet('ME')", {
			  		success:function(){
			  			
				  		UIComponent.prototype.init.apply(that, arguments);
						var oegiregtool = new ODataModel(oConfig.requestRemote, {
						defaultOperationMode: sap.ui.model.odata.OperationMode.Client,
						useBatch: false,
						defaultUpdateMethod: sap.ui.model.odata.UpdateMethod.Put
				});
			         	that.setModel(oegiregtool, "overall");	
			  		},
			  		error: function() {
			  		 MessageToast.show("Hello World");	
			  		}	
			  	});*/
			// var EgiRegToolmodel = new JSONModel();
			// EgiRegToolmodel.loadData(oConfig.requestRemote+"/UserDataSet('ME')",{},false,"GET");
				// //catch the fail
				// 	EgiRegToolmodel.attachRequestFailed(function(){
		  //           MessageToast.show("Hello World");
		  //          });
			var oConfig = this.getMetadata().getConfig();
			this.sConfig = oConfig;	
			UIComponent.prototype.init.apply(this, arguments);
						var oegiregtool = new ODataModel(oConfig.requestRemote, {
						defaultOperationMode: sap.ui.model.odata.OperationMode.Client,
						useBatch: false,
						defaultUpdateMethod: sap.ui.model.odata.UpdateMethod.Put
				});
			         	this.setModel(oegiregtool, "overall");	
		}
	});

});
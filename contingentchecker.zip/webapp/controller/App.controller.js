sap.ui.define([
	'sap/support/supportportalegiregtool/controller/BaseController',
	"sap/m/MessageToast",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/support/supportportalegiregtool/model/Formatter",
	"sap/support/supportportalegiregtool/model/models"
], function(BaseController, MessageToast, ODataModel, JSONModel, formatter, models) {
	"use strict";
	return BaseController.extend("sap.support.supportportalegiregtool.controller.App", {
		formatter: formatter,
		onInit: function() {
			var checkmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			var that = this;
			checkmodel.read("/UserDataSet('ME')", {
				success: function(oData) {
					var myDate = new Date();
					var year = myDate.getFullYear();
					var oDataYear = {
						time: year
					};

					var oModelTotal = new JSONModel(oDataYear);
					that.getView().byId("timetotal").setModel(oModelTotal, "Year");
					var oModelUsed = new JSONModel(oDataYear);
					that.getView().byId("timeused").setModel(oModelUsed, "Year");
					var myDate = new Date();
					var year = myDate.getFullYear();
					var Date_from = year + "-01-01";
					var Date_to = year + "-12-31";
					var oDataTime = {
						time_from: Date_from,
						time_to: Date_to
					};
					var oModelTime = new JSONModel(oDataTime);
					that.getView().byId("DTI_from").setModel(oModelTime, "Time");
					that.getView().byId("DTI_to").setModel(oModelTime, "Time");
					// set total contingent display
					var flag_total = oData.expert;
					if (flag_total === "X") {
						that.getView().byId("totalContingent").setVisible(true);
					}
				},
				error: function() {
					that.getView().byId("APP").destroyContent();
					var i18nModel = that.geti18nModel();
					var ErrorMessage = i18nModel.getResourceBundle().getText("Authority");
					var Warning = i18nModel.getResourceBundle().getText("Error");
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.warning(
						ErrorMessage, {
							icon: sap.m.MessageBox.Icon.WARNING,
							title: Warning,
							actions: [sap.m.MessageBox.Action.YES]
						});
				}
			});

			//--------------------URL for Search-------------------------
			var oViewModel = models.createViewModel();
			this.setModel(oViewModel, "viewDisplay");
			var custNoModel = new JSONModel();
			this.getView().setModel(custNoModel, "custNoModel");
			this.triggerURLSearch();
			//-------------------add delete icon for input----------------
			this.changeInputIcon();

			//-----------------prepare for Contingent table---------------

			var oContingentsModel = new JSONModel();
			this.setModel(oContingentsModel, "contingentsModel");
		},
		
		changeInputIcon: function() {
			/*sap.m.Input.prototype.onAfterRendering = function(){
				this._getValueHelpIcon().setSrc("sap-icon://sys-cancel");
			};*/
			this.getView().byId("S-UserID")._getValueHelpIcon().setSrc("sap-icon://sys-cancel");
			this.getView().byId("Number")._getValueHelpIcon().setSrc("sap-icon://sys-cancel");
		},

		triggerURLSearch: function() {
			var customer_no = jQuery.sap.getUriParameters().get("customer_no");
			if (customer_no !== null) {
				var custNo = {
					Customer: customer_no
				};
				this.getView().getModel("custNoModel").setData(custNo);
				this.onSearch();
			}
		},

		onDelete: function(oEvent) {
			if (oEvent.getSource().getId().search(/S-UserID/) !== -1) {
				this.getView().byId("S-UserID").setValue("");
			} else {
				this.getView().byId("Number").setValue("");
			}
		},

		geti18nModel: function() {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		},
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onSearch: function(e) { //main
			var that = this;
			var result = that.CheckAuthority();
			that.FilterResult(result);
			this.updateContingentsModel(result);
		},
		//-------------------Contingents Data table-------------------
		getYearNumber: function(Date) {
			var refactDate = this._timeRefactor(Date);
			var year = refactDate.substr(0, 4);
			return year;
		},
		getFilterData: function() {
			this.Filter = [];
			var UserID = this.getView().byId("S-UserID").getValue();
			var filter_user = new sap.ui.model.Filter("suser",
				sap.ui.model.FilterOperator.EQ, UserID);
			this.Filter.push(filter_user);
			var CustomerNum = this.getView().byId("Number").getValue();
			var filter_customer = new sap.ui.model.Filter("Customer",
				sap.ui.model.FilterOperator.EQ, CustomerNum);
			this.Filter.push(filter_customer);
			if (UserID.length === 0 && CustomerNum.length === 0) {
				this.callErrorMessage();
			}
			var Date_from = this.getView().byId("DTI_from").getDateValue();
			var Date_to = this.getView().byId("DTI_to").getDateValue();
			var from_year;
			var to_year;
			if (Date_from && Date_to) {
				from_year = this.getYearNumber(Date_from);
				to_year = this.getYearNumber(Date_to);
			} else {
				var myDate = new Date();
				from_year = myDate.getFullYear().toString();
				to_year = myDate.getFullYear().toString();
			}
			var filter_from = new sap.ui.model.Filter("from_year",
				sap.ui.model.FilterOperator.EQ, from_year);
			this.Filter.push(filter_from);
			
			var filter_to = new sap.ui.model.Filter("to_year",
				sap.ui.model.FilterOperator.EQ, to_year);
			this.Filter.push(filter_to);

		},
		updateContingentsModel: function(result) {
			this.displayViewAccordingAuth(result);
			this.getFilterData();
			var that = this;
			//this.oContingentsModel = this.getModel("contingentsModel");
			var oContingentsData = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			oContingentsData.read("/ContingentsSet", {
				filters: this.Filter,
				success: function(oData, oResponse) {
					var oContingentsModel = new sap.ui.model.json.JSONModel({
						Congtingents: oResponse.data.results
					});
					that.setModel(oContingentsModel, "contingentsModel");
				}
			});
		},
		displayViewAccordingAuth: function(result) {
			var oViewModel = this.getModel("viewDisplay");
			if (result === 3) {
				oViewModel.setProperty("/visible", true);
			} else if (result === 1) {
				oViewModel.setProperty("/visible", false);
			}
		},

		CheckAuthority: function() {
			var that = this;
			var useid;
			var EgiRegToolmodel = new JSONModel();
			EgiRegToolmodel.loadData(that._getRemoteRoot() + "/UserDataSet('ME')", {}, false, "GET");
			//catch the fail
			/*						EgiRegToolmodel.attachRequestFailed(function(){
					            	that.onOpenDialog();
					            });*/
			var that = this;
			//have different authority
			var Authorityesa = EgiRegToolmodel.getData().d.esa;
			var Authorityexpert = EgiRegToolmodel.getData().d.expert;
			// if(Authorityesa == "X" && Authorityexpert!=="X" ){
			if (Authorityexpert == "X") {
				return 3; //  show three table
			}
			// if(Authorityexpert=="X" ){
			if (Authorityesa == "X" && Authorityexpert !== "X") {
				that.getView().byId("showTotalTable").setVisible(false);
				that.getView().byId("timetotal").setVisible(false);
				that.getView().byId("TotalTable").setVisible(false);
				that.getView().byId("table2").setVisible(false);
				that.getView().byId("table3").setVisible(false);
				return 1; //show only one table
			}
		},
		_getRemoteRoot: function() {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			var root = oComp.sConfig.requestRemote;
			return root;
		},
		onOpenDialog: function() {
			var oView = this.getView();
			var oDialog = oView.byId("Dialog");
			if (!oDialog) {
				// create dialog via fragment factory
				oDialog = sap.ui.xmlfragment(oView.getId(), "sap.support.supportportalegiregtool.view.Dialog");
				oView.addDependent(oDialog);
			}
			oDialog.open();
		},
		/*-------------------- filter parameters -------------------------*/
		callErrorMessage: function() {
			var i18nModel = this.geti18nModel();
			var ErrorMessage = i18nModel.getResourceBundle().getText("ErrorMessage");
			var Warning = i18nModel.getResourceBundle().getText("warning");
			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.warning(
				ErrorMessage, {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: Warning,
					actions: [sap.m.MessageBox.Action.YES]
				});
		},
		FilterResult: function(result) {
			var UserID = this.getView().byId("S-UserID").getValue();
			var CustomerNum = this.getView().byId("Number").getValue();

			/*************************************Contingents***********************************/
			var oContingents = new JSONModel();
			oContingents.loadData(this._getRemoteRoot() + "/SUserSet(suser='" + UserID + "',customer='" + CustomerNum + "')", {}, false, "GET");
			var total_contingents = oContingents.getProperty("/d/total_contingents");
			var used_contingents = oContingents.getProperty("/d/used_contingents");
			if (result == 3) { // show two information
				/*************************************Total***********************************/
				var oDataTotal = {
					total: total_contingents
				};
				var oModeltotal = new JSONModel(oDataTotal);
				this.getView().byId("TotalTable").setModel(oModeltotal, "total_contingents");
				/*************************************used***********************************/
				var oDataUsed = {
					used: used_contingents
				};
				var oModelUsed = new JSONModel(oDataUsed);
				this.getView().byId("UsedContingents").setModel(oModelUsed, "used_contingents");
			}
			if (result == 1) { // show only one information
				var oDataUsed = {
					used: used_contingents
				};
				var oModelUsed = new JSONModel(oDataUsed);
				this.getView().byId("UsedContingents").setModel(oModelUsed, "used_contingents");
			}
			// show corresponding cusmtor info
			var customerNumber = oContingents.getProperty("/d/customer");
			//if( customerNumber !== "" && CustomerNum === ""){
			this.getView().byId("Number").setValue(customerNumber);
			CustomerNum = customerNumber;
			//}
			var CustomerName = oContingents.getProperty("/d/customer_name");
			this.getView().byId("Customer_name").setText(CustomerName);
			// get tables data
			var Check = this.getView().byId("checkBox").getSelected();
			var Date_from = this.getView().byId("DTI_from").getDateValue();
			var Date_to = this.getView().byId("DTI_to").getDateValue();
			var oFilters1 = []; //Contract; Support level 
			var oFilters2 = []; //Contract; Support level 
			if (Check == true) {
				var check_result = 'X';
				var filter_check = new sap.ui.model.Filter("current_user_only",
					sap.ui.model.FilterOperator.EQ, check_result);
				oFilters1.push(filter_check);
			}
			if (UserID.length == 0 && CustomerNum.length == 0 && result != 0) {
				this.callErrorMessage();
			}
			if (UserID.length !== 0) {
				var filter0 = new sap.ui.model.Filter("RegUser",
					sap.ui.model.FilterOperator.EQ, UserID);
				oFilters1.push(filter0);
			}
			if (CustomerNum.length !== 0) {
				var filter1 = new sap.ui.model.Filter("RegCustomer",
					sap.ui.model.FilterOperator.EQ, CustomerNum);
				oFilters1.push(filter1);
				var filter2 = new sap.ui.model.Filter("customer",
					sap.ui.model.FilterOperator.EQ, CustomerNum);
				oFilters2.push(filter2);
			}

			if (Date_from && Date_to) {
				var timeFrom = this._timeRefactor(Date_from);
				var timeTo = this._timeRefactor(Date_to);
				var filter1 = new sap.ui.model.Filter("From_date",
					sap.ui.model.FilterOperator.EQ, timeFrom);
				oFilters1.push(filter1);
				var filter2 = new sap.ui.model.Filter("To_date",
					sap.ui.model.FilterOperator.EQ, timeTo);
				oFilters1.push(filter2);

				var filter3 = new sap.ui.model.Filter("From_date",
					sap.ui.model.FilterOperator.EQ, timeFrom);
				oFilters2.push(filter3);
				var filter4 = new sap.ui.model.Filter("To_date",
					sap.ui.model.FilterOperator.EQ, timeTo);
				oFilters2.push(filter4);

			}
			if (Date_from && Date_to) {
				var timeFrom = this._timeRefactor(Date_from);
				var filter1 = new sap.ui.model.Filter("From_date",
					sap.ui.model.FilterOperator.EQ, timeFrom);
				oFilters1.push(filter1);
				var filter2 = new sap.ui.model.Filter("From_date",
					sap.ui.model.FilterOperator.EQ, timeFrom);
				oFilters2.push(filter2);
			}
			if (Date_from && Date_to) {
				var timeTo = this._timeRefactor(Date_to);
				var filter1 = new sap.ui.model.Filter("To_date",
					sap.ui.model.FilterOperator.EQ, timeTo);
				oFilters1.push(filter1);
				var filter2 = new sap.ui.model.Filter("To_date",
					sap.ui.model.FilterOperator.EQ, timeTo);
				oFilters2.push(filter2);
			}
			/*---------------------- read data ---------------------------*/
			var EgiRegmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			var EgiSopportmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			var EgiConmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			var that = this;
			if (result == 3) { //show three table
				EgiRegmodel.read("/RegistrationSet", {
					filters: oFilters1,
					success: function(oData, oResponse) {
						var model_Registration = new sap.ui.model.json.JSONModel({
							EgiRegSet: oResponse.data.results
						});
						that.getView().byId("RegistrationTable").setModel(model_Registration, "EgiReg");
						/*************************************show Customer name ***********************************/
						//var CustomerName = model_Registration.oData.EgiRegSet[0].RegCustomer_name;
						//that.getView().byId("Customer_name").setText(CustomerName);
					}
				});
				EgiSopportmodel.read("/SupportlevelSet", {
					filters: oFilters2,
					success: function(oData, oResponse) {
						var model_Supportlevel = new sap.ui.model.json.JSONModel({
							EgiSupportlevelSet: oResponse.data.results
						});
						that.getView().byId("Support_level_info").setModel(model_Supportlevel, "EgiSupportlevel");
					}
				});

				EgiConmodel.read("/ContractdataSet", {
					filters: oFilters2,
					success: function(oData, oResponse) {
						var model_Contract = new sap.ui.model.json.JSONModel({
							EgiConSet: oResponse.data.results
						});
						that.getView().byId("Contract_det_info").setModel(model_Contract, "EgiContract");
					}
				});
			}
			if (result == 1) { //show only one table
				EgiRegmodel.read("/RegistrationSet", {
					filters: oFilters1,
					success: function(oData, oResponse) {
						var model_Registration = new sap.ui.model.json.JSONModel({
							EgiRegSet: oResponse.data.results
						});
						that.getView().byId("RegistrationTable").setModel(model_Registration, "EgiReg");
					}
				});
			}
		},
		_timeRefactor: function(date) {
			if (date) {
				var Year = date.getFullYear();
				var MM = date.getMonth() + 1;
				var Month = MM < 10 ? "0" + MM : MM.toString();
				var DD = date.getDate();
				var dd = DD < 10 ? "0" + DD : DD.toString();
				var Time = Year + Month + dd;
				return Time;
			}

		}
	});
});
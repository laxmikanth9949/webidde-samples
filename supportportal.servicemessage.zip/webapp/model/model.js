sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/Device"
], function(JSONModel, ODataModel, Device) {
	"use strict";

	return {
		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		
		createNewODataModel: function(sUrl, bBatch){
			return new ODataModel({
				useBatch: bBatch,
				serviceUrl: sUrl
			});
		},

		createInputValueModel: function() {
			var oModel = new JSONModel({
				to: "",
				cc: "",
				subject: "",
				body: ""
			});
			return oModel;
		},
		
		initialInputValueModel: function(oInputValueModel){
			oInputValueModel.setProperty("/subject", "");
			oInputValueModel.setProperty("/has_subscription", "");
			oInputValueModel.setProperty("/body", "");
			oInputValueModel.setProperty("/Substitute", "");
			oInputValueModel.setProperty("/navButton", true);
			return oInputValueModel;
		},

		createEmailTokenValueModel: function() {
			var oModel = new JSONModel({
				SendTo: [/*{
					email: "Deskjet Printer"
				}, {
					email: "LCD Display"
				}*/],
				CCTo: []
			});
			return oModel;
		},
		
		initialEmailTokenValueModel: function(oEmailTokenModel) {
			oEmailTokenModel.setProperty("/SendTo", "");
			oEmailTokenModel.setProperty("/CCTo", "");
			return oEmailTokenModel;
		},
		
		createDetailViewModel: function(){
			var oModel = new JSONModel({
				hasSubscription: "",
				currentUser: "",
				substitute: ""
			});
			return oModel;
		}
	};
});
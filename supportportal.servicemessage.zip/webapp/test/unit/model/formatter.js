sap.ui.define([
	"sap/support/servicemessage/model/formatter"
], function(Formatter) {
	"use strict";

	QUnit.module("formatter - icon color");

	QUnit.test("Should see Positive icon coloer when Rating is 'A'.", function(assert) {
		var sAct = Formatter.PriorityColor.call(this.oController, "A");
		assert.equal(sAct, "Positive", "Icon color is correct!");
	});
	
	QUnit.test("Should see Critical icon color when functional status is 'B'.", function(assert) {
		var sAct = Formatter.PriorityColor.call(this.oController, "B");
		assert.equal(sAct, "Critical", "Icon color is correct!");
	});
	
	QUnit.test("Should see Negative icon color when functional status is 'C'.", function(assert) {
		var sAct = Formatter.PriorityColor.call(this.oController, "C");
		assert.equal(sAct, "Negative", "Icon color is correct!");
	});
	
	QUnit.test("Should see Neutral icon color when functional status is others.", function(assert) {
		var sAct = Formatter.PriorityColor.call(this.oController, "T");
		assert.equal(sAct, "Neutral", "Icon color is correct!");
	});
	
	QUnit.module("formatter - remove prefix 0 ");

	QUnit.test("Should see 123 when CRM_Order is '00123'.", function(assert) {
		var sAct = Formatter.removeLeadingZero.call(this.oController, "00123");
		assert.equal(sAct, "123", "Icon color is correct!");
	});
	
	QUnit.test("Should see 10023 when CRM_Order is '10023'.", function(assert) {
		var sAct = Formatter.removeLeadingZero.call(this.oController, "10023");
		assert.equal(sAct, "10023", "Icon color is correct!");
	});
	
	QUnit.test("Should see 12300 when CRM_Order is '12300'.", function(assert) {
		var sAct = Formatter.removeLeadingZero.call(this.oController, "12300");
		assert.equal(sAct, "12300", "Icon color is correct!");
	});
	
	QUnit.module("formatter - EMail adderss check");
	
	QUnit.test("Should see invalid alert when email address without '@'", function(assert) {
		var sAct = Formatter.emailValueStateCheck.call(this.oController, "sf.com");
		assert.equal(sAct, "Error", "E-Mail address is invalid!");
	});
	
	QUnit.test("Should see alert when email address without '.'", function(assert) {
		var sAct = Formatter.emailValueStateCheck.call(this.oController, "sf@com");
		assert.equal(sAct, "Error", "E-Mail address is invalid!");
	});
	
	QUnit.test("Should see alert when email address without '@'", function(assert) {
		var sAct = Formatter.emailValueStateCheck.call(this.oController, "sf.com");
		assert.equal(sAct, "Error", "E-Mail address is invalid!");
	});
	
	QUnit.test("Should see alert when email address with '/'", function(assert) {
		var sAct = Formatter.emailValueStateCheck.call(this.oController, "sf/com");
		assert.equal(sAct, "Error", "E-Mail address is invalid!");
	});
	
	QUnit.test("Should not see alert when email address is valid", function(assert) {
		var sAct = Formatter.emailValueStateCheck.call(this.oController, "sf@1.com");
		assert.equal(sAct, "None", "E-Mail address is valid!");
	});
	
	QUnit.test("Should see 'Create subscription' button when subscription hasn't been created", function(assert) {
		var sAct = Formatter.determSubscribeButtonName.call(this.oController,"Create subscription", "Update subscription", "");
		assert.equal(sAct, "Create subscription");
	});
	
	QUnit.test("Should see 'Update subscription' button when subscription has been created", function(assert) {
		var sAct = Formatter.determSubscribeButtonName.call(this.oController,"Create subscription", "Update subscription", "X");
		assert.equal(sAct, "Update subscription");
	});
	
	QUnit.test("Should see 'email' icon when message has been subscribed", function(assert){
		var sAct = Formatter.setSubscribeIcon.call(this.oController,"X");
		assert.equal(sAct, "sap-icon://email");
	});
	
	QUnit.test("Shouldn't see 'email' icon when message hasn't been subscribed", function(assert){
		var sAct = Formatter.setSubscribeIcon.call(this.oController,"");
		assert.equal(sAct, "");
	});
	
	QUnit.test("Should see 'Set up auto-forwarding' button and 'auto-forwarding' column when user is hosting partner", function(assert){
		var sAct = Formatter.setAvaliableForSubscribe.call(this.oController,"X");
		assert.equal(sAct, true);
	});
	
	QUnit.test("Should not see 'Set up auto-forwarding' button and 'auto-forwarding' column when user isn't hosting partner", function(assert){
		var sAct = Formatter.setAvaliableForSubscribe.call(this.oController,"");
		assert.equal(sAct, false);
	});
	
	QUnit.test("Should see multi-select button on table when user is hosting partner", function(assert){
		var sAct = Formatter.setTableMode.call(this.oController,"X");
		assert.equal(sAct, "MultiSelect");
	});
	
	QUnit.test("Shouldn't see multi-select button on table when user isn't hosting partner", function(assert){
		var sAct = Formatter.setTableMode.call(this.oController,"");
		assert.equal(sAct, "None");
	});
	
});
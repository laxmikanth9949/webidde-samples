sap.ui.define([
	"sap/support/servicemessage/controller/BaseController",
	"sap/m/Token",
	"sap/ui/model/json/JSONModel",
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog",
	"sap/ui/model/odata/v2/ODataModel",
	'sap/m/MessageToast',
	"sap/support/servicemessage/model/formatter"
], function (BaseController, Token, JSONModel, ValueHelpDialog, ODataModel, MessageToast, formatter) {
	"use strict";
	return BaseController.extend("sap.support.servicemessage.controller.Homepage", {
		formatter: formatter,
		onInit: function () {
			// view init
			var userType = this.getUserType();
			if (userType === "S") {
				this.getView().byId("A1").setVisible(false);
				this.getView().byId("B1").setVisible(false);
			} else {
				this.getView().byId("A0").setVisible(false);
				this.getView().byId("B0").setVisible(false);
			}
			/*
			var oParas = sap.ui.core.Component.getOwnerComponentFor(this.getView()).oData;
			var oURLModel = new JSONModel();
			oURLModel.setData(oParas);
			this.setModel(oURLModel,"URLModel");*/

			var oView = this.getView();
			oView.byId("DTI_to").setDateValue(new Date());
			if (oView.sViewName === "sap.support.servicemessage.view.Homepage") {
				this.getRouter().attachRouteMatched($.proxy(function (e) {
					var view = this.getView();
					var model = view.getModel("overall");
					this.getView().setModel(model, "overall");
					model.setSizeLimit(3000);
				}), this);

			}
			var installmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			var _ofilters = new sap.ui.model.Filter({
				path: "CustomerNo",
				operator: "EQ",
				value1: "GET_ALL"
			});
			var that = this;
			this.model = new sap.ui.model.json.JSONModel();
			//this.getView().byId("installation").getModel("installation").setSizeLimit(1000);
			installmodel.read("/CustomerInstallationSet", {
				filters: [_ofilters],
				success: function (oData, oResponse) {
					var model = new sap.ui.model.json.JSONModel({
						CustomerInstallationSet: oResponse.data.results,
						SizeLimit: 9000
					});
					that.model.setData(model.getData());
					var userCustomerSet = new ODataModel(that._getRemoteRoot(), {
						useBatch: false
					});
					if(that.url !== undefined && that.url) {
					userCustomerSet.read("/UserCustomerSet", {
						success: function (oData, oResponse) {
							var custList = new Array();
							for (var i = 0; i < oData.results.length; i++) {
								custList.push(oData.results[i].CustomerNo);
							}
							// if the customer number is provided in url, validate if it belongs to customer's list and search
							// else, set all the customers by default, for search
							var cust_no = that.getView().byId("customer_no").getSelectedKeys();
							if (cust_no.length !== 0) {
								var validCust = false;
								if (custList) {
									validCust = custList.includes(cust_no[0]);
								}
								if (validCust === false) {
									var infotitle = that.getResourceBundle().getText("information");
									var infoMessage = that.getResourceBundle().getText("NoValidCustomer");
									jQuery.sap.require("sap.m.MessageBox");
									sap.m.MessageBox.error(
										infoMessage, {
											icon: sap.m.MessageBox.Icon.INFORMATION,
											title: infotitle,
											actions: [sap.m.MessageBox.Action.CLOSE]
										});
								} 
								else {
									that.onSearch();
								}
							} 
							else {
								that.getView().byId("customer_no").setSelectedKeys(custList);
								that.onSearch();
							}
						},error: function(oData, oRsponse){
							debugger;
						}
					});
					}
				}
			});  
			this.getView().byId("installation").setModel(this.model, "installation");
			this.getView().byId("installation").getModel("installation").setSizeLimit(9000);
			//this.getView().byId("installation").getModel("installation").setSizeLimit(1000);
			// test setSizeLimit function with mock date
			/*var oModel = new JSONModel(jQuery.sap.getModulePath("sap.support.servicemessage.test.mockdata", "/customerInstallation.json"));
			this.getView().byId("installation").setModel(oModel, "installation");
			this.getView().byId("installation").getModel("installation").setSizeLimit(118);*/

			this.oFilterBar = this.getView().byId("filterBar");
			this.oFilterBar.setShowNotificationFB(true);
			if (this.getSubstitute() === "X") {
				var oVM = sap.ui.getCore().byId("__management0");
				oVM.setEnableManageSaveAsButton(false);
			}

			this.oFilterBar.registerFetchData(this._fetchData);
			this.oFilterBar.registerApplyData(this._applyData);

			this._setDatePickerReadOnly();
			//	this._setProcessorReadOnly();
			//	this._setMultiComboBoxReadOnly();

			var oMuiltiInputSO = oView.byId("serviceOrder");
			oMuiltiInputSO.addValidator(function (args) {
				var text = args.text;
				return new Token({
					key: text,
					text: text
				});
			});
			var oMuiltiInputSI = oView.byId("systemId");
			oMuiltiInputSI.addValidator(function (args) {
				var text = args.text.toUpperCase();
				return new Token({
					key: text,
					text: text
				});
			});

			// var sVariantDefault = this.getView().getModel("view").getProperty("/initialVariant");
			// 	if (sVariantDefault.length > 0) {
			// 		oEvent.getSource().setCurrentVariantId(sVariantDefault);
			// 	}

			var urlParamFilterBarHide = window.location.href.indexOf("filterbarstate=hidden") === -1 ? false : true;
			if (urlParamFilterBarHide === true) {
				this.getView().byId("filterBar").setFilterBarExpanded(false);
			}

			var urlParamGo = window.location.href.indexOf("action=Go") === -1 ? false : true;
			if (urlParamGo === true) {
				this.url = urlParamGo;
				var cust; // pick customer number from url else, from the logged in User info
				var piece = window.location.href.split("&"); //split url to array and find index of customer substring
				var val = piece.findIndex(function (args) {
					return args.includes("customer");
				});
				if (val != -1) {
					var lis = piece[val].split("=");
					cust = lis[1];
				}
				if (cust) {
					this.getView().byId("customer_no").setSelectedKeys(cust);
					// search retrieves results based on above Customer Number. If the above fetched number is not in 
					// customer dropdown(validate against customer's list-read from model-UserCustomerSet), 
					// set a message to user and no search result is retrieved. 
				}
			}

			this.getOwnerComponent().getRouter().attachRoutePatternMatched(this._onRoutePatternMatched, this);
			this.getOwnerComponent().getRouter("homepage1").attachRoutePatternMatched(this._onRoutePatternMatched, this);
			this.getOwnerComponent().getRouter("homepage2").attachRoutePatternMatched(this._onRoutePatternMatched, this);
			this.getOwnerComponent().getRouter("homepage3").attachRoutePatternMatched(this._onRoutePatternMatched, this);
			this.getOwnerComponent().getRouter("homepage4").attachRoutePatternMatched(this._onRoutePatternMatched, this);
			this.getOwnerComponent().getRouter("homepage5").attachRoutePatternMatched(this._onRoutePatternMatched, this);
			this.getOwnerComponent().getRouter("homepage6").attachRoutePatternMatched(this._onRoutePatternMatched, this);
		},

		_onRoutePatternMatched: function (oEvent) { // /Company/202420/0020256312/EFP/SMEWA
			var name = oEvent.getParameter("name");
			var oParas = {};
			if (name === "EWAhomepagewithSysNo") {
				oParas.Visible = false;
				this.setFilterBarVisible(oParas);

				var oArguments = oEvent.getParameters().arguments;
				this.Filter = this.formatURLParaToFilter(oArguments);
				this.getSearchResult(this.Filter, oArguments.ServiceType);
			} else {
				oParas.Visible = true;
				this.setFilterBarVisible(oParas);
			}
		},

		onAfterRendering: function () {
			// dis/enable search variant header visible
			var oParas = this.getOData();
			if (oParas.Visible === false) { //?Customer=202420&Installation=0020256312
				this.setFilterBarVisible(oParas);
				if (this.checkCustomerNum(oParas.Customer)) {
					if (this.checkInstallation(oParas.Installation)) {
						this.Filter = this.formatURLParaToFilter(oParas);
						this.getSearchResult(this.Filter, oParas.ServiceType);
					}
				}
			}
		},

		setFilterBarVisible: function (oParas) {
			var oURLModel = new JSONModel();
			oURLModel.setData(oParas);
			this.setModel(oURLModel, "URLModel");
		},

		getCustomerList: function (oCustomerModel) {
			var listLength = oCustomerModel.getData().d.results.length;
			var aCustomer = [];
			for (var i = 0; i < listLength; i++) {
				if (oCustomerModel.getData().d.results[i].CustomerNo) {
					aCustomer.push(oCustomerModel.getData().d.results[i].CustomerNo);
				}
			}
			return aCustomer;
		},

		checkValidity: function (aNumbers, sNumber) {
			if (aNumbers.length === 0) {
				return false;
			} else {
				var iCustomer = aNumbers.length;
				for (var j = 0; j < iCustomer; j++) {
					if (aNumbers[j].includes(sNumber)) {
						return true;
					}
				}
			}
			return false;
		},

		checkCustomerNum: function (sCustomer) {
			//var i18nModel = this.geti18nModel();
			var infotitle = this.getResourceBundle().getText("information");
			if (!sCustomer) {
				var infoMessage = this.getResourceBundle().getText("NoneCustomer");
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error(
					infoMessage, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: infotitle,
						actions: [sap.m.MessageBox.Action.CLOSE]
					});
				return false;
			} else {
			//	if (this.getUserType() === "S") {
					var oCustomerModel = new JSONModel();
					oCustomerModel.loadData("/services/odata/svt/servicemessage/" + "UserCustomerSet", {}, false, "GET");
					var aCustomer = this.getCustomerList(oCustomerModel);
					if (!this.checkValidity(aCustomer, sCustomer)) {
						var noValidCus = this.getResourceBundle().getText("NoValidCustomer");
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.error(
							noValidCus, {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: infotitle,
								actions: [sap.m.MessageBox.Action.CLOSE]
							});
					} else {
						return true;
					}
				/*} else {
					return true;
				}*/

			}
		},
		getInstallationList: function (oIntallationModel) {
			var listLength = oIntallationModel.getData().d.results.length;
			var aInstallation = [];
			for (var i = 0; i < listLength; i++) {
				if (oIntallationModel.getData().d.results[i].InstallationNo) {
					aInstallation.push(oIntallationModel.getData().d.results[i].InstallationNo);
				}
			}
			return aInstallation;
		},
		checkInstallation: function (sIntallation) {
			if (!sIntallation) {
				return true;
			} else {
				if (this.getUserType() === "S") {
					var oIntallationModel = new JSONModel();
					oIntallationModel.loadData("/services/odata/svt/servicemessage/" + "CustomerInstallationSet?$filter=CustomerNo eq 'GET_ALL'", {},
						false, "GET");
					var aInstallation = this.getInstallationList(oIntallationModel);
					if (!this.checkValidity(aInstallation, sIntallation)) {
						var infotitle = this.getResourceBundle().getText("information");
						var noValidCus = this.getResourceBundle().getText("NoValidInstal");
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.error(
							noValidCus, {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: infotitle,
								actions: [sap.m.MessageBox.Action.CLOSE]
							});
					} else {
						return true;
					}
				} else {
					return true;
				}
			}
		},

		formatURLParaToFilter: function (oParas) {
			var oFilters = [];
			if (oParas.Customer) {
				var filter0 = new sap.ui.model.Filter("Customer",
					sap.ui.model.FilterOperator.EQ, oParas.Customer);
				oFilters.push(filter0);
			}
			if (oParas.Installation) {
				var filter1 = new sap.ui.model.Filter("Installation",
					sap.ui.model.FilterOperator.EQ, oParas.Installation);
				oFilters.push(filter1);
			}

			if (oParas.SystemID) {
				var filter2 = new sap.ui.model.Filter("SystemID",
					sap.ui.model.FilterOperator.EQ, oParas.SystemID);
				oFilters.push(filter2);
			}
			if (oParas.SystemNo) {
				var filter3 = new sap.ui.model.Filter("SystemNumber",
					sap.ui.model.FilterOperator.EQ, oParas.SystemNo);
				oFilters.push(filter3);
			}
			if (oParas.ServiceType) {
				var filter4 = new sap.ui.model.Filter("Themk",
					sap.ui.model.FilterOperator.EQ, oParas.ServiceType);
				oFilters.push(filter4);
			}
			return oFilters;
		},

		/*onBeforeRenderingPicker: function() {
			var selectedItems = this.getView().byId("customer_no").getSelectedItems();
			var oFilters = [];
			for (var i = 0; i < selectedItems.length; i++) {
				var _ofilters = new sap.ui.model.Filter("CustomerNo",
					sap.ui.model.FilterOperator.EQ, selectedItems[i].getKey());
				oFilters.push(_ofilters);
			}
			var that = this;
			if (oFilters.length === 0) {
				var ofilters = new sap.ui.model.Filter({
					path: "CustomerNo",
					operator: "EQ",
					value1: "GET_ALL"
				});
				oFilters.push(ofilters);
			}
			// new model : local
			var installmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			this.model = new sap.ui.model.json.JSONModel();
			//this.getView().byId("installation").getModel("installation").setSizeLimit(1000);
			installmodel.read("/CustomerInstallationSet", {
				filters: [_ofilters],
				success: function(oData, oResponse) {
					var model = new sap.ui.model.json.JSONModel({
						CustomerInstallationSet: oResponse.data.results,
						SizeLimit: 1000
					});
					that.model.setData(model.getData());
				}
			});
			this.getView().byId("installation").setModel(this.model, "installation");
			this.getView().byId("installation").getModel("installation").setSizeLimit(1000);
		},*/

		_setVariantFeature: function (e) {
			if (this.getSubstitute() === "X") {
				var oVM = sap.ui.getCore().byId("__management0");
				oVM.currentVariantSetModified(false);
			}
		},
		_setDatePickerReadOnly: function () {
			sap.m.DatePicker.prototype.onAfterRendering = function (e) {
				$('#' + e.srcControl.getId() + '-inner').prop('readonly', true);
			};
		},
		/*_setProcessorReadOnly: function() {
			sap.m.MultiInput.prototype.onAfterRendering = function(e) {
				if (e.srcControl.getId().indexOf("processor") !== -1) {
					$('#' + e.srcControl.getId() + '-inner').prop('readonly', true);
				}
			};
		},*/
		_setMultiComboBoxReadOnly: function () {
			sap.m.MultiComboBox.prototype.onAfterRendering = function (e) {
				if (e.srcControl.getId().indexOf("installation") === -1) {
					$('#' + e.srcControl.getId() + '-inner').prop('readonly', true);
				}
			};
		},

		/*	_filterBarInitialized: function(oEvent) {
				var sVariant = this.getView().getModel("view").getProperty("/initialVariant");
				if (sVariant.length > 0) {
					oEvent.getSource().setCurrentVariantId(sVariant);
				}
			},*/

		_afterVariantSaved: function (oEvent) {
			sap.ui.getCore().getEventBus().publish("overviewpage", "refresh", {
				source: "servicemessage",
				target: "servicemessage"
			});
		},

		_onChange: function (oEvent) {
			this.oFilterBar = this.getView().byId("filterBar");
			if (this.oFilterBar) {
				this.oFilterBar.fireFilterChange(oEvent);
			}
			this._setVariantFeature();
		},

		_onChangeAndSearch: function (oEvent) {
			this.oFilterBar = this.getView().byId("filterBar");
			if (this.oFilterBar) {
				this.oFilterBar.fireFilterChange(oEvent);
			}
			this.onSearch();
			this._setVariantFeature();
		},

		_onChangeAndSearchByType: function (oEvent) {
			this.oFilterBar = this.getView().byId("filterBar");
			if (this.oFilterBar) {
				this.oFilterBar.fireFilterChange(oEvent);
			}
			if (oEvent.getParameters().type === "added") {
				this.onSearch();
			}
			this._setVariantFeature();
		},
		_fetchData: function () {

			var sGroupName;
			var oJsonParam;
			var oJsonData = [];

			var oItems = this.getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				oJsonParam = {};
				sGroupName = null;
				if (oItems[i].getGroupName) {
					sGroupName = oItems[i].getGroupName();
					oJsonParam.group_name = sGroupName;
				}

				oJsonParam.name = oItems[i].getName();
				var oControl = this.determineControlByFilterItem(oItems[i]);
				if (!oControl) {
					continue;
				}
				switch (oJsonParam.name) {
				case "processor":
				case "serviceOrder":
				case "systemId":
					var aTokens = oControl.getTokens();
					var oArray = new Array();
					for (var j = 0; j < aTokens.length; j++) {
						oArray.push(aTokens[j].getText());
					}
					oJsonParam.value = oArray;
					oJsonData.push(oJsonParam);
					break;
				case "customerNumber0":
				case "installation0":
				case "serviceType":
				case "status":
					oJsonParam.value = oControl.getSelectedKeys();
					oJsonData.push(oJsonParam);
					break;
				case "sessionDateFrom":
				case "sessionDateTo":
					if (oControl.getValue() !== "") {
						var Date_stemp = oControl.getValue().split("/");
						if (Date_stemp.length !== 1) {
							for (var k = 0; k < 3; k++) {
								if (Date_stemp[k].length === 1) {
									Date_stemp[k] = "0" + Date_stemp[k];
								}
							}
							var Time = "20" + Date_stemp[2] + Date_stemp[0] + Date_stemp[1];
						} else {
							var Date_temp = oControl.getValue().split(".");
							Time = Date_temp[2] + Date_temp[1] + Date_temp[0];
						}
						oJsonParam.value = Time;
					} else {
						oJsonParam.value = oControl.getValue();
					}

					oJsonData.push(oJsonParam);
					break;
				default:
					oJsonParam.value = oControl.getValue();
					oJsonData.push(oJsonParam);
					break;
				}

			}

			return oJsonData;

		},
		_applyData: function (oJsonData) {
			var oItems = this.getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				var oControl = this.determineControlByFilterItem(oItems[i]);
				if (oControl) {
					switch (oItems[i].getName()) {
					case "processor":
					case "serviceOrder":
					case "systemId":
						oControl.setTokens([]);
						break;
					case "customerNumber0":
					case "installation0":
					case "serviceType":
					case "status":
						oControl.setSelectedKeys([]);
						break;
					default:
						oControl.setValue("");
						break;
					}
				}
			}

			var sGroupName;

			if (oJsonData === null) {
				return;
			}

			for (i = 0; i < oJsonData.length; i++) {

				sGroupName = null;

				if (oJsonData[i].group_name) {
					sGroupName = oJsonData[i].group_name;
				}

				oControl = this.determineControlByName(oJsonData[i].name, sGroupName);
				if (!oControl) {
					continue;
				}

				switch (oJsonData[i].name) {
				case "processor":
				case "serviceOrder":
				case "systemId":
					var o = oJsonData[i].value;
					var oArray = [];
					if (o.constructor === Array) {
						oArray = o;
					} else {
						if (o.length) {
							oArray.push(o);
						}
					}
					var aToken = [];
					for (var j = 0; j < oArray.length; j++) {
						aToken.push(new sap.m.Token({
							key: oArray[j],
							text: oArray[j]
						}));
					}
					oControl.setTokens(aToken);
					break;
				case "customerNumber0":
				case "installation0":
				case "serviceType":
				case "status":
					//case "System":
					oControl.setSelectedKeys(oJsonData[i].value);
					break;
				case "sessionDateFrom":
				case "sessionDateTo":
					if (oJsonData[i].value !== "") {
						var DateTemp = oJsonData[i].value;
						var Date_stemp = DateTemp.split("/");
						var Time;
						if (Date_stemp.length !== 1) {
							for (var k = 0; k < 3; k++) {
								if (Date_stemp[k].length === 1) {
									Date_stemp[k] = "0" + Date_stemp[k];
								}
							}
							Time = Date_stemp[1] + "." + Date_stemp[0] + "." + "20" + Date_stemp[2];

						} else {
							Time = DateTemp.substr(6, 2) + "." + DateTemp.substr(4, 2) + "." + DateTemp.substr(0, 4);
						}

					}
					oControl.setValue(Time);
					break;
				default:
					oControl.setValue(oJsonData[i].value);
					break;
				}
			}
		},

		_handleMultiComboxSelectionChange: function (oEvent, id) {
			var changedItemName = oEvent.getParameters().changedItem.getText();
			var changedItemStatus = oEvent.getParameters().selected;
			var oMultiComBox = this.getView().byId(id);

			if (changedItemName === "Select All") {
				if (changedItemStatus === true) {
					oMultiComBox.setSelectedItems(oMultiComBox.getItems());
				} else if (changedItemStatus === false) {
					oEvent.getSource().removeAllSelectedItems();
				}
			} else {
				var itemsNumber = oMultiComBox.getItems().length;
				var selectedItemsNumber = oMultiComBox.getSelectedItems().length;
				if (selectedItemsNumber < itemsNumber && oMultiComBox.getSelectedKeys()[0] === "") {
					oMultiComBox.removeSelectedItem(oMultiComBox.getItems()[0]);
				} else if (selectedItemsNumber + 1 === itemsNumber) {
					oMultiComBox.setSelectedItems(oMultiComBox.getItems());
				}
			}
		},

		handleCustomerSelectionChange: function (oEvent) {
			this._handleMultiComboxSelectionChange(oEvent, "customer_no");
		},
		handleInstallationSelectionChange: function (oEvent) {
			this._handleMultiComboxSelectionChange(oEvent, "installation");
		},
		handleStatusSelectionChange: function (oEvent) {
			if (this.getUserType() === "S") {
				this._handleMultiComboxSelectionChange(oEvent, "status");
			}
		},

		handleServiceTypeSelectionChange: function (oEvent) {
			if (this.getUserType() === "S") {
				this._handleMultiComboxSelectionChange(oEvent, "serviceType");
			}
		},

		handleCustomerSelectionFinish: function (oEvent) {
			// regist old selcted items's Keys of installation
			var oInstalMutiCombox = this.getView().byId("installation");
			this.installstion_SelectedItems = oInstalMutiCombox.getSelectedItems();
			var allOldSelectedKeys = [];
			for (var i = 0; i < this.installstion_SelectedItems.length; i++) {
				var eachSelectedKeys = this.installstion_SelectedItems[i].getKey();
				if (this.installstion_SelectedItems[i].getText() === "Select All") {
					this.SelectedAll = "true";
				}
				allOldSelectedKeys.push(eachSelectedKeys);
			}

			// get new installation model
			var selectedItems = oEvent.getParameter("selectedItems");
			var oFilters = [];
			for (var j = 0; j < selectedItems.length; j++) {
				var _ofilters = new sap.ui.model.Filter("CustomerNo",
					sap.ui.model.FilterOperator.EQ, selectedItems[j].getKey());
				oFilters.push(_ofilters);
			}
			var that = this;
			if (oFilters.length === 0) {
				var ofilters = new sap.ui.model.Filter({
					path: "CustomerNo",
					operator: "EQ",
					value1: "GET_ALL"
				});
				oFilters.push(ofilters);
			}
			// new model : local
			var installmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			this.model = new sap.ui.model.json.JSONModel();
			installmodel.read("/CustomerInstallationSet", {
				filters: oFilters,
				success: function (oData, oResponse) {
					var model = new sap.ui.model.json.JSONModel({
						CustomerInstallationSet: oResponse.data.results
					});
					that.model.setData(model.getData());
					if (that.SelectedAll === "true") {
						if (that.installstion_SelectedItems.length < that.model.oData.CustomerInstallationSet.length) {
							that.installstion_SelectedItems.shift();
						}
					}
					that.getView().byId("installation").setSelectedItems(that.installstion_SelectedItems);
				}
			});
			this.getView().byId("installation").setModel(this.model, "installation");
			this.getView().byId("installation").getModel("installation").setSizeLimit(9000);
		},

		/*handleAULiveChange: function(oEvent) {
			var newSUValue = oEvent.getParameter("value");
			if (newSUValue !== "") {
				this.byId("processor").setValueState("Error");
			} else {
				this.byId("processor").setValueState("None");
			}
		},*/

		handleSOLiveChange: function (oEvent) {
			var newSOValue = oEvent.getParameter("value");
			if (this._soCheck(newSOValue)) {
				this.byId("serviceOrder").setValueState("None");
			} else {
				this.byId("serviceOrder").setValueState("Error");
			}
		},

		_soCheck: function (oString) {
			if (oString.length === 8) {
				if (((oString.substr(0, 2) === "73") || (oString.substr(0, 2) === "75")) && /^\d+$/.test(oString.substr(1, 8))) {
					return true;
				}
			} else if (oString === "") {
				return true;
			}
			return false;
		},
		handleSILiveChange: function (oEvent) {
			var newSIValue = oEvent.getParameter("value");
			if (this._siCheck(newSIValue)) {
				this.byId("systemId").setValueState("None");
			} else {
				this.byId("systemId").setValueState("Error");
			}
		},

		_siCheck: function (oString) {
			if (oString.length === 3) {
				if (/^[a-zA-Z]+$/.test(oString)) {
					return true;
				}
			} else if (oString === "") {
				return true;
			}
			return false;
		},
		/*refreshModel: function() {
			this.getView().byId("installation").getModel("installation").refresh();
			this.getView().byId("installation").getModel("installation").setSizeLimit(500);
		},*/

		/*addSnappedLabel: function() {
			var oSnappedLabel = this.getSnappedLabel();
			oSnappedLabel.attachBrowserEvent("click", this.onToggleHeader, this);
			this.getPageTitle().addSnappedContent(oSnappedLabel);
		},

		getSnappedLabel: function() {
			return new sap.m.Label({
				text: "{/Filter/text}"
			});
		},

		getPageTitle: function() {
			return this.getPage().getTitle();
		},

		getPage: function() {
			return this.getView().byId("dynamicPageId");
		},

		onToggleHeader: function() {
			this.getPage().setHeaderExpanded(!this.getPage().getHeaderExpanded());
		},*/

		onHelpProcessor: function () {
			var that = this;
			this.aKeys = ["suser", "fullname"];
			var i18nModel = this.geti18nModel();
			this.theTokenInput = this.getView().byId("processor");
			this.theTokenInput.setEnableMultiLineMode(sap.ui.Device.system.phone);
			this.oValueHelpDialog = new ValueHelpDialog({
				id: "helpProcessor",
				title: "{i18n>Processor}",
				supportMultiselect: false,
				supportRanges: false,
				supportRangesOnly: false,
				key: this.aKeys[0],
				descriptionKey: this.aKeys[1],
				stretch: sap.ui.Device.system.phone,

				ok: function (oControlEvent) {
					that.aTokens = oControlEvent.getParameter("tokens");
					that.theTokenInput.setTokens([that.aTokens[that.aTokens.length - 1]]);
					that._onChange();
					that.oValueHelpDialog.close();
				},

				cancel: function (oControlEvent) {
					that.oValueHelpDialog.close();
				},

				afterClose: function () {
					that.oValueHelpDialog.destroy();
				}
			});

			/*---------------------------------- table content------------------------------*/
			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "SAP Support ID",
					template: "suser"
				}, {
					label: "First Name",
					template: "firstname"
				}, {
					label: "Last Name",
					template: "lastname",
					demandPopin: true
				}]
			});
			this.oValueHelpDialog.getTable().setModel(oColModel, "columns");
			this.oValueHelpDialog.setTokens(this.theTokenInput.getTokens());

			/* -----------------------------Filter bar-------------------------------------*/
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: false,
				filterBarExpanded: true,
				showFilterConfiguration: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterItems: [new sap.ui.comp.filterbar.FilterItem({
						name: "A",
						label: "SAP Support ID",
						control: new sap.m.Input("S_User", {
							change: $.proxy(function (oEvent) {
								this._getResultByInput(oEvent);
							}, this)
						})
					}),
					new sap.ui.comp.filterbar.FilterItem({
						name: "B",
						label: "First name",
						control: new sap.m.Input("firstName", {
							change: $.proxy(function (oEvent) {
								this._getResultByInput(oEvent);
							}, this)
						})
					}),
					new sap.ui.comp.filterbar.FilterItem({
						name: "C",
						label: "Last name",
						control: new sap.m.Input("lastName", {
							change: $.proxy(function (oEvent) {
								this._getResultByInput(oEvent);
							}, this)
						})
					})
				],
				search: $.proxy(function (oEvent) {
					this._getResultByGo(oEvent);
				}, this)
			});

			this.oValueHelpDialog.setModel(i18nModel, "i18n");
			this.oValueHelpDialog.setFilterBar(oFilterBar);
			if (this.theTokenInput.$().closest(".sapUiSizeCompact").length > 0) { // check if the Token field runs in Compact mode
				this.oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			} else {
				this.oValueHelpDialog.addStyleClass("sapUiSizeCozy");
			}
			this.oValueHelpDialog.open();
		},

		_getResultByInput: function () {
			var sUser, firstName, lastName;
			var oItems = this.oValueHelpDialog.getFilterBar().getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				var oControl = this.oValueHelpDialog.getFilterBar().determineControlByFilterItem(oItems[i]);
				if (!oControl) {
					continue;
				}
				switch (oItems[i].getName()) {
				case "A":
					sUser = oControl.getValue().toLocaleUpperCase();
					break;
				case "B":
					firstName = oControl.getValue();
					break;
				case "C":
					lastName = oControl.getValue();
					break;
				default:
					break;
				}
			}
			this._search(sUser, firstName, lastName);
		},
		_getResultByGo: function (oEvent) {
			var sUser = oEvent.getParameters().selectionSet[0].getValue();
			var firstName = oEvent.getParameters().selectionSet[1].getValue();
			var lastName = oEvent.getParameters().selectionSet[2].getValue();
			this._search(sUser, firstName, lastName);
		},
		_search: function (sUser, firstName, lastName) {
			var that = this;
			var i18nModel = this.geti18nModel();
			var ProcessorModel = new ODataModel(that._getRemoteRoot(), {
				useBatch: false
			});
			var Filters = [];
			if (sUser !== "") {
				var _ofilter_suser = new sap.ui.model.Filter({
					path: "suser",
					operator: "EQ",
					value1: sUser.toLocaleUpperCase()
				});
				Filters.push(_ofilter_suser);
			}
			if (firstName !== "") {
				var _ofilter_firstname = new sap.ui.model.Filter({
					path: "firstname",
					operator: "EQ",
					value1: firstName
				});
				Filters.push(_ofilter_firstname);
			}
			if (lastName !== "") {
				var _ofilter_lastname = new sap.ui.model.Filter({
					path: "lastname",
					operator: "EQ",
					value1: lastName
				});
				Filters.push(_ofilter_lastname);
			}
			if (Filters.length === 0) {
				var noSearchCriteria = i18nModel.getResourceBundle().getText("noSearchCriteria");
				sap.m.MessageToast.show(noSearchCriteria);
				return;
			}
			ProcessorModel.read("/SUserSet", {
				filters: Filters,
				success: function (oData, oResponse) {
					var oRowsModel = new sap.ui.model.json.JSONModel({
						SUserSet: oResponse.data.results
					});

					that.oValueHelpDialog.getTable().setModel(oRowsModel);
					if (that.oValueHelpDialog.getTable().bindRows) {
						that.oValueHelpDialog.getTable().bindRows("/SUserSet");
					}
					var i18nModel1 = that.geti18nModel();
					var searchResult = oRowsModel.getData().SUserSet.length;
					if (searchResult === 0) {
						var notData = i18nModel.getResourceBundle().getText("noData");
						sap.m.MessageToast.show(notData);
					} else {
						var searchCompleted = i18nModel1.getResourceBundle().getText("searchCompleted");
						MessageToast.show(searchCompleted);
					}
				}
			});
		},

		_timeRefactor: function (date) {
			if (date !== "") {
				var Time;
				var Date_stemp = date.split("/");
				if (Date_stemp.length !== 1) {
					for (var k = 0; k < 3; k++) {
						if (Date_stemp[k].length === 1) {
							Date_stemp[k] = "0" + Date_stemp[k];
						}
					}
					Time = "20" + Date_stemp[2] + Date_stemp[0] + Date_stemp[1];
				} else {
					var Date_temp = date.split(".");
					Time = Date_temp[2] + Date_temp[1] + Date_temp[0];
				}
				return Time;
			}
		},
		/*_timeRefactorToDisplay: function(date) {
			if (date !== "") {
				var Date_stemp = date.split("/");
				for (var k = 0; k < 3; k++) {
					if (Date_stemp[k].length === 1) {
						Date_stemp[k] = "0" + Date_stemp[k];
					}
				}
				var Time = "20" + Date_stemp[2] + Date_stemp[0] + Date_stemp[1];
				return Time;
			}
		},*/
		_checkMandatorySearchCriteria: function (userType, Customer, installation, serviceOrder) {
			//var i18nModel = this.geti18nModel();
			var infotitle = this.getResourceBundle().getText("infoMessage");
			if (userType === "S") {
				if (Customer.length === 0) {
					var infoMessage = this.getResourceBundle().getText("infoMessage");
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.error(
						infoMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: infotitle,
							actions: [sap.m.MessageBox.Action.CLOSE]
						});
					return false;
				}
			} else {
				if (Customer.length === 0 && installation.length === 0 && serviceOrder.length === 0) {
					var infoMessage1 = this.getResourceBundle().getText("infoMessage1");
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.error(
						infoMessage1, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: infotitle,
							actions: [sap.m.MessageBox.Action.CLOSE]
						});
					return false;
				}
			}
		},

		onSearch: function (e) {
			var oView = this.getView();
			/*------------------------ filter parameters ---------------------*/
			// Customer No.
			/*var i18nModel = this.geti18nModel();
			var infoMessage = i18nModel.getResourceBundle().getText("infoMessage");
			var infoMessage1 = i18nModel.getResourceBundle().getText("infoMessage1");
			var infotitle = i18nModel.getResourceBundle().getText("information");*/
			var customer_no;
			var userType = this.getUserType();
			if (this.getView().byId("A0").getVisible() === true) {
				customer_no = this.getView().byId("customer_no").getSelectedKeys();
				/*if (customer_no.length === 0) {
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.error(
						infoMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: infotitle,
							actions: [sap.m.MessageBox.Action.CLOSE]
						});
					return;
				}*/
			} else if (this.getView().byId("A1").getVisible() === true) {
				var customer_id = this.getView().byId("customer_no_0").getValue();
				if (customer_id !== "") {
					var temp_customer = [];
					temp_customer.push(customer_id);
					customer_no = temp_customer;
				} else {
					customer_no = [];
				}
			}
			// Installation NO.
			var installation_Number;
			if (this.getView().byId("B0").getVisible() === true) {
				installation_Number = this.getView().byId("installation").getSelectedKeys();
			} else if (this.getView().byId("B1").getVisible() === true) {
				var installation_No = this.getView().byId("installation_0").getValue();
				if (installation_No !== "") {
					var temp_installation = [];
					temp_installation.push(installation_No);
					installation_Number = temp_installation;
				} else {
					installation_Number = [];
				}

				/*	if (customer_no.length === 0 && installation_Number.length === 0) {
						jQuery.sap.require("sap.m.MessageBox");
						sap.m.MessageBox.error(
							infoMessage1, {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: infotitle,
								actions: [sap.m.MessageBox.Action.CLOSE]
							});
						return;
					}*/
			}
			var serviceOrder = oView.byId("serviceOrder").getTokens();
			if (this._checkMandatorySearchCriteria(userType, customer_no, installation_Number, serviceOrder) === false) {
				return;
			}
			var processor = oView.byId("processor").getTokens();
			var serviceType = oView.byId("serviceType").getSelectedKeys();

			var status = oView.byId("status").getSelectedKeys();
			var Date_from = oView.byId("DTI_from").getValue();
			var Date_to = oView.byId("DTI_to").getValue();
			var systemId = oView.byId("systemId").getTokens();
			var oFilters = [];
			if (customer_no.length !== 0) {
				for (var i = 0; i < customer_no.length; i++) {
					var filter0 = new sap.ui.model.Filter("Customer",
						sap.ui.model.FilterOperator.EQ, customer_no[i]);
					oFilters.push(filter0);
				}
			}

			if (installation_Number.length !== 0) {
				for (var j = 0; j < installation_Number.length; j++) {
					var filter2 = new sap.ui.model.Filter("Installation",
						sap.ui.model.FilterOperator.EQ, installation_Number[j]);
					oFilters.push(filter2);
				}
			}

			if (processor.length !== 0) {
				var processorNum = this.getProcessorKey(processor[0].getKey());
				var filter3 = new sap.ui.model.Filter("Aktion_User",
					sap.ui.model.FilterOperator.EQ, processorNum);
				oFilters.push(filter3);

			}
			if (serviceType.length !== 0) {
				for (var i = 0; i < serviceType.length; i++) {
					var filter4 = new sap.ui.model.Filter("Themk",
						sap.ui.model.FilterOperator.EQ, serviceType[i]);
					oFilters.push(filter4);
				}
			}
			if (serviceOrder.length !== 0) {
				for (var k = 0; k < serviceOrder.length; k++) {
					var filter7 = new sap.ui.model.Filter("CRM_Order",
						sap.ui.model.FilterOperator.EQ, serviceOrder[k].getKey());
					oFilters.push(filter7);
				}
			}
			if (status.length !== 0) {
				for (var j = 0; j < status.length; j++) {
					var filter5 = new sap.ui.model.Filter("Status",
						sap.ui.model.FilterOperator.EQ, status[j]);
					oFilters.push(filter5);
				}

			}
			if (Date_from !== "" && Date_to !== "") {
				var timeFrom = this._timeRefactor(Date_from);
				var timeTo = this._timeRefactor(Date_to);
				var filter6 = new sap.ui.model.Filter("Last_Sess_Dat",
					sap.ui.model.FilterOperator.BT, timeFrom, timeTo);
				oFilters.push(filter6);
			}
			if (systemId.length !== 0) {
				for (var n = 0; n < systemId.length; n++) {
					var filter8 = new sap.ui.model.Filter("SystemID",
						sap.ui.model.FilterOperator.EQ, systemId[n].getKey());
					oFilters.push(filter8);
				}
			}
			this.Filter = oFilters;
			/*---------------------- read data ---------------------------*/
			this.getSearchResult(oFilters);

		},
		getTxt: function (oData, sType) {
			var listLength = oData.length;
			var sTxt = "";
			for (var i = 0; i < listLength; i++) {
				if (oData[i].Service_Type === sType) {
					return oData[i].ServiceType_Txt;
				}
			}
			return sTxt;
		},
		getServiceTypeTxt: function (sType) {
			var oServiceTypeModel = new JSONModel();
			oServiceTypeModel.loadData("/services/odata/svt/servicemessage/" + "ServiceTypeSet", {}, false, "GET");
			var sServiceTypeTxt = this.getTxt(oServiceTypeModel.getData().d.results, sType);
			return sServiceTypeTxt;
		},
		getMessageToastContent: function (sType) {
			var searchCompletedInfo;
			if (sType) {
				var sServiceTypeTxt = this.getServiceTypeTxt(sType);
				if (sServiceTypeTxt) {
					searchCompletedInfo = this.getResourceBundle().getText("SearchCompletedWithST", [sServiceTypeTxt]);
				}
			}
			if (!searchCompletedInfo) {
				searchCompletedInfo = this.getResourceBundle().getText("searchCompleted");
			}
			return searchCompletedInfo;
		},

		getSearchResult: function (oFilters, sType) {
			var ServiceMsgmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: true
			});
			var that = this;
			ServiceMsgmodel.read("/ServiceMessageSet", {
				filters: oFilters,
				success: function (oData, oResponse) {
					that.getView().setBusy(false);
					var model = new sap.ui.model.json.JSONModel({
						ServiceMessageSet: oData.results
					});
					that.getView().setModel(model, "serviceMsg");
					var searchCompletedInfo = that.getMessageToastContent(sType);
					MessageToast.show(searchCompletedInfo);
				}
			});
			this.getView().setBusy(true);
		},

		onDownload: function () {
			var URL = this._getRemoteRoot() + "DownloadSet?$filter=";
			var regist_path;
			for (var i = 0; i < this.Filter.length; i++) {
				var Operator = this.Filter[i].sOperator;
				if (Operator === "EQ") {
					var Path = this.Filter[i].sPath;
					if (Path === "Aktion_User") {
						Path = "Action_User";
					}
					var Value = this.Filter[i].oValue1;
					var fixString = "(" + Path + " eq '" + Value + "') and ";
					URL += fixString;
					if (this.Filter[i + 1] && this.Filter[i + 1].sPath === Path) {
						URL = URL.substr(0, URL.length - 6);
						URL += " or ";
						var next_same = "true";
					}
					if (this.Filter[i - 1] && this.Filter[i - 1].sPath === Path) {
						var index = URL.search(Path + " eq '" + Value);
						URL = URL.substr(0, index - 1);
						URL += fixString.substr(1);
						if (next_same === "true") {
							URL = URL.substr(0, URL.length - 6);
							URL += " or ";
						}
					}
					next_same = "false";
				}
				if (Operator === "BT") {
					var Path = this.Filter[i].sPath;
					var Value1 = this.Filter[i].oValue1;
					var Value2 = this.Filter[i].oValue2;
					URL += "(" + Path + " ge '" + Value1 + "' and " + Path + " le '" + Value2 + "') and";
				}
			}
			URL = URL.substr(0, URL.length - 4);
			URL += "&$format=xlsx";
			var pDownload = window.open(URL, "_blank");
		},

		getProcessorKey: function (processorKey) {
			var processorNum;
			if (processorKey.length !== 11) {
				processorNum = processorKey.split("(")[1].split(")")[0];
			} else {
				processorNum = processorKey;
			}
			return processorNum;
		},

		/*getSelect: function(sId) {
			return this.getView().byId(sId);
		},*/

		onNavigatetoInfoPageAndGetGeneralText: function (oEvent) {
			var eventSource = oEvent.getSource().getParent().getBindingContext("serviceMsg");
			var selectedIndex = eventSource.sPath.split("/")[2];
			var selectedPointer = eventSource.oModel.oData.ServiceMessageSet[selectedIndex].Pointer;
			this._globalPointer = selectedPointer;
			//var serviceThemk = eventSource.oModel.oData.ServiceMessageSet[selectedIndex].Themk;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("SplitPage", {
				Pointer: selectedPointer
			});
		},

		/*_updateTable: function(model) {
			var oTable = this.getView().byId("serviceMsgTable");
			oTable.setModel(model, "serviceMsg");
			//	oTable.refresh();
			//this.getOwnerComponent().getModel("overall").refresh();
		},*/

		geti18nModel: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		},
		/*-------------------------------Set up auto-forwarding----------------------------------------*/
		onSelectMsgItem: function (oEvent) {
			var seletedItemsContext = oEvent.getSource().getSelectedContexts();
			var sPointers = "";
			this.NonEWA = false;
			this.hasSubscription = false;
			if (seletedItemsContext.length > 0) {
				for (var i = 0; i < seletedItemsContext.length; i++) {
					var sPath = seletedItemsContext[i].getPath();
					var sPointer = seletedItemsContext[i].getModel().getProperty(sPath).Pointer;
					sPointers = sPointers + ";" + sPointer;
					if (seletedItemsContext[i].getModel().getProperty(sPath).Themk !== "SMEWA") {
						this.NonEWA = true;
					}
					if (seletedItemsContext[i].getModel().getProperty(sPath).Has_Subscription === "X") {
						this.hasSubscription = true;
					}
				}
			}
			this.sPointers = "";
			this.sPointers = sPointers;
		},

		callMessageBoxWarning: function (sInfo) {
			sap.m.MessageBox.warning(
				sInfo, {
					icon: sap.m.MessageBox.Icon.WARNING,
					actions: [sap.m.MessageBox.Action.OK]
				});
		},

		callMessageBoxShow: function (sInfo) {
			sap.m.MessageBox.show(
				sInfo, {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === "YES") {
							var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
							oRouter.navTo("Subscribe");
							var oEventBus = sap.ui.getCore().getEventBus();
							oEventBus.publish("Homepage", "ReloadSubscribeView", {
								Pointer: this.sPointers,
								Substitute: this.getModel("Model_userdata").getData().d.SUBSTITUTE
							});
						}
					}.bind(this)
				});
		},

		onNavToSetUpAutoForwarding: function (oEvent) {
			if (this.sPointers === "" || this.sPointers === undefined) {
				this.callMessageBoxWarning(this.getModel("i18n").getResourceBundle().getText("warnSelectFirstToCreateAutoForward"));
			} else if (this.NonEWA) {
				this.callMessageBoxWarning(this.getModel("i18n").getResourceBundle().getText("warnSelectOnlyEWAToCreateAutoForward"));
			} else if (this.hasSubscription) {
				this.callMessageBoxShow(this.getModel("i18n").getResourceBundle().getText("showSelectEWAHasSubscription"));
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Subscribe");
				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("Homepage", "ReloadSubscribeView", {
					Pointer: this.sPointers,
					Substitute: this.getModel("Model_userdata").getData().d.SUBSTITUTE
				});
			}
		}
	});

});
/*global history */
sap.ui.define([
	"sap/support/servicemessage/controller/BaseController",
	"sap/ui/model/odata/v2/ODataModel",
	'sap/ui/model/json/JSONModel',
	"sap/ui/core/routing/History",
	'sap/m/MessageToast',
	"sap/support/servicemessage/model/formatter",
	"sap/support/servicemessage/model/model"
], function (BaseController, ODataModel, JSONModel, History, MessageToast, formatter, model) {
	"use strict";

	return BaseController.extend("sap.support.servicemessage.controller.Session01", {
		formatter: formatter,
		_Themk: "",
		_has_feedback_form: "",
		_has_feedback_answer: "",
		_SessionHistory: ["GENERAL"],
		_currentProcessor: "",
		_surveyVersion: "",
		onInit: function () {
			//this.getView().setBusy(true);
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("Master", "ReloadDetailView", this.onReloadDetailView, this);
			// var oModel = new JSONModel(jQuery.sap.getModulePath("sap.support.servicemessage.test.mockdata", "/satisfactionSurvey.json"));
			// this.getView().setModel(oModel);
			this.surveyQModel = new JSONModel();
			this.setModel(this.surveyQModel, "serviveType");

			oEventBus.subscribe("Subscribe", "setGeneralPageSubscribeButton", this.reSetSubscribeButton, this);
		},

		reSetSubscribeButton: function (sChanel, e, oData) {
			var oDetailViewModel = this.getModel("detailView");
			oDetailViewModel.setProperty("/hasSubscription", oData.hasSubscription);
		},

		onReloadDetailView: function (sChanel, e, oData) {
			this.Model = new JSONModel();
			this.Model.setData(oData);
			this.setModel(this.Model, "sessionData");
			this._globalPointer = oData.Pointer;
			if (sChanel === "Master") {
				this._SessionHistory.push(oData.SessGuid);
			}
			// ----------------------------Object Title----------------------------------------
			var ServiceMessageModel = new JSONModel();
			ServiceMessageModel.loadData(this._getRemoteRoot() +
				"ServiceMessageSet('" + oData.Pointer + "')", {}, true, "GET");
			var that = this;
			ServiceMessageModel.attachRequestCompleted(
				function () {
					var ObjectName = ServiceMessageModel.getData().d.Description;
					var ContactPersonName = ServiceMessageModel.getData().d.Action_User_Name;
					var ContactPersonNumber = ServiceMessageModel.getData().d.Aktion_User;
					var i18nModel = that.geti18nModel();
					var SessionContactText = i18nModel.getResourceBundle().getText("firstLineOfGeneralMessage");
					var CoCatText = SessionContactText + " " + ContactPersonName + " " + ContactPersonNumber;
					var serviceOrder = ServiceMessageModel.getData().d.CRM_Order;
					//that._surveyVersion = ServiceMessageModel.getData().d.Survey_version;
					/*that._Themk = ServiceMessageModel.getData().d.Themk;
					if (that._Themk === "SMEWA") {
						that.getView().byId("surveyForm").setVisible(false);
						that.getView().byId("emptySurvey").setVisible(false);
						that.getView().byId("sessionName").setShowTitle(false);
						that.getView().byId("reopen").setVisible(false);
					} else {
						that.getView().byId("surveyForm").setVisible(true);
						that.getView().byId("emptySurvey").setVisible(true);
						that.getView().byId("sessionName").setShowTitle(true);
					}*/
					that.getView().byId("session1Title").setObjectTitle(ObjectName);
					that.getView().byId("SessContact").setText(CoCatText);
					that.getView().byId("serviceOrder").setText(serviceOrder);

					/*------------------set read and compelted Button--------------------------------------*/
					var serviceMessageStatus = ServiceMessageModel.getData().d.Status;
					if (serviceMessageStatus === "2") {
						that.getView().byId("unRead").setVisible(false);
						that.getView().byId("read").setVisible(true);
						that.getView().byId("disComplete").setVisible(true);
						that.getView().byId("complete").setVisible(false);
					} else if (serviceMessageStatus === "1") {
						that.getView().byId("unRead").setVisible(true);
						that.getView().byId("read").setVisible(false);
						that.getView().byId("disComplete").setVisible(true);
						that.getView().byId("complete").setVisible(false);
					} else if (serviceMessageStatus === "3") {
						that.getView().byId("unRead").setVisible(false);
						that.getView().byId("read").setVisible(true);
						that.getView().byId("disComplete").setVisible(false);
						that.getView().byId("complete").setVisible(true);
					}
					/*---------------------set forward and status enabel state------------------------------*/
					this._currentProcessor = ServiceMessageModel.getData().d.Aktion_User;
					that._setVisibleStatusOfForwardAndStatusSetIcon(this._currentProcessor);
				}
			);
			var SessionModel = new JSONModel();
			SessionModel.loadData(this._getRemoteRoot() +
				"SessionSet(Pointer='" + oData.Pointer + "',Sess_Guid='" + oData.SessGuid + "')", {}, true, "GET");
			SessionModel.attachRequestCompleted(function () {
				var i18nModel = that.geti18nModel();
				if (SessionModel.getData().d.auto_service === "X") {
					that.getView().byId("item4").setVisible(false);
					that.getView().byId("item2").setVisible(false);
					that.getView().byId("item6").setVisible(false);
					var Q2a = i18nModel.getResourceBundle().getText("Q2a");
					that.getView().byId("item3Q").setText(Q2a);
					var Q3a = i18nModel.getResourceBundle().getText("Q3a");
					that.getView().byId("item5Q").setText(Q3a);
					var Q4a = i18nModel.getResourceBundle().getText("Q4a");
					that.getView().byId("item7Q").setText(Q4a);

				} else {
					that.getView().byId("item2").setVisible(true);
					that.getView().byId("item4").setVisible(true);
					that.getView().byId("item6").setVisible(true);
					var Q3 = i18nModel.getResourceBundle().getText("Q3");
					that.getView().byId("item3Q").setText(Q3);
					var Q5 = i18nModel.getResourceBundle().getText("Q5");
					that.getView().byId("item5Q").setText(Q5);
					var Q7 = i18nModel.getResourceBundle().getText("Q7");
					that.getView().byId("item7Q").setText(Q7);
				}

				that.getModel("serviveType").setProperty("visible", SessionModel.getData().d.auto_service === "X" ? false : true);
				var MessageName = SessionModel.getData().d.Message_Name;
				that.getView().byId("sessionName").setTitle(MessageName);
				var serviceInstNo = SessionModel.getData().d.Sess_Instno;
				var serviceSystId = SessionModel.getData().d.Sess_SystemID;
				that.getView().byId("Sess_systemId").setText(serviceSystId);
				that.getView().byId("Sess_instNo").setText(serviceInstNo);
				that._has_feedback_answer = SessionModel.getData().d.Has_Feedback_Answer;
				that._has_feedback_form = SessionModel.getData().d.Has_Feedback_Form;
				that._surveyVersion = SessionModel.getData().d.Survey_version;
				that._SurveyVisibleStatus(sChanel, e, oData);
			});
			/*------------------set Favorite Button------------------------------------*/
			this._initFavorite(oData.Pointer, "favorite", "unfavorite", "session1Title");

			// ----------------------------Seesion Resulte----------------------------------------
			var SessionResultModel01 = new JSONModel();
			SessionResultModel01.loadData(this._getRemoteRoot() +
				"TextSet(Pointer='" + oData.Pointer + "',Sess_Guid='" + oData.SessGuid + "')", {}, false, "GET");

			var SessionResultModel02 = new JSONModel();
			SessionResultModel02.loadData(this._getRemoteRoot() +
				"TextSet(Pointer='" + oData.Pointer + "',Sess_Guid='" + oData.SessGuid + "')/TextURLSet", {}, true, "GET");

			SessionResultModel02.attachRequestCompleted(
				function () {
					var sHtmlText = SessionResultModel01.getData().d.Long_Text;
					var rHtmlText;
					var attachedUrlNumber = SessionResultModel02.getData().d.results.length;
					var loaner = "";
					if (attachedUrlNumber !== 0) {
						for (var i = 0; i < attachedUrlNumber; i++) {
							var AttachecURL = SessionResultModel02.getData().d.results[i];
							loaner = loaner + "<a href='" + AttachecURL.URL + "'>" + AttachecURL.URL_Name + "</a><br>";
						}
						var embed =
							'<embed data-index="0"><br><embed data-index="1"><br><embed data-index="2"><br><embed data-index="3"><br><embed data-index="4"><br><embed data-index="5"><br><embed data-index="6"><br><embed data-index="7"><br><embed data-index="8"><br><embed data-index="9">';
						rHtmlText = sHtmlText.replace(embed, loaner);

						// hide information if installation id is 0020983005
						/*var sReplaceText = "<strong>SAP Solution Manager:</strong> <a class='sapMLnk' style='font-size:1em;' href='https://launchpad.support.sap.com/#/systemdata/000000000800376017'target='_blank'>CBX</a> (Installation:<a class='sapMLnk' style='font-size:1em;' href='https://launchpad.support.sap.com/#/installation/management/0020983005' target='_blank'>0020983005</a>)</li> ";
						var sHtmlLongText = rHtmlText.replace(rHtmlText.split("<li>")[1], sReplaceText),
							rHtmlLongText = sHtmlLongText.replace(sHtmlLongText.split("<li>")[2], "<strong>Solution:</strong> CBX NextGen for OSP and SB7</li> ");*/
						/*if (rHtmlText.match(/0020983005/)) {
							var sHtmlReplaceText = rHtmlText.replace(rHtmlText.split("<li>")[1], "<strong>SAP Solution Manager:</strong>  </li>"),
								rHtmlPeplaceText = sHtmlReplaceText.replace(sHtmlReplaceText.split("<li>")[2], "<strong>Solution:</strong> </li>");
						}*/
						if (rHtmlText.match(/0020983005/)) {
							var sHtmlReplaceText = rHtmlText.split("<li>");
							sHtmlReplaceText.splice(1, 2);
							sHtmlReplaceText[0] = sHtmlReplaceText[0] + "<li>";
							var rHtmlReplaceText = sHtmlReplaceText[0] + sHtmlReplaceText[1];
						} else {
							rHtmlReplaceText = rHtmlText;
						}
					} else {
						//rHtmlText = sHtmlText;
						rHtmlReplaceText = sHtmlText;
					}

					that.getView().byId("sessionResult").setHtmlText(rHtmlReplaceText);
				}
			);

		},
		_SurveyVisibleStatus: function (sChanel, e, oData) {
			// ----------------------------------Survey-----------------------------------------------
			var userType = this.getUserType();
			if (userType === "S") {
				if (this._has_feedback_form === "X") {
					this.getView().byId("emptySurvey").setVisible(false);
					if (this._surveyVersion === 'X') {
						this.getView().byId("surveyForm").setVisible(false);
						this.getView().byId("newSurveyForm").setVisible(true);
					} else {
						this.getView().byId("surveyForm").setVisible(true);
						this.getView().byId("newSurveyForm").setVisible(false);
					}

					this.getView().byId("save").setVisible(true);
					this._setSurveyData(sChanel, e, oData);
				} else {
					this.getView().byId("emptySurvey").setVisible(false);
					this.getView().byId("surveyForm").setVisible(false);
					this.getView().byId("newSurveyForm").setVisible(false);
					this.getView().byId("save").setVisible(false);
					this.getView().byId("sessionName").setShowTitle(false);
				}
			} else if (userType !== "S") {
				// check wether internal user has survey authorization
				var that = this;
				var FeedbackFormModel = new JSONModel();
				FeedbackFormModel.loadData(that._getRemoteRoot() +
					"FeedbackformSet(Pointer='" + oData.Pointer + "',Sess_Guid='" + oData.SessGuid + "')", {}, true, "GET");
				FeedbackFormModel.attachRequestCompleted(
					function () {
						var Error_Text = FeedbackFormModel.getData().d.Error_Text;
						if (that._has_feedback_form === "X") {
							if (Error_Text === "") {
								that.getView().byId("emptySurvey").setVisible(false);
								if (that._surveyVersion === 'X') {
									that.getView().byId("surveyForm").setVisible(false);
									that.getView().byId("newSurveyForm").setVisible(true);

								} else {
									that.getView().byId("surveyForm").setVisible(true);
									that.getView().byId("newSurveyForm").setVisible(false);
								}
								that.getView().byId("save").setVisible(true);
								that._setSurveyData(sChanel, e, oData);
							} else {
								that.getView().byId("emptySurvey").setVisible(true);
								that.getView().byId("surveyForm").setVisible(false);
								that.getView().byId("newSurveyForm").setVisible(false);
								that.getView().byId("unauthorizedSryText").setHtmlText(Error_Text);
								that.getView().byId("save").setVisible(false);
							}
						} else {
							that.getView().byId("emptySurvey").setVisible(false);
							that.getView().byId("surveyForm").setVisible(false);
							that.getView().byId("newSurveyForm").setVisible(false);
							that.getView().byId("save").setVisible(false);
							that.getView().byId("sessionName").setShowTitle(false);
						}
						if (FeedbackFormModel.getData().d.Has_Reopen_Button === "X") {
							that.getView().byId("reopen").setVisible(true);
						} else {
							that.getView().byId("reopen").setVisible(false);
						}
					});
			}
		},
		_setSurveyData: function (sChanel, e, oData) {
			var that = this;
			var FeedbackModel = new ODataModel(this._getRemoteRoot(), {
				useBatch: false
			});
			FeedbackModel.read("/FeedbackSet(Pointer='" + oData.Pointer + "',Sess_Guid='" + oData.SessGuid + "')", {
				success: function (oData, oResponse) {
					var Model = new sap.ui.model.json.JSONModel({
						FeedbackSet: oResponse.data
					});
					var tempValue = Model.getData().FeedbackSet;
					var Name = tempValue.NAME;
					var Email = tempValue.EMAIL;
					var Phone = tempValue.TELNR;
					var commentText = tempValue.ANSWER8;
					var recommendPossibility = tempValue.ANSWER9;
					var satisfactionLevel = [];
					satisfactionLevel.push(tempValue.ANSWER1);
					satisfactionLevel.push(tempValue.ANSWER2);
					satisfactionLevel.push(tempValue.ANSWER3);
					satisfactionLevel.push(tempValue.ANSWER4);
					satisfactionLevel.push(tempValue.ANSWER5);
					satisfactionLevel.push(tempValue.ANSWER6);
					satisfactionLevel.push(tempValue.ANSWER7);
					that._setSurveyUneditabel();
					that._setSurveyTextData(Name, Email, Phone, commentText, recommendPossibility);
					that._setSurveyRadioDataAndUneditable(satisfactionLevel);
				},
				error: function (error) {
					// Set a new empty survey
					var FeedbackFormModel = new JSONModel();
					FeedbackFormModel.loadData(that._getRemoteRoot() +
						"FeedbackformSet(Pointer='" + oData.Pointer + "',Sess_Guid='" + oData.SessGuid + "')", {}, true, "GET");
					FeedbackFormModel.attachRequestCompleted(
						function () {
							if (FeedbackFormModel.getData().d.Only_Display === "X") {
								that._setSurveyTextData("", "", "", "", "0");
								that._setSurveyUneditabel();
								that._reSetRadioButtonAndSetUneditable();
							} else {
								var Name = FeedbackFormModel.getData().d.User_Name;
								var Email = FeedbackFormModel.getData().d.User_Email;
								var Phone = FeedbackFormModel.getData().d.User_Phone;
								that._setSurveyTextData(Name, Email, Phone, "", "0");
								that._setSurveyEditabel();
							}
						});
				}
			});
		},
		_setSurveyRadioDataAndUneditable: function (satisfactionLevel) {
			if (this._surveyVersion === "") {
				for (var i = 1; i < 8; i++) {
					var level = satisfactionLevel[i - 1];
					for (var j = 1; j < 11; j++) {
						var dynamicID = "Q" + i + j;
						if (Number(level) === j - 1) {
							this.getView().byId(dynamicID).setSelected(true).setEnabled(false);
						} else {
							this.getView().byId(dynamicID).setEnabled(false);
						}
					}
				}
			} else {
				for (var p = 1; p < 5; p++) {
					var newLevel = satisfactionLevel[p - 1];
					for (var q = 1; q < 11; q++) {
						var newDynamicID = "NQ" + p + q;
						if (Number(newLevel) === q - 1) {
							this.getView().byId(newDynamicID).setSelected(true).setEnabled(false);
						} else {
							this.getView().byId(newDynamicID).setEnabled(false);
						}
					}
				}
			}

		},
		_reSetRadioButtonAndSetUneditable: function () {
			if (this._surveyVersion === "") {
				for (var i = 1; i < 8; i++) {
					for (var j = 1; j < 11; j++) {
						var dynamicID = "Q" + i + j;
						this.getView().byId(dynamicID).setSelected(false).setEnabled(false);
					}
				}
			} else {
				for (var p = 1; p < 5; p++) {
					for (var q = 1; q < 11; q++) {
						var newDynamicID = "NQ" + p + q;
						this.getView().byId(newDynamicID).setSelected(false).setEnabled(false);
					}
				}
			}

		},
		_setSurveyUneditabel: function () {
			this.getView().byId("save").setVisible(false);
			if (this._surveyVersion === "") {
				this.getView().byId("name").setEditable(false);
				this.getView().byId("email").setEditable(false);
				this.getView().byId("phone").setEditable(false);
				this.getView().byId("commentText").setEditable(false);
				this.getView().byId("select").setEnabled(false);
				for (var i = 1; i < 8; i++) {
					for (var j = 1; j < 11; j++) {
						var dynamicID = "Q" + i + j;
						this.getView().byId(dynamicID).setEnabled(false);
					}
				}
			} else {
				this.getView().byId("name_N").setEditable(false);
				this.getView().byId("email_N").setEditable(false);
				this.getView().byId("phone_N").setEditable(false);
				this.getView().byId("commentText_N").setEditable(false);
				for (var p = 1; p < 5; p++) {
					for (var q = 1; q < 11; q++) {
						var newDdynamicID = "NQ" + p + q;
						this.getView().byId(newDdynamicID).setEnabled(false);
					}
				}
			}

		},
		_setSurveyEditabel: function () {
			this.getView().byId("save").setVisible(true);
			if (this._surveyVersion === "") {
				this.getView().byId("name").setEditable(true);
				this.getView().byId("email").setEditable(true);
				this.getView().byId("phone").setEditable(true);
				this.getView().byId("commentText").setEditable(true);
				this.getView().byId("select").setEnabled(true);
				for (var i = 1; i < 8; i++) {
					for (var j = 1; j < 11; j++) {
						var dynamicID = "Q" + i + j;
						this.getView().byId(dynamicID).setSelected(false).setEnabled(true);
					}
				}
			} else {
				this.getView().byId("name_N").setEditable(true);
				this.getView().byId("email_N").setEditable(true);
				this.getView().byId("phone_N").setEditable(true);
				this.getView().byId("commentText_N").setEditable(true);
				for (var p = 1; p < 5; p++) {
					for (var q = 1; q < 11; q++) {
						var newDynamicID = "NQ" + p + q;
						this.getView().byId(newDynamicID).setSelected(false).setEnabled(true);
					}
				}
			}
		},

		_setSurveyTextData: function (Name, Email, Phone, commentText, recommendPossibility) {
			if (this._surveyVersion === "") {
				this.getView().byId("name").setValue(Name);
				this.getView().byId("email").setValue(Email);
				this.getView().byId("phone").setValue(Phone);
				this.getView().byId("commentText").setValue(commentText);
				this.getView().byId("select").setSelectedKey(recommendPossibility);
			} else {
				this.getView().byId("name_N").setValue(Name);
				this.getView().byId("email_N").setValue(Email);
				this.getView().byId("phone_N").setValue(Phone);
				this.getView().byId("commentText_N").setValue(commentText);
			}
		},

		onSave: function (oEvent) {
			var SurveyAnswerModel = {};
			// pointer and ses_Guid
			/*re-upload again*/
			SurveyAnswerModel.Pointer = this.getModel("sessionData").getData().Pointer;
			SurveyAnswerModel.Sess_Guid = this.getModel("sessionData").getData().SessGuid;
			// satisfaction level
			var oRadioData = [];
			var oSatisLevel, Name, Email, Phone, selectStatus, recommendPossibility, commentText;
			if (this._surveyVersion === "X") {
				oSatisLevel = this.getView().byId("satisfaction_N");
				Name = this.getView().byId("name_N").getValue();
				Email = this.getView().byId("email_N").getValue();
				Phone = this.getView().byId("phone_N").getValue();
				for (var i = 0; i < 4; i++) {
					for (var j = 2; j < 12; j++) {
						selectStatus = oSatisLevel.getItems()[i].getCells()[j].getSelected();
						if (selectStatus === true) {
							oRadioData[i] = j - 2;
						}
					}
				}
				// Additional information
				commentText = this.getView().byId("commentText_N").getValue();
			} else {
				oSatisLevel = this.getView().byId("satisfaction");
				// Contact information
				Name = this.getView().byId("name").getValue();
				Email = this.getView().byId("email").getValue();
				Phone = this.getView().byId("phone").getValue();
				for (var p = 0; p < 7; p++) {
					for (var q = 2; q < 12; q++) {
						selectStatus = oSatisLevel.getItems()[p].getCells()[q].getSelected();
						if (selectStatus === true) {
							oRadioData[p] = q - 2;
						}
					}
				}
				// Additional information
				recommendPossibility = this.getView().byId("select").getSelectedKey();
				commentText = this.getView().byId("commentText").getValue();
			}
			SurveyAnswerModel.ANSWER1 = (oRadioData[0] !== undefined ? oRadioData[0].toString() : oRadioData[0]);
			SurveyAnswerModel.ANSWER2 = (oRadioData[1] !== undefined ? oRadioData[1].toString() : oRadioData[1]);
			SurveyAnswerModel.ANSWER3 = (oRadioData[2] !== undefined ? oRadioData[2].toString() : oRadioData[2]);
			SurveyAnswerModel.ANSWER4 = (oRadioData[3] !== undefined ? oRadioData[3].toString() : oRadioData[3]);
			SurveyAnswerModel.ANSWER5 = (oRadioData[4] !== undefined ? oRadioData[4].toString() : oRadioData[4]);
			SurveyAnswerModel.ANSWER6 = (oRadioData[5] !== undefined ? oRadioData[5].toString() : oRadioData[5]);
			SurveyAnswerModel.ANSWER7 = (oRadioData[6] !== undefined ? oRadioData[6].toString() : oRadioData[6]);
			SurveyAnswerModel.ANSWER8 = commentText;
			SurveyAnswerModel.ANSWER9 = recommendPossibility;
			SurveyAnswerModel.NAME = Name;
			SurveyAnswerModel.EMAIL = Email;
			SurveyAnswerModel.TELNR = Phone;

			var that = this;
			var url = this._getRemoteRoot();
			var m = new sap.ui.model.odata.v2.ODataModel(url);
			m.setUseBatch(false);
			m.create("/FeedbackSet", SurveyAnswerModel, {
				success: function () {
					that._setSurveyTextData(Name, Email, Phone, commentText, recommendPossibility);
					that._setSurveyUneditabel();
					/*	for (var i = 1; i < 8; i++) {
							var level = oRadioData[i - 1];
							for (var j = 1; j < 11; j++) {
								var dynamicID = "Q" + i + j;
								if (Number(level) === j - 1) {
									that.getView().byId(dynamicID).setSelected(true).setEnabled(false);
								} else {
									that.getView().byId(dynamicID).setEnabled(false);
								}
							}
						}*/
					// set re-open button
					var FeedbackFormModel = new JSONModel();
					FeedbackFormModel.loadData(that._getRemoteRoot() +
						"FeedbackformSet(Pointer='" + SurveyAnswerModel.Pointer + "',Sess_Guid='" + SurveyAnswerModel.Sess_Guid + "')", {}, true,
						"GET");
					FeedbackFormModel.attachRequestCompleted(
						function () {
							if (FeedbackFormModel.getData().d.Has_Reopen_Button === "X") {
								that.getView().byId("reopen").setVisible(true);
							} else {
								that.getView().byId("reopen").setVisible(false);
							}
						});
					// give info
					var i18nModel = that.geti18nModel();
					var inforMsg = i18nModel.getResourceBundle().getText("inforMsg");
					MessageToast.show(inforMsg);
					/*jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.information(
						inforMsg, {
							title: infor,
							icon: sap.m.MessageBox.Icon.INFORMATION,
							actions: [sap.m.MessageBox.Action.YES]
						});*/
				},
				error: function (oError) {
					var i18nModel = that.geti18nModel();
					var errorMsg = i18nModel.getResourceBundle().getText("errorMsg");
					var Warning = i18nModel.getResourceBundle().getText("warning");
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.warning(
						errorMsg, {
							title: Warning,
							icon: sap.m.MessageBox.Icon.WARNING,
							actions: [sap.m.MessageBox.Action.OK]
						});
				}
			});
		},
		addFavorite: function () {
			this._addFavorite("favorite", "unfavorite", "session1Title");
		},

		removeFavorite: function () {
			this._removeFavorite("favorite", "unfavorite", "session1Title");
		},

		forward: function () {
			this._forward("SessContact");
		},

		backTogeneralPage: function () {
			var historyLength = this._SessionHistory.length;
			if (historyLength === 2) {
				var oApp = this.getView().getParent().getParent();
				var odeviceModel = this.getModel("device");
				if (!odeviceModel.getData().system.phone) {
					this._SessionHistory = ["GENERAL"];
					oApp.to(oApp.getDetailPages()[0]);
					var favorite_flag = this.getView().byId("session1Title").getMarkFavorite();
					var read_flag = this.getView().byId("read").getVisible();
					var completed_flag = this.getView().byId("complete").getVisible();
					var oData = {};
					oData.favorite_flag = favorite_flag;
					oData.read_flag = read_flag;
					oData.completed_flag = completed_flag;
					oData.NewProcessor = this._NewProcessor;
					oData.NewProcessorName = this._NewProcessorName;
					var oEventBus = sap.ui.getCore().getEventBus();
					oEventBus.publish("Session01", "setGeneralPageFavorite", oData);
				} else {
					this._SessionHistory.pop();
					oApp.to(oApp.getMasterPages()[0]);
				}
			} else {
				var sess_Guid = this._SessionHistory[historyLength - 2];
				this._SessionHistory.pop();
				var lData = {};
				lData.Pointer = this._globalPointer;
				lData.SessGuid = sess_Guid;
				this.onReloadDetailView("Session01", "ReloadDetailView", lData);
			}

		},

		onReOpne: function () {
			this.getView().byId("reopen").setVisible(false);
			this._setSurveyEditabel();
		},

		onBack: function () {
			var oApp = this.getView().getParent().getParent();
			oApp.to(oApp.getDetailPages()[0]);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("homepage", true);
		},

		_getRemoteRoot: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			var root = oComp.sConfig.requestRemote;
			return root;
		},

		geti18nModel: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		},
		getUserData: function () {
			var userData = this.getOwnerComponent().getModel("Model_userdata");
			return userData;
		},
		onActionLog: function (oEvent) {
         	this.getOwnerComponent().ModDialog.open(this.getView());
			this.loadLog();
		}
			/*getRate: function(oEvent){
				var ChangingRate = oEvent.getParameters().id.substring(14,16);
				var oItem = oEvent.getSource().getParent();
				var oNewRadio = oItem.getCells()[Number(ChangingRate)+1];
				var oCheck = oNewRadio.getSelected();
				var QNumber = oNewRadio.getGroupName();
				var oData = {};
				oData.QNumber = QNumber;
				oData.ChangingRate = ChangingRate;
			}*/

	});

});
sap.ui.define([
	"sap/support/servicemessage/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog",
	"sap/ui/model/odata/v2/ODataModel",
	'sap/m/MessageToast',
	'sap/m/MessageBox',
	'sap/ui/export/Spreadsheet',
	"sap/support/servicemessage/model/formatter"
], function (BaseController, JSONModel, ValueHelpDialog, ODataModel, MessageToast, MessageBox, Spreadsheet, formatter) {
	"use strict";

	return BaseController.extend("sap.support.servicemessage.controller.Report", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf sap.support.servicemessage.view.Report
		 */
		onInit: function () {

			// var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			// var oUsertype = oComp.UserType;
			/*if(oUsertype === "S"){
					var oView = that.getView();
					that.getView().byId("idpagereport").setVisible(true);
					oView.byId("DP2").setDateValue(new Date());
			}
			else{
				
			}*/
			var ServiceMsgmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: true
			});
			var that = this;
			ServiceMsgmodel.read("/UsageLogSet", {
				success: function (oData, oResponse) {
					that.getView().setBusy(false);
					var oView = that.getView();
					that.getView().byId("idpagereport").setVisible(true);
					oView.byId("DP2").setDateValue(new Date());
					// that.getView().byId("filterbar").setVisible(false);
					// that.getView().byId("idProductsTable").setVisible(false);
				},
				error: function (error) {
					that.getView().setBusy(false);
					that.getView().byId("idpagereport").setVisible(false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);

				}
			});

		},
		_timeRefactor: function (date) {
			if (date !== "") {
				var Time;
				var Date_stemp = date.split("/");
				if (Date_stemp.length !== 1) {
					for (var k = 0; k < 3; k++) {
						if (Date_stemp[k].length === 1) {
							Date_stemp[k] = "0" + Date_stemp[k];
						}
					}
					Time = "20" + Date_stemp[2] + Date_stemp[0] + Date_stemp[1];
				} else {
					var Date_temp = date.split(".");
					Time = Date_temp[2] + Date_temp[1] + Date_temp[0];
				}
				return Time;
			}
		},
		onupdatefinished: function (oEvent) {
			var oView = this.getView();

		},
		handleDatePickerChange: function (oEvent) {
			var oView = this.getView();

		},
		onSearch: function (e) {
			var oView = this.getView();
			var oDateFrom = oView.byId("DP1").getDateValue();
			var oDateTo = oView.byId("DP2").getDateValue();
			var oFilters = [];
			if (oDateFrom !== null && oDateTo !== null) {
				var oTempDate = new Date(oDateFrom.setHours("00", "00", "00", "00"));
				oDateFrom = new Date(oTempDate.getTime() + oTempDate.getTimezoneOffset() * (-60000));
				var oTempDate1 = new Date(oDateTo.setHours("00", "00", "00", "00"));
				oDateTo = new Date(oTempDate1.getTime() + oTempDate1.getTimezoneOffset() * (-60000));
			}
			if (oDateFrom === null && oDateTo !== null) {
				var oTempDate1 = new Date(oDateTo.setHours("00", "00", "00", "00"));
				oDateTo = new Date(oTempDate1.getTime() + oTempDate1.getTimezoneOffset() * (-60000));
			}
			if (oDateFrom !== null && oDateTo === null) {
				var oTempDate = new Date(oDateFrom.setHours("00", "00", "00", "00"));
				oDateFrom = new Date(oTempDate.getTime() + oTempDate.getTimezoneOffset() * (-60000));
			}
			var filter1 = new sap.ui.model.Filter("CountDate",
				sap.ui.model.FilterOperator.BT, oDateFrom, oDateTo);
			oFilters.push(filter1);
			this.Filter = oFilters;
			this.getSearchResult(oFilters);

		},

		getSearchResult: function (oFilters) {
			// var oView = this.getView();
			var ServiceMsgmodel = new ODataModel(this._getRemoteRoot(), {
				useBatch: true
			});
			var that = this;
			ServiceMsgmodel.read("/UsageLogSet", {
				filters: oFilters,
				success: function (oData, oResponse) {
					that.getView().setBusy(false);
					var model = new sap.ui.model.json.JSONModel({
						UsageLogSet: oData.results
					});
					that.getView().setModel(model, "UsageLog");
					
					var count = 0;
					for (var i = 0; i < oData.results.length; i++) {

						if (oData.results[i].Counter) {
							count = count + oData.results[i].Counter;
						}
					}
					that.getView().byId("idtext1").setText("Total Usage Count : " + count);
					that.getView().byId("idtext2").setText("Source System : " +oData.results[0].SourceSystem );
					// var searchCompletedInfo = that.getMessageToastContent(sType);
					// MessageToast.show(searchCompletedInfo);
					
				},
				error: function (error) {
					that.getView().setBusy(false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);

				}
			});
			this.getView().setBusy(true);
		},
		createColumnConfig: function () {
			return [{
				label: this.getResourceBundle().getText("CountDate"),
				property: "CountDate",
				type: "Date",
				width: "15"
			}, {
				label: this.getResourceBundle().getText("Activity"),
				property: "Activity",
				type: "string",
				width: "15"
			}, {
				label: this.getResourceBundle().getText("UserType"),
				property: "UserType",
				type: "string",
				width: "10"
			}, {
				label: this.getResourceBundle().getText("Counter"),
				property: "Counter",
				type: "number",
				width: "10"
			}, {
				label: this.getResourceBundle().getText("SystemID"),
				property: "SystemId",
				type: "string",
				width: "10"
			},
			{
				label: this.getResourceBundle().getText("SourceSystem"),
				property: "SourceSystem",
				type: "string",
				width: "10"
			}];
		},
		onExportReport: function () {
			var aCols, oRowBinding, oSettings, oSheet, oTable;

			if (!this._oTable) {
				this._oTable = this.byId('idProductsTable');
			}

			oTable = this._oTable;
			oRowBinding = oTable.getBinding('items');
			aCols = this.createColumnConfig();

			oSettings = {
				workbook: {
					columns: aCols,
					context: {
						title: this.getResourceBundle().getText("serviceMessageUR"),
						sheetName: this.getResourceBundle().getText("serviceMessageUR")
					}
					
				},
				dataSource: oRowBinding,
				fileName: this.getResourceBundle().getText("serviceMessageUR") + ".xlsx"
				// worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf sap.support.servicemessage.view.Report
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf sap.support.servicemessage.view.Report
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf sap.support.servicemessage.view.Report
		 */
		//	onExit: function() {
		//
		//	}

	});

});
sap.ui.define([
		"sap/support/servicemessage/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("sap.support.servicemessage.controller.SplitPage", {

			onInit : function () {
				this.getRouter().getRoute("SplitPage").attachPatternMatched(this.getGeneralPage, this);
			},
			getGeneralPage: function(){
				var oApp = this.getView().getContent()[0];
				var odeviceModel = this.getModel("device");
				if(!odeviceModel.getData().system.phone){
					oApp.to(oApp.getDetailPages()[0]);
				}else{
					oApp.to(oApp.getMasterPages()[0]);
				}
				
			}
			
		});

	}
);
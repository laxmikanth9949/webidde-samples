sap.ui.define([
	"sap/ui/model/Filter"
], function(Filter) {
	"use strict";

	var Help = {
		navTo: function(oComponent, oRoute) {
			oComponent.getRouter().navTo(oRoute);
			sap.git.usage.Reporting.addEvent(oComponent, "Navigation to \'" + oRoute + "\' view");
		},
		
		setAuthCheckFilters: function() {
			return [
				new Filter("user_id", "EQ", "ME"),
				new Filter("application", "EQ", "MCCAPP")
			];
		},

		setStatusListFilters: function() {
			return [
				new Filter("key", "EQ", "STATUS")
			];
		},

		setCategoryListFilters: function() {
			return [
				new Filter("key", "EQ", "CATEGORY")
			];
		},

		setRatingListFilters: function() {
			return [
				new Filter("key", "EQ", "RATING")
			];
		},

		setPriorityListFilters: function() {
			return [
				new Filter("key", "EQ", "PRIORITY")
			];
		},
		
		setServiceTeamListFilters: function() {
			return [
				new Filter("key", "EQ", "SERVICETEAM")
			];
		},

		setUserProfileFilters: function() {
			return [
				new Filter("Attribute", "EQ", "USERNAME"),
				new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_VISIBLE_LISTS"),
				new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_VISIBLE_CATEG"),
				new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_VISIBLE_STATU"),
				new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_DEFAULT_CATEG"),
				new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_DEFAULT_CASE"),
				new Filter("Attribute", "EQ", "APP_DATA_MCC_ACTIVITIES_WELCOME"),
				new Filter("Attribute", "EQ", "NEED_MCC_PUSHNOTIFICATION"),
				new Filter("Attribute", "EQ", "FAVORITE_ACTIVITIES"),
				new Filter("Attribute", "EQ", "FAVORITE_CUSTOMERS"),
				new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_DEFAULT_STEAM"),
				new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_REGION")
			];
		},

		setMyActivityFilters: function() {
			return [
				/*new Filter("key", "EQ", "myInvolvements"),
				new Filter("value1", "EQ", "ACT_GRP")*/
				new Filter("myactivities", "EQ", "X"),
				new Filter("activity_process_type", "EQ", "ZS46")
			];
		},

		setAssignedFilters: function(aActIds, aCategory, aStatus) {
			if (!Array.isArray(aActIds)) {
				aActIds = [];
			}
			var aActIdFilters = [];
			var aAllFilters = [
				new Filter("myactivities", "EQ", "X"),
				new Filter("activity_process_type", "EQ", "ZS46")
			];
			aActIdFilters = aActIds.map(function(item) {
				return new Filter("activity_id", "EQ", item);
			});
			$.each([aActIdFilters, this.setUserCategoryFilters(aCategory), this.setUserStatusFilters(aStatus, false)], function(index, item) {
				if (item.length !== 0) {
					aAllFilters.push(new Filter({
						filters: item,
						and: false
					}));
				}
			});
			return [
				new Filter({
					filters: aAllFilters,
					and: true
				})
			];
		},

		setCreByMeFilters: function(me, aCategory, aStatus) {
			if (Object.prototype.toString.call(me) !== "[object String]") {
				me = "";
			}
			var aAllFilters = [
				new Filter("mycreatedactivities", "EQ", "X"),
				new Filter("activity_process_type", "EQ", "ZS46")
				/*new Filter({
					filters: [
						new Filter("activity_created_by", "EQ", me),
						new Filter({
							filters: [
								new Filter("activity_partner_function", "EQ", "ZSERR001"),
								new Filter("activity_business_partner", "EQ", me)
							],
							and: true
						})
					],
					and: false
				}),
				new Filter("activity_process_type", "EQ", "ZS46")*/
			];
			$.each([this.setUserCategoryFilters(aCategory), this.setUserStatusFilters(aStatus, false)], function(index, item) {
				if (item.length !== 0) {
					aAllFilters.push(new Filter({
						filters: item,
						and: false
					}));
				}
			});
			return [
				new Filter({
					filters: aAllFilters,
					and: true
				})
			];
		},

		setFavoriteFilters: function(aItems, aCategory, aStatus) {
			if (!Array.isArray(aItems)) {
				aItems = [{Text: ""}];
			}
			var aFavFilters = [];
			var aAllFilters = [
				new Filter("activity_process_type", "EQ", "ZS46")
			];
			aFavFilters = aItems.map(function(item) {
				return new Filter("activity_id", "EQ", item.Text);
			});
			$.each([aFavFilters, this.setUserCategoryFilters(aCategory), this.setUserStatusFilters(aStatus, false)], function(index, item) {
				if (item.length !== 0) {
					aAllFilters.push(new Filter({
						filters: item,
						and: false
					}));
				}
			});
			return [
				new Filter({
					filters: aAllFilters,
					and: true
				})
			];
		},

		setFavoriteCustomerFilters: function(aCusts, aCategory, aStatus) {
			if (!Array.isArray(aCusts)) {
				aCusts = [];
			}
			var aCustomerFilters = [];
			var aAllFilters = [new Filter("activity_process_type", "EQ", "ZS46")];

			aCustomerFilters = aCusts.map(function(item) {
				return new Filter("activity_customer", "EQ", item.Value);
			});
			$.each([aCustomerFilters, this.setUserCategoryFilters(aCategory), this.setUserStatusFilters(aStatus, true)], function(index, item) {
				if (item.length !== 0) {
					aAllFilters.push(new Filter({
						filters: item,
						and: false
					}));
				}
			});
			return [
				new Filter({
					filters: aAllFilters,
					and: true
				})
			];
		},

		setServiceTeamFilters: function(sServiceTeam, aCategory, aStatus) {
			if (Object.prototype.toString.call(sServiceTeam) !== "[object String]") {
				sServiceTeam = "";
			}
			var aAllFilters = [
				new Filter("activity_process_type", "EQ", "ZS46"),
				new Filter("activity_service_team", "EQ", sServiceTeam)
			];
			$.each([this.setUserCategoryFilters(aCategory), this.setUserStatusFilters(aStatus, true)], function(index, item) {
				if (item.length !== 0) {
					aAllFilters.push(new Filter({
						filters: item,
						and: false
					}));
				}
			});
			return [
				new Filter({
					filters: aAllFilters,
					and: true
				})
			];
		},

		setUserCategoryFilters: function(aCategory) {
			var aFilters = [];
			$.each(aCategory, function(index, item) {
				if (item.bSelected) {
					aFilters.push(new Filter("activity_cat", "EQ", item.value1));
				}
			});
			return aFilters;
		},

		setUserStatusFilters: function(aStatus, bComplete) {
			var aFilters = [];
			$.each(aStatus, function(index, item) {
				if (item.bSelected && (!bComplete || (item.value1 !== "E0013" && item.value1 !== "E0014"))) {
					aFilters.push(new Filter("activity_status", "EQ", item.value1));
				}
			});
			return aFilters;
		},
		
		setSingleActSearchFilters: function(sActId) {
			return [
				new Filter("activity_process_type", "EQ", "ZS46"),
				new Filter("activity_id", "EQ", sActId)
			];
		},
		
		setCaseIdSearchFilters: function(sCust, sCase) {
			var aFilter = [
				new Filter("customer_r3_no", "EQ", sCust),
				new Filter("case_type", "EQ", "ZS02"),
				new Filter({
					filters: [
						new Filter("status", "EQ", "71"),
						new Filter("status", "EQ", "80"),
						new Filter("status", "EQ", "81"),
						new Filter("status", "EQ", "99")
					],
					and: false
				})
			];
			if (sCase) {
				aFilter.unshift(new Filter("case_id", "EQ", sCase));
			}
			return aFilter;
		}
	};

	return Help;
}, true);
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/Device"
], function(JSONModel, ODataModel, Device) {
	"use strict";

	return {

		createDeviceModel: function() {
			var oDeviceModel = new JSONModel({
				isTouch: Device.support.touch,
				isNoTouch: !Device.support.touch,
				isPhone: Device.system.phone,
				isNoPhone: !Device.system.phone,
				listMode: Device.system.phone ? "None" : "SingleSelectMaster",
				listItemType: Device.system.phone ? "Active" : "Inactive",
				os: Device.os.name
			});
			oDeviceModel.setDefaultBindingMode("OneWay");
			return oDeviceModel;
		},

		createNewODataModel: function(sUrl, bBatch) {
			return new ODataModel({
				json: true,
				useBatch: bBatch,
				/*defaultUpdateMethod: "Put",*/
				serviceUrl: sUrl
			});
		},

		createNewJSONModel: function(sMode) {
			var oJSONModel = new JSONModel();
			oJSONModel.setDefaultBindingMode(sMode);
			return oJSONModel;
		},

		handleGroupData: function(aData) {
			var oData = {};
			jQuery.each(aData, function(index, oItem) {
				if (oItem.Field) {
					if (!oData[oItem.Attribute]) {
						oData[oItem.Attribute] = [];
					}
					oData[oItem.Attribute].push(oItem);
				} else {
					oData[oItem.Attribute] = oItem;
				}
			});
			return oData;
		},

		setVisibleListData: function(oList, aData) {
			$.each(aData, function(index, oItem) {
				if (oList.hasOwnProperty(oItem.Value)) {
					oList[oItem.Value].visible = true;
				}
			});
			return oList;
		},

		setSelectedFilterData: function(aFilter, aData) {
			if (!Array.isArray(aFilter)) {
				aFilter = [];
			}
			if (!Array.isArray(aData)) {
				aData = [];
			}
			var aList = aData.map(function(oItem) {
				return oItem.Value;
			});
			$.each(aFilter, function(index, oItem) {
				if (aList.indexOf(oItem.value1) !== -1) {
					oItem.bSelected = true;
				} else {
					oItem.bSelected = false;
				}
			});
			return aFilter;
		},

		setSearchString: function(aActivities) {
			if (aActivities && aActivities !== {}) {
				for (var index = 0; index < aActivities.length; index++) {
					var oActivity = aActivities[index];
					oActivity.searchString =
						oActivity.activity_description +
						oActivity.activity_id +
						oActivity.activity_status_desc +
						oActivity.activity_priority_desc +
						oActivity.account_name_F +
						oActivity.activity_person_name +
						oActivity.activity_service_team_name;
				}
			}
			return aActivities;
		},

		groupServiceTeam: function(aServiceTeam) {
			var aGroupList = [];
			if (!Array.isArray(aServiceTeam)) {
				return aGroupList;
			} else {
				$.each(aServiceTeam, function(index, item) {
					var flagEqual = false;
					$.each(aGroupList, function(index01, item01) {
						if (item01.Region === item.value2) {
							flagEqual = true;
							item01.Topic.push({name: item.value3, service_team_id: item.value1});
							return;
						}
					});
					if(!flagEqual) {
						aGroupList.push({Region: item.value2, Topic: [{name: item.value3, service_team_id: item.value1}]});
					}
				});
				return aGroupList;
			}
		}
	};
});
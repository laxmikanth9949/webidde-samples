sap.ui.define([
	/*"sap/support/mccactivities/test/unit/pages/App",*/
	"sap/support/mccactivities/test/unit/pages/CreateActivity",
	"sap/support/mccactivities/test/unit/pages/Detail",
	"sap/support/mccactivities/test/unit/pages/Settings",
	"sap/support/mccactivities/test/unit/model/DataManager",
	"sap/support/mccactivities/test/unit/model/help",
	"sap/support/mccactivities/test/unit/model/models",
	"sap/support/mccactivities/test/unit/util/Formatter",
	"sap/support/mccactivities/test/unit/util/Base"
], function() {
	"use strict";
});
sap.ui.define([
	"sap/support/mccactivities/model/help",
	"sap/ui/model/Filter",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(help, Filter) {
	"use strict";
	QUnit.module("model - help: Test cases for help functions");

	QUnit.test("Should see authorization check filters when calling service", function(assert) {
		var sAct = [
			new Filter("user_id", "EQ", "ME"),
			new Filter("application", "EQ", "MCCAPP")
		];
		assert.deepEqual(help.setAuthCheckFilters(), sAct);
	});

	QUnit.test("Should see status list filters when calling service", function(assert) {
		var sAct = [
			new Filter("key", "EQ", "STATUS")
		];
		assert.deepEqual(help.setStatusListFilters(), sAct);
	});

	QUnit.test("Should see category list filters when calling service", function(assert) {
		var sAct = [
			new Filter("key", "EQ", "CATEGORY")
		];
		assert.deepEqual(help.setCategoryListFilters(), sAct);
	});

	QUnit.test("Should see rating list filters when calling service", function(assert) {
		var sAct = [
			new Filter("key", "EQ", "RATING")
		];
		assert.deepEqual(help.setRatingListFilters(), sAct);
	});

	QUnit.test("Should see priority list filters when calling service", function(assert) {
		var sAct = [
			new Filter("key", "EQ", "PRIORITY")
		];
		assert.deepEqual(help.setPriorityListFilters(), sAct);
	});

	QUnit.test("Should see service team list filters when calling service", function(assert) {
		var sAct = [
			new Filter("key", "EQ", "SERVICETEAM")
		];
		assert.deepEqual(help.setServiceTeamListFilters(), sAct);
	});

	QUnit.test("Should see user profile filters when calling service", function(assert) {
		var sAct = [
			new Filter("Attribute", "EQ", "USERNAME"),
			new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_VISIBLE_LISTS"),
			new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_VISIBLE_CATEG"),
			new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_VISIBLE_STATU"),
			new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_DEFAULT_CATEG"),
			new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_DEFAULT_CASE"),
			new Filter("Attribute", "EQ", "APP_DATA_MCC_ACTIVITIES_WELCOME"),
			new Filter("Attribute", "EQ", "NEED_MCC_PUSHNOTIFICATION"),
			new Filter("Attribute", "EQ", "FAVORITE_ACTIVITIES"),
			new Filter("Attribute", "EQ", "FAVORITE_CUSTOMERS"),
			new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_DEFAULT_STEAM"),
			new Filter("Attribute", "EQ", "APP_MCC_ACTIVITIES_REGION")
		];
		assert.deepEqual(help.setUserProfileFilters(), sAct);
	});

	QUnit.test("Should see my activity filters when calling service", function(assert) {
		var sAct = [
			new Filter("myactivities", "EQ", "X"),
			new Filter("activity_process_type", "EQ", "ZS46")
		];
		assert.deepEqual(help.setMyActivityFilters(), sAct);
	});

	QUnit.module("model - help: Test cases for reading activity filters", {
		beforeEach: function() {
			sinon.stub(help, "setUserCategoryFilters").returns([]);
			sinon.stub(help, "setUserStatusFilters").returns([]);
		},
		afterEach: function() {
			help.setUserCategoryFilters.restore();
			help.setUserStatusFilters.restore();
		}
	});

	QUnit.test("Should see no activity id filter when current user has invalid assigned activity with no category & status", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("myactivities", "EQ", "X"),
					new Filter("activity_process_type", "EQ", "ZS46")
				],
				and: true
			})
		];
		assert.deepEqual(help.setAssignedFilters(undefined), sAct);
	});

	QUnit.test("Should see 1 activity id filter when current user has 1 assigned activity", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("myactivities", "EQ", "X"),
					new Filter("activity_process_type", "EQ", "ZS46"),
					new Filter({
						filters: [new Filter("activity_id", "EQ", "12345")],
						and: false
					})
				],
				and: true
			})
		];
		assert.deepEqual(help.setAssignedFilters(["12345"]), sAct);
	});

	QUnit.test("Should see 2 activity ids filter when current user has 2 assigned activities", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("myactivities", "EQ", "X"),
					new Filter("activity_process_type", "EQ", "ZS46"),
					new Filter({
						filters: [
							new Filter("activity_id", "EQ", "12345"),
							new Filter("activity_id", "EQ", "67890")
						],
						and: false
					})
				],
				and: true
			})
		];
		assert.deepEqual(help.setAssignedFilters(["12345", "67890"]), sAct);
	});
	
	QUnit.test("Should see my created activities filter when calling service", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("mycreatedactivities", "EQ", "X"),
					new Filter("activity_process_type", "EQ", "ZS46")
				],
				and: true
			})
		];
		assert.deepEqual(help.setCreByMeFilters(undefined), sAct);
	});

	/*QUnit.test("Should see empty creater filter when user name of the creater is not valid", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter({
						filters: [
							new Filter("activity_created_by", "EQ", ""),
							new Filter({
								filters: [
									new Filter("activity_partner_function", "EQ", "ZSERR001"),
									new Filter("activity_business_partner", "EQ", "")
								],
								and: true
							})
						],
						and: false
					}),
					new Filter("activity_process_type", "EQ", "ZS46")
				],
				and: true
			})

		];
		assert.deepEqual(help.setCreByMeFilters(undefined), sAct);
	});

	QUnit.test("Should see creater 'user' filter when user name of the creater is 'user'", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter({
						filters: [
							new Filter("activity_created_by", "EQ", "user"),
							new Filter({
								filters: [
									new Filter("activity_partner_function", "EQ", "ZSERR001"),
									new Filter("activity_business_partner", "EQ", "user")
								],
								and: true
							})
						],
						and: false
					}),
					new Filter("activity_process_type", "EQ", "ZS46")
				],
				and: true
			})

		];
		assert.deepEqual(help.setCreByMeFilters("user"), sAct);
	});*/

	QUnit.test("Should see no favorite activity filter when current user has invalid favorite activity", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("activity_process_type", "EQ", "ZS46"),
					new Filter({
						filters: [new Filter("activity_id", "EQ", "")],
						and: false
					})
				],
				and: true
			})
		];
		assert.deepEqual(help.setFavoriteFilters(undefined), sAct);
	});

	QUnit.test("Should see 1 favorite activity filter when current user has 1 favorite activity", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("activity_process_type", "EQ", "ZS46"),
					new Filter({
						filters: [new Filter("activity_id", "EQ", "12345")],
						and: false
					})
				],
				and: true
			})
		];
		assert.deepEqual(help.setFavoriteFilters([{
			Text: "12345"
		}]), sAct);
	});

	QUnit.test("Should see 2 favorite activities filter when current user has 2 favorite activities", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("activity_process_type", "EQ", "ZS46"),
					new Filter({
						filters: [
							new Filter("activity_id", "EQ", "12345"),
							new Filter("activity_id", "EQ", "67890")
						],
						and: false
					})
				],
				and: true
			})
		];
		assert.deepEqual(help.setFavoriteFilters([{
			Text: "12345"
		}, {
			Text: "67890"
		}]), sAct);
	});

	QUnit.test("Should see no favorite customer filter when current user has invalid favorite customer", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("activity_process_type", "EQ", "ZS46")
				],
				and: true
			})
		];
		assert.deepEqual(help.setFavoriteCustomerFilters(undefined), sAct);
	});

	QUnit.test("Should see 1 favorite customer filter when current user has 1 favorite customer", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("activity_process_type", "EQ", "ZS46"),
					new Filter({
						filters: [new Filter("activity_customer", "EQ", "customer1")],
						and: false
					})
				],
				and: true
			})
		];
		assert.deepEqual(help.setFavoriteCustomerFilters([{
			Value: "customer1"
		}]), sAct);
	});

	QUnit.test("Should see 2 favorite customer filters when current user has 2 favorite customer", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("activity_process_type", "EQ", "ZS46"),
					new Filter({
						filters: [
							new Filter("activity_customer", "EQ", "customer1"),
							new Filter("activity_customer", "EQ", "customer2")
						],
						and: false
					})
				],
				and: true
			})
		];
		assert.deepEqual(help.setFavoriteCustomerFilters([{
			Value: "customer1"
		}, {
			Value: "customer2"
		}]), sAct);
	});

	QUnit.test("Should see no service team filter when current user has invalid service team", function(assert) {
		var sAct = [
			new Filter({
				filters: [
					new Filter("activity_process_type", "EQ", "ZS46"),
					new Filter("activity_service_team", "EQ", "")
				],
				and: true
			})
		];
		assert.deepEqual(help.setServiceTeamFilters(undefined), sAct);
	});
	
	QUnit.test("Should get filter to read detail of activity '12345' when target activity id is '12345'", function(assert) {
		var sAct = [
			new Filter("activity_process_type", "EQ", "ZS46"),
			new Filter("activity_id", "EQ", "12345")
		];
		assert.deepEqual(help.setSingleActSearchFilters("12345"), sAct);
	});
});
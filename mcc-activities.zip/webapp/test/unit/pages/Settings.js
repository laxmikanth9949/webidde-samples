sap.ui.require([
	"sap/support/mccactivities/view/Settings.controller",
	"sap/ui/core/mvc/View",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/core/UIComponent",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/Router",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(SettingsController, View, ResourceModel, Component, Controller, Router, ODataModel, JSONModel) {
	"use strict";

	QUnit.module("pages - Settings view", {
		beforeEach: function() {
			this.oController = new sap.support.mccactivities.view.Settings();
			this.oModelI18n = new ResourceModel({
				bundleName: "sap.support.mccactivities.i18n.message_bundle",
				bundleLocale: "EN"
			});
			this.oComponent = new Component();
			this.oComponent.setModel(this.oModelI18n, "i18n");
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
			this.oViewStub = new View({});
			sinon.stub(this.oController, "getView").returns(this.oViewStub);
			sinon.stub(this.oController, "_requireOtherModule");
			//this.oControlStub = new sinon.stub(this.oViewStub, "byId");
			this.oStubDialogOpen = sinon.stub(sap.m.Dialog.prototype, "open");
			this.oStubDialogClose = sinon.stub(sap.m.Dialog.prototype, "close");
			this.oStubMsgShow = sinon.stub(sap.m.MessageToast, "show");
			this.oController._oCustomerDialog = new sap.m.Dialog();
			sinon.stub(this.oController, "eventUsage");
		},
		afterEach: function() {
			this.oController.destroy();
			Controller.prototype.getOwnerComponent.restore();
			this.oModelI18n.destroy();
			this.oComponent.destroy();
			this.oViewStub.destroy();
			sap.m.Dialog.prototype.open.restore();
			sap.m.Dialog.prototype.close.restore();
			sap.m.MessageToast.show.restore();
			this.oController._oCustomerDialog.destroy();
		}
	});
	
	function setUserProfileModel() {
		var oUserProfileModel = new JSONModel({});
		this.oComponent.setModel(oUserProfileModel, "UserProfile");
	}
	
	function setUserProfileEditModel() {
		var oUserProfileEditModel = new JSONModel({});
		this.oViewStub.setModel(oUserProfileEditModel, "UserProfileEdit");
	}
	
	QUnit.test("Favorite Customers: After user enters 'Favorite Customers' section, 'Save' and 'Cancel' buttons are hidden.", function(assert) {
		this.stub(this.oViewStub, "byId").returns(new sap.m.Button());
		this.oStubBtnVisible = this.stub(sap.m.Button.prototype, "setVisible");          
		this.oController.onIconTabBarSelected(new sap.ui.base.Event("", new sap.ui.base.EventProvider(), {
			item: new sap.m.IconTabFilter({
				key: 3
			})
		}));
		assert.strictEqual(this.oStubBtnVisible.withArgs(false).called, true);
		assert.strictEqual(this.oStubBtnVisible.callCount, 2);
	});
	
	QUnit.test("Favorite Customers: After user enters sections other than 'Favorite Customers', 'Save' and 'Cancel' buttons are visible.", function(assert) {
		this.stub(this.oViewStub, "byId").returns(new sap.m.Button());
		this.oStubBtnVisible = this.stub(sap.m.Button.prototype, "setVisible");          
		this.oController.onIconTabBarSelected(new sap.ui.base.Event("", new sap.ui.base.EventProvider(), {
			item: new sap.m.IconTabFilter({
				key: 1
			})
		}));
		assert.strictEqual(this.oStubBtnVisible.withArgs(true).called, true);
		assert.strictEqual(this.oStubBtnVisible.callCount, 2);
	});
	
	QUnit.test("Favorite Customers: After 'Add' button is pressed, the 'Input Customer Number' popup shows.", function(assert) {
		this.oController.handleAddFavCustomers();
		assert.strictEqual(this.oStubDialogOpen.called, true);
	});
	
	QUnit.test("Favorite Customers: When 'Input Customer Number' popup is shown, after 'Cancel' button is pressed, the dialog close.", function(assert) {
		this.oController.cancelCustomerDialog();
		assert.strictEqual(this.oStubDialogClose.called, true);
	});
	
	QUnit.test("Favorite Customers: When 'Input Customer Number' popup is shown, after 'F4Help' button is pressed, the 'Customer Search' dialog open.", function(assert) {
		this.oStubF4Help = this.stub(this.oController, "_openCustomerSearchF4Help");
		this.oController.onCustomerF4(new sap.ui.base.Event());
		assert.strictEqual(this.oStubF4Help.called, true);
	});	
		
	QUnit.test("Favorite Customers: When 'Input Customer Number' popup is shown, after an invalid customer number is searched and press 'OK', state of input field is 'Error' and the dialog won't close.", function(assert) {
		setUserProfileEditModel.call(this);
		this.stub(sap.ui.getCore(), "byId").returns(new sap.m.Input());
		this.oController.onConfirmCustomer(new sap.ui.base.Event());
		assert.strictEqual(sap.ui.getCore().byId("iCustomerInput").getValueState(), "Error");
		assert.strictEqual(this.oStubDialogClose.called, false);
	});	
		
	QUnit.test("Favorite Customers: When 'Input Customer Number' popup is shown, after a duplicated customer number is searched and press 'OK', a message shows and the dialog won't close.", function(assert) {
		setUserProfileEditModel.call(this);
		this.oViewStub.getModel("UserProfileEdit").setProperty("/FAVORITE_CUSTOMERS", [{
				Value: "0000012345"
			}, {
				Value: "0000067890"
			}]
		);
		var oInput = new sap.m.Input();
		oInput.setValue("0000012345");
		this.stub(sap.ui.getCore(), "byId").returns(oInput);
		this.oController.onConfirmCustomer(new sap.ui.base.Event());
		assert.strictEqual(this.oStubMsgShow.called, true);
		assert.strictEqual(this.oStubDialogClose.called, false);
	});
		
	QUnit.test("Favorite Customers: When 'Input Customer Number' popup is shown, after a valid customer number is searched and press 'OK', list refreshes and a message shows with the dialog closes.", function(assert) {
		setUserProfileModel.call(this);
		setUserProfileEditModel.call(this);
		this.oComponent.oDataUserProfile = new ODataModel({serviceUrl: "test"});
		this.oViewStub.getModel("UserProfileEdit").setProperty("/FAVORITE_CUSTOMERS", [{
				Value: "0000012345"
			}, {
				Value: "0000067890"
			}]
		);
		var oInput = new sap.m.Input();
		oInput.setValue("13579");
		this.stub(sap.ui.getCore(), "byId").returns(oInput);
		this.stub(ODataModel.prototype, "create").callsArg(0).yieldsTo("success");
		this.stub(ODataModel.prototype, "read").callsArg(0).yieldsTo("success");
		var oStubModelRefresh = this.stub(JSONModel.prototype, "refresh");
		
		this.oController.onConfirmCustomer(new sap.ui.base.Event());
		assert.strictEqual(this.oStubMsgShow.called, true);
		assert.strictEqual(this.oStubDialogClose.called, true);
		assert.strictEqual(oStubModelRefresh.called, true);
	});
	
	QUnit.test("Favorite Customers: When user want to delete a favorite customer, the 'Delete Favorite Customer' popup shows.", function(assert) {
		setUserProfileEditModel.call(this);
		
		this.oController.handleDelFavCustomers(new sap.ui.base.Event("delFav", new sap.ui.base.EventProvider(), {
			listItem: new sap.m.StandardListItem({
				title: "Test Favorite Customer(12345)",
				customData: new sap.ui.core.CustomData({
					key: "field",
					value: 1
				})
			})
		}));
		
		assert.strictEqual(this.oStubDialogOpen.called, true);
	});
	
	QUnit.test("Favorite Customers: When 'Delete Favorite Customer' popup is shown, after deletion is cancelled, the dialog closes.", function(assert) {
		this.oController._oDeleteCutomerDialog = new sap.m.Dialog();
		this.oController.cancelDeleteCustomerDialog();
		assert.strictEqual(this.oStubDialogClose.called, true);
	});
	
	QUnit.test("Favorite Customers: When 'Delete Favorite Customer' popup is shown, after deletion is confirmed, list refreshes and a message shows with the dialog closes.", function(assert) {
		setUserProfileModel.call(this);
		setUserProfileEditModel.call(this);
		this.oComponent.oDataUserProfile = new ODataModel({serviceUrl: "test"});
		this.oController._oDeleteCutomerDialog = new sap.m.Dialog();
		
		this.stub(ODataModel.prototype, "remove").callsArg(0).yieldsTo("success");
		this.stub(ODataModel.prototype, "read").callsArg(0).yieldsTo("success");
		var oStubModelRefresh = this.stub(JSONModel.prototype, "refresh");
		
		this.oController.onConfirmCustomerDelete(new sap.ui.base.Event());
		assert.strictEqual(this.oStubMsgShow.called, true);
		assert.strictEqual(this.oStubDialogClose.called, true);
		assert.strictEqual(oStubModelRefresh.called, true);
	});
	
	QUnit.test("onInit: Should init 'Settings' controller when navigate to this view firstly. ", function(assert) {
		var oStubModel = this.stub(View.prototype, "setModel");
		this.stub(Component.prototype, "getEventBus").returns(new sap.ui.core.EventBus());
		this.stub(sap.ui.core.EventBus.prototype, "subscribe");
		this.oComponent.sFirstSlash = "/";
		this.oComponent.sFioriLaunchpad = "";
		var oStubData = this.stub(this.oController, "copyDataToEditModel");
		
		this.oController.onInit();
		
		assert.strictEqual(oStubModel.callCount, 3);
		assert.strictEqual(this.oController.env_PG_ESCALATIONS, "/services/customer/search");
		assert.strictEqual(oStubData.callCount, 1);
	});
	
	QUnit.test("settingsEventInputFields: Should show 'Defaults' tag when input data of event is 'Defaults'.", function(assert) {
		var oTData = {data: "Defaults"};
		var iconTBar = new sap.m.IconTabBar();
		this.stub(View.prototype, "byId").returns(iconTBar);
		
		this.oController.settingsEventInputFields(null, null, oTData);
		
		assert.strictEqual(iconTBar.getSelectedKey(), "1");
	});
	
	QUnit.test("settingsEventInputFields: Should show 'List Settings' tag when input data of event is other strings.", function(assert) {
		var oTData = {data: "Others"};
		var iconTBar = new sap.m.IconTabBar();
		this.stub(View.prototype, "byId").returns(iconTBar);
		
		this.oController.settingsEventInputFields(null, null, oTData);
		
		assert.strictEqual(iconTBar.getSelectedKey(), "0");
	});
	
	// QUnit.test("prepareServiceTeamSelection: Should set correct selection for 'Service Team' when user has set value before.", function(assert) {
	// 	var oTestModel = new JSONModel();
	// 	oTestModel.setData({APP_MCC_ACTIVITIES_DEFAULT_STEAM: "124"});
	// 	this.oController.getView().setModel(oTestModel, "UserProfileEdit");
	// 	var oStubSet = this.stub(this.oController, "setServiceTeam");
		
	// 	this.oController.prepareServiceTeamSelection();
		
	// 	assert.strictEqual(oStubSet.callCount, 1);
	// });
	
	// QUnit.test("prepareServiceTeamSelection: Should set correct selection for 'Region' when user has not set value before.", function(assert) {
	// 	var oTestModel = new JSONModel();
	// 	oTestModel.setData({APP_MCC_ACTIVITIES_DEFAULT_STEAM: "", APP_DATA_MCC_ACTIVITIES_DEFAULT_REGION: "8"});
	// 	this.oController.getView().setModel(oTestModel, "UserProfileEdit");
	// 	var oStubSet = this.stub(this.oController, "setServiceTeam");
	// 	var oSelection = new sap.m.Select();
	// 	this.stub(View.prototype, "byId").returns(oSelection);
	// 	var oStubCheck = this.stub(this.oController, "checkSelectedRegion");
		
	// 	this.oController.prepareServiceTeamSelection();
		
	// 	assert.strictEqual(oStubSet.callCount, 0);
	// 	assert.strictEqual(oSelection.getSelectedKey(), "8");
	// 	assert.strictEqual(oStubCheck.callCount, 1);
	// });
	
	QUnit.test("copyDataToEditModel: Should copy data to all edit model for 'Settings' controller.", function(assert) {
		var oStubList = this.stub(this.oController, "copyListSettingsToEditModel");
		var oStubPush = this.stub(this.oController, "copyNeedPushNotifToEditModel");
		var oStubUP = this.stub(this.oController, "copyUserProfileDataToEditModel");
		
		this.oController.copyDataToEditModel();
		
		assert.strictEqual(oStubList.callCount, 1);
		assert.strictEqual(oStubPush.callCount, 1);
		assert.strictEqual(oStubUP.callCount, 1);
	});
	
	QUnit.test("copyListSettingsToEditModel: Should copy list settings data to edit model.", function(assert) {
		var oModelList = new JSONModel();
		var oDataTest = {test: "hello"};
		oModelList.setData(oDataTest);
		this.oComponent.setModel(oModelList, "VisibleList");
		var oModelEdit = new JSONModel();
		this.oViewStub.setModel(oModelEdit, "SettingsEdit");
		
		this.oController.copyListSettingsToEditModel();
		
		assert.deepEqual(this.oController.getView().getModel("SettingsEdit").getData(), oDataTest);
	});
	
	QUnit.test("copyNeedPushNotifToEditModel: Should copy need push notification data to edit model.", function(assert) {
		var oModelList = new JSONModel();
		var oDataTest = {test: "hello"};
		oModelList.setData(oDataTest);
		this.oComponent.setModel(oModelList, "NeedPushNotif");
		var oModelEdit = new JSONModel();
		this.oViewStub.setModel(oModelEdit, "NeedPushNotifEdit");
		
		this.oController.copyNeedPushNotifToEditModel();
		
		assert.deepEqual(this.oController.getView().getModel("NeedPushNotifEdit").getData(), oDataTest);
	});
	
	QUnit.test("copyUserProfileDataToEditModel: Should copy user profile data to edit model.", function(assert) {
		var oModelList = new JSONModel();
		var oDataTest = {test: "hello"};
		oModelList.setData(oDataTest);
		this.oComponent.setModel(oModelList, "UserProfile");
		var oModelEdit = new JSONModel();
		this.oViewStub.setModel(oModelEdit, "UserProfileEdit");
		var oStubServiceTeam = this.stub(this.oController, "_updateServiceTeamSelection");
		
		this.oController.copyUserProfileDataToEditModel();
		
		assert.deepEqual(this.oController.getView().getModel("UserProfileEdit").getData(), oDataTest);
		assert.strictEqual(oStubServiceTeam.callCount, 1);
	});
	
	QUnit.test("getCaseId: Should get correct case id from input field and set it to the model.", function(assert) {
		var oInput = new sap.m.Input();
		oInput.setValue("testing");
		this.stub(View.prototype, "byId").returns(oInput);
		var oModelUP = new JSONModel();
		var oDataTest = {APP_MCC_ACTIVITIES_DEFAULT_CASE: {Value: ""}};
		oModelUP.setData(oDataTest);
		this.oViewStub.setModel(oModelUP, "UserProfileEdit");
		
		this.oController.getCaseId();
		
		assert.strictEqual(this.oController.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE").Value, "testing");
	});
	
	QUnit.test("onSave: Should save settings data, show message and clear edit mode flag when clicking save button with default region invalid.", function(assert) {
		this.oViewStub.setModel(new JSONModel({APP_MCC_ACTIVITIES_REGION: {Value: ""}}), "UserProfileEdit");
		var oStubMsg = this.stub(sap.m.MessageBox, "warning");
		
		this.oController.onSave();
		
		assert.strictEqual(oStubMsg.callCount, 1);
	});
	
	QUnit.test("onSave: Should save settings data, show message and clear edit mode flag when clicking save button with default region valid.", function(assert) {
		var oStubList = this.stub(this.oController, "saveListSettings");
		var oStubPush = this.stub(this.oController, "saveNeedPushNotif");
		var oStubServiceTeam = this.stub(this.oController, "saveDefaultServiceTeam");
		var oStubCase = this.stub(this.oController, "saveDefaultCase");
		var oStubRegion = this.stub(this.oController, "saveDefaultRegion");
		var oStubMsg = this.stub(this.oController, "_showMessageAfterSavingSettings");
		this.oComponent._bSettingsEditMode = true;
		this.oViewStub.setModel(new JSONModel({APP_MCC_ACTIVITIES_REGION: {Value: "test"}}), "UserProfileEdit");
		
		this.oController.onSave();
		
		assert.strictEqual(oStubList.callCount, 1);
		assert.strictEqual(oStubPush.callCount, 1);
		assert.strictEqual(oStubServiceTeam.callCount, 1);
		assert.strictEqual(oStubCase.callCount, 1);
		assert.strictEqual(oStubRegion.callCount, 1);
		assert.strictEqual(oStubMsg.callCount, 1);
		assert.strictEqual(this.oComponent._bSettingsEditMode, false);
	});
	
	QUnit.test("onCancel: Should copy original data to edit model and navigate back to the last route when clicking cancel button.", function(assert) {
		var oStubCopy = this.stub(this.oController, "copyDataToEditModel");
		var oStubNav = this.stub(this.oController, "onNavBack");
		
		this.oController.onCancel();
		
		assert.strictEqual(oStubCopy.callCount, 1);
		assert.strictEqual(oStubNav.callCount, 1);
	});
	
	QUnit.test("onNavBack: Should navigate to 'master' route and clear edit mode flag when clicking back button.", function(assert) {
		this.oComponent._bSettingsEditMode = true;
		var oStubNav = this.stub(this.oController, "navTo");
		
		this.oController.onNavBack();
		
		assert.strictEqual(oStubNav.callCount, 1);
		assert.strictEqual(this.oComponent._bSettingsEditMode, false);
	});
	
	QUnit.test("_showMessageAfterSavingSettings: Should show an error message and clear status flag when statue is 'true'.", function(assert) {
		this.oController._saveSettingsStatus = true;
		
		this.oController._showMessageAfterSavingSettings();
		
		assert.strictEqual(this.oStubMsgShow.callCount, 1);
		assert.strictEqual(this.oController._saveSettingsStatus, true);
	});
	
	QUnit.test("_showMessageAfterSavingSettings: Should show a successful message and clear status flag when statue is 'false'.", function(assert) {
		this.oController._saveSettingsStatus = false;
		
		this.oController._showMessageAfterSavingSettings();
		
		assert.strictEqual(this.oStubMsgShow.callCount, 1);
		assert.strictEqual(this.oController._saveSettingsStatus, true);
	});
	
	QUnit.test("saveListSettings: Should change nothing when list settings is not changed.", function(assert) {
		this.stub(this.oController, "_listSettingsChanged").returns(false);
		var oStubDM = this.stub(this.oController, "getDataManager").returns({setVisibleList: function(aData) {return aData;}});
		
		this.oController.saveListSettings();
		
		assert.strictEqual(oStubDM.callCount, 0);
	});
	
	QUnit.test("saveListSettings: Should change visible list model when list settings is changed.", function(assert) {
		this.stub(this.oController, "_listSettingsChanged").returns(true);
		var oDM = {setVisibleList: function(aData) {return aData;}};
		var oStubDM = this.stub(oDM, "setVisibleList");
		this.stub(this.oController, "getDataManager").returns(oDM);
		var oModelSetting = new JSONModel();
		var oModelList = new JSONModel();
		var oDataSetting = {one: {visible: true}, two: {visible: false}, three: {visible: true}};
		oModelSetting.setData(oDataSetting);
		this.oViewStub.setModel(oModelSetting, "SettingsEdit");
		this.oComponent.setModel(oModelList, "VisibleList");
		
		this.oController.saveListSettings();
		
		assert.deepEqual(oStubDM.args[0][0], ["one", "three"]);
	});
	
	QUnit.test("saveNeedPushNotif: Should not change push notification model when need push notification flag isn't changed.", function(assert) {
		this.stub(this.oController, "_needPushNotifChanged").returns(false);
		var oDM = {updateNeedPushNotification: function(aData) {return aData;}};
		this.stub(oDM, "updateNeedPushNotification");
		var oStubDM = this.stub(this.oController, "getDataManager").returns(oDM);
		
		this.oController.saveNeedPushNotif();
		
		assert.strictEqual(oStubDM.callCount, 0);
	});
	
	QUnit.test("saveNeedPushNotif: Should change push notification model to 'YES' when need push notification flag is changed to true.", function(assert) {
		this.stub(this.oController, "_needPushNotifChanged").returns(true);
		var oDM = {updateNeedPushNotification: function(aData) {return aData;}};
		var oStubDM = this.stub(oDM, "updateNeedPushNotification");
		this.stub(this.oController, "getDataManager").returns(oDM);
		var oModelPush = new JSONModel();
		var oModelNoti = new JSONModel();
		var oDataPush = {result: true};
		oModelPush.setData(oDataPush);
		this.oViewStub.setModel(oModelPush, "NeedPushNotifEdit");
		this.oComponent.setModel(oModelNoti, "NeedPushNotif");
		
		this.oController.saveNeedPushNotif();
		
		assert.deepEqual(oStubDM.args[0][0], "YES");
	});
	
	QUnit.test("saveNeedPushNotif: Should change push notification model to 'NO' when need push notification flag is changed to false.", function(assert) {
		this.stub(this.oController, "_needPushNotifChanged").returns(true);
		var oDM = {updateNeedPushNotification: function(aData) {return aData;}};
		var oStubDM = this.stub(oDM, "updateNeedPushNotification");
		this.stub(this.oController, "getDataManager").returns(oDM);
		var oModelPush = new JSONModel();
		var oModelNoti = new JSONModel();
		var oDataPush = {result: false};
		oModelPush.setData(oDataPush);
		this.oViewStub.setModel(oModelPush, "NeedPushNotifEdit");
		this.oComponent.setModel(oModelNoti, "NeedPushNotif");
		
		this.oController.saveNeedPushNotif();
		
		assert.deepEqual(oStubDM.args[0][0], "NO");
	});
	
	
});
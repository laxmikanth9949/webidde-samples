sap.ui.require([
	"sap/support/mccactivities/util/BaseController",
	"sap/ui/core/mvc/View",
	"sap/ui/core/UIComponent",
	"sap/ui/core/mvc/Controller"
], function(BaseController, View, Component, Controller) {
	"use strict";

	QUnit.module("util - Base: Test cases for Base Controller", {
		beforeEach: function() {
			this.oController = new BaseController();
			this.oComponent = new Component();
			this.oViewStub = new View({});
			sinon.stub(Controller.prototype, "getView").returns(this.oViewStub);
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
		},
		afterEach: function() {
			Controller.prototype.getOwnerComponent.restore();
			Controller.prototype.getView.restore();
			this.oViewStub.destroy();
			this.oComponent.destroy();
			this.oController.destroy();
		}
	});
	
	QUnit.test("getDataManager: Should return DataManger object when calling this method.", function(assert) {
		this.oComponent.oDataManager = {data: "test"};
		assert.deepEqual(this.oController.getDataManager(), {data: "test"});
	});
	
	QUnit.test("getDataSource: Should get service url from component when calling this method.", function(assert) {
		this.oComponent.getDataSource = function() {
			return ;
		};
		var oStubData = this.stub(this.oComponent, "getDataSource");
		
		this.oController.getDataSource();
		
		assert.strictEqual(oStubData.callCount, 1);
	});
	
	QUnit.test("getSystem: Should return 'd' when current environment is Fiori Launchpad Dev.", function(assert) {
		this.oComponent.sFioriLaunchpad = true;
		this.stub(this.oController, "getCurrentUrl").returns("wfd7746b4");
		assert.strictEqual(this.oController.getSystem(), "d");
	});
	
	QUnit.test("getSystem: Should return 't' when current environment is Fiori Launchpad Test.", function(assert) {
		this.oComponent.sFioriLaunchpad = true;
		this.stub(this.oController, "getCurrentUrl").returns("sapitcloudt");
		assert.strictEqual(this.oController.getSystem(), "t");
	});
	
	QUnit.test("getSystem: Should return 'p' when current environment is Fiori Launchpad Prod.", function(assert) {
		this.oComponent.sFioriLaunchpad = true;
		this.stub(this.oController, "getCurrentUrl").returns("fiorilaunchpad.sap");
		assert.strictEqual(this.oController.getSystem(), "p");
	});
	
	QUnit.test("getSystem: Should return 'd' when current environment is One Support Launchpad Dev.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("dgq5qdz5dm");
		assert.strictEqual(this.oController.getSystem(), "d");
	});
	
	QUnit.test("getSystem: Should return 't' when current environment is One Support Launchpad Qual.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("q28pq0r93n");
		assert.strictEqual(this.oController.getSystem(), "t");
	});
	
	QUnit.test("getSystem: Should return 'd' when current environment is One Support Launchpad Maint.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("mj7fgura3u");
		assert.strictEqual(this.oController.getSystem(), "d");
	});
	
	QUnit.test("getSystem: Should return 't' when current environment is One Support Launchpad Test.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("tnxd3nxr8c");
		assert.strictEqual(this.oController.getSystem(), "t");
	});
	
	QUnit.test("getSystem: Should return 't' when current environment is One Support Launchpad Demo.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("a73e63587");
		assert.strictEqual(this.oController.getSystem(), "t");
	});
	
	QUnit.test("getSystem: Should return 'p' when current environment is One Support Launchpad Pilot.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("a8f41cb0e");
		assert.strictEqual(this.oController.getSystem(), "p");
	});
	
	QUnit.test("getSystem: Should return 'p' when current environment is One Support Launchpad Prod.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("supportportal");
		assert.strictEqual(this.oController.getSystem(), "p");
	});
	
	QUnit.test("getSystem: Should return 'd' when current environment is others.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("test");
		assert.strictEqual(this.oController.getSystem(), "d");
	});
	
	QUnit.test("getAccount: Should return account href of Dev when current environment is Fiori Launchpad Dev.", function(assert) {
		this.oComponent.sFioriLaunchpad = true;
		this.stub(this.oController, "getCurrentUrl").returns("wfd7746b4");
		assert.strictEqual(this.oController.getAccount(), "dgq5qdz5dm.dispatcher.int.sap");
	});
	
	QUnit.test("getAccount: Should return account href of Demo when current environment is Fiori Launchpad Test.", function(assert) {
		this.oComponent.sFioriLaunchpad = true;
		this.stub(this.oController, "getCurrentUrl").returns("sapitcloudt");
		assert.strictEqual(this.oController.getAccount(), "a73e63587.dispatcher");
	});
	
	QUnit.test("getAccount: Should return account href of Prod when current environment is Fiori Launchpad Prod.", function(assert) {
		this.oComponent.sFioriLaunchpad = true;
		this.stub(this.oController, "getCurrentUrl").returns("fiorilaunchpad.sap");
		assert.strictEqual(this.oController.getAccount(), "supportportal.dispatcher");
	});
	
	QUnit.test("getAccount: Should return account href of Dev when current environment is One Support Launchpad Dev.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("dgq5qdz5dm.dispatcher.int.sap");
		assert.strictEqual(this.oController.getAccount(), "dgq5qdz5dm.dispatcher.int.sap");
	});
	
	QUnit.test("getAccount: Should return account href of Qual when current environment is One Support Launchpad Qual.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("q28pq0r93n.dispatcher.int.sap");
		assert.strictEqual(this.oController.getAccount(), "q28pq0r93n.dispatcher.int.sap");
	});
	
	QUnit.test("getAccount: Should return account href of Maint when current environment is One Support Launchpad Maint.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("mj7fgura3u.dispatcher.int.sap");
		assert.strictEqual(this.oController.getAccount(), "mj7fgura3u.dispatcher.int.sap");
	});
	
	QUnit.test("getAccount: Should return account href of Test when current environment is One Support Launchpad Test.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("tnxd3nxr8c.dispatcher.int.sap");
		assert.strictEqual(this.oController.getAccount(), "tnxd3nxr8c.dispatcher.int.sap");
	});
	
	QUnit.test("getAccount: Should return account href of Prod(Canary) when current environment is One Support Launchpad Prod(Canary).", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("supportportal.dispatcher.int.sap");
		assert.strictEqual(this.oController.getAccount(), "supportportal.dispatcher.int.sap");
	});
	
	QUnit.test("getAccount: Should return account href of Demo when current environment is One Support Launchpad Demo.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("a73e63587");
		assert.strictEqual(this.oController.getAccount(), "a73e63587.dispatcher");
	});
	
	QUnit.test("getAccount: Should return account href of Pilot when current environment is One Support Launchpad Pilot.", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("a8f41cb0e");
		assert.strictEqual(this.oController.getAccount(), "a8f41cb0e.dispatcher");
	});
	
	QUnit.test("getAccount: Should return account href of Prod(Factory) when current environment is One Support Launchpad Prod(Factory).", function(assert) {
		this.oComponent.sFioriLaunchpad = false;
		this.stub(this.oController, "getCurrentUrl").returns("supportportal");
		assert.strictEqual(this.oController.getAccount(), "supportportal.dispatcher");
	});
	
	// QUnit.test("onRegionChange: Should set selected region if region changed without 'CallMe' flag.", function(assert) {
	// 	var oEvent = new sap.ui.base.Event(null, null, {selectedItem: new sap.ui.core.Item()});
	// 	var oStubProp = this.stub(sap.ui.base.ManagedObject.prototype, "getProperty");
	// 	var oStubRegion = this.stub(this.oController, "checkSelectedRegion");
	// 	this.oController.oFlagCallMe = false;
		
	// 	this.oController.onRegionChange(oEvent);
		
	// 	assert.strictEqual(oStubRegion.callCount, 1);
	// 	assert.strictEqual(oStubProp.callCount, 1);
	// });
	
	// QUnit.test("onRegionChange: Should set selected region and topic if region changed with 'CallMe' flag.", function(assert) {
	// 	var oEvent = new sap.ui.base.Event(null, null, {selectedItem: new sap.ui.core.Item()});
	// 	var oStubProp = this.stub(sap.ui.base.ManagedObject.prototype, "getProperty");
	// 	var oStubRegion = this.stub(this.oController, "checkSelectedRegion");
	// 	this.oController.setCMTopic = function() {return;};
	// 	this.oController.oFlagCallMe = true;
		
	// 	this.oController.onRegionChange(oEvent);
		
	// 	assert.strictEqual(oStubRegion.callCount, 1);
	// 	assert.strictEqual(oStubProp.callCount, 2);
	// });
	
	// QUnit.test("onTopicChange: Should set service team to input field when topic is changed to one in the list.", function(assert) {
	// 	var oEvent = new sap.ui.base.Event(null, null, {selectedItem: new sap.ui.core.Item()});
	// 	this.stub(sap.ui.core.Item.prototype, "getProperty").returns("3");
	// 	var oInputST = new sap.m.Input();
	// 	this.stub(View.prototype, "byId").returns(oInputST);
		
	// 	this.oController.onTopicChange(oEvent);
		
	// 	assert.strictEqual(oInputST.getValue(), "3");
	// 	assert.strictEqual(oInputST.getVisible(), true);
	// 	assert.strictEqual(oInputST.getEnabled(), false);
	// });
	
	// QUnit.test("onTopicChange: Should set empty to input field when topic is changed to one out of the list.", function(assert) {
	// 	var oEvent = new sap.ui.base.Event(null, null, {selectedItem: new sap.ui.core.Item()});
	// 	this.stub(sap.ui.core.Item.prototype, "getProperty").returns("-1");
	// 	var oInputST = new sap.m.Input();
	// 	this.stub(View.prototype, "byId").returns(oInputST);
		
	// 	this.oController.onTopicChange(oEvent);
		
	// 	assert.strictEqual(oInputST.getValue(), "");
	// 	assert.strictEqual(oInputST.getVisible(), false);
	// 	assert.strictEqual(oInputST.getEnabled(), true);
	// });
	
});
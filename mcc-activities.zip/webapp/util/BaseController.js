sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/support/mccactivities/util/Formatter"
], function(Controller, Formatter) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.util.BaseController", {
		_bInitViews: false,
		_view: {},
		_oPopover: {},
		_BPcustNoSelected: {},
		_activitySelected: {},
		oModelCaseID: {},
		env_PG_AGS_DASHBOARDS: "",
		
		getModel: function(sModel) {
			return this.getOwnerComponent().getModel(sModel);	
		},
		
		getDataManager: function() {
			return this.getOwnerComponent().oDataManager;	
		},

		getEventBus: function() {
			return sap.ui.getCore().getEventBus();
		},

		getDataSource: function(service) {
			return this.getOwnerComponent().getDataSource(service);
		},
		
		getCurrentUrl: function() {
			return window.location.href;
		},
		
		copyObject: function(obj) {
			return JSON.parse(JSON.stringify(obj));	
		},

		onCaseIdF4: function() {
			window.openValueHelpDialog(this.byId("idMatnrInputCaseID").getValue(), this.byId("inAccount").getValue(), this);
		},

		onCustomerF4: function(oEvent) {
			this._openCustomerSearchF4Help(oEvent.getSource());
		},

		_openCustomerSearchF4Help: function(oController) {
			window.openValueHelpCustomer(oController, this, true);
		},

		getSystem: function() {
			var sReturnValue = "d";
			var sUrl = this.getCurrentUrl();
			if (this.getOwnerComponent().sFioriLaunchpad) {
				if (sUrl.indexOf("wfd7746b4") > -1) {
					sReturnValue = "d";
				} else if (sUrl.indexOf("sapitcloudt") > -1) {
					sReturnValue = "t";
				} else if (sUrl.indexOf("fiorilaunchpad.sap") > -1) {
					sReturnValue = "p";
				}
			} else {
				if (sUrl.indexOf("dgq5qdz5dm") > -1) {
					sReturnValue = "d";
				} else if (sUrl.indexOf("q28pq0r93n") > -1) {
					sReturnValue = "t";
				} else if (sUrl.indexOf("mj7fgura3u") > -1) {
					sReturnValue = "d";
				} else if (sUrl.indexOf("tnxd3nxr8c") > -1) {
					sReturnValue = "t";
				} else if (sUrl.indexOf("p949rs36bi") > -1) {
					sReturnValue = "p";
				} else if (sUrl.indexOf("a73e63587") > -1) {
					sReturnValue = "t";
				} else if (sUrl.indexOf("a8f41cb0e") > -1) {
					sReturnValue = "p";
				} else if (sUrl.indexOf("supportportal") > -1) {
					sReturnValue = "p";
				}
			}
			return sReturnValue;
		},

		getAccount: function() {
			var sReturnValue = "dgq5qdz5dm.dispatcher.int.sap";
			var sUrl = this.getCurrentUrl();
			if (this.getOwnerComponent().sFioriLaunchpad) {
				if (sUrl.indexOf("wfd7746b4") > -1) {
					sReturnValue = "dgq5qdz5dm.dispatcher.int.sap";
				} else if (sUrl.indexOf("sapitcloudt") > -1) {
					sReturnValue = "a73e63587.dispatcher";
				} else if (sUrl.indexOf("fiorilaunchpad.sap") > -1) {
					sReturnValue = "supportportal.dispatcher";
				}
			} else {
				if (sUrl.indexOf("dispatcher.int.sap") > -1) {
					if (sUrl.indexOf("dgq5qdz5dm") > -1) {
						sReturnValue = "dgq5qdz5dm";
					} else if (sUrl.indexOf("q28pq0r93n") > -1) {
						sReturnValue = "q28pq0r93n";
					} else if (sUrl.indexOf("mj7fgura3u") > -1) {
						sReturnValue = "mj7fgura3u";
					} else if (sUrl.indexOf("tnxd3nxr8c") > -1) {
						sReturnValue = "tnxd3nxr8c";
					} else if (sUrl.indexOf("p949rs36bi") > -1) {
						sReturnValue = "p949rs36bi";
					} else if (sUrl.indexOf("supportportal") > -1) {
						sReturnValue = "supportportal";
					}
					sReturnValue += ".dispatcher.int.sap";
				} else {
					if (sUrl.indexOf("a73e63587") > -1) {
						sReturnValue = "a73e63587";
					} else if (sUrl.indexOf("a8f41cb0e") > -1) {
						sReturnValue = "a8f41cb0e";
					} else if (sUrl.indexOf("supportportal") > -1) {
						sReturnValue = "supportportal";
					}
					sReturnValue += ".dispatcher";
				}
			}
			return sReturnValue;
		},

		help: function() {
			var fnHelp = function() {
				this.navTo("aboutHelp");
			}.bind(this);
			if (this.getOwnerComponent()._bEditMode || this.leaveEditSettings()) {
				sap.m.MessageBox.confirm("Leave the edit page without saving?", {
					onClose: function(oAction) {
						if (oAction === "OK") {
							this.getOwnerComponent()._bSettingsEditMode = false;
							this.getEventBus().publish("sap.support.mccactivities", "LeaveEditMode");
							fnHelp();
						}
					}.bind(this)
				});
			} else {
				fnHelp();
			}
		},

		pushNotifMsgPage: function() {
			var that = this;
			var fnHelp = function() {
				that.navTo("pushNotification");
			};
			if (this.getOwnerComponent()._bEditMode || this.leaveEditSettings()) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.confirm("Leave the edit page without saving?", {
					onClose: function(oAction) {
						if (oAction === "OK") {
							that.getOwnerComponent()._bSettingsEditMode = false;
							that.getEventBus().publish("sap.support.mccactivities", "LeaveEditMode");
							fnHelp();
						}
					}
				});
			} else {
				fnHelp();
			}
		},

		onDoNotShowAgain: function() {
			var sCollection = "services/odata/svt/user_profile_srv/Entries";
			var oModel = new sap.ui.model.odata.ODataModel(sCollection, true);
			sap.ui.getCore().setModel(oModel);
			//  var oRequest = sap.ui.getCore().getModel()._createRequest();
			oModel.refreshSecurityToken();
			var oModelHeaders = oModel.getHeaders();
			var oHeaders = {
				"x-csrf-token": oModelHeaders['x-csrf-token'],
				"Content-Type": "application/json; charset=utf-8",
				"x-http-method": "MERGE"
			};
			sCollection = sCollection + "(Username='',Attribute='APP_DATA_MCC_ACTIVITIES_WELCOME',Field='')";
			var oData = {
				Value: "X"
			};
			jQuery.ajax({
				async: true,
				url: sCollection,
				type: "POST",
				dataType: "json",
				headers: oHeaders,
				data: JSON.stringify(oData),
				success: function() {},
				error: function() {}
			});
			/*var oModel = this.getOwnerComponent()._oUserProfilModel;
			oModel.update(
					"/Entries(Username='',Attribute='APP_DATA_MCC_ACTIVITIES_WELCOME',Field='')",
					{ "Value": "X"});*/
			this._oWelcomeDialog.close();
		},

		getCategoryList: function(bCreate, oAddAct) {
			this.getView().byId("category").removeAllItems();
			var aData, cData = this.getOwnerComponent().getModel("SettingList").getProperty("/CategoryList");
			// Type of cData is Array?
			if (Object.prototype.toString.call(cData) === "[object Array]") {
				aData = cData.slice();
			}
			if (!aData) {
				return;
			}
			if (bCreate) {
				aData = aData.filter(function(item) { 
					return item.value2;
				});
			}
			if (oAddAct) {
				var bHasThisCateg = false;
				$.each(aData, function(index, item) {
					if (item.value1 === oAddAct.activity_cat) {
						bHasThisCateg = true;
						return false;
					}
				});
				if (!bHasThisCateg) {
					this.getView().byId("category").addItem(
						new sap.ui.core.Item({
							key: oAddAct.activity_cat,
							text: oAddAct.activity_cat_desc
						})
					);
				}
			}

			for (var iIndex = 0; iIndex < aData.length; iIndex++) {
				this.getView().byId("category").addItem(
					new sap.ui.core.Item({
						key: aData[iIndex].value1,
						text: aData[iIndex].value3
					})
				);
			}
		},

		getStatusList: function(bSelect) {
			var that = this;
			that.getView().byId("status").removeAllItems();
			var aData = that.getOwnerComponent().getModel("SettingList").getProperty("/StatusList");
			if (bSelect) {
				that.getView().byId("status").addItem(
					new sap.ui.core.Item({
						key: "0",
						text: "Please select"
					})
				);
			}
			if (!aData) {
				return;
			}
			for (var iIndex = 0; iIndex < aData.length; iIndex++) {
				/*if (aData[iIndex].value1 === "E0010") {
					continue;
				}*/
				that.getView().byId("status").addItem(
					new sap.ui.core.Item({
						key: aData[iIndex].value1,
						text: aData[iIndex].value3
					})
				);
			}
		},

		getPriorityList: function() {
			var that = this;
			that.getView().byId("priority").removeAllItems();
			var aData = that.getOwnerComponent().getModel("SettingList").getProperty("/PriorityList");
			if (!aData) {
				return;
			}
			for (var iIndex = 0; iIndex < aData.length; iIndex++) {
				that.getView().byId("priority").addItem(
					new sap.ui.core.Item({
						key: aData[iIndex].value1,
						text: aData[iIndex].value3
					})
				);
			}
		},

		getRatingList: function() {
			var that = this;
			that.getView().byId("rating").removeAllItems();
			var aData = that.getOwnerComponent().getModel("SettingList").getProperty("/RatingList");
			if (!aData) {
				return;
			}
			that.getView().byId("rating").addItem(
				new sap.ui.core.Item({
					key: "0",
					text: "Please select"
				})
			);
			for (var iIndex = 0; iIndex < aData.length; iIndex++) {
				that.getView().byId("rating").addItem(
					new sap.ui.core.Item({
						key: aData[iIndex].value1,
						text: aData[iIndex].value3
					})
				);
			}
		},

		// getRegionList: function() {
		// 	var that = this;
		// 	that.getView().byId("region").removeAllItems();
		// 	that.getView().byId("topic").removeAllItems();
		// 	var aData = that.getOwnerComponent().getModel("SettingList").getProperty("/RegionList");
		// 	that.getView().byId("region").addItem(new sap.ui.core.Item({
		// 		key: -1,
		// 		text: "Please select"
		// 	}));
		// 	that.getView().byId("topic").addItem(new sap.ui.core.Item({
		// 		key: -1,
		// 		text: "Please select"
		// 	}));
		// 	if (!aData) {
		// 		return;
		// 	}
		// 	for (var iIndex = 0; iIndex < aData.length; iIndex++) {
		// 		that.getView().byId("region").addItem(new sap.ui.core.Item({
		// 			key: iIndex,
		// 			text: aData[iIndex].Region
		// 		}));
		// 	}
		// 	that.getView().byId("region").addItem(new sap.ui.core.Item({
		// 		key: -2,
		// 		text: "Enter Service Team Id"
		// 	}));
		// },

		// onRegionChange: function(oEvent) {
		// 	var sRegionKey = oEvent.getParameter("selectedItem").getProperty("key");
		// 	this.checkSelectedRegion(sRegionKey);
		// 	if (this.oFlagCallMe !== undefined && this.oFlagCallMe) {
		// 		this.setCMTopic(oEvent.getParameter("selectedItem").getProperty("text"));
		// 	}
		// },

		// onTopicChange: function(oEvent) {
		// 	var oSelectedItem = oEvent.getParameter("selectedItem");
		// 	var oInServiceTeam = this.getView().byId("inServiceTeam");
		// 	if (oSelectedItem.getProperty("key") !== "-1") {
		// 		oInServiceTeam.setValue(parseInt(oSelectedItem.getProperty("key"), 0));
		// 		oInServiceTeam.setVisible(true);
		// 		oInServiceTeam.setEnabled(false);
		// 	} else {
		// 		oInServiceTeam.setValue("");
		// 		oInServiceTeam.setVisible(false);
		// 		oInServiceTeam.setEnabled(true);
		// 	}
		// },

		// checkSelectedRegion: function(sRegionKey) {
		// 	var oInServiceTeam = this.getView().byId("inServiceTeam");
		// 	if (sRegionKey === "-2") {
		// 		this.getView().byId("topic").setVisible(false);
		// 		oInServiceTeam.setValue();
		// 		oInServiceTeam.setVisible(true);
		// 		oInServiceTeam.setEnabled(true);
		// 	} else if (sRegionKey !== "-1") {
		// 		this.setTopicList(sRegionKey);
		// 		this.getView().byId("topic").setVisible(true);
		// 		this.getView().byId("topic").setSelectedKey(0);
		// 		oInServiceTeam.setValue();
		// 		oInServiceTeam.setVisible(false);
		// 	} else {
		// 		this.getView().byId("topic").setVisible(false);
		// 		oInServiceTeam.setValue();
		// 		oInServiceTeam.setVisible(false);
		// 	}
		// },
		
		// setTopicList: function(regionkey) {
		// 	var iRegionKey = parseInt(regionkey, 0);
		// 	var aData = this.getOwnerComponent().getModel("SettingList").getProperty("/RegionList")[iRegionKey].Topic;
		// 	var oTopic = this.getView().byId("topic");
		// 	oTopic.removeAllItems();
		// 	oTopic.addItem(new sap.ui.core.Item({
		// 		key: -1,
		// 		text: "Please select"
		// 	}));
		// 	for (var index = 0; index < aData.length; index++) {
		// 		oTopic.addItem(
		// 			new sap.ui.core.Item({
		// 				key: aData[index].service_team_id,
		// 				text: aData[index].name
		// 			})
		// 		);
		// 	}
		// },

		// setServiceTeam: function(serviceTeam) {
		// 	var oTopic = this.getView().byId("topic");
		// 	var oRegion = this.getView().byId("region");
		// 	var oInServiceTeam = this.getView().byId("inServiceTeam");
		// 	var aData = this.getOwnerComponent().getModel("SettingList").getProperty("/RegionList");
		// 	if (serviceTeam === "") {
		// 		oRegion.setSelectedKey("-1");
		// 		oTopic.setSelectedKey("-1");
		// 		oTopic.setVisible(false);
		// 		oInServiceTeam.setValue("");
		// 		oInServiceTeam.setVisible(false);
		// 		oInServiceTeam.setEnabled(true);
		// 	} else {
		// 		for (var indexRegion = 0; indexRegion < aData.length; indexRegion++) {
		// 			for (var indexTopic = 0; indexTopic < aData[indexRegion].Topic.length; indexTopic++) {
		// 				// use "==" because type of serviceTeam doesn't match
		// 				if (aData[indexRegion].Topic[indexTopic].service_team_id == serviceTeam) {
		// 					oRegion.setSelectedKey(indexRegion);
		// 					this.checkSelectedRegion(indexRegion);
		// 					oTopic.setSelectedKey(aData[indexRegion].Topic[indexTopic].service_team_id);
		// 					oTopic.setVisible(true);
		// 					oInServiceTeam.setValue(serviceTeam);
		// 					oInServiceTeam.setVisible(true);
		// 					oInServiceTeam.setEnabled(false);
		// 					return;
		// 				}
		// 			}
		// 			oRegion.setSelectedKey("-2");
		// 			oTopic.setSelectedKey("-1");
		// 			oTopic.setVisible(false);
		// 			oInServiceTeam.setValue(serviceTeam);
		// 			oInServiceTeam.setVisible(true);
		// 			oInServiceTeam.setEnabled(true);
		// 		}
		// 	}
		// },

		// setDefaultCategory: function() {
		// 	var oUserProfileData = this.getOwnerComponent().getModel("UserProfile").getData();
		// 	if (this._checkFilledObject(oUserProfileData)) {
		// 		var aData = this.getOwnerComponent().getModel("DefaultCategory").getProperty("/result");
		// 		this.getView().byId("category").setSelectedKey(aData);
		// 	} else {
		// 		this.getView().byId("category").setSelectedKey("-1");
		// 	}
		// },

		// _checkFilledObject: function(obj) {
		// 	for (var key in obj) {
		// 		return true;
		// 	}
		// 	return false;
		// },

		CloseDialog: function(oEvent) {
			oEvent.getSource().getParent().close();
		},

		afterCloseDialog: function(oEvent) {
			oEvent.getSource().destroy();
		},

		addEFOStoTitle: function() {
			this.getView().setBusy(true);
			this.getOwnerComponent().getModel("CreateControl").setProperty("/EFOSDialogAccept", false);
			if (this._oEFOSDialog) {
				this._oEFOSDialog.close();
			}
			this._searchFields_activity.title = "EFOS:" + this._searchFields_activity.title;
			this.createActivity(this._searchFields_activity);
		},

		cancelEFOSDialog: function() {
			if (this._oEFOSDialog) {
				this._oEFOSDialog.close();
			}
			this.getView().byId("iBtnCreateAct").setEnabled(true);
			this.getView().setBusy(false);
		},

		createActivity: function(searchFields_activity) {
			this.eventUsage(false, "Create activity");
			var that = this;
			//var sUrl = that.getDataSource("env_PG_AGS_DASHBOARDS");
			/*var sCollection = sUrl + "ActivityList";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			sap.ui.getCore().setModel(oModel);
			//  var oRequest = sap.ui.getCore().getModel()._createRequest();
			oModel.refreshSecurityToken();
			var oModelHeaders = oModel.getHeaders();
			var oHeaders = {
				"x-csrf-token": oModelHeaders["x-csrf-token"],
				"Content-Type": "application/json; charset=utf-8"
			};*/
			var entries = {};
			if (searchFields_activity.serviceTeam && searchFields_activity.serviceTeam !== "0") {
				entries.activity_service_team = searchFields_activity.serviceTeam;
			} else {
				entries.activity_service_team = "";
			}
			if (searchFields_activity.category && searchFields_activity.category !== "0") {
				entries.activity_cat = searchFields_activity.category;
			} else {
				entries.category = "";
			}
			if (searchFields_activity.prio && searchFields_activity.prio !== "0") {
				entries.activity_priority_code = searchFields_activity.prio;
			} else {
				entries.activity_priority_code = "";
			}
			if (searchFields_activity.caseID && searchFields_activity.caseID !== "0") {
				entries.activity_case_id = searchFields_activity.caseID;
			} else {
				entries.activity_case_id = "";
			}
			if (searchFields_activity.requestorVisible && searchFields_activity.requestor) {
				entries.activity_requestor_id = searchFields_activity.requestor;
			} else {
				entries.activity_requestor_id = "";
			}
			var oModel = new sap.ui.model.json.JSONModel({
				ActivityList: [{
					activity_process_type: "ZS46",
					Notes: searchFields_activity.actDescr,
					activity_description: searchFields_activity.title,
					activity_activity_partner: searchFields_activity.BPNo,
					activity_customer: searchFields_activity.ERPNo,
					activity_service_team: entries.activity_service_team,
					activity_cat: entries.activity_cat,
					activity_priority: entries.activity_priority_code,
					activity_person_user_id: Formatter.uppercaseLeadingLetter(searchFields_activity.userId),
					activity_planned_date_to: "/Date(" + new Date().setDate(new Date().getDate() + 1) + ")/",
					CaseId: entries.activity_case_id,
					activity_requestor_id: entries.activity_requestor_id
				}]
			});
			//var oModelAgsDB = new sap.ui.model.odata.ODataModel(sUrl, true);
			if (!this.getOwnerComponent().oDashBoardsModel) {
				return;
			}
			this.getOwnerComponent().oDashBoardsModel.create("/ActivityList", oModel.getData().ActivityList[0], {
				success: function(data) {
					//Fehler -  keine ID wird zurückgeliefert, wenn über Kunden angelegt... 
					//Daher wenn ID leer --> StartBildschirm
					//that.getView().byId("iBtnCreateAct").setEnabled(true);
					//that.getOwnerComponent().getModel("CreateControl").setProperty("/InvalidCaseIdDialogAccept", true);
					that.getView().setBusy(false);
					that._clearCreateModel();
					if (data) {
						if (data.activity_id === "") {
							sap.m.MessageToast.show("Error during creation: No Activity ID");
							that.navTo("detail");

						} else {
							that._activitySelected = data.activity_id;
							that._BPcustNoSelected = data.activity_activity_partner;
							that.navTo("detail");
							that.getEventBus().publish("sap.support.mccactivities", "DisplayActivity", {
								id: data.activity_id
							});
							//that.getEventBus().publish("sap.support.mccactivities", "RefreshMasterLists");
							that.getOwnerComponent().oDataManager.loadActivitiesList();
						}
					}
				},
				error: function() {
					that.getView().setBusy(false);
					that._clearCreateModel();
					sap.m.MessageToast.show("Error during creation: Failed");
					that.navTo("detail");
				}
			});
		},

		getActivityDetails: function(activityID) {
			var oSearchFields = {};
			if (activityID === "") {
				oSearchFields.crmCustNo = this._BPcustNoSelected;
			} else {
				//oSearchFields.activityID = new sap.m.Text();
				oSearchFields.activityID = activityID;
			}
			//this.viewSelected = "activityAppSearchResult";
			this.startSearchActivityByID(oSearchFields);
		},

		startSearchActivityByID: function(oSearchFields) {
			var filter = "";
			var that = this;
			var expand = "";
			var count = 0;
			this.activitySearchCount++;
			that.getView().setBusy(true);
			var sActivityUrl = that.getDataSource("env_PG_AGS_DASHBOARDS") + "ActivityList?$filter=";
			if (oSearchFields.activityID !== "" && oSearchFields.activityID !== "0" && oSearchFields.activityID !== undefined) {
				if (count > 0) {
					filter += "and%20activity_id%20eq%20'" + oSearchFields.activityID + "'%20";
				} else {
					filter += "activity_id%20eq%20'" + oSearchFields.activityID + "'%20";
				}
				count++;
			}
			filter += "and%20activity_process_type%20eq%20'ZS46'" + expand;
			if (count > 0) {
				sActivityUrl += filter;
				sActivityUrl += "&$expand=PartiesInvolved,ActivityCases,Attachment";
				jQuery.ajax({
					async: true,
					url: sActivityUrl,
					type: "get",
					dataType: "json",
					success: function(data) {
						var activities = {};
						activities = data.d.results;
						//that.activityDetail = activities;
						if (data.d.results.length !== 0) {
							/*that.activityNotes = {};
							that.activityNotes = data.d.results[0].ActivityNotes.results;*/
							if (activities[0].activity_status === "Restricted") {
								sap.m.MessageToast.show("This activity has status \"Restricted\". It can be accessed only directly via CRM", {
									duration: 6000
								});
								//alert("This activity has status \"Restricted\". It can be accessed only directly via CRM");
								that.navTo("detail");
							} else {
								/*var aPartiesInvolved = data.d.results[0].PartiesInvolved.results;
								for(var index = 0; index < aPartiesInvolved.length; index++){
									if(aPartiesInvolved[index].parties_function === "Service Team"){
										activities[0].activity_service_team_name = aPartiesInvolved[index].name;
									}
								}*/
								if (activities[0].ActivityCases.results.length === 0) {
									// add empty case_id for data binding
									activities[0].ActivityCases.results.push({
										transactions_case_id: "",
										transactions_id: ""
									});
									that.setBShowCaseIcon(activities[0], true);
								} else {
									that.setBShowCaseIcon(activities[0], false);
								}
								activities = that.checkFavorite(activities);
								that._oModel.setData(that.prepareDate(activities[0]));
								that.getView().setModel(that._oModel, "Detail");
								//._oModelEdit.setData(activities[0]);
								that.getView().setModel(that._oModelEdit, "DetailEdit");
								that.getActivityNotes(oSearchFields);
							}
						}
						that.getView().setBusy(false);
					},
					error: function() {
						sap.m.MessageToast.show("Error during activity search. Please reload this page.");
						that.getView().setBusy(false);
						that.navTo("detail");
					}
				});
			}
		},

		checkFavorite: function(activities) {
			if (!activities) {
				return activities;
			}
			var bFavorite = false;
			var aFavorites = this.getOwnerComponent().getModel("UserProfile").getProperty("/FAVORITE_ACTIVITIES");
			if (aFavorites !== undefined) {
				for (var index = 0; index < activities.length; index++) {
					for (var iFavoriteIndex = 0; iFavoriteIndex < aFavorites.length; iFavoriteIndex++) {
						if (activities[index].activity_id === aFavorites[iFavoriteIndex].Value || aFavorites[iFavoriteIndex].Value.indexOf(activities[index].activity_id) > -1) {
							bFavorite = true;
							break;
						} else {
							bFavorite = false;
						}
					}
					activities[index]._bFavorite = bFavorite;
				}
			}
			return activities;
		},

		setBShowCaseIcon: function(oActivity, bShowNoCaseIcon) {
			oActivity._bShowCaseIcon = bShowNoCaseIcon;
			oActivity._bShowNoCaseIcon = !bShowNoCaseIcon;
		},

		getActivityNotes: function(searchFields) {
			var that = this;
			var sActivityUrl = that.getDataSource("env_PG_AGS_DASHBOARDS") + "ActivityNotesList?$filter=activity_id%20eq%20%27" + searchFields.activityID +
				"%27%20and%20notes_type%20eq%20%27HIST%27";
			jQuery.ajax({
				async: true,
				url: sActivityUrl,
				type: "get",
				dataType: "json",
				success: function(data) {
					that.prepareNote(data);
				},
				error: function() {}
			});
		},

		leaveEditSettings: function() {
			if (this.getOwnerComponent().getCurrentRoute() === "settings") {
				this.getOwnerComponent().getEventBus().publish("sap.support.mccactivities", "CheckSettingsChanged");
				return this.getOwnerComponent()._bSettingsEditMode;
			} else {
				return false;
			}
		},
		
		prepareDateNew: function(oData) {
			var oActivity = oData.results[0];
			oActivity.activity_change_time = oActivity.activity_change_date.setMilliseconds(oActivity.activity_change_time.ms - 28800000);
			oActivity.activity_change_time = new Date(oActivity.activity_change_time);
			oActivity.activity_create_time = oActivity.activity_create_date.setMilliseconds(oActivity.activity_create_time.ms - 28800000);
			oActivity.activity_create_time = new Date(oActivity.activity_create_time);
			return oActivity;
		},

		prepareDate: function(oActivity) {
			var fValue = oActivity.activity_change_time;
			jQuery.sap.require("sap.ui.core.format.DateFormat");
			var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "KK:mm:ss a"
			});
			if (fValue !== undefined || fValue !== null) {
				fValue = Date(oTimeFormat.parse(fValue));
			}
			//var oReturn = oTimeFormat.format(new Date(fValue));
			var oChangeDate = new Date();
			oChangeDate.setTime(oActivity.activity_change_date.substring(6, 16) * 1000);
			var sHour = oActivity.activity_change_time.substring(2).split("H")[0];
			var sMinute = oActivity.activity_change_time.substring(5).split("M")[0];
			var sSecond = oActivity.activity_change_time.substring(8).split("S")[0];
			oChangeDate.setHours(sHour, sMinute, sSecond);
			oActivity.activity_change_date = oChangeDate;
			var oChangeTime = new Date();
			//oChangeTime.setTime(oActivity.activity_change_time.substring(6, 16) * 1000);
			sHour = oActivity.activity_change_time.substring(2).split("H")[0];
			sMinute = oActivity.activity_change_time.substring(5).split("M")[0];
			sSecond = oActivity.activity_change_time.substring(8).split("S")[0];
			oChangeTime.setHours(sHour, sMinute, sSecond);
			oActivity.activity_change_time = oChangeTime;
			var oCreateDate = new Date();
			oCreateDate.setTime(oActivity.activity_create_date.substring(6, 16) * 1000);
			var sHour = oActivity.activity_create_time.substring(2).split("H")[0];
			var sMinute = oActivity.activity_create_time.substring(5).split("M")[0];
			var sSecond = oActivity.activity_create_time.substring(8).split("S")[0];
			oCreateDate.setHours(sHour, sMinute, sSecond);
			oActivity.activity_create_date = oCreateDate;
			var oCreateTime = new Date();
			//oCreateTime.setTime(oActivity.activity_change_time.substring(6, 16) * 1000);
			sHour = oActivity.activity_create_time.substring(2).split("H")[0];
			sMinute = oActivity.activity_create_time.substring(5).split("M")[0];
			sSecond = oActivity.activity_create_time.substring(8).split("S")[0];
			oCreateTime.setHours(sHour, sMinute, sSecond);
			oActivity.activity_create_time = oCreateTime;
			var oPlannedDate = new Date();
			if (oActivity.activity_planned_date !== null) {
				oPlannedDate.setTime(oActivity.activity_planned_date.substring(6, 16) * 1000);
				oActivity.activity_planned_date = oPlannedDate;
			}
			var oPlannedDateTo = new Date();
			if (oActivity.activity_planned_date_to !== null) {
				oPlannedDateTo.setTime(oActivity.activity_planned_date_to.substring(6, 16) * 1000);
				oActivity.activity_planned_date_to = oPlannedDateTo;
			}
			var oToDate = new Date();
			oToDate.setTime(oActivity.to_date.substring(6, 16) * 1000);
			oActivity.to_date = oToDate;
			return oActivity;
		},

		_clearCreateModel: function() {
			this.getView().byId("iBtnCreateAct").setEnabled(true);
			this.getOwnerComponent().getModel("CreateControl").setProperty("/InvalidCaseIdDialogAccept", true);
			this.getOwnerComponent().getModel("CreateControl").setProperty("/NoAccountDialogAccept", true);
			this.getOwnerComponent().getModel("CreateControl").setProperty("/EFOSDialogAccept", true);
		},

		navTo: function(oRoute) {
			this.getOwnerComponent().getRouter().navTo(oRoute);
			this.eventUsage(oRoute);
			/* global swa */
			if (swa) {
				swa.trackLoad();
				swa.trackCustomEvent("mccact", "2");
			}
		},

		eventUsage: function(oRoute, sEventName) {
			if (oRoute) {
				sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Navigation to \'" + oRoute + "\' view");
			} else {
				sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), sEventName);
			}
		}
	});
});
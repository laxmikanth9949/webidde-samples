sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/support/mccactivities/util/Formatter",
	"sap/support/mccactivities/model/help"
], function(Controller, JSONModel, Formatter, help) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.view.PushNotificationMsg", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf sap.support.mccactivities.view.view.PushNotificationMsg
		 */
		onInit: function() {
			var sUrl = this.getOwnerComponent().getDataSource("env_PG_AGS_DASHBOARDS");
			this.oDataModelMsg = new sap.ui.model.odata.ODataModel(sUrl, true);
			this.getView().addEventDelegate({
				onBeforeShow: function() {
					//this._readPushNotificationMsg();
					this.getOwnerComponent().oDataManager.readNotificationMsg(this._syncBadgeNumber);
				}.bind(this)
			});
		},

		onPressNotifListItem: function(oEvent) {
			this._minusBadgeNumber(oEvent);
			/*var oMsgList = this.getView().getModel("pushNotifMsg").getData();
			var oIndex = oEvent.getSource().getBindingContextPath().replace("/results/", "");
			var oMsgItem = oMsgList.results[oIndex];
			var oActivityId;
			this.oDataModelMsg.update("/pushnotfmsgSet(msg_key='" + oMsgItem.msg_key + "')", {
				"msg_key": oMsgItem.msg_key
			}, {
				success: function(oSuccess) {
					this._readPushNotificationMsg();
				}.bind(this),
				error: function(oError) {}
			});*/
			var oCustomData = oEvent.getSource().getCustomData();
			this.getOwnerComponent().oDataManager.updateNotificationMsg(oCustomData[0].getValue());
			this._toActivityDetail(oCustomData[1].getValue());
			/*if (oMsgItem.object_id !== "") {
				oActivityId = oMsgItem.object_id;
			} else {
				oActivityId = oMsgItem.data;
			}
			this._toActivityDetail(oActivityId);*/
		},

		onDeleteNotifListItem: function(oEvent) {
			this._minusBadgeNumber(oEvent);
			/*var oListControl = oEvent.getSource().getParent();
			oListControl.setBusy(true);*/
			/*var oMsgList = this.getView().getModel("pushNotifMsg").getData();
			var oIndex = oEvent.getSource().getBindingContextPath().replace("/results/", "");
			var oMsgItem = oMsgList.results[oIndex];*/
			/*this.oDataModelMsg.remove("/pushnotfmsgSet(msg_key='" + oMsgItem.msg_key + "')", {
				success: function(oSuccess) {
					this._readPushNotificationMsg();
					oListControl.setBusy(false);
				}.bind(this),
				error: function(oError) {}
			});*/
			this.getOwnerComponent().oDataManager.removeNotificationMsg(oEvent.getSource().getCustomData()[0].getValue());
		},

		onDeleteAll: function(oEvent) {
			this._resetBadgeNumber();
			/*var oListControl = oEvent.getSource().getParent();
			var oDataPushNotif = this.getView().getModel("pushNotifMsg").getData();
			if (oDataPushNotif.results !== undefined && oDataPushNotif.results.length !== 0) {
				oListControl.setBusy(true);
				this.oDataModelMsg.remove("/pushnotfmsgSet(msg_key='DELETE_ALL')", {
					success: function(oSuccess) {
						this._readPushNotificationMsg();
						oListControl.setBusy(false);
					}.bind(this),
					error: function(oError) {
						oListControl.setBusy(false);
					}
				});
			}*/
			this.getOwnerComponent().oDataManager.removeNotificationMsg("DELETE_ALL");
		},

		onNavBack: function() {
			help.navTo(this.getOwnerComponent() ,"master");
		},

		_readPushNotificationMsg: function() {
			var oModelPushNotifMsg = new JSONModel();
			this.oDataModelMsg.read("/pushnotfmsgSet", {
				success: function(oData) {
					oModelPushNotifMsg.setData(oData);
				}
			});
			this.getView().setModel(oModelPushNotifMsg, "pushNotifMsg");
		},

		_toActivityDetail: function(ActivityId) {
			help.navTo(this.getOwnerComponent(), "detail");
			sap.ui.getCore().getEventBus().publish("sap.support.mccactivities", "DisplayActivity", {
				id: ActivityId
			});
		},
		
		_syncBadgeNumber: function(component) {
			if (sap.Push) {
				var curBadgeNum = 0;
				var aMsg = component.getModel("NotificationMsg").getProperty("/Messages");
				$.each(aMsg, function(index, item) {
					if (item.is_read === "") {
						curBadgeNum ++;
					}
				});
				sap.Push.setBadgeNumber(curBadgeNum);
			}
		},
		
		_minusBadgeNumber: function(oEvent) {
			if (sap.Push && oEvent.getSource().getPriority() === "High") {
				sap.Push.getBadgeNumber(function(nCount) {
					if (nCount > 0) {
						sap.Push.setBadgeNumber(nCount - 1);
					}	
				});
			}
		},
		
		_resetBadgeNumber: function() {
			if (sap.Push) {
				//sap.Push.resetBadge(this.getOwnerComponent().resetBadgeSuccess);
				sap.Push.setBadgeNumber(0);
			}
		}

	});

});
sap.ui.define([
	"sap/support/mccactivities/util/BaseController",
	"sap/support/mccactivities/util/Formatter",
	"sap/m/MessageBox"
], function(Controller, Formatter, MessageBox) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.view.MasterActivities", {
		_oActivities: new sap.ui.model.json.JSONModel({}),
		_oUser: new sap.ui.model.json.JSONModel({}),
		/*_sExpandedPanel: "PanelAssigned",*/
		_bDoInit: true,
		_sMasterListsLoaded: "",
		_bIntialDisplayFirst: true,
		formatter: Formatter,

		onInit: function() {
			var that = this;

			that.getView().setModel(that._oActivities, "Activities");
			that.getView().setModel(that.getOwnerComponent().getModel("Settings"), "Settings");
			that.getView().setModel(that.getOwnerComponent().getModel("SettingList"), "SettingList");
			that.getView().setModel(that._oUser, "User");

			this.getView().addEventDelegate({
				onBeforeShow: function(oEvent) {
					that._oRouter = oEvent.data.oRouter;
					that._sSelected = oEvent.data.sSelected;
					this._onShowLatestVersionPopup();
				}.bind(this)
			});
		},
		
		_onShowLatestVersionPopup: function() {
			if(sap.Push) {
				MessageBox.warning(this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("txt_msgUpdateMobVersion"));
			} else {
				MessageBox.warning(
					this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("txt_msgUpdateWebVersion"),
					{
						actions: ["Go", MessageBox.Action.CLOSE],
						onClose: function(sAction) {
							if(sAction === "Go") {
								window.location.href = "ht" + "tps://mccactivity-sapitcloud.dispatcher.hana.ondemand.com";
							}
						}
					}
				);
			}
		},
		
		onAfterRendering: function() {
			if (this._bDoInit) {
				this.handleURIParamters();
				this._bDoInit = false;
			}
		},

		openWelcomeDialog: function() {
			//(this._oWelcomeDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.WhatsNewDialog", this)).open();
			this._oWelcomeDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.WhatsNewDialog", this);
			this.getView().addDependent(this._oWelcomeDialog);
			this._oWelcomeDialog.open();
		},

		handleURIParamters: function() {
			var oUriParameters = jQuery.sap.getUriParameters();
			switch (oUriParameters.get("event")) {
				case "create":
					// create initial view for "detail" in case navigation error
					//this.navTo("detail");
					this.navTo("create");
					this._bIntialDisplayFirst = false;
					this.getEventBus().publish("sap.support.mccactivities", "CreateUsingEvent", {
						data: this._getEventCreationProperties()
					});
					break;
				case "display":
					var sAcitivtyId = oUriParameters.get("activityid");
					this.getEventBus().publish("sap.support.mccactivities", "DisplayActivity", {
						id: sAcitivtyId
					});
					this._bIntialDisplayFirst = false;
					break;
				case "settings":
					this.navTo("settings");
					this._bIntialDisplayFirst = false;
					this.getEventBus().publish("sap.support.mccactivities", "SettingsUsingEvent", {
						data: oUriParameters.get("tag")
					});
					break;
				default:
			}
		},

		onSearch: function(oEvent) {
			sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Search for activity within List");
			if (oEvent.getParameter("refreshButtonPressed")) {
				this.refreshLists();
			}
		},

		refreshLists: function() {
			this.getOwnerComponent().oDataManager.loadActivitiesList();
		},

		filterMasterLists: function() {
			this.setFilter("Assigned");
			this.setFilter("CreatedByMe");
			this.setFilter("Favorites");
			this.setFilter("ForMyFavoriteCustomers");
			this.setFilter("ServiceTeam");
		},

		filterList: function(sSearchString, sList) {
			var aFilters = [new sap.ui.model.Filter("searchString", sap.ui.model.FilterOperator.Contains, sSearchString)];
			if (this.getView().byId(sList).getBinding("items")) {
				this.getView().byId(sList).getBinding("items").filter(aFilters, false);
			}
			if (this.getView().byId(sList).getBinding("items")) {
				this.getView().byId("Count" + sList).setText("(" + this.getView().byId(sList).getBinding("items").aIndices.length + ")");
			}
		},

		sortList: function(sList) {
			var oItems = this.getView().byId(sList).getBinding("items");
			oItems.sort(new sap.ui.model.Sorter("activity_change_date", true));
		},

		onSelectActivity: function(oEvent) {
			var that = this;
			that._sSelectedActivity = oEvent.getSource().getNumber();
			if (this.getOwnerComponent()._bEditMode || this.leaveEditSettings()) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.confirm("Leave the edit page without saving?", {
					onClose: function(oAction) {
						if (oAction === "OK") {
							that.getOwnerComponent()._bSettingsEditMode = false;
							if (that.getOwnerComponent().getCurrentRoute() === "detail") {
								that.getEventBus().publish("sap.support.mccactivities", "LeaveEditMode");
							} else if (this.getOwnerComponent().getCurrentRoute() === "settings") {
								this.getOwnerComponent().getEventBus().publish("sap.support.mccactivities", "RecoverSettings");
							}
							that.getEventBus().publish("sap.support.mccactivities", "DisplayActivity", {
								id: that._sSelectedActivity
							});
							that.navTo("detail");
						}
					}.bind(this)
				});
			} else {
				that.navTo("detail");
				that.getEventBus().publish("sap.support.mccactivities", "DisplayActivity", {
					id: oEvent.getSource().getNumber()
				});
			}
		},

		setFilter: function(sList) {
			var aFilter = this.getFilters();
			if (this.getView().byId(sList).getBinding("items").oList.length > 0) {
				this.getView().byId(sList).getBinding("items").filter(aFilter, false);
			}
			var aList = this.getView().byId(sList).getBinding("items").aIndices;
			if (!aList) {
				aList = [];
			}
			this.getView().byId("Count" + sList).setText("(" + aList.length + ")");
		},

		getFilters: function() {
			var aFilter = [];
			var oFilter = {};
			var aDataStatus = this.getOwnerComponent().getModel("SettingList").getProperty("/StatusList");
			for (var indexS = 0; indexS < aDataStatus.length; indexS++) {
				if (aDataStatus[indexS].bSelected) {
					oFilter = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, aDataStatus[indexS].value1);
					aFilter.push(oFilter);
				}
			}
			var aDataCateg = this.getOwnerComponent().getModel("SettingList").getProperty("/CategoryList");
			for (var indexC = 0; indexC < aDataCateg.length; indexC++) {
				if (aDataCateg[indexC].bSelected) {
					oFilter = new sap.ui.model.Filter("activity_cat", sap.ui.model.FilterOperator.EQ, aDataCateg[indexC].value1);
					aFilter.push(oFilter);
				}
			}
			var sSearchString = this.getView().byId("searchField").getValue();
			if (sSearchString.length > 0) {
				oFilter = new sap.ui.model.Filter("searchString", sap.ui.model.FilterOperator.Contains, sSearchString);
				aFilter.push(oFilter);
			}
			return aFilter;
		},

		onCreateActivity: function() {
			var that = this;
			var fnNavToDetail = function() {
				that.navTo("create");
			};
			if (this.getOwnerComponent()._bEditMode || this.leaveEditSettings()) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.confirm("Leave the edit page without saving?", {
					onClose: function(oAction) {
						if (oAction === "OK") {
							that.getOwnerComponent()._bSettingsEditMode = false;
							that.getEventBus().publish("sap.support.mccactivities", "LeaveEditMode");
							fnNavToDetail();
						}
					}
				});
			} else {
				fnNavToDetail();
			}

		},

		onSearchActivityDialog: function() {
			var that = this;
			var fnOpenDialog = function() {
				that._oActivityByIdDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.getActivityByIdDialog", that);
				that.getView().addDependent(that._oActivityByIdDialog);
				that._oActivityByIdDialog.open();
			};
			if (this.getOwnerComponent()._bEditMode) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.confirm("Leave the edit page without saving?", {
					onClose: function(oAction) {
						if (oAction === "OK") {
							that.getEventBus().publish("sap.support.mccactivities", "LeaveEditMode");
							fnOpenDialog();
						}
					}
				});
			} else {
				fnOpenDialog();
			}
		},

		CloseDialog: function(oEvent) {
			oEvent.getSource().getParent().close();
		},

		afterCloseDialog: function(oEvent) {
			oEvent.getSource().destroy();
		},

		getActivityById: function() {
			sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Search activity");
			var oInput = this._oActivityByIdDialog.getContent()[0].getContent()[1];
			var sActivityId = oInput.getValue();
			if (sActivityId === "" || isNaN(sActivityId)) {
				oInput.setValueState(sap.ui.core.ValueState.Error);
				oInput.setValueStateText("Please fill this field!");
				return;
			}
			this._oActivityByIdDialog.close();
			this.navTo("detail");
			this.getEventBus().publish("sap.support.mccactivities", "DisplayActivity", {
				id: sActivityId
			});
		},

		onFilterMasterLists: function() {
			var that = this;
			var fnOpenDialog = function() {
				that._oFilterDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.FilterDialog", that);
				that._oFilterDialog.setModel(that.getOwnerComponent().getModel("SettingList"), "SettingList");
				that.getView().addDependent(that._oFilterDialog);
				that._oFilterDialog.open();
			};
			if (this.getOwnerComponent()._bEditMode) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.confirm("Leave the edit page without saving?", {
					onClose: function(oAction) {
						if (oAction === "OK") {
							that.getEventBus().publish("sap.support.mccactivities", "LeaveEditMode");
							fnOpenDialog();
						}
					}
				});
			} else {
				fnOpenDialog();
			}
		},

		onFilterDialogConfirm: function(oEvent) {
			var aData = oEvent.getParameter("filterItems");
			if (this._checkNoSelectedStatus(aData)) {
				sap.m.MessageBox.confirm("Please select at least one 'Status' item.", {
					onClose: function(oAction) {
						this.onFilterMasterLists();
					}.bind(this)
				});
			} else {
				sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Save filters");
				var index, sPath;
				this._oFilterDialog.destroy();
				var oFilters = this.getOwnerComponent().getModel("SettingList").getData();
				for (index = 0; index < oFilters.CategoryList.length; index++) {
					sPath = "/CategoryList/" + index + "/bSelected";
					this.getOwnerComponent().getModel("SettingList").setProperty(sPath, false);
				}
				for (index = 0; index < oFilters.StatusList.length; index++) {
					sPath = "/StatusList/" + index + "/bSelected";
					this.getOwnerComponent().getModel("SettingList").setProperty(sPath, false);
				}
				for (index = 0; index < aData.length; index++) {
					sPath = aData[index].getBindingContext("SettingList").getPath() + "/bSelected";
					this.getOwnerComponent().getModel("SettingList").setProperty(sPath, true);
				}
				this.saveCategoryFilter();
				this.saveStatusFilter();
				this.refreshLists();
			}
		},
		
		_checkNoSelectedStatus: function(aData) {
			var result = true;
			$.each(aData, function(index, item) {
				if (item.getBindingContext("SettingList").getPath().indexOf("StatusList") !== -1) {
					result = false;
				}
			});
			return result;
		},

		onFilterDialogCancel: function() {
			this._oFilterDialog.destroy();
		},

		onFilterDialogResetFilters: function(oEvent) {
			//this.setInitialFilter();
		},

		saveCategoryFilter: function() {
			var aCategList = this.getOwnerComponent().getModel("SettingList").getProperty("/CategoryList");
			var auxData = [];
			$.each(aCategList, function(index, item) {
				if (item.bSelected) {
					auxData.push(item.value1);
				}
			});
			this.getOwnerComponent().oDataManager.saveCategoryFilter(auxData);
		},

		saveStatusFilter: function() {
			var oStatusList = this.getOwnerComponent().getModel("SettingList").getProperty("/StatusList");
			var auxData = [];
			$.each(oStatusList, function(index, item) {
				if (item.bSelected) {
					auxData.push(item.value1);
				}
			});
			this.getOwnerComponent().oDataManager.saveStatusFilter(auxData);
		},

		onOverflow: function(oEvent) {
			var oButton = oEvent.getSource();
			if (!this._actionSheet) {
				this._actionSheet = sap.ui.xmlfragment("sap.support.mccactivities.fragment.MasterActionSheet", this);
				this.getView().addDependent(this._actionSheet);
			}
			this._actionSheet.openBy(oButton);
		},

		onBack: function() {
			var that = this;
			var fnNavBack = function() {
				that.navTo("master");
			};
			if (this.getOwnerComponent()._bEditMode || this.leaveEditSettings()) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.confirm("Leave the edit page without saving?", {
					onClose: function(oAction) {
						if (oAction === "OK") {
							that.getOwnerComponent()._bSettingsEditMode = false;
							that.getEventBus().publish("sap.support.mccactivities", "LeaveEditMode");
							fnNavBack();
						}
					}
				});
			} else {
				fnNavBack();
			}
		},

		onPanelExpand: function(oEvent) {
			/*var sPanelId = oEvent.getParameter("id").substring(49);
			if (this._sExpandedPanel !== sPanelId) {
				if (this._sExpandedPanel !== "") {
					this.getView().byId(this._sExpandedPanel).setExpanded(false);
				}
				this._sExpandedPanel = sPanelId;
			} else {
				this._sExpandedPanel = "";
			}*/
		},

		onSettings: function() {
			this.navTo("settings");
		},

		_getEventCreationProperties: function() {
			var oActivity = {};
			if (jQuery.sap.getUriParameters().get("prio") !== null) {
				oActivity.priority = jQuery.sap.getUriParameters().get("prio");
			} else {
				oActivity.priority = "5";
			}
			if (jQuery.sap.getUriParameters().get("serviceteam") != null) {
				oActivity.serviceteam = jQuery.sap.getUriParameters().get("serviceteam");
			}
			if (jQuery.sap.getUriParameters().get("category") != null) {
				oActivity.category = jQuery.sap.getUriParameters().get("category");
			}
			if (jQuery.sap.getUriParameters().get("erpcust") !== null) {
				oActivity.customer = jQuery.sap.getUriParameters().get("erpcust");
			}
			if (jQuery.sap.getUriParameters().get("caseid") !== null) {
				oActivity.caseid = jQuery.sap.getUriParameters().get("caseid");
			}
			if (jQuery.sap.getUriParameters().get("desc") !== null) {
				oActivity.desc = jQuery.sap.getUriParameters().get("desc");
			}
			if (jQuery.sap.getUriParameters().get("title") !== null) {
				oActivity.title = jQuery.sap.getUriParameters().get("title");
			}
			return oActivity;
		},

		afterMasterListUpdate: function(oEvent) {
			if (oEvent.getParameters("reason").reason === "Growing") {
				sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Display more activities");
			}
		}
	});
});
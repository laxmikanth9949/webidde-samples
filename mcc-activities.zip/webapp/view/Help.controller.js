sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/support/mccactivities/model/help"
], function(Controller, help) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.view.Help", {
		onNavBack: function() {
			help.navTo(this.getOwnerComponent(), "aboutHelp");
		}
	});
});
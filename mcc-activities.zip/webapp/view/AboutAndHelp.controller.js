sap.ui.define([
	"sap/support/mccactivities/util/BaseController",
	"sap/support/mccactivities/util/Formatter"
], function(Controller, Formatter) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.view.AboutAndHelp", {
		onInit: function() {
			var oImageSRC = jQuery.sap.getModulePath("sap.support.mccactivities") + "/res/favicon.png";
			this.getView().byId("iMainImage").setSrc(oImageSRC);
		},

		onNavBack: function() {
			//window.history.go(-1);
			this.navTo("master");
		},

		onNews: function() {
			/*this._oWelcomeDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.WhatsNewDialog", this);
			this.getView().addDependent(this._oWelcomeDialog);
			this._oWelcomeDialog.open();*/
			sap.m.URLHelper.redirect("ht" + "tps://jam4.sapjam.com/blogs/show/tK1WIdjgjEdpHeGaE5DuGn", true);
		},

		onJam: function() {
			//var sLink = "ht" + "tps://go.sap.corp/MCC-Activities";
			var sLink = "ht" + "tps://jam4.sapjam.com/wiki/show/bSqwaf1AJfhnV61OfzSgrG";
			sap.m.URLHelper.redirect(sLink, true);
		},

		onHelp: function() {
			//this.navTo("help");
			sap.m.URLHelper.redirect("ht" + "tps://jam4.sapjam.com/wiki/show/oamCPrXcp7bx34E8Cv5cPy", true);
		},

		onShare: function() {
			var subject = "MCC Activities App";
			var shareEmailText = "Dear colleague,\n\nPlease have a look at the MCC Activities App" +
				"\n\nTo access the MCC Activities App please use the link below." +
				"\n\nLink to UI5 App:\nht" +
				"tps://mccactivities-" + this.getAccount() + ".hana" + ".ondemand.com/" +
				"\n\nLink to app installation on iOS from SAP Mobile Place:\nht" +
				"tps://sap.sapmobileplace.com/?ID=996b6cdf34cc2d2399e36cb42c6f2274#ApplicationDetails" +
				"\n\nDirect Link to app on Fiori Launchpad:\nht" +
				"tps://fiorilaunchpad-sapitcloud.dispatcher.hana.ondemand.com/sites#mccactivities-Display" +
				"\n\n\n\n------------------------------------------------------------------------------------------------------------------\n" +
				"DISCLAIMER: This document is confidential and should only be used internally.\n" +
				"------------------------------------------------------------------------------------------------------------------" +
				"\n\nCreated by MCC Actvities App";
			sap.m.URLHelper.triggerEmail("", subject, shareEmailText);
		},

		onReportIssue: function() {
			var sLink =
				"ht" +
				"tps://fiorilaunchpad.sap.com/sap/hana/uis/clients/ushell-app/shells/fiori/FioriLaunchpad.html#Help-Inbox&/create/ZINE/IMAS_SVD_SUA/Issue%20in%20MCC%20Activities%20App%20(UI5)/02/null/ICP/---%20PLEASE%20ENTER%20TEXT%20HERE%20---";
			sap.m.URLHelper.redirect(sLink, true);
		},

		onGuideline: function() {
			var sLink = "ht" + "tps://mccguidline-d060917trial.dispatcher.hanatrial.ondemand.com/index.html";
			sap.m.URLHelper.redirect(sLink, true);
		}
	});
});
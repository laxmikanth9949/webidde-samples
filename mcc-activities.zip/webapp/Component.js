sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/HashChanger",
	"sap/support/mccactivities/model/DataManager",
	"sap/support/mccactivities/model/models",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"
], function(UIComponent, JSONModel, HashChanger, DataManager, models, Filter, MessageToast) {
	"use strict";

	return UIComponent.extend("sap.support.mccactivities.Component", {
		//oAuth: {auth: false},
		_bEditMode: false,
		_bSettingsEditMode: false,
		sFirstSlash: "",
		sFioriLaunchpad: "",
		sUser: "",
		sCurActivityId: "",
		fReadFirstAct: true,
		fCreateWithExistST: false,
		
		metadata: {
			manifest: "json",
			version: "1.0"
		},

		config: {
			reportingId: "MCC Activities"
		},

		init: function() {
			UIComponent.prototype.init.apply(this, arguments);

			this._checkEnvironment();
			this._requireReuseLib();
			this.oDataManager = new DataManager(this);
			
			//this.onSuccess();
		},
		
		onSuccess: function() {
			sap.git.usage.Reporting.setUser(this, this.sUser);
			this.getRouter().initialize();
		},
		
		// onFailed: function(error) {
		// 	if (this.oAuth.auth) {
		// 		MessageToast.show("Error while reading data!\nLog:" + error);
		// 		this.getRouter().initialize();
		// 	} else {
		// 		this._navigateToNotFound();
		// 	}
		// },
		
		_navigateToNotFound: function() {
			this.getRouter().getTargets().display(["emptyMaster", "notFound"]);
		},

		navTo: function(oRoute) {
			this.getRouter().navTo(oRoute);
		},

		//_environmentPrepare: function() {
			//this.getRootControl().setBusy(true);
			// Check if the environment is local web IDE or hcp and fiori client evironment
			//this._checkEnvironment();
			// Require reuse library
			//this._requireReuseLib();
			// Set global models
			//this._setGlobalModels();
			// Check Authorization
			//this._checkAuth();
		//},

		/*_dataPrepare: function() {

			this.getSettingList();
			this.getSettings();
			this.getNeedPushNotif();
			this.getDefaultCateg();

			// Set Control Model
			this._setCreateControlModel();
		},*/

		/*getSettingList: function() {
			this.getRegionList();
			this.getCategoryList();
			this.getStatusList();
			this.getRatingList();
			this.getPriorityList();
			this.getICCTemplate();
		},*/

		
		/*addBSelected: function(aData, sType) {
			for (var index = 0; index < aData.length; index++) {
				if (sType === "Status") {
					switch (aData[index].value1) {
						case "E0010":
						case "E0011":
						case "E0012":
							aData[index].bSelected = true;
							break;
						default:
							aData[index].bSelected = false;
					}
				} else {
					aData[index].bSelected = true;
				}
			}
			return aData;
		},*/

		getDataSource: function(service) {
			var sReturnValue;
			switch (service) {
				case "env_PG_AGS_DASHBOARDS":
					sReturnValue = this.sFirstSlash + this.sFioriLaunchpad + "sap/opu/odata/sap/ZS_AGS_DASHBOARDS_SRV/";
					break;
				case "env_PG_MDF":
					sReturnValue = this.sFirstSlash + this.sFioriLaunchpad + "sap/opu/odata/svx/MDF_SRV/";
					break;
				case "env_PG_ESCALATIONS":
					sReturnValue = this.sFirstSlash + this.sFioriLaunchpad + "sap/opu/odata/sap/ZS_ESCALATIONS/";
					break;
				default:
					sReturnValue = this.sFirstSlash + this.sFioriLaunchpad + "sap/opu/odata/sap/ZS_AGS_DASHBOARDS_SRV/";
			}
			return sReturnValue;
		},

		/*setNeedPushNotifModel: function() {
			var aVisibleLists = this.getModel("UserProfile").getProperty("/NEED_MCC_PUSHNOTIFICATION");
			switch (aVisibleLists) {
				case "":
					this._oUserProfilModel.create("/Entries", {
						"Attribute": "NEED_MCC_PUSHNOTIFICATION",
						"Value": "YES",
						success: function() {}
					});
					this.getModel("NeedPushNotif").setProperty("/result", true);
					break;
				case "YES":
					this.getModel("NeedPushNotif").setProperty("/result", true);
					break;
				case "NO":
					this.getModel("NeedPushNotif").setProperty("/result", false);
					break;
				default:
			}
		},*/

		/*setDefaultCategModel: function() {
			var oDefaultCateg = this.getModel("UserProfile").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CATEG");
			switch (oDefaultCateg) {
				case "":
					this._oUserProfilModel.create("/Entries", {
						"Attribute": "APP_MCC_ACTIVITIES_DEFAULT_CATEG",
						"Value": "Z88",
						success: function() {}
					});
					this.getModel("DefaultCategory").setProperty("/result", "Z88");
					break;
				default:
					this.getModel("DefaultCategory").setProperty("/result", oDefaultCateg);
			}
		},*/

		/*setVisibleCategModel: function() {
			var oModelBatch = this._oUserProfilBatchModel;
			var oVisibleCateg = this.getModel("UserProfile").getProperty("/APP_MCC_ACTIVITIES_VISIBLE_CATEG");
			var oCategList = this.getModel("SettingList").getProperty("/CategoryList");
			var oFlag;
			if (oVisibleCateg.length === 0) {
				var auxData = [];
				var sDeferredGroup = "category";
				for (var oIndex in oCategList) {
					auxData.push(oCategList[oIndex].value1);
				}
				oModelBatch.setDeferredGroups([sDeferredGroup]);
				for (var sList in auxData) {
					oModelBatch.create("/Entries", {
						Attribute: "APP_MCC_ACTIVITIES_VISIBLE_CATEG",
						Value: auxData[sList]
					}, {
						groupId: sDeferredGroup
					});
				}
				oModelBatch.submitChanges({
					groupId: sDeferredGroup,
					success: function(oData) {},
					error: function(oError) {}
				});
			} else {
				for (var iList in oCategList) {
					oFlag = false;
					for (var iVisible in oVisibleCateg) {
						if (oVisibleCateg[iVisible].Value === oCategList[iList].value1) {
							oCategList[iList].bSelected = true;
							oFlag = true;
							break;
						}
					}
					if (!oFlag) {
						oCategList[iList].bSelected = false;
					}
				}
				this.getModel("SettingList").setProperty("/CategoryList", oCategList);
			}
		},*/

		/*setVisibleStatusModel: function() {
			var oModelBatch = this._oUserProfilBatchModel;
			var oVisibleStatus = this.getModel("UserProfile").getProperty("/APP_MCC_ACTIVITIES_VISIBLE_STATU");
			var oStatusList = this.getModel("SettingList").getProperty("/StatusList");
			var oFlag;
			if (oVisibleStatus.length === 0) {
				var auxData = [];
				var sDeferredGroup = "status";
				for (var oIndex in oStatusList) {
					switch (oStatusList[oIndex].value1) {
						case "E0010":
						case "E0011":
						case "E0012":
							auxData.push(oStatusList[oIndex].value1);
							break;
						default:
					}
				}
				oModelBatch.setDeferredGroups([sDeferredGroup]);
				for (var sList in auxData) {
					oModelBatch.create("/Entries", {
						Attribute: "APP_MCC_ACTIVITIES_VISIBLE_STATU",
						Value: auxData[sList]
					}, {
						groupId: sDeferredGroup
					});
				}
				oModelBatch.submitChanges({
					groupId: sDeferredGroup,
					success: function() {},
					error: function() {}
				});
			} else {
				for (var iList in oStatusList) {
					oFlag = false;
					for (var iVisible in oVisibleStatus) {
						if (oVisibleStatus[iVisible].Value === oStatusList[iList].value1) {
							oStatusList[iList].bSelected = true;
							oFlag = true;
							break;
						}
					}
					if (!oFlag) {
						oStatusList[iList].bSelected = false;
					}
				}
				this.getModel("SettingList").setProperty("/StatusList", oStatusList);
			}
		},*/


		/*setMasterListVisible: function() {
			var oModelUPBatch = this._oUserProfilBatchModel;
			var sDeferredGroup = "list";
			var auxData = ["Assigned", "CreatedByMe", "Favorites"];
			oModelUPBatch.setDeferredGroups([sDeferredGroup]);
			for (var sList in auxData) {
				oModelUPBatch.create("/Entries", {
					"Attribute": "APP_MCC_ACTIVITIES_VISIBLE_LISTS",
					"Value": auxData[sList],
					success: function() {
						this.getEventBus().publish("sap.support.mccactivities", "RefreshMasterList", {
							id: auxData[sList]
						});
					}
				}, {
					groupId: sDeferredGroup
				});
			}
			oModelUPBatch.submitChanges({
				groupId: sDeferredGroup,
				success: function() {},
				error: function() {}
			});
		},*/

		/*getSplitapp: function() {
			if (this._oSplitapp) {
				return this._oSplitapp;
			} else {
				this._oSplitapp = this._oView.getAggregation("content")[0];
				return this._oSplitapp;
			}
		},*/

		getCurrentRoute: function() {
			return HashChanger.getInstance().getHash();
		},

		registerForPush: function() {
			//MessageToast.show("sap.Push: " + JSON.stringify(sap.Push));
			if (sap.Push) {
				//sap.m.MessageToast.show("try to register");
				var nTypes = sap.Push.notificationType.SOUNDS | sap.Push.notificationType.ALERT | sap.Push.notificationType.BADGE;
				sap.Push.registerForNotificationTypes(nTypes, this.regSuccess.bind(this), this.regFailure.bind(this),
					this.processNotificationFrontend.bind(this), ""); //GCM Sender ID, null for APNS
				//{}, ""); //GCM Sender ID, null for APNS
			}
		},

		regSuccess: function(result) {
			//sap.m.MessageToast.show("Successfully registered:" + JSON.stringify(result));
			//console.log("Successfully registered:" + JSON.stringify(result));
		},

		regFailure: function(errorInfo) {
			sap.m.MessageToast.show("Error while registering:" + JSON.stringify(errorInfo));
		},

		refreshNotification: function() {
			//sap.m.MessageToast.show("sap.Push: " + JSON.stringify(sap.Push));
			//this.getRouter().navTo("pushNotification");
		},

		processNotificationFrontend: function(notification) {
			sap.m.MessageBox.confirm("You received a new push notification. Do you want to check it in Notification Message center?", {
				onClose: function(oAction) {
					if (oAction === "OK") {
						this.getRouter().navTo("pushNotification");
					}
				}.bind(this)
			});
		},

		resetBadgeSuccess: function(result) {
			sap.m.MessageToast.show("Badge has been reset: " + JSON.stringify(result));
		},

		/*_setCreateControlModel: function() {
			var oCreateControlModel = new sap.ui.model.json.JSONModel({});
			oCreateControlModel.setDefaultBindingMode("OneWay");
			this.setModel(oCreateControlModel, "CreateControl");

			this.getModel("CreateControl").setProperty("/InvalidCaseIdDialogAccept", true);
			this.getModel("CreateControl").setProperty("/NoAccountDialogAccept", true);
			this.getModel("CreateControl").setProperty("/EFOSDialogAccept", true);
		},*/

		_checkEnvironment: function() {
			var url = document.location.toString();
			var arrUrl = url.split("//");
			var start = arrUrl[1].indexOf("/");
			var relUrl = arrUrl[1].substring(start);
			if (relUrl.indexOf("?") !== -1) {
				relUrl = relUrl.split("?")[0];
			}
			//if current path is '/webapp/', means application is running in local web IDE
			var bLocalWebIde = relUrl.indexOf("/webapp/") > -1;
			this.sFirstSlash = bLocalWebIde ? "/" : "";

			this.sFioriLaunchpad = !window["sap-fiori-ui5-bootstrap"] ? "" : "sap/fiori/mccactivities/";
		},

		_requireReuseLib: function() {
			/*try {
				jQuery.sap.registerModulePath("sap.git.usage", "ht" + "tps://" + "trackingshallwe.hana.ondemand.com/web-client/");
				jQuery.sap.require("sap.git.usage.MobileUsageReporting");
				sap.git.usage.MobileUsageReporting.startReporting(this);
			} catch (err) {
				jQuery.sap.log.error("Could not load/inject MobileUsageReporting");
			}*/
			this._mobileReporting();

			try {
				jQuery.sap.registerModulePath("sap.support.f4help", this.sFirstSlash + this.sFioriLaunchpad + "applications/techhelper/HelpScreens/");
				jQuery.sap.require("sap.support.f4help.CaseF4Help");
			} catch (oEvent) {
				sap.m.MessageToast.show(oEvent);
			}

			try {
				jQuery.sap.registerModulePath("sap.support.f4help", this.sFirstSlash + this.sFioriLaunchpad + "applications/techhelper/HelpScreens/");
				jQuery.sap.require("sap.support.f4help.CustomerF4Help");
			} catch (oEvent) {
				sap.m.MessageToast.show(oEvent);
			}
			
			// Add push notification event (Device push notification register)
			document.addEventListener("onSapLogonSuccess", this.registerForPush.bind(this), false);
			document.addEventListener("onSapResumeSuccess", this.refreshNotification.bind(this), false);
			//this.registerForPush();
		},

		/*_setGlobalModels: function() {
			// Set the device model
			this.setModel(models.createDeviceModel(), "device");
			// Filter Model
			var oFilterModel = new JSONModel({
				Status: "",
				Category: "",
				ServiceTeam: ""
			});
			this.setModel(oFilterModel, "Filter");
			// User Profile oData model
			this._oUserProfilModel = models.createNewODataModel(this.sFirstSlash + this.sFioriLaunchpad + "services/odata/svt/user_profile_srv", false);
			this._oUserProfilBatchModel = models.createNewODataModel(this.sFirstSlash + this.sFioriLaunchpad +
				"services/odata/svt/user_profile_srv", true);
			// AGS Dashboards oData model
			this._oDashBoardsModel = models.createNewODataModel(this.sFirstSlash + this.sFioriLaunchpad +
				"sap/opu/odata/sap/ZS_AGS_DASHBOARDS_SRV/", false);
			// Settings model
			this.setModel(models.createNewJSONModel("OneWay"), "SettingList");
			// User Profile model
			this.setModel(models.createNewJSONModel("OneWay"), "UserProfile");
			this.setModel(models.createNewJSONModel("OneWay"), "UserProfileV2");
		},*/

		_mobileReporting: function() {
			sap.git = sap.git || {};
			sap.git.usage = sap.git.usage || {};
			sap.git.usage.Reporting = {
				_lp: null,
				_load: function(a) {
					this._lp = this._lp || sap.ui.getCore().loadLibrary("sap.git.usage", {
						url: "ht" + "tps://trackingshallwe.hana.ondemand.com/web-client/v3",
						async: !0
					});
					this._lp.then(function() {
						a(sap.git.usage.MobileUsageReporting);
					}, this._loadFailed);
				},
				_loadFailed: function(a) {
					jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Loading failed: " + a);
				},
				setup: function(a) {
					this._load(function(b) {
						b.setup(a);
					});
				},
				addEvent: function(a, b) {
					this._load(function(c) {
						c.addEvent(a, b);
					});
				},
				setUser: function(a, b) {
					this._load(function(c) {
						c.setUser(a, b);
					});
				}
			};

			sap.git.usage.Reporting.setup(this);
		}
	});

});
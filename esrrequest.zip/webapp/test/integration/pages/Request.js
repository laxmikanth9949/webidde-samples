sap.ui.require([
		'sap/ui/test/Opa5',
		'sap/ui/test/matchers/AggregationLengthEquals',
		'sap/ui/test/matchers/PropertyStrictEquals',
		'sap/support/esrrequest/test/integration/pages/Common',
		'sap/ui/test/matchers/AggregationFilled'
	],
	function(Opa5, AggregationLengthEquals, PropertyStrictEquals, Common, Press, AggregationFilled) {
		"use strict";
		var sViewName = "Request",
			sTableId = "idRqtList";
		Opa5.createPageObjects({
			onTheRequestPage: {
				baseClass: Common,
				actions: {
					iPressOnMoreData: function() {
						return this.waitFor({
							id: sTableId,
							viewName: sViewName,
							actions: new Press(),
							errorMessage: "The Table does not have a trigger"
						});
					}
				},
				assertions: {
					thePageShouldHaveRequestListWithId: function(id) {
						return this.waitFor({
							viewName: sViewName,
							id: id,
							success: function() {
								Opa5.assert.ok(true, "The " + id + " is visible");
							},
							errorMessage: "The " + id + " is not found"
						});
					},
					theTableShouldHaveAllEntries: function() {
						return this.waitFor({
							id: sTableId,
							viewName: sViewName,
							matchers: new AggregationLengthEquals({
								name: "items",
								length: 9
							}),
							success: function() {
								Opa5.assert.ok(true, "The table has 23 items");
							},
							errorMessage: "Table does not have all entries."
						});
					},
					theTableShouldHaveContent: function() {
						return this.waitFor({
							viewName: sViewName,
							id: sTableId,
							matchers: new AggregationFilled({
								name: "items"
							}),
							success: function() {
								Opa5.assert.ok(true, "The table has at least one item");
							},
							errorMessage: "can't find the table"
						});
					},
					theTitleShouldDisplayTheTotalAmountOfItems: function() {
						return this.waitFor({
							id: "tableHeader",
							viewName: sViewName,
							matchers: function(oPage) {
								var sExpectedText = oPage.getModel("i18n").getResourceBundle().getText("worklistTableTitleCount", [23]);
								return new PropertyStrictEquals({
									name: "text",
									value: sExpectedText
								}).isMatching(oPage);
							},
							success: function() {
								Opa5.assert.ok(true, "The table header has 9 items");
							},
							errorMessage: "The Table's header does not container the number of items: 23"
						});
					}
				}
			}
		});
	});
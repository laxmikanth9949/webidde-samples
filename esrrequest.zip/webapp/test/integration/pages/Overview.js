sap.ui.require([
		'sap/ui/test/Opa5',
		'sap/ui/test/matchers/AggregationLengthEquals',
		'sap/ui/test/matchers/PropertyStrictEquals',
		'sap/ui/test/matchers/BindingPath',
		'sap/support/esrrequest/test/integration/pages/Common'
	],
	function(Opa5,
		AggregationLengthEquals,
		PropertyStrictEquals,
		BindingPath,
		Common) {
		"use strict";

		var sViewName = "Overview";

		Opa5.createPageObjects({
			onTheOverviewPage: {
				baseClass: Common,
				actions: {
					iClickTheCreateButtonWithId: function(id) {
						return this.waitFor({
							viewName: sViewName,
							id: id,
							success: function(button) {
								button.$().trigger("tap");
							},
							errorMessage: "No button found"
						});
					}
				},
				assertions: {
					thePageShouldHaveRefreshButtonWithId: function(id) {
						return this.thePageShouldHaveControlWithViewAndId(sViewName, id);
					},
					iShouldSeeTheActionSheetWithType: function(controlType) {
						return this.waitFor({
							viewName: sViewName,
							controlType: controlType,
							success: function() {
								Opa5.assert.ok(true, "The " + controlType + " is visible");
							},
							errorMessage: "The " + controlType + " is not visible"
						});
					}
				}
			}
		});
	});
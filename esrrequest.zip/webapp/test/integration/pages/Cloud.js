sap.ui.require([
		'sap/ui/test/Opa5',
		'sap/support/esrrequest/test/integration/pages/Common'
	],
	function(Opa5,
		Common) {
		"use strict";

		var sViewName = "CloudRequest";

		Opa5.createPageObjects({
			onTheCloudPage: {
				baseClass: Common,
				actions: {
					
				},
				assertions: {
					thePageShouldHaveContentWithId: function(id) {
						return this.thePageShouldHaveControlWithViewAndId(sViewName, id);
					},
					thePageShouldHaveButtonWithText: function(text){
						return this.thePageShouldHaveButtonWithViewAndText(sViewName,text);
					}
				}
			}
		});
	});
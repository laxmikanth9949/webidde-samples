sap.ui.define([
		'sap/ui/test/Opa5',
		'sap/ui/test/matchers/PropertyStrictEquals',
		'sap/ui/test/matchers/AggregationLengthEquals'
	],
	function(Opa5, PropertyStrictEquals, AggregationLengthEquals) {
		"use strict";

		function getFrameUrl(sHash, sUrlParameters, html) {
			sHash = sHash || "";
			var sUrl = jQuery.sap.getResourcePath("sap/support/esrrequest/" + html, ".html");

			if (sUrlParameters) {
				sUrlParameters = "?" + sUrlParameters;
			}

			return sUrl + sUrlParameters + "#" + sHash;
		}

		return Opa5.extend("sap.support.esrrequest.test.integration.pages.Common", {

			constructor: function(oConfig) {
				Opa5.apply(this, arguments);

				this._oConfig = oConfig;
			},

			iStartMyApp: function(oOptions) {
				var sUrlParameters;
				oOptions = oOptions || {
					delay: 0
				};
				sUrlParameters = "serverDelay=" + oOptions.delay;

				this.iStartMyAppInAFrame(getFrameUrl(oOptions.hash, sUrlParameters, oOptions.html ? oOptions.html : "app"));
			},

			iLookAtTheScreen: function() {
				return this;
			},
			
			theControlShouldBeVisibleWithViewAndType: function(sViewName, controlType) {
				return this.waitFor({
					viewName: sViewName,
					controlType: controlType,
					success: function() {
						Opa5.assert.ok(true, "The " + controlType + " is visible");
					},
					errorMessage: "The " + controlType + " is not visible"
				});
			},

			iClickTheButtonWithViewAndIcon: function(sViewName, icon) {
				return this.waitFor({
					viewName: sViewName,
					controlType: "sap.m.Button",
					matchers: new PropertyStrictEquals({
						name: "icon",
						value: icon
					}),
					success: function(buttons) {
						buttons[0].$().trigger("tap");
					},
					errorMessage: "The " + icon + " button isn't found"
				});
			},
			thePageShouldHaveControlWithViewAndId: function(sViewName, id) {
				return this.waitFor({
					viewName: sViewName,
					id: id,
					success: function() {
						Opa5.assert.ok(true, "The " + id + " is visible");
					},
					errorMessage: "The " + id + " is not found"
				});
			},
			thePageShouldHaveButtonWithViewAndText: function(sViewName, text){
				return this.waitFor({
					viewName: sViewName,
					controlType: "sap.m.Button",
					matchers: function(button) {
						return new PropertyStrictEquals({
							name: "text",
							value: button.getModel("i18n").getProperty(text)
						}).isMatching(button);
					},
					success: function() {
						Opa5.assert.ok(true, "The "+text+" button is found");
					},
					errorMessage: "The "+text+" button isn't found"
				});
			}
		});
	});
sap.ui.require(
	["sap/ui/test/opaQunit"],
	function(opaTest) {
		"use strict";

		QUnit.module("Cloud");

		opaTest("Should find Simple form", function(Given, When, Then) {
			// Arrangements
			Given.iStartMyApp({
				hash: "/esrrequest/cloud"
			});
			//Actions
			When.onTheCloudPage.iLookAtTheScreen();

			// Assertions
			Then.onTheCloudPage.thePageShouldHaveContentWithId("create_CLD");
				
		});
		opaTest("Should see the radio button of Customer", function(Given, When, Then) {
			//Actions
			When.onTheCloudPage.iLookAtTheScreen();

			// Assertions
			Then.onTheCloudPage.thePageShouldHaveContentWithId("cloudCustomers");
		});
		opaTest("Should see the Solution type of each Customer", function(Given, When, Then) {
			//Actions
			When.onTheCloudPage.iLookAtTheScreen();

			// Assertions
			Then.onTheCloudPage.thePageShouldHaveContentWithId("solution_select");
		});
		opaTest("Should see the time frame", function(Given, When, Then) {
			//Actions
			When.onTheCloudPage.iLookAtTheScreen();

			// Assertions
			Then.onTheCloudPage.thePageShouldHaveContentWithId("timeFrame");
		});
		opaTest("The page should have submit button on footer", function(Given, When, Then) {
			//Actions
			When.onTheCloudPage.iLookAtTheScreen();

			// Assertions
			Then.onTheCloudPage.thePageShouldHaveButtonWithText("Submit");
		});
		opaTest("The page should have Back to  OverView page button on footer", function(Given, When, Then) {
			//Actions
			When.onTheCloudPage.iLookAtTheScreen();

			// Assertions
			Then.onTheCloudPage.thePageShouldHaveContentWithId("cloudBackToOverview");
		});
	
	
	}
);
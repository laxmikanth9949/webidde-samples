jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;


sap.ui.require([
	"sap/ui/test/Opa5",
	"sap/support/esrrequest/test/integration/pages/Common",
	"sap/support/esrrequest/test/integration/pages/Overview",
	"sap/support/esrrequest/test/integration/pages/Cloud"/*,
	"sap/support/esrrequest/test/integration/pages/Request"*/
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "sap.support.esrrequest.view."
	});

	sap.ui.require([
		"sap/support/esrrequest/test/integration/OverviewJourney",
		"sap/support/esrrequest/test/integration/CloudJourney"/*,
		"sap/support/esrrequest/test/integration/RequestJourney"*/
	], function () {
		QUnit.start();
	});
});
sap.ui.require(
	["sap/ui/test/opaQunit"
	],function(opaTest) {
		"use strict";
		QUnit.module("Request");
		
	/*	opaTest("Should see the request list", function(Given, When, Then) {
			// Arrangements
			//Given.iStartMyAppInAFrame(jQuery.sap.getResourcePath("sap/support/esrrequest/test", ".html"));
			Given.iStartMyApp({hash:"/esrrequest"});
			//Actions
			When.onTheRequestPage.iLookAtTheScreen();
			// Assertions
			Then.onTheRequestPage.thePageShouldHaveControlWithId("idRqtList");
			
		});*/
		/*opaTest("Should be able to load more items", function(Given, When, Then) {
			//Actions
			When.onTheRequestPage.iPressOnMoreData();
			// Assertions

			Then.onTheRequestPage.theTableShouldHaveAllEntries().
			and.iTeardownMyAppFrame();
		});*/
	}
);
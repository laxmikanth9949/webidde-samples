sap.ui.require(
	["sap/ui/test/opaQunit"],
	function(opaTest) {
		"use strict";

		QUnit.module("Overview");

		opaTest("Should find refresh button", function(Given, When, Then) {
			// Arrangements
			Given.iStartMyApp({
				hash: "/esrrequest"
			});
			//Actions
			When.onTheOverviewPage.iLookAtTheScreen();

			// Assertions
			Then.onTheOverviewPage.thePageShouldHaveRefreshButtonWithId("pullToRefresh");
		
		});
		opaTest("Should see the create new request button(three contract)", function(Given, When, Then) {
			//Actions
			When.onTheOverviewPage.iLookAtTheScreen();

			// Assertions
			Then.onTheOverviewPage.thePageShouldHaveRefreshButtonWithId("threeContrate")
				.and.iTeardownMyAppFrame();
		});
		/*opaTest("Should see the action sheet of create request", function(Given, When, Then){
			//Action
			When.onTheOverviewPage.iClickTheCreateButtonWithId("threeContrate");
			
			//Assertions
			Then.onTheOverviewPage.iShouldSeeTheActionSheetWithType("sap.ui.xmlfragment");
		});*/
	
	}
);
sap.ui.require(
	[
		"sap/support/esrrequest/model/Formatter"
	],
	function (Formatter) {
		"use strict";
		QUnit.module("Formatting - status");
		function statusTestCase(oOptions){
			// Act
			var sState = Formatter.action(oOptions.status);
			// Assert
			oOptions.assert.strictEqual(sState, oOptions.expected, "The status was correct");
		}
		QUnit.test("Should format the report status to word", function (assert) {
			statusTestCase.call(this, {
				assert: assert,
				status: "1",
				expected: "Delete"
			});
		});
		QUnit.test("Should format the report status to word", function (assert) {
			statusTestCase.call(this, {
				assert: assert,
				status: "2",
				expected: ""
			});
		});
		QUnit.test("Should format the report status to word", function (assert) {
			statusTestCase.call(this, {
				assert: assert,
				status: "3",
				expected: "Open"
			});
		});
		
		QUnit.module("Formatting - enter");
		function endterTestCase(oOptions){
			// Act
			var sStr = Formatter.enter(oOptions.str);
			// Assert
			oOptions.assert.strictEqual(sStr, oOptions.expected, "The string was correct");
		}
		QUnit.test("Should format the string from '@@' to 'enter' ", function (assert) {
			endterTestCase.call(this, {
				assert: assert,
				str: "(0000202420)test cust. #3. OSS corp. funct.@@(0000202419)SAPNet R/3-Frontend Test customer # LSDE",
				expected: "(0000202420)test cust. #3. OSS corp. funct.\r\n(0000202419)SAPNet R/3-Frontend Test customer # LSDE"
			});
		});
		
		QUnit.module("Formatting - installation review");
		function instDisplayTestCase(oOptions){
			// Act
			var sStr = Formatter.separateInstToReview(oOptions.str);
			// Assert
			oOptions.assert.strictEqual(sStr, oOptions.expected, "The string was correct");
		}
		QUnit.test("Should display all selected installations when select 4 installations ", function (assert) {
			instDisplayTestCase.call(this, {
				assert: assert,
				str: "0020700116: NW;0020727367: ERP;0020727367: ERP ESupport;0020866684Unknown;",
				expected: "0020700116: NW\r\n0020727367: ERP\r\n0020727367: ERP ESupport\r\n0020866684Unknown\r\n"
			});
			
		});
		QUnit.test("Should display all selected installations when select 5 installations ", function (assert) {
			instDisplayTestCase.call(this, {
				assert: assert,
				str: "0020700116: NW;0020727367: ERP;0020727367: ERP ESupport;0020866684Unknown;0020866684Unknown;",
				expected: "0020700116: NW\r\n0020727367: ERP\r\n0020727367: ERP ESupport\r\n0020866684Unknown\r\n0020866684Unknown\r\n"
			});
			
		});
		/*QUnit.test("Should display 5 selected installations when select 6 installations ", function (assert) {
			instDisplayTestCase.call(this, {
				assert: assert,
				str: "0020700116: NW;0020727367: ERP;0020727367: ERP ESupport;0020866684Unknown;0020866684Unknown;0020727367: ERP;",
				expected: "0020700116: NW\r\n0020727367: ERP\r\n0020727367: ERP ESupport\r\n0020866684Unknown\r\n0020866684Unknown\r\n"
			});
			
		});*/
		
		QUnit.test("Should see 'Selected Installation' item in review page when choose selecte installation step ", function (assert) {
			assert.equal(Formatter.passIntoBool("Select installations"), true);
			
		});
		
		QUnit.test("Should not see 'Selected Installation' item in review page when do not choose selecte installation step ", function (assert) {
			assert.equal(Formatter.passIntoBool("Select chapters"), false);
		});
		
		QUnit.module("Formatting - installation in overview");
		
		function textMoreTestCase(oOptions){
			// Act
			var sStr = Formatter.getTextVisible(oOptions.str);
			// Assert
			oOptions.assert.strictEqual(sStr, oOptions.expected, "The visible was correct");
		}
		
		QUnit.test("Should not see 'More...' link when installation is empty ", function (assert) {
			textMoreTestCase.call(this, {
				assert: assert,
				str: "",
				expected: false
			});
		});
		
		QUnit.test("Should not see 'More...' link when select 2 installations ", function (assert) {
			textMoreTestCase.call(this, {
				assert: assert,
				str: "0020700116: NW;0020727367: ERP;",
				expected: false
			});
		});
		
		QUnit.test("Should see 'More...' link when select 5 installations ", function (assert) {
			textMoreTestCase.call(this, {
				assert: assert,
				str: "0020700116: NW;0020727367: ERP;0020727367: ERP ESupport;0020866684Unknown;0020866684Unknown",
				expected: true
			});
		});
		
		function instOverviewTestCase(oOptions){
			// Act
			var sStr = Formatter.separateInstToOverview(oOptions.str);
			// Assert
			oOptions.assert.strictEqual(sStr, oOptions.expected, "The string was correct");
		}
		
		QUnit.test("Should only see two selected installations in a row when number of installations more than 2 ", function (assert) {
			instOverviewTestCase.call(this, {
				assert: assert,
				str: "0020700116;0020727367;0020727367;",
				expected: "0020700116\r\n0020727367"
			});
		});
		
		QUnit.test("Should disable all buttons when under substitute mode", function (assert) {
			var sAct = Formatter.determButtonStatus.call(this.oController, "X");
			assert.equal(sAct, false);
		});
		
		QUnit.test("Should enabled all buttons when under regular mode", function (assert) {
			var sAct = Formatter.determButtonStatus.call(this.oController, "");
			assert.equal(sAct, undefined);
		});
		
	}
);
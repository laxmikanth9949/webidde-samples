sap.ui.define([
	"sap/support/esrrequest/controller/App.controller",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/base/ManagedObject",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(App, ODataModel, MessageBox, ResourceModel, ManagedObject) {
	"use strict";

	QUnit.module("App - request again", {
		beforeEach: function() {
			this.oApp = new App();
			this.oModelI18n = new ResourceModel({
				bundleName: "sap.support.esrrequest.i18n.message_bundle",
				bundleLocale: "EN"
			});
			this.oComponent = new ManagedObject();
			this.oComponent.setModel(this.oModelI18n, "i18n");
			sinon.stub(this.oApp, "getOwnerComponent").returns(this.oComponent);
		},
		afterEach: function() {
			this.oApp.destroy();
			this.oApp.getOwnerComponent.restore();
			this.oModelI18n.destroy();
			this.oComponent.destroy();
		}
	});
	
	QUnit.test("Should show warning msg when select a 'CLOUD' report ", function(assert) {
		//Arrangement
		this.stub(this.oApp, "checkSelectedReportType").returns(false);
		var oStubMsg = this.stub(sap.m.MessageBox, "warning");
		//Action
		this.oApp.onRequestAgain();
		assert.strictEqual(oStubMsg.callCount, 1);
	});
	
	QUnit.test("Should show warning msg when select none request and click 'Request Again' button", function(assert) {
		//Arrangement
		this.stub(this.oApp, "checkSelectedReportType").returns(true);
		this.stub(this.oApp, "getSelectedRequests").returns([]);
		this.stub(ODataModel.prototype, "create");
		var oStubMsg = this.stub(sap.m.MessageBox, "warning");
		//Action
		this.oApp.onRequestAgain();
		assert.strictEqual(oStubMsg.callCount, 1);
	});
	
	QUnit.test("Should create a requests when select one request and click 'Request Again' button", function(assert) {
		//Arrangement
		this.stub(this.oApp, "checkSelectedReportType").returns(true);
		this.stub(this.oApp, "getSelectedRequests").returns(["'S000031511920161101071420'"]);
		this.stub(ODataModel.prototype, "create");
		//Action
		this.oApp.onRequestAgain();
		assert.deepEqual(ODataModel.prototype.create.getCall(0).args[1], {
			Request_Again: "S000031511920161101071420;"
		});
	});

	QUnit.test("Should create two requests when select two request and click 'Request Again' button", function(assert) {
		//Arrangement
		this.stub(this.oApp, "checkSelectedReportType").returns(true);
		this.stub(this.oApp, "getSelectedRequests").returns(["'S000031511920161101071420'", "'S000031511920161207070803'"]);
		this.stub(ODataModel.prototype, "create");
		//Action
		this.oApp.onRequestAgain();
		assert.deepEqual(ODataModel.prototype.create.getCall(0).args[1], {
			Request_Again: "S000031511920161101071420;S000031511920161207070803;"
		});
	});

	QUnit.test("Should refresh overview request list after create success", function(assert) {
		//Arrangement
		this.stub(this.oApp, "checkSelectedReportType").returns(true);
		this.stub(this.oApp, "getSelectedRequests").returns(["S000031511920161101071420"]);
		this.stub(ODataModel.prototype, "create").yieldsTo("success");
		var oStubRefresh = this.stub(this.oApp, "autoRefresh");
		this.stub(sap.m.MessageToast, "show");
		//Action
		this.oApp.onRequestAgain();
		assert.deepEqual(oStubRefresh.callCount, 1);
	});
	
	QUnit.test("Should display success message when create success", function(assert) {
		//Arrangement
		this.stub(this.oApp, "checkSelectedReportType").returns(true);
		this.stub(this.oApp, "getSelectedRequests").returns(["S000031511920161101071420"]);
		this.stub(ODataModel.prototype, "create").yieldsTo("success");
		this.stub(this.oApp, "autoRefresh");
		var oStubMsg = this.stub(sap.m.MessageToast, "show");
		//Action
		this.oApp.onRequestAgain();
		assert.deepEqual(oStubMsg.callCount, 1);
	});

	QUnit.test("Should refresh overview request list after create error", function(assert) {
		//Arrangement
		this.stub(this.oApp, "checkSelectedReportType").returns(true);
		this.stub(this.oApp, "getSelectedRequests").returns(["S000031511920161101071420"]);
		this.stub(ODataModel.prototype, "create").yieldsTo("error");
		var oStubRefresh = this.stub(this.oApp, "autoRefresh");
		//Action
		this.oApp.onRequestAgain();
		assert.strictEqual(oStubRefresh.callCount, 1);
	});

	QUnit.test("Should display an warning message when selected requests more than 10 ", function(assert) {
		//Arrangement
		this.stub(this.oApp, "checkSelectedReportType").returns(true);
		this.stub(this.oApp, "getSelectedRequests").returns(
			["S000031511920161101071420", "S000031511920161101071420", "S000031511920161101071420",
				"S000031511920161101071420", "S000031511920161101071420", "S000031511920161101071420",
				"S000031511920161101071420", "S000031511920161101071420", "S000031511920161101071420",
				"S000031511920161101071420", "S000031511920161101071420"
			]);
		var oStubMsg = this.stub(sap.m.MessageBox, "warning");
		this.stub(ODataModel.prototype, "create");
		//Action
		this.oApp.onRequestAgain();
		assert.strictEqual(oStubMsg.callCount, 1);
	});
	
	

});
sap.ui.define([
	"sap/support/esrrequest/controller/Detail.controller",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/core/Component",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/StandardTreeItem",
	"sap/ui/model/Context",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Detail, ResourceModel, Component, Controller, JSONModel, StandardTreeItem, Context) {
	"use strict";

	QUnit.module("Optional step", {
		beforeEach: function() {
			this.oDetail = new Detail();
			this.oModel = new JSONModel();
		},
		afterEach: function() {
		}
	});
	
	QUnit.test("Should see relevant alerts in Detail view when select items with alerts in Master view", function(assert) {
		//Arrangement
		this.model = new JSONModel({selectedStep: "Select installations"});
		//Action
		this.oDetail.goToNextStep();
		assert.strictEqual(this.oMaster.getOwnerComponent().getModel("alert").getData(), "Test");
	});
	
	/*QUnit.test("Should see no alerts in Detail view when select items without alerts in Master view", function(assert) {
		goToNextStep.call(this, {});
		
		assert.deepEqual(this.oMaster.getOwnerComponent().getModel("alert").getData(), {});
	});*/
});
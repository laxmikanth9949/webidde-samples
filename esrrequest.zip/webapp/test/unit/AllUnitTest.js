sap.ui.define([
	"sap/support/esrrequest/test/unit/model/formatter",
	//"sap/support/esrrequest/test/unit/page/Detail.controller",
	"sap/support/esrrequest/test/unit/page/App.controller"
], function() {
	"use strict";
});
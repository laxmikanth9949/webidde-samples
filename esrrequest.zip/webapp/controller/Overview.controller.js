sap.ui.define([
	"sap/ui/core/mvc/Controller"
], 
function (Controller, model) {
	"use strict";
	return Controller.extend("sap.support.esrrequest.controller.App", {
		
	});
});
sap.ui.define([
	'jquery.sap.global',
	'sap/support/esrrequest/controller/BaseController',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"sap/support/esrrequest/model/Formatter",
	"sap/ui/core/Fragment",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/Sorter"
], function (jQuery, Controller, Filter, FilterOperator, JSONModel, Dialog, Formatter, Fragment, ODataModel, Sorter) {
	"use strict";
	var _downtimeCheckfirst = "true";
	return Controller.extend("sap.support.esrrequest.controller.Request", {
		formatter: Formatter,

		onInit: function () {
			this._init();
			this.getView().byId("formattedText1").addEventDelegate({
				onAfterRendering: $.proxy(function () {
					var children = $("#" + this.getView().byId("formattedText1").getId()).children();
					$(children[2]).attr('class', 'formattedTextstyle');
					$(children[4]).attr('class', 'formattedTextstyle');
				}, this)
			});
			/*var oModel = new JSONModel({
				HTML2: "<h3><strong>IMPORTANT “PDF-Cloud Version will soon END”</strong></h3>" +
					"<p>Please note the interactive " +
					"<a href=\"//launchpad.support.sap.com/#/customerinsight360\" style=\"color:blue; font-weight:600;\">" +
					"SAP Enterprise Support reporting cockpit </a>" +
					"has been released for our customers. All necessary information about the reporting cockpit (content, access rights, etc.) " +
					"can be found the SAP Enterprise Support reporting cockpit " +
					"<a href=\"//support.sap.com/esrc\" style=\"color:blue; font-weight:600;\">portal page</a>. " +
					"Additional information about the reporting cockpit can be found in " +
					"<a href=\"//blogs.sap.com/tag/esrc/\" style=\"color:blue; font-weight:600;\">customer BLOG</a>.</p>" +
					"<p>After a transition period, the pdf based cloud report will no longer be available. " +
					"<strong>The transition period is planned till 30.11.2020.</strong>" +
					" Please use this time to make yourself familiar with the ES reporting cockpit.</p>" +
					"<p>The PDF based on-premise report is currently not affected.</p>"
			});*/
			var oModel = new JSONModel({
				HTML2: "<p>The <a href=\"//launchpad.support.sap.com/#/esrrequest\" style=\"color:blue; font-weight:400;\">" +
					"Support Report Document application</a> supports PDF report generation for <strong>on-premise content</strong>.</p>" +
					"<p>To access <strong>cloud content</strong>, please use the " +
					"<a href=\"//launchpad.support.sap.com/#/customerinsight360\" style=\"color:blue; font-weight:400;\">" +
					"SAP Enterprise Support reporting cockpit</a>." +
					" - a new interactive reporting tool, which replaces the PDF-based SAP Enterprise Support report cloud edition.</p>" +
					"<p>For more details visit <a href=\"//support.sap.com/esrc\" style=\"color:blue; font-weight:400;\">support.sap.com/esrc</a>" +
					" and read <a href=\"//blogs.sap.com/tag/esrc/\" style=\"color:blue; font-weight:600;\">our blog</a>.</p>"
			});

			this.getView().setModel(oModel);
		},

		_init: function () {
			this.overViewTable();
			var filters = [];
			var oFilter1 = new Filter("ReportType", FilterOperator.EQ, this.getReportType());
			//filters.push(oFilter1);
			filters.push(oFilter1);
			this.refreshModel("overview", filters);
		},

		// onAfterRendering: function() {
		// 	if (_downtimeCheckfirst === "true") {
		// 		var reportType = this.getReportType();
		// 		if (reportType !== "CLD") {
		// 			this.checkDownTime();
		// 		}
		// 	}
		// },

		refreshModel: function (name, filters) {
			var oModel = this.getOwnerComponent().getModel(name);
			var oTabBar = this.getView().getContent()[1];
			var oTable = oTabBar.getContent()[0];
			oTable.setModel(oModel, name);
			oTable.getBinding("items").filter(filters);
			oTable.setGrowing("true");
		},
		checkDownTime: function () {
			var i18nModel = this.geti18nModel();
			var Warning = i18nModel.getResourceBundle().getText("warning");
			//check down time 
			var reportType = this.getReportType();
			var oModeluserdata;
			if (reportType === "ES") {
				oModeluserdata = this.getUserdata_es();
			} else if (reportType === "PSLE") {
				oModeluserdata = this.getUserdata_psle();
			} else if (reportType === "ES_PSLE") {
				oModeluserdata = this.getUserdata_es();
			} else if (reportType === "ALL") {
				oModeluserdata = this.getUserdata_cld();
			}
			// before 7 days 
			var downPopText = oModeluserdata.getData().d.DownPopText;
			if (downPopText.length !== 0) {

				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.warning(
					downPopText, {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: Warning,
						actions: [sap.m.MessageBox.Action.YES]
					});
			}
			// During down time
			var downBottomText = oModeluserdata.getData().d.DownBottomText;

			if (downBottomText.length !== 0) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.warning(
					downBottomText, {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: Warning,
						actions: [sap.m.MessageBox.Action.YES]
					});
			}
			_downtimeCheckfirst = "false";
			return _downtimeCheckfirst;
		},

		getUserdata_es: function () {
			var es_userData = this.getOwnerComponent().getModel("Model_userdata_es");
			return es_userData;
		},

		getUserdata_psle: function () {
			var psle_userData = this.getOwnerComponent().getModel("Model_userdata_psle");
			return psle_userData;

		},
		getUserdata_cld: function () {
			var cld_userData = this.getOwnerComponent().getModel("Model_userdata_cld");
			return cld_userData;
		},
		/*getAuthorizedApp: function() {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.authorizedApp;
		},*/
		overViewTable: function (oController) {
			var that = this;
			this.getView().byId("idIconTabBar").destroyContent();
			var oTable = new sap.m.Table("idRqtList", {
				inset: true,
				mode: sap.m.ListMode.MultiSelect,
				includeItemInSelection: false
			});

			var oHeaderToolbar = new sap.m.Toolbar("requestToolbar", {
				title: "{i18n>error}"
			});
			var headerText = new sap.m.Label("tableName", {
				text: "{i18n>requestListTitle}",
				design: "Bold"
			});
			var toolspacer = new sap.m.ToolbarSpacer();
			var viewsetButton = new sap.m.Button("viewSetting", {
				icon: "sap-icon://drop-down-list",
				press: $.proxy(function () {
					this.handleViewSettingsDialogButtonPressed();
				}, this)
			});
			oHeaderToolbar.addContent(headerText);
			oHeaderToolbar.addContent(toolspacer);
			oHeaderToolbar.addContent(viewsetButton);

			oTable.setHeaderToolbar(oHeaderToolbar);

			var col1 = new sap.m.Column("col1", {
				header: new sap.m.Label({
					text: "{i18n>columnReportType}"
				}),
				width: "25%"
			});
			oTable.addColumn(col1);

			var col2 = new sap.m.Column("col2", {
				header: new sap.m.Label({
					text: "{i18n>columnAction}"
				}),
				width: "8%",
				minScreenWidth: "Large",
				demandPopin: true
			});
			oTable.addColumn(col2);

			var col3 = new sap.m.Column("col3", {
				header: new sap.m.Label({
					text: "{i18n>columnRequestedOn}"
				}),
				width: "20%",
				minScreenWidth: "Medium",
				demandPopin: true
			});
			oTable.addColumn(col3);

			var col4 = new sap.m.Column("col4", {
				header: new sap.m.Label({
					text: "{i18n>columnRequestedFor}"
				}),
				width: "30%",
				minScreenWidth: "Medium",
				demandPopin: true
			});
			oTable.addColumn(col4);

			var colInst = new sap.m.Column("inst", {
				header: new sap.m.Label({
					text: "{i18n>columnInstallation}"
				}),
				width: "20%",
				minScreenWidth: "Medium",
				demandPopin: true
			});
			oTable.addColumn(colInst);

			var col5 = new sap.m.Column("col5", {
				header: new sap.m.Label({
					text: "{i18n>columnLanguage}"
				}),
				width: "12%",
				minScreenWidth: "Tablet",
				demandPopin: true
			});
			oTable.addColumn(col5);

			var col6 = new sap.m.Column("col6", {
				header: new sap.m.Label({
					text: "{i18n>columnCurrentStatus}"
				}),
				width: "13%",
				minScreenWidth: "Tablet",
				demandPopin: true
			});
			oTable.addColumn(col6);

			var colItems = new sap.m.ColumnListItem("colItems", {
				type: "Inactive"
			});
			oTable.bindAggregation("items", "overview>/ESR_REQUESTSet", colItems);

			var list1 = new sap.m.Text("list1", {
				text: "{overview>ReportName}"
			});
			var list1Des = new sap.m.Label("list1Desc", {
				text: {
					path: "overview>Description"
				},
				design: "Bold"
			});

			var oVBox1 = new sap.m.VBox();
			oVBox1.addItem(list1);
			oVBox1.addItem(list1Des);
			colItems.addCell(oVBox1);

			var list2 = new sap.m.Link("list2", {
				text: {
					parts: [{
						path: "overview>Status"
					}, {
						path: "overview>ReportId"
					}],
					formatter: that.formatter.action
				},
				href: "",
				press: function (oEvent) {
					that.onShowMsg(oEvent);
				}

			});
			colItems.addCell(list2);

			var list3 = new sap.m.Text("list3", {
				text: "{overview>CreatedAt}"
			});
			colItems.addCell(list3);

			var list4 = new sap.m.Text("list4", {
				text: {
					path: "overview>CustomerName",
					formatter: that.formatter.enter
				}
			});
			colItems.addCell(list4);

			var listInst = new sap.m.Text("listInst", {
				text: {
					path: "overview>Installation_No",
					formatter: that.formatter.separateInstToOverview
				}
			});
			var listInstMore = new sap.m.Link("listMore", {
				text: {
					path: "i18n>more"
				},
				visible: {
					path: "overview>Installation_No",
					formatter: that.formatter.getTextVisible
				},
				tooltip: "Click to see more",
				press: function (oEvent) {
					that.getPopover(oEvent);
				}
			});
			var oVBox = new sap.m.VBox();
			oVBox.addItem(listInst);
			oVBox.addItem(listInstMore);
			/*var listInstTemplat = new sap.ui.core.tmpl.Template();
			listInstTemplat.setContent(listInst);
			listInstTemplat.setContent(listInstMore);*/

			colItems.addCell(oVBox);

			var list5 = new sap.m.Text("list5", {
				text: "{overview>LanguageName}"
			});
			colItems.addCell(list5);

			var list6 = new sap.m.Text("list6", {
				text: "{overview>StatusName}"
			});
			colItems.addCell(list6);

			this.getView().byId("idIconTabBar").insertContent(oTable);

			var countModel = this.getCountModel();

			this.getView().byId("idIconTabBar").setModel(countModel, "count");
		},

		getSelectedRequestId: function (oEvent) {
			var oSource = oEvent.getSource();
			var requestsPath = oSource.getParent().getBindingContext("overview").sPath;
			var requestId = requestsPath.substring(requestsPath.indexOf("'"), requestsPath.indexOf(")"));
			return requestId;
		},

		getPopover: function (oEvent) {
			var requestId = this.getSelectedRequestId(oEvent);
			var instModel = this.getModel("instModel");

			instModel.loadData("/services/odata/svt/esr_srv/ESR_REQUESTSet" + "(RequestId=" + requestId + ")/Request_InstallationSet", {},
				false, "GET");
			/*instModel.read("/ESR_REQUESTSet" + "(RequestId=" + requestId + ")/Request_InstallationSet", {
				success: function() {
					instModel.refresh();
				},
				error: function() {
					instModel.refresh();
				}
			});*/
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("sap.support.esrrequest.view.Popover", this);
				this.getView().addDependent(this._oPopover);
				this._oPopover.setModel(instModel, "installation");
				//this._oPopover.bindElement("instModel");
			}

			this._oPopover.openBy(oEvent.getSource());
		},

		handleViewSettingsDialogButtonPressed: function (oEvent) {
			var i18nModel = this.geti18nModel();
			var report_Type = this.getReportType();
			if (report_Type === "PSLE") {
				if (!this._oDialog_PSLE) {
					this._oDialog_PSLE = sap.ui.xmlfragment("sap.support.esrrequest.view.ViewSettingPSLE", this);
					this._oDialog_PSLE.setModel(i18nModel, "i18n");
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog_PSLE);
				}
				/*var jug_psle = this._oDialog_PSLE.getFilterItems()[0].getItems();
				if(!jug_psle.length){
						// filter language
						var psloModel = this.getOwnerComponent().getModel("oModel_psl");
						var contentOfLanguageSet_psl = psloModel.oData.d.LanguageSet.results;
						var amountOfLuag_psl = contentOfLanguageSet_psl.length;
						for(var i=0;i<amountOfLuag_psl;i++){
							var psle_ViewSettingsItem_language = new sap.m.ViewSettingsFilterItem({
								text: contentOfLanguageSet_psl[i].Langu_name,
								key: contentOfLanguageSet_psl[i].Langu_name
							});
							this._oDialog_PSLE.getFilterItems()[0].addItem(psle_ViewSettingsItem_language);
					}
				}*/
				this._oDialog_PSLE.open();
			} else if (report_Type === "ES") {
				if (!this._oDialog_ES) {
					this._oDialog_ES = sap.ui.xmlfragment("sap.support.esrrequest.view.ViewSettingES", this);
					this._oDialog_ES.setModel(i18nModel, "i18n");
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog_ES);
				}
				var jug_es = this._oDialog_ES.getFilterItems()[0].getItems();
				if (!jug_es.length) {
					var reportType_ES1 = i18nModel.getResourceBundle().getText("reportType_ES1");
					var reportType_ESB = i18nModel.getResourceBundle().getText("reportType_ESB");
					var es1_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("es1_item", {
						text: reportType_ES1,
						key: "ES1"
					});
					var esb_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("esb_item", {
						text: reportType_ESB,
						key: "ESB"
					});
					this._oDialog_ES.getFilterItems()[0].addItem(es1_ViewSettingsItem);
					this._oDialog_ES.getFilterItems()[0].addItem(esb_ViewSettingsItem);

					var es1oModel = this.getOwnerComponent().getModel("oModel_es1");
					// filter language
					var contentOfLanguageSet_es1 = es1oModel.oData.d.LanguageSet.results;
					var amountOfLuag_es1 = contentOfLanguageSet_es1.length;
					for (var j = 0; j < amountOfLuag_es1; j++) {
						var es_ViewSettingsItem_language = new sap.m.ViewSettingsFilterItem({
							text: contentOfLanguageSet_es1[j].Langu_name,
							key: contentOfLanguageSet_es1[j].Langu_name
						});
						this._oDialog_ES.getFilterItems()[1].addItem(es_ViewSettingsItem_language);
					}
				}
				this._oDialog_ES.open();
			} else if (report_Type === "ES_PSLE") {
				if (!this._oDialog_ES_PSLE) {
					this._oDialog_ES_PSLE = sap.ui.xmlfragment("sap.support.esrrequest.view.ViewSettingES_PSLE", this);
					this._oDialog_ES_PSLE.setModel(i18nModel, "i18n");
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog_ES_PSLE);
				}
				var jug_es = this._oDialog_ES_PSLE.getFilterItems()[0].getItems();
				if (!jug_es.length) {
					var reportType_ES1 = i18nModel.getResourceBundle().getText("reportType_ES1");
					var reportType_ESB = i18nModel.getResourceBundle().getText("reportType_ESB");
					var reportType_PSL = i18nModel.getResourceBundle().getText("reportType_PSL");

					var es1_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("es1_item", {
						text: reportType_ES1,
						key: "ES1"
					});
					var esb_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("esb_item", {
						text: reportType_ESB,
						key: "ESB"
					});
					var psl_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("psl_item", {
						text: reportType_PSL,
						key: "PSL"
					});

					this._oDialog_ES_PSLE.getFilterItems()[0].addItem(es1_ViewSettingsItem);
					this._oDialog_ES_PSLE.getFilterItems()[0].addItem(esb_ViewSettingsItem);
					this._oDialog_ES_PSLE.getFilterItems()[0].addItem(psl_ViewSettingsItem);
				}
				this._oDialog_ES_PSLE.open();
			}
			/* else if (report_Type === "CLD") {
				if (!this._oDialog_CLD) {
					this._oDialog_CLD = sap.ui.xmlfragment("sap.support.esrrequest.view.ViewSettingCLD", this);
					this._oDialog_CLD.setModel(i18nModel, "i18n");
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog_CLD);

				}
				this._oDialog_CLD.open();
			}  else if (report_Type === "ALL") {
				var AuthoriedType = this.getAuthorizedType();
				if (!this._oDialog_ALL) {
					this._oDialog_ALL = sap.ui.xmlfragment("sap.support.esrrequest.view.ViewSettingALL", this);
					this._oDialog_ALL.setModel(i18nModel, "i18n");
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog_ALL);
				}
				var jug_es = this._oDialog_ALL.getFilterItems()[0].getItems();
				if (!jug_es.length) {
					if (AuthoriedType === "Both") {
						var reportType_ES1 = i18nModel.getResourceBundle().getText("reportType_ES1");
						var reportType_ESB = i18nModel.getResourceBundle().getText("reportType_ESB");
						var reportType_PSL = i18nModel.getResourceBundle().getText("reportType_PSL");
						var reportType_CLD = i18nModel.getResourceBundle().getText("reportType_CLD");

						var es1_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("es1_item", {
							text: reportType_ES1,
							key: "ES1"
						});
						var esb_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("esb_item", {
							text: reportType_ESB,
							key: "ESB"
						});
						var psl_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("psl_item", {
							text: reportType_PSL,
							key: "PSL"
						});
						var cld_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("cld_item", {
							text: reportType_CLD,
							key: "CLD"
						});

						this._oDialog_ALL.getFilterItems()[0].addItem(es1_ViewSettingsItem);
						this._oDialog_ALL.getFilterItems()[0].addItem(esb_ViewSettingsItem);
						this._oDialog_ALL.getFilterItems()[0].addItem(psl_ViewSettingsItem);
						this._oDialog_ALL.getFilterItems()[0].addItem(cld_ViewSettingsItem);
					} else if (AuthoriedType === "ES") {
						var reportType_ES1 = i18nModel.getResourceBundle().getText("reportType_ES1");
						var reportType_ESB = i18nModel.getResourceBundle().getText("reportType_ESB");
						var reportType_CLD = i18nModel.getResourceBundle().getText("reportType_CLD");

						var es1_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("es1_item", {
							text: reportType_ES1,
							key: "ES1"
						});
						var esb_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("esb_item", {
							text: reportType_ESB,
							key: "ESB"
						});
						 var cld_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("cld_item", {
							text: reportType_CLD,
							key: "CLD"
						}); 

						this._oDialog_ALL.getFilterItems()[0].addItem(es1_ViewSettingsItem);
						this._oDialog_ALL.getFilterItems()[0].addItem(esb_ViewSettingsItem);
						this._oDialog_ALL.getFilterItems()[0].addItem(cld_ViewSettingsItem);
					} else if (AuthoriedType === "PSLE") {
						 var reportType_PSL = i18nModel.getResourceBundle().getText("reportType_PSL");
						 var reportType_CLD = i18nModel.getResourceBundle().getText("reportType_CLD");
						var psl_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("psl_item", {
							text: reportType_PSL,
							key: "PSL"
						});
						  var cld_ViewSettingsItem = new sap.m.ViewSettingsFilterItem("cld_item", {
							text: reportType_CLD,
							key: "CLD"
						}); 
						this._oDialog_ALL.getFilterItems()[0].addItem(psl_ViewSettingsItem);
						this._oDialog_ALL.getFilterItems()[0].addItem(cld_ViewSettingsItem);
					}
				}
				this._oDialog_ALL.open();
			} */

		},
		handleConfirm: function (oEvent) {
			var oView = this.getView();
			var oTabbar = oView.byId("idIconTabBar");
			var oTable = oTabbar.getContent()[0];
			var mParams = oEvent.getParameters();
			var oBinding = oTable.getBinding("items");
			// set to client
			oBinding.attachDataReceived(function (oEvent) { //Hits when the data is received from back-end server   
				var oSource = oEvent.getSource();
				oSource.bClientOperation = true; //Set Client Operation to true   
				oSource.sOperationMode = "Client"; //Set operation mode to Client   
			});
			var aFilters = [];
			var oFilter = new Filter("ReportType", FilterOperator.EQ, this.getReportType());
			aFilters.push(oFilter);

			//sort
			var aSorters = [];
			var sPath = mParams.sortItem.getKey();
			var bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			oBinding.sort(aSorters);

			// apply filters to binding
			jQuery.each(mParams.filterItems, function (i, oItem) {
				var sPath1 = oItem.getParent().getKey();
				var sValue = oItem.getKey();
				var oFilter1 = new Filter(sPath1, FilterOperator.EQ, sValue);
				aFilters.push(oFilter1);
			});
			oBinding.filter(aFilters);
			oBinding.refresh();

		},

		handleIconTabBarSelect: function (oEvent) {
			var oBinding = oEvent.getSource().getContent()[0].getBinding("items"),
				sKey = oEvent.getParameter("key");
			var filters = new Array();
			var oFilter2 = new Filter("ReportType", FilterOperator.EQ, this.getReportType());
			var oFilter;
			filters.push(oFilter2);
			if (sKey === "New") {
				oFilter = new Filter("Status", "EQ", "1");
			} else if (sKey === "Process") {
				oFilter = new Filter("Status", "EQ", "2");
			} else if (sKey === "Complete") {
				oFilter = new Filter("Status", "EQ", "3");
			}

			if (oFilter) {
				filters.push(oFilter);
			}
			oBinding.filter(filters);
			oBinding.refresh();
		},

		deleteReportItem: function (RequestId) {
			var that = this;
			var url = "/services/odata/svt/esr_srv";
			var m = new sap.ui.model.odata.v2.ODataModel(url);
			m.setUseBatch(false);
			m.remove("/ESR_REQUESTSet" + "(RequestId=" + RequestId + ")", {
				success: function () {
					that.autoRefresh();
				},
				error: function () {
					that.autoRefresh();
				}
			});

		},

		onShowMsg: function (oEvent) {
			var i18nModel = this.geti18nModel();
			var linkSource = oEvent.getSource();
			var RequestsPath = linkSource.getParent().getBindingContext("overview").sPath;
			var RequestId = RequestsPath.substring(RequestsPath.indexOf("'"), RequestsPath.indexOf(")"));
			var that;
			if (linkSource.getText() === "Open") {
				var request_obj = RequestsPath.substr(1);
				var downLoadLink = linkSource.getParent().getBindingContext("overview").getModel().oData[request_obj].Report_Url;
				sap.m.URLHelper.redirect(downLoadLink, true);
				// var url = "#/esrrequest/RequestId(";
				// sap.m.URLHelper.redirect(url + RequestsPath.substring(RequestsPath.indexOf("'"),
				// 	RequestsPath.indexOf(")")) + ")", true);
			} else if (linkSource.getText() === "Delete") {
				that = this;
				var vMessage = i18nModel.getResourceBundle().getText("comfirm");
				var Delete = i18nModel.getResourceBundle().getText("deleteDialogTitle");

				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.information(
					vMessage, {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: Delete,
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === "YES") {
								that.deleteReportItem(RequestId);
							}
						}
					});
			} else if (linkSource.getText() === "Download") {
				var request_obj = RequestsPath.substr(1);
				var downLoadLink = linkSource.getParent().getBindingContext("overview").getModel().oData[request_obj].Report_Url;
				sap.m.URLHelper.redirect(downLoadLink, true);

			}
		},

		setReportType: function (reportTypeIndex) {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			if (reportTypeIndex === 0) {
				oComp.sReportType = "ES";
			} else if (reportTypeIndex === 1) {
				oComp.sReportType = "PSLE";
			}
		},
		getReportType: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.sReportType;
		},
		getAuthorizedType: function () {
			var flag;
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			if (oComp.authorizedES === "true" && oComp.authorizedPSLE === "true") {
				flag = "Both";
			} else if (oComp.authorizedES === "true" && oComp.authorizedPSLE === "false") {
				flag = "ES";
			} else if (oComp.authorizedES === "false" && oComp.authorizedPSLE === "true") {
				flag = "PSLE";
			}
			return flag;
		},
		getErroMesg_es: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.errorMessageOf_es;
		},
		getErroMesg_psle: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.errorMessageOf_psle;
		},
		geti18nModel: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		},

		getCountModel: function () {
			var countModel = this.getOwnerComponent().getModel("count");
			return countModel;
		},
		autoRefresh: function () {
			this.getOwnerComponent().getModel("overview").refresh();
		}
	});

});
sap.ui.define([
	'jquery.sap.global',
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"sap/m/List",
	"sap/m/StandardListItem",
	"sap/m/Button",
	"sap/ui/table/TreeTable",
	"sap/m/Text",
	"sap/m/CheckBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/support/esrrequest/model/Formatter"
], function (jQuery, Controller, History, ODataModel, JSONModel, Dialog, List, StandardListItem, Button, TreeTable, Text, CheckBox,
	Filter,
	FilterOperator, MessageBox, Formatter) {
	"use strict";
	return Controller.extend("sap.support.esrrequest.controller.Detail", {
		formatter: Formatter,
		onInit: function () {

			this._oNavContainer = this.getView().byId("wizardNavContainer");
			// use as a navcontainer,has two page "wizardContentPage"and"ReviewPage"
			this._oWizardContentPage = this.getView().byId("wizardContentPage");
			this._wizard = this.getView().byId("CreateProductWizard");
			this._oWizardReviewPage = sap.ui.xmlfragment("sap.support.esrrequest.view.ReviewPage", this);
			this._oNavContainer.addPage(this._oWizardReviewPage);

			// create new data model to sent data between detail and reviews
			this.model = new JSONModel();
			this.getView().setModel(this.model);

			this._initRadiobutton();

			//this._initCustomersTable();
			this.prepareChapters();

			// formatted text style
			sap.ui.getCore().byId("formattedText2").addEventDelegate({
				onAfterRendering: $.proxy(function () {
					var children = $("#" + sap.ui.getCore().byId("formattedText2").getId()).children();
					$(children[2]).attr('class', 'formattedTextstyle');
					$(children[4]).attr('class', 'formattedTextstyle');
				}, this)
			});

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("overview").attachPatternMatched(this.refreshView, this);
		},

		_initDescriptionArea: function () {
			this.getView().byId("description").setValue("");
		},

		_initRadiobutton: function () {
			var reportType = this.getReportType();
			var userdataModel = new JSONModel();
			var radioGroup = this.getView().byId("radioGroup");
			var es1oModel;
			var psloModel;
			// load model(report_type、langu、email chaper),and prepare for tree chapter
			if (reportType === "ES") {
				// first step name
				this.getView().byId("reportTypeStep").bindProperty("title", {
					path: "i18n>esrFirstStepTitle"
				});
				// remove other name of type
				radioGroup.removeButton(0);
				//get oMoel, which include langu
				es1oModel = this.getOwnerComponent().getModel("oModel_es1");
				this.getView().byId("Langu_select").setModel(es1oModel, "select"); // get langu

				// get email of userdata
				userdataModel = this.getOwnerComponent().getModel("Model_userdata_es");
				this.getView().setModel(userdataModel, "email");

				// build trichapter model
				this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
				this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));

			} else if (reportType === "PSLE") {

				// first step name
				this.getView().byId("reportTypeStep").bindProperty("title", {
					path: "i18n>psleFirstStepTitle"
				});
				radioGroup.removeButton(1);
				//radioGroup.removeButton(1);
				psloModel = this.getOwnerComponent().getModel("oModel_psl");
				this.getView().byId("Langu_select").setModel(psloModel, "select");

				userdataModel = this.getOwnerComponent().getModel("Model_userdata_psle");
				this.getView().setModel(userdataModel, "email");

				this.getOwnerComponent().getModel("triChaptersModel").setData(psloModel.getData());
				this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
			} else if (reportType === "ES_PSLE") {

				this.getView().byId("reportTypeStep").bindProperty("title", {
					path: "i18n>esrFirstStepTitle"
				});
				psloModel = this.getOwnerComponent().getModel("oModel_psl");
				this.getView().byId("Langu_select").setModel(psloModel, "select"); // get langu

				// get email of userdata
				userdataModel = this.getOwnerComponent().getModel("Model_userdata_es");
				this.getView().setModel(userdataModel, "email");

				// build trichapter model
				this.getOwnerComponent().getModel("triChaptersModel").setData(psloModel.getData());
				this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
			} else if (reportType === "ALL") {
				var AuthoriedType = this.getAuthorizedType();
				if (AuthoriedType === "Both") {
					this.getView().byId("reportTypeStep").bindProperty("title", {
						path: "i18n>esrFirstStepTitle"
					});
					psloModel = this.getOwnerComponent().getModel("oModel_psl");
					this.getView().byId("Langu_select").setModel(psloModel, "select"); // get langu

					// get email of userdata
					userdataModel = this.getOwnerComponent().getModel("Model_userdata_es");
					this.getView().setModel(userdataModel, "email");

					// build trichapter model
					this.getOwnerComponent().getModel("triChaptersModel").setData(psloModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
				} else if (AuthoriedType === "ES") {
					// first step name
					this.getView().byId("reportTypeStep").bindProperty("title", {
						path: "i18n>esrFirstStepTitle"
					});
					// remove other name of type
					radioGroup.removeButton(0);
					//get oMoel, which include langu
					es1oModel = this.getOwnerComponent().getModel("oModel_es1");
					this.getView().byId("Langu_select").setModel(es1oModel, "select"); // get langu

					// get email of userdata
					userdataModel = this.getOwnerComponent().getModel("Model_userdata_es");
					this.getView().setModel(userdataModel, "email");

					// build trichapter model
					this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
				} else if (AuthoriedType === "PSLE") {
					// first step name
					this.getView().byId("reportTypeStep").bindProperty("title", {
						path: "i18n>psleFirstStepTitle"
					});
					radioGroup.removeButton(1);
					//radioGroup.removeButton(1);
					psloModel = this.getOwnerComponent().getModel("oModel_psl");
					this.getView().byId("Langu_select").setModel(psloModel, "select");

					userdataModel = this.getOwnerComponent().getModel("Model_userdata_psle");
					this.getView().setModel(userdataModel, "email");

					this.getOwnerComponent().getModel("triChaptersModel").setData(psloModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
				}
			}
		},

		_initCustomersTable: function (oEvent) {
			var oTable = this.getView().byId("customerList");
			oTable.bindRows({
				path: 'overview>/CustomerSet',
				parameters: {
					operationMode: sap.ui.model.odata.OperationMode.Server
				}
			});

			var oBinding = this.getView().byId("customerList").getBinding("rows");
			oBinding.attachDataReceived(function () { //Hits when the data is received from back-end server   
				var oSource = oEvent.getSource();
				oSource.bClientOperation = true; //Set Client Operation to true   
				oSource.sOperationMode = "Client"; //Set operation mode to Client   
			});

			var sQuery = oEvent.getParameter("query");
			var filters = new Array();
			if (sQuery) {
				filters = new Filter([
					new Filter("Customer_No", FilterOperator.Contains, sQuery),
					new Filter("Customer_Name", FilterOperator.Contains, sQuery)
				], false);
			}

			/*filters.push(oFilter1);
			filters.push(oFilter2);*/
			oBinding.filter(filters);
			oBinding.refresh();
		},

		// set trichapter model on tritable
		prepareChapters: function () {
			var model = this.getOwnerComponent().getModel("triChaptersModel");
			var contentInDialog = this.setTriTable(model.getData());
			var oTable = contentInDialog._oTable;
			// var NewModelchapter = contentInDialog._NewModelchapter;	
			var chapter = this.getView().byId("chapters_select");
			chapter.addContent(oTable);
		},
		re_loadDetail: function () {
			var _firstLoadDetail = sap.ui.core.Component.getOwnerComponentFor(this.getView())._firstLoadDetail;
			if (!_firstLoadDetail) {
				var radioGroup = this.getView().byId("radioGroup");
				if (radioGroup.getButtons().length === 2) {
					this._initRadiobutton();
					this.prepareChapters();
				}
			}
		},

		refreshView: function () {
			/*--------initial description textarea---------*/
			this._initDescriptionArea();
			/*---------------------------------------------*/
			var oForm = this.getView().byId("chapters_select");
			oForm.removeAllContent();
			//--------------------------------------------------------------
			var _radioGroup = this.getView().byId("radioGroup");
			_radioGroup.setSelectedIndex(null);
			var _customerList = this.getView().byId("customerList");
			_customerList.clearSelection();
			var es1oModel;
			var psloModel;
			if (this.getReportType() === "ES") {
				// build trichapter model
				es1oModel = this.getOwnerComponent().getModel("oModel_es1");
				this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
				this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
				this.prepareChapters();
			} else if (this.getReportType() === "PSLE" || this.getReportType() === "ES_PSLE") {
				psloModel = this.getOwnerComponent().getModel("oModel_psl");
				this.getOwnerComponent().getModel("triChaptersModel").setData(psloModel.getData());
				this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
				this.prepareChapters();
			} else if (this.getReportType() === "ALL") {
				var AuthoriedType = this.getAuthorizedType();
				if (AuthoriedType === "Both" || AuthoriedType === "PSLE") {
					psloModel = this.getOwnerComponent().getModel("oModel_psl");
					this.getOwnerComponent().getModel("triChaptersModel").setData(psloModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
					this.prepareChapters();
				} else if (AuthoriedType === "ES") {
					es1oModel = this.getOwnerComponent().getModel("oModel_es1");
					this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
					this.prepareChapters();
				}
			}

			this._oNavContainer.backToTop();
			this._wizard.goToStep(this._wizard.getSteps()[0]);
			this.discardProgress(this._wizard.getSteps()[0]);
			//--------------------------------------------------------------
			/*			this.getView().byId("showSelectedChapters_status").bindProperty("text", { path: "i18n>selectedAll" });
			 */
		},

		onSelect_reporttype: function () {
			var oForm = this.getView().byId("chapters_select");
			oForm.removeAllContent();
			var radioGroup = this.getView().byId("radioGroup");
			/*var reportType = radioGroup.getSelectedButton().sId;
			var type = reportType.substr(12, 2);*/
			var temp = radioGroup.getSelectedIndex();
			var type = this.getReportType();
			var es1oModel;
			var esboModel;
			var psloModel;
			if (type === "ES") {
				if (temp === 0) {
					// load resource of ES1,include langu chapters 
					es1oModel = this.getOwnerComponent().getModel("oModel_es1");
					this.getView().byId("Langu_select").setModel(es1oModel, "select");
					this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
					this.prepareChapters();
				} else if (temp === 1) {
					// load resource of ESb,include langu chapters 
					esboModel = this.getOwnerComponent().getModel("oModel_esb");
					this.getView().byId("Langu_select").setModel(esboModel, "select");
					this.getOwnerComponent().getModel("triChaptersModel").setData(esboModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
					this.prepareChapters();
				}
			} else if (type === "ES_PSLE") {
				if (temp === 1) {
					// load resource of ES1,include langu chapters 
					es1oModel = this.getOwnerComponent().getModel("oModel_es1");
					this.getView().byId("Langu_select").setModel(es1oModel, "select");
					this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
					this.prepareChapters();
				} else if (temp === 2) {
					// load resource of ESb,include langu chapters 
					esboModel = this.getOwnerComponent().getModel("oModel_esb");
					this.getView().byId("Langu_select").setModel(esboModel, "select");
					this.getOwnerComponent().getModel("triChaptersModel").setData(esboModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
					this.prepareChapters();
				} else if (temp === 0) {
					// load resource of ESb,include langu chapters 
					psloModel = this.getOwnerComponent().getModel("oModel_psl");
					this.getView().byId("Langu_select").setModel(psloModel, "select");
					this.getOwnerComponent().getModel("triChaptersModel").setData(psloModel.getData());
					this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
					this.prepareChapters();
				}
			} else if (type === "ALL") {
				var AuthoriedType = this.getAuthorizedType();
				if (AuthoriedType === "Both") {
					if (temp === 1) {
						// load resource of ES1,include langu chapters 
						es1oModel = this.getOwnerComponent().getModel("oModel_es1");
						this.getView().byId("Langu_select").setModel(es1oModel, "select");
						this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
						this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
						this.prepareChapters();
					} else if (temp === 2) {
						// load resource of ESb,include langu chapters 
						esboModel = this.getOwnerComponent().getModel("oModel_esb");
						this.getView().byId("Langu_select").setModel(esboModel, "select");
						this.getOwnerComponent().getModel("triChaptersModel").setData(esboModel.getData());
						this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
						this.prepareChapters();
					} else if (temp === 0) {
						// load resource of ESb,include langu chapters 
						psloModel = this.getOwnerComponent().getModel("oModel_psl");
						this.getView().byId("Langu_select").setModel(psloModel, "select");
						this.getOwnerComponent().getModel("triChaptersModel").setData(psloModel.getData());
						this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
						this.prepareChapters();
					}
				} else if (AuthoriedType === "ES") {
					if (temp === 0) {
						// load resource of ES1,include langu chapters 
						es1oModel = this.getOwnerComponent().getModel("oModel_es1");
						this.getView().byId("Langu_select").setModel(es1oModel, "select");
						this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
						this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
						this.prepareChapters();
					} else if (temp === 1) {
						// load resource of ESb,include langu chapters 
						esboModel = this.getOwnerComponent().getModel("oModel_esb");
						this.getView().byId("Langu_select").setModel(esboModel, "select");
						this.getOwnerComponent().getModel("triChaptersModel").setData(esboModel.getData());
						this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));
						this.prepareChapters();
					}
				}
			}
		},
		//
		// search fiead of customList table 
		filterGlobally: function (oEvent) {
			var oTable = this.getView().byId("customerList");
			oTable.bindRows({
				path: 'overview>/CustomerSet',
				parameters: {
					operationMode: sap.ui.model.odata.OperationMode.Server
				}
			});

			var oBinding = this.getView().byId("customerList").getBinding("rows");
			oBinding.attachDataReceived(function () { //Hits when the data is received from back-end server   
				var oSource = oEvent.getSource();
				oSource.bClientOperation = true; //Set Client Operation to true   
				oSource.sOperationMode = "Client"; //Set operation mode to Client   
			});

			var sQuery = oEvent.getParameter("query");
			var filters = new Array();
			if (sQuery) {
				filters = new Filter([
					new Filter("Customer_No", FilterOperator.Contains, sQuery),
					new Filter("Customer_Name", FilterOperator.Contains, sQuery)
				], false);
			}

			/*filters.push(oFilter1);
			filters.push(oFilter2);*/
			oBinding.filter(filters);
			oBinding.refresh();
		},

		onBacktoOverview: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("overview", true);
			}

		},
		/*---------------------------New feature---------------------------------*/
		goToNextStep: function () {
			var selectedKey = this.model.getProperty("/selectedStep");
			this._enableInstallationStep = false;
			switch (selectedKey) {
			case "Select installations":
				this.byId("selectCustomerStep").setNextStep(this.getView().byId("installationStep"));
				this._enableInstallationStep = true;
				this._getInsatallationData();
				break;
			case "Select chapters":
			default:
				this.byId("selectCustomerStep").setNextStep(this.getView().byId("ProductInfoStep"));
				break;
			}
		},
		setWizardStep: function () {
			var i18nModel = this.geti18nModel();
			var changeStepInfo = i18nModel.getResourceBundle().getText("changeStepInfo");
			this.setDiscardableProperty({
				message: changeStepInfo,
				discardStep: this.byId("selectCustomerStep"),
				modelPath: "/selectedStep",
				historyPath: "prevStepSelect"
			});
		},
		setDiscardableProperty: function (params) {
			if (this._wizard.getProgressStep() !== params.discardStep) {
				MessageBox.warning(params.message, {
					actions: [MessageBox.Action.YES, MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === MessageBox.Action.YES) {
							this._wizard.discardProgress(params.discardStep);
							history[params.historyPath] = this.model.getProperty(params.modelPath);
						} else {
							this.model.setProperty(params.modelPath, history[params.historyPath]);
						}
					}.bind(this)
				});
			} else {
				history[params.historyPath] = this.model.getProperty(params.modelPath);
			}
		},
		getSelectedCustomersIntoFilter: function () {
			var oFilters = [];
			var real_index_context = this.getSelectedCustomerIndex();
			for (var i = 0; i < real_index_context.length; i++) {
				var numberOfSelectedCustomer = this.getSelectedCustomerInfo(real_index_context, i)[1];
				var filter = new sap.ui.model.Filter("Customer_No",
					sap.ui.model.FilterOperator.EQ, numberOfSelectedCustomer);
				oFilters.push(filter);
			}
			return oFilters;
		},

		onSelectCustomer: function () {
			if (this._enableInstallationStep === true) {
				this._getInsatallationData();
			}
		},

		_getInsatallationData: function () {
			this.getView().byId("installationData").clearSelection();
			this.InstallationSelectStatus = false;
			var that = this;
			var oFilters = this.getSelectedCustomersIntoFilter();
			var installmodel = new ODataModel("/services/odata/svt/esr_srv", {
				useBatch: false
			});
			installmodel.read("/InstallationSet", {
				filters: oFilters,
				success: function (oData, oResponse) {
					that.model.setProperty("/InstallationSet", oResponse.data.results);
				}
			});
			this.getView().byId("installationData").setModel(this.model, "installationModel");
		},
		/*-----------------------------------------------------------------------*/
		getSelectedCustomerIndex: function () {
			var selected_indices = this.getView().byId("customerList").getSelectedIndices();
			//var selectedind_length = selected_indices.length;
			var tableVisibleItemsInfo = this.getView().byId("customerList").getBinding("rows").getContexts();
			var length_contex = tableVisibleItemsInfo.length;
			var arr_index_selct = selected_indices;
			var arr_contex_visit = Object.keys(new Int8Array(length_contex)).map(Number);
			var real_index_context = this._intersect(arr_index_selct, arr_contex_visit);
			return real_index_context;
		},

		getSelectedCustomerInfo: function (real_index_context, i) {
			var tableVisibleItemsInfo = this.getView().byId("customerList").getBinding("rows").getContexts();
			var real_index = real_index_context[i];
			var selected_item_path = tableVisibleItemsInfo[real_index].sPath;
			var selected_item_key = selected_item_path.substr(1);
			var selected_item_info = tableVisibleItemsInfo[real_index].oModel.oData;
			var nameOfselectedCustomer = selected_item_info[selected_item_key].Customer_Name;
			var numberOfSelectedCustomer = selected_item_info[selected_item_key].Customer_No;
			return [nameOfselectedCustomer, numberOfSelectedCustomer];
		},
		wizardCompletedHandler: function () {
			// save slected report_Type Name
			var radioGroup = this.getView().byId("radioGroup");
			var selected_reportType_Name = radioGroup.getSelectedButton().getText();
			this.model.setProperty("/reportType_Name", selected_reportType_Name);
			// save report languge type
			var LanguType = this.getView().byId("Langu_select").getSelectedItem().getText();
			this.model.setProperty("/reportLangu", LanguType);
			// save report description
			var description = this.getView().byId("description").getValue();
			this.model.setProperty("/description", description);
			// show chapter selected status
			var i18nModel = this.geti18nModel();
			var UnselectedChapterItems = this.onSaveUnSelectedChapter(this.getOwnerComponent().getModel("triChaptersModel"));
			if (UnselectedChapterItems.length === 0) {
				var selectedAll = i18nModel.getResourceBundle().getText("selectedAll");
				this.model.setProperty("/showSelectedChapters_status", selectedAll);
			} else {
				var someUnselected = i18nModel.getResourceBundle().getText("someUnselected");
				this.model.setProperty("/showSelectedChapters_status", someUnselected);

			}
			var real_index_context = this.getSelectedCustomerIndex();
			if (real_index_context.length === 0) {
				this.getAlertForLostCustomer();
			} else if (this.InstallationSelectStatus === false && this._enableInstallationStep === true) {
				this.getAlertForLostInstallation();
			} else {
				var LengthOfSelectedMemory = sap.ui.getCore().byId("selected_Customers").getItems().length;
				for (var j = 0; j < LengthOfSelectedMemory; j++) {
					sap.ui.getCore().byId("selected_Customers").removeItem(0);
				}

				for (var i = 0; i < real_index_context.length; i++) {

					var nameOfselectedCustomer = this.getSelectedCustomerInfo(real_index_context, i)[0];
					var addTextOfSelectedCustomer = new Text({
						text: nameOfselectedCustomer
					});
					sap.ui.getCore().byId("selected_Customers").addItem(addTextOfSelectedCustomer);
				}
				this._oNavContainer.to(this._oWizardReviewPage);

				var submitButtonFlag = this.getOwnerComponent().flagSubmitButton;
				if (submitButtonFlag === "false") {
					this._oNavContainer.getPage("wizardReviewPage").getAggregation("footer").getAggregation("contentRight")[0].setEnabled(false);
				}
			}
		},

		// calculate intersect
		_intersect: function (target1, target2) {
			var result = [],
				i = 0,
				l, repeat, compare, b = target1.length < target2.length;
			repeat = b ? target1 : target2;
			compare = b ? target2 : target1;
			l = repeat.length;
			while (i < l) {
				//!!~compare.indexOf(repeat[i]) && result.push(repeat[i]);
				if (!!~compare.indexOf(repeat[i]) === true) {
					result.push(repeat[i]);
				}
				i++;
			}
			return result;
		},
		getAlertForLostCustomer: function () {
			var i18nModel = this.geti18nModel();
			var mustChooseOne = new Dialog({
				title: "{i18n>alert}",
				type: "Message",
				state: "Error",
				content: new Text({
					text: "{i18n>pleaseSelectCustomers}"
				}),
				endButton: new sap.m.Button({
					text: "{i18n>ok}",
					press: function () {
						mustChooseOne.close();
					}
				})
			});
			mustChooseOne.setModel(i18nModel, "i18n");
			mustChooseOne.open();
		},
		checkCustomerSelectStatus: function () {
			var selected_indices = this.getView().byId("customerList").getSelectedIndices();
			//var selectedind_length = selected_indices.length;
			var tableVisibleItemsInfo = this.getView().byId("customerList").getBinding("rows").getContexts();
			var length_contex = tableVisibleItemsInfo.length;
			var arr_index_selct = selected_indices;
			var arr_contex_visit = Object.keys(new Int8Array(length_contex)).map(Number);
			var real_index_context = this._intersect(arr_index_selct, arr_contex_visit);
			if (real_index_context.length === 0) {
				this.getAlertForLostCustomer();
				this._wizard.goToStep(this._wizard.getSteps()[1]);
				this.discardProgress(this._wizard.getSteps()[1]);
				return false;
			}
			return true;
		},

		getSelectedInstallationsNumber: function (oInstallationTable, aSelectedItems) {
			var sInstallationName = "";
			var sInstallationNumber = "";
			for (var i = 0; i < aSelectedItems.length; i++) {
				/*var installationNumber = aSelectedItems[i].getCells()[2].getText();
				var installationName = aSelectedItems[i].getCells()[1].getText();
				sInstallationNumber = sInstallationNumber + installationNumber + ";";
				sInstallationName = sInstallationName + installationName + ";";*/
				var sPath = oInstallationTable.getContextByIndex(aSelectedItems[i]).getPath();
				var oRowData = oInstallationTable.getModel().getProperty(sPath);
				var installationNumber = oRowData.Installation_No;
				var installationName = oRowData.Installation_Name;
				sInstallationNumber = sInstallationNumber + installationNumber + ";";
				sInstallationName = sInstallationName + installationName + ";";
			}
			this.model.setProperty("/selectedInstallationsNumber", sInstallationNumber);
			this.model.setProperty("/selectedInstallationsName", sInstallationName);
		},

		onSelectRow: function (oEvent) {
			var oInstallationTable = this.getView().byId("installationData");
			var aSelectedItems = oInstallationTable.getSelectedIndices();
			if (aSelectedItems.length === 0) {
				this.InstallationSelectStatus = false;
			} else {
				this.InstallationSelectStatus = true;
				this.getSelectedInstallationsNumber(oInstallationTable, aSelectedItems);
			}

		},
		getAlertForLostInstallation: function () {
			var i18nModel = this.geti18nModel();
			var mustChooseOne = new Dialog({
				title: "{i18n>alert}",
				type: "Message",
				state: "Error",
				content: new Text({
					text: "{i18n>pleaseSelectInstallations}"
				}),
				endButton: new sap.m.Button({
					text: "{i18n>ok}",
					press: function () {
						mustChooseOne.close();
					}
				})
			});
			mustChooseOne.setModel(i18nModel, "i18n");
			mustChooseOne.open();
		},

		checkCustomerAndInstallationSelectStatus: function () {
			var bCustomerSeleted = this.checkCustomerSelectStatus();
			if (bCustomerSeleted === true && this.InstallationSelectStatus !== true && this._enableInstallationStep === true) {
				this.getAlertForLostInstallation();
				this._wizard.goToStep(this._wizard.getSteps()[2]);
				this.discardProgress(this._wizard.getSteps()[2]);
			}
		},

		backToWizardContent: function () {
			this._oNavContainer.backToPage(this._oWizardContentPage.getId());
		},

		getChildren: function (obj) {
			var children = [];
			Object.getOwnPropertyNames(obj).forEach(function (x) {
				if (typeof obj[x] === "object") {
					children.push(obj[x]);
				}
			});
			return children;
		},

		onSaveUnSelectedChapter: function (model, that) {
			function getUnselectItems(children, saveUnchecked) {
				Object.getOwnPropertyNames(children).forEach(function (x) {
					if (typeof children[x] === "object") {
						getUnselectItems(children[x], saveUnchecked);
					} else {
						if (x === "checked" && children.checked === false) {
							saveUnchecked.push(children.HEADERID);
						}
					}
				});
				return saveUnchecked;
			}
			var saveUnchecked = [];
			var obj = model.getData();
			var children = this.getChildren(obj);
			saveUnchecked = getUnselectItems(children, saveUnchecked);
			/*if (that !== null) {
				var i18nModel = this.geti18nModel();
				if (saveUnchecked.length === 0) {
					var selectedAll = i18nModel.getResourceBundle().getText("selectedAll");
					that.model.setProperty("/showSelectedChapters_status", selectedAll);
				} else {
					var someUnselected = i18nModel.getResourceBundle().getText("someUnselected");
					that.model.setProperty("/showSelectedChapters_status", someUnselected);
				}
			}*/
			return saveUnchecked;
		},
		//function for tristatucheckbox 
		setTriTable: function (model) {
			function getChildren(obj) {
				var children = [];
				Object.getOwnPropertyNames(obj).forEach(function (x) {
					if (typeof obj[x] === "object") {
						children.push(obj[x]);
					}
				});
				return children;
			}

			function setChildState(obj, state) {
				getChildren(obj).forEach(function (x) {
					x.checked = state;
					setChildState(x, state);
				});
			}

			function validateChild(_model, path) {
				var cur = _model.getProperty(path);
				setChildState(cur, cur.checked);
			}

			function validateParent(_model, path) {
				if (path === "/root") {
					return;
				}
				var obj = _model.getProperty(path);
				var children = getChildren(obj);
				var selectedCount = children.filter(function (x) {
					return x.checked === true;
				}).length;
				if (selectedCount === children.length) {
					obj.checked = true;
				}
				_model.setProperty(path, obj);
				path = path.substring(0, path.lastIndexOf("/"));
				if (path !== "/root") {
					validateParent(_model, path);
				}
			}
			//setup oTable for checkbox
			var oTable = new TreeTable({
				//title: "Chapter Selection",	
				visibleRowCount: 12,
				columns: [new sap.ui.table.Column({
					template: new sap.m.CheckBox({
							text: "{NBR} {ZTXT}",
							enabled: "{enabled}",
							selected: "{checked}",
							select: function (e) {
								var cxt = e.getSource().getBindingContext();
								var path = cxt.getPath();
								validateChild(this.getModel(), path);
								path = path.substring(0, path.lastIndexOf("/"));
								validateParent(this.getModel(), path);
							}
						})
						/*template: new sap.m.Text({
							text: "{NBR} {ZTXT}"
						})*/
						/*template: new sap.ui.commons.TriStateCheckBox({
							text: "{NBR} {ZTXT}",
							selectionState: "{checked}",
							enabled: "{enabled}",
							change: function(e) {
								var cxt = e.getSource().getBindingContext();
								var path = cxt.getPath();
								validateChild(this.getModel(), path);
								path = path.substring(0, path.lastIndexOf("/"));
								validateParent(this.getModel(), path);
							}
						})*/
				})],
				selectionMode: sap.ui.table.SelectionMode.Single,
				expandFirstLevel: true
			});

			var NewModelchapter = new JSONModel();
			//set model to oTable
			NewModelchapter.setData(model);

			oTable.setModel(NewModelchapter);
			oTable.bindRows("/root");
			oTable.selectAll();
			return {
				_oTable: oTable,
				_NewModelchapter: NewModelchapter
			};
		},

		// the chapter select dialog
		onselectChapters: function (oEvent) {
			var model = this.getOwnerComponent().getModel("triChaptersModel");
			var contentInDialog = this.setTriTable(model.getData());
			var oTable = contentInDialog._oTable;
			var NewModelchapter = contentInDialog._NewModelchapter;
			// create new Dialog
			var that = this;
			var i18nModel = this.geti18nModel();
			var chapterDialog = new Dialog({
				title: "{i18n>selectChapters}",
				type: "Message",
				content: oTable,
				contentWidth: "600px",
				beginButton: new Button({
					text: "{i18n>saveButton}",
					press: function () {
						that.onSaveUnSelectedChapter(NewModelchapter, that);
						chapterDialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "{i18n>closeButton}",
					press: function () {
						chapterDialog.close();
					}
				})
			});
			chapterDialog.setModel(i18nModel, "i18n");
			chapterDialog.open();
		},

		onSaveAllOptions: function () {
			//get Report type
			var reportID;
			var radio_index = this.getView().byId("radioGroup").getSelectedIndex();
			var reportType = this.getReportType();
			if (reportType === "ES_PSLE") {
				if (radio_index === 0) {
					reportID = "PSL";
				} else if (radio_index === 1) {
					reportID = "ES1";
				}
			} else if (reportType === "PSLE") {
				reportID = "PSL";
			} else if (reportType === "ES") {
				reportID = "ES1";
			} else if(reportType === "ALL"){
				var AuthoriedType = this.getAuthorizedType();
				if(AuthoriedType === "Both"){
					if (radio_index === 0) {
						reportID = "PSL";
					} else if (radio_index === 1) {
						reportID = "ES1";
					}
				}else if(AuthoriedType === "ES"){
					reportID = "ES1";
				}else if(AuthoriedType === "PSLE"){
					reportID = "PSL";
				}
			}
			//get selected Language
			var Langukey = this.getView().byId("Langu_select").getSelectedItem().getKey();

			//get unselected Chapters
			var UnselectedChapterItems = this.onSaveUnSelectedChapter(this.getOwnerComponent().getModel("triChaptersModel"));
			var reSaveUnselectedChapterItems = "";
			for (var i = 0; i < UnselectedChapterItems.length; i++) {
				var reSaveUnselectedChapterItemscopy = UnselectedChapterItems[i] + ";";
				reSaveUnselectedChapterItems = reSaveUnselectedChapterItems + reSaveUnselectedChapterItemscopy;
			}
			//get selected customers
			var selected_indices = this.getView().byId("customerList").getSelectedIndices();
			//var selectedind_length = selected_indices.length;
			var tableVisibleItemsInfo = this.getView().byId("customerList").getBinding("rows").getContexts();
			var length_contex = tableVisibleItemsInfo.length;
			var arr_index_selct = selected_indices;
			var arr_contex_visit = Object.keys(new Int8Array(length_contex)).map(Number);
			var real_index_context = this._intersect(arr_index_selct, arr_contex_visit);
			var SelectedCustomers = [];
			for (var j = 0; j < real_index_context.length; j++) {
				var real_index = real_index_context[j];
				var selected_item_path = tableVisibleItemsInfo[real_index].sPath;
				var selected_item_key = selected_item_path.substr(1);
				var selected_item_info = tableVisibleItemsInfo[real_index].oModel.oData;
				var nameOfselectedCustomer = selected_item_info[selected_item_key].Customer_No;
				SelectedCustomers.push(nameOfselectedCustomer);
			}
			var reSaveSelectedCustomers = "";
			for (var k = 0; k < SelectedCustomers.length; k++) {
				var reSaveSelectedCustomerscopy = SelectedCustomers[k] + ";";
				reSaveSelectedCustomers = reSaveSelectedCustomers + reSaveSelectedCustomerscopy;
			}

			var oData = {};
			oData.ReportId = reportID;
			oData.ReportLangu = Langukey;
			oData.RemoveChapter = reSaveUnselectedChapterItems;
			oData.RepKunnr = reSaveSelectedCustomers;
			/*----------New feature get selected installation numbers ---------*/
			if (this.model.getProperty("/selectedStep") === "Select installations") {
				oData.Installation_No = this.model.getProperty("/selectedInstallationsNumber");
			}
			/*------------------------------------------------------------------*/
			/*----------New feature get description text ---------*/
			oData.Description = this.model.getProperty("/description");
			/*------------------------------------------------------------------*/

			var that = this;
			var url = "/services/odata/svt/esr_srv";
			var m = new sap.ui.model.odata.v2.ODataModel(url);
			m.setUseBatch(false);
			m.create("/ESR_REQUESTSet", oData, {
				success: function () {
					that.autoRefresh();
				},
				error: function () {
					that.autoRefresh();
				}
			});
			// back to overview page and reset chapter table(ES report)
			if (reportID !== "PSL") {
				var es1oModel = this.getOwnerComponent().getModel("oModel_es1");
				this.getOwnerComponent().getModel("triChaptersModel").setData(es1oModel.getData());
				this.rebuildChaptersModel(this.getOwnerComponent().getModel("triChaptersModel"));

			}
			var i18nModel = this.geti18nModel();
			var selectedAll = i18nModel.getResourceBundle().getText("selectedAll");
			this.model.setProperty("/showSelectedChapters_status", selectedAll);
			this.onBacktoOverview();
		},

		geti18nModel: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		},

		getCustomList: function () {
			var customListModel = new JSONModel();
			customListModel.loadData("/services/odata/svt/esr_srv/CustomerSet", {}, false, "GET");
			return customListModel;
		},

		rebuildChaptersModel: function (oModel) {
			//tree without checkbox
			var chapterData = oModel.getData().d.ChapterSet.results;
			var oData1 = {};
			oData1.root = {};
			var level1Index = 0;
			var level2Index = 0;
			var level3Index = 0;
			var level4Index = 0;
			for (var i = 0; i < chapterData.length; i++) {
				delete chapterData[i]["__metadata"];
				var tep = "__proto__";
				delete chapterData[i][tep];
				chapterData[i]["checked"] = true;
				if (chapterData[i].ZLEVEL === "1") {
					oData1.root[level1Index] = {};
					oData1.root[level1Index] = chapterData[i];
					var temp1 = level1Index++;
					level2Index = 0;
					level3Index = 0;
					level4Index = 0;
				} else if (chapterData[i].ZLEVEL === "2") {
					oData1.root[temp1][level2Index] = {};
					oData1.root[temp1][level2Index] = chapterData[i];
					var temp2 = level2Index++;
					continue;
				} else if (chapterData[i].ZLEVEL === "3") {
					oData1.root[temp1][temp2][level3Index] = {};
					oData1.root[temp1][temp2][level3Index] = chapterData[i];
					var temp3 = level3Index++;
					continue;
				} else {
					oData1.root[temp1][temp2][temp3][level4Index] = {};
					oData1.root[temp1][temp2][temp3][level4Index++] = chapterData[i];
					continue;
				}
				// oTree.addNode(level1TreeNode);
			}
			oData1.root[0].enabled = false;
			oModel.setData(oData1);
			return oModel;
		},

		onTargetEmailButton: function () {

			var i18nModel = this.geti18nModel();
			var Information = i18nModel.getResourceBundle().getText("infor");
			var dilogcontent = i18nModel.getResourceBundle().getText("msg");

			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.information(
				dilogcontent, {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: Information,
					actions: [sap.m.MessageBox.Action.YES]
				});
		},
		getReportType: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.sReportType;
		},
		getAuthorizedType: function () {
			var flag;
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			if (oComp.authorizedES === "true" && oComp.authorizedPSLE === "true") {
				flag = "Both";
			} else if (oComp.authorizedES === "true" && oComp.authorizedPSLE === "false") {
				flag = "ES";
			} else if (oComp.authorizedES === "false" && oComp.authorizedPSLE === "true") {
				flag = "PSLE";
			}
			return flag;
		},
		autoRefresh: function () {
			this.getOwnerComponent().getModel("overview").refresh();
		},
		discardProgress: function (sStep) {
			this._wizard.discardProgress(sStep);
			//this._wizard.discardProgress(this._wizard.getSteps()[0]);
			/*var clearContent = function (content) {
					for (var i = 0; i < content.length ; i++) {
						if (content[i].setValue) {
							content[i].setValue("");
						}
	
						if (content[i].getContent) {
							clearContent(content[i].getContent());
						}
					}
				};
				clearContent(this._wizard.getSteps());*/
		},
		onHelpButton: function () {
			var i18nModel = this.geti18nModel();
			var oBundle = i18nModel.getResourceBundle();
			var sHtmlText;
			var HelpInfo = {};
			var sHtmlText1;
			var HelpInfo1 = {};
			//var oLink;
			//var oLink1;
			if (this.getReportType() === "ES") {
				HelpInfo = this._getESHelpText();
				sHtmlText = HelpInfo._oHtmlText;
				//oLink = HelpInfo._oLink;
			} else if (this.getReportType() === "PSLE") {
				HelpInfo = this._getPSLEHelpText();
				sHtmlText = HelpInfo._oHtmlText;
				//oLink = HelpInfo._oLink;
			} else if (this.getReportType() === "ES_PSLE") {
				HelpInfo = this._getESHelpText();
				HelpInfo1 = this._getPSLEHelpText();
				sHtmlText = HelpInfo._oHtmlText;
				sHtmlText1 = HelpInfo1._oHtmlText;
				sHtmlText = sHtmlText + sHtmlText1;
				//oLink = HelpInfo._oLink;
				//oLink1 = HelpInfo1._oLink;
			} else if (this.getReportType() === "ALL") {
				var AuthoriedType = this.getAuthorizedType();
				if (AuthoriedType === "Both") {
					HelpInfo = this._getESHelpText();
					HelpInfo1 = this._getPSLEHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					sHtmlText1 = HelpInfo1._oHtmlText;
					sHtmlText = sHtmlText + sHtmlText1;
					//oLink = HelpInfo._oLink;
					//oLink1 = HelpInfo1._oLink;
				} else if (AuthoriedType === "ES") {
					HelpInfo = this._getESHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					//oLink = HelpInfo._oLink;
				} else if (AuthoriedType === "PSLE") {
					HelpInfo = this._getPSLEHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					//	oLink = HelpInfo._oLink;
				}
			}

			var oFTV1 = new sap.m.FormattedText();
			oFTV1.setHtmlText(sHtmlText);
			//	oFTV1.addControl(oLink);
			//	oFTV1.addControl(oLink1);

			var Information = oBundle.getText("infor");
			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.information(
				oFTV1, {
					title: Information,
					icon: sap.m.MessageBox.Icon.INFORMATION,
					actions: [sap.m.MessageBox.Action.YES]
				});
		},

		_getESHelpText: function () {
			var i18nModel = this.geti18nModel();
			var oBundle = i18nModel.getResourceBundle();
			var sHtmlText;
			//var oLink;
			var href1 = "https:" + "//launchpad.support" + ".sap.com/#/incident/create";
			sHtmlText = "<span class='myCustomHelpDialog'>" + oBundle.getText("helpTitle_ESR") + "</span><br><br>";
			sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine1_ESR_PSLE") + "</span><br>";
			sHtmlText += "<li>" + oBundle.getText("helpTip1_ESR_PSLE_1") + "<a href='" + href1 + "'>" + "&nbsp;" + oBundle.getText(
				"helpTip1_ESR_PSLE_2") + "&nbsp;" + "</a>" + oBundle.getText("helpTip1_ESR_PSLE_3") + "</li><br>";
			sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine2_ESR_PSLE") + "</span><br>";
			sHtmlText += "<li>" + oBundle.getText("helpTip2_ESR") + "</li>";

			/*oLink = new Link({
				text: oBundle.getText("helpTip1_ESR_PSLE_2"),
				href: href1,
				target: "_blank"
			});*/
			return {
				_oHtmlText: sHtmlText
					//_oLink: oLink
			};
		},
		_getPSLEHelpText: function () {
			var i18nModel = this.geti18nModel();
			var oBundle = i18nModel.getResourceBundle();
			var sHtmlText;
			//var oLink;
			var href1 = "https:" + "//launchpad.support" + ".sap.com/#/incident/create";
			sHtmlText = "<span class='myCustomHelpDialog'>" + oBundle.getText("helpTitle_PSLE") + "</span><br><br>";

			sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine1_ESR_PSLE") + "</span><br>";
			sHtmlText += "<li>" + oBundle.getText("helpTip1_ESR_PSLE_1") + "<a href='" + href1 + "'>" + "&nbsp;" + oBundle.getText(
					"helpTip1_ESR_PSLE_2") + "&nbsp;" + "</a>" + oBundle.getText("helpTip1_ESR_PSLE_3") +
				"</li><br>";

			sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine2_ESR_PSLE") + "</span><br>";
			sHtmlText += "<li>" + oBundle.getText("helpTip2_PSLE") + "</li>";

			/*	oLink = new Link({
					text: oBundle.getText("helpTip1_ESR_PSLE_2"),
					href: href1,
					target: "_blank"
				});*/
			return {
				_oHtmlText: sHtmlText
					//_oLink: oLink
			};
		}
	});
});
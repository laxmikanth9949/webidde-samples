sap.ui.define([
		"sap/support/esrrequest/controller/BaseController",
		"sap/ui/core/routing/History",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/m/RadioButton",
		"sap/ui/model/json/JSONModel",
		"sap/support/esrrequest/model/model",
		"sap/support/esrrequest/model/Formatter"
	],
	function (BaseController, History, Filter, FilterOperator, RadioButton, JSONModel, model, formatter) {
		"use strict";
		return BaseController.extend("sap.support.esrrequest.controller.CloudRequest", {
			formatter: formatter,
			onInit: function () {
				this._setCustomerList();
				/*var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("cloud").attachPatternMatched(this._setCustomerList, this);*/
				/*-----------------------------footer button display mode-----------------------------------*/
				var overviewDisplayModel = model.creatOverviewDisplayModel();
				this.setModel(overviewDisplayModel, "overviewDisplay");
				var submitButtonFlag = this.getOwnerComponent().flagSubmitButton;
				if (submitButtonFlag === "false") {
					overviewDisplayModel.setProperty("/substituted", "X");
				}
			var oModel = new JSONModel({
				HTML1: "<h3><strong>IMPORTANT “PDF-Cloud Version will soon END”</strong></h3>" +
					"<p>Please note the interactive " +
					"<a href=\"//launchpad.support.sap.com/#/customerinsight360\" style=\"color:blue; font-weight:600;\">" +
					"SAP Enterprise Support reporting cockpit </a>" +
					"has been released for our customers. All necessary information about the reporting cockpit (content, access rights, etc.) " +
					"can be found the SAP Enterprise Support reporting cockpit " +
					"<a href=\"//support.sap.com/esrc\" style=\"color:blue; font-weight:600;\">portal page</a>. " +
					"Additional information about the reporting cockpit can be found in " +
					"<a href=\"//blogs.sap.com/tag/esrc/\" style=\"color:blue; font-weight:600;\">customer BLOG</a>.</p>" +
					"<p>After a transition period, the pdf based cloud report will no longer be available. " +
					"<strong>The transition period is planned till 30.11.2020.</strong>" +
					" Please use this time to make yourself familiar with the ES reporting cockpit.</p>" +
					"<p>The PDF based on-premise report is currently not affected.</p>"
			});
			this.getView().setModel(oModel);
			},
			_setCustomerList: function () {
				var cunstomListModel = this.getCustomList();
				var countOfCustomerList = cunstomListModel.getData().d.results.length;
				for (var i = 0; i < countOfCustomerList; i++) {
					var customButton = new RadioButton({
						id: "customer_" + i,
						text: cunstomListModel.getData().d.results[i].Customer_No + " " + cunstomListModel.getData().d.results[i].Customer_Name
					});
					this.getView().byId("cloudCustomers").addButton(customButton);
				}
				this.getView().byId("cloudCustomers").setSelectedIndex(0);
				var CustomerNo = this.getView().byId("cloudCustomers").getSelectedButton().getText().substr(0, 10);
				this.SetSolutionModel(CustomerNo);
				//var SolutionModel = this._getSolutionSet(CustomerNo);
				//this.getView().byId("solution_select").setModel(SolutionModel, "solution");
			},
			onSelectCustomer: function () {
				var CustomerNo = this.getView().byId("cloudCustomers").getSelectedButton().getText().substr(0, 10);
				this.SetSolutionModel(CustomerNo);
				//var SolutionModel = this._getSolutionSet(CustomerNo);
				//this.getView().byId("solution_select").setModel(SolutionModel, "solution");
			},
			onSaveAndDownloadCloudRequest: function () {
				var SelectedCustomer = this.getView().byId("cloudCustomers").getSelectedButton().getText().substr(0, 10);
				var SelectedSolution = this.getView().byId("solution_select").getSelectedItem().getKey();
				var SelctedTimeFrame = this.getView().byId("timeFrame").getSelectedItem().getText();
				// create request 
				var oData = {};
				oData.RepKunnr = SelectedCustomer;
				oData.ReportId = "CLD";
				oData.ReportLangu = "E";
				oData.Solution_key = SelectedSolution;
				oData.Time_Frame = SelctedTimeFrame;
				// create a cloud report
				var that = this;
				var url = this._getRemoteRoot();
				//var url = "/services/odata/svt/esr_srv";
				this.m = new sap.ui.model.odata.v2.ODataModel(url);
				this.m.setUseBatch(false);
				this.m.create("/ESR_REQUESTSet", oData, {
					success: function (Data, res) {
						var times = 0;
						var oTimer = setInterval(function () {
							var requestCheckModel = new JSONModel();
							requestCheckModel.loadData(that._getRemoteRoot() +
								"ESR_REQUESTSet(RequestId='" + Data.RequestId + "')", {}, false, "GET");
							if (requestCheckModel.getData().d.Report_Url !== "") {
								clearInterval(oTimer);
								that.getView().setBusy(false);
								sap.m.URLHelper.redirect(requestCheckModel.getData().d.Report_Url, true);
								that.autoRefresh();
								that.onBacktoOverview();
							}
							times++;
							if (times === 6) {
								clearInterval(oTimer);
								that._serviceUnavailable();
							}
						}.bind(this), 11000);
						/*that.getView().setBusy(false);
						sap.m.URLHelper.redirect(Data.Report_Url, true);
						that.autoRefresh();
						that.onBacktoOverview();*/
					},
					error: function (oError) {
						that._serviceUnavailable();
					}
				});
				this.getView().setBusy(true);
			},
			_serviceUnavailable: function () {
				this.getView().setBusy(false);
				var userdataModel = new JSONModel();
				userdataModel = this.getOwnerComponent().getModel("Model_userdata_cld");
				var email_address = userdataModel.getData().d.UserEmail;
				//	userdataModel
				var i18nModel = this.geti18nModel();
				var oBundle = i18nModel.getResourceBundle();
				var sHtmlText;
				sHtmlText = "<span class='myCloudDialog' >" + oBundle.getText("unavailable_message_1") + "&nbsp;" + oBundle.getText(
					"unavailable_message_2") + email_address + "</span><br>";
				var oFTV1 = new sap.m.FormattedText();
				oFTV1.setHtmlText(sHtmlText);
				var Information = oBundle.getText("infor");
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.information(
					oFTV1, {
						title: Information,
						icon: sap.m.MessageBox.Icon.INFORMATION,
						actions: [sap.m.MessageBox.Action.YES]
					});
			},
			autoRefresh: function () {
				this.getOwnerComponent().getModel("overview").refresh();
			},
			onBacktoOverview: function () {
				var oHistory = History.getInstance();
				var sPreviousHash = oHistory.getPreviousHash();
				this.getView().byId("cloudCustomers").setSelectedIndex(0);
				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("overview", true);
				}
			},
			getCustomList: function () {
				var customListModel = new JSONModel();
				var root = this._getRemoteRoot();
				customListModel.loadData(root + "CustomerSet?$filter=ReportType eq 'CLD'", {}, false, "GET");
				return customListModel;
			},
			geti18nModel: function () {
				var i18nModel = this.getOwnerComponent().getModel("i18n");
				return i18nModel;
			},
			getReportType: function () {
				var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				return oComp.sReportType;
			},
			_getRemoteRoot: function () {
				var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				var root = oComp.sConfig.requestRemote;
				return root;
			},
			SetSolutionModel: function (CustomerNo) {
				//var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				var root = this._getRemoteRoot();
				var oModel_solution = new JSONModel();
				oModel_solution.loadData(root +
					"SolutionSet?$filter=CustomerNo eq '" + CustomerNo + "'", {}, true, "GET");
				oModel_solution.attachRequestFailed(function () {
					var oData = {};
					oData.d = {};
					oData.d.results = [];
					oData.d.results[0] = {};
					oData.d.results[0].CustomerNo = CustomerNo;
					oData.d.results[0].Solution_Key = "BYD";
					oData.d.results[0].Solution_Name = "Business ByDesign";
					oModel_solution.setData(oData);
					oData.d.results[1] = {};
					oData.d.results[1].CustomerNo = CustomerNo;
					oData.d.results[1].Solution_Key = "SFSF";
					oData.d.results[1].Solution_Name = "SuccessFactors";
					oModel_solution.setData(oData);
					oData.d.results[2] = {};
					oData.d.results[2].CustomerNo = CustomerNo;
					oData.d.results[2].Solution_Key = "S4HANA";
					oData.d.results[2].Solution_Name = "S/4HANA";
					oModel_solution.setData(oData);
					oData.d.results[3] = {};
					oData.d.results[3].CustomerNo = CustomerNo;
					oData.d.results[3].Solution_Key = "COD";
					oData.d.results[3].Solution_Name = "Cloud for Customer";
					oModel_solution.setData(oData);
					oData.d.results[4] = {};
					oData.d.results[4].CustomerNo = CustomerNo;
					oData.d.results[4].Solution_Key = "IBP";
					oData.d.results[4].Solution_Name = "SAP Integrated Business Planning (IBP)";
					oModel_solution.setData(oData);
				});
				this.getView().byId("solution_select").setModel(oModel_solution, "solution");
			},
			onHelpButton: function () {
				var i18nModel = this.geti18nModel();
				var oBundle = i18nModel.getResourceBundle();
				var sHtmlText;
				var HelpInfo = {};
				var sHtmlText1;
				var HelpInfo1 = {};
				//var oLink;
				//var oLink1;
				if (this.getReportType() === "ES") {
					HelpInfo = this._getESHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					//oLink = HelpInfo._oLink;
				} else if (this.getReportType() === "PSLE") {
					HelpInfo = this._getPSLEHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					//oLink = HelpInfo._oLink;
				} else if (this.getReportType() === "ES_PSLE") {
					HelpInfo = this._getESHelpText();
					HelpInfo1 = this._getPSLEHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					sHtmlText1 = HelpInfo1._oHtmlText;
					sHtmlText = sHtmlText + sHtmlText1;
					//oLink = HelpInfo._oLink;
					//oLink1 = HelpInfo1._oLink;
				} else if (this.getReportType() === "ALL") {
					var AuthoriedType = this.getAuthorizedType();
					if (AuthoriedType === "Both") {
						HelpInfo = this._getESHelpText();
						HelpInfo1 = this._getPSLEHelpText();
						sHtmlText = HelpInfo._oHtmlText;
						sHtmlText1 = HelpInfo1._oHtmlText;
						sHtmlText = sHtmlText + sHtmlText1;
						//oLink = HelpInfo._oLink;
						//oLink1 = HelpInfo1._oLink;
					} else if (AuthoriedType === "ES") {
						HelpInfo = this._getESHelpText();
						sHtmlText = HelpInfo._oHtmlText;
						//oLink = HelpInfo._oLink;
					} else if (AuthoriedType === "PSLE") {
						HelpInfo = this._getPSLEHelpText();
						sHtmlText = HelpInfo._oHtmlText;
						//	oLink = HelpInfo._oLink;
					}
				}

				var oFTV1 = new sap.m.FormattedText();
				oFTV1.setHtmlText(sHtmlText);
				//	oFTV1.addControl(oLink);
				//	oFTV1.addControl(oLink1);

				var Information = oBundle.getText("infor");
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.information(
					oFTV1, {
						title: Information,
						icon: sap.m.MessageBox.Icon.INFORMATION,
						actions: [sap.m.MessageBox.Action.YES]
					});
			},

			_getESHelpText: function () {
				var i18nModel = this.geti18nModel();
				var oBundle = i18nModel.getResourceBundle();
				var sHtmlText;
				//var oLink;
				var href1 = "https:" + "//launchpad.support" + ".sap.com/#/incident/create";
				sHtmlText = "<span class='myCustomHelpDialog'>" + oBundle.getText("helpTitle_ESR") + "</span><br><br>";
				sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine1_ESR_PSLE") + "</span><br>";
				sHtmlText += "<li>" + oBundle.getText("helpTip1_ESR_PSLE_1") + "<a href='" + href1 + "'>" + "&nbsp;" + oBundle.getText(
					"helpTip1_ESR_PSLE_2") + "&nbsp;" + "</a>" + oBundle.getText("helpTip1_ESR_PSLE_3") + "</li><br>";
				sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine2_ESR_PSLE") + "</span><br>";
				sHtmlText += "<li>" + oBundle.getText("helpTip2_ESR") + "</li>";

				/*oLink = new Link({
					text: oBundle.getText("helpTip1_ESR_PSLE_2"),
					href: href1,
					target: "_blank"
				});*/
				return {
					_oHtmlText: sHtmlText
						//_oLink: oLink
				};
			},
			_getPSLEHelpText: function () {
				var i18nModel = this.geti18nModel();
				var oBundle = i18nModel.getResourceBundle();
				var sHtmlText;
				//var oLink;
				var href1 = "https:" + "//launchpad.support" + ".sap.com/#/incident/create";
				sHtmlText = "<span class='myCustomHelpDialog'>" + oBundle.getText("helpTitle_PSLE") + "</span><br><br>";

				sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine1_ESR_PSLE") + "</span><br>";
				sHtmlText += "<li>" + oBundle.getText("helpTip1_ESR_PSLE_1") + "<a href='" + href1 + "'>" + "&nbsp;" + oBundle.getText(
						"helpTip1_ESR_PSLE_2") + "&nbsp;" + "</a>" + oBundle.getText("helpTip1_ESR_PSLE_3") +
					"</li><br>";

				sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine2_ESR_PSLE") + "</span><br>";
				sHtmlText += "<li>" + oBundle.getText("helpTip2_PSLE") + "</li>";

				/*	oLink = new Link({
						text: oBundle.getText("helpTip1_ESR_PSLE_2"),
						href: href1,
						target: "_blank"
					});*/
				return {
					_oHtmlText: sHtmlText
						//_oLink: oLink
				};
			},
			getAuthorizedType: function () {
				var flag;
				var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				if (oComp.authorizedES === "true" && oComp.authorizedPSLE === "true") {
					flag = "Both";
				} else if (oComp.authorizedES === "true" && oComp.authorizedPSLE === "false") {
					flag = "ES";
				} else if (oComp.authorizedES === "false" && oComp.authorizedPSLE === "true") {
					flag = "PSLE";
				}
				return flag;
			},

		});

	});
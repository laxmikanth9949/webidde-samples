sap.ui.define([
	"sap/support/esrrequest/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/support/esrrequest/model/model",
	"sap/support/esrrequest/model/Formatter"
], function (BaseController, History, MessageToast, MessageBox, model, formatter) {
	"use strict";
	return BaseController.extend("sap.support.esrrequest.controller.App", {
		formatter: formatter,
		onInit: function () {
			var contract = this.getAuthrizedContract();
			var reportType = this.getReportType();
			// var oModeluserdata;
			if (reportType !== undefined) {
				/*
				var disableNewRequest = oModeluserdata.getData().d.Disable_New_Request;*/
				if (contract === "three") { //ES&PLSE&CLOUD
					this.getView().byId("threeContrate").setVisible(true);
					/*if (disableNewRequest === "X") { //4th downtime
						this.getView().byId("onlyCloud").setVisible(true);
					} else {
						this.getView().byId("threeContrate").setVisible(true);
					}*/
				} else if (contract === "onPremise") { //ES||/&PLSE and out of 4th downtime
					this.getView().byId("onlyOnpremise").setVisible(true);
					/*if (disableNewRequest !== "X") {
						this.getView().byId("onlyOnpremise").setVisible(true);
					}*/
				} else if (contract === "onpremise_Cloud") { // ES||/&PLSE AND CLD 
					this.getView().byId("threeContrate").setVisible(true);
					/*if (disableNewRequest !== "X") {
						this.getView().byId("threeContrate").setVisible(true);
					} else {
						this.getView().byId("onlyCloud").setVisible(true);
					}*/
				} else if (contract === "cloud") {
					this.getView().byId("onlyCloud").setVisible(true);
				} 
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("overview").attachPatternMatched(this.refreshView, this);
			/*-----------------------------footer button display mode-----------------------------------*/
			var overviewDisplayModel = model.creatOverviewDisplayModel();
			this.setModel(overviewDisplayModel, "overviewDisplay");
			var submitButtonFlag = this.getOwnerComponent().flagSubmitButton;
			if (submitButtonFlag === "false") {
				overviewDisplayModel.setProperty("/substituted", "X");
			}
		},
		getAuthrizedContract: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.checkContract;
		},
		refreshView: function () {
			this.getOwnerComponent().getModel("overview").refresh();
		},
		autoRefresh: function () {
			this.getOwnerComponent().getModel("overview").refresh();
		},
		onNavBackButton: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			this.setFristLoadDetail(false);
			if (sPreviousHash !== undefined) {
				window.history.go(-1);

			}
		},
		onAfterNavigate: function (oEvent) {
			var oView = oEvent.getParameter("to");
			if (oView.getViewName() === "sap.support.esrrequest.view.Detail") {
				var radioGroup = oView.byId("radioGroup");
				radioGroup.setSelectedIndex(0);
				oView.byId("Langu_select").setSelectedKey("E");
			}
		},

		onHelpButton: function () {
			var i18nModel = this.geti18nModel();
			var oBundle = i18nModel.getResourceBundle();
			var sHtmlText;
			var HelpInfo = {};
			var sHtmlText1;
			var HelpInfo1 = {};
			//var oLink;
			//var oLink1;
			if (this.getReportType() === "ES") {
				HelpInfo = this._getESHelpText();
				sHtmlText = HelpInfo._oHtmlText;
				//oLink = HelpInfo._oLink;
			} else if (this.getReportType() === "PSLE") {
				HelpInfo = this._getPSLEHelpText();
				sHtmlText = HelpInfo._oHtmlText;
				//oLink = HelpInfo._oLink;
			} else if (this.getReportType() === "ES_PSLE") {
				HelpInfo = this._getESHelpText();
				HelpInfo1 = this._getPSLEHelpText();
				sHtmlText = HelpInfo._oHtmlText;
				sHtmlText1 = HelpInfo1._oHtmlText;
				sHtmlText = sHtmlText + sHtmlText1;
				//oLink = HelpInfo._oLink;
				//oLink1 = HelpInfo1._oLink;
			} /* else if (this.getReportType() === "ALL") {
				var AuthoriedType = this.getAuthorizedType();
				if (AuthoriedType === "Both") {
					HelpInfo = this._getESHelpText();
					HelpInfo1 = this._getPSLEHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					sHtmlText1 = HelpInfo1._oHtmlText;
					sHtmlText = sHtmlText + sHtmlText1;
					//oLink = HelpInfo._oLink;
					//oLink1 = HelpInfo1._oLink;
				} else if (AuthoriedType === "ES") {
					HelpInfo = this._getESHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					//oLink = HelpInfo._oLink;
				} else if (AuthoriedType === "PSLE") {
					HelpInfo = this._getPSLEHelpText();
					sHtmlText = HelpInfo._oHtmlText;
					//	oLink = HelpInfo._oLink;
				}

			var oFTV1 = new sap.m.FormattedText();
			oFTV1.setHtmlText(sHtmlText);
			//	oFTV1.addControl(oLink);
			//	oFTV1.addControl(oLink1);

			var Information = oBundle.getText("infor");
			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.information(
				oFTV1, {
					title: Information,
					icon: sap.m.MessageBox.Icon.INFORMATION,
					actions: [sap.m.MessageBox.Action.YES]
				});
				*/
			},
		onDelete: function () {  
			/* var requestView = this.getView().getContent()[0].getPages()[0].getContent()[0];
			var requestTable = requestView.getContent()[0].getContent()[0];
			var selectedCotexts = requestTable.getSelectedContexts();
			var countOfSelected = selectedCotexts.length;
			var RequestIdSet = [];
			for (var i = 0; i < countOfSelected; i++) {
				var selectedRquestStatus = requestTable.getSelectedItems()[i].getCells()[5].getText();
				if (selectedRquestStatus === "In Process") {
					return this._alertDeleteInprocess();
				}
				var RequestsPath = selectedCotexts[i].sPath;
				var RequestId = RequestsPath.substring(RequestsPath.indexOf("'"), RequestsPath.indexOf(")"));
				RequestIdSet.push(RequestId);
			}*/ 
			var RequestIdSet = this.getSelectedRequests();
			var that = this;
			var i18nModel = this.geti18nModel();
			var Delete = i18nModel.getResourceBundle().getText("deleteDialogTitle");
			var alertTitle = i18nModel.getResourceBundle().getText("alert");
			if (RequestIdSet.length !== 0) {
				var vMessage = i18nModel.getResourceBundle().getText("comfirm2");
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.information(
					vMessage, {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: Delete,
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === "YES") {
								that.deleteReportItem(RequestIdSet);
							}
						}
					});
			} else {
				var eMessage = i18nModel.getResourceBundle().getText("noOneSelected");
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.information(
					eMessage, {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: alertTitle,
						actions: [sap.m.MessageBox.Action.OK]
					});
			}
		},

		getSelectedRequests: function () {
			var requestView = this.getView().getContent()[0].getPages()[0].getContent()[0];
			var requestTable = requestView.getContent()[0].getContent()[0];
			var selectedCotexts = requestTable.getSelectedContexts();
			var countOfSelected = selectedCotexts.length;
			var RequestIdSet = [];
			for (var i = 0; i < countOfSelected; i++) {
				var selectedRquestStatus = requestTable.getSelectedItems()[i].getCells()[5].getText();
				if (selectedRquestStatus === "In Process") {
					return this._alertDeleteInprocess();
				}
				var RequestsPath = selectedCotexts[i].sPath;
				var RequestId = RequestsPath.substring(RequestsPath.indexOf("'"), RequestsPath.indexOf(")"));
				RequestIdSet.push(RequestId);
			}
			return RequestIdSet;
		},

		setRequestIdToString: function (aRequestID) {
			var sRequestID = "";
			if (aRequestID.length !== 0 & aRequestID.length < 10 || aRequestID.length === 10) {

				for (var i = 0; i < aRequestID.length; i++) {
					sRequestID = sRequestID + aRequestID[i].substr(1, 25) + ";";
				}
				return sRequestID;
			} else if (aRequestID.length !== 0 & aRequestID.length > 10) {
				MessageBox.warning(
					this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("warningSelectedMT10"), {
						icon: sap.m.MessageBox.Icon.WARNING,
						actions: [sap.m.MessageBox.Action.YES]
					});
			} else if (aRequestID.length === 0) {
				MessageBox.warning(
					this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("warningSelectedAL1"), {
						icon: sap.m.MessageBox.Icon.WARNING,
						actions: [sap.m.MessageBox.Action.YES]
					});
			}
		},
		
		callPopupToStopCopyCloudReport: function(){
			MessageBox.warning(
				this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("forbidCopyCLD"), {
					icon: sap.m.MessageBox.Icon.WARNING,
					actions: [sap.m.MessageBox.Action.OK]
				});
		},
		
		checkSelectedReportType: function () {
			var requestView = this.getView().getContent()[0].getPages()[0].getContent()[0];
			var requestTable = requestView.getContent()[0].getContent()[0];
			for (var i = 0; i < requestTable.getSelectedItems().length; i++) {
				if (requestTable.getSelectedItems()[i].getCells()[0].getItems()[0].getText().indexOf("Cloud") !== -1) {
					this.callPopupToStopCopyCloudReport();
					return false;
				}
				if (requestTable.getSelectedItems()[i].getCells()[0].getItems()[0].getText().indexOf("BusinessObjects") !== -1) {
					this.callPopupToStopCreatedByCopy();
					return false;
				}
			}
			return true;
		},

		_createAsCopy: function (sRequestID) {
			var oData = {};
			oData.Request_Again = sRequestID;
			var url = "/services/odata/svt/esr_srv";
			var m = new sap.ui.model.odata.v2.ODataModel(url);
			m.setUseBatch(false);
			m.create("/ESR_REQUESTSet", oData, {
				success: function () {
					this.autoRefresh();
					MessageToast.show(this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("requestSuccess"));
				}.bind(this),
				error: function () {
					this.autoRefresh();
				}.bind(this)
			});
		},
		
		callPopupToStopCreatedByCopy: function () {
			var oi18nModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			MessageBox.warning(
				oi18nModel.getText("forbidCopyOldRequest1_1") + oi18nModel.getText("forbidCopyOldRequest1_2") + "\n\n" + oi18nModel.getText(
					"forbidCopyOldRequest2"), {
					icon: sap.m.MessageBox.Icon.WARNING,
					actions: [sap.m.MessageBox.Action.OK]
				});
		},

		checkSelectedReportCreatedTime: function () {
			var requestView = this.getView().getContent()[0].getPages()[0].getContent()[0];
			var requestTable = requestView.getContent()[0].getContent()[0];
			for (var i = 0; i < requestTable.getSelectedItems().length; i++) {
				var aCreatedTime = requestTable.getSelectedItems()[i].getCells()[2].getText().substr(0, 10).split(".");
				var sCreatedTime = aCreatedTime[2] + aCreatedTime[1] + aCreatedTime[0];
				if (sCreatedTime < "20190319") {
					this.callPopupToStopCreatedByCopy();
					return false; // Can't be requested again
				}
			}
			return true;
		},
		onRequestAgain: function () {
			var aRequestID = this.getSelectedRequests();
			var sRequestID = this.setRequestIdToString(aRequestID);
			if (aRequestID.length === 0) {
				return;
			}
			/*-------forbid copy cloud report and ESB Report-------*/
			if (this.checkSelectedReportType()) {
				//Check copy request is created after 20190319
				if (this.checkSelectedReportCreatedTime()) {
					// Check Downtime
					if (this._CheckOnpremisDowntime(sRequestID) === "true") {
						this._createAsCopy(sRequestID);
					}
				}
			} 
		},

		_alertDeleteInprocess: function () {
			var i18nModel = this.geti18nModel();
			var vMessage = i18nModel.getResourceBundle().getText("alertInporcessDelete");
			var Delete = i18nModel.getResourceBundle().getText("deleteDialogTitle");

			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.information(
				vMessage, {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: Delete,
					actions: [sap.m.MessageBox.Action.YES]
				});
		},

		deleteReportItem: function (RequestIdSet) {
			for (var i = 0; i < RequestIdSet.length; i++) {
				var that = this;
				var url = "/services/odata/svt/esr_srv";
				var m = new sap.ui.model.odata.v2.ODataModel(url);
				m.setUseBatch(false);
				m.remove("/ESR_REQUESTSet" + "(RequestId=" + RequestIdSet[i] + ")", {
					success: function () {
						that.autoRefresh();
						that.messagetoastForDeleteSuccess();
					},
					error: function () {
						that.autoRefresh();
					}
				});
			}
		},

		messagetoastForDeleteSuccess: function () {
			var i18nModel = this.geti18nModel();
			var msg = i18nModel.getResourceBundle().getText("messageOfDeleteSuccess");
			MessageToast.show(msg);
		},

		_getESHelpText: function () {
			var i18nModel = this.geti18nModel();
			var oBundle = i18nModel.getResourceBundle();
			var sHtmlText;
			//var oLink;
			var href1 = "https:" + "//launchpad.support" + ".sap.com/#/incident/create";
			sHtmlText = "<span class='myCustomHelpDialog'>" + oBundle.getText("helpTitle_ESR") + "</span><br><br>";
			sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine1_ESR_PSLE") + "</span><br>";
			sHtmlText += "<li>" + oBundle.getText("helpTip1_ESR_PSLE_1") + "<a href='" + href1 + "'>" + "&nbsp;" + oBundle.getText(
				"helpTip1_ESR_PSLE_2") + "&nbsp;" + "</a>" + oBundle.getText("helpTip1_ESR_PSLE_3") + "</li><br>";
			sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine2_ESR_PSLE") + "</span><br>";
			sHtmlText += "<li>" + oBundle.getText("helpTip2_ESR") + "</li>";

			/*oLink = new Link({
				text: oBundle.getText("helpTip1_ESR_PSLE_2"),
				href: href1,
				target: "_blank"
			});*/
			return {
				_oHtmlText: sHtmlText
					//_oLink: oLink
			};
		},
		_getPSLEHelpText: function () {
			var i18nModel = this.geti18nModel();
			var oBundle = i18nModel.getResourceBundle();
			var sHtmlText;
			//var oLink;
			var href1 = "https:" + "//launchpad.support" + ".sap.com/#/incident/create";
			sHtmlText = "<span class='myCustomHelpDialog'>" + oBundle.getText("helpTitle_PSLE") + "</span><br><br>";

			sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine1_ESR_PSLE") + "</span><br>";
			sHtmlText += "<li>" + oBundle.getText("helpTip1_ESR_PSLE_1") + "<a href='" + href1 + "'>" + "&nbsp;" + oBundle.getText(
					"helpTip1_ESR_PSLE_2") + "&nbsp;" + "</a>" + oBundle.getText("helpTip1_ESR_PSLE_3") +
				"</li><br>";

			sHtmlText += "<span class='sapUiFTVBold' >" + oBundle.getText("helpLine2_ESR_PSLE") + "</span><br>";
			sHtmlText += "<li>" + oBundle.getText("helpTip2_PSLE") + "</li>";

			/*	oLink = new Link({
					text: oBundle.getText("helpTip1_ESR_PSLE_2"),
					href: href1,
					target: "_blank"
				});*/
			return {
				_oHtmlText: sHtmlText
					//_oLink: oLink
			};
		},
		getAuthorizedType: function () {
			var flag;
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			if (oComp.authorizedES === "true" && oComp.authorizedPSLE === "true") {
				flag = "Both";
			} else if (oComp.authorizedES === "true" && oComp.authorizedPSLE === "false") {
				flag = "ES";
			} else if (oComp.authorizedES === "false" && oComp.authorizedPSLE === "true") {
				flag = "PSLE";
			}
			return flag;
		},

		onCreateNewReport: function (e) {
			if (!this._actionSheet) {
				this._actionSheet = new sap.ui.xmlfragment("sap.support.esrrequest.view.CreatebuttonActionSheet", this);
				this.getView().addDependent(this._actionSheet);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._actionSheet);
			}
			this._actionSheet.openBy(e.getSource());
		},
		_CheckOnpremisDowntime: function (sRequestID) {
			var i18nModel = this.geti18nModel();
			var Warning = i18nModel.getResourceBundle().getText("warning");
			//check down time 
			var reportType = this.getReportType();
			var oModeluserdata;
			if (reportType === "ES") {
				oModeluserdata = this.getUserdata_es();
			} else if (reportType === "PSLE") {
				oModeluserdata = this.getUserdata_psle();
			} else if (reportType === "CLD") {
				oModeluserdata = this.getUserdata_cld();
			} else if (reportType === "ALL") {
				oModeluserdata = this.getUserdata_cld();
			} else if (reportType === "ES_PSLE") {
				oModeluserdata = this.getUserdata_es();
			}
			this.disableNewRequest = oModeluserdata.getData().d.Disable_New_Request; // for judge whther can create one
			// before 7 days 
			var downPopText = oModeluserdata.getData().d.DownPopText;
			var that = this;
			if (downPopText.length !== 0) {
				jQuery.sap.require("sap.m.MessageBox");

				sap.m.MessageBox.warning(
					downPopText, {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: Warning,
						actions: [sap.m.MessageBox.Action.YES],
						onClose: function (oAction) {
							if (sRequestID === undefined) {
								var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
								oRouter.navTo("detail");
							} else {
								that._createAsCopy(sRequestID);
							}
						}
					});
				return;
			}
			// During down time
			var downBottomText = oModeluserdata.getData().d.DownBottomText;
			if (downBottomText.length !== 0) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.warning(
					downBottomText, {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: Warning,
						actions: [sap.m.MessageBox.Action.YES],
						onClose: function (oAction) {
							if (that.disableNewRequest === "") {
								if (sRequestID === undefined) {
									var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
									oRouter.navTo("detail");
								} else {
									that._createAsCopy(sRequestID);
								}
							}
						}
					});
				return;
			}
			var flag = "true";
			return flag;

		},
		onCreateOnpremiseReport: function () {
			var flag = this._CheckOnpremisDowntime();
			if (flag === "true") {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("detail");
			}
		},
		onCreateCLD: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("cloud");
		},
		getUserdata_es: function () {
			var es_userData = this.getOwnerComponent().getModel("Model_userdata_es");
			return es_userData;

		},
		getUserdata_psle: function () {
			var psle_userData = this.getOwnerComponent().getModel("Model_userdata_psle");
			return psle_userData;
		},
		getUserdata_cld: function () {
			var cld_userData = this.getOwnerComponent().getModel("Model_userdata_cld");
			return cld_userData;
		},
		handleRefresh: function () {
			this.getOwnerComponent().getModel("overview").refresh();
		},

		getReportType: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.sReportType;
		},
		/*	getAuthorizedApp: function() {
				var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				return oComp.authorizedApp;
			},*/

		setFristBack: function (val) {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			oComp._firstBack = val;
		},
		setReportType: function (val) {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			oComp.sReportType = val;
		},
		setFristLoadDetail: function (val) {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			oComp._firstLoadDetail = val;
		},
		getSUser: function () {
			var oComp = sap.ui.core.Component.getOwnerComponentFor(this.getView());
			return oComp.sUserID;
		},

		geti18nModel: function () {
			var i18nModel = this.getOwnerComponent().getModel("i18n");
			return i18nModel;
		}
	});
});
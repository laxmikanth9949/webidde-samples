sap.ui.define([], function() {
	"use strict";
	return {

		action: function(status, ReportId) {
			if (status === "1") {
				return "Delete";
			} else if (status === "2") {
				return "";
			} else if (status === "3") {
				return "Open";
			}

		},
		enter: function(str) {
			var i = str.replace(/@@/g, "\r\n");
			return i;
		},
		separateInstToReview: function(str){
			if (str) {
				var formedStr = str.replace(/;/g, "\r\n");
				return formedStr;
			}
		},
		separateInstToOverview: function(str) {
			if (str) {
				//var str = "1;2;3;4;5;6;";
				var patt = new RegExp(";", "g");
				var Index = [];
				var i = 0;
				while ((patt.exec(str)) !== null && i < 2) {
					Index.push(patt.lastIndex);
					i++;
				}
				var head5Str = str.slice(0, Index[i-1] - 1);
				var formedStr = head5Str.replace(/;/g, "\r\n");
				return formedStr;
			}
		},
		getTextVisible: function(str){
			if(str){
				var patt = new RegExp(";", "g");
				var arr = str.match(patt);
				if(arr.length > 2){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		},
		passIntoBool: function(str) {
			if (str === "Select installations") {
				return true;
			} else {
				return false;
			}
		},
		
		determButtonStatus: function(substituted){
			if(substituted === "X"){
				return false;
			}
		}
		
		
	};
});
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/Dialog"
], function(UIComponent, JSONModel, ResourceModel, ODataModel, Dialog) {
	"use strict";

	return UIComponent.extend("sap.support.esrrequest.Component", {
		metadata: {
			manifest: "json"
		},

		init: function() {
			var oConfig = this.getMetadata().getConfig();
			this.sConfig = oConfig;
			// ES report userdata
			var oModel_userdata_es = new JSONModel();
			oModel_userdata_es.loadData(oConfig.requestRemote + "UserDataSet('ES')", {}, false, "GET");
			this.errorMessageOf_es = oModel_userdata_es.getData().d.ErrorMsg;
			this.setModel(oModel_userdata_es, "Model_userdata_es");
			// PSLE report userdata
			var oModel_userdata_psle = new JSONModel();
			oModel_userdata_psle.loadData(oConfig.requestRemote + "UserDataSet('PSLE')", {}, false, "GET");
			this.errorMessageOf_psle = oModel_userdata_psle.getData().d.ErrorMsg;
			this.setModel(oModel_userdata_psle, "Model_userdata_psle");

			//------------------------------------Wave 8 un-Launch------------------------------------------------//
			// Cloud report userdata 
			/* var oModel_userdata_cld = new JSONModel();
			oModel_userdata_cld.loadData(oConfig.requestRemote + "UserDataSet('CLD')", {}, false, "GET");
			this.errorMessageOf_cld = oModel_userdata_cld.getData().d.ErrorMsg;
			this.Authorized_Cld = oModel_userdata_cld.getData().d.Authorized_Cld;
			this.setModel(oModel_userdata_cld, "Model_userdata_cld"); */

			//------------------------------------Wave 8 un-Launch------------------------------------------------//

			UIComponent.prototype.init.apply(this, arguments);
			//--------------------check offered report type authoriaztion---------------------------
			//support type
			var insideUser;
			var substitute;
			this.flagSubmitButton = "true";
			this.authorizedES = "false";
			this.authorizedPSLE = "false";
			this.authorizedCld = "false";
			//cloud report
			if (this.errorMessageOf_es.length === 0) {
				this.authorizedES = "true";
			}
			if (this.errorMessageOf_psle.length === 0) {
				this.authorizedPSLE = "true";
			}
			/* if (this.errorMessageOf_cld.length === 0) {
				this.authorizedCld = "true";
			} */
			//ESR report
			if (this.authorizedES === "true" && this.authorizedPSLE === "false" && this.authorizedCld === "false") {
				this.sReportType = "ES";
				insideUser = oModel_userdata_es.getData().d.Inside_User;
				substitute = oModel_userdata_es.getData().d.Substitute;
				if (substitute !== "" && insideUser === "") {
					this.flagSubmitButton = "false";
				}
				// overview request list model
				this.preSetRequestListModel(oConfig);
				//(languageSET and chapterSET)Model
				this._getESR_ChapterLagModel(oConfig);
			} else if (this.authorizedES === "false" && this.authorizedPSLE === "true" && this.authorizedCld === "false") {
				this.sReportType = "PSLE";
				insideUser = oModel_userdata_psle.getData().d.Inside_User;
				substitute = oModel_userdata_psle.getData().d.Substitute;
				if (substitute !== "" && insideUser === "") {
					this.flagSubmitButton = "false";
				}
				// overview request list model
				this.preSetRequestListModel(oConfig);
				// setModel for Detail view (languageSET and chapterSET)
				this._getPSLE_ChapterLagModel(oConfig);
			} /* else if (this.authorizedES === "false" && this.authorizedPSLE === "false" && this.authorizedCld === "true") {
				this.sReportType = "CLD";
				insideUser = oModel_userdata_cld.getData().d.Inside_User;
				substitute = oModel_userdata_cld.getData().d.Substitute;
				if (substitute !== "" && insideUser === "") {
					this.flagSubmitButton = "false";
				}
				//
				this.preSetRequestListModel(oConfig); 
			} */ else if (this.authorizedES === "false" && this.authorizedPSLE === "false" && this.authorizedCld === "false") {
				// have no authorization
				this.authorizedApp = "false";
				this.sReportType = "";
			}
			// HAVE BOTH ES&PSLE CONTRACT
			else if (this.authorizedES === "true" && this.authorizedPSLE === "true" && this.authorizedCld === "false") {
				this.sReportType = "ES_PSLE";
				insideUser = oModel_userdata_psle.getData().d.Inside_User;
				substitute = oModel_userdata_psle.getData().d.Substitute;
				if (substitute !== "" && insideUser === "") {
					this.flagSubmitButton = "false";
				}
				//
				this.preSetRequestListModel(oConfig);
				this._getESR_ChapterLagModel(oConfig);
				this._getPSLE_ChapterLagModel(oConfig);
			} /* else if (this.authorizedES === "true" || this.authorizedPSLE === "true" && this.authorizedCld === "true") {
				this.sReportType = "ALL";
				insideUser = oModel_userdata_cld.getData().d.Inside_User;
				substitute = oModel_userdata_cld.getData().d.Substitute;
				if (substitute !== "" && insideUser === "") {
					this.flagSubmitButton = "false";
				}
				//
				this.preSetRequestListModel(oConfig);
				if (this.authorizedES === "true") {
					this._getESR_ChapterLagModel(oConfig);
				}
				if (this.authorizedPSLE === "true") {
					this._getPSLE_ChapterLagModel(oConfig);
				}
			} */
			//------------------------------------------------------------------------------
			//HAVE BOTH ESR & CLOUD CONTRACT

			if (this.authorizedApp === "false") {
				var i18nModel = this.getModel("i18n");
				var userErrorDialog = new Dialog({
					title: "{i18n>userError}",
					type: "Message",
					state: "{i18n>userError}",
					content: new sap.m.Text({
						text: "{i18n>userErrorMessage}"
					}),
					endButton: new sap.m.Button({
						text: "{i18n>ok}",
						press: function() {
							userErrorDialog.close();
						}
					})
				});

				userErrorDialog.setModel(i18nModel, "i18n");
				userErrorDialog.open();
				return;
			} /* else if (this.sReportType === "ALL" && this.authorizedES === "true" && this.authorizedPSLE === "true") { // ES PSLE CLD
				this.checkContract = "three";
			} */ else if (this.sReportType.length !== 0 && this.authorizedCld === "false") { // ES OR/AND PSLE 
				this.checkContract = "onPremise";
			} /* else if (this.sReportType === "ALL") { // ES OR PLSE AND CLD
				this.checkContract = "onpremise_Cloud";
			}  else if (this.sReportType === "CLD") { //CLD
				this.checkContract = "cloud";
			}  */
			//----------------------------------------------
			//TriTable Model in selectChapter Dialog
			var oChaptersModel = new JSONModel();
			this.setModel(oChaptersModel, "triChaptersModel");
			//Popover Model for installation
			var oInstModel = new JSONModel();
			this.setModel(oInstModel, "instModel");
			// Detail view installation model
			var installmodel = new ODataModel("/services/odata/svt/esr_srv", {
				useBatch: false
			});
			this.setModel(installmodel, "installationModel");
			
			// create the views based on the url/hash
			this.getRouter().initialize();

			// SHELL HELP
			/*var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish('shell', 'message', {
			    text : 'Please enter your search term to the search field.',
			    type : 0
			});*/
			/*var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish('shell', 'help', {
				items : [
					{
						anchoredControl : this.createId('helpButton'),
					    text : 'Please enter your search term to the search field.'
					}
				]
			});*/
		},
		
		preSetRequestListModel: function(oConfig) {
			//pre_set requestList OverviewModel
			var oRequestModel = new ODataModel(oConfig.requestRemote);
			oRequestModel.setUseBatch(false);
			this.setModel(oRequestModel, "overview");
			//model count in the tabbar
			var countModel = new JSONModel();
			this.setModel(countModel, "count");

			oRequestModel.attachRequestCompleted(function(oData, oResponse) {
				var oDataReq = oRequestModel.oData;
				var aKeys = Object.keys(oDataReq);
				if (aKeys.length !== 0) {
					for (var i = 0; i < aKeys.length; i++) {
						if (aKeys[i].substr(0, 1) === "E") {
							var obj = oDataReq[aKeys[i]];
							countModel.setData(obj);
							break;
						}
					}
					/*	if (aKeys[0].substr(0, 1) === "E") {
							var obj = oDataReq[aKeys[0]];
							countModel.setData(obj);
						}else if(aKeys[0].substr(0, 1) === "C" && aKeys.length > 4){
							var obj = oDataReq[aKeys[4]];
							countModel.setData(obj);
						}*/
				}
			}, this);
		},
		_getESR_ChapterLagModel: function(oConfig) {
			var oModel_es1 = new JSONModel();
			oModel_es1.loadData(oConfig.requestRemote + "ReportSet(ReportId='ES1',ReportLangu='E')?$expand=LanguageSet,ChapterSet", {}, false,
				"GET");
			this.setModel(oModel_es1, "oModel_es1");

			var oModel_esb = new JSONModel();
			oModel_esb.loadData(oConfig.requestRemote + "ReportSet(ReportId='ESB',ReportLangu='E')?$expand=LanguageSet,ChapterSet", {}, false,
				"GET");
			this.setModel(oModel_esb, "oModel_esb");
		},
		_getPSLE_ChapterLagModel: function(oConfig) {
			var oModel_psl = new JSONModel();
			oModel_psl.loadData(oConfig.requestRemote + "ReportSet(ReportId='PSL',ReportLangu='E')?$expand=LanguageSet,ChapterSet", {}, false,
				"GET");
			this.setModel(oModel_psl, "oModel_psl");
		}

	});

});
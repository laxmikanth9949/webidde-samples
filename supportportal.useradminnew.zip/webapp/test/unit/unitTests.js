sap.ui.define([
	"test/unit/model/Util.test",
	"test/unit/model/Formatter.test",
	"test/unit/util/DetailUtil.test"
], function() {
	"use strict";	
});
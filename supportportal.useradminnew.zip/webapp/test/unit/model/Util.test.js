sap.ui.require([
	"test/unit/TestUtil",
	"sap/support/useradministration/util/Util",
	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function (TestUtil, Util) {
	"use strict";
	
	QUnit.module("Util: Strings");
	
	QUnit.test("normalizeCustomerNumber: normalize customer number to 10-char length via leading zeros", function(assert) {
		TestUtil.strictEqualMassTest(assert, Util.normalizeCustomerNumber, [
			{arg: null, value: "0000000000"},
			{arg: "0", value: "0000000000"},
			{arg: "7", value: "0000000007"},
			{arg: "202191", value: "0000202191"},
			{arg: "901923211", value: "0901923211"},
			{arg: "8819832221", value: "8819832221"}
		]);
	});
});
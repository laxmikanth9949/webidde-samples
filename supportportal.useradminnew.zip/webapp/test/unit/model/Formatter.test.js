sap.ui.require([
	"sap/support/useradministration/model/Formatter",
	"sap/support/useradministration/util/Util",
	"test/unit/TestUtil",
	
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function (Formatter, Util, TestUtil, DateFormat, ResourceModel) {
	"use strict";
	
	var ListMode = sap.m.ListMode,
		ListType = sap.m.ListType,
		ValueState = sap.ui.core.ValueState;
	
	var _oMediumDateFormat = DateFormat.getDateInstance({
			style: "medium"
		});
	var _oShortDateFormat = DateFormat.getDateInstance({
			pattern: "dd.MM.yyyy",
			UTC: true
		});
	
	// Cache i18n model to run tests faster
	var _oResourceModel = new ResourceModel({
		bundleUrl : jQuery.sap.getModulePath("sap.support.useradministration", "/i18n/messageBundle.properties")
	});
	
	QUnit.module("Formatter: Authorizations", {
		setup: function () {
			this._oResourceModel = _oResourceModel;
			this._oBundle = this._oResourceModel.getResourceBundle();
			this._oView = {
				getModel: sinon.stub().withArgs("i18n").returns(this._oResourceModel)
			};
		}
	});
	
	QUnit.test("detail.authorizationHasDetails: check if authorization has a detail assign", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.authorizationHasDetails, [
			{arg: "DEBITOR", value: true},
			{arg: "GLOBAL", value: false},
			{arg: "group", value: false},
			{arg: "INSTALL", value: true},
			{arg: "USER", value: true}
		]);
	});
	
	QUnit.test("detail.authorizationLevel: get authorization level", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.authorizationLevel, [
			{arg: "G_ALL", value: "Top"},
			{arg: "G_GRP", value: "Group"},
			{arg: "G_INSTALL", value: "Group"},
			{arg: "ABC", value: "None"},
			{arg: "", value: "None"}
		]);
	});
	
	QUnit.test("detail.authorizationListItemType: get authorization list item type - Navigation for non-group items", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.authorizationListItemType, [
			{arg: "DEBITOR", value: ListType.Navigation},
			{arg: "GLOBAL", value: ListType.Inactive},
			{arg: "group", value: ListType.Inactive},
			{arg: "INSTALL", value: ListType.Navigation},
			{arg: "USER", value: ListType.Navigation}
		]);
	}); 
	
	QUnit.test("detail.authorizationPackageEdit: get editable state for authorization package", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.authorizationPackageEdit, [
			{args: [false, false], name: "Not protected and button not enabled", value: false},
			{args: [false, true], name: "Not protected and button enabled", value: false},
			{args: [true, false], name: "Protected and button not enabled", value: false},
			{args: [true, true], name: "Protected and button enabled", value: true}
		]);
	});
	
	QUnit.test("detail.authorizationStatus: get status text for authorization", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.authorizationStatus.bind(this._oView), [
			{args: ["", "CCC", "CCC"], value: ""},
			{args: ["", "DEBITOR", "DEBITOR"], value: ""},
			{args: ["", "GLOBAL", "GLOBAL"], value: ""},
			//{args: ["", "INSTALL", "INSTALL"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4INST_ONLY_TEXT")},
			{args: ["", "USER", "USER"], value: ""},
			{args: ["", "CCC", "DEBITOR"], value: ""},
			{args: ["", "DEBITOR", "INSTALL"], value: ""},
			{args: ["", "GLOBAL", "DEBITOR"], value: ""},
			{args: ["", "INSTALL", "DEBITOR"], value: ""},
			{args: ["", "USER", "DEBITOR"], value: ""},
			{args: ["none", "CCC", "CCC"], value: ""},
			{args: ["none", "DEBITOR", "DEBITOR"], value: ""},
			{args: ["none", "GLOBAL", "GLOBAL"], value: ""},
			//{args: ["none", "INSTALL", "INSTALL"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4INST_ONLY_TEXT")},
			{args: ["none", "USER", "USER"], value: ""},
			{args: ["none", "CCC", "DEBITOR"], value: ""},
			{args: ["none", "DEBITOR", "INSTALL"], value: ""},
			{args: ["none", "GLOBAL", "DEBITOR"], value: ""},
			{args: ["none", "INSTALL", "DEBITOR"], value: ""},
			{args: ["none", "USER", "DEBITOR"], value: ""},
			{args: ["full", "INSTALL", "INSTALL"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4INST_ONLY_TEXT")},
			{args: ["full", "CCC", "CCC"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4INST_TEXT")},
			{args: ["full", "DEBITOR", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4CUST_TEXT")},
			{args: ["full", "GLOBAL", "GLOBAL"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4CUST_TEXT")},
			{args: ["full", "USER", "USER"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4USER_TEXT")},
			{args: ["full", "CCC", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4INST_TEXT")},
			{args: ["full", "DEBITOR", "INSTALL"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4CUST_TEXT")},
			{args: ["full", "GLOBAL", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4CUST_TEXT")},
			{args: ["full", "INSTALL", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4INST_TEXT")},
			{args: ["full", "USER", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4USER_TEXT")},
			{args: ["restricted", "CCC", "CCC"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4INST_TEXT")},
			{args: ["restricted", "DEBITOR", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4CUST_TEXT")},
			{args: ["restricted", "GLOBAL", "GLOBAL"], value: ""},
			{args: ["restricted", "INSTALL", "INSTALL"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4INST_ONLY_TEXT")},
			{args: ["restricted", "USER", "USER"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4USER_TEXT")},
			{args: ["restricted", "CCC", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4INST_TEXT")},
			{args: ["restricted", "DEBITOR", "INSTALL"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4CUST_TEXT")},
			{args: ["restricted", "GLOBAL", "DEBITOR"], value: ""},
			{args: ["restricted", "INSTALL", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4INST_TEXT")},
			{args: ["restricted", "USER", "DEBITOR"], value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4USER_TEXT")}
		]);
	});
	
	QUnit.test("detail.authorizationValueFormat: remove leading zeros if authorization type is not INSTALL", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.authorizationValueFormat, [
			{args: ["32032000", "DEBITOR"], value: "32032000"},
			{args: ["00048000", "DEBITOR"], value: "48000"},
			{args: ["000003142", "DEBITOR"], value: "3142"},
			{args: ["09998", "CCOE"], value: "9998"},
			{args: ["00004923", "INSTALL"], value: "00004923"},
			{args: ["3283210000", "INSTALL"], value: "3283210000"}
		]);
	}); 
	
	QUnit.test("detail.canSwitchFullAuth: check if full authorization can be assigned for authorization object", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.canSwitchFullAuth, [
			{arg: "CCC", name: "Top level CCoE", value: true},
			{arg: "DEBITOR", name: "Top level Customer", value: true},
			{arg: "GLOBAL", name: "Top level Global", value: true},
			{arg: "INSTALL", name: "Top level Installation", value: false},
			{arg: "USER", name: "Top level User", value: false},
			{arg: "", name: "Top level empty", value: false}
		]);
	}); 
	
	QUnit.test("detail.cloudAuthorizationListItemType: get list item type for user's cloud authorizations list", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.cloudAuthorizationListItemType, [
			{arg: true, name: "Global flag set", value: ListType.Inactive},
			{arg: false, name: "Global flag not set", value: ListType.Navigation}
		]);
	});
	
	QUnit.test("detail.copyLevelsButtonVisible: check if Copy Levels should be visible", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.copyLevelsButtonVisible, [
			{args: ["none", "DEBITOR"], value: false},
			{args: ["none", "GLOBAL"], value: false},
			{args: ["none", "group"], value: false},
			{args: ["none", "INSTALL"], value: false},
			{args: ["none", "USER"], value: false},
			{args: ["full", "DEBITOR"], value: true},
			{args: ["full", "GLOBAL"], value: false},
			{args: ["full", "group"], value: false},
			{args: ["full", "INSTALL"], value: true},
			{args: ["full", "USER"], value: false},
			{args: ["restricted", "DEBITOR"], value: true},
			{args: ["restricted", "GLOBAL"], value: false},
			{args: ["restricted", "group"], value: false},
			{args: ["restricted", "INSTALL"], value: true},
			{args: ["restricted", "USER"], value: false},
			{args: ["none", "DEBITOR", true], value: false},
			{args: ["none", "GLOBAL", true], value: false},
			{args: ["none", "group", true], value: false},
			{args: ["none", "INSTALL", true], value: false},
			{args: ["none", "USER", true], value: false},
			{args: ["full", "DEBITOR", true], value: false},
			{args: ["full", "GLOBAL", true], value: false},
			{args: ["full", "group", true], value: false},
			{args: ["full", "INSTALL", true], value: false},
			{args: ["full", "USER", true], value: false},
			{args: ["restricted", "DEBITOR", true], value: false},
			{args: ["restricted", "GLOBAL", true], value: false},
			{args: ["restricted", "group", true], value: false},
			{args: ["restricted", "INSTALL", true], value: false},
			{args: ["restricted", "USER", true], value: false}
		]);
	}); 
	
	QUnit.test("detail.copyLevelsLocalButtonVisible: check if Copy Levels should be visible in local edit", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.copyLevelsLocalButtonVisible, [
			{args: [false, false, "DEBITOR"], name: "Not edit mode", value: false},
			{args: [false, false, "GLOBAL"], name: "Not edit mode", value: false},
			{args: [false, false, "group"], name: "Not edit mode", value: false},
			{args: [false, false, "INSTALL"], name: "Not edit mode", value: false},
			{args: [false, false, "USER"], name: "Not edit mode", value: false},
			{args: [false, true, "DEBITOR"], name: "Not edit mode", value: false},
			{args: [false, true, "GLOBAL"], name: "Not edit mode", value: false},
			{args: [false, true, "group"], name: "Not edit mode", value: false},
			{args: [false, true, "INSTALL"], name: "Not edit mode", value: false},
			{args: [false, true, "USER"], name: "Not edit mode", value: false},
			{args: [true, false, "DEBITOR"], name: "Edit mode but not selected auth", value: false},
			{args: [true, false, "GLOBAL"], name: "Edit mode but not selected auth", value: false},
			{args: [true, false, "group"], name: "Edit mode but not selected auth", value: false},
			{args: [true, false, "INSTALL"], name: "Edit mode but not selected auth", value: false},
			{args: [true, false, "USER"], name: "Edit mode but not selected auth", value: false},
			{args: [true, true, "DEBITOR"], name: "Selected in edit mode, customer level", value: true},
			{args: [true, true, "GLOBAL"], name: "Selected in edit mode, global level", value: false},
			{args: [true, true, "group"], name: "Selected in edit mode, group level", value: false},
			{args: [true, true, "INSTALL"], name: "Selected in edit mode, installation level", value: true},
			{args: [true, true, "USER"], name: "Selected in edit mode, user level", value: true}
		]);
	});
	
	QUnit.test("detail.existingAuthorizationListItemType: get list item type (Inactive/Navigation) for user's Existing Authorization list item", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.existingAuthorizationListItemType, [
			{args: ["GLOBAL", "INSTALL", false], value: ListType.Inactive},
			{args: ["GLOBAL", "GLOBAL", false], value: ListType.Inactive},
			{args: ["GLOBAL", "GLOBAL", true], value: ListType.Inactive},
			{args: ["GLOBAL", "DEBITOR", true], value: ListType.Inactive},
			{args: ["group", "DEBITOR", false], value: ListType.Inactive},
			{args: ["group", "GLOBAL", false], value: ListType.Inactive},
			{args: ["group", "GLOBAL", true], value: ListType.Inactive},
			{args: ["group", "INSTALL", true], value: ListType.Inactive},
			{args: ["INSTALL", "GLOBAL", false], value: ListType.Inactive},
			{args: ["DEBITOR", "DEBITOR", true], value: ListType.Inactive},
			{args: ["DEBITOR", "GLOBAL", false], value: ListType.Inactive},
			{args: ["INSTALL", "DEBITOR", true], value: ListType.Inactive},
			{args: ["INSTALL", "INSTALL", false], value: ListType.Navigation},
			{args: ["DEBITOR", "INSTALL", false], value: ListType.Navigation},
			{args: ["DEBITOR", "DEBITOR", false], value: ListType.Navigation},
			{args: ["DEBITOR", "DEBITOR"], value: ListType.Navigation}
		]);
	});
	
	QUnit.test("detail.installationsDialogTitle: get title for dialog to select restricted installations or users", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.installationsDialogTitle.bind(this._oView), [
			{arg: true, name: "User Mode", value: this._oBundle.getText("AUTH_OBJ_USER_LEVEL_MULTIPLE")},
			{arg: false, name: "Installation Mode", value: this._oBundle.getText("AUTH_OBJ_INST_LEVEL_MULTIPLE")}
		]);
	}); 
	
	QUnit.test("detail.installationsTableTitle: get title for table showing restricted installations or users", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.installationsTableTitle.bind(this._oView), [
			{arg: "DEBITOR", name: "Customer level", value: ""},
			{arg: "GLOBAL", name: "Global level", value: ""},
			{arg: "group", name: "Group level", value: ""},
			{arg: "INSTALL", name: "Installation Mode", value: this._oBundle.getText("AUTH_OBJ_INST_LEVEL_TITLE")},
			{arg: "USER", name: "User Mode", value: this._oBundle.getText("AUTH_OBJ_USER_LEVEL_TITLE")}
		]);
	});
	
	QUnit.test("detail.isAuthAllGranted: check if authorization granted for all (according to backend data)", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isAuthAllGranted, [
			{arg: "full", name: "Full Auhtorization Level", value: true},
			{arg: "", name: "Empty Auhtorization Level", value: false},
			{arg: "none", name: "None Auhtorization Level", value: false},
			{arg: "restricted", name: "Restricted Auhtorization Level", value: false}
		]);
	});
	
	QUnit.test("detail.isAuthorizationSelected: check if authorization's checkbox is selected (according to backend data)", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isAuthorizationSelected, [
			{arg: "full", name: "Full Auhtorization Level", value: true},
			{arg: "", name: "Empty Auhtorization Level", value: false},
			{arg: "none", name: "None Auhtorization Level", value: false},
			{arg: "restricted", name: "Restricted Auhtorization Level", value: true}
		]);
	});
	
	QUnit.test("detail.isAuthTopLevelCCC: check if authorization's top level is CCCoE", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isAuthTopLevelCCC, [
			{arg: "CCC", name: "CCoE top level", value: true},
			{arg: "DEBITOR", name: "Customer top level", value: false},
			{arg: "GLOBAL", name: "Global top level", value: false}
		]);
	});
	
	QUnit.test("detail.isAuthTopLevelGlobal: check if authorization's top level is Global", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isAuthTopLevelGlobal, [
			{arg: "CCC", name: "CCoE top level", value: false},
			{arg: "DEBITOR", name: "Customer top level", value: false},
			{arg: "GLOBAL", name: "Global top level", value: true}
		]);
	});
	
	QUnit.test("detail.isCloudAuthAdmin: check if authorization is Cloud Admin Authorization", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isCloudAuthAdmin, [
			{arg: "CL_ADMIN", value: true},
			{arg: "cl_admin", value: false},
			{arg: "CLOUD_ADMIN", value: false},
			{arg: "", value: false}
		]);
	});
	
	QUnit.test("detail.isCloudAuthSelected: check if cloud authorization's checkbox is selected (according to backend data)", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isCloudAuthSelected, [
			{arg: "full", name: "Full Global Flag", value: true},
			{arg: "", name: "Empty Global Flag", value: false},
			{arg: "none", name: "None Global Flag", value: false},
			{arg: "restricted", name: "Restricted Global Flag", value: true}
		]);
	});
	
	QUnit.test("detail.isClusterLevel: filter if authorization level type is CLUSTER", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isClusterLevel, [
			{arg: { AuthLevelType: "CLUSTER" }, value: true},
			{arg: { AuthLevelType: "CUSTOMER" }, value: false},
			{arg: { AuthLevelType: "DEBITOR" }, value: false},
			{arg: { AuthLevelType: "INSTALL" }, value: false},
			{arg: { AuthLevelType: "NONDEBITOR" }, value: false},
			{arg: { AuthLevelType: "USER" }, value: false},
			{arg: { AuthLevelType: "" }, value: false},
			{arg: {}, value: false}
		]);
	});
	
	QUnit.test("detail.isInstallationsTableVisible: check if Installations table should be visible", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isInstallationsTableVisible, [
			{arg: "DEBITOR", name: "Customer level", value: false},
			{arg: "GLOBAL", name: "Global level", value: false},
			{arg: "group", name: "Group level", value: false},
			{arg: "INSTALL", name: "Installation level", value: true},
			{arg: "USER", name: "User level", value: true}
		]);
	});
	
	QUnit.test("detail.isCustomerLevel: filter if authorization level type is Customer", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isCustomerLevel, [
			{arg: { AuthLevelType: "CLUSTER" }, value: false},
			{arg: { AuthLevelType: "CUSTOMER" }, value: true},
			{arg: { AuthLevelType: "DEBITOR" }, value: true},
			{arg: { AuthLevelType: "INSTALL" }, value: false},
			{arg: { AuthLevelType: "NONDEBITOR" }, value: false},
			{arg: { AuthLevelType: "USER" }, value: false},
			{arg: { AuthLevelType: "" }, value: false},
			{arg: {}, value: false}
		]);
	});
	
	QUnit.test("detail.isInstallationOrUserLevel: filter if authorization level type is Installation or User", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.isInstallationOrUserLevel, [
			{arg: { AuthLevelType: "CLUSTER" }, value: false},
			{arg: { AuthLevelType: "CUSTOMER" }, value: false},
			{arg: { AuthLevelType: "DEBITOR" }, value: false},
			{arg: { AuthLevelType: "INSTALL" }, value: true},
			{arg: { AuthLevelType: "NONDEBITOR" }, value: false},
			{arg: { AuthLevelType: "USER" }, value: true},
			{arg: { AuthLevelType: "" }, value: false},
			{arg: {}, value: false}
		]);
	}); 
	
	QUnit.test("detail.fullAuthSwitchText: get text for Granted for All authorization switch", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.fullAuthSwitchText.bind(this._oView), [
			{arg: "DEBITOR", name: "Customer level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4CUST_TEXT")},
			{arg: "INSTALL", name: "Installation level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4INST_TEXT")},
			{arg: "USER", name: "User level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4USER_TEXT")},
			{arg: "GLOBAL", name: "Global level", value: ""},
			{arg: "group", name: "Group level", value: ""},
			{arg: "", name: "Empty", value: ""}
		]);
	});
	
	QUnit.test("detail.listSelectionMode: get selection mode for list", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.listSelectionMode, [
			{args: [true, true], value: ListMode.None},
			{args: [true, false], value: ListMode.MultiSelect},
			{args: [false, true], value: ListMode.None},
			{args: [false, false], value: ListMode.None}
		]);
	});
	
	QUnit.test("master.authorizationStatusText: get status text for authorization in Mass Authorization assign dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.authorizationStatusText.bind(this._oView), [
			{args: [false, false, "DEBITOR", false], name: "Not selected for adding - Customer level", value: ""},
			{args: [false, false, "GLOBAL", false], name: "Not selected for adding - Global level", value: ""},
			{args: [false, false, "INSTALL", false], name: "Not selected for adding - Installation level", value: ""},
			{args: [false, false, "USER", false], name: "Not selected for adding - User level", value: ""},
			{args: [false, false, "DEBITOR", true], name: "Not selected for removing - Customer level", value: ""},
			{args: [false, false, "GLOBAL", true], name: "Not selected for removing - Global level", value: ""},
			{args: [false, false, "INSTALL", true], name: "Not selected for removing - Installation level", value: ""},
			{args: [false, false, "USER", true], name: "Not selected for removing - User level", value: ""},
			{args: [false, true, "DEBITOR", false], name: "Restricted for some levels - Customer level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4CUST_TEXT")},
			{args: [false, true, "INSTALL", false], name: "Restricted for some levels - Installation level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4INST_TEXT")},
			{args: [false, true, "USER", false], name: "Restricted for some levels - User level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_REST4USER_TEXT")},
			{args: [false, true, "DEBITOR", true], name: "Removed from some levels - Customer level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_REST4CUST_TEXT")},
			{args: [false, true, "INSTALL", true], name: "Removed from some levels - Installation level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_REST4INST_TEXT")},
			{args: [false, true, "USER", true], name: "Removed from some levels - User level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_REST4USER_TEXT")},
			{args: [true, false, "DEBITOR", false], name: "Granted for all - Customer level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4CUST_TEXT")},
			{args: [true, false, "GLOBAL", false], name: "Granted for all - Global level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4CUST_TEXT")},
			{args: [true, false, "INSTALL", false], name: "Granted for all - Installation level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4INST_TEXT")},
			{args: [true, false, "USER", false], name: "Granted for all - User level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4USER_TEXT")},
			{args: [true, false, "DEBITOR", true], name: "Removed from all - Customer level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_FULL4CUST_TEXT")},
			{args: [true, false, "GLOBAL", true], name: "Removed from all - Global level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_FULL4INST_TEXT")},
			{args: [true, false, "INSTALL", true], name: "Removed from all - Installation level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_FULL4INST_TEXT")},
			{args: [true, false, "USER", true], name: "Removed from all - User level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_FULL4USER_TEXT")}
		]);
	}); 
	
	QUnit.test("master.fullAuthSwitchText: get text for Granted for All authorization switch in Mass add/delete Authorizations dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.fullAuthSwitchText.bind(this._oView), [
			{args: ["DEBITOR", true], name: "Remove all on Customer level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_FULL4CUST_TEXT")},
			{args: ["INSTALL", true], name: "Remove all on Installation level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_FULL4INST_TEXT")},
			{args: ["USER", true], name: "Remove all on User level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_NO_FULL4USER_TEXT")},
			{args: ["DEBITOR", false], name: "Grant all on Customer level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4CUST_TEXT")},
			{args: ["INSTALL", false], name: "Grant all on Installation level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4INST_TEXT")},
			{args: ["USER", false], name: "Grant all on User level", value: this._oBundle.getText("AUTH_OBJ_SWITCH_FULL4USER_TEXT")},
			{args: ["", true], name: "Empty", value: ""},
			{args: ["", false], name: "Empty", value: ""}
		]);
	});
	
	QUnit.test("master.isAuthWithLowLevel: check if authorization has a low-level assign", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.isAuthWithLowLevel, [
			{arg: "DEBITOR", name: "Customer level authorization", value: true},
			{arg: "GLOBAL", name: "Global level authorization", value: false},
			{arg: "group", name: "Group level authorization", value: false},
			{arg: "INSTALL", name: "Installation level authorization", value: true},
			{arg: "USER", name: "User level authorization", value: true}
		]);
	});
	
	QUnit.module("Formatter: Basic");
	
	QUnit.test("isAnyTrue: get true if any argument is true", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.isAnyTrue, [
			{args: [], value: false},
			{args: [0, null, false], value: false},
			{args: [true, "a", {}], value: true},
			{args: ["a", "", 0], value: true},
			{args: [undefined], value: false}
		]);
	});
	
	QUnit.test("isFalse: get true if value is false-like", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.isFalse, [
			{args: [], value: true},
			{arg: 0, value: true},
			{arg: "a", value: false},
			{arg: "", value: true}
		]);
	});
	
	QUnit.test("isNoneTrue: get true if no one value is true-like", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.isNoneTrue, [
			{args: [], value: true},
			{args: [0], value: true},
			{arg: "a", value: false},
			{args: [0, null, false], value: true},
			{args: [false, null, 1, 0], value: false}
		]);
	});
	
	QUnit.test("isNotEqual: check if values are not strictly equal", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.isNotEqual, [
			{args: [1, 2], value: true},
			{args: [3, 3], value: false},
			{args: [1, "1"], value: true},
			{args: [null, "null"], value: true},
			{args: ["ABC", "ABC"], value: false}
		]);
	});
	
	QUnit.test("isTrue: get true if value is true-like", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.isTrue, [
			{args: [], value: false},
			{args: ["q"], value: true},
			{args: [0], value: false},
			{args: [10], value: true}
		]);
	});
	
	QUnit.test("number: format numeric value", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.number, [
			{args: [0], value: 0},
			{args: [null], value: 0},
			{args: ["1212"], value: 1212},
			{args: [431], value: 431}
		]);
	});
	
	QUnit.module("Formatter: DateTime", {
		setup: function () {
			this._oResourceModel = _oResourceModel;
			this._oBundle = this._oResourceModel.getResourceBundle();
			this._oView = {
				getModel: sinon.stub().withArgs("i18n").returns(this._oResourceModel)
			};
		}
	});

	QUnit.test("dateOrEmpty: format date or return empty string on null/zero date", function(assert) {
		var oFormat = DateFormat.getDateInstance({
				style: "medium"
			}),
			oTestDate = TestUtil.createDate(2017, 5, 12);
		
		TestUtil.strictEqualMassTest(assert, Formatter.dateOrEmpty, [
			{args: [null], value: ""},
			{args: [new Date(0)], value: ""},
			{args: [oTestDate], value: oFormat.format(oTestDate)}
		]);
	});
	
	QUnit.test("dateOrNever: format date or return NEVER on zero date", function(assert) {
		var oTestDate = TestUtil.createDate(2017, 5, 12);
		
		TestUtil.strictEqualMassTest(assert, Formatter.dateOrNever.bind(this._oView), [
			//{arg: null, value: ""},
			{name: "Date(0)", arg: new Date(0), value: this._oBundle.getText("MISC_NEVER")},
			{arg: oTestDate, value: _oShortDateFormat.format(oTestDate)}
		]);
	}); 
	
	QUnit.test("dialog.lastNMonthsFilter: format filter key for last N months filter in User List filter dialog", function(assert) {
		var oClock = sinon.useFakeTimers(TestUtil.createDate(2019, 5, 21).getTime());
		
		TestUtil.strictEqualMassTest(assert, Formatter.dialog.lastNMonthsFilter, [
			{arg: 1, value: "Trdat___GE___2019-04-21"},
			{arg: 3, value: "Trdat___GE___2019-02-21"},
			{arg: 6, value: "Trdat___GE___2018-11-21"},
			{arg: 12, value: "Trdat___GE___2018-05-21"}
		]);
		
		oClock.restore();
	});
	
	QUnit.test("fromBackendDate: format date retrieved from the backend", function(assert) {
		var oTestDate = TestUtil.createDate(2015, 11, 3);
		
		TestUtil.strictEqualMassTest(assert, Formatter.fromBackendDate, [
			{arg: null, value: ""},
			{arg: oTestDate, value: _oMediumDateFormat.format(oTestDate)},
			{arg: "2018-04-11", value: _oMediumDateFormat.format(TestUtil.createDate(2018, 4, 11))},
			{arg: "2010-09-30T10:34:00", value: _oMediumDateFormat.format(TestUtil.createDate(2010, 9, 30))}
		]);
	});
	
	//
	
	QUnit.module("Formatter: Messages & texts", {
		setup: function () {
			this._oResourceModel = _oResourceModel;
			this._oBundle = this._oResourceModel.getResourceBundle();
			this._oView = {
				getModel: sinon.stub().withArgs("i18n").returns(this._oResourceModel)
			};
		}
	});
	
	QUnit.test("detail.allEntriesPerCustomerSelectedMessage: get message if all entries per customer were selected", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.allEntriesPerCustomerSelectedMessage.bind(this._oView), [
			{arg: "000202419", value: this._oBundle.getText("AUTHORIZATION_LEVEL_ALL_ENTRIES_4_CUST") + "202419. " 
				+ this._oBundle.getText("AUTHORIZATION_LEVEL_ALL_ENTRIES_4_CUST2")}
		]);
	});
	
	QUnit.test("detail.userImageTooltip: get tooltip for user image to show critical role", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.userImageTooltip.bind(this._oView), [
			{arg: true, name: "Critical role assigned", value: this._oBundle.getText("TOOLTIP_CRITICAL_ROLE_ASSIGNED")},
			{arg: false, name: "Critical role not assigned", value: this._oBundle.getText("TOOLTIP_NO_CRITICAL_ROLE")}
		]);
	});
	
	QUnit.test("dialog.columnText: get column name by i18n key", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.dialog.columnText.bind(this._oView), [
			{arg: "MASTER_COLUMN_USER_ID", value: this._oBundle.getText("MASTER_COLUMN_USER_ID")},
			{arg: "MASTER_COLUMN_USER_EMAIL", value: this._oBundle.getText("MASTER_COLUMN_USER_EMAIL")},
			{arg: "MASTER_COLUMN_CUST_NAME", value: this._oBundle.getText("MASTER_COLUMN_CUST_NAME")},
			{arg: "MASTER_COLUMN_CUST_NUM", value: this._oBundle.getText("MASTER_COLUMN_CUST_NUM")},
			{arg: "MASTER_COLUMN_USER_CUST_NUM", value: this._oBundle.getText("MASTER_COLUMN_USER_CUST_NUM")},
			{arg: "MASTER_COLUMN_CCC_NAME", value: this._oBundle.getText("MASTER_COLUMN_CCC_NAME")},
			{arg: "MASTER_COLUMN_FUNCTION", value: this._oBundle.getText("MASTER_COLUMN_FUNCTION")},
			{arg: "MASTER_COLUMN_PROD_NAME", value: this._oBundle.getText("MASTER_COLUMN_PROD_NAME")}
		]);
	}); 
	
	QUnit.test("dialog.userListColumnName: get column name by column ID", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.dialog.userListColumnName.bind(this._oView), [
			{arg: "lname", value: this._oBundle.getText("DETAIL_USER_LAST_NAME")},
			{arg: "fname", value: this._oBundle.getText("DETAIL_USER_FIRST_NAME")},
			{arg: "email", value: this._oBundle.getText("MASTER_COLUMN_USER_EMAIL")},
			{arg: "userID", value: this._oBundle.getText("MASTER_COLUMN_USER_ID")},
			{arg: "cust_name", value: this._oBundle.getText("MASTER_COLUMN_CUST_NAME")},
			{arg: "cust_num", value: this._oBundle.getText("MASTER_COLUMN_CUST_NUM")},
			{arg: "country", value: this._oBundle.getText("DETAIL_USER_CONTACT_LAND1_REGION")},
			{arg: "department", value: this._oBundle.getText("MASTER_COLUMN_DEPT")},
			{arg: "logon_date", value: this._oBundle.getText("DETAIL_USER_LAST_LOGON_DATE")},
			{arg: "created_by", value: this._oBundle.getText("REQUESTED_USER_REQUESTER_NAME")},
			{arg: "created_on", value: this._oBundle.getText("DETAIL_USER_CREATED_ON")},
			{arg: "phone_number", value: this._oBundle.getText("DETAIL_USER_PHONE_NUMBER")},
			{arg: "expiry_date", value: this._oBundle.getText("DETAIL_USER_EXPIRY_DATE")},
			{arg: "status", value: this._oBundle.getText("DETAIL_STATUS")},
			{arg: "uid_is_assigned", value: this._oBundle.getText("DETAIL_USER_UID_STATUS")},
			{arg: "uid_last_name", value: this._oBundle.getText("DETAIL_USER_UNIVERSAL_ID_LAST_NAME")},
			{arg: "uid_first_name", value: this._oBundle.getText("DETAIL_USER_UNIVERSAL_ID_FIRST_NAME")},
			{arg: "action", value: this._oBundle.getText("MASTER_MANAGE")},
			//{arg: "isValidEmail", value: this._oBundle.getText("DETAIL_NON_COMPLIANT_EMAIL")},
			{args: ["", "Very new column"], name: "Empty key, suggested name", value: "Very new column"},
			{args: ["new_column", "Really new"], name: "Unknown key, suggested name", value: "Really new"}
		]);
	}); 
	
	QUnit.test("master.allOrNoneText: get All or None text, or return given value", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.allOrNoneText.bind(this._oView), [
			{arg: "All", value: this._oBundle.getText("MISC_ALL")},
			{arg: "None", value: this._oBundle.getText("MASTER_NONE")},
			{arg: "Something", value: "Something"},
			{arg: "Department 100", value: "Department 100"}
		]);
	});
	
	QUnit.test("master.customersTableTitle: get title for Customers table in Mass Authorization add/delete dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.customersTableTitle.bind(this._oView), [
			{arg: true, name: "Delete Mode", value: this._oBundle.getText("AUTH_OBJ_CUSTOMER_LEVEL_TITLE_REMOVED")},
			{arg: false, name: "Add Mode", value: this._oBundle.getText("AUTH_OBJ_CUSTOMER_LEVEL_TITLE")}
		]);
	});
	
	QUnit.test("master.deletedUserStatus: get User deletion status", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.deletedUserStatus.bind(this._oView), [
			{arg: "D", name: "Deleted", value: this._oBundle.getText("MISC_DELETED")},
			{arg: "P", name: "Pending Deletion", value: this._oBundle.getText("MISC_PENDING_DELETION")},
			{arg: "U", name: "Unknown", value: ""},
			{arg: "", name: "Empty", value: ""}
		]);
	}); 
	
	QUnit.test("master.installationsTableColumnText: get column name for restricted Installations/Users table in Mass Add/Delete Authorization dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.installationsTableColumnText.bind(this._oView), [
			{arg: true, name: "User Mode", value: this._oBundle.getText("AUTHORIZATION_LEVEL_USER_NAME")},
			{arg: false, name: "Installation Mode", value: this._oBundle.getText("AUTHORIZATION_LEVEL_INST_NAME")}
		]);
	}); 
	
	QUnit.test("master.installationsTableEditButtonTooltip: get Edit button tooltip for restricted Installations/Users table in Mass Add/Delete Authorization dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.installationsTableEditButtonTooltip.bind(this._oView), [
			{arg: true, name: "User Mode", value: this._oBundle.getText("BUTTON_USER_AUTH_ADD")},
			{arg: false, name: "Installation Mode", value: this._oBundle.getText("BUTTON_INST_AUTH_ADD")}
		]);
	});
	
	QUnit.test("master.installationsTableNoDataText: get No Data text for restricted Installations/Users table in Mass Add/Delete Authorization dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.installationsTableNoDataText.bind(this._oView), [
			{arg: true, name: "User Mode", value: this._oBundle.getText("AUTH_OBJ_NO_USER_AUTH_DATA_TEXT")},
			{arg: false, name: "Installation Mode", value: this._oBundle.getText("AUTH_OBJ_NO_INST_AUTH_DATA_TEXT")}
		]);
	});
	
	QUnit.test("master.installationsTableNoDataText: get No Data text for restricted Installations/Users table in Mass Add/Delete Authorization dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.installationsTableNoDataText.bind(this._oView), [
			{arg: true, name: "User Mode", value: this._oBundle.getText("AUTH_OBJ_NO_USER_AUTH_DATA_TEXT")},
			{arg: false, name: "Installation Mode", value: this._oBundle.getText("AUTH_OBJ_NO_INST_AUTH_DATA_TEXT")}
		]);
	});
	
	QUnit.test("master.installationsTableTitle: get title for restricted Installations/Users table in Mass Add/Delete Authorization dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.installationsTableTitle.bind(this._oView), [
			{args: [true, true], name: "User remove restrictions Mode", value: this._oBundle.getText("AUTH_OBJ_USER_LEVEL_TITLE_REMOVED")},
			{args: [true, false], name: "User add restrictions Mode", value: this._oBundle.getText("AUTH_OBJ_USER_LEVEL_TITLE")},
			{args: [false, true], name: "Installation remove restrictions Mode", value: this._oBundle.getText("AUTH_OBJ_INST_LEVEL_TITLE_REMOVED")},
			{args: [false, false], name: "Installation add restrictions Mode", value: this._oBundle.getText("AUTH_OBJ_INST_LEVEL_TITLE")}
		]);
	});
	
	QUnit.test("master.massAddDeleteAuthDialogTitle: get title for Mass Add/Delete Authorization dialog", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.massAddDeleteAuthDialogTitle.bind(this._oView), [
			{arg: true, name: "Delete Mode", value: this._oBundle.getText("DIALOG_REMOVE_AUTHORIZATIONS_TITLE")},
			{arg: false, name: "Add Mode", value: this._oBundle.getText("DIALOG_ADD_AUTHORIZATIONS_TITLE")}
		]);
	});
	
	QUnit.test("master.RACountLabelText: show title with counter for Reports and Updates table", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.RACountLabelText.bind(this._oView), [
			{arg: 0, value: this._oBundle.getText("MISC_ITEMS") + " (0)"},
			{arg: 11, value: this._oBundle.getText("MISC_ITEMS") + " (11)"},
			{arg: 901, value: this._oBundle.getText("MISC_ITEMS") + " (901)"}
		]);
	});
	
	QUnit.test("master.requestedUserStatus: get status text for Requested User", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.requestedUserStatus.bind(this._oView), [
			{arg: "S", name: "Successful", value: this._oBundle.getText("MISC_SUCCESS")},
			{arg: "A", name: "Successful but pass visible", value: this._oBundle.getText("MISC_SUCCESS")},
			{arg: "E", name: "Error", value: this._oBundle.getText("MISC_ERROR")},
			{arg: "R", name: "Rejected", value: this._oBundle.getText("MISC_REJECTED")},
			{arg: "", name: "In process", value: this._oBundle.getText("MISC_PROCESS")}
		]);
	});
	
	QUnit.test("master.requesterName: show uses requester's name", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.requesterName.bind(this._oView), [
			{args: ["self", ""], name: "Self", value: this._oBundle.getText("MISC_SELF")},
			{args: ["self", "S003212"], name: "Self", value: this._oBundle.getText("MISC_SELF")},
			{args: ["SAP", ""], name: "No User Id", value: "SAP"},
			{args: ["Alex Pushkin", "S5151331"], name: "All given", value: "Alex Pushkin (S5151331)"}
		]);
	});
	
	QUnit.test("master.uidStatus: show Universal ID status", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.uidStatus.bind(this._oView), [
			{arg: true, value: this._oBundle.getText("UID_STATUS_LINKED")},
			{arg: false, value: this._oBundle.getText("UID_STATUS_NOT_LINKED")}
		]);
	});
	
	QUnit.test("master.userCountLabelText: show title with counter for Users table", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.userCountLabelText.bind(this._oView), [
			{arg: 0, value: this._oBundle.getText("MASTER_USERS") + " (0)"},
			{arg: 34, value: this._oBundle.getText("MASTER_USERS") + " (34)"},
			{arg: 1321, value: this._oBundle.getText("MASTER_USERS") + " (1321)"}
		]);
	});
	
	QUnit.module("Formatter: Phone numbers", {
		setup: function () {
			Util._registerCountryList([
				{Land1: "DE", PrqSpregt: "49"},
				{Land1: "RU", PrqSpregt: "7"},
				{Land1: "US", PrqSpregt: "1"}
			]);
		}
	});
	
	QUnit.test("detail.phoneMask: format phone number mask", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.phoneMask, [
			{arg: "", name: "Empty country code", value: ""},
			{arg: "+929", name: "Country code with 9", value: "+^92^9-999999999999999"},
			{arg: "+9", name: "Country code with 9", value: "+^9-999999999999999"},
			{arg: "+102", value: "+102-999999999999999"},
			{arg: "+7", value: "+7-999999999999999"}
		]);
	}); 
	
	QUnit.test("detail.phoneNumberHyphen: format phone number using hyphen", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.phoneNumberHyphen, [
			{args: ["+1", ""], name: "Empty number", value: ""},
			{args: ["+4", "32932"], value: "+4-32932"},
			{args: ["+201", "0002141"], value: "+201-0002141"}
		]);
	});
	
	QUnit.test("detail.phoneNumberSpace: format phone number using space", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.phoneNumberSpace, [
			{args: ["+1", ""], name: "Empty number", value: ""},
			{args: ["+4", "32932"], value: "+4 32932"},
			{args: ["+201", "0002141"], value: "+201 0002141"}
		]);
	});
	
	QUnit.test("phoneCode: format phone code from country code", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.phoneCode, [
			{arg: "+21", value: "+21"},
			{arg: "DE", value: "+49"},
			{arg: "RU", value: "+7"},
			{arg: "US", value: "+1"},
			{arg: "", value: ""}
		]);
	}); 
	
	QUnit.test("phoneNumber: format phone number", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.phoneNumber, [
			{args: ["+21", "100"], value: "+21 100"},
			{args: ["DE", "3293"], value: "+49 3293"},
			{args: ["DE", ""], value: ""}
		]);
	});
	
	QUnit.module("Formatter: Strings");
	
	QUnit.test("concat: concatenate non-empty strings", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.concat, [
			{args: [], value: ""},
			{args: [null], value: ""},
			{args: ["abc"], value: "abc"},
			{args: ["Name", "", "Surname"], value: "Name Surname"},
			{args: ["Name", "MiddleName", "Surname"], value: "Name MiddleName Surname"}
		]);
	});
	
	QUnit.test("detail.addressCityCountry: format full address", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.addressCityCountry, [
			{args: ["Red Square 1", "Moscow", "Russia"], value: "Red Square 1 Moscow, Russia"}
		]);
	});
	
	QUnit.test("detail.userNameAndId: format user's full name and ID", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.userNameAndId, [
			{args: ["", "", "", ""], name: "All empty", value: ""},
			{args: ["", "", "", "201222"], name: "ID only", value: "(201222)"},
			{args: ["", "", "Pushkin", ""], name: "Last Name", value: "Pushkin"},
			{args: ["", "", "Pushkin", "201222"], name: "ID and Last Name", value: "Pushkin (201222)"},
			{args: ["", "Alexander", "", ""], name: "First name", value: "Alexander"},
			{args: ["", "Alexander", "", "32141"], name: "First name and ID", value: "Alexander (32141)"},
			{args: ["", "Alexander", "Pushkin", ""], name: "First name and last name", value: "Alexander Pushkin"},
			{args: ["", "Alexander", "Pushkin", "54151"], name: "No title", value: "Alexander Pushkin (54151)"},
			{args: ["Mr.", "", "Tesla", ""], name: "Title and last name", value: "Mr. Tesla"},
			{args: ["Mrs.", "Alberta", "Einstein", ""], name: "No ID", value: "Mrs. Alberta Einstein"},
			{args: ["Mr.", "Leo", "Tolstoy", "8771"], name: "All given", value: "Mr. Leo Tolstoy (8771)"}
		]);
	});
	
	QUnit.test("master.buttonTooltip: get tooltip for any button", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.buttonTooltip, [
			{args: ["", "", true], name: "Button enabled - show default button tooltip", "value": ""},
			{args: ["", "Info text", true], name: "Button enabled - show default button tooltip", "value": ""},
			{args: ["Default way", "", true], name: "Button enabled - show default button tooltip", "value": "Default way"},
			{args: ["Click me", "Info text", true], name: "Button enabled - show default button tooltip", "value": "Click me"},
			{args: ["", "Info text about it", false], name: "Button disabled - show disruption information text", "value": "Info text about it"},
			{args: ["Click me!", "Info text!", false], name: "Button disabled - show disruption information text", "value": "Info text!"},
			{args: ["I am a button", "<b>Crash!</b>", false], name: "Button disabled - show disruption information text until HTML", "value": ""},
			{args: ["I am a button", "We have a crash! <a href=\"localhost\">Read more</a>", false], name: "Button disabled - show disruption information text without HTML", "value": "We have a crash! "}
		]);
	});
	
	QUnit.test("master.requestedUserPassword: show password for failed user requests", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.requestedUserPassword, [
			{args: ["qwerty123", "S"], name: "Successful", value: ""},
			{args: ["qwerty1!23", "A"], name: "Successful but pass visible", value: "qwerty1!23"},
			{args: ["Rx11ra13", "E"], name: "Error", value: "Rx11ra13"},
			{args: ["1dsaer43a", "R"], name: "Rejected", value: "1dsaer43a"},
			{args: ["axcz1351", ""], name: "In process", value: "axcz1351"}
		]);
	});
	
	QUnit.test("titleAndNumber: format title with number in brackets", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.titleAndNumber, [
			{args: ["Items", 0], value: "Items (0)"},
			{args: ["Users", 200], value: "Users (200)"},
			{args: ["Deleted Users", 3219], value: "Deleted Users (3219)"}
		]);
	});
	
	QUnit.test("upperCase: make string uppercase", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.upperCase, [
			{arg: "Items", value: "ITEMS"},
			{arg: "select all", value: "SELECT ALL"},
			{arg: null, value: ""}
		]);
	});
	
	QUnit.module("Formatter: Validation", {
		setup: function () {
			this._oResourceModel = _oResourceModel;
			this._oBundle = this._oResourceModel.getResourceBundle();
			this._oView = {
				getModel: sinon.stub().withArgs("i18n").returns(this._oResourceModel)
			};
		}
	});
	/*
	QUnit.test("detail.validEmailState: validate email then return value state", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.detail.validEmailState, [
			{arg: "", name: "Empty email", value: ValueState.None},
			{arg: "email", name: "No at & domain", value: ValueState.Error},
			{arg: "abc21@21@ad.com", name: "At signs", value: ValueState.Error},
			{arg: "abc21@@ad.com", name: "At signs", value: ValueState.Error},
			{arg: "abc21@", name: "No domain", value: ValueState.Error},
			{arg: "abc21@localhost", name: "No domain zone", value: ValueState.Error},
			{arg: "abc21@ad.com.", name: "Ends on dot", value: ValueState.Error},
			{arg: "it.is.me@sap.com", name: "Normal email", value: ValueState.None},
			{arg: "ace_218A8.abcA21-dsa@abc.ru", name: "Normal email", value: ValueState.None},
			{arg: "ace_218A8.abcA21-dsa@d8a-21.3213-329.ru", name: "Normal email", value: ValueState.None}
		]);
	});
	*/
	QUnit.test("dialog.isNameHasInvalidChars: check if user's name has invalid symbols", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.dialog.isNameHasInvalidChars, [
			{arg: "", name: "Empty name", value: false},
			{arg: "Kate \"Nick\"", name: "Signs", value: true},
			{arg: "Alex (Mike)", name: "Signs", value: true},
			{arg: "Abc.Test", name: "Signs", value: true},
			{arg: "\u042f\u043d", name: "Cyrillic", value: true},
			{arg: "\u00c4\u00e4\u00d6\u00f6\u00dc\u00fc\u00df", name: "Umlauts", value: false},
			{arg: "Test 123456", name: "Correct name", value: false},
			{arg: "Ana-Maria", name: "Correct name", value: false},
			{arg: "Ana Maria", name: "Correct name", value: false},
			{arg: "Vladimir", name: "Correct name", value: false}
		]);
	});
	
	QUnit.test("dialog.isNameReserved: check if user's name is reserved", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.dialog.isNameReserved, [
			{arg: "", name: "Empty name", value: false},
			{arg: "Anna", name: "Regular name", value: false},
			{arg: "--TECH-USER--", name: "Invalid tech user", value: false},
			{arg: "---TECH-USER---", name: "Tech user", value: true}
		]);
	}); 
	
	QUnit.test("dialog.requestUserFormValid: check if Request user form is valid", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.dialog.requestUserFormValid, [
			{args: ["", "", "", "", "", ""], name: "All empty", value: false},
			{args: ["", "Albert", "Einstein", "1234", "Mr.", "DE"], name: "Email empty", value: false},
			{args: [false, "Albert", "Einstein", "1234", "Mr.", "DE"], name: "Email incorrect", value: false},
			{args: [false, "Albert", "Einstein", "1234", "Mr.", "DE"], name: "Email incorrect", value: false},
			{args: [false, "Albert", "Einstein", "1234", "Mr.", "DE"], name: "Email incorrect", value: false},
			{args: [true, "", "Einstein", "1234", "Mr.", "DE"], name: "First name empty", value: false},
			{args: [true, "\u042f\u043d", "Name", "1234", "Mr.", "DE"], name: "Invalid first name symbols", value: false},
			{args: [true, "Mike", "", "1234", "Mr.", "US"], name: "Last name empty", value: false},
			{args: [true, "Anna", "\"Nick\"", "1234", "Mrs.", "FR"], name: "Invalid last name symbols", value: false},
			{args: [true, "Kate", "White", "", "Mrs.", "UK"], name: "Customer number empty", value: false},
			{args: [true, "Niel", "White", "987231", "", "AU"], name: "Salutation empty", value: false},
			{args: [true, "Alexander", "Pushkin", "8912", "Mr.", ""], name: "Country empty", value: false}//,
			//{args: [true, "\u00c4l", "Name", "1234", "Mr.", "DE"], name: "Umlauts in first name", value: true},
			//{args: [true, "My", "N\u00e4me", "1234", "Mr.", "DE"], name: "Umlauts in last name", value: true},
			//{args: [true, "My", "Name\u00df", "1234", "Mr.", "DE"], name: "Eszett in last name", value: true},
			//{args: [true, "Albert", "Einstein", "1234", "Mr.", "DE"], name: "All correct", value: true}
		]);
	}); 
	
	QUnit.test("dialog.userNameValueState: get value state for user name input", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.dialog.userNameValueState, [
			{arg: "", name: "Empty name", value: ValueState.None},
			{arg: "Anna", name: "Regular name", value: ValueState.None},
			{arg: "--TECH-USER--", name: "Invalid tech user", value: ValueState.None},
			{arg: "---TECH-USER---", name: "Tech user", value: ValueState.Error},
			{arg: "Kate \"Nick\"", name: "Signs", value: ValueState.Error},
			{arg: "Alex (Mike)", name: "Signs", value: ValueState.Error},
			{arg: "Abc.Test", name: "Signs", value: ValueState.Error},
			{arg: "\u042f\u043d", name: "Cyrillic", value: ValueState.Error},
			{arg: "\u00c4\u00e4\u00d6\u00f6\u00dc\u00fc\u00df", name: "Umlauts", value: ValueState.None},
			{arg: "Test 123456", name: "Correct name", value: ValueState.None},
			{arg: "Ana-Maria", name: "Correct name", value: ValueState.None},
			{arg: "Ana Maria", name: "Correct name", value: ValueState.None},
			{arg: "D'Maria", name: "Correct name", value: ValueState.None},
			{arg: "Vladimir", name: "Correct name", value: ValueState.None}
		]);
	});  
	
	QUnit.test("dialog.userNameValueStateText: get value state text for user input error", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.dialog.userNameValueStateText.bind(this._oView), [
			{arg: "", name: "Empty name", value: ""},
			{arg: "Anna", name: "Regular name", value: ""},
			{arg: "--TECH-USER--", name: "Invalid tech user", value: ""},
			{arg: "---TECH-USER---", name: "Tech user", value: this._oBundle.getText("MESSAGE_RESERVED_NAME")},
			{arg: "Kate \"Nick\"", name: "Signs", value: this._oBundle.getText("DIALOG_USER_NAME_HAS_INVALID_SYMBOLS_LONG")},
			{arg: "Alex (Mike)", name: "Signs", value: this._oBundle.getText("DIALOG_USER_NAME_HAS_INVALID_SYMBOLS_LONG")},
			{arg: "Abc.Test", name: "Signs", value: this._oBundle.getText("DIALOG_USER_NAME_HAS_INVALID_SYMBOLS_LONG")},
			{arg: "\u042f\u043d", name: "Cyrillic", value: this._oBundle.getText("DIALOG_USER_NAME_HAS_INVALID_SYMBOLS_LONG")},
			{arg: "\u00c4\u00e4\u00d6\u00f6\u00dc\u00fc\u00df", name: "Umlauts", value: ""},
			{arg: "Test 123456", name: "Correct name", value: ""},
			{arg: "Ana-Maria", name: "Correct name", value: ""},
			{arg: "Ana Maria", name: "Correct name", value: ""},
			{arg: "D'Maria", name: "Correct name", value: ""},
			{arg: "Vladimir", name: "Correct name", value: ""}
		]);
	});
	
	QUnit.test("master.departmentValueState: get value state for Department name input", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.departmentValueState.bind(this._oView), [
			{arg: "", name: "Empty", value: ValueState.None},
			{arg: "DEPT+10", name: "Invalid symbols", value: ValueState.Error},
			{arg: "De-part", name: "Valid symbols", value: ValueState.None},
			{arg: "Depart_ment 94", name: "Valid symbols", value: ValueState.None}
		]);
	});
	
	QUnit.test("master.isDepartmentNameValid: check if department name is valid", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.isDepartmentNameValid, [
			{arg: "", name: "Empty", value: false},
			{arg: "Group+10", name: "Invalid symbols", value: false},
			{arg: "All-together", name: "Valid symbols", value: true},
			{arg: "Our Depart_ment 94", name: "Valid symbols", value: true}
		]);
	}); 
	
	QUnit.module("Formatter: UI Parameters");
	
	QUnit.test("listItemNavigation: get type for list item - Inactive or Navigation", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.listItemNavigation, [
			{arg: true, value: ListType.Navigation},
			{arg: false, value: ListType.Inactive},
			{arg: null, value: ListType.Inactive}
		]);
	});
	
	QUnit.test("valueStateError: get item's value state - Error or None", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.valueStateError, [
			{arg: true, value: ValueState.Error},
			{arg: false, value: ValueState.None},
			{arg: null, value: ValueState.None}
		]);
	});
	
	QUnit.test("master.enabledDeleteButton: check if Delete button enabled in footer", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.enabledDeleteButton, [
			{args: ["AuthPackages", true], name: "Auth Packages, no general disruption", value: false},
			{args: ["AuthPackages", false], name: "Auth Packages, general disruption", value: false},
			{args: ["ReportsAndUpdates", true], name: "Reports and Updates, no general disruption", value: false},
			{args: ["ReportsAndUpdates", false], name: "Reports and Updates, general disruption", value: false},
			{args: ["TechnicalUsers", true], name: "Tech Users tab, no general disruption", value: false},
			{args: ["TechnicalUsers", false], name: "Tech Users tab, general disruption", value: false},
			{args: ["ImportantContacts", true], name: "Important Contacts List, no general disruption", value: false},
			{args: ["ImportantContacts", false], name: "Important Contacts List, general disruption", value: false},
			{args: ["DeletedUsers", true], name: "Deleted User List, no general disruption", value: false},
			{args: ["DeletedUsers", false], name: "Deleted User List, general disruption", value: false},
			{args: ["RequestedUsers", true], name: "Requested User List, no general disruption", value: false},
			{args: ["RequestedUsers", false], name: "Requested User List, general disruption", value: false},
			{args: ["AllUsers", true], name: "User List, no general disruption", value: true},
			{args: ["AllUsers", false], name: "User List, general disruption", value: false}
		]);
	});
	
	QUnit.test("master.enabledForNonEmptyReportsList: get enabled state if number of items is not empty", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.enabledForNonEmptyReportsList, [
			{args: [], value: false},
			{arg: 0, value: false},
			{arg: 1, value: true},
			{arg: 5, value: true}
		]);
	}); 
	
	QUnit.test("master.importantContactUserRowType: get row type for Important Contacts table row according to User ID", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.importantContactUserRowType, [
			{arg: "NA", value: ListType.Inactive},
			{arg: "S000120301", value: ListType.Navigation},
			{arg: "S123455", value: ListType.Navigation}
		]);
	});
	
	QUnit.test("master.isAuthorizationPackagesTab: check if current tab is Authorization Packages", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.isAuthorizationPackagesTab, [
			{arg: "AuthPackages", value: true},
			{arg: "ReportsAndUpdates", value: false},
			{arg: "TechnicalUsers", value: false},
			{arg: "ImportantContacts", value: false},
			{arg: "DeletedUsers", value: false},
			{arg: "RequestedUsers", value: false},
			{arg: "AllUsers", value: false}
		]);
	});
	
	QUnit.test("master.isNotAuthorizationPackagesTab: check if current tab is not Authorization Packages", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.isNotAuthorizationPackagesTab, [
			{arg: "AuthPackages", value: false},
			{arg: "ReportsAndUpdates", value: true},
			{arg: "TechnicalUsers", value: true},
			{arg: "ImportantContacts", value: true},
			{arg: "DeletedUsers", value: true},
			{arg: "RequestedUsers", value: true},
			{arg: "AllUsers", value: true}
		]);
	});
	
	QUnit.test("master.isNotRUorAPTab: check if current tab is not Reports and Updates or Authorization Packages", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.isNotRUorAPTab, [
			{arg: "AuthPackages", value: false},
			{arg: "ReportsAndUpdates", value: false},
			{arg: "TechnicalUsers", value: true},
			{arg: "ImportantContacts", value: true},
			{arg: "DeletedUsers", value: true},
			{arg: "RequestedUsers", value: true},
			{arg: "AllUsers", value: true}
		]);
	});
	
	QUnit.test("master.isReportsAndUpdatesTab: check if current tab is Reports and Updates", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.isReportsAndUpdatesTab, [
			{arg: "AuthPackages", value: false},
			{arg: "ReportsAndUpdates", value: true},
			{arg: "TechnicalUsers", value: false},
			{arg: "ImportantContacts", value: false},
			{arg: "DeletedUsers", value: false},
			{arg: "RequestedUsers", value: false},
			{arg: "AllUsers", value: false}
		]);
	});
	
	QUnit.test("master.navigableOrInactive: get Navigation or Inactive list item type", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.navigableOrInactive, [
			{arg: true, value: ListType.Navigation},
			{arg: false, value: ListType.Inactive}
		]);
	});
	
	QUnit.test("master.requestedUserRowType: get Navigation or Inactive list item type for Requested User table", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.requestedUserRowType, [
			{arg: "S", name: "Successful", value: ListType.Navigation},
			{arg: "A", name: "Successful but pass visible", value: ListType.Navigation},
			{arg: "E", name: "Error", value: ListType.Inactive},
			{arg: "R", name: "Rejected", value: ListType.Inactive},
			{arg: "", name: "In process", value: ListType.Inactive}
		]);
	});
	
	QUnit.test("master.requestedUserSuccessful: check if Requested User is successful", function(assert) {
		TestUtil.strictEqualMassTest(assert, Formatter.master.requestedUserSuccessful, [
			{arg: "S", name: "Successful", value: true},
			{arg: "A", name: "Successful but pass visible", value: false},
			{arg: "E", name: "Error", value: false},
			{arg: "R", name: "Rejected", value: false},
			{arg: "", name: "In process", value: false}
		]);
	});
});
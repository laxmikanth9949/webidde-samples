sap.ui.require([
	"test/unit/TestUtil",
	"sap/support/useradministration/util/DetailUtil",
	
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function (TestUtil, DetailUtil) {
	"use strict";
	
	QUnit.module("DetailUtil: validations", {
		setup: function () {
			
		}
	});
	
	QUnit.test("validateEmail: e-mail validation", function(assert) {
		TestUtil.strictEqualMassTest(assert, DetailUtil.validateEmail, [
			{arg: "leo.tolstoy@sap.com", value: true},
			{arg: "SergeyEsenin123456789@new-server.all.org", value: true}//,
			//{arg: "My@Maild@qtest.com", value: false, name: "Two ats"},
			//{arg: "alex.pushkin@localhost", value: false, name: "No domain"}
		]);
	});
});
sap.ui.define([

], function () {

	/**
	 * Get list with range of numbers
	 * @param {int} iFrom range start
	 * @param {int} iTo range end, not included in the range
	 * @returns {int[]} range of numbers
	 * @function
	 * @private
	 */
	function _range(iFrom, iTo) {
		var aResult = [],
			iFromNum = Number(iFrom) || 0,
			iToNum = Number(iTo) || 0,
			iStart = iTo === undefined ? 0 : iFromNum,
			iEnd = iTo === undefined ? iFromNum : iToNum;

		for (var iIndex = iStart; iIndex < iEnd; iIndex++) {
			aResult.push(iIndex);
		}
		return aResult;
	}
	
	var _aChars = String.fromCharCode.apply(String, _range("A".charCodeAt(0), "Z".charCodeAt(0)).concat(_range("a".charCodeAt(0), "z".charCodeAt(0))));

	var TestUtil = {
		/**
		 * Apply function in batch
		 * @param {function} fnFunction function
		 * @param {Array[]} aArgs list of arguments lists
		 * @function
		 * @public
		 */
		batchApply: function (fnFunction, aArgs) {
			aArgs.forEach(function (aArgsItem) {
				fnFunction.apply(this, aArgsItem);
			}.bind(this));
		},
		
		/**
		 * Create date with given parameters
		 * @param {int} [iYear] year
		 * @param {int} [iMonth] month 1..12
		 * @param {int} [iDay] day of month 1..31
		 * @param {int} [iHour] hour of day 0..23
		 * @param {int} [iMinute] minute of hour 0..59
		 * @param {int} [iSecond] second of minute 0..59
		 * @returns {Date} date
		 * @function
		 * @public
		 */
		createDate: function () {
			var oDate = new Date(0),
				aYearMonthDay = Array.prototype.slice.call(arguments, 0, 3),
				aHourMinuteSecond = Array.prototype.slice.call(arguments, 3);           
			
			if (!aYearMonthDay.length) {
				return oDate;
			}
			
			// If month defined
			if (aYearMonthDay.length > 1) {
				aYearMonthDay[1] -= 1;
			}
			
			oDate.setFullYear.apply(oDate, aYearMonthDay);
			
			if (aHourMinuteSecond.length) {
				oDate.setHours.apply(oDate, aHourMinuteSecond);
			}
			
			return oDate;
		},
		
		/**
		 * jquery.each adaptation
		 * @param {Object} oObject object to iterate over
		 * @param {function} fnCallback callback (key, value)
		 * @function
		 * @public
		 */
		each: function (oObject, fnCallback) {
			if (oObject) {
				Object.keys(oObject).forEach(function (sKey) {
					var oValue = oObject[sKey];
					fnCallback(sKey, oValue);
				});
			}
		},

		/**
		 * Get random number
		 * @param {int} iMax max number
		 * @returns {int} random number
		 * @function
		 * @public
		 */
		getRandomInt: function (iMax) {
			return Math.floor(Math.random() * iMax);
		},
		
		/**
		 * Get random item from the list
		 * @param {any[]} aList list of items
		 * @returns {any} item
		 * @function
		 * @public
		 */
		getRandomListItem: function (aList) {
			return aList && aList[TestUtil.getRandomInt(aList.length)];
		},
		
		/**
		 * Get random string
		 * @param {int} iLength string length
		 * @returns {string} string
		 * @function
		 * @public
		 */
		getRandomString: function (iLength) {
			return _range(iLength).map(TestUtil.getRandomListItem.bind(this, _aChars)).join("");
		},
		
		getRange: _range,
		
		/**
		 * Inverse string case
		 * @param {string} sString string
		 * @returns {string} inverted string
		 * @function
		 * @public
		 */
		inverseCase: function (sString) {
			return sString && sString.split("").map(function (sChar) {
				var sUpCase = sChar.toUpperCase();
				return sUpCase === sChar ? sChar.toLowerCase() : sChar.toUpperCase();
			}).join("");
		},
		
		/**
		 * Run strictEqual
		 * @param {function} fnAssert assert function
		 * @param {function} fnFunction callback to check
		 * @param {string} sTitle test case title
		 * @param {any} mExpectedValue,
		 * @param {...*} callback arguments
		 * @function
		 * @public
		 */
		runStrictEqual: function (fnAssert, fnFunction, sTitle, mExpectedValue) {
			var aArgs = Array.prototype.slice.call(arguments, 4); 
			fnAssert.strictEqual(fnFunction.apply(this, aArgs), mExpectedValue, sTitle);
		},
			
		/**
		 * Run tests in batch
		 * @param {function} fnAssert assertion function
		 * @param {function} fnCallback function to test
		 * @param {object[]} aTests tests
		 * @function
		 * @public
		 */
		massTest: function(fnAssert, fnCallback, aTests) {
			if (!fnCallback) {
				throw new TypeError("Function to test is undefined!");
			}
			
			aTests.forEach(function (oTest) {
				var aArgs = oTest.args || (oTest.arg !== undefined && [oTest.arg]) || [],
					sArgs = JSON.stringify(aArgs),
					sTestName = [oTest.name, sArgs].filter(Boolean).join(" ");
					
				fnAssert(fnCallback.apply(this, aArgs), oTest.value, sTestName + " => " + JSON.stringify(oTest.value));
			}.bind(this));
		},
			
		/**
		 * Run deep equal tests in batch
		 * @param {object} assert assertion object
		 * @param {function} fnCallback function to test
		 * @param {object[]} aTests tests
		 * @function
		 * @public
		 */
		deepEqualMassTest: function(assert, fnCallback, aTests) {
			TestUtil.massTest(assert.deepEqual.bind(assert), fnCallback, aTests);
		},
			
		/**
		 * Run strict equal tests in batch
		 * @param {object} assert assertion object
		 * @param {function} fnCallback function to test
		 * @param {object[]} aTests tests
		 * @function
		 * @public
		 */
		strictEqualMassTest: function(assert, fnCallback, aTests) {
			if (!fnCallback) {
				throw new TypeError("Function to test is undefined!");
			}
			
			aTests.forEach(function (oTest) {
				var aArgs = oTest.args || (oTest.arg !== undefined && [oTest.arg]) || [],
					sArgs = JSON.stringify(aArgs),
					sTestName = [oTest.name, sArgs].filter(Boolean).join(" ");
					
				assert.strictEqual(fnCallback.apply(this, aArgs), oTest.value, sTestName + " => " + JSON.stringify(oTest.value));
			}.bind(this));
		}
	};

	return TestUtil;
});
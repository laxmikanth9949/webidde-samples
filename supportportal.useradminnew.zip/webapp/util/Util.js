sap.ui.define([
    "sap/support/useradministration/model/Constant",
    "sap/support/useradministration/util/ErrorResponse",
    "sap/support/useradministration/util/DateUtil",
    "sap/support/useradministration/util/DetailUtil",
    
    "sap/m/MessageToast",
    "sap/base/strings/formatMessage",
    "sap/base/util/merge",
	"sap/m/library",
], function(Constant, ErrorResponse, DateUtil, DetailUtil, MessageToast, formatMessage, merge, MobileLibrary) {
	"use strict";
	
	var MessageBox = sap.m.MessageBox,
		Sorter = sap.ui.model.Sorter,
		_oCountriesByCode = {},
		_oCachedBundle = null;
	
    /**
     * Get error message from JSON response
     * @param {object} oErrorXhr XHR error object
     * @returns {string} error message on success, empty string otherwise
     * @function
     * @private
     */
    var _fnParseJSONError = function(oErrorXhr) {
	    var sResponseText = oErrorXhr.responseText;
	    try {
    	    var oBody = JSON.parse(sResponseText);
    	    return oBody.error.message.value || "";
	    } catch (e) {
	        return "";
	    }
    };
    
    /**
     * 
     * Check if value is function
     * @param {any} vValue value to check
     * @returns {boolean} check result
     * @function
     * @private
     */
    var _isFunction = function(vValue) {
        return Boolean(vValue && vValue.constructor && vValue.call && vValue.apply);  
    };
    
	var _fnDeferred = jQuery.Deferred;
    var BATCH_RESPONSES = "__batchResponses",
        CHANGE_RESPONSES = "__changeResponses";
    
    var Util = {
    	Constant: Constant,
    	
    	date: DateUtil,
        detail: DetailUtil,
        
        formatMessage: formatMessage,
        merge: merge,
        
        Error: {
            /**
             * Display error
             * @param {object} oError error info object
             * @returns {sap.m.Dialog} opened dialog
             * @function
             * @public
             */
            display: function (oError) {
                var oUABundle = Util.getBundle.call(this),
                    aMessage = [];
                
                if (!oError.messageBody) {
                    jQuery.each({
                        message: "MESSAGE",
                        responseText: "RESPONSE_TEXT",
                        statusCode: "STATUS_CODE",
                        statusText: "STATUS_TEXT",
                        requestUri: "REQUEST_URI"
                    }, function (sKey, sTextName) {
                        aMessage.push(oError[sKey] ? oUABundle.getText(sTextName) + " " + oError[sKey] : "");
                    });
                } else {
                    aMessage.push(oError.messageBody);
                }
                
                var sMessage = aMessage.filter(Boolean).join("\n");
            	jQuery.sap.log.error(sMessage);
            	
            	var oDialog = new sap.m.Dialog({
					type: MobileLibrary.DialogType.Message,
                    title: oError.message,
                    content: [
                        new sap.m.Text({
                            text: sMessage
                        })
                    ],
                    beginButton: new sap.m.Button({
                        text: oUABundle.getText("BUTTON_USER_CLOSE"),
                        type: sap.m.ButtonType.Default,
                        press: function() {
                            oDialog.close();
                        }
                    })
                });
                oDialog.open();
                return oDialog;
            },
            /**
             * Parse error
             * @param {string} sResponse error response text
             * @returns {sap.support.useradministration.util.ErrorResponse} error response object
             * @function
             * @public
             */
            parse: function(sResponse) {
                return new ErrorResponse(sResponse);
            }
        },
        JSONError: {
            /**
             * Get error message from JSON response
             * @param {object} oErrorXhr XHR error object
             * @returns {string} error message on success, empty string otherwise
             * @function
             * @public
             */
            parse: function(oErrorXhr) {
                return _fnParseJSONError(oErrorXhr);
            },
            
            /**
             * Show message toast with error message
             * @param {object} oErrorXhr XHR error object
             * @function
             * @public
             */
            showToast: function(oErrorXhr) {
                MessageToast.show(_fnParseJSONError(oErrorXhr));
            }
        },
        
        callbacks: { // Predefined callback functions
            /**
             * Returns callback to get value at specific key
             * @param {string} sKey key
             * @returns {function} callback
             * @function
             * @public
             */
            getKey: function(sKey) {
                return function(oItem) {
                    return oItem[sKey];
                };
            },
            
            /**
             * Returns value himself
             * @param {any} vValue value to return
             * @returns {any} value in parameter
             * @function
             * @public
             */
            self: function(vValue) {
                return vValue;
            }
        },
        
        /**
         * Register country list for determing country phone codes
         * @param {object[]} aCountryList list of countries'
         * @function
         * @private
         */
        _registerCountryList: function (aCountryList) {
        	var aCountries = aCountryList || [];
        	aCountries = aCountries.map(function (oCountry) {
        		return {
        			CountryCode: oCountry.Land1,
        			PhoneCode: oCountry.PrqSpregt
        		};
        	});
        	
        	_oCountriesByCode = Util.mapBy(aCountries, "CountryCode");
        },
        
        /**
         * Find value in the array for what callback is true
         * @param {any[]} aArray array
         * @param {function} fnCallback callback
         * @returns {any} found object
         * @function
         * @public
         */
        arrayFind: function(aArray, fnCallback) {
            var oFound;
            
            if (aArray && aArray.some) {
                aArray.some(function (oItem) {
                    if (fnCallback(oItem)) {
                        oFound = oItem;
                        return true;
                    }
                    return false;
                });
            }
            return oFound;
        },
		
        /**
         * Traverse up across the control tree to find closest instance of the given class
         * @param {sap.ui.core.Control} oControl control to start with
         * @param {object} oClass class object 
         * @returns {sap.ui.core.Control} closest parent (or control itself) of the given class
         * @function
         * @public
         */
        closest: function(oControl, oClass) {
        	var oItem = oControl;
        	while (oItem) {
        		if (oItem instanceof oClass) {
        			return oItem;
        		}
        		oItem = oItem.getParent && oItem.getParent();
        	}
        	return null;
        },
        
        /**
         * Create object by getting keys and values from array items
         * @param {any[]} aArray array
         * @param {function} fnKeys callback to get keys, if not provided use array item as key
         * @param {function|any} vValues callback to get values or constant value
         * @returns {object} object where keys are property values and values are true
         * @function
         * @public
         */
        combineArray: function(aArray, fnKeys, vValues) {
            var oMap = {};
            
            aArray.forEach(function(vItem) {
                var vValue = _isFunction(vValues) ? vValues(vItem) : vValues,
                    vKey = _isFunction(fnKeys) ? fnKeys(vItem) : vItem;
                oMap[vKey] = vValue;
            });
            return oMap;
        },
        
        /**
         * Copy object
         * @param {object} oObject object
         * @returns {object} copy
         * @function
         * @public
         */
        copy: function (oObject) {
        	return Util.merge({}, oObject);
        },
        
        /**
         * Count occurrence per each item value or callback value
         * @param {any[]} aArray array
         * @param {function} [fnCallback] callback to get value from items, otherwise whole item will be used
         * @returns {object} object where keys are property values and values are numbers of occurrence
         * @function
         * @public
         */
        countArray: function(aArray, fnCallback) {
            var oMap = {};
            
            aArray.forEach(function(vItem) {
                var vKey = _isFunction(fnCallback) ? fnCallback(vItem) : vItem;
                oMap[vKey] = oMap[vKey] ? oMap[vKey] + 1 : 1;
            });
            return oMap;
        },
        
        /**
         * Get deep copy of the object
         * @param {object} oValue object to copy
         * @returns {object} copy
         * @function
         * @public
         */
        deepCopy: function (oValue) {
        	return jQuery.extend(true, {}, oValue);
        },
        
        /**
         * Delete extensions from extended OData object
         * @param {object} oObject object to modify
         * @returns {object} modified object
         * @function
         * @public
         */
        deleteODataExtensions: function(oObject) {
            var KEY = "__list";
            jQuery.each(oObject, function(sKey, vValue) {
                if (vValue && vValue[KEY]) {
                    delete oObject[sKey];
                } 
            });
            return oObject;
        },

		/**
		 * native jQuery.each
		 * @param {object} oObject to iterate
		 * @param {function} fnCallback callback to apply to each value
		 * @function
		 * @public
		 */
		each: function (oObject, fnCallback) {
			Object.keys(oObject || {}).map(function (sKey) {
				var vValue = oObject[sKey];
				fnCallback(vValue, sKey);
			});
		},
		
        /**
         * Get error from any response in batch
         * @param {object} oData backend response object
         * @returns {string} error body
         * @function
         * @public
         */
        getBatchError: function(oData) {
            var oBatchResponse = oData[BATCH_RESPONSES] && oData[BATCH_RESPONSES][0],
                oResponse = oBatchResponse && oBatchResponse.response,
                aChangeResponses = oBatchResponse && oBatchResponse[CHANGE_RESPONSES] || [];
            
            if (oResponse) {
                if (Number(oResponse && oResponse.statusCode) >= 400) {
                    return Util.parseError(oResponse.body || "").getMessage();
                } 
            }
            
            for (var iIndex = 0; iIndex < aChangeResponses.length; iIndex++) {
                oResponse = aChangeResponses[iIndex].response;
                if (Number(oResponse && oResponse.statusCode) >= 400) {
                    return Util.parseError(oResponse.body || "").getMessage();
                } 
            }
            return null;
        },
        
        /**
         * Get batch message
         * @param {object} oData backend response object
         * @returns {string} message
         * @function
         * @public
         */
        getBatchMessage: function(oData) {
            return oData[BATCH_RESPONSES] && oData[BATCH_RESPONSES][0].message;
        },
	        
	    /**
	     * Get i18n bundle from context
	     * CALL WITH CONTEXT
	     * @returns {sap.ui.model.resource.ResourceBundle} bundle
	     * @function
	     * @public
	     */
	    getBundle: function() {
            var oModel = Util.getModel.call(this, "i18n");
            if (oModel) {
                return oModel.getResourceBundle();
            } else if (this && this._oUABundle) {
                return this._oUABundle;
            } else if (!_oCachedBundle) {
                _oCachedBundle = jQuery.sap.resources({
                    url: jQuery.sap.getModulePath("sap.support.useradministration") + "/i18n/messageBundle.properties"
                });
            }
            return _oCachedBundle;
	    },
	    
	    /**
	     * Get comparator for Array.sort
	     * @param {string} [sProperty] property of the object
	     * @returns {function} comparator
	     * @function
	     * @public
	     */
	    getComparator: function (sProperty) {
	    	if (sProperty) {
		    	return function (vFirst, vSecond) {
		    		return Sorter.defaultComparator(vFirst && vFirst[sProperty], vSecond && vSecond[sProperty]);
		    	};
	    	} else {
		    	return function (vFirst, vSecond) {
		    		return Sorter.defaultComparator(vFirst, vSecond);
		    	};
	    	}
	    },
	    
	    /**
	     * Get country phone code
	     * @param {string} sCountryCode country's code
	     * @returns {string} country's phone code
	     * @function
	     * @public
	     */
	    getCountryPhoneCode: function (sCountryCode) {
	    	var oCountry = _oCountriesByCode[sCountryCode];
	    	return oCountry && oCountry.PhoneCode || "";
	    },
	    
        /**
	     * Get model with given name from context
	     * CALL WITH CONTEXT
	     * @param {string} sModelName model name
	     * @returns {sap.ui.model.Model} model
	     * @function
	     * @private
	     */
	    getModel: function(sModelName) {
	        var oModel = null;
	        if (this && this !== Util) {
	            var oView = this.getView && this.getView(),
	                oComponent = this.getOwnerComponent && this.getOwnerComponent();
	            oModel = this.getModel && this.getModel(sModelName);
	            if (!oModel && oView && oView.getModel) {
	                oModel = oView.getModel(sModelName);
	            }
	            if (!oModel && oComponent && oComponent.getModel) {
	                oModel = oComponent.getModel(sModelName);
	            }
	        }
	        return oModel;
	    },
    
		/**
		 * Get jQuery promise
		 * @returns {object} promise
		 * @function
		 * @public
		 */
		getPromise: function() {
			return _fnDeferred();
		},
		
		/**
		 * Get sorter by property
		 * @param {string} sProperty property name
		 * @returns {function} sorter
		 * @function
		 * @public
		 */
		getSorter: function (sProperty) {
			return function (oFirst, oSecond) {
				return sap.ui.model.Sorter.defaultComparator(oFirst[sProperty], oSecond[sProperty]);
			};
		},
        
        /**
         * Get i18n text
         * CALL WITH CONTEXT
         * @param {string} sKey i18n key
         * @param {any[]} [aArgs] text args
         * @returns {string} i18n text
         * @function
         * @public
         */
        getText: function(sKey, aArgs) {
            return Util.getBundle.call(this).getText(sKey, aArgs);
        },
		
		/**
		 * Get SAP Logon language
		 * @returns {string} language code
		 * @function
		 * @public
		 */
		getSAPLogonLanguage: function() {
			return sap.ui.getCore().getConfiguration().getSAPLogonLanguage();
		},
		
		/**
		 * Join non-empty strings with separator
		 * @param {string[]} aStrings strings to join
		 * @param {string} sSeparator separator
		 * @returns {string} joined string
		 * @function
		 * @public
		 */
		join: function (aStrings, sSeparator) {
			return (aStrings || []).filter(Boolean).join(sSeparator);
		},
		
		/**
		 * native jQuery.map
		 * @param {object} oObject to iterate
		 * @param {function} fnCallback mapping callback
		 * @returns {any[]} result array
		 * @function
		 * @public
		 */
		map: function (oObject, fnCallback) {
			return Object.keys(oObject || {}).map(function (sKey) {
				var vValue = oObject[sKey];
				return fnCallback ? fnCallback(vValue, sKey) : vValue;
			});
		},
		
		/**
		 * Map items by callback values
		 * @param {any[]} aList list of items
		 * @param {string|function} vPropertyOrCallback property name or callback to get keys
		 * @param {boolean} bKeyReplace if true, replaces the value for duplicated key, otherwise keeps it
		 * @returns {object} key-value mapped items
		 * @function
		 * @public
		 */
		mapBy: function(aList, vPropertyOrCallback, bKeyReplace) {
			var oMap = {},
				fnCallback = vPropertyOrCallback;

			if (typeof fnCallback !== "function") {
				fnCallback = function(oCallbackItem) {
					return oCallbackItem[vPropertyOrCallback];
				};
			}
			aList.forEach(function(oItem) {
				var vKey = fnCallback(oItem);
				if (!(bKeyReplace && oMap.hasOwnProperty(vKey))) {
					oMap[vKey] = oItem;
				}
			});
			return oMap;
		},
		
		/**
		 * Normalize customer number to 10-char length
		 * @param {string} sCustomerNumber customer number
		 * @returns {string} normalized number
		 * @function
		 * @public
		 */
		normalizeCustomerNumber: function (sCustomerNumber) {
			var sNumber = sCustomerNumber || "",
				iLength = sNumber.length || 0;
				
			return "0000000000".slice(iLength) + sNumber;
		},
		
        /**
         * Parse error
         * @param {string} sResponse error response text
         * @returns {sap.support.useradministration.util.ErrorResponse} error response object
         * @function
         * @public
         */
        parseError: function(sResponse) {
            return new ErrorResponse(sResponse);
        },
        
        /**
		 * Create entry in the given model with given options then return native promise
		 * CALL WITH CONTEXT or model object
		 * @param {string} sPath path to create in
		 * @param {object} oData entry to create
		 * @param {object} oOptions options
		 * @param {string|sap.ui.model.Model} vModel model name or instance itself
		 * @returns {Promise} native promise
		 * @function
		 * @private
		 */
		promiseCreate: function(sPath, oData, oOptions, vModel) {
		    var oModel = vModel instanceof sap.ui.model.Model ? vModel : Util.getModel.call(this, vModel);
		    
		    return new Promise(function (resolve, reject) {
				oModel.create(sPath, oData, merge(oOptions, {
					success: resolve,
					error: reject
				}));
			});
		},
        
        /**
		 * Delete entry in the given model with given options then return native promise
		 * CALL WITH CONTEXT or model object
		 * @param {string} sPath path to delete in
		 * @param {object} oOptions options
		 * @param {string|sap.ui.model.Model} vModel model name or instance itself
		 * @returns {Promise} native promise
		 * @function
		 * @private
		 */
		promiseDelete: function(sPath, oOptions, vModel) {
		    var oModel = vModel instanceof sap.ui.model.Model ? vModel : Util.getModel.call(this, vModel);
		    
		    return new Promise(function (resolve, reject) {
				oModel.remove(sPath, merge(oOptions, {
					success: resolve,
					error: reject
				}));
			});
		},
        
        /**
		 * Read data from given model with given options then return native promise
		 * CALL WITH CONTEXT or model object
		 * @param {string} sPath path to read
		 * @param {object} oOptions options
		 * @param {string|sap.ui.model.Model} vModel model name or instance itself
		 * @returns {Promise} native promise
		 * @function
		 * @public
		 */
		promiseRead: function(sPath, oOptions, vModel) {
		    var oModel = vModel instanceof sap.ui.model.Model ? vModel : Util.getModel.call(this, vModel);
		    
		    return new Promise(function (resolve, reject) {
				oModel.read(sPath, merge(oOptions, {
					success: resolve,
					error: reject
				}));
			});
		},
		
		/**
		 * Do backend submit changes in promise
		 * @param {object} vOptions request options
		 * @param {string|sap.ui.model.Model} vModel model name or instance itself
		 * @returns {Promise} promise
		 * @function
		 * @public
		 */
		promiseSubmitChanges: function(vOptions, vModel) {
		    var oModel = vModel instanceof sap.ui.model.Model ? vModel : Util.getModel.call(this, vModel);
		    
			return new Promise(function (resolve, reject) {
				oModel.submitChanges(Util.merge(vOptions || {}, {
					success: resolve,
					error: reject
				}));
			});
		},
		
        /**
		 * Read data from given model with given options then return native promise
		 * CALL WITH CONTEXT or model object
		 * @param {string} sPath path to read
		 * @param {object} oData entry to create
		 * @param {object} oOptions options
		 * @param {string|sap.ui.model.Model} vModel model name or instance itself
		 * @returns {Promise} native promise
		 * @function
		 * @private
		 */
		promiseUpdate: function(sPath, oData, oOptions, vModel) {
		    var oModel = vModel instanceof sap.ui.model.Model ? vModel : Util.getModel.call(this, vModel);
		    
		    return new Promise(function (resolve, reject) {
				oModel.update(sPath, oData, merge(oOptions, {
					success: resolve,
					error: reject
				}));
			});
		},
		
		 /**
		 * Call Function Import with given paramaters
		 * @param {string} sPath path to read
		 * @param {object} oOptions options
		 * @param {string|sap.ui.model.Model} vModel model name or instance itself
		 * @returns {Promise} native promise
		 * @function
		 * @public
		 */
		promiseCallFunction: function(sPath, oOptions,vModel) {
		    var oModel = vModel instanceof sap.ui.model.Model ? vModel : Util.getModel.call(this, vModel);
		    
		    return new Promise(function (resolve, reject) {
				oModel.callFunction(sPath, merge(oOptions, {
					success: resolve,
					error: reject
				}));
			});
		},
		
		promiseAll: function(promises) {
			return new Promise(function (resolve, reject) {
				var count = promises.length,
					aRes = [],
					resolvedCount = 0;
				function checkStatus(data) {
			    	aRes.push(data);
			    	resolvedCount++;
			    	if (resolvedCount === count) {
			        	resolve(aRes);
			    	}
			    }
			    
			    promises.forEach(function(promise)  {
    				promise().then(function (data) {
    					checkStatus(data);
    				}).catch(function(error) {
    					reject(error);
    				});
				});
			});
		},
        
		/**
		 * Read data from given model with given options
		 * @param {string} sPath path to read
		 * @param {object} oOptions options
		 * @param {string|sap.ui.model.Model} vModel model name or instance itself
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		read: function(sPath, oOptions, vModel) {
		    var oPromise = Util.getPromise(),
		    	oModel = vModel instanceof sap.ui.model.Model ? vModel : Util.getModel.call(this, vModel);
		    
		    oModel.read(sPath, jQuery.extend({}, oOptions, {
		        success: function(oData) {
		            oPromise.resolve(oData);
		        },
		        error: function(oError) {
		            oPromise.reject(oError);
		        }
		    }));
		    return oPromise.promise();
		},
		
		/**
		 * Show confirmation box
		 * @param {string} sMessage confirmation message
		 * @param {string} sTitle confirmation box title
		 * @returns {object} promise
		 * @function
		 * @public
		 */
		showConfirmationBox: function(sMessage, sTitle) {
			var oPromise = Util.getPromise();
			MessageBox.confirm(sMessage, {
				title: sTitle,
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						oPromise.resolve();
					} else {
						oPromise.reject();
					}
				}
			});
			return oPromise.promise();
		},
		
		/**
		 * Show confirmation box via native promise
		 * @param {string} sMessage confirmation message
		 * @param {string} sTitle confirmation box title
		 * @returns {object} promise
		 * @function
		 * @public
		 */
		showConfirmationPromiseBox: function(sMessage, sTitle) {
		    return new Promise(function (resolve, reject) {
				MessageBox.confirm(sMessage, {
					title: sTitle,
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							resolve();
						} else {
							reject();
						}
					},
					enableFormattedText: true
				});
			});
		},
		
		showConfirmationPromiseBoxWithCustomAction: function(sMessage, sTitle, sButtonText) {
		    return new Promise(function (resolve, reject) {
				MessageBox.confirm(sMessage, {
					title: sTitle,
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.CANCEL) {
							reject();
						} else {
							resolve();
						}
					},
					actions: [sButtonText, MessageBox.Action.CANCEL],
					emphasizedAction: sButtonText,
					enableFormattedText: true
				});
			});
		},
        /**
         * Show message toast for error response
         * @param {object} oXhr error response
         * @function
         * @public
         */
        showErrorMessageToast: function(oXhr) {
            var oError = Util.parseError(oXhr.responseText || "");
            MessageToast.show(oError.getMessage());
        },
        
        /**
         * Show error message box
         * @param {string} sMessage error message
         * @function
         * @public
         */
        showErrorBox: function(sMessage) {
            Util.Error.display({
                message: Util.getText.call(this, "MISC_ERROR"),
                messageBody: sMessage
            });
        },
        
        /**
         * Show message toast with message
         * @param {string} sMessage message
         * @function
         * @public
         */
        showToast: function(sMessage) {
            MessageToast.show(sMessage);
        },
		
		/**
		 * Show warning box via native promise
		 * @param {string} sMessage confirmation message
		 * @param {string} sTitle confirmation box title
		 * @returns {object} promise
		 * @function
		 * @public
		 */
		showWarningPromiseBox: function(sMessage, sTitle, sButtonText) {
		    return new Promise(function (resolve, reject) {
				sap.m.MessageBox.warning(sMessage, {
					title: sTitle,
					onClose:  function(oAction) {
						if (oAction === sap.m.MessageBox.Action.CANCEL) {
							reject();
						} else {
							resolve();
						}
					},
					emphasizedAction: sButtonText,
					actions: [sButtonText, sap.m.MessageBox.Action.CANCEL]
				});
			});
		},
		
		/**
		 * Split array by filter
		 * @param {any[]} aArray array
		 * @param {function} fnFilter filter function
		 * @returns {object} result
		 */
		splitArray: function (aArray, fnFilter) {
			var aTrueItems = [],
				aFalseItems = [];
				
			aArray.forEach(function (vValue) {
				if (fnFilter(vValue)) {
					aTrueItems.push(vValue);	
				} else {
					aFalseItems.push(vValue);
				}
			});
			
			return {
				trueItems: aTrueItems,
				falseItems: aFalseItems
			};
		},
            
		/**
		 * Run submitChanges for given model with given options
		 * @param {object} oOptions options
		 * @param {string|sap.ui.model.Model} vModel model name or instance itself
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		submitChanges: function(oOptions, vModel) {
		    var oPromise = Util.getPromise(),
		    	oModel = vModel instanceof sap.ui.model.Model ? vModel : Util.getModel.call(this, vModel);
		    
		    oModel.submitChanges(jQuery.extend({}, oOptions, {
		        success: function(oData) {
		            oPromise.resolve(oData);
		        },
		        error: function(oError) {
		            oPromise.reject(oError);
		        }
		    }));
		    return oPromise.promise();
		},
		
		/**
		 * Trim string
		 * @param {string} sString string
		 * @returns {string} trimmed string
		 * @function
		 * @public
		 */
		trimString: function (sString) {
			if (sString && sString.trim) {
				return sString.trim();
			}
			return "";
		},
		
		encodeString: function (sString) {
			if (sString) {
				var sEncoded =  sString.replace(/\&/g, "&amp;")
					.replace(/</g, "&lt;")
					.replace(/>/g, "&gt;")
					.replace(/"/g, "&quot;")
					.replace(/'/g, "&#x27;")
					.replace(/\//g, "&#x2F;");
				return sEncoded;
			}
			return "";
		}
    };
    
    return Util;
});
sap.ui.define([
], function() {
    var _oPhoneNumberRegex = /^[0-9-+\(\)\/]+$/;
    return {
		/**
		 * Extract number without code
		 * @param {string} sPhoneNumber phone number
		 * @returns {string} result
		 * @function
		 * @public
		 */
		dividePhoneNumber: function(sPhoneNumber) {
			var sCleared = sPhoneNumber.replace(/[_+]/g, ""),
				oSearch = /^\d*[- ](\d*)$/.exec(sCleared) || [];
			return oSearch[1] || "";
		},
        
        /**
         * Validate email
         * @param {string} oText string to check
         * @returns {boolean} validation result
         * @function
         * @public
         */
        validateEmail: function(oText, emailRegexp) {
        	var oEmailRegex = new RegExp(emailRegexp, "i");
        	return Boolean(oText && oEmailRegex.test(oText));
        },
        
        /**
         * Validate phone number
         * @param {string} oText string to check
         * @returns {boolean} validation result
         * @function
         * @public
         */
        validatePhoneNumber: function(oText) {
            return Boolean(!oText || _oPhoneNumberRegex.test(oText));
        }
    };
});
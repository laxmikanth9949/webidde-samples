sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function(DateFormat) {
	"use strict";
	
	var _oMediumDate = DateFormat.getDateInstance({
		style: "medium"
	}), _oFilterDate = DateFormat.getDateInstance({
		pattern: "yyyy-MM-dd"
	}), _oStandardDate = DateFormat.getDateInstance({
		pattern: "dd.MM.yyyy"
	}), _oUTCStandardDate = DateFormat.getDateInstance({
		pattern: "dd.MM.yyyy",
		UTC: true
	});
	
	var _sDatePattern = "",
		_oMinExpiryDate = _oStandardDate.parse("21.10.2020"),
		_oShortDateFormat = null;

	/**
	 * Get date format pattern
	 * @returns {string} date format pattern
	 * @function
	 * @private
	 */
	var _getDatePattern = function () {
		if (!_sDatePattern) {
			_sDatePattern = sap.ui.getCore().getConfiguration().getFormatSettings().getDatePattern("medium") || "dd.MM.yyyy";
		}
		return _sDatePattern;
	};

	/**
	 * Get short date format
	 * @returns {sap.ui.core.format.DateFormat} format
	 * @function
	 * @private
	 */
	var _getShortDateFormat = function () {
		if (!_oShortDateFormat) {
			_oShortDateFormat = DateFormat.getDateInstance({
				pattern: _getDatePattern(),
				UTC: true
			});
		}
		return _oShortDateFormat;
	};
	
	var DateUtil = {
		
		getUserProfileDatePattern: _getDatePattern,
		
		/**
		 * Convert date to UTC
		 * @param {Date} oDate date
		 * @returns {Date} UTC date
		 * @function
		 * @public
		 */
		dateToUTCDate: function (oDate) {
			if (oDate && oDate instanceof Date) {
				return _oUTCStandardDate.parse(_oStandardDate.format(oDate));
			}
			return null;
		},
		
		/**
		 * Format date retrieved from the backend
		 * @param {string} sDate backend date
		 * @returns {string} formatted Date
		 * @function
		 * @public
		 */
		formatBackendDate: function(sDate) {
			return DateUtil.formatDate(DateUtil.getDate(sDate));
		},
		
		/**
		 * Format date object
		 * @param {Date} oDate date object
		 * @returns {string} formatted Date
		 * @function
		 * @public
		 */
		formatDate: function (oDate) {
			return oDate ? _oMediumDate.format(oDate) : "";
		},
		
		/**
		 * Format date for filter
		 * @param {Date} oDate date object
		 * @returns {string} formatted filter date
		 * @function
		 * @public
		 */
		formatFilterDate: function (oDate) {
			return oDate ? _oFilterDate.format(oDate) : "";
		},
		
		/**
		 * Format date in short format
		 * @param {Date} oDate date
		 * @returns {string} formatted value
		 * @function
		 * @public
		 */
		formatShortDate: function (oDate) {
			return oDate ? _getShortDateFormat().format(oDate) : "";
		},
		
		/**
		 * Format date in standard UTC format
		 * @param {Date} oDate date
		 * @returns {string} formatted value
		 * @function
		 * @public
		 */
		formatStandardUTCDate: function (oDate) {
			return oDate ? _oUTCStandardDate.format(oDate) : "";
		},
		
		/**
		 * Get date retrieved from the backend
		 * @param {string} sDate backend date
		 * @returns {Date|null} date object or null
		 * @function
		 * @public
		 */
		getDate: function (sDate) {
			var oDate = sDate && new Date(sDate);
			return oDate && !isNaN(oDate.getTime()) ? oDate : null;
		},
	    
	    /**
	     * Get minimal possible expiry date
	     * @param {Date} [oMinDate] pre-defined min date
	     * @returns {Date} date
	     * @function
	     * @public
	     */
	    getMinExpiryDate: function (oMinDate) {
	    	var oDate = oMinDate || new Date();
	    	
	    	return oDate > _oMinExpiryDate ? oDate : _oMinExpiryDate;
	    },
	    
	    /**
	     * Check if two dates are in the same day
	     * @param {Date} oFirstDate first date
	     * @param {Date} oSecondDate second date
	     * @returns {boolean} check result
	     * @function
	     * @public
	     */
	    isSameDay: function (oFirstDate, oSecondDate) {
	    	return DateUtil.formatDate(oFirstDate) === DateUtil.formatDate(oSecondDate);
	    },
		
		/**
		 * Shift date to some years
		 * @param {object} oDate date
		 * @param {int} [iYears] years to add
		 * @param {int} [iMonths] months to add
		 * @param {int} [iDays] days to add
		 * @returns {Date} changed date
		 * @function
		 * @public
		 */
		shiftDate: function (oDate, iYears, iMonths, iDays) {
			if (oDate) {
				var oBackup = new Date(oDate);
				
				if (iYears) {
					oBackup.setFullYear(oBackup.getFullYear() + iYears);
				}
				
				if (iMonths) {
					oBackup.setMonth(oBackup.getMonth() + iMonths);
				}
				
				if (iDays) {
					oBackup.setDate(oBackup.getDate() + iDays);
				}
				
				return oBackup;
			}
			return null;
		},
		
		/**
		 * Convert UTC date to normal one
		 * @param {Date} oDate UTC date
		 * @returns {Date} date
		 * @function
		 * @public
		 */
		utcDateToDate: function (oDate) {
			if (oDate && oDate instanceof Date) {
				return _oStandardDate.parse(_oUTCStandardDate.format(oDate));
			}
			return null;
		}
	};
	
	return DateUtil;
});
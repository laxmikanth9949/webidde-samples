sap.ui.define([
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/model/Constant"
], function (Util, Constant) {

	var Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator;

	var aSharedEmails = [],
		aProcessedEmails = [];

	var _result = {
		bEmailValid: true,
		bEmailFormatValid: true,
		bEmailShared: false,
		bEmailDuplicate: false,

		init: function () {
			this.setEmailValid();
		},

		setEmailValid: function () {
			this.bEmailValid = true;
			this.bEmailFormatValid = true;
			this.bEmailShared = false;
			this.bEmailDuplicate = false;
		},

		setEmailFormatIncorrect: function () {
			this.bEmailValid = false;
			this.bEmailFormatValid = false;
		},

		setEmailFormatCorrect: function () {
			this.bEmailFormatValid = true;
		},

		setEmailShared: function () {
			this.bEmailValid = false;
			this.bEmailShared = true;
		},

		setEmailDuplicate: function () {
			this.bEmailValid = false;
			this.bEmailDuplicate = true;
		},

		isEmailValid: function () {
			return this.bEmailValid;
		},

		isEmailFormatValid: function () {
			return this.bEmailFormatValid;
		},

		isEmailFormatNotValid: function () {
			return !this.bEmailFormatValid;
		},

		isEmailDuplicate: function () {
			return this.bEmailDuplicate;
		},

		isEmailShared: function () {
			return this.bEmailShared;
		}

	};

	var _sEmail = "",
		_sCustomerNumber = "";

	function _setEmail(sEmail) {
		_sEmail = sEmail;
	}

	function _getEmail() {
		return _sEmail;
	}

	function _setCustomerNumber(sCustomerNumber) {
		_sCustomerNumber = sCustomerNumber;
	}

	function _getCustomerNumber() {
		return _sCustomerNumber;
	}

	function _isFormatValid() {
		var sEmail = _getEmail(),
			emailRegexp = this.getView().getModel("appSettings").oData.emailRegexp;

		return Util.detail.validateEmail(sEmail, emailRegexp);
	}

	function _isEmailInbuffer() {
		var sEmail = _getEmail(),
			sLocalPart = sEmail.split("@")[0].toUpperCase();
		return aProcessedEmails.includes(sLocalPart);
	}

	function _isSharedEmail() {
		var sEmail = _getEmail(),
			sLocalPart = sEmail.split("@")[0].toUpperCase();
		return aSharedEmails.includes(sLocalPart);
	}

	function _fetchSharedEmails() {
		var oPromise = {};
		var sEmail = _getEmail(),
			sLocalPart = sEmail.split("@")[0].toUpperCase();

		if (!_isEmailInbuffer.call(this, sLocalPart)) {
			oPromise = Util.promiseRead.call(this, "/SharedMailsSet", {
					filters: [new Filter("EMail", FilterOperator.EQ, sLocalPart)]
				})
				.then(function (oData) {
					aProcessedEmails.push(sLocalPart);
					if (oData.results.length > 0) {
						aSharedEmails.push(sLocalPart);
					}
				});
		} else {
			oPromise = new Promise(function (resolve) {
				resolve();
			});

		}
		return oPromise;
	}

	function _isEmailDuplicate() {
		var oPromise = {};
		var sEmail = _getEmail(),
			sKunnr = _getCustomerNumber();

		var isDuplicateCheckEnabled = this.getSettings().emailDuplicateCheck;

		var oFunctionParamsIsDuplicateEmail = {
			method: "GET",
			urlParameters: {
				Ipadr: sEmail,
				Kunnr: sKunnr
			},
			refreshAfterChange: true
		};

		if (isDuplicateCheckEnabled) {
			oPromise = Util.promiseCallFunction.call(this, Constant.Functions.IsEmailDuplicate, oFunctionParamsIsDuplicateEmail, this.getView()
				.getModel());

		} else {
			oPromise = new Promise(function (resolve) {
				setTimeout(function () {
					resolve(Constant.Response.NotDuplicateEmail);
				}, 200);
			});
		}

		return oPromise;
	}

	return {

		validate: function (sEmail, sCustomerNumber, bRunDuplicateCheck) {
			var oPromise = {};
			_setEmail(sEmail);
			_setCustomerNumber(sCustomerNumber);
			_result.init();

			if (!_isFormatValid.call(this)) {
				oPromise = new Promise(function (resolve) {
					_result.setEmailFormatIncorrect();
					setTimeout(function () {
						resolve(_result);
					}, 200);
				});
			} else {
				_result.setEmailFormatCorrect();
				oPromise = new Promise(function (resolve) {
					_fetchSharedEmails.call(this)
						.then(function () {
							if (_isSharedEmail()) {
								_result.setEmailShared();
								setTimeout(function () {
									resolve(_result);
								}, 200);
							} else {
								if (bRunDuplicateCheck && sCustomerNumber) {
									_isEmailDuplicate.call(this).then(function (oResult) {
										var bIsuplicateEmail = oResult.IsEmailDuplicate.boolValue;
										if (bIsuplicateEmail) {
											_result.setEmailDuplicate();
										} else {
											_result.setEmailValid();
										}
										setTimeout(function () {
											resolve(_result);
										}, 200);
									});
								} else {
									_result.setEmailValid();
									setTimeout(function () {
										resolve(_result);
									}, 200);
								}
							}
						}.bind(this));
				}.bind(this));
			}
			return oPromise;
		}
	};
});
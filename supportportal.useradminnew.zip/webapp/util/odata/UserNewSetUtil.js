sap.ui.define([
    "sap/support/useradministration/util/Util"
], function (Util) {
	var MODEL_NAME;
	
	var Filter = sap.ui.model.Filter;
	
	var bUserNewSetEnabled = false,
		oRawMapping = { // First for UserSet, second for UserNewSet. If just one provided, use it for both options
			UserId: ["Susid"], // User's ID
			
			CountryCode: ["Land1"], // User's country code
			CountryName: ["Land1T"], // User's country name
			CreatedOnDate: ["Erdat"], // Date when user has been created
			CustomerAddress: ["KunnrStras"], // User's customer address (house and street)
			CustomerCity: ["KunnrCity"], // User's customer city
			CustomerId: ["Kunnr"], // User's customer ID
			CustomerName: ["KunnrName"], // User's customer name
			CustomerPostalCode: ["KunnrPstlz"], // User's customer postal code
			DepartmentId: ["DepartmentId"], // User's department ID
			DepartmentName: ["Department"], // User's department name
			EmailDomain: ["EmailDomain"], // User's domain
			Email: ["Ipadr"], // User's E-mail address
			ExpiryDate: ["ExpDate"], // Date when user will be expired
			ExpiryStatus: ["Status"], // Expiry status like Active, Expired, etc.
			ExtensionRequestedOnDate: ["ExtendReqOn"], // Date when extention of the user has been requested
			FirstName: ["Namev"], // User's first name
			FirstPhoneCountryId: ["CountryOtherContact"], // Country ID for user's first phone number
			FirstPhoneNumber: ["Handy"], // First phone number
			FlagDialogSearch: ["Tmpfx"], // A flag used to search users from Copy Authorizations dialog in user detail
			Function: ["UserCriticalRoleID"], // User's function - useradmin, superadmin, etc.
			IsAuthorizedToEdit: ["EditAuthority"], // If user can be edited
			IsCustomerHasUid: ["CustHasUid"], // Flag if user's customer has Universal ID connected
			IsImportantRolesAssigned: ["UserCriticalRole"], // Flag if important functions are assigned
			IsUidAssigned: ["IsUidAssigned"], // Flag if Universal ID is assigned to current user
			JobTitle: ["JobTitle"], // User's job title
			LanguageCode: ["ParlaExt"], // User's language code
			LanguageName: ["ParlaT"], // User's language name
			LastLogonDate: ["Trdat"], // Date of user's last logon
			LastName: ["Name1"], // User's last name
			Notes: ["Notes"], // Notes
			ReqExpDate: ["ReqExpDate"], // Requested expiry date
			RequesterId: ["Ernam"], // ID of current user's requester
			RequesterName: ["ChangedByName"], // Name of current user's requester
			Salutation: ["Anred"], // Salutation like Mr. or Ms.
			SecondPhoneCode: ["CountryTelCode2"], // Country code for user's first phone number
			SecondPhoneCountryId: ["CountryTelContact2"], // Country ID for user's second phone number
			SecondPhoneNumber: ["Phone2"], // First phone number
			UserType: ["UserType"], // User's type (Customer or Partner)
			IsValidDomain: ["IsValidDomain"] // Is e-Mail valid
			
		},
		oRawAggregationMapping = {
			ExistUserAuthObjectListSet: ["ExistUserAuthObjectListSet"],
			UserAuthorizationObjectSet: ["UserAuthorizationObjectSet"],
			UserExistingAuthorizationsSet: ["UserExistingAuthorizationsSet"],
			UserImportantRoleSet: ["UserImportantRoleSet"],
			
			Authorizations: ["UserAuthObjectSet"] // User's authorization list
		},
		oFrontToBack = {},
		oBackToFront = {},
		oFrontToBackAggregation = {},
		oBackToFrontAggregation = {},
		aAggregations = [];
	
	
	var _extractResults = function (oData) {
		return oData && oData.results || [];	
	};
	
	/**
	 * Utility to switch between old UserSet and refactored UserNewSet
	 */
	var UserNewSetUtil = {
		
		/**
		 * Set UserNewSet enabled state
		 * @param {boolean} bIsUserNewSetEnabled if UserNewSet is enabled
		 * @function
		 * @public
		 */
		init: function (bIsUserNewSetEnabled) {
			bUserNewSetEnabled = !!bIsUserNewSetEnabled;
			
			UserNewSetUtil._initMappings();
		},
		
		/**
		 * Initialize mapping of frontend fields to backend ones and vice versa
		 * @function
		 * @private
		 */
		_initMappings: function () {
			Util.each(oRawMapping, function (vBackProp, sFrontPropName) {
				// Choose first
				var sBackPropName = (bUserNewSetEnabled && vBackProp[1]) || vBackProp[0];
				
				oFrontToBack[sFrontPropName] = sBackPropName;
				oBackToFront[sBackPropName] = sFrontPropName;
			});
			Util.each(oRawAggregationMapping, function (vBackAgg, sFrontAggName) {
				var sBackAggName = (bUserNewSetEnabled && vBackAgg[1]) || vBackAgg[0];
				
				oFrontToBackAggregation[sFrontAggName] = sBackAggName;
				oBackToFrontAggregation[sBackAggName] = sFrontAggName;
			});
			aAggregations = Object.keys(oBackToFrontAggregation);
		},
		
		/**
		 * Clear aggregation data from the entry to be sent to backend
		 * Made to prevent request crash
		 * @param {object} oBackendEntry entry, will be modified
		 * @returns {object} modified entry
		 * @function
		 * @public
		 */
		clearAggregations: function (oBackendEntry) {
			aAggregations.forEach(function (sAggregationName) {
				delete oBackendEntry[sAggregationName];
			});
			return oBackendEntry;
		},
    	
    	/**
    	 * Extract raw list of authorization objects from backend entry
    	 * @param {object} oBackendEntry backend entry
    	 * @returns {object[]} list
    	 * @function
    	 * @public
    	 */
    	extractAuthorizationsRawList: function (oBackendEntry) {
    		var vResults = oBackendEntry[UserNewSetUtil.getBackendAggregation("Authorizations")] || [];
    		
    		if (Array.isArray(vResults)) {
    			return vResults || [];
    		} else {
    			return vResults.results || vResults.__list || [];
    		}
    	},
    	
    	/**
    	 * Extract user ID from backend entry
    	 * @param {object} oBackendEntry backend entry
    	 * @returns {string} user ID
    	 * @function
    	 * @public
    	 */
    	extractUserId: function (oBackendEntry) {
    		return oBackendEntry[UserNewSetUtil.getBackendProperty("UserId")];
    	},
    	
    	/**
    	 * Get backend aggregation name by frontend one
    	 * @param {string} sFrontEndAggregationName frontend aggregation name
    	 * @returns {string} backend aggregation name
    	 * @function
    	 * @public
    	 */
    	getBackendAggregation: function (sFrontEndAggregationName) {
    		return oFrontToBackAggregation[sFrontEndAggregationName] || sFrontEndAggregationName;
    	},
    	
    	/**
    	 * Create filter to backend
    	 * @param {string} sFrontEndPropertyName frontend property name
    	 * @param {sap.ui.model.FilterOperator} sFilterOperator filter operator
    	 * @param {any} vValue1 value to compare
    	 * @param {any} [vValue2] second value to compare
    	 * @returns {sap.ui.model.Filter} filter
    	 * @function
    	 * @public
    	 */
    	getBackendFilter: function (sFrontEndPropertyName, sFilterOperator, vValue1, vValue2) {
    		var sBackendPropertyName = UserNewSetUtil.getBackendProperty(sFrontEndPropertyName);
    		return new Filter(sBackendPropertyName, sFilterOperator, vValue1, vValue2);
    	},
    	
    	/**
    	 * Get backend property name by frontend one
    	 * @param {string} sFrontEndPropertyName frontend property name
    	 * @returns {string} backend property name
    	 * @function
    	 * @public
    	 */
    	getBackendProperty: function (sFrontEndPropertyName) {
    		return oFrontToBack[sFrontEndPropertyName] || sFrontEndPropertyName;
    	},
    	
    	/**
    	 * Get frontend aggregation name by backend one
    	 * @param {string} sBackEndAggregationName backend aggregation name
    	 * @returns {string} frontend aggregation name
    	 * @function
    	 * @public
    	 */
    	getFrontendAggregation: function (sBackEndAggregationName) {
    		return oBackToFrontAggregation[sBackEndAggregationName] || sBackEndAggregationName;
    	},
    	
    	/**
    	 * Get frontend property name by backend one
    	 * @param {string} sBackEndPropertyName backend property name
    	 * @returns {string} frontend property name
    	 * @function
    	 * @public
    	 */
    	getFrontendProperty: function (sBackEndPropertyName) {
    		return oBackToFront[sBackEndPropertyName] || sBackEndPropertyName;
    	},
    	
    	/**
    	 * Get path to the UserSet
    	 * @returns {string} path
    	 * @function
    	 * @public
    	 */
    	getUserSetPath: function () {
    		return bUserNewSetEnabled ? "/UserNewSet" : "/UserSet";
    	},
    	
    	/**
    	 * Get path to the UserSet single entity
    	 * @param {string} sUserId user ID
    	 * @returns {string} path
    	 * @function
    	 * @public
    	 */
    	getUserSetPathWithParams: function (sUserId) {
    		var sPath = UserNewSetUtil.getUserSetPath();
    		
    		return Util.formatMessage(sPath + "(''{0}'')", [sUserId]);
    	},
		
    	/**
    	 * Check if refactored UserNewSet is enabled
    	 * @returns {boolean} check result
    	 * @function
    	 * @public
    	 */
    	isUserNewSetEnabled: function () {
    		return !!bUserNewSetEnabled;
    	},
    	
		/**
		 * Read existing authorizations for specific user
		 * CALL WITH CONTEXT
		 * @param {string} sUserId User ID
		 * @returns {Promise} promise
		 * @function
		 * @public
		 */
		readExistingAuthorizations: function (sUserId) {
			var sPath = UserNewSetUtil.getUserSetPathWithParams(sUserId) + "/UserExistingAuthorizationsSet";
			
			return Util.promiseRead.call(this, sPath, {}, MODEL_NAME)
				.then(_extractResults);
		},
		
		/**
		 * Read authorization objects for specific user
		 * CALL WITH CONTEXT
		 * @param {string} sUserId User ID
		 * @returns {Promise} promise
		 * @function
		 * @public
		 */
		readAuthObjectSet: function (sUserId, oParams) {
			var sPath = UserNewSetUtil.getUserSetPathWithParams(sUserId) + "/UserAuthObjectSet",
				oRequsetParam = oParams || {};
			
			return Util.promiseRead.call(this, sPath, oRequsetParam, MODEL_NAME)
				.then(_extractResults);
		},
    	
    	/**
    	 * Convert frontend entry to backend one
    	 * @param {object} oFrontendEntry frontend entry
    	 * @returns {object} backend entry
    	 * @function
    	 * @public
    	 */
    	toBackendEntry: function (oFrontendEntry) {
    		var oEntry = {};
    		
    		Util.each(oFrontendEntry, function (vValue, sKey) {
    			var sPropName =	oFrontToBack[sKey] || sKey;
    			oEntry[sPropName] = vValue;
    		});
    		return oEntry;
    	},
    	
    	/**
    	 * Convert backend entry to frontend one
    	 * @param {object} oBackendEntry backend entry
    	 * @returns {object} frontend entry
    	 * @function
    	 * @public
    	 */
    	toFrontendEntry: function (oBackendEntry) {
    		var oEntry = Util.copy(oBackendEntry);
    		
    		Util.each(oBackendEntry, function (vValue, sKey) {
    			var sPropName =	oBackToFront[sKey];
    			
    			if (sPropName) {
    				oEntry[sPropName] = vValue;
    			}
    		});
    		return oEntry;
    	},
    	
    	/**
    	 * Update user data
		 * CALL WITH CONTEXT
    	 * @param {string} sPath path of the user entry
    	 * @param {object} oUser frontend data of the user entity
		 * @returns {Promise} promise
		 * @function
		 * @public
		 */
    	updateUser: function (sPath, oUser) {
    		var oModel = this.getModel(MODEL_NAME),
    			oBackendUser = Util.merge({}, oModel.getProperty(sPath), UserNewSetUtil.toBackendEntry(oUser));
    		
    		UserNewSetUtil.clearAggregations(oBackendUser);
			return Util.promiseUpdate(sPath, oBackendUser, {}, oModel);
    	}
	};
	
	return UserNewSetUtil;
});
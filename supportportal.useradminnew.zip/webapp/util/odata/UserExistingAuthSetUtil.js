sap.ui.define([
    "sap/support/useradministration/util/Util",
    "sap/support/useradministration/util/odata/UserNewSetUtil"
], function (Util, UserNewSetUtil) {
	
	var _extractResults = function (oData) {
		return oData && oData.results || [];	
	};
	
	/**
	 * Utility for UserExistingAuthorizationsSet
	 */
	var UserExistingAuthSetUtil = {
		/**
		 * Read existing authorizations for specific user
		 * CALL WITH CONTEXT
		 * @param {string} sUserId User ID
		 * @returns {Promise} promise
		 * @function
		 * @public
		 */
		readForUser: function (sUserId) {
			var sPath = UserNewSetUtil.getUserSetPathWithParams(sUserId) + "/UserExistingAuthorizationsSet";
			
			return Util.promiseRead.call(this, sPath, {})
				.then(_extractResults);
		}
	};
	
	return UserExistingAuthSetUtil;
});
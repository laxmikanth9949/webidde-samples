sap.ui.define([
    "sap/support/useradministration/util/odata/UserExistingAuthSetUtil",
    "sap/support/useradministration/util/odata/UserNewSetUtil"
], function (UserExistingAuthSetUtil, UserNewSetUtil) {
	
	return {
		UserExistingAuthSet: UserExistingAuthSetUtil,
		UserNewSet: UserNewSetUtil,
		UserSet: UserNewSetUtil,
		
		/**
		 * Set UserNewSet enabled state
		 * @param {boolean} bIsUserNewSetEnabled if UserNewSet is enabled
		 * @function
		 * @public
		 */
		init: function (bIsUserNewSetEnabled) {
			UserNewSetUtil.init(bIsUserNewSetEnabled);
		}
	};
});
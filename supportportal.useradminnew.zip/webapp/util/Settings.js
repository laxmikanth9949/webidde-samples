sap.ui.define([
], function () {
	"use strict";
	
	return {
		isNewDepartmentAPIEnabled: true,
		isSelfAuthorizationRequestVisible: true,
		isSUserLifetimeEnabled: true,
		/*isSettingsTabEnabled: true,*/
		isServicesSettingsDialogEnabled: true, // Enable Manage Services dialog and Self-Auth Request settings
		isAuthorizationAssignmentHistoryEnabled: true,
		isSharedEmailCheckEnabled: true,
		isDuplicateEmailCheckEnabled: false,
		maxYearsForUserCreation: 2, // A maximum date to set expiry date for new user is today + N years
		maxYearsForUserExtension: 5, // A maximum date to extend user's expiry is today + N years
		maxYearsForMassExtension: 2, // A maximum date to mass extend user's expiry is today + N years
		prefilledYearsForUserCreation: 2, // A pre-filled date to set new user's expiry is today + N years
		prefilledYearsForUserExtension: 1, // A pre-filled date to extend user's expiry is today + N years
		maxUsersAllowedForMassUserExtentions: 500,
		isAPCopyDialogEnabled: true,
		isRequestedAuthObjectEnabled: true,
		isRequestUserPageEnabled: true,
		maxFilterCount: 20,
		isAdditionalNoteEnabled: true,
		isNoPermissionAuthorizationsEnabled: true,
		isExpDateHistoryEnabled: true,
		userDetailView:{
			emailDuplicateCheck: true
		},
		requestUserView: {
			emailDuplicateCheck: true
		}
	};
});

sap.ui.define([
	"sap/ui/base/Object"
], function(BaseObject) {
	"use strict";

	var TYPE_XML = "xml",
		TYPE_JSON = "json",
		TYPE_HTML = "html",
		TYPE_TEXT = "text";

	/**
	 * Parse error response
	 * @param {string} sResponse response
	 * @returns {Node|object|string} parsed error
	 * @function
	 * @private
	 */
	var _parse = function(sResponse) {
		if (sResponse[0] === "{") {
			try {
				return JSON.parse(sResponse);
			} catch (e) {
				jQuery.sap.log.warning("Not a valid JSON");
			}
		} else if (sResponse[0] === "<") {
			try {
				return $.parseXML(sResponse);
			} catch (e) {
				jQuery.sap.log.warning("Not a valid XML");
			}
		}
		return $.parseHTML(sResponse);
	};

	/**
	 * An object that contains info about error response
	 * @class
	 * @extends sap.ui.base.Object
	 * @alias sap.support.useradministration.util.ErrorResponse
	 */
	return BaseObject.extend("sap.support.useradministration.util.ErrorResponse", {
		constructor: function(sResponseText) {
			this._iCode = null;
			this._sTitle = "";
			this._vContent = _parse(sResponseText);
			if (this._vContent instanceof Node) {
				var oDocument = this._vContent.firstChild,
					oMessageNode = oDocument && oDocument.getElementsByTagName("message")[0],
					oTextNode = oMessageNode && oMessageNode.firstChild;
				this._sMessage = oTextNode && oTextNode.nodeValue || "";
				this._sType = TYPE_XML;
			} else if (this._vContent instanceof Array) {
				var sText = this._vContent.map(function(oNode) {
						if (oNode.nodeType === 3) {
							return oNode.nodeValue;
						}
					}).filter(Boolean).join(" "),
					sTitle = $(this._vContent).filter("title").text();

				this._sMessage = sText || "";
				this._sTitle = sTitle || "";
				this._sType = TYPE_HTML;
			} else if (this._vContent instanceof Object) {
				var oError = this._vContent.error;
				this._sMessage = oError && oError.message && oError.message.value;
				this._iCode = oError && oError.code;
				this._sType = TYPE_JSON;
			} else {
				this._sMessage = this._vContent;
				this._sType = TYPE_TEXT;
			}
		},

		/**
		 * Get code of JSON error
		 * @returns {string} error code or null
		 * @function
		 * @public
		 */
		getCode: function() {
			return this._iCode;
		},

		/**
		 * @returns {Node|object|string} content
		 * @function
		 * @public
		 */
		getContent: function() {
			return this._vContent;
		},

		/**
		 * Get error message
		 * @returns {string} error message
		 * @function
		 * @public
		 */
		getMessage: function() {
			return this._sMessage;
		},

		/**
		 * Get error title
		 * @returns {string} error title
		 * @function
		 * @public
		 */
		getTitle: function() {
			return this._sTitle;
		},

		/**
		 * @returns {boolean} if response type is HTML
		 * @function
		 * @public
		 */
		isHTML: function() {
			return this._sType === TYPE_HTML;
		},
		
		/**
		 * @returns {boolean} if response type is JSON
		 * @function
		 * @public
		 */
		isJSON: function() {
			return this._sType === TYPE_JSON;
		},

		/**
		 * @returns {boolean} if response type is XML
		 * @function
		 * @public
		 */
		isXML: function() {
			return this._sType === TYPE_XML;
		}
	});
});
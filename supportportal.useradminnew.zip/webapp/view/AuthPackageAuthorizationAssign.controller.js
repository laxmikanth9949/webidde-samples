sap.ui.define([
    "sap/support/useradministration/controller/BaseController",
    "sap/m/MessageBox",
    
    "sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/model/Constant",
    "sap/support/useradministration/util/Util",
    
    "sap/ui/comp/filterbar/FilterBar"
], function(Controller, MessageBox, Dialogs, Constant, Util) {
    
    var Callbacks = Util.callbacks;
    
    var ROUTE = "packAuthorizationAssign",
        MODEL = "ap";

return Controller.extend("sap.support.useradministration.view.AuthPackageAuthorizationAssign", {
	onInit: function () {
		this._attachRouteMatched();

	    this._aKeys = ["AuthLevel", "AuthLevelDesc"];
		this._oDialogs = new Dialogs(this);
		
		this._bindViewModel("APDetail");
	    this._attachBusEvent("updateLevels", this._updateLevels.bind(this));
	},
	
	/**
	 * Attach route matched
	 * @function
	 * @private
	 */
	_attachRouteMatched: function () {
		var oView = this.getView();
		
		sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function(evt) {
			this._sCurrentRoute = evt.getParameter("name");
			
			oView.setBusy(true);
			
			if (evt.getParameter("name") === ROUTE) {
				var oArgs = evt.getParameter("arguments"),
			        sPath = "/AuthObjectSet(PackageId='" + oArgs.pack + "',ObjectId='" + oArgs.object + "')",
			        sFullPath = MODEL ? MODEL + ">" + sPath : sPath;
			        
			    if (!oView.getElementBinding(MODEL) || oView.getElementBinding(MODEL).getPath() !== sPath) {
    				oView.bindElement(sFullPath, {
    				    expand: "AuthObjectAuthLevelSet"
    				});
    				oView.getElementBinding(MODEL).refresh();
    			    oView.getElementBinding(MODEL).attachDataReceived(this._resetAuthDetails.bind(this));
				} else if (this._getViewProperty("Auth/Edit")) {
					oView.getElementBinding(MODEL).refresh();
				    this._resetAuthDetails();
				}
				
				if (!this._getViewProperty("Auth/Edit")) {
    				oView.setBusy(true);
					oView.getElementBinding(MODEL).refresh();
				}
			}
		}, this);
	},

	/**
	 * Attach EventBus event
	 * @param {string} sEventName event name
	 * @param {function} fnHander event handler
	 * @function
	 * @private
	 */
	_attachBusEvent: function(sEventName, fnHander) {
        this.getOwnerComponent().getEventBus().subscribe("APDetail", sEventName, fnHander);
	},
	
    /**
     * Get extended copy of authorization level object
     * @param {object} oLevel level object
     * @returns {object} extended object
     * @function
     * @private
     */
	_extendAuthorizationLevelObject: function(oLevel) {
	    return jQuery.extend(true, {}, oLevel);
	},
	
	/**
	 * Reset authorizations List and package data in view model
	 * @param {sap.ui.base.Event} oEvent event data
	 * @function
	 * @private
	 */
	_resetAuthDetails: function() {
	   var  oContext = this.getView().getBindingContext(MODEL),
			oDetail = this._getViewProperty("Auth/Detail"),
	        aURIList = oContext.getProperty("AuthObjectAuthLevelSet") || [],
	        aAuthLevelList = aURIList.map(function (sURI) {
	            return oContext.getModel().getProperty("/" + sURI);
	        }).map(this._extendAuthorizationLevelObject.bind(this));
	    if (oDetail && !oDetail.Customers) {    
        	this._setViewProperty("Auth/Detail/Customers", aAuthLevelList.filter(this.formatter.detail.isCustomerLevel));
        	this._setViewProperty("Auth/Detail/Installations", aAuthLevelList.filter(this.formatter.detail.isInstallationOrUserLevel));
	    }
    	this.getView().setBusy(false);
	},
	
	/**
	 * Trigger EventBus event
	 * @param {string} sEventName event name
	 * @function
	 * @private
	 */
	_triggerBusEvent: function(sEventName) {
        this.getOwnerComponent().getEventBus().publish("APDetail", sEventName);
	},
		
    	
	/**
	 * Update auth levels
	 * @function
	 * @private
	 */
	_updateLevels: function() {
	    var oBinding = this.getView().getElementBinding(MODEL);
	    if (oBinding && this._sCurrentRoute === ROUTE) {
	        oBinding.refresh();
	    }
	},
	
	/**
	 * Set "Granted All" switch to true
	 * @function
	 * @public
	 */
	grantAll: function() {
	    this._setViewProperty("Auth/Detail/TempSelected", true);
	    this._triggerBusEvent("authTopLevelChange");
	},
	
	/**
	 * Edit restricted customers list
	 * @event
	 * @public
	 */
	onEditCustomers: function() {
        var oContext = this.getView().getBindingContext(MODEL),
            oDialog = this._oDialogs.getDialog("SelectRestrictedCustomers"),
            aTokens = this._getViewProperty("Auth/Detail/Customers").map(function (oLevel) {
			    return new sap.m.Token({
					key: oLevel.AuthLevel,
					text: oLevel.AuthLevelDesc + " (" + oLevel.AuthLevel + ")"
			    });
			});
        oDialog.setModelName(MODEL);
        oDialog.setContext(oContext.getPath());
        oDialog.setTokens(aTokens);
        oDialog.syncStyleClass();
        oDialog.open();
	},
	
	/**
	 * Handle top level switch state change
	 * Send auth to the Detail controller
	 * @param {sap.ui.base.Event} oEvent event
	 * @event
	 * @public
	 */
	onTopLevelSwitchChange: function(oEvent) {
	    this._setViewProperty("Auth/Detail/TempSelected", oEvent.getSource().getSelected());
	    this._triggerBusEvent("authTopLevelChange");
	},

	/**
	 * Append customers in the customers table 
	 * @param {object[]} aCustomers selected customers
	 * @function
	 * @public
	 */
	appendCustomers: function(aCustomers) {
	    var aExisting = this._getViewProperty("Auth/Detail/Customers") || [],
	        oExisting = Util.combineArray(aExisting, Callbacks.getKey("AuthLevel"), true);
	    
	    aCustomers.forEach(function(oCustomer) {
	        if (!oExisting[oCustomer.AuthLevel]) {
	            aExisting.push(oCustomer);   
	        }
	    });
	    this._setViewProperty("Auth/Detail/Customers", aExisting);
		this._triggerBusEvent("authDetailsChange");
	},
	
	/**
	 * Save customers to the customer table
	 * @param {object[]} aCustomers selected customers
	 * @function
	 * @public
	 */
	saveCustomers: function(aCustomers) {
	    this._setViewProperty("Auth/Detail/Customers", aCustomers);
		this._triggerBusEvent("authDetailsChange");
	},
	
	/**
	 * Save installations to the installation table
	 * @param {object[]} aInstallations selected installations
	 * @function
	 * @public
	 */
	saveInstallations: function(aInstallations) {
	    var aCustomers = this._getViewProperty("Auth/Detail/Customers") || [],
	        oCustomers = Util.combineArray(aCustomers, Callbacks.getKey("AuthLevel"), true),
	        bCrossCustomer = aInstallations && aInstallations.some(function (oInstallation) {
		        return oCustomers[oInstallation.CustNum];
		    });
	    
	    this._setViewProperty("Auth/Detail/Installations", aInstallations);
	    if (bCrossCustomer) {
			sap.m.MessageBox.show(this.getBundle().getText("AUTHORIZATION_LEVEL_CUST_SELECTED"), {
				icon: sap.m.MessageBox.Icon.INFORMATION,
				title: this.getBundle().getText("HELP_TITLE"),
				actions: [sap.m.MessageBox.Action.CLOSE]
			});
	    }
		this._triggerBusEvent("authDetailsChange");
	},
	
	/**
	 * Edit restricted installations list
	 * @event
	 * @public
	 */
	onEditInstallations: function() {
        var oContext = this.getView().getBindingContext(MODEL),
            oDialog = this._oDialogs.getDialog("SelectRestrictedInstallations"),
            aTokens = this._getViewProperty("Auth/Detail/Installations").map(function (oLevel) {
			    return new sap.m.Token({
					key: oLevel.AuthLevel,
					text: oLevel.AuthLevelDesc + " (" + oLevel.AuthLevel + ")"
			    });
			});
        
        oDialog.setModelName(MODEL);
        oDialog.setAuthObjectData(oContext.getObject());
        oDialog.setContext(oContext.getPath());
        oDialog.setTokens(aTokens);
        oDialog.setUsersMode(oContext.getProperty("AuthLevelId") === Constant.AuthLevelId.USER);
        oDialog.syncStyleClass();
        oDialog.open();
	},
	
	onRemoveCustPress: function (oEvent) {
			var aCustomers = this._getViewProperty("Auth/Detail/Customers");
			aCustomers.splice(this._getRowIndex(oEvent), 1);
			this._setViewProperty("Auth/Detail/Customer", aCustomers);
			this._triggerBusEvent("authDetailsChange");
		},
		
		onRemoveInstallPress: function (oEvent) {
			var aInsallations = this._getViewProperty("Auth/Detail/Installations");
			aInsallations.splice(this._getRowIndex(oEvent), 1);
			this._setViewProperty("Auth/Detail/Installations", aInsallations);
			this._triggerBusEvent("authDetailsChange");
		},
		
		_getRowIndex: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContextPath();
			var aPathParts = sPath.split("/");
			return aPathParts[aPathParts.length - 1];
		}
    });
});
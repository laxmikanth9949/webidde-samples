sap.ui.define([
	"sap/support/useradministration/controller/BaseController",

	"sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/extended/HashChecker",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/extended/SmartTable"
], function (BaseController, Dialogs, HashChecker, Constant, Util, SmartTable) {
	"use strict";
	
	var AUTH_PACK_DETAIL_ROUTE = "authPackageDetail",
		AUTH_PACK_VIEW_ROUTE = "authPackageView";

	return BaseController.extend("sap.support.useradministration.view.AuthPackageDetail", {
		onInit: function () {
			this._aKeys = ["AuthLevel", "AuthLevelDesc"];
			this._oDialogs = new Dialogs(this);

			this._bindViewModel("APDetail");
			this._attachRouteMatched();
			this._oHashChecker = new HashChecker(this.getRouter());
			this._attachBusEvent("authTopLevelChange", this._handleDetailAuthTopLevelChange.bind(this, false));
			this._attachBusEvent("authDetailsChange", this._handleDetailAuthTopLevelChange.bind(this, true));
		},
		
		/**
		 * Attach EventBus event
		 * @param {string} sEventName event name
		 * @param {function} fnHander event handler
		 * @function
		 * @private
		 */
		_attachBusEvent: function (sEventName, fnHander) {
			this.getOwnerComponent().getEventBus().subscribe("APDetail", sEventName, fnHander);
		},
		
		/**
		 * Attach route matched
		 * @function
		 * @private
		 */
		_attachRouteMatched: function () {
			var oView = this.getView();
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function (oEvent) {
				var bMainRoute = oEvent.getParameter("name") === AUTH_PACK_DETAIL_ROUTE,
					bViewRoute = oEvent.getParameter("name") === AUTH_PACK_VIEW_ROUTE;
				
				if (bMainRoute || bViewRoute) {
					var sAPId = oEvent.getParameter("arguments").object;
					var sPath = "/auth_pack_for_custSet('" + sAPId + "')";
					
					this._setViewProperty("ViewMode", bViewRoute);
					if (!oView.getElementBinding("ap") || oView.getElementBinding("ap").getPath() !== sPath) {
						oView.bindElement("ap>" + sPath, {
							expand: "AuthObjectSet"
						});
						oView.getElementBinding("ap").attachDataReceived(function (oDataReceivedEvent) {
							var bIsAPProtected = oDataReceivedEvent.getParameter("data").Protected,
								bIsSuperAdmin = this.getModel("app").getProperty("/IsSuperAdmin");
							
							this._setViewProperty("Auth/EditProtected", !!(bIsSuperAdmin || !bIsAPProtected)); // If User can edit AP
							this._setViewProperty("Auth/SaveEnabled", true);
							this._resetAuthorizationsList();
						}.bind(this));
						oView.getElementBinding("ap").refresh();
						oView.byId("idAPOverviewAuthTable").getBinding("items").filter([
							new sap.ui.model.Filter("AuthPackId", sap.ui.model.FilterOperator.EQ, sAPId)
						]);
					}

					this.__flagShowHideIFTab = false;
				}
				oView.getParent()._flagUAStopNav = true;
			}, this);
		},

		/**
		 * Show confirmation box for page data save
		 * @function
		 * @private
		 */
		_confirmSavePageData: function () {
			var fnShowConfirmationBox = confirm,
				oBundle = this.getBundle(),
				sConfirmationText = oBundle.getText("MESSAGE_ALERT_EDIT_MODE_SINGLE", [oBundle.getText("DETAIL_USER_INFOTAB_AUTHORITY")]);

			if (fnShowConfirmationBox(sConfirmationText + " " + oBundle.getText("MESSAGE_ALERT_CONFIRM_SAVE_DATA"))) {
				this.onSaveAuthorizations();
			} else {
				this.onCancelAuthorizations();
			}
		},

		/**
		 * Get extended copy of authorization object
		 * @param {object} oAuthObject authorization object
		 * @returns {object} extended object
		 * @function
		 * @private
		 */
		_extendAuthorizationObject: function (oAuthObject) {
			var oFormatter = this.formatter.detail;

			return jQuery.extend(true, {
				Customers: null, // List of customers from detail assign
				Installations: null, // List of installations from detail assign,
				IsGroupHeader: /^G_/.test(oAuthObject.ObjectId),
				IsTopHeader: oAuthObject.ObjectId === Constant.AuthGroup.ALL,
				TempChanges: false, // Has changes in detail assign
				TempCurrentAuthLevel: oAuthObject.CurrentAuthLevel,
				TempSelected: oFormatter.isAuthorizationSelected(oAuthObject.CurrentAuthLevel),
				URI: oAuthObject.__metadata.uri
			}, oAuthObject);
		},

		/**
		 * Get authorization list
		 * @returns {object[]} list
		 * @function
		 * @private
		 */
		_getAuthorizationList: function () {
			return this._getViewProperty("Auth/List") || [];
		},

		/**
		 * Get authorization object group
		 * @param {string} sAuthObjectGroup group name
		 * @returns {object[]} group
		 * @function
		 * @private
		 */
		_getAuthorizationObjectGroup: function (sAuthObjectGroup) {
			return this._getAuthorizationList().filter(function (oAuth) {
				return oAuth.AuthObjectGroup === sAuthObjectGroup;
			});
		},

		/**
		 * Get authorization object group header
		 * @param {string} sAuthObjectGroup group name
		 * @returns {object} group header
		 * @function
		 * @private
		 */
		_getAuthorizationObjectGroupHeader: function (sAuthObjectGroup) {
			var aList = this._getAuthorizationList();
			for (var iIndex = 0; iIndex < aList.length; iIndex++) {
				if (aList[iIndex].ObjectId === sAuthObjectGroup) {
					return aList[iIndex];
				}
			}
			return null;
		},

		/**
		 * Get all authorization object group headers
		 * @returns {object} group header
		 * @function
		 * @private
		 */
		_getAuthorizationObjectGroupHeaders: function () {
			return this._getAuthorizationList().filter(function (oAuth) {
				return oAuth.IsGroupHeader && !oAuth.IsTopHeader;
			});
		},

		/**
		 * Handle selection change for auth object
		 * Change its data according to selected state
		 * Propagate selected state to group(s) if needed
		 * @param {object} oAuth authorization object
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @param {boolean} bSkipUpdate don't update the model (for mass selection changes)
		 * @function
		 * @private
		 */
		_handleAuthorizationObjectSelectChange: function (oAuth, bKeepDetails, bSkipUpdate) {
			var aGroup = [];

			if (oAuth.IsGroupHeader) {
				if (oAuth.IsTopHeader) {
					aGroup = this._getAuthorizationList();
				} else {
					aGroup = this._getAuthorizationObjectGroup(oAuth.ObjectId);
				}
				// Set checked state for all children
				aGroup.forEach(function (oInnerAuth) {
					oInnerAuth.TempSelected = oAuth.TempSelected;
					if (!oInnerAuth.IsGroupHeader) {
						oInnerAuth.TempChanges = false;
						oInnerAuth.TempCurrentAuthLevel = oInnerAuth.TempSelected ? Constant.AuthLevel.FULL : Constant.AuthLevel.EMPTY;
						oInnerAuth.Customers = [];
						oInnerAuth.Installations = [];
					}
				});
			} else {
				var oGroupHeader = this._getAuthorizationObjectGroupHeader(oAuth.AuthObjectGroup);
				oAuth.TempChanges = bKeepDetails;
				if (bKeepDetails) {
					oAuth.TempSelected = Boolean((oAuth.Customers && oAuth.Customers.length) || (oAuth.Installations && oAuth.Installations.length));
					oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.RESTRICTED : Constant.AuthLevel.EMPTY;
				} else {
					oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.FULL : Constant.AuthLevel.EMPTY;
					oAuth.Customers = [];
					oAuth.Installations = [];
				}

				// Set checkbox for group header
				if (oAuth.TempSelected) {
					aGroup = this._getAuthorizationObjectGroup(oAuth.AuthObjectGroup);
					oGroupHeader.TempSelected = aGroup.every(function (oInnerAuth) {
						return oInnerAuth.TempSelected;
					});
				} else {
					oGroupHeader.TempSelected = false;
				}
			}

			// Set checkbox for top item
			var aHeaders = this._getAuthorizationObjectGroupHeaders(),
				oTopAuth = this._getAuthorizationList()[0] || {};
			oTopAuth.TempSelected = aHeaders.every(function (oInnerAuth) {
				return oInnerAuth.TempSelected;
			});
			
			if (!bSkipUpdate) {
				this._updateAuthorizationListChanges();
			}

			this._checkSaveEnabling();
		},

		_checkSaveEnabling: function(){
			this._setViewProperty("Auth/SaveEnabled", this._getAuthorizationList().some(function(oItem){
				return oItem.TempSelected;
			}));
		},

		/**
		 * Handle top level change for auth in detailed assign
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleDetailAuthTopLevelChange: function (bKeepDetails) {
			var oAuth = this._getViewProperty("Auth/Detail");
			if (oAuth) {
				this._handleAuthorizationObjectSelectChange(oAuth, bKeepDetails);
			}
		},

		/**
		 * Handle window hash change
		 * Ask for saving edit data if needed
		 * @param {object} oNativeEvent native browser event
		 * @event
		 * @private
		 */
		_handleHashChange: function (oNativeEvent) {
			var bEditAuth = this._getViewProperty("Auth/Edit"),
				sUrl = oNativeEvent.newURL || window.location.href,
				sRouteName = this._oHashChecker.getMatchedRouteName(sUrl),
				bMatchAuthPackAssign = sRouteName === "packAuthorizationAssign",
				bMatchAuthPackDetail = sRouteName === AUTH_PACK_DETAIL_ROUTE,
				bSaveAuth = bEditAuth && !bMatchAuthPackAssign && !bMatchAuthPackDetail;

			if (bSaveAuth) {
				this._confirmSavePageData();
			}
		},

		/**
		 * Reset authorizations List and AP data in view model
		 * @param {sap.ui.base.Event} [oEvent] event data
		 * @function
		 * @private
		 */
		_resetAuthorizationsList: function (oEvent) {
			var oPackage = oEvent && oEvent.getParameter("data"),
				aAuthObjectList = oPackage && oPackage.AuthObjectSet,
				sDetailURI = this._getViewProperty("Auth/Detail/URI");

			if (this._getViewProperty("Auth/Edit")) {
				return;
			}

			// If no event data
			if (!aAuthObjectList) {
				var oContext = this.getView().getBindingContext("ap"),
					aURIList = oContext.getProperty("AuthObjectSet") || [];

				oPackage = oContext.getObject();
				aAuthObjectList = aURIList.map(function (sURI) {
					return oContext.getModel().getProperty("/" + sURI);
				});
			}
			aAuthObjectList = aAuthObjectList.map(this._extendAuthorizationObject.bind(this));

			this._setViewProperty("Auth/Package", oPackage); // Current user
			this._setViewProperty("Auth/List", aAuthObjectList);
			this._updateAuthorizationGroupsSelectedState(); // Update groups selected state

			var oDetail = null;
			if (sDetailURI) {
				aAuthObjectList.some(function (oAuth) {
					if (oAuth.URI === sDetailURI) {
						oDetail = oAuth;
						return true;
					}
					return false;
				});
			}
			this._setViewProperty("Auth/Detail", oDetail); // Auth selected for detailed assign
			this._triggerBusEvent("updateLevels");
		},

		/**
		 * Update single authorization in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oAuth authorization to update
		 * @function
		 * @private
		 */
		_saveSingleAuth: function (sGroupId, oModel, oAuth) {
			if (!/^G_/.test(oAuth.ObjectId)) { // Skip group items
				if (!oAuth.TempSelected || oAuth.TempCurrentAuthLevel === Constant.AuthLevel.FULL) { // top level auth
					var sPath = jQuery.sap.formatMessage("/AuthObjectSet(PackageId=''{0}'',ObjectId=''{1}'')", [oAuth.PackageId, oAuth.ObjectId]),
						oData = jQuery.extend(true, {}, oModel.getProperty(sPath));
					oData.Selected = oAuth.TempSelected;
					Util.deleteODataExtensions(oData); // because {__list: [...]} causes an error
					oModel.update(sPath, oData, {
						batchGroupId: sGroupId
					});
				} else if (oAuth.TempChanges) {
					if (oAuth.Customers && this.formatter.detail.isAuthTopLevelCCC(oAuth.TopLevel)) {
						oAuth.Customers.map(function (oCust) {
							return jQuery.extend({}, oCust, {
								AuthLevelType: "DEBITOR"
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
					if (oAuth.Installations && this.formatter.detail.isInstallationsTableVisible(oAuth.AuthLevelId)) {
						oAuth.Installations.map(function (oInst) {
							return jQuery.extend({}, oInst, {
								AuthLevelType: oAuth.AuthLevelId
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
				}
			}
		},

		/**
		 * Update single authorization level in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oLevel level
		 * @function
		 * @private
		 */
		_saveSingleAuthLevel: function (sGroupId, oModel, oLevel) {
			var sPath = jQuery.sap.formatMessage("/AuthObjectLevelSet(PackId=''{0}'',ObjectId=''{1}'',AuthLevel=''{2}'',AuthLevelType=''{3}'')", [
					oLevel.PackId, oLevel.ObjectId, oLevel.AuthLevel, oLevel.AuthLevelType
				]),
				oData = jQuery.extend(true, {
					AuthLevel: oLevel.AuthLevel,
					AuthLevelType: oLevel.AuthLevelType,
					ObjectId: oLevel.ObjectId,
					PackId: oLevel.PackId
				}, oModel.getProperty(sPath));

			oData.IsAssigned = true;
			oModel.update(sPath, oData, {
				batchGroupId: sGroupId
			});
		},

		/**
		 * Trigger EventBus event
		 * @param {string} sEventName event name
		 * @function
		 * @private
		 */
		_triggerBusEvent: function (sEventName) {
			this.getOwnerComponent().getEventBus().publish("APDetail", sEventName);
		},

		/**
		 * Update selected state for authorization groups
		 * @function
		 * @private
		 */
		_updateAuthorizationGroupsSelectedState: function () {
			var aHeaders = this._getAuthorizationObjectGroupHeaders(),
				oTopAuth = this._getAuthorizationList()[0] || {};

			aHeaders.forEach(function (oHeader) {
				var aGroup = this._getAuthorizationObjectGroup(oHeader.ObjectId);
				oHeader.TempSelected = aGroup.every(Util.callbacks.getKey("TempSelected"));
			}.bind(this));

			oTopAuth.TempSelected = aHeaders.every(Util.callbacks.getKey("TempSelected"));
			this._updateAuthorizationListChanges();
		},

		/**
		 * Update authorization list local changes (made without setProperty)
		 * @returns {object[]} list
		 * @function
		 * @private
		 */
		_updateAuthorizationListChanges: function () {
			return this._setViewProperty("Auth/List", this._getAuthorizationList());
		},

		/**
		 * Open copy levels dialog
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		handleCopyAuthorizationLevels: function (oEvent) {
			var oAuthorization = oEvent.getSource().getBindingContext("view").getObject(),
				oPackage = this.getView().getBindingContext("ap").getObject(),
				oDialog = this._oDialogs.getDialog("CopyAPAuthorizationLevels");

			oDialog.setAuthorization(oAuthorization);
			oDialog.setAuthPackage(oPackage);
			oDialog.syncStyleClass();
			oDialog.open();
		},

		/**
		 * Attach hash change listener
		 * @event
		 * @public
		 */
		onAfterRendering: function () {
			window.addEventListener("hashchange", this._handleHashChange.bind(this));
		},

		/**
		 * Navigate to detailed auth object assign
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onAuthorizationObjectPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view"),
				oAuth = oContext.getObject();

			if (this.formatter.detail.authorizationHasDetails(oAuth.AuthLevelId)) {
				this._setViewProperty("Auth/Detail", oAuth);
				this.getRouter().navTo("packAuthorizationAssign", {
					from: "packAuthorizationAssign",
					pack: oAuth.PackageId,
					object: oAuth.ObjectId
				}, /* bReplace= */ false);
			}
		},

		/**
		 * Handle checkbox state change for auth object
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		onAuthorizationObjectTopLevelSelect: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view");
			this._handleAuthorizationObjectSelectChange(oContext.getObject());
		},

		/**
		 * Cancel changes in authorizations
		 * @event
		 * @public
		 */
		onCancelAuthorizations: function () {
			this._setViewProperty("Auth/Edit", false);
			this._resetAuthorizationsList();
		},

		/**
		 * Run authorizations edit mode
		 * @event
		 * @public
		 */
		onEditAuthorizations: function () {
			this._setViewProperty("Auth/Edit", true);
		},

		/**
		 * Save changes in authorizations
		 * @event
		 * @public
		 */
		onSaveAuthorizations: function () {
			var sBatchGroupId = "idPackAuthObjAssignGroup",
				oModel = this.getModel("ap"),
				oView = this.getView();

			this._setViewProperty("Auth/Edit", false);
			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups([sBatchGroupId]);
			this._getAuthorizationList().forEach(this._saveSingleAuth.bind(this, sBatchGroupId, oModel));
			
			this.setBusy(true);
			this._submitChanges({
					batchGroupId: sBatchGroupId
				}, "ap")
				.then(function (oData) {
					if (Util.getBatchMessage(oData) !== Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData)) {
						sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_AUTH_SAVED_AP"));
					} else {
						this._resetAuthorizationsList();
					}
					oModel.refresh();
					window.location.reload();
				}.bind(this))
				.fail(function (oError) {
					Util.JSONError.showToast(oError);
					this._resetAuthorizationsList();
				})
				.always(function () {
					this.setBusy(false);
					oModel.setUseBatch(false);
					//oModel.refresh();
					oView.getElementBinding("ap").refresh();
				}.bind(this));
		},

		/**
		 * Refresh binding of the page
		 * @function
		 * @public
		 */
		refreshBinding: function () {
			this.getView().getElementBinding("ap").refresh();
		},
		
		/**
		 * Download data of the smart table as CSV
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onSmartTableDownload: function (oEvent) {
			var oTable = Util.closest(oEvent.getSource(), SmartTable);
			if (oTable) {
				oTable.saveToFile();
			}
		}
	});
});
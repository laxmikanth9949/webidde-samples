sap.ui.define([
	"sap/support/useradministration/controller/BaseController",
	"sap/support/useradministration/model/Models",

	"sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/extended/HashChecker",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/util/Settings",
	"sap/support/usermanagmentcustomlib/userheader/util/EmailValidator"
], function (BaseController, Models, Dialogs, HashChecker, Constant, Util, Settings, EmailValidator) {

	var History = sap.ui.core.routing.History,
		HistoryDirection = sap.ui.core.routing.HistoryDirection,
		Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator,

		UserExpirationStatus = Constant.UserExpirationStatus,
		
		UserType = Constant.UserType;

	var MODEL_AP = "ap",
		USER_DETAIL_ROUTE = "userDetailNew",
		USER_DETAIL_VIEW_ROUTE = "userDetailView";

	//sap.ui.controller("sap.support.useradministration.view.UserDetail", {
	return BaseController.extend("sap.support.useradministration.view.UserDetail", {
		_oHistory: History.getInstance(),

		// A switch to hide or show Cloud Authorizations
		_bShowCloudAuthorizations: false,
		_typingTimer: "",
		_doneTypingInterval: 1000,

		onInit: function () {
			var oUABundle = this.getBundle();
			this._aKeys = ["AuthLevel", "AuthLevelDesc"];

			this._oUABundle = oUABundle;
			this._oDialogs = new Dialogs(this);
			this._oAuthAssignHistoryDialogs = {};
			
			this._oFormattedDuplicateErrorText = this.getText("MESSAGE_EMAIL_ALREADY_EXISITS") + " %%0";	 
			this.sCurrentEmail = "";
			this.sLastValidatedEmail = "";

			this._bindViewModel("UserDetail");
			this._setViewProperty("Cloud/Visible", Boolean(this._bShowCloudAuthorizations));

			this._setViewProperty("IsNewDepartmentAPIEnabled", this._getSettings().isNewDepartmentAPIEnabled);
			// this._setViewProperty("IsDomainCheckEnabled", this._getSettings().isDomainCheckEnabled);
			
			this._attachRouteMatched();
			this._oHashChecker = new HashChecker(this.getRouter());
			this._attachBusEvent("authTopLevelChange", this._handleDetailAuthTopLevelChange.bind(this, false));
			this._attachBusEvent("authDetailsChange", this._handleDetailAuthTopLevelChange.bind(this, true));
			// this.oDataDomain = new sap.ui.model.odata.v2.ODataModel('/services/odata/emaildomain/', {json: true});
			this.oDataDomain = this.getOwnerComponent().getModel("domains");
			// it is not really obvious at first why this.oDataUP is needed
			// but model with this name and this target is assumed by usermanagmentcustomlib in EmailValidator.js for UID checks
			// and as usual, for local development it should be appended to absolute URL:
			// https://supportshell-dgq5qdz5dm.dispatcher.int.sap.eu2.hana.ondemand.com/services/****
			this.oDataUP = new sap.ui.model.odata.ODataModel("/services/odata/svt/user_profile_srv", {
				json: true
			});
			this.unverifiedStartDomain = "";
		},

		onBeforeRendering: function () {
			var oView = this.getView();
			var oModel = oView.getModel();
			var fnCheckAdminAuth = function (aAuthList) {
				for(var authIndex in aAuthList){
					if(aAuthList[authIndex].ObjectId === "ADMIN"){
						this._bIsUserAbetEditAuth = true;
					}
				}
			};
			oModel.read("/LogonUserInfoSet", {
				success: function (oData, oResponse) {
					this._bIsUserAbetEditAuth = false;
					oView.__logonUserID = oResponse.data.results[0].Userid;
					this._setViewProperty("LogonUserId",  oResponse.data.results[0].Userid);
					this._setViewProperty("IsShowNotes",  
						(oResponse.data.results[0].Function === "1SUPERADMIN" || 
						oResponse.data.results[0].Function === "1SUPERADMIN_CLOUD") && 
						this._getSettings().isAdditionalNoteEnabled);
					var isAdminRole = oResponse.data.results[0].Function === "1SUPERADMIN" || 
						oResponse.data.results[0].Function === "1SUPERADMIN_CLOUD" ||
						oResponse.data.results[0].Function === "USERADMIN" ||
						oResponse.data.results[0].Function === "USERADMIN_CLOUD";	
					this._setViewProperty("IsDomainCheckEnabled", isAdminRole && 
						this.getModel("appSettings").getData().domainCheckActive);
					// as for now appSettings endpoint does not return isEmailCheckEnabled toggle state
					// so this toggle is outdated and cosindered "always on"
					// related code will be cleaned up in ticket UMT-1177
					var isEmailCheckEnabled = true;
					this._setViewProperty("IsEmailCheckEnabled", isAdminRole && isEmailCheckEnabled);
					
					this.getUserSetODataUtil().readExistingAuthorizations.call(this, this.getView().__logonUserID)
						.then(function (aResults){
		                    fnCheckAdminAuth.call(this, aResults);
							return Util.promiseRead("/auth_pack_set_for_userSet", {
								filters: [new sap.ui.model.Filter("SUser", sap.ui.model.FilterOperator.EQ, this.getView().__logonUserID)]
							}, this.getModel(MODEL_AP));
						}.bind(this))
						.then(function (oRes) {
							var aResults = oRes.results || [];
							return Promise.all(aResults.map(this._gatherAPAuthorizations.bind(this, Util.promiseRead.bind(this), fnCheckAdminAuth.bind(this))));
						}.bind(this))
						.then(function (){
							this._setViewProperty("IsAuthorizedToEditAuth", this._getViewProperty("IsAuthorizedToEdit") && this._bIsUserAbetEditAuth);
						}.bind(this));
				}.bind(this),
				error: function (oError) {
					jQuery.sap.log.error("LogonUserInfoSet loading Error: " + oError.message);
				}
			});
		},
		

		/**
		 * Attach hashchange event
		 * @function
		 * @public
		 * @override
		 */
		onAfterRendering: function () {
			var that = this;
			var fnOnHashChange = function (e) {
				that._handleHashChange(e);
			};
			var domainSelectorUserAdmin = this.getView().byId("domainSelectorUserAdmin");

			window.addEventListener("hashchange", fnOnHashChange, {
				once: false
			});

			this._setViewProperty("IsEmailOnFocusValidationFinished", true)
			if (this.getView().getModel("app").getProperty("/IsSuperAdmin")) {
				// usually we don't need to delete controls that we don't need, we just set them invisible
				// but layout of sap.ui.layout.form.SimpleForm breaks if it has invisible element, therefore we explicitly delete it here
				if(domainSelectorUserAdmin){
					domainSelectorUserAdmin.destroy();
				}
			}
		},
		/**
		 * Add event listeners in onInit function to prevent multiple click issue
		 */
		_addOnFocusHandler: function ( ) {
			var that = this;
			var oEmailInput = this.getView().byId("IdUmtDetailEmailInput");
			var oEmailNamePartInput = this.getView().byId("namePartOfEmail");
			var domainSelectorUserAdmin = this.getView().byId("domainSelectorUserAdmin");
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
			oEmailInput.addEventDelegate({
				onfocusin : function() {
					this._setViewProperty("IsEmailOnFocusValidationFinished", false);
					this._validateEmailOnFocus()
				}.bind(this)
			});
			oEmailInput.addEventDelegate({
				onsapfocusleave : function() {
					if (that._isSameEmail()) {
						that.sLastValidatedEmail = "";
						that._hideAllEmailErrors();
					}
				}.bind(this)
			});				
			oEmailNamePartInput.addEventDelegate({
				onfocusin : function() {
					that._setViewProperty("IsEmailOnFocusValidationFinished", true);
					this._validateEmail();
				}.bind(this)
			});		
			
			oEmailNamePartInput.addEventDelegate({
				onsapfocusleave : function() {
					if (that._isSameEmail()) {
						that.sLastValidatedEmail = "";
						that._hideAllEmailErrors(true);
					}
				}.bind(this)
			});
			domainSelectorSuperCloudAdmin.addEventDelegate({
				onfocusin : function() {
					this._focusIn();
				}.bind(this)
			});
			domainSelectorSuperCloudAdmin.addEventDelegate({
				onsapfocusleave : function() {
					this._focusOut();
				}.bind(this)
			});
			if(domainSelectorUserAdmin){
				domainSelectorUserAdmin.addEventDelegate({
					onfocusin : function() {
						this._focusInUA();
					}.bind(this)
				});
				domainSelectorUserAdmin.addEventDelegate({
					onsapfocusleave : function() {
						this._focusOutUA();
					}.bind(this)
				});				
			}
		},
		_focusInUA: function () {
			var that = this;
			var domainSelectorUserAdmin = this.getView().byId("domainSelectorUserAdmin");
			//As SelectWithLink element fires multiple events we need to handle only the first and ignore the rest
			//Additional onfocusin events when selection is open need to be ignored
			if(!domainSelectorUserAdmin.isOpen()
				&& that._getFullEmail() !== that.sLastValidatedEmail){
				that._setViewProperty("IsEmailOnFocusValidationFinished", true);
				that.sLastValidatedEmail = that._getFullEmail();
				that._validateEmail();
				setTimeout(function () {
					that._validateDomainUserAdmin();
					that._validateEmail();
				}.bind(this), 10);
			}
		},
		_focusOutUA: function () {
			var that = this;
			var domainSelectorUserAdmin = this.getView().byId("domainSelectorUserAdmin");
			if(!domainSelectorUserAdmin.isOpen() && domainSelectorUserAdmin.getValueState() == sap.ui.core.ValueState.Information) {
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
			}
			if (that._isSameEmail() 
			//We need to ignore onsapfocusleave when only an element is selected but focus is still on the element
			 && !domainSelectorUserAdmin.isOpen()) {
				//Reset last validated email to enable a validation when the element is focused again
				that.sLastValidatedEmail = "";
				that._hideAllEmailErrors(true);
			}
		},
		_focusOut: function () {
			var that = this;
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
			if(!domainSelectorSuperCloudAdmin.isOpen() && domainSelectorSuperCloudAdmin.getValueState() == sap.ui.core.ValueState.Information) {
				that.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
			}		
			if (that._isSameEmail()) {
				that.sLastValidatedEmail = "";
				that._hideAllEmailErrors(true);
				that._clearBorders(true);
			}
		},
		_focusIn: function () {
			var that = this;
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
			this.getView().getModel("view").setProperty("/domainList", this.domainList);
			if(domainSelectorSuperCloudAdmin.getValueState() === sap.ui.core.ValueState.None) {
				that.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Information);
				that.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminStateText", "Your domain is missing? Add new domains to the Maintain Allowed Company Domains tool.");
			}
			that._setViewProperty("IsEmailOnFocusValidationFinished", true);
			setTimeout(function () {
				this._validateDomainSuperOrCloudAdmin();
				that._validateEmail();
			}.bind(this), 10);
		},	
		/**
		 * Attach EventBus event
		 * @param {string} sEventName event name
		 * @param {function} fnHander event handler
		 * @function
		 * @private
		 */
		_attachBusEvent: function (sEventName, fnHander) {
			this.getOwnerComponent().getEventBus().subscribe("UserDetail", sEventName, fnHander);
		},

		/**
		 * Attach route matched
		 * @function
		 * @private
		 */
		_attachRouteMatched: function () {
			var that = this;
			var oView = this.getView();

			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function (evt) {
				var bMainRoute = evt.getParameter("name") === USER_DETAIL_ROUTE,
					bViewRoute = evt.getParameter("name") === USER_DETAIL_VIEW_ROUTE;

				// Create app model on detail view
				Models.createAppModel(this, "app");

				// When detail navigation occurs, update the binding context
				if (bMainRoute || bViewRoute) {
					var sUserId = evt.getParameter("arguments").user_id,
						sPath = this.getUserSetODataUtil().getUserSetPathWithParams(sUserId);

					this._setViewProperty("ViewMode", bViewRoute);

					if (!oView.getElementBinding() || oView.getElementBinding().getPath() !== sPath) {
						oView.bindElement(sPath, {
							expand: "UserAuthObjectSet"
						});

						oView.getElementBinding().attachDataRequested(this._handleUserDataRequested.bind(this, sUserId));
						oView.getElementBinding().attachDataReceived(this._handleUserDataReceived.bind(this, sUserId));
						oView.getElementBinding().refresh();
					} else if (this._oHistory.getDirection() !== HistoryDirection.Backwards && !this._isAuthEditMode() && !this._isContactEditMode()) {
						oView.getElementBinding().refresh();
					}
					/*this.__flagShowHideIFTab = false;*/
					oView.__selectedUser = evt.getParameter("arguments").user_id;

					// Shell title update
					//var oEventBus = sap.ui.getCore().getEventBus();
					//oEventBus.publish('shell', 'title', { title : oUABundle.getText("DETAIL_USER_TITLE") } ); 
					this._addOnFocusHandler();
				}
				that.getView().getParent()._flagUAStopNav = true;
				that.__firstVisit = true;
			}, this);
		},

		/**
		 * Cancel edit page data
		 * @param {boolean} bSaveAuth if authorizations are to be cancelled
		 * @param {boolean} bSaveContact if contact details are to be cancelled
		 * @param {boolean} bSaveCloud if cloud auth are to be saved
		 * @param {boolean} bSaveAPs if auth packages are to be saved
		 * @function
		 * @private
		 */
		_cancelPageData: function (bSaveAuth, bSaveContact, bSaveCloud, bSaveAPs) {
			if (bSaveAuth) {
				this.onCancelAuthorizations();
			}
			if (bSaveContact) {
				this.onCancelContactDetails();
			}
			if (bSaveCloud) {
				this.onCancelCloudAuth();
			}
			if (bSaveAPs) {
				this.onCancelAuthorizationPackages();
			}
		},

		/**
		 * Show confirmation box for page data save
		 * @param {boolean} bSaveAuth if authorizations are to be saved
		 * @param {boolean} bSaveContact if contact details are to be saved
		 * @param {boolean} bSaveCloud if cloud auth are to be saved
		 * @param {boolean} bSaveAPs if auth packages are to be saved
		 * @function
		 * @private
		 */
		_confirmSavePageData: function (bSaveAuth, bSaveContact, bSaveCloud, bSaveAPs) {
			var iNumOfPanes = [bSaveAuth, bSaveContact, bSaveCloud, bSaveAPs].filter(Boolean).length,
				fnShowConfirmationBox = confirm,
				oBundle = this.getBundle();

			if (iNumOfPanes) {
				var sConfirmationText = oBundle.getText("MESSAGE_ALERT_CONFIRM_SAVE_DATA");
				if (iNumOfPanes === 1) {
					var sPaneKey = "";
					if (bSaveAuth) {
						sPaneKey = "DETAIL_USER_INFOTAB_AUTHORITY";
					} else if (bSaveContact) {
						sPaneKey = "DETAIL_USER_INFOTAB_CONTACT_DETAIL";
					} else if (bSaveCloud) {
						sPaneKey = "DETAIL_USER_INFOTAB_CLOUD_AUTHORITY";
					} else if (bSaveAPs) {
						sPaneKey = "DETAIL_USER_INFOTAB_AP_AUTHORITY";
					}
					sConfirmationText = oBundle.getText("MESSAGE_ALERT_EDIT_MODE_SINGLE", [oBundle.getText(sPaneKey)]);
				} else {
					sConfirmationText = oBundle.getText("MESSAGE_ALERT_EDIT_MODE_MULTIPLE");
				}
				sConfirmationText = sConfirmationText + " " + oBundle.getText("MESSAGE_ALERT_CONFIRM_SAVE_DATA");

				if (fnShowConfirmationBox(sConfirmationText)) {
					this._savePageData(bSaveAuth, bSaveContact, bSaveCloud, bSaveAPs);
				} else {
					this._cancelPageData(bSaveAuth, bSaveContact, bSaveCloud, bSaveAPs);
				}
			}
		},
		
		/**
		 * Update phone country and code
		 * @param {sap.ui.base.Event} oEvent event
		 * @param {int} iIndex phone number index
		 * @function
		 * @private
		 */
		_contactDetailsUpdatePhoneCountry: function (oEvent, iIndex) {
			var sCode = oEvent.getParameter("selectedItem").getBindingContext().getProperty("PrqSpregt") || "",
				sNumberProp = iIndex === 1 ? "Contact/Data/Phone1Number" : "Contact/Data/Phone2Number",
				sCodeProp = iIndex === 1 ? "Contact/Data/Phone1Code" : "Contact/Data/Phone2Code",
				sPhoneNumber = iIndex === 1 ? "Contact/Data/Phone1NumberPlain" : "Contact/Data/Phone2NumberPlain",
				sNumber = this._getViewProperty(sPhoneNumber) || "";
			sCode = "+" + sCode.replace(/_/g, "");

			this._setViewProperty(sCodeProp, sCode);
			this._setViewProperty(sNumberProp, sCode + "-" + sNumber);
			this._setViewProperty(sPhoneNumber, sNumber);
		},

		/**
		 * Get extended copy of authorization object
		 * @param {object} oAuthObject authorization object
		 * @returns {object} extended object
		 * @function
		 * @private
		 */
		_extendAuthorizationObject: function (oAuthObject) {
			var oFormatter = this.formatter.detail;

			return jQuery.extend(true, {
				Clusters: null, // List of clusters from detail assign; null if no changes at all
				Customers: null, // List of customers from detail assign
				Installations: null, // List of installations from detail assign,
				IsGroupHeader: /^G_/.test(oAuthObject.ObjectId),
				IsTopHeader: oAuthObject.ObjectId === Constant.AuthGroup.ALL,
				TempChanges: false, // Has changes in detail assign
				TempCurrentAuthLevel: oAuthObject.CurrentAuthLevel,
				TempSelected: oFormatter.isAuthorizationSelected(oAuthObject.CurrentAuthLevel),
				URI: oAuthObject.__metadata.uri
			}, oAuthObject);
		},

		/**
		 * Get extended copy of cloud authorization object
		 * @param {object} oCloudAuth cloud auth
		 * @returns {object} extended object
		 * @function
		 * @private
		 */
		_extendCloudAuthObject: function (oCloudAuth) {
			var oFormatter = this.formatter.detail,
				bCloudAdmin = oFormatter.isCloudAuthAdmin(oCloudAuth.AuthObject);

			return jQuery.extend(true, {}, oCloudAuth, {
				_GlobalFlag: oCloudAuth.GlobalFlag,
				_HasDetails: !oCloudAuth.GlobalFlag,
				_Installs: null,
				_InstallsVisible: !bCloudAdmin,
				_IsCloudAdmin: bCloudAdmin,
				_Prods: null,
				_ProdsVisible: true,
				_Selected: oFormatter.isCloudAuthSelected(oCloudAuth.GlobalFlag),
				_Tenants: null,
				_TenantsVisible: !bCloudAdmin,
				_URI: oCloudAuth.__metadata.uri
			});
		},

		/**
		 * Get authorization list
		 * @returns {object[]} list
		 * @function
		 * @private
		 */
		_getAuthorizationList: function () {
			return this._getViewProperty("Auth/List") || [];
		},

		/**
		 * Get authorization object group
		 * @param {string} sAuthObjectGroup group name
		 * @returns {object[]} group
		 * @function
		 * @private
		 */
		_getAuthorizationObjectGroup: function (sAuthObjectGroup) {
			return this._getAuthorizationList().filter(function (oAuth) {
				return oAuth.AuthObjectGroup === sAuthObjectGroup;
			});
		},

		/**
		 * Get authorization object group header
		 * @param {string} sAuthObjectGroup group name
		 * @returns {object} group header
		 * @function
		 * @private
		 */
		_getAuthorizationObjectGroupHeader: function (sAuthObjectGroup) {
			var aList = this._getAuthorizationList();
			for (var iIndex = 0; iIndex < aList.length; iIndex++) {
				if (aList[iIndex].ObjectId === sAuthObjectGroup) {
					return aList[iIndex];
				}
			}
			return null;
		},

		/**
		 * Get all authorization object group headers
		 * @returns {object} group header
		 * @function
		 * @private
		 */
		_getAuthorizationObjectGroupHeaders: function () {
			return this._getAuthorizationList().filter(function (oAuth) {
				return oAuth.IsGroupHeader && !oAuth.IsTopHeader;
			});
		},

		/**
		 * Get User ID for currently open user
		 * @returns {string} user ID
		 * @function
		 * @private
		 */
		_getUserId: function () {
			var oObject = this.getView().getBindingContext().getObject();
			return this.getUserSetODataUtil().extractUserId(oObject);
		},
		_getIsNoDuplicate: function () {
			var oObject = this.getView().getBindingContext().getObject();
			return oObject["IsEmailNotDuplicate"];
		},                            


		/**
		 * Handle selection change for auth object
		 * Change its data according to selected state
		 * Propagate selected state to group(s) if needed
		 * @param {object} oAuth authorization object
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleAuthorizationObjectSelectChange: function (oAuth, bKeepDetails) {
			var aGroup = [];

			if (oAuth.IsGroupHeader) {
				if (oAuth.IsTopHeader) {
					aGroup = this._getAuthorizationList().filter(function(oItem) {
						return !oItem.isDisabled;
					});
				} else {
					aGroup = this._getAuthorizationObjectGroup(oAuth.ObjectId).filter(function(oItem) {
						return !oItem.isDisabled;
					});
				}
				// Set checked state for all children
				aGroup.forEach(function (oInnerAuth) {
					oInnerAuth.TempSelected = oAuth.TempSelected;
					if (!oInnerAuth.IsGroupHeader) {
						oInnerAuth.TempChanges = false;
						oInnerAuth.TempCurrentAuthLevel = oInnerAuth.TempSelected ? Constant.AuthLevel.FULL : Constant.AuthLevel.EMPTY;
						oInnerAuth.Clusters = [];
						oInnerAuth.Customers = [];
						oInnerAuth.Installations = [];
					}
				});
			} else {
				var oGroupHeader = this._getAuthorizationObjectGroupHeader(oAuth.AuthObjectGroup);
				oAuth.TempChanges = bKeepDetails;
				if (bKeepDetails) {
					oAuth.TempSelected = Boolean((oAuth.Clusters && oAuth.Clusters.length) || (oAuth.Customers && oAuth.Customers.length) ||
						(oAuth.Installations && oAuth.Installations.length));
					oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.RESTRICTED : Constant.AuthLevel.EMPTY;
				} else {
					oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.FULL : Constant.AuthLevel.EMPTY;
					oAuth.Clusters = [];
					oAuth.Customers = [];
					oAuth.Installations = [];
				}

				// Set checkbox for group header
				if (oAuth.TempSelected) {
					aGroup = this._getAuthorizationObjectGroup(oAuth.AuthObjectGroup);
					oGroupHeader.TempSelected = aGroup.every(function (oInnerAuth) {
						return oInnerAuth.TempSelected;
					});
				} else {
					oGroupHeader.TempSelected = false;
				}
			}

			// Set checkbox for top item
			var aHeaders = this._getAuthorizationObjectGroupHeaders(),
				oTopAuth = this._getAuthorizationList()[0] || {};
			oTopAuth.TempSelected = aHeaders.every(function (oInnerAuth) {
				return oInnerAuth.TempSelected;
			});
			this._updateAuthorizationListChanges();
		},

		/**
		 * Handle top level change for auth in detailed assign
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleDetailAuthTopLevelChange: function (bKeepDetails) {
			var oAuth = this._getViewProperty("Auth/Detail");
			if (oAuth) {
				this._handleAuthorizationObjectSelectChange(oAuth, bKeepDetails);
			}
		},

		/**
		 * Handle window hash change
		 * Ask for saving edit data if needed
		 * @param {object} oNativeEvent native browser event
		 * @event
		 * @private
		 */
		_handleHashChange: function (oNativeEvent) {
			var bEditAuth = this._isAuthEditMode(),
				bEditCloud = this._getViewProperty("Cloud/Edit"),
				bEditContact = this._isContactEditMode(),
				bEditAPs = this._getViewProperty("AuthPackages/Edit"),
				sUrl = oNativeEvent.newURL || window.location.href,
				sRouteName = this._oHashChecker.getMatchedRouteName(sUrl),
				bMatchUserAuthAssign = sRouteName === "userAuthorizationAssign",
				bMatchUserCloudAuthAssign = sRouteName === "userCloudAuthorizationAssign",
				bMatchAPDetailView = sRouteName === "authPackageView",
				bMatchAPDetailLevel = sRouteName === "packAuthorizationAssign",
				bMatchUserDetail = sRouteName === USER_DETAIL_ROUTE;

			var bSaveAuth = bEditAuth && !bMatchUserAuthAssign && !bMatchUserDetail,
				bSaveDetails = bEditContact && !bMatchUserDetail,
				bSaveCloud = this._bShowCloudAuthorizations && bEditCloud && !bMatchUserCloudAuthAssign && !bMatchUserDetail,
				bSaveAPs = bEditAPs && !bMatchAPDetailView && !bMatchAPDetailLevel && !bMatchUserDetail;

			this._confirmSavePageData(bSaveAuth, bSaveDetails, bSaveCloud, bSaveAPs);
		},

		/**
		 * Run after user data is received
		 * Process the data then request existing authorizations and authorization packages
		 * @param {string} sUserId user's ID
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @private
		 */
		_handleUserDataReceived: function (sUserId, oEvent) {
			if (!oEvent.getSource() || !oEvent.getSource().getBoundContext()) {
				this.getRouter().navTo("UA_main_search", {
					searchterm: sUserId
				});
				return;
			}
			var oUserBackendEntry = oEvent.getSource().getBoundContext().getObject(),
				oUser = this.getUserSetODataUtil().toFrontendEntry(oUserBackendEntry),
				bIsLifetimeEnabled = this._getSettings().isSUserLifetimeEnabled;

			this.setBusy(false);
			this._setViewProperty("IsUserActive", bIsLifetimeEnabled ? !!this.formatter.detail.isUserActive(oUser.ExpiryStatus) : true);
			this._setViewProperty("IsUserUnexpired", bIsLifetimeEnabled ? !this.formatter.detail.isUserExpired(oUser.ExpiryStatus) : true);
			this._setViewProperty("IsAuthorizedToEdit", !!oUser.IsAuthorizedToEdit);
			//this._setViewProperty("IsAuthorizedToEditAuth", !!oUser.IsAuthorizedToEdit);
			this._setViewProperty("IsAllowedForManageExpDate", this.formatter.isUserRoleAllowedForManageExpiry(oUser.Function));

			this._requestExistingAuthorizations(sUserId);
			this._requestExistingAP(sUserId);
			this._resetAuthorizationsList(oEvent);
			this._updateAuthorizationPermissionState();
			this._refreshImportantFunctions();
			// this.getUserSetODataUtil().readExistingAuthorizations.call(this, this.getView().__logonUserID)
			// 	.then(function (aResults) {
   //                 var bIsUserAbetEditAuth = false;
			// 		for(var authIndex in aResults){
			// 			if(aResults[authIndex].ObjectId === "ADMIN"){
			// 				bIsUserAbetEditAuth = true;
			// 			}
			// 		}
			// 		this._setViewProperty("IsAuthorizedToEditAuth", !!oUser.IsAuthorizedToEdit && bIsUserAbetEditAuth);
			// 	}.bind(this));				
		},

		/**
		 * Run after user data is requested
		 * @param {string} sUserId user's ID
		 * @event
		 * @private
		 */
		_handleUserDataRequested: function (sUserId) {
			this.setBusy(true);

			if (this._bShowCloudAuthorizations) {
				this._requestCloudAuthorizations(sUserId);
			}
		},


		_updateAuthorizationPermissionState: function() {
			var aAuthList = this._getViewProperty("Auth/List"),
				aRestrictedItems = aAuthList.filter(function(oAuth){
					return oAuth.TempCurrentAuthLevel === Constant.AuthLevel.RESTRICTED;
				}),
				aCurrentUserAuth = [];
			Util.promiseRead.call(this, "/LogonUserInfoSet", {}, this.getModel())
				.then(function(oData) {
					this.getView().__logonUserID = oData.results[0].Userid; 
					if (!this._getViewProperty("LogonUserAuth")) {
						return this._requestAllAuthorizations.call(this,  this.getView().__logonUserID);
					} else {
						return this._getViewProperty("LogonUserAuth");
					}
				}.bind(this))
				.then(function(aResults) {
					this._setViewProperty("LogonUserAuth", aResults);
					// Remove items, for wich logon user has top level authorization
					var aRestrictedForLogonUser = aRestrictedItems.filter(function(oAuth) {
						return !aResults.some(function (oExistAuth) {
							return oAuth.ObjectId === oExistAuth.ObjectId &&
									oExistAuth.Field === Constant.TopLevel.CCC;
						});
					});
					aCurrentUserAuth = aResults;
					return Promise.all(aRestrictedForLogonUser.map(function(oAuth) {
							var sPath = jQuery.sap.formatMessage("/AuthObjectSet(UserId=''{0}'',ObjectId=''{1}'')", [this._getViewProperty("User").Susid, oAuth.ObjectId]),
								oParams = {
									urlParameters: {
										"$expand": "AuthObjectAuthLevelSet"
									}
								};
							
							return Util.promiseRead(sPath, oParams, this.getModel());
						}.bind(this)));
				}.bind(this))
				.then(function(aResults) {
					var bHasDisabled = false,
					aExtendResults = aResults.map(function (oAuthorization){
						var aAuthLevelSet = oAuthorization.AuthObjectAuthLevelSet.results,
							bHasRestricted = aAuthLevelSet.some(function(oAuthLevel){
								return !aCurrentUserAuth.some(function(oCurrentUserAuth){
									return oCurrentUserAuth.ObjectId === oAuthLevel.ObjectId &&
										((oCurrentUserAuth.Value === oAuthLevel.AuthLevel &&
						    			 oCurrentUserAuth.Field === oAuthLevel.AuthLevelType) ||
						    			 (oAuthLevel.CustNum === oCurrentUserAuth.Value));
								});
							});
						oAuthorization.isDisabled = bHasRestricted;
						return oAuthorization;
					});
					aAuthList = aAuthList.map(function(oAuth){
						oAuth.isDisabled = aExtendResults.some(function(oItem) {
							return oAuth.ObjectId === oItem.ObjectId && oItem.isDisabled;
						});
						if (oAuth.isDisabled) {
							bHasDisabled = true;
						}
						return oAuth;
					});
					this._setViewProperty("Auth/List", aAuthList);
					this._setViewProperty("Auth/HasDisabled", bHasDisabled);
				}.bind(this));
		},
		
		_requestAllAuthorizations: function(sUserId) {
			var aAuthList = [];
			return this.getUserSetODataUtil().readExistingAuthorizations.call(this, sUserId)
			.then(function(aResults) {
				aAuthList = aResults;
				return Util.promiseRead("/auth_pack_set_for_userSet", {
					filters: [new sap.ui.model.Filter("SUser", sap.ui.model.FilterOperator.EQ, sUserId)]
				}, this.getModel(MODEL_AP));
			}.bind(this))
			.then(function(oRes) {
				var aRes = oRes.results || [];
				return Promise.all(aRes.map(function (oAuthPackObject) {
					var sAuthPackId = oAuthPackObject.AuthPackId,
					aFilters = [new sap.ui.model.Filter("AuthPackId",sap.ui.model.FilterOperator.EQ, sAuthPackId)],
					aSkipAuthFilters = aFilters.concat([new sap.ui.model.Filter("SkipAuthCheck", sap.ui.model.FilterOperator.EQ, true)]);

					return Util.promiseRead("/Auth_pack_detailSet", {
						filters: aSkipAuthFilters
					}, this.getModel(MODEL_AP))
					.then(function (oPackData) {
						var aPackResults = oPackData.results || [];
						aPackResults = aPackResults.map(function (oAuth) {
							oAuth.AuthPackId = sAuthPackId;
							oAuth.AuthPackText = oAuthPackObject.Text;
							oAuth.ValueDescription = oAuth.ValueDesc;
							oAuth.ObjectId = oAuth.Object;
							oAuth.isPackageAuth = true;
							return oAuth;
						});
						aAuthList = aAuthList.concat(aPackResults);
					});
				}.bind(this)));
			}.bind(this)).then(function() {
				return aAuthList;
			});
		},
		/**
		 * Check if edit mode for authorization is active
		 * @returns {boolean} result
		 * @function
		 * @private
		 */
		_isAuthEditMode: function () {
			return !!this._getViewProperty("Auth/Edit");
		},

		/**
		 * Check if edit mode for Contact Details is active
		 * @returns {boolean} result
		 * @function
		 * @private
		 */
		_isContactEditMode: function () {
			return !!this._getViewProperty("Contact/Edit");
		},

		/**
		 * Refresh important functions table
		 * @function
		 * @private
		 */

		_refreshImportantFunctions: function () {
			this.getView().byId("idImportantRoleTable").getBinding("items").refresh();
		},

		/**
		 * Request a visiblity of authorizations' tables
		 * @param {string} sUserId user ID
		 * @function
		 * @private
		 */
		_requestAuthorizationTablesVisibility: function (sUserId) {
			this._read("/user_auth_check_cld_onpremSet", {
				filters: [new sap.ui.model.Filter("Userid", sap.ui.model.FilterOperator.EQ, sUserId)]
			}, "ca").then(function (oData) {
				var aResults = oData.results || [];
				aResults.forEach(function (oResult) {
					if (oResult.CheckId === "CLD_admin") {
						this.byId("idUAUserDetailCloudAuth").setVisible(Boolean(oResult.Checked));
						this.byId("idUAUserDetailExistCloudAuth").setVisible(Boolean(oResult.Checked));
					} else if (oResult.CheckId === "OnPrem_adm") {
						//
					}
				}.bind(this));
			}.bind(this), function (oError) {
				jQuery.sap.log.error("USER_AUTH_CHECK__GET_ENTITYSET loading Error: " + oError.message);
			});
		},

		/**
		 * Request cloud authorizations
		 * @param {string} sUserId user ID
		 * @function
		 * @private
		 */
		_requestCloudAuthorizations: function (sUserId) {
			this.getModel("ca").read("/USER_AUTHSet", {
				filters: [new sap.ui.model.Filter("Userid", sap.ui.model.FilterOperator.EQ, sUserId)],
				success: this._resetCloudAuthList.bind(this),
				error: this._resetCloudAuthList.bind(this, {})
			});

			this.getModel("ca").read("/get_cld_auth_for_userSet", {
				filters: [new sap.ui.model.Filter("Userid", sap.ui.model.FilterOperator.EQ, sUserId)],
				success: this._resetCloudExistingAuthList.bind(this),
				error: this._resetCloudExistingAuthList.bind(this, {})
			});
		},

		/**
		 * Turn edit mode for authorization on or off
		 * @param {boolean} bEdit edit mode state
		 * @function
		 * @private
		 */
		_setAuthEditMode: function (bEdit) {
			this._setViewProperty("Auth/Edit", !!bEdit);
		},

		/**
		 * Turn edit mode for Contact Details on or off
		 * @param {boolean} bEdit edit mode state
		 * @function
		 * @private
		 */
		_setContactEditMode: function (bEdit) {
			this._setViewProperty("Contact/Edit", !!bEdit);
		},

		/**
		 * Check for inactive authorization package
		 * @param {object} oPackage AP object
		 * @returns {Promise} promise
		 * @function
		 * @private
		 */
		_checkInactiveAuthPackage: function (oPackage) {
			return Util.promiseRead.call(this, "/Auth_pack_detailSet", {
					filters: [new sap.ui.model.Filter("AuthPackId", sap.ui.model.FilterOperator.EQ, oPackage.AuthPackId)]
				}, "ap")
				.then(function () {
					oPackage.isInactive = false;
					return oPackage;
				}).catch(function () {
					oPackage.isInactive = true;
					return oPackage;
				});
		},

		/**
		 * Request Existing AP
		 * @param {string} sUserId userID
		 * @function
		 * @private
		 */
		_requestExistingAP: function (sUserId) {
			this._setViewProperty("AuthPackages/Backup", []);
			this._setViewProperty("AuthPackages/Busy", true);
			this._setViewProperty("AuthPackages/Edit", false);
			this._setViewProperty("AuthPackages/List", []);

			Util.promiseRead.call(this, "/auth_pack_set_for_userSet", {
					filters: [new sap.ui.model.Filter("SUser", sap.ui.model.FilterOperator.EQ, sUserId)]
				}, "ap").then(function (oData) {
					var aPackages = (oData.results || []).map(Util.deepCopy);
					var aPromises = aPackages.map(this._checkInactiveAuthPackage.bind(this));

					return Promise.all(aPromises)
						.then(function (aList) {
							this._setViewProperty("AuthPackages/Backup", aList);
							this._setViewProperty("AuthPackages/List", aList.map(Util.deepCopy));
						}.bind(this));
				}.bind(this))
				.finally(this._setViewProperty.bind(this, "AuthPackages/Busy", false));
		},

		/**
		 * Add requested authorizations to the map
		 * @param {object[]} aExistingAuthGroups array containing existing authorization groups
		 * @param {object} oExistingAuthGroups object containing info about existing authorization groups
		 * @param {object} oAuthsMap resulting map
		 * @param {object[]} aRequestedAuths authorization object to process
		 * @function
		 * @private
		 */
		_addRequestedAuthorizations: function (aExistingAuthGroups, oExistingAuthGroups, oAuthsMap, aRequestedAuths) {
			var oSplit = Util.splitArray(aRequestedAuths, function (oAuth) {
					return oAuth.AuthLevelId === "group";
				}),
				aGroups = oSplit.trueItems,
				aAuths = oSplit.falseItems;

			// Initialize groups
			aGroups.forEach(function (oGroup) {
				var sGroupId = oGroup.ObjectId,
					bGroupExists = oExistingAuthGroups[sGroupId];

				if (!bGroupExists) {
					aExistingAuthGroups.push(Util.copy(oGroup));
					oExistingAuthGroups[sGroupId] = true;
					oAuthsMap[sGroupId] = [];
				}
			});
			aAuths.forEach(function (oAuth) {
				var sGroupId = oAuth.AuthLevelId,
					oGroup = oAuthsMap[sGroupId],
					bAuthNotExists = oGroup && !oGroup.some(function (oExistingAuth) {
						return oExistingAuth.ObjectId === oAuth.ObjectId &&
							oExistingAuth.AuthPackId === oAuth.AuthPackId &&
							oExistingAuth.Field === oAuth.Field &&
							oExistingAuth.Value === oAuth.Value;
					});

				if (bAuthNotExists) {
					oGroup.push(Util.copy(oAuth));
				}
			});
		},

		/**
		 * Gather existing authorizations for specific AP
		 * @param {function} fnPromiseRead function for sending read requests returning promise
		 * @param {function} fnAddAuths function to collect authorizations
		 * @param {object} oAuthPackObject authorization package object
		 * @returns {Promise} promise
		 * @function
		 * @private
		 */
		_gatherAPAuthorizations: function (fnPromiseRead, fnAddAuths, oAuthPackObject) {
			var bIsInactive = false,
				sAuthPackId = oAuthPackObject.AuthPackId,
				aFilters = [new Filter("AuthPackId", FilterOperator.EQ, sAuthPackId)],
				aSkipAuthFilters = aFilters.concat([new Filter("SkipAuthCheck", FilterOperator.EQ, true)]);

			return fnPromiseRead("/Auth_pack_detailSet", {
					filters: aSkipAuthFilters
				}, MODEL_AP)
				.then(function (oPackData) {
					var aPackResults = oPackData.results || [];
					aPackResults = aPackResults.map(function (oAuth) {
						oAuth.AuthPackId = sAuthPackId;
						oAuth.AuthPackText = oAuthPackObject.Text;
						oAuth.ValueDescription = oAuth.ValueDesc;
						oAuth.ObjectId = oAuth.Object;
						oAuth.isPackageAuth = true;
						return oAuth;
					});

					// Check if user is authorized for AP
					return fnPromiseRead("/Auth_pack_detailSet", {
							filters: aFilters
						}, MODEL_AP)
						.then(function (oAuthPackageDetail) {
							var aDetailResults = oAuthPackageDetail.results || [];
							bIsInactive = aDetailResults.length === 0;
						})
						.catch(function () {
							bIsInactive = true;
						})
						.finally(function () {
							fnAddAuths(aPackResults.map(function (oAuth) {
								oAuth.isInactive = bIsInactive;
								return oAuth;
							}));
						});
				});
		},

		/**
		 * Request Existing Authorizations
		 * @param {string} sUserId user ID
		 * @function
		 * @private
		 */
		_requestExistingAuthorizations: function (sUserId) {
			var aExistingAuthGroups = [],
				oExistingAuthGroups = {},
				oAuthsMap = {},
				oAPModel = this.getModel(MODEL_AP),
				fnPromiseRead = Util.promiseRead.bind(this),
				fnAddAuths = this._addRequestedAuthorizations.bind(this, aExistingAuthGroups, oExistingAuthGroups, oAuthsMap),
				fnGatherAPAuths = this._gatherAPAuthorizations.bind(this, fnPromiseRead, fnAddAuths);

			this._setViewProperty("Auth/ExistingList", []);
			this._setViewProperty("ExistingAuthListBusy", true);
			this._setViewProperty("AuthPackages/Busy", true);

			this.getUserSetODataUtil().readExistingAuthorizations.call(this, sUserId)
				.then(function (aResults) {
					fnAddAuths(aResults);

					// Read APs for user
					return fnPromiseRead("/auth_pack_set_for_userSet", {
						filters: [new sap.ui.model.Filter("SUser", sap.ui.model.FilterOperator.EQ, sUserId)]
					}, oAPModel);
				})
				.then(function (oData) {
					var aResults = oData.results || [];
					return Promise.all(aResults.map(fnGatherAPAuths)); // Gather authorizations for each AP
				})
				.finally(function () {
					var aExistingAuthList = [];

					Util.each(oAuthsMap, function (aAuthList) {
						aAuthList.sort(Util.getComparator("ObjectId"));
					});
					aExistingAuthGroups.forEach(function (oAuthGroup) {
						var sGroupId = oAuthGroup.ObjectId;

						if (oAuthsMap[sGroupId].length > 0) {
							aExistingAuthList.push(Util.copy(oAuthGroup));
							aExistingAuthList = aExistingAuthList.concat(oAuthsMap[sGroupId]);
						}
					});

					this._setViewProperty("Auth/ExistingList", aExistingAuthList);
					this._requestExistingAP(sUserId);
					this._setViewProperty("ExistingAuthListBusy", false);
				}.bind(this));
		},

		/**
		 * Reset authorizations List and user data in view model
		 * @param {sap.ui.base.Event} oEvent event data
		 * @function
		 * @private
		 */
		_resetAuthorizationsList: function (oEvent) {
			var oUserSetODataUtil = this.getUserSetODataUtil(),
				oUser = oEvent && oEvent.getParameter("data"),
				aAuthObjectList = oUser && oUserSetODataUtil.extractAuthorizationsRawList(oUser),
				sDetailURI = this._getViewProperty("Auth/Detail/URI");

			if (this._isAuthEditMode()) { // possible on Contact Details save
				return;
			}

			// If no event data
			if (!aAuthObjectList) {
				var oContext = this.getView().getBindingContext();
				oUser = oContext.getObject();

				var aURIList = oUserSetODataUtil.extractAuthorizationsRawList(oUser);
				aAuthObjectList = aURIList.map(function (sURI) {
					return oContext.getModel().getProperty("/" + sURI);
				});
			}
			aAuthObjectList = aAuthObjectList.map(this._extendAuthorizationObject.bind(this));
			aAuthObjectList = aAuthObjectList.map(this._copyAuthObjectEditableState.bind(this));
			this._setViewProperty("Auth/User", oUser); // Current user
			this._setViewProperty("User", oUser); // Current user
			this._setViewProperty("Auth/List", aAuthObjectList);
			this._updateAuthorizationGroupsSelectedState(); // Update groups selected state
			this._setViewProperty("EditAuthority", oUser.EditAuthority);
			
			this._setViewProperty("UserData", this.getUserSetODataUtil().toFrontendEntry(oUser));

			var oDetail = null;
			if (sDetailURI) {
				oDetail = Util.arrayFind(function (oAuth) {
					return oAuth.URI === sDetailURI;
				});
			}
			this._setViewProperty("Auth/Detail", oDetail); // Auth selected for detailed assign
			this._triggerBusEvent("updateLevels");
		},
		
		_copyAuthObjectEditableState: function(oAuth) {
			var oExistItem = Util.arrayFind(this._getViewProperty("Auth/List"), function(oItem) {
				return oAuth.Value === oItem.Value &&
						oAuth.Field === oItem.Field &&
						oAuth.ObjectId === oItem.ObjectId;
			});
			if (oExistItem) {
				oAuth.isDisabled = oExistItem.isDisabled;
			}
			return oAuth;
		},
		
		/**
		 * Reset cloud authorizations List in view model
		 * @param {object} oData auth data
		 * @function
		 * @private
		 */
		_resetCloudAuthList: function (oData) {
			var sDetailURI = this._getViewProperty("Cloud/Detail/_URI"),
				aCloudAuthList = (oData ? oData.results : this._getViewProperty("Cloud/List")) || [];

			if (this._getViewProperty("Cloud/Edit")) { // possible on Contact Details save
				return;
			}

			aCloudAuthList = aCloudAuthList.map(this._extendCloudAuthObject.bind(this));
			this._setViewProperty("Cloud/List", aCloudAuthList);

			var oDetail = null;
			if (sDetailURI) {
				oDetail = Util.arrayFind(aCloudAuthList, function (oAuth) {
					return oAuth._URI === sDetailURI;
				});
			}
			this._setViewProperty("Cloud/Detail", oDetail); // Auth selected for detailed assign
			this._triggerBusEvent("updateCloudLevels");
		},

		/**
		 * Reset existing cloud authorizations List in view model
		 * @param {object} oData auth data
		 * @function
		 * @private
		 */
		_resetCloudExistingAuthList: function (oData) {
			var aCloudAuthList = (oData ? oData.results : this._getViewProperty("Cloud/ExistingList")) || [];

			aCloudAuthList = aCloudAuthList.map(this._extendCloudAuthObject.bind(this));
			this._setViewProperty("Cloud/ExistingList", aCloudAuthList);
		},

		/**
		 * Collect phone numbers data for contact details
		 * @param {object} oUserData current user data
		 * @returns {object} phone numbers data
		 * @function
		 * @private
		 */
		_getUserPhoneData: function (oUserData) {
			var sDefaultCountry = this.getModel("app").getProperty("/DefaultLang") || "",
				sFirstCode = oUserData.FirstPhoneCountryId && this.formatter.phoneCode(oUserData.FirstPhoneCountryId) || "",
				sFirstPhone = this.formatter.detail.phoneNumberHyphen(sFirstCode, oUserData.FirstPhoneNumber),
				sSecondCode = oUserData.SecondPhoneCode && this.formatter.phoneCode(oUserData.SecondPhoneCode) || "",
				sSecondPhone = this.formatter.detail.phoneNumberHyphen(sSecondCode, oUserData.SecondPhoneNumber);

			return {
				Phone1Code: sFirstCode,
				Phone1Country: oUserData.FirstPhoneCountryId || sDefaultCountry,
				Phone1Number: sFirstPhone,
				Phone1NumberPlain: oUserData.FirstPhoneNumber,
				Phone2Code: sSecondCode,
				Phone2Country: oUserData.SecondPhoneCountryId || sDefaultCountry,
				Phone2Number: sSecondPhone,
				Phone2NumberPlain: oUserData.SecondPhoneNumber
			};
		},

		/**
		 * Reset contact details
		 * @param {object} oUserData current user data
		 * @function
		 * @private
		 */
		_resetContactDetails: function (oUserData) {
			var oFirstPhoneSelect = this.byId("umSelectUserFirstCountry"),
				oSecondPhoneSelect = this.byId("umSelectUserSecondCountry"),
				oPhoneData = this._getUserPhoneData(oUserData),
				oContactData = Util.merge(oPhoneData, {
					Department: oUserData.DepartmentName || "",
					DepartmentId: oUserData.DepartmentId || "",
					JobTitle: oUserData.JobTitle || "",
					Email: oUserData.Email || "",
					Language: oUserData.LanguageCode || "",
					Salutation: oUserData.Salutation || "",
					Notes: this.formatter.detail.unescapeNotes(oUserData.Notes) || ""
				});

			this._setViewProperty("Contact/Data", oContactData);
			this.sCurrentEmail = oUserData.Email || "";
			// Fill default country code on empty phone numbers
			if (!oContactData.Phone1Number && oFirstPhoneSelect && oFirstPhoneSelect.getSelectedItem()) {
				oFirstPhoneSelect.fireChange({
					selectedItem: oFirstPhoneSelect.getSelectedItem()
				});
			}
			if (!oContactData.Phone2Number && oFirstPhoneSelect && oSecondPhoneSelect.getSelectedItem()) {
				oSecondPhoneSelect.fireChange({
					selectedItem: oSecondPhoneSelect.getSelectedItem()
				});
			}
		},

		/**
		 * Save page data
		 * @param {boolean} bSaveAuth if authorizations are to be saved
		 * @param {boolean} bSaveContact if contact details are to be saved
		 * @param {boolean} bSaveCloud if cloud auth are to be saved
		 * @param {boolean} bSaveAPs if auth packages are to be saved
		 * @function
		 * @private
		 */
		_savePageData: function (bSaveAuth, bSaveContact, bSaveCloud, bSaveAPs) {
			if (bSaveAuth) {
				this.onSaveAuthorizations();
			}
			if (bSaveContact) {
				if (this.getView().getModel("appSettings").getProperty("/domainCheckActive")) {
					this.onSaveContactDetails();
				} else {
					this.onSaveContactDetailsOld();
				}
			}
			if (bSaveCloud) {
				this.onSaveCloudAuth();
			}
			if (bSaveAPs) {
				this.onSaveAuthorizationPackages();
			}
		},

		onSaveContactDetailsButtonClick: function (oEvent) {
			if (this.getView().getModel("appSettings").getProperty("/domainCheckActive")) {
				this.onSaveContactDetails(oEvent);
			} else {
				this.onSaveContactDetailsOld(oEvent);
			}
		},

		/**
		 * Update single authorization in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oAuth authorization to update
		 * @function
		 * @private
		 */
		_saveSingleAuth: function (sGroupId, oModel, oAuth) {
			if (!/^G_/.test(oAuth.ObjectId)) { // Skip group items
				if (!oAuth.TempSelected || oAuth.TempCurrentAuthLevel === Constant.AuthLevel.FULL) { // top level auth
					var sPath = jQuery.sap.formatMessage("/AuthObjectSet(UserId=''{0}'',ObjectId=''{1}'')", [oAuth.UserId, oAuth.ObjectId]),
						oData = jQuery.extend(true, {}, oModel.getProperty(sPath));
					oData.Selected = oAuth.TempSelected;
					delete oData.AuthObjectAuthLevelSet; // because {__list: [...]} causes an error
					oModel.update(sPath, oData, {
						batchGroupId: sGroupId
					});
				} else if (oAuth.TempChanges) {
					if (oAuth.Customers && this.formatter.detail.isAuthTopLevelCCC(oAuth.TopLevel)) {
						oAuth.Customers.map(function (oCust) {
							return jQuery.extend({}, oCust, {
								AuthLevelType: "DEBITOR"
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
					if (oAuth.Installations && this.formatter.detail.isInstallationsTableVisible(oAuth.AuthLevelId)) {
						oAuth.Installations.map(function (oInst) {
							return jQuery.extend({}, oInst, {
								AuthLevelType: oAuth.AuthLevelId
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
					if (oAuth.Clusters) {
						oAuth.Clusters.map(function (oClust) {
							return jQuery.extend({}, oClust, {
								AuthLevel: oClust.AuthLevelDesc,
								AuthLevelType: oClust.AuthLevelDesc
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
				}
			}
		},

		/**
		 * Update single authorization level in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oLevel level
		 * @function
		 * @private
		 */
		_saveSingleAuthLevel: function (sGroupId, oModel, oLevel) {
			var sPath = jQuery.sap.formatMessage("/AuthObjectLevelSet(UserId=''{0}'',ObjectId=''{1}'',AuthLevel=''{2}'',AuthLevelType=''{3}'')", [
					oLevel.UserId, oLevel.ObjectId, oLevel.AuthLevel, oLevel.AuthLevelType
				]),
				oData = jQuery.extend(true, {
					AuthLevel: oLevel.AuthLevel,
					AuthLevelType: oLevel.AuthLevelType,
					ObjectId: oLevel.ObjectId,
					UserId: oLevel.UserId
				}, oModel.getProperty(sPath));

			oData.IsAssigned = true;
			oModel.update(sPath, oData, {
				batchGroupId: sGroupId
			});
		},

		/**
		 * Update single cloud authorization in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oAuth cloud authorization to update
		 * @returns {boolean} if anything has been saved
		 * @function
		 * @private
		 */
		_saveSingleCloudAuth: function (sGroupId, oModel, oAuth) {
			var aProducts = oAuth._ProdsVisible && oAuth._Prods || [],
				aInstalls = oAuth._InstallsVisible && oAuth._Installs || [],
				aTenants = oAuth._TenantsVisible && oAuth._Tenants || [];

			aProducts.forEach(this._saveSingleCloudAuthLevel.bind(this, sGroupId, oModel, "P"));
			aInstalls.forEach(this._saveSingleCloudAuthLevel.bind(this, sGroupId, oModel, "I"));
			aTenants.forEach(this._saveSingleCloudAuthLevel.bind(this, sGroupId, oModel, "T"));

			return Boolean(aProducts.length || aInstalls.length || aTenants.length);
		},

		/**
		 * Update single cloud authorization level in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {string} sType level type - P (product), I (installation) or other (Tenant)
		 * @param {object} oLevel level
		 * @function
		 * @private
		 */
		_saveSingleCloudAuthLevel: function (sGroupId, oModel, sType, oLevel) {
			var bIsProduct = sType === "P",
				bIsInstallation = sType === "I";

			var oData = {
				Ubname: oLevel.sUser,
				Object: oLevel.authObject,
				Field: bIsProduct ? oLevel.InstProd : bIsInstallation && "INSTALL" || "TENANT",
				Value: bIsProduct ? oLevel.CustomerId : oLevel.InstProd
			};
			var sPath = Util.formatMessage("/beruser_cldSet(Ubname=''{0}'',Object=''{1}'',Field=''{2}'',Value=''{3}'')", [
				oData.Ubname, oData.Object, oData.Field, oData.Value
			]);

			oModel.update(sPath, oData, {
				groupId: sGroupId
			});
		},

		/**
		 * Trigger EventBus event
		 * @param {string} sEventName event name
		 * @function
		 * @private
		 */
		_triggerBusEvent: function (sEventName) {
			this.getOwnerComponent().getEventBus().publish("UserDetail", sEventName);
		},

		/**
		 * Update selected state for authorization groups
		 * @function
		 * @private
		 */
		_updateAuthorizationGroupsSelectedState: function () {
			var aHeaders = this._getAuthorizationObjectGroupHeaders(),
				oTopAuth = this._getAuthorizationList()[0] || {};

			aHeaders.forEach(function (oHeader) {
				var aGroup = this._getAuthorizationObjectGroup(oHeader.ObjectId);
				oHeader.TempSelected = aGroup.every(Util.callbacks.getKey("TempSelected"));
			}.bind(this));

			oTopAuth.TempSelected = aHeaders.every(Util.callbacks.getKey("TempSelected"));
			this._updateAuthorizationListChanges();
		},

		/**
		 * Update authorization list local changes (made without setProperty)
		 * @returns {object[]} list
		 * @function
		 * @private
		 */
		_updateAuthorizationListChanges: function () {
			return this._setViewProperty("Auth/List", this._getAuthorizationList());
		},

		/**
		 * Navigate to detailed auth object assign
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onAuthorizationObjectPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view"),
				oAuth = oContext.getObject();

			this._navDetailAuth(oAuth);
		},

		/**
		 * Handle focus in Notes field
		 * Show note under this field
		 * @event
		 * @public
		 */
		onNotesFocusIn: function () {
			this._setViewProperty("Contact/ShowNotesInfo", true);
		},

		/**
		 * Handle focus out of Notes field
		 * Hide note under this field
		 * @event
		 * @public
		 */
		onNotesFocusOut: function () {
			this._setViewProperty("Contact/ShowNotesInfo", false);
		},

		/**
		 * Open popover with User Status information
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onUserStatusInformationPress: function (oEvent) {
			if (!this._oUserStatusInformationPopover) {
				this._oUserStatusInformationPopover = sap.ui.xmlfragment(
					"sap.support.useradministration.view.fragment.detail.UserStatusInformationPopover", this);
				this.getView().addDependent(this._oUserStatusInformationPopover);
			}

			this._oUserStatusInformationPopover.openBy(oEvent.getSource());
		},

		/**
		 * Open popover with UniversalID information
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onUniversalIDInformationPress: function (oEvent) {
			if (!this._oUniversalIDInformationPopover) {
				this._oUniversalIDInformationPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.UidDetails", this);
				this.getView().addDependent(this._oUniversalIDInformationPopover);
			}

			this._oUniversalIDInformationPopover.openBy(oEvent.getSource());
		},

		/**
		 * Set assigned auth packages from the dialog
		 * @param {object[]} aPackages packages
		 * @function
		 * @public
		 */
		setAssignedAuthorizationPackages: function (aPackages) {
			var aPromises = aPackages.map(this._checkInactiveAuthPackage.bind(this));
			this._setViewProperty("AuthPackages/Busy", true);

			Promise.all(aPromises)
				.then(function (aList) {
					var aSelectedAPIds = aList.map(function (oSelectedAP) {
						return oSelectedAP.AuthPackId;
					});

					var aInactiveList = this._getViewProperty("AuthPackages/Backup").filter(function (oAP) {
						return oAP.isInactive && aSelectedAPIds.indexOf(oAP.AuthPackId) === -1;
					});

					this._setViewProperty("AuthPackages/List", aList.concat(aInactiveList));
				}.bind(this))
				.finally(this._setViewProperty.bind(this, "AuthPackages/Busy", false));
		},

		/**
		 * Update user data after managing expiry date
		 * @function
		 * @public
		 */
		updateAfterManageExpiryDate: function () {
			this.getView().getElementBinding().refresh();
		},

		/**
		 * Navigate to Authorization Detail page
		 * @param {object} oAuth Authorization object
		 * @function
		 * @private
		 */
		_navDetailAuth: function (oAuth) {
			if (this.formatter.detail.authorizationHasDetails(oAuth.AuthLevelId)) {
				this._setViewProperty("Auth/Detail", oAuth);
				this.getRouter().navTo("userAuthorizationAssign", {
					from: "userAuthorizationAssign",
					user: oAuth.UserId,
					object: oAuth.ObjectId
				}, /* bReplace= */ false);
			}
		},

		/**
		 * Navigate to Cloud Authorization Detail page
		 * @param {object} oAuth Cloud Authorization object
		 * @function
		 * @private
		 */
		_navDetailCloudAuth: function (oAuth) {
			this._setViewProperty("Cloud/Detail", oAuth);
			this.getRouter().navTo("userCloudAuthorizationAssign", {
				user: oAuth.Userid,
				object: oAuth.AuthObject
			}, /* bReplace= */ false);
		},

		/**
		 * Handle checkbox state change for auth object
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		onAuthorizationObjectTopLevelSelect: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view");
			this._handleAuthorizationObjectSelectChange(oContext.getObject());
		},

		/**
		 * Cancel changes in auth pack table
		 * @event
		 * @public
		 */
		onCancelAuthorizationPackages: function () {
			this._setViewProperty("AuthPackages/List", this._getViewProperty("AuthPackages/Backup"));
			this._setViewProperty("AuthPackages/Edit", false);
		},

		/**
		 * Cancel changes in authorizations
		 * @event
		 * @public
		 */
		onCancelAuthorizations: function () {
			this._setAuthEditMode(false);
			this._resetAuthorizationsList();
		},

		/**
		 * Cancel changes in cloud authorizations
		 * @event
		 * @public
		 */
		onCancelCloudAuth: function () {
			this._setViewProperty("Cloud/Edit", false);
			this._resetCloudAuthList();
		},

		/**
		 * Cancel changes in contact details
		 * @event
		 * @public
		 */
		onCancelContactDetails: function () {
			this.sLastValidatedEmail = "";
			this._setContactEditMode(false);
			this.getView().getModel("view").setProperty("/isFormatInvalid", false);
			this.getView().getModel("view").setProperty("/isEmailShared", false);
			this.getView().getModel("view").setProperty("/isEmailDuplicate", false);
			this.getView().getModel("view").setProperty("/isEmailAllowedDomainListEmpty", false);
			this.getView().getModel("view").setProperty("/isEmailDomainVerified", false);
			this.getView().getModel("view").setProperty("/isEmailDomainFormatValid", false);
			this.getView().getModel("view").setProperty("/isEmailLinkedDifferentUid", false);
			this.getView().getModel("view").setProperty("/isEmailNotLinkedUid", false);
			var domList = this.getView().getModel("view").getProperty("/domainList");
			domList.push({
				email: "",
				enabled: false
			});	
			this.getView().getModel("view").setProperty("/domainList", domList);
			this.getView().byId("domainSelectorSuperCloudAdmin").setSelectedKey("");
			
			this._clearExpandMsgs(true);
			this._clearBorders();
		},

		/**
		 * Navigate to detailed auth object assign
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onCloudAuthObjectPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view"),
				oAuth = oContext.getObject();

			if (oAuth._HasDetails) {
				this._navDetailCloudAuth(oAuth);
			}
		},

		/**
		 * Update phone country and code
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onContactDetailsPhone1CountryChange: function (oEvent) {
			this._contactDetailsUpdatePhoneCountry(oEvent, 1);
		},

		/**
		 * Update phone country and code
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onContactDetailsPhone2CountryChange: function (oEvent) {
			this._contactDetailsUpdatePhoneCountry(oEvent, 2);
		},

		/**
		 * Prevent Phone max length to be exceeded
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onPhoneChange: function (oEvent) {
			var phoneNumber = oEvent.getSource().getValue();
			var phoneRegexpStr = this.getView().getModel("appSettings").oData.phoneRegexp;
			var phoneMaxLength = parseInt(this.getView().getModel("appSettings").oData.phoneMaxLength);
			var phoneRegexp = new RegExp(phoneRegexpStr, "g");
			phoneNumber = phoneNumber.slice(0, phoneMaxLength).replace(phoneRegexp, "");
			oEvent.getSource().setValue(phoneNumber);
		},

		/**
		 * Open new Department Value Help
		 * @event
		 * @public
		 */
		onDepartmentNewValueHelp: function () {
			this._oDialogs.getDialog("AssignDepartmentNew").clearData().setValueHelpMode(true)
				.syncStyleClass().open();
		},

		/**
		 * Run authorizations edit mode
		 * @event
		 * @public
		 */
		onEditAuthorizations: function () {
			this._setAuthEditMode(true);
		},

		/**
		 * Run cloud authorizations edit mode
		 * @event
		 * @public
		 */
		onEditCloudAuth: function () {
			this._setViewProperty("Cloud/Edit", true);
		},

		/**
		 * Run contact details edit mode
		 * @event
		 * @public
		 */
		onEditContactDetails: function () {
			var oUserData = this._getViewProperty("UserData");
			var email = oUserData.Email;
			this.bHasDomainChanged = false;
			this._resetContactDetails(oUserData);
			this._setContactEditMode(true);
			this._setSplitedEmail(this._splitEmail(email));
			this.getView().getModel("view").setProperty("/isEmailDomainFormatValid", true);
			this.getView().getModel("view").setProperty("/isEmailDomainVerified", true);
			this.getView().getModel("view").setProperty("/isEmailAllowedDomainListEmpty", false);
			this.getView().getModel("view").setProperty("/domainEditable", false);
			this.getView().getModel("view").setProperty("/additionalNotesRemovedForUnverifiedDomain", false);
			this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
			this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
			this.getView().byId("signPartOfEmail").removeStyleClass("sapMInputBaseContentWrapperError");
			this.getView().byId("domainSelectorSuperCloudAdmin").setSelectedKey(
					this.getView().getModel("view").getProperty("/domainPartOfEmail"));
			if (this.getView().getModel("appSettings").getProperty("/domainCheckActive")) {
				EmailValidator.getDomainList.call(this, this.getView().getModel("view").getProperty("/UserDetail/UserData/CustomerId")).then(function (aDomainList) {
					if (aDomainList.length !== 0) {
						var extandedList = aDomainList.map(function (sValue){
								return {
									email: sValue,
									enabled: true
								};
							}),
							sDomain = this._splitEmail(email)[1];
						this.domainList = [].concat(extandedList);
						if (!aDomainList.includes(sDomain)) {
							this.unverifiedStartDomain = sDomain;
							extandedList.push({
								email: sDomain,
								enabled: false
							});
						}
						this.getView().getModel("view").setProperty("/domainList", extandedList);
						this.getView().getModel("view").setProperty("/domainEditable", true);
						this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
					} else {
						var	domain = this._splitEmail(email)[1];
						var	list =[{ email: domain, enabled: false}];
						this.getView().getModel("view").setProperty("/domainList", list);
						this.getView().getModel("view").setProperty("/domainEditable", false);
						this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
						this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "None");
						this.getView().getModel("view").setProperty("/isEmailAllowedDomainListEmpty", true);
					}
					if(!this.bHasDomainChanged){
						this._setSplitedEmail(this._splitEmail(email));
					}
				}.bind(this));
			}
			// this._setViewProperty("Contact/Data/IsValidEmail", true);
			// this._setViewProperty("Contact/Data/IsEmailFormatCorrect", true);
			// this._setViewProperty("Contact/Data/IsDuplicateEmail", false);
			// this._setViewProperty("Contact/Data/IsSharedEmail", false);
			// this._setViewProperty("Contact/Data/EmailLocalPart", "");
			// this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.None);
			// this._validateEmail();
		},

		_splitEmail: function (email) {
			return email.split("@");
		},
		
		_setSplitedEmail: function (arr) {
			this.getView().getModel("view").setProperty("/namePartOfEmail", arr[0]);
			this.getView().getModel("view").setProperty("/domainPartOfEmail", arr[1]);
		},

		/**
		 * Save changes in auth pack table
		 * @event
		 * @public
		 */
		onSaveAuthorizationPackages: function () {
			var aList = this._getViewProperty("AuthPackages/List"),
				aBackup = this._getViewProperty("AuthPackages/Backup"),
				sUserId = this._getUserId(),
				sBatchGroupId = "idAssignUserAPs",
				oModel = this.getModel("ap"),
				oModelParameters = {
					groupId: sBatchGroupId
				};

			var aNewAuthPackages = aList.map(function (oPack) {
					return oPack.AuthPackId;
				}),
				aExistingAuthPackages = aBackup.map(function (oPack) {
					return oPack.AuthPackId;
				});

			var aToRemove = aExistingAuthPackages.filter(function (sAuthPackId) {
					return aNewAuthPackages.indexOf(sAuthPackId) === -1;
				}),
				aToAdd = aNewAuthPackages.filter(function (sAuthPackId) {
					return aExistingAuthPackages.indexOf(sAuthPackId) === -1;
				});

			this._setViewProperty("AuthPackages/Edit", false);
			this.setBusy(true);

			var oPromise = Promise.resolve();

			if (aToRemove.length || aToAdd.length) {
				oModel.setUseBatch(true);
				oModel.setDeferredGroups([sBatchGroupId]);

				aToAdd.forEach(function (sAuthPackId) {
					oModel.update(Util.formatMessage("/auth_pack_set_for_userSet(AuthPackId=''{0}'',SUser=''{1}'')", [sAuthPackId, sUserId]), {
						SUser: sUserId,
						AuthPackId: sAuthPackId
					}, oModelParameters);
				});

				aToRemove.forEach(function (sAuthPackId) {
					oModel.remove(Util.formatMessage("/auth_pack_set_for_userSet(AuthPackId=''{0}'',SUser=''{1}'')", [sAuthPackId, sUserId]),
						oModelParameters);
				});

				oPromise = Util.promiseSubmitChanges(oModelParameters, oModel)
					.then(function () {
						sap.m.MessageToast.show(this.getText("MESSAGE_AP_UPDATED"));
					}.bind(this))
					.catch(function (oXhrError) {
						var sResponseText = oXhrError.responseText,
							oError = JSON.parse(sResponseText);
						sap.m.MessageToast.show(oError.error.message.value);
					})
					.finally(function () {
						this.setBusy(false);
						window.location.reload();
						oModel.setUseBatch(false);
					}.bind(this));
			}

			oPromise.finally(function () {
				//this._requestExistingAP(sUserId);
				this._requestExistingAuthorizations(sUserId);
				this._refreshImportantFunctions();
				oModel.refresh();
				this.setBusy(false);
			}.bind(this));
		},

		/**
		 * Save changes in authorizations
		 * @event
		 * @public
		 */
		onSaveAuthorizations: function () {
			var sBatchGroupId = "idUserAuthObjAssignGroup",
				oModel = this.getModel();

			this._setAuthEditMode(false);
			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups([sBatchGroupId]);
			this._getAuthorizationList().forEach(this._saveSingleAuth.bind(this, sBatchGroupId, oModel));

			this.setBusy(true);
			this._submitChanges({
					batchGroupId: sBatchGroupId
				})
				.then(function (oData) {
					if (Util.getBatchMessage(oData) !== Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData)) {
						sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_AUTH_SAVED"));
					} else {
						if (oData.__batchResponses[0].response.statusCode === "403") {
							var dialogContent = new sap.m.FormattedText();
							var errorMessage =
								this.getBundle().getText("RESTRICTED_AUTH_NORMAL") + "<br><br><strong>" + this.getBundle().getText("RESTRICTED_AUTH_BOLD") +
								"</strong>";
							dialogContent.setHtmlText(errorMessage);
							dialogContent.addStyleClass("sapUiSmallMarginBeginEnd sapUiSmallMarginTopBottom");
							var oDialog = new sap.m.Dialog({
								title: this.getBundle().getText("RESTRICTED_AUTH_TITLE"),
								state: sap.ui.core.ValueState.Warning,
								icon: "sap-icon://message-warning",
								content: [
									dialogContent
								],
								beginButton: new sap.m.Button({
									text: this.getBundle().getText("BUTTON_USER_OK"),
									type: sap.m.ButtonType.Default,
									press: function () {
										oDialog.close();
									}
								})
							});
							oDialog.setContentWidth("40vw");
							oDialog.open();
						}
						this._resetAuthorizationsList();
					}
				}.bind(this))
				.fail(function (oError) {
					Util.JSONError.showToast(oError);
					this._resetAuthorizationsList();
				}.bind(this))
				.always(function () {
					this.setBusy(false);
					oModel.setUseBatch(false);
					oModel.refresh();
				}.bind(this));
		},

		/**
		 * Save changes in cloud authorizations
		 * @event
		 * @public
		 */
		onSaveCloudAuth: function () {
			var sBatchGroupId = "idUserAuthObjCloudAssignGroup",
				oModel = this.getModel("ca");

			this._setViewProperty("Cloud/Edit", false);
			oModel.setUseBatch(true);
			oModel.setDeferredGroups([sBatchGroupId]);
			var bHasChanges = this._getViewProperty("Cloud/List")
				.map(this._saveSingleCloudAuth.bind(this, sBatchGroupId, oModel))
				.some(Boolean);

			if (bHasChanges) {
				this._submitChanges({
						groupId: sBatchGroupId
					}, "ca")
					.then(function (oData) {
						var sMessage = Util.getBatchMessage(oData),
							oError = Util.getBatchError(oData);
						if (sMessage !== Constant.HTTP_REQUEST_FAILED && !oError) {
							sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_AUTH_SAVED"));
						} else {
							Util.showErrorBox(sMessage);
							this._resetCloudAuthList();
						}
					}.bind(this))
					.fail(function (oError) {
						Util.JSONError.showToast(oError);
						this._resetCloudAuthList();
					})
					.always(function () {
						oModel.setUseBatch(false);
						oModel.refresh();
					});
			} else {
				sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_AUTH_SAVED"));
			}
		},

		/**
		 * Save changes in contact details
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		onSaveContactDetails: function (oEvent) {
			var oData = this._getViewProperty("Contact/Data"),
				sFirstNumber = oData.Phone1NumberPlain,
				sSecondNumber = oData.Phone2NumberPlain;
			var sFullEmail = this._getFullEmail();
			var bIsSameEmail = this.sCurrentEmail === sFullEmail;
			if (!bIsSameEmail) {
				this._validateDomainPart();
			}
			var notesLength = this.getView().getModel("view").getProperty("/UserDetail/Contact/Data/Notes").length;
			var additionalNotesRemovedForUnverifiedDomain = this.getView().getModel("view").getProperty("/additionalNotesRemovedForUnverifiedDomain");
			var bEmailDomainValid = this._getViewModel().getProperty("/isEmailDomainVerified") || notesLength > 0;
			this._checkEmailValidity().then(function (oResult) {
				if ((!oResult.bEmailValid || !Util.detail.validatePhoneNumber(sFirstNumber) || !bEmailDomainValid) && !bIsSameEmail) {
					this._showEmailValidationError(oResult, true);
					if (!oEvent) {
						this.onCancelContactDetails();
					} else {
						Util.showToast(this.getText("MESSAGE_ENTER_VALID_CONTACT_DATA"));
					}
				} else if (notesLength == 0 && additionalNotesRemovedForUnverifiedDomain) {
					Util.showToast(this.getText("MESSAGE_ENTER_VALID_CONTACT_DATA"));					
				} else {
					var oContext = this.getView().getBindingContext(),
						oContactData = {
							CountryCode: oData.Phone1Country,
							// 08.03.2023/I565696/UMT-1259 United Arab Emirates cannot be saved in details page
							// Full country name is actually not used in BE when updating the user info
							// CountryCode field is used instead, therefore no need to send it here
							// This way avoiding the exception when validating length of corresponding field in BE data structure
							// CountryName: this.byId("umSelectUserFirstCountry").getSelectedItem().getText(),
							Email: sFullEmail,
							FirstPhoneNumber: sFirstNumber,
							JobTitle: oData.JobTitle,
							LanguageCode: oData.Language,
							LanguageName: this.byId("umSelectUserLanguage").getSelectedItem().getText(),
							Notes: oData.Notes,
							Salutation: oData.Salutation,
							SecondPhoneCountryId: oData.Phone2Country,
							SecondPhoneNumber: sSecondNumber
						};

					if (this._getSettings().isNewDepartmentAPIEnabled) {
						oContactData.DepartmentId = oData.DepartmentId;
						oContactData.DepartmentName = oData.Department;
					} else {
						oContactData.DepartmentName = unescape(oData.Department);
					}

					if (this._getSettings().isSUserLifetimeEnabled) {
						oContactData.ExpiryStatus = UserExpirationStatus.ACTIVE;
					}

					this._setContactEditMode(false);
					this.setBusy(true);
					this.getUserSetODataUtil().updateUser.call(this, oContext.getPath(), oContactData)
						.then(function () {
							sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_USER_DATA_UPDATE_SUCCESS"));
						}.bind(this))
						.catch(Util.JSONError.showToast)
						.finally(this.setBusy.bind(this, false));
						
					this._clearExpandMsgs(true);
					this._clearBorders();	
				}
			}.bind(this));
		},

		onSaveContactDetailsOld: function (oEvent) {
			var oData = this._getViewProperty("Contact/Data"),
				sFirstNumber = Util.detail.dividePhoneNumber(oData.Phone1Number),
				sSecondNumber = Util.detail.dividePhoneNumber(oData.Phone2Number);
			var bPerformDuplicateCheck = true;
			var bIsSameEmail = this.sCurrentEmail === this._getViewProperty("Contact/Data/Email");
			this._checkEmailValidity(bPerformDuplicateCheck && !bIsSameEmail).then(function (oResult) {
				if ((!oResult.bEmailValid || !Util.detail.validatePhoneNumber(sFirstNumber)) && !bIsSameEmail) {
					this._showEmailValidationErrorOld(oResult, true);
					if (!oEvent) {
						this.onCancelContactDetails();
					} else {
						Util.showToast(this.getText("MESSAGE_ENTER_VALID_CONTACT_DATA"));
					}
				} else {
					var oContext = this.getView().getBindingContext(),
						oContactData = {
							CountryCode: oData.Phone1Country,
							CountryName: this.byId("umSelectUserFirstCountry").getSelectedItem().getText(),
							Email: oData.Email,
							FirstPhoneNumber: sFirstNumber,
							JobTitle: oData.JobTitle,
							LanguageCode: oData.Language,
							LanguageName: this.byId("umSelectUserLanguage").getSelectedItem().getText(),
							Notes: oData.Notes,
							Salutation: oData.Salutation,
							SecondPhoneCountryId: oData.Phone2Country,
							SecondPhoneNumber: sSecondNumber
						};

					if (this._getSettings().isNewDepartmentAPIEnabled) {
						oContactData.DepartmentId = oData.DepartmentId;
						oContactData.DepartmentName = oData.Department;
					} else {
						oContactData.DepartmentName = unescape(oData.Department);
					}

					if (this._getSettings().isSUserLifetimeEnabled) {
						oContactData.ExpiryStatus = UserExpirationStatus.ACTIVE;
					}

					this._setContactEditMode(false);
					this.setBusy(true);
					this.getUserSetODataUtil().updateUser.call(this, oContext.getPath(), oContactData)
						.then(function () {
							sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_USER_DATA_UPDATE_SUCCESS"));
						}.bind(this))
						.catch(Util.JSONError.showToast)
						.finally(this.setBusy.bind(this, false));
				}
			}.bind(this));
		},
		
		onEmailDomainChange: function (oEvent) {
			this.bHasDomainChanged = true;
			this._validateEmail();
		},
		
		_getFullEmail: function () {
			var sEmail, oUserData = {customerNumber: this._getViewProperty("UserData/CustomerId")};
			if (this.getView().getModel("appSettings").getProperty("/domainCheckActive")) {
				var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
				var domain = domainSelectorSuperCloudAdmin.getVisible() ? domainSelectorSuperCloudAdmin.getValue() : this.getView().getModel("view").getProperty("/domainPartOfEmail");
				return [
					this.getView().getModel("view").getProperty("/namePartOfEmail"), 
					domain
				].join("@");
			} else {
				return sEmail = this._getViewProperty("Contact/Data/Email");
			}
		},
		
		_validateEmail: function () {
			var sEmail = this._getFullEmail();
			if (sEmail === this.sLastValidatedEmail) {
				//Fix user admin switch name field to domain field bug
				this._validateDomainPart();
				return;
			} else {
				this.getView().getModel("view").setProperty("/isEmailDuplicate", false);
			}
			this.sLastValidatedEmail = sEmail;			
			if (this._getViewProperty("IsEmailOnFocusValidationFinished")) {
				this._checkEmailValidity().then(function (oResult) {
					//ignore results when email already changed or user already cancelled the edit mode
					if(oResult.sValidatedEmail === sEmail && this._isContactEditMode()) {
						if (oResult.bEmailValid) {
							this._hideAllEmailErrors();
							this.getView().getModel("view").setProperty("/isFormatInvalid", false);
							this.getView().getModel("view").setProperty("/isEmailShared", false);
							this.getView().getModel("view").setProperty("/isEmailDuplicate", false);
							this.getView().getModel("view").setProperty("/isEmailLengthInvalid", false);
							this.getView().getModel("view").setProperty("/isEmailLinkedDifferentUid", false);
							this.getView().getModel("view").setProperty("/isEmailNotLinkedUid", false);
							this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
							this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.None);
							this._clearExpandMsgs();
						} else {
							this._showEmailValidationError(oResult, false, sEmail);
						}
						this._validateDomainPart();
					}
				}.bind(this));
			}
		},
		
		_validateEmailOld: function () {
			var sEmail = this._getViewProperty("Contact/Data/Email");
			if (this._getViewProperty("IsEmailOnFocusValidationFinished")) {
				this._checkEmailValidity().then(function (oResult) {
					if (oResult.bEmailValid) {
						this._showErrorEmailNone();
					} else {
						this._showEmailValidationErrorOld(oResult, false, sEmail);
					}
				}.bind(this));
			}
		},

		_showEmailValidationErrorOld: function (oResult, bShowEmailDuplicateDialog, sCheckedEmail) {
			if (!oResult.bEmailFormatValid) {
				this._showErrorEmailInvalidFormat();
			} else if (oResult.bInvalidLength){
                this._showErrorEmailInvalidLength(oResult.iMaxLength);
			} else if (oResult.bEmailShared) {
				this._showErrorEmailShared();
			} else if (oResult.bEmailDuplicate) {
				this._showErrorEmailIsDuplicateOld(bShowEmailDuplicateDialog, sCheckedEmail);
			} else {
				this._showErrorEmailNone();
			}
		},

		_showErrorEmailNone: function () {
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.None);
		},

		_isLocalPartInvalid: function () {
			var emailRegexp = this.getView().getModel("appSettings").oData.emailRegexp;
			var localPartRegex = emailRegexp.split("@")[0] + "$";
			var oEmailRegex = new RegExp(localPartRegex, "i");
			var localEmailPart = this.getView().getModel("view").getProperty("/namePartOfEmail");
			var isLocalPartValid = Boolean(localEmailPart && oEmailRegex.test(localEmailPart));
			return !isLocalPartValid;
		},

		_showEmailValidationError: function (oResult, bShowEmailDuplicateDialog, sCheckedEmail) {
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
			var domain = domainSelectorSuperCloudAdmin.getVisible() ? domainSelectorSuperCloudAdmin.getValue() : this.getView().getModel("view").getProperty("/domainPartOfEmail");
			if (this._isLocalPartInvalid()) {
				this._showErrorEmailInvalidFormat();
			} else {
				this.getView().getModel("view").setProperty("/isFormatInvalid", false);
			}

			if (oResult.bInvalidLength) {
				this._showErrorEmailInvalidLength(oResult.iMaxLength);
			} else {
				this.getView().getModel("view").setProperty("/isEmailLengthInvalid", false);
			}
			
			if (oResult.bEmailShared) {
				this._showErrorEmailShared();
			} else {
				this.getView().getModel("view").setProperty("/isEmailShared", false);
			}
	
			if (oResult.bEmailDuplicate) {
				this._showErrorEmailIsDuplicate(bShowEmailDuplicateDialog, sCheckedEmail);
			} else {
				this.getView().getModel("view").setProperty("/isEmailDuplicate", false);
			}

			if (oResult.bLinkedToDifferentUid) {
				this._showErrorEmailLinkedDifferentUid();
			} else {
				this.getView().getModel("view").setProperty("/isEmailLinkedDifferentUid", false);
			}

			if (!oResult.bLinkedToUid) {
				this._showErrorEmailNotLinkedUid();
			} else {
				this.getView().getModel("view").setProperty("/isEmailNotLinkedUid", false);
			}

			this._expandFirstErrorMsg();
		},

		_checkEmailValidity: function () {
			var 
				email = this._getFullEmail(),
				userData = {
					customerNumber: this._getViewProperty("UserData/CustomerId"),
					userId: this._getViewProperty("UserData/UserId")
				},
				duplicateCheck = true, 
				sharedEmailCheck = true, 
				uidAssigned = this._getViewProperty("UserData/IsUidAssigned"),
				lengthCheck = true;
			
			return EmailValidator.setConcurrentCheck(true).validate.call(this, 
				email, 
				userData, 
				duplicateCheck, 
				sharedEmailCheck, 
				uidAssigned, 
				lengthCheck
			);
		},
		
		_isDomainCorrectFormat: function(sDomainName) {
			var oDomainConfigModel = this.getView().getModel("DomainConfig"),
				sRegex = oDomainConfigModel.getProperty("/REGEX_VALID_DOMAIN");
			var pattern = new RegExp(sRegex);
			var isDomainMatchingRegexp =  pattern.test(sDomainName);
			
			if (sDomainName.length < 1 || !isDomainMatchingRegexp) {
				return false;
			} else {
				return true;
			}
		},
		_validateDomainPart: function() {
			var bIsSuperAdmin = this.getView().getModel("app").getProperty("/IsSuperAdmin");
			if (bIsSuperAdmin) {
				this._validateDomainSuperOrCloudAdmin();
			} else {
				this._validateDomainUserAdmin();
			}
		},
		
		validateAdditionalNotes: function() {
			var notesLength = this.getView().getModel("view").getProperty("/UserDetail/Contact/Data/Notes").length;
			var domainCheckActive = this.getView().getModel("appSettings").getProperty("/domainCheckActive");
			if (notesLength == 0 && domainCheckActive) {
				var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
				var selectedDomain = domainSelectorSuperCloudAdmin.getSelectedItem();
				var isSelectedFromAllowedDomainList = selectedDomain !== null && selectedDomain.getEnabled();
				if (!isSelectedFromAllowedDomainList) {
					this.getView().getModel("view").setProperty("/valueStateForNotesArea", "Warning");	
					this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Warning);
					this.getView().getModel("view").setProperty("/additionalNotesRemovedForUnverifiedDomain", true);
					this.getView().byId("unverifiedEmailDomainSuperAdminStrip").setVisible(true);
					this.getView().byId("unverifiedEmailDomainSuperAdminStrip").setExpand(true);
				} else {
					this.getView().getModel("view").setProperty("/additionalNotesRemovedForUnverifiedDomain", false);
				}
			} else {
				this.getView().getModel("view").setProperty("/additionalNotesRemovedForUnverifiedDomain", false);
			}
		},
		
		_validateDomainUserAdmin: function() {
			if (this.getView().byId("domainSelectorUserAdmin").getSelectedItem().getEnabled()) {
				this.getView().getModel("view").setProperty("/isEmailDomainVerified", true);
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", sap.ui.core.ValueState.Information);
			} else {
				this.getView().getModel("view").setProperty("/isEmailDomainVerified", false);
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", sap.ui.core.ValueState.Error);
			}
			this._clearExpandMsgs();
			this._expandFirstErrorMsg();			
		},
		
		_validateDomainSuperOrCloudAdmin: function() {
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
			var sDomainName = domainSelectorSuperCloudAdmin.getValue();
			var isSelectedFromAllowedDomainList = domainSelectorSuperCloudAdmin.getSelectedItem() !== null && sDomainName !== this.unverifiedStartDomain;
			if (isSelectedFromAllowedDomainList) {
				this.getView().getModel("view").setProperty("/isEmailDomainVerified", true);
				this.getView().getModel("view").setProperty("/isEmailDomainFormatValid", true);
				if(this.getView().getModel("view").getProperty("/isEmailDuplicate")){
					this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Error);
				} else {
					if(domainSelectorSuperCloudAdmin.bIsFocused){
						this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Information);
					} else {
						this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
					}
				}
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");									
			} else if (this._isDomainCorrectFormat(sDomainName)) {				
				this.getView().getModel("view").setProperty("/isEmailDomainVerified", false);
				this.getView().getModel("view").setProperty("/isEmailDomainFormatValid", true);
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "Warning");	
				if (this.getView().getModel("view").getProperty("/isEmailDuplicate")) {	
					this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Error);
				} else {
					this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Warning);
				}
				//Fix to make messageStrip visible after failed saving and refocus
				this.getView().byId("unverifiedEmailDomainSuperAdminStrip").setVisible(true);							
			} else {
				this.getView().getModel("view").setProperty("/isEmailDomainVerified", true);
				this.getView().getModel("view").setProperty("/isEmailDomainFormatValid", false);
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Error);
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");									
			}
			this._clearExpandMsgs();
			this._expandFirstErrorMsg();
		},
		
		_validateDomainFormat: function() {
			var oDomainConfigModel = this.getView().getModel("DomainConfig"),
				sRegex = oDomainConfigModel.getProperty("/REGEX_VALID_DOMAIN");

			if (sValue.length < 1 || !this.isValidDomain(sValue, sRegex)) {
				oBinding.setValueState("Error");
				oViewModel.setProperty("/enableCustomerSelection", false);
				oViewModel.setProperty("/addDomainButtonEnable", false);
				result = false;
			} else {
				oBinding.setValueState("None");
				oViewModel.setProperty("/enableCustomerSelection", true);
				oViewModel.setProperty("/addDomainButtonEnable", true);
				result = true;
			}
		},
		
		_showBordersForEmailParts_old: function() {
			if (this.getView().getModel("view").getProperty("/isValid")) {
				this.getView().byId("namePartOfEmail").setValueState("None");
				this.getView().byId("signPartOfEmail").removeStyleClass("sapMInputBaseContentWrapperError");
				this.getView().byId("domainSelectorSuperCloudAdmin").setValueState("None");
				// if (!this.getView().getModel("app").getProperty("/IsSuperAdmin")) {
				// 	this.getView().byId("domainSelectorUserAdmin").setValueState("None");
				// }	
			}
			if (!this.getView().getModel("view").getProperty("/isEmailDomainVerified") || !this.getView().getModel("view").getProperty("/isEmailDomainFormatValid")){
				this.getView().byId("namePartOfEmail").setValueState("None");
				this.getView().byId("signPartOfEmail").removeStyleClass("sapMInputBaseContentWrapperError");
				this.getView().byId("domainSelectorSuperCloudAdmin").setValueState("Warning");
				// if (!this.getView().getModel("app").getProperty("/IsSuperAdmin")) {
				// 	this.getView().byId("domainSelectorUserAdmin").setValueState("None");
				// }	
			}
		},
		
		_hideAllEmailErrors: function (bUnchangedEmailLostFocus) {
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.None);
			if(!bUnchangedEmailLostFocus){
				this.getView().getModel("view").setProperty("/isEmailDomainVerified", true);
			}
			this.getView().getModel("view").setProperty("/isValid", true);
			this.getView().getModel("view").setProperty("/isEmailDomainFormatValid", true);
			this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
			this._showBordersForEmailParts();
		},

		_showErrorEmailShared: function () {
			this._setViewProperty("Contact/Data/ValidationEmailText", this.getText("MESSAGE_SHARED_EMAIL_NEW"));
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.Error);
			this.getView().getModel("view").setProperty("/isEmailShared", true);
		},

		_showErrorEmailInvalidFormat: function () {
			this._setViewProperty("Contact/Data/ValidationEmailText", this.getText("MESSAGE_EMAIL_INVALID"));
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.Error);
			this.getView().getModel("view").setProperty("/isFormatInvalid", true);
		},

		_showErrorEmailInvalidLength: function (iLength) {
			this._setViewProperty("Contact/Data/ValidationEmailText", this.getText("MESSAGE_EMAIL_LENGTH_INVALID_OLD",[iLength]));
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.Error);
			this.getView().getModel("view").setProperty("/isEmailLengthInvalid", true);
			this.getView().getModel("view").setProperty("/maxEmailLength", iLength);
		},

		_showErrorEmailIsDuplicate: function (bShowEmailDuplicateDialog, sCheckedEmail) {
			var sEmail = sCheckedEmail? sCheckedEmail: this._getFullEmail();
			if(!bShowEmailDuplicateDialog){
				if((this.sCurrentEmail === sEmail && this._getIsNoDuplicate()) || !this._getViewProperty("IsEmailOnFocusValidationFinished")){
					this._hideAllEmailErrors();
					this._validateDomainPart();
					return;
				}				
			}		
			this._setViewProperty("Contact/Data/ValidationEmailText", this._oFormattedDuplicateErrorText);
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.Error);
			this._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Error);
			this._setViewProperty("emailDomainUserAdminValueState", sap.ui.core.ValueState.Error);
			this.getView().getModel("view").setProperty("/isEmailDuplicate", true); 
			this.getView().getModel("view").setProperty("/emailDuplicateText", this.getText("MESSAGE_STRIP_DETAILS__DUPLICATE_EMAIL"));
			var oData = {
				Email: sEmail,
				CustomerNumber: this._getViewProperty("UserData/Kunnr")
			};
			var duplicateDialog = this._oDialogs.getDialog("EmailDuplicates");
			duplicateDialog.setViewModel(oData);
			duplicateDialog.setExcludeUser(this._getUserId());
			if(bShowEmailDuplicateDialog){
					duplicateDialog.syncStyleClass()
					.open(this);
			}
			return false;
		},

		_showErrorEmailIsDuplicateOld: function (bShowEmailDuplicateDialog, sCheckedEmail) {
			var sEmail = sCheckedEmail? sCheckedEmail: this._getViewProperty("Contact/Data/Email");
			if(this.sCurrentEmail === sEmail){
				this._showErrorEmailNone();
				return;
			}			
			this._setViewProperty("Contact/Data/ValidationEmailText", this._oFormattedDuplicateErrorText);
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.Error);

			var oData = {
				Email: sEmail,
				CustomerNumber: this._getViewProperty("UserData/Kunnr")
			};
			if(bShowEmailDuplicateDialog){
				this._oDialogs.getDialog("EmailDuplicates")
					.setViewModel(oData)
					.syncStyleClass()
					.open(this);
			}
		},

		_showErrorEmailLinkedDifferentUid: function () {
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.Error);
			this.getView().getModel("view").setProperty("/isEmailLinkedDifferentUid", true);
		},

		_showErrorEmailNotLinkedUid: function () {
			this._setViewProperty("Contact/Data/EmailValueState", sap.ui.core.ValueState.Error);
			this.getView().getModel("view").setProperty("/isEmailNotLinkedUid", true);
		},

		getSettings: function () {
			return Settings.userDetailView;
		},

		handleEmailDuplicateDialogClose: function () {
			this._setContactEditMode(true);
		},

		/**
		 * Validate user's Email
		 * @param {object} oEvent live change event
		 * @function
		 * @public
		 */
		validateEmail: function () {
			if (!this._getViewProperty("IsEmailOnFocusValidationFinished")) {
				// this._sleep(2500);
			}
			clearTimeout(this._typingTimer);
			if (this.getView().getModel("appSettings").getProperty("/domainCheckActive")) {
				this._typingTimer = setTimeout(this._validateEmail.bind(this), this._doneTypingInterval);
			} else {
				this._typingTimer = setTimeout(this._validateEmailOld.bind(this), this._doneTypingInterval);				
			}
		},

		onEmailIconPress: function (oEvent) {
			if (!this._oEmailValidationPopover) {
				this._oEmailValidationPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.EMailValidationPopover", this);
				this._oEmailValidationPopover.setModel(this.getModel("i18n"), "i18n");
				this.getView().addDependent(this._oEmailValidationPopover);
			}

			this._oEmailValidationPopover.setPlacement(sap.m.PlacementType.Bottom);
			this._oEmailValidationPopover.openBy(oEvent.getSource());
		},

		openAuthorizationHistoryDialog: function () {
			if (this._getSettings().isExpDateHistoryEnabled) {
				this._oDialogs.getDialogAndReset("History")
					.setUser(this._getUserId())
					.open();
			} else {
				this._oDialogs.getDialogAndReset("AuthorizationHistory")
					.setUser(this._getUserId())
					.open();
			}
		},

		/**
		 * Open dialog to manage user's expiry date
		 * KNGMHM02-18662
		 * @event
		 * @public
		 */
		openManageExpiryDateDialog: function () {
			this._oDialogs.getDialogAndReset("ManageExpiryDate")
				.setSelectedUsers([this._getViewProperty("UserData")])
				.open();
		},

		onExit: function () {
			if (this._oDialogCopyAuth) {
				this._oDialogCopyAuth.destroy();
			}

			if (this._oDialogCopyAuthLevels) {
				this._oDialogCopyAuthLevels.destroy();
			}

			if (this._oUidPopover) {
				this._oUidPopover.destroy();
			}
		},

		/**
		 * Handle Copy User's Authorizations footer button press
		 * Open dialog to Copy Authorizations
		 * @event
		 * @public
		 */
		onPressCopyAuthAction: function () {
			this._oDialogs.getDialog("CopyUsersAuthorizations")
				.setUserData(this._getUserId(), this._getViewProperty("UserData"))
				.syncStyleClass()
				.open();
		},

		/**
		 * Set deparment got from the Assign Department Dialog
		 * @param {string} sDepartmentId department id
		 * @param {string} sDepartmentName department name
		 * @function
		 * @public
		 */
		setNewDepartment: function (sDepartmentId, sDepartmentName) {
			this._setViewProperty("Contact/Data/DepartmentId", sDepartmentId || "");
			this._setViewProperty("Contact/Data/Department", sDepartmentName || "");
		},

		/**
		 * Open dialog to select user's department for old Department API
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		handleDeptValueHelp: function (oEvent) {
			this._oDepartmentInput = oEvent.getSource().getId();
			this._oDialogs.getDialogAndReset("SelectUserDepartment").open();
		},

		/**
		 * Select given department for user using old Department API
		 * @param {string} sDepartmentName dept name
		 * @function
		 * @public
		 */
		selectDepartment: function (sDepartmentName) {
			if (this._oDepartmentInput) {
				this._oDepartmentInput.setValue(sDepartmentName);
			}
		},

		/**
		 * Show Important Information popover
		 * @event
		 * @public
		 */
		showImportantInfo: function () {
			if (!this._oImportantInfoPopover) {
				this._oImportantInfoPopover = sap.ui.xmlfragment("sap.support.useradministration.view.ImportantInfo", this);
				this.getView().addDependent(this._oImportantInfoPopover);
			}

			var oIcon = this.getView().byId("idImportantInfoIcon");
			this._oImportantInfoPopover.openBy(oIcon);
		},

		/**
		 * Close popover
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		closePopover: function (oEvent) {
			var oPopover = Util.closest(oEvent.getSource(), sap.m.ResponsivePopover);
			if (oPopover) {
				oPopover.close();
			}
		},

		/**
		 * Open Copy Authorization Levels dialog for selected authorization
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		handleCopyAuthorizationLevels: function (oEvent) {
			var oAuth = oEvent.getSource().getBindingContext("view").getObject();

			this._oCopyAuthorizationLevelsDialog = this._oDialogs.getDialog("CopyAuthorizationLevels");
			this._oCopyAuthorizationLevelsDialog.syncStyleClass()
				.initAuthorization(oAuth.AuthLevelId, oAuth.ObjectId, oAuth.ObjectDesc)
				.initUser(oAuth.UserId)
				.open();
		},

		/**
		 * Go to existing authorization detail page
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		handleExistAuthListItemPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view"),
				oAuth = Util.copy(oContext.getObject()),
				bIsGlobalAuth = oEvent.getSource().getBindingContext().getProperty("AuthLevelId") !== "GLOBAL";

			if (bIsGlobalAuth || oAuth.isPackageAuth) {
				var aList = this._getViewProperty("Auth/List") || [];
				aList.some(function (oItem) {
					if (oItem.UserId === oAuth.UserId && oItem.ObjectId === oAuth.ObjectId) {
						oAuth = oItem;
						return true;
					}
					return false;
				});
				this._navDetailAuth(oAuth);
			}
		},

		/**
		 * Go to cloud authorization detail page
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		handleExistCloudAuthListItemPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view"),
				oAuth = Util.copy(oContext.getObject()),
				aList = this._getViewProperty("Cloud/List") || [];

			// Find authorization in local model
			var bFound = aList.some(function (oItem) {
				if (oItem.Userid === oAuth.Userid && oItem.AuthObjectText === oAuth.AuthObjectName) {
					oAuth = oItem;
					return true;
				}
				return false;
			});

			if (bFound && oAuth._HasDetails) {
				this._navDetailCloudAuth(oAuth);
			}
		},

		/**
		 * Open dialog to edit user's Authorization Package list
		 * @event
		 * @public
		 */
		onUserAPTableEdit: function () {
			var sUserId = this._getUserId(),
				oDialog = this._oDialogs.getDialogAndReset("AssignUserAuthPackages"),
				aList = this._getViewProperty("AuthPackages/List");

			this._setViewProperty("AuthPackages/Edit", true);
			oDialog.setInitialSelection(aList.map(function (oPackage) {
				return oPackage.AuthPackId;
			}), aList.filter(function (oPackage) {
				return oPackage.isInactive;
			}).map(function (oPackage) {
				return oPackage.AuthPackId;
			}));
			oDialog.setUserId(sUserId);
			oDialog.open();
		},

		/**
		 * Open authorization package detail
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		handleAPPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view"),
				oUserAP = oContext.getObject(),
				bViewMode = this._getViewProperty("ViewMode") || this._getViewProperty("AuthPackages/Edit");

			this.getRouter().navTo(bViewMode ? "authPackageView" : "authPackageDetail", {
				from: USER_DETAIL_ROUTE,
				object: oUserAP.AuthPackId
			}, /* bReplace = */ false);
		},

		onDeletePress: function () {
			var oView = this.getView();
			var userId = this._getUserId();
			var userCricalRole = this.getView().getBindingContext().getObject().UserCriticalRole;
			var userType = this.getView().getBindingContext().getObject().UserType;

			if (userId === oView.__logonUserID) {
				sap.m.MessageBox.show(this.getText("MESSAGE_USER_SELF_DELETE_WARNING"), {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: this.getText("TOOLTIP_USER_DELETE"),
					actions: [sap.m.MessageBox.Action.OK]
				});
			} else if (userCricalRole || userType === UserType.PARTNER) {
				sap.m.MessageBox.show(this.getText("MASTER_CRITICAL_ROLE_USER"), {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: this.getText("TOOLTIP_CRITICAL_ROLE_ASSIGNED"),
					actions: [sap.m.MessageBox.Action.OK]
				});
			} else {
				sap.m.MessageBox.show(this.getText("MESSAGE_USER_DELETE_WARNING"), {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: this.getText("TOOLTIP_USER_DELETE"),
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.OK) {
							oView.getController()._deleteProcess(userId);
						}
					}
				});
			}
		},
		_deleteProcess: function (userId) {
			var sPath = "/UserSet('" + userId + "')";
			var oModel = this.getModel();
			this.setBusy(true);
			oModel.setUseBatch(true);
			this._triggerBusEvent("deleteSingleUserInDetailsRefresh");
			Util.promiseDelete.call(this, sPath, oModel)
				.then(function () {
					sap.m.MessageBox.show((this.getText("MESSAGE_USER_DELETED")), {
						title: this.getText("TOOLTIP_USER_DELETE"),
						onClose: function () {
							this.getRouter().navTo("UA_main", {}, false);
						}.bind(this)
					});
					//Update launchpad KPIs
					sap.ui.getCore().getEventBus().publish("landingpage", "refresh", {
						source: "useradminnew",
						target: "userManagement"
					});
				}.bind(this))
				.catch(function () {
					if (!this.DeletionErrorDialog ) {
						this.DeletionErrorDialog = new sap.m.Dialog({
							type: "Message",
							title: this.getText("GENERAL_ERROR_TITLE"),
							state: "Error",
							content: new sap.m.FormattedText({ 
								htmlText: this.getText("GENERAL_ERROR_MESSAGE")
							}),
							beginButton: new sap.m.Button({
								text: this.getText("BUTTON_USER_OK"),
								press: function () {
									this.DeletionErrorDialog.close();
									this.getRouter().navTo("UA_main", {}, false);
								}.bind(this)
							})
						});
					}
					this.DeletionErrorDialog.open();
				}.bind(this))
				.finally(function () {
					oModel.setUseBatch(false);
					this.setBusy.bind(this, false);
				}.bind(this));
		},
		
		onNotesIconPress: function (oEvent) {
			if (!this._oNotesPopover) {
				this._oNotesPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.NotesPopover", this);
				this._oNotesPopover.setModel(this.getModel("i18n"), "i18n");
			}
			this._oNotesPopover.setPlacement(sap.m.PlacementType.Bottom);
			this._oNotesPopover.openBy(oEvent.getSource());
		},
		
		onHighlightEmailPress: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			if (!this._oUnverifiedDomainPopover) {
				this._oUnverifiedDomainPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.UnverifiedDomainPopover", this);
				this._oUnverifiedDomainPopover.setModel(this.getModel("i18n"), "i18n");
			}
			var isEmailFormatValid = oContext.getProperty("IsEmailFormatValid");
			var isEmailNotShared = oContext.getProperty("IsEmailNotShared");
			var isEmailNotDuplicate = oContext.getProperty("IsEmailNotDuplicate");
			var isValidDomain = oContext.getProperty("IsValidDomain");

			this._oUnverifiedDomainPopover.setTitle(this.getText("DETAIL_NON_COMPLIANT_EMAIL_TITLE"));
			this._oUnverifiedDomainPopover.getContent()[0].setHtmlText(this.formatter.master.messageInvalidEmailOrDomain(this, isEmailFormatValid, isEmailNotShared, isEmailNotDuplicate, isValidDomain));

			this._oUnverifiedDomainPopover.setPlacement(sap.m.PlacementType.Bottom);
			this._oUnverifiedDomainPopover.openBy(oEvent.getSource());
		},
		
		_isSameEmail: function() {
			var bFirstProperty = this.sCurrentEmail === this._getViewProperty("Contact/Data/Email");
			var bSecondProperty = this.sCurrentEmail === this._getFullEmail();
			
			return bFirstProperty && bSecondProperty;
		},
		
		_emailValidationOnFocus: function(oEmailInput) {
			if (this.getView().getModel("appSettings").getProperty("/domainCheckActive")) {
				this.newEmailValidation(oEmailInput.getValue());
			}
			else {
				this.emailValidation(oEmailInput);
			}
		},
				
		_validateEmailOnFocus: function () {
			var sEmail = this._getViewProperty("Contact/Data/Email");
			this._checkEmailValidity().then(function (oResult) {
				if (oResult.bEmailValid) {
					this._hideAllEmailErrors();
				} else {
					this._showEmailValidationErrorOld(oResult, false, sEmail);
				}
				this._setViewProperty("IsEmailOnFocusValidationFinished", true);
			}.bind(this));
		},
		
		_sleep: function(milliseconds) {
			var date = Date.now();
			var currentDate = null;
			do {
				currentDate = Date.now();
			} while (currentDate - date < milliseconds);
		},

		onMsgStripTitleClick: function(oEvent) {
			this._collapseOtherMsgStrips(oEvent);
			this._showBordersForEmailParts();
		},
		
		_collapseOtherMsgStrips: function(oEvent) {
			var idExpandItem = oEvent.getSource().getId();
			var arrMgs = this._getArrayMsgStrips();
			arrMgs.forEach(function (item) {
				if(item.getId() !== idExpandItem) {
					item.setExpand(false); 
				}
				else {
					item.setExpand(!oEvent.getSource().getExpand());
				}
			});
			// this._showBordersForEmailParts();
		}, 
		_showBordersForEmailParts: function() {
			this.getView().byId("signPartOfEmail").removeStyleClass("sapMInputBaseContentWrapperError");
			if (this.getView().getModel("view").getProperty("/isValid")) {
				this._clearBorders();
			}			
			if (this.getView().byId("noAllowedEmailDomainsUserAdminStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "None");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "None");
			}
			if (this.getView().byId("noAllowedEmailDomainsSuperAdminStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "None");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "None");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
			}
			if (this.getView().byId("invalidEmailLengthStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "None");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "None");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
			}
			if (this.getView().byId("invalidEmailFormatStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "None");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "None");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
			}
			if (this.getView().byId("sharedEmailStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "None");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "None");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
			}
			if (this.getView().byId("duplicateEmailFormatStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "Error");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
			}
			if (this.getView().byId("unverifiedEmailDomainUserAdminStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "None");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "Error");
			}
			if (this.getView().byId("unverifiedEmailDomainSuperAdminStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "None");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "Warning");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "Warning");
			}
			if (this.getView().byId("invalidDomainFormatStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "None");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "Error");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
			}
			if (this.getView().byId("emailNotLinkedUidStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "Error");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
			}
			if (this.getView().byId("emailLinkedAnotherUidStrip").getExpand()){
				this._setViewProperty("Contact/Data/EmailValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", "Error");
				this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", "Error");
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
			}

		},
		_getArrayMsgStrips: function() {
			var arrMgs = [];
			arrMgs.push(this.getView().byId("noAllowedEmailDomainsUserAdminStrip"));
			arrMgs.push(this.getView().byId("noAllowedEmailDomainsSuperAdminStrip"));
			arrMgs.push(this.getView().byId("invalidEmailLengthStrip"));
			arrMgs.push(this.getView().byId("invalidEmailFormatStrip"));
			arrMgs.push(this.getView().byId("sharedEmailStrip"));
			arrMgs.push(this.getView().byId("duplicateEmailFormatStrip"));
			arrMgs.push(this.getView().byId("unverifiedEmailDomainUserAdminStrip"));
			arrMgs.push(this.getView().byId("unverifiedEmailDomainSuperAdminStrip"));
			arrMgs.push(this.getView().byId("invalidDomainFormatStrip"));
			arrMgs.push(this.getView().byId("emailNotLinkedUidStrip"));
			arrMgs.push(this.getView().byId("emailLinkedAnotherUidStrip"));
			return arrMgs;
		},
		
		_expandFirstErrorMsg: function() {
			var arrMgs = this._getArrayMsgStrips();
			var firstMsg = arrMgs.find(function (item) {
				return item.getVisible();
			});
			var firstID;
			if(firstMsg){
				firstMsg.setExpand(true);
				firstID = firstMsg.getId();
			} else {
				firstID = "";
			}
			arrMgs.filter(function (item) {
					return item.getId() !== firstID;
				})
				.forEach(function (item) {
					return item.setExpand(false);
				});
		},

		
		_clearExpandMsgs: function(bSetInvisible) {
			this.getView().byId("invalidEmailLengthStrip").setExpand(false);
			this.getView().byId("invalidEmailFormatStrip").setExpand(false);
			this.getView().byId("sharedEmailStrip").setExpand(false);
			this.getView().byId("duplicateEmailFormatStrip").setExpand(false);
			this.getView().byId("unverifiedEmailDomainUserAdminStrip").setExpand(false);
			this.getView().byId("unverifiedEmailDomainSuperAdminStrip").setExpand(false);
			this.getView().byId("invalidDomainFormatStrip").setExpand(false);
			this.getView().byId("emailNotLinkedUidStrip").setExpand(false);
			this.getView().byId("emailLinkedAnotherUidStrip").setExpand(false);
			if(bSetInvisible) {
				var arrMgs = this._getArrayMsgStrips();
				arrMgs.forEach(function (item) {
					item.setVisible(false); 
				});				
			}
		},
		_clearBorders: function(bUnchangedEmailLostFocus) {
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
			if(!bUnchangedEmailLostFocus) {
				this.getView().getModel("view").setProperty("/valueStateForNotesArea", "None");
				if(domainSelectorSuperCloudAdmin.getValueState() !== sap.ui.core.ValueState.Information) {
					this.getView().getModel("view").setProperty("/emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
				}
			}
			this.getView().byId("signPartOfEmail").removeStyleClass("sapMInputBaseContentWrapperError");
			this.getView().byId("namePartOfEmail").setValueState("None");
			this.getView().getModel("view").setProperty("/emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
		},
	});
});

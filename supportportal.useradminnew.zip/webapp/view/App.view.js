sap.ui.jsview("sap.support.useradministration.view.App", {

	getControllerName: function () {
		return "sap.support.useradministration.view.App";
	},
	
	createContent: function () {
		
		// to avoid scroll bars on desktop the root view must be set to block display
		this.setDisplayBlock(true);
		
		// create app
		this.app = new sap.m.App("idUAListApp");
		
		return new sap.m.Shell({
	        app: this.app,
	        showLogout: false,
	        appWidthLimited: false
		});
	}
});


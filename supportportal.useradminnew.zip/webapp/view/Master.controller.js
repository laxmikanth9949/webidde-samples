sap.ui.define([
	"sap/support/useradministration/controller/BaseController",
	"sap/support/useradministration/util/Util",

	"sap/support/useradministration/extended/SmartTable",
	"sap/base/Log",
	"sap/support/useradministration/util/Settings"
], function (BaseController, Util, SmartTable, Log, Settings) {

	jQuery.sap.require("sap.ui.core.util.Export");
	jQuery.sap.require("sap.support.useradministration.js.ExportTypeCSV");
	jQuery.sap.require("sap.support.useradministration.controller.Dialogs");

	var log = Log.getLogger("sap.support.useradministration.view.Master");

	var Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator,
		MessageBox = sap.m.MessageBox;

	var Callbacks = Util.callbacks,
		UserSet = Util.Constant.UserSet,
		UserType = Util.Constant.UserType;

	var ALL_USER_TABLE_ID = "idUserTable",
		REQ_USER_TABLE_ID = "idReqUserTable",
		DEL_USER_TABLE_ID = "idDelUserTable",
		IMP_CONT_TABLE_ID = "idImportantContactsTable",
		USER_REP_TABLE_ID = "idUserReportTable",
		AUTH_PACK_TABLE_ID = "idAuthPackagesTable",
		TASKS_TABLE_ID = "idTasksTable";

	var ALL_USERS_TAB = "AllUsers",
		REQ_USERS_TAB = "RequestedUsers",
		DEL_USERS_TAB = "DeletedUsers",
		IMP_CONTACT_TAB = "ImportantContacts",
		REPORTS_UPDATES_TAB = "ReportsAndUpdates",
		AUTH_PACK_TAB = "AuthPackages",
		TASKS_TAB = "Tasks";
		
	var oTabList = [ALL_USERS_TAB,REQ_USERS_TAB,DEL_USERS_TAB,IMP_CONTACT_TAB,REPORTS_UPDATES_TAB,AUTH_PACK_TAB,TASKS_TAB];
	var MODEL_TAB = "tab";

	var USER_DETAIL_ROUTE = "userDetailNew";

	var _oTabConfig = {};
	_oTabConfig[ALL_USERS_TAB] = {
		Table: ALL_USER_TABLE_ID
	};
	_oTabConfig[REQ_USERS_TAB] = {
		Table: REQ_USER_TABLE_ID
	};
	_oTabConfig[DEL_USERS_TAB] = {
		Table: DEL_USER_TABLE_ID
	};
	_oTabConfig[IMP_CONTACT_TAB] = {
		Table: IMP_CONT_TABLE_ID
	};
	_oTabConfig[REPORTS_UPDATES_TAB] = {
		Table: USER_REP_TABLE_ID
	};
	_oTabConfig[AUTH_PACK_TAB] = {
		Table: AUTH_PACK_TABLE_ID
	};

	return BaseController.extend("sap.support.useradministration.view.Master", {
		_fragments: {},
		_oHistory: sap.ui.core.routing.History.getInstance(),

		/**
		 * Initialize main view ..
		 * @function
		 * @public
		 */
		onInit: function () {
			var that = this;
			var oView = this.getView();
			
			this._initUserList();
			this.oFilterBar = oView.byId("filterBar4AR");
			this._oUABundle = this.getBundle();
			this._initTabModel();

			this.getRouter().attachRouteMatched(function (evt) {
				var oArguments = evt.getParameter("arguments"),
					sRouteName = evt.getParameter("name");

				//When detail navigation occurs, update the binding context
				if (sRouteName === "UA_main" || sRouteName === "UA_main_tab") {
					// Load icon tab bar content
					var oIconTabBar = oView.byId("idIconTabBar"),
						sTab = oArguments.tab;

					if (this.__fromTab) {
						oIconTabBar.setSelectedKey(this.__fromTab);
					} else if (sTab) {
						oIconTabBar.setSelectedKey(sTab);
					}

					if (sTab === REPORTS_UPDATES_TAB) {
						that._loadReportsAndUpdatesFilters();
						if (oArguments.install) {
							that._install_num = oArguments.install;
						}
					}
					that._initTab();

					that._setViewProperty("TabKey", oIconTabBar.getSelectedKey());
				} else if (sRouteName === "UA_main_search") {
					var oIconTabBar = oView.byId("idIconTabBar");
					if (this._oHistory.getDirection() !== sap.ui.core.routing.HistoryDirection.Backwards) {
						oIconTabBar.setSelectedKey("AllUsers");
					}

					var sSearchQuery = decodeURIComponent(oArguments.searchterm);
					if (!sSearchQuery || sSearchQuery === "undefined") {
						sSearchQuery = "";
					}
					that._delayedUserListSearch(sSearchQuery);
					that._setViewProperty("TabKey", oIconTabBar.getSelectedKey());
				}
			}, this);

			this.bEmptySearch = true;

			this.oFilterBar.registerFetchData(this._fetchData);
			this.oFilterBar.registerApplyData(this._applyData);

			this._oDialogs = new sap.support.useradministration.controller.Dialogs(this);
			this._bindViewModel("Master");
			this.createJSONModel({
				List: []
			}, "empty");

			this._setViewProperty("IsNewDepartmentAPIEnabled", this._isNewDepartmentAPIEnabled());
			this._setViewProperty("IsSelfAuthorizationRequestVisible", this._isSelfAuthorizationRequestVisible());
			// this._setViewProperty("IsDomainCheckEnabled", this._getSettings().isDomainCheckEnabled);
			/*this._setViewProperty("IsSettingsTabEnabled", this._isSettingsTabEnabled());*/
			

			this._attachBusEvent("tasksTableRefresh", this._handleTasksTableRefresh.bind(this));
			this._attachBusEvent("requestedUsersRefresh", this._handleRequestedUsersRefresh.bind(this));
			this._attachBusEventUserDetail("deleteSingleUserInDetailsRefresh", this._handleDeletedSingleUserInDetailsRefresh.bind(this));
			this._attachBusEventCreateAuthPack("createAuthPackRefresh", this._handleCreateAuthPackRefresh.bind(this));
			
			this._sRUSearch = "";
			this._aRUFilter = [];
			this._sDUSearch = "";
			this._aDUFilter = [];
			this._sICSearch = "";
			this._aICFilter = [];
			
			this._isUserTableFiltered = false;
			this.getRouter().getRoute("UA_main").attachMatched(this._onRouteMatched, this);
		},
		
		_onRouteMatched : function (oEvent) {
			var oArgs, oView, oQuery;
			oArgs = oEvent.getParameter("arguments");
			oView = this.getView();

			oQuery = oArgs["?query"];

			if (oQuery && oTabList.includes(oQuery.tab)){
				oView.getModel("view").setProperty("/selectedTabKey", oQuery.tab);
			} else {
				oView.getModel("view").setProperty("/selectedTabKey", ALL_USERS_TAB);
			}
		},	
		_initUserList: function () {
			this.isNewUserSet = this.getUserSetODataUtil().isUserNewSetEnabled();
			var sUserListName = "sap.support.useradministration.view.fragment.master." + ((this.isNewUserSet) ? "UserListNew" : "UserList"),
				oUserList = sap.ui.xmlfragment(sUserListName, this);
			this.oUserList = oUserList;
			this.getView().byId("usersListIcon").addContent(oUserList);
		},
		
		_getUserTable: function () {
			return this.oUserList;
		},
		
		getTableById: function (sTableName) {
			return (sTableName === ALL_USER_TABLE_ID) ? this._getUserTable() : this.getView().byId(sTableName);
		},

		/**
		 * Attach EventBus event
		 * @param {string} sEventName event name
		 * @param {function} fnHander event handler
		 * @function
		 * @private
		 */
		_attachBusEvent: function (sEventName, fnHander) {
			this.getOwnerComponent().getEventBus().subscribe("Master", sEventName, fnHander);
		},
		
		/**
		 * Attach EventBus event for UserDetail channel
		 * @param {string} sEventName event name
		 * @param {function} fnHander event handler
		 * @function
		 * @private
		 */
		_attachBusEventUserDetail: function (sEventName, fnHander) {
			this.getOwnerComponent().getEventBus().subscribe("UserDetail", sEventName, fnHander);
		},
		
		/**
		 * Attach EventBus event for CreateAuthPack channel
		 * @param {string} sEventName event name
		 * @param {function} fnHander event handler
		 * @function
		 * @private
		 */
		_attachBusEventCreateAuthPack: function (sEventName, fnHander) {
			this.getOwnerComponent().getEventBus().subscribe("CreateAuthPack", sEventName, fnHander);
		},

		_handleTasksTableRefresh: function () {
			this._invalidateTabs(["Tasks"]);
		},
		
		_handleRequestedUsersRefresh: function () {
			this._invalidateTabs([REQ_USERS_TAB]);
		},
		_handleDeletedSingleUserInDetailsRefresh: function () {
			this._invalidateTabs();
		},
		_handleCreateAuthPackRefresh: function () {
			this._invalidateTabs([AUTH_PACK_TAB]);
		},

		/**
		 * Do delayed search in user list
		 * It will be performed if not interrupted
		 * @param {string} sSearchQuery search query
		 * @function
		 * @private
		 */
		_delayedUserListSearch: function (sSearchQuery) {
			if (this._oUserListSearchTimer) {
				clearTimeout(this._oUserListSearchTimer);
			}

			this._oUserListSearchTimer = setTimeout(this._doUserListSearch.bind(this, sSearchQuery), 500);
		},

		/**
		 * Do search in user list
		 * @param {string} sSearchQuery search query
		 * @function
		 * @private
		 */
		_doUserListSearch: function (sSearchQuery) {
			var aFilters = [],
				oView = this.getView(),
				// oBinding = oView.byId(ALL_USER_TABLE_ID).getBinding("items");
				oBinding = this._getUserTable().getBinding("items");

			if (sSearchQuery && sSearchQuery.length) {
				//Start of remove I521000
				// var aProperties = [UserSet.USER_ID, UserSet.LAST_NAME, UserSet.FIRST_NAME,
				// 	/*UserSet.CUSTOMER_NUMBER, UserSet.CUSTOMER_NAME, 
				// 	UserSet.DEPARTMENT,*/
				// 	UserSet.EMAIL, UserSet.COUNTRY
				// ]; 
				//End of remove I521000
				
				var aProperties = [UserSet.SEARCH_FIELD];
				
				aFilters = aProperties.map(function (sFieldName) {
					return new Filter(sFieldName, FilterOperator.Contains, sSearchQuery);
				});
			}

			oBinding.filter(aFilters, "Application");

			if (oView._aCUFilters) {
				oBinding.filter(oView._aCUFilters, "Control");
			}
		},

		/**
		 * Get configuration for the current tab
		 * @returns {object} config
		 * @function
		 * @private
		 */
		_getCurrentTabConfig: function () {
			return _oTabConfig[this._getCurrentTabKey()] || {};
		},

		/**
		 * Get key of the current tab
		 * @returns {string} tab key
		 * @function
		 * @private
		 */
		_getCurrentTabKey: function () {
			return this.getView().byId("idIconTabBar").getSelectedKey();
		},

		/**
		 * Initialize opened tab
		 * @function
		 * @private
		 */
		_initTab: function () {
			var sTabKey = this._getCurrentTabKey(),
				oTabConfig = this.getModel("tab").getProperty("/" + sTabKey) || {};

			if (sTabKey === TASKS_TAB) {
				if (!oTabConfig.IsInitialized || oTabConfig.IsInvalid) {
					this._initActionRequiredTab();
					oTabConfig.IsInitialized = true;
				}
			} else {
				var sBindingPath = oTabConfig.BindingPath,
					sTableId = oTabConfig.TableId,
					oTable = sTableId && this.getTableById(sTableId),
					oBindingInfo = oTable && oTable.getBindingInfo("items");

				if (oBindingInfo) {
					if (oBindingInfo.model === "empty") {
						// Bind items
						oTable.bindItems({
							path: sBindingPath,
							model: oTabConfig.ModelName,
							template: oBindingInfo.template
						});
					} else if (oTabConfig.IsInvalid) {
						oBindingInfo.binding.refresh();
					}
				}
			}
			oTabConfig.IsInvalid = false;
		},

		/**
		 * Initialize tab settings model
		 * @function
		 * @private
		 */
		_initTabModel: function () {
			var sUserSetPath = this.getUserSetODataUtil().getUserSetPath();
			this.createJSONModel({
				AllUsers: {
					BindingPath: sUserSetPath,
					CountPath: sUserSetPath + "/$count",
					CountProperty: "Count/TotalUser",
					TableId: ALL_USER_TABLE_ID
				},
				RequestedUsers: {
					BindingPath: "/RequestedUsersSet",
					CountPath: "/RequestedUsersSet/$count",
					CountProperty: "Count/TotalReqUser",
					TableId: REQ_USER_TABLE_ID
				},
				DeletedUsers: {
					BindingPath: "/DeletedUsersSet",
					CountPath: "/DeletedUsersSet/$count",
					CountProperty: "Count/TotalDelUser",
					TableId: DEL_USER_TABLE_ID
				},
				ImportantContacts: {
					BindingPath: "/ImportantRolesSet",
					CountPath: "/ImportantRolesSet/$count",
					CountProperty: "Count/TotalImpContacts",
					TableId: IMP_CONT_TABLE_ID
				},
				AuthPackages: {
					BindingPath: "/auth_pack_for_custSet",
					CountPath: "/auth_pack_for_custSet/$count",
					CountProperty: "APTotal",
					ModelName: "ap",
					TableId: AUTH_PACK_TABLE_ID
				},
				Tasks: {
					CountPath: "/AuthorizationRequestSet/$count",
					CountProperty: "Count/TotalPendingTasks",
					CountFilters: [{
						Property: "Status",
						Operator: FilterOperator.EQ,
						Value1: "O"
					}],
					IsInitialized: false,
					SettingsDialog: "SettingTasks",
					SettingsEnabled: true
				}
			}, MODEL_TAB);
		},

		/**
		 * Invalidate given tabs or all tabs
		 * @param {string[]} aTabKeys tab keys, if empty - invalidate all tabs
		 * @function
		 * @private
		 */
		_invalidateTabs: function (aTabKeys) {
			var oTabData = this.getModel("tab").getData(),
				fnInvalidate = function (oTabConfig) {
					oTabConfig.IsInvalid = true;
				};

			if (aTabKeys && aTabKeys.length) {
				aTabKeys.map(function (sTabKey) {
					return oTabData[sTabKey];
				}).filter(Boolean).forEach(fnInvalidate);
			} else {
				Util.each(oTabData, fnInvalidate);
			}

			this._updateListCounts(aTabKeys);
			this._initTab();
		},

		/**
		 * Check if new Department API is enabled
		 * @returns {boolean} enabled state
		 * @function
		 * @private
		 */
		_isNewDepartmentAPIEnabled: function () {
			return Boolean(this._getSettings().isNewDepartmentAPIEnabled);
		},

		/**
		 * Check if self authorization request is enabled
		 * @returns {boolean} enabled state
		 * @function
		 * @private
		 */
		_isSelfAuthorizationRequestVisible: function () {
			return Boolean(this._getSettings().isSelfAuthorizationRequestVisible);
		},
		
		/**
		 * Check if setting tab is enabled
		 * @returns {boolean} enabled state
		 * @function
		 * @private
		 */
		/*_isSettingsTabEnabled: function () {
			return Boolean(this._getSettings().isSettingsTabEnabled);
		},*/

		/**
		 * Remember current opened tab
		 * @function
		 * @private
		 */
		_rememberCurrentTab: function () {
			this.__fromTab = this._getCurrentTabKey();
		},

		/**
		 * Update item numbers for users' lists
		 * @param {string[]} aTabKeys tab keys, if empty - update all tabs
		 * @function
		 * @private
		 */
		_updateListCounts: function (aTabKeys) {
			var oTabData = this.getModel("tab").getData(),
				fnUpdate = function (oTabConfig) {
					var sPath = oTabConfig.CountPath,
						sCountProperty = oTabConfig.CountProperty,
						sModelName = oTabConfig.ModelName,
						aFilters = [];

					if (oTabConfig.CountFilters && oTabConfig.CountFilters.map) {
						aFilters = oTabConfig.CountFilters.map(function (oFilterConfig) {
							return new Filter(oFilterConfig.Property, oFilterConfig.Operator, oFilterConfig.Value1);
						});
					}

					if (sPath && sCountProperty) {
						Util.promiseRead.call(this, sPath, {
								filters: aFilters
							}, sModelName)
							.then(this._setViewProperty.bind(this, sCountProperty));
					}
				}.bind(this);

			if (aTabKeys && aTabKeys.length) {
				aTabKeys.map(function (sTabKey) {
					return oTabData[sTabKey];
				}).filter(Boolean).forEach(fnUpdate);
			} else {
				Util.each(oTabData, fnUpdate);
			}
		},

		/**
		 * Update length of the current list with applied filters in UI
		 * @param {sap.ui.model.odata.v2.ODataListBinding} oItemsBinding items binding
		 * @param {string} sCountProperty property in the view model which contains items count
		 * @function
		 * @private
		 */
		_updateListCurrentLength: function (oItemsBinding, sCountProperty) {
			// Check if model already processed a $count request
			if (oItemsBinding.isLengthFinal()) {
				this._setViewProperty(sCountProperty, oItemsBinding.getLength());
			} else {
				// Wait until model processes a $count request
				var iInterval = setInterval(function () {
					if (oItemsBinding.isLengthFinal()) {
						this._setViewProperty(sCountProperty, oItemsBinding.getLength());
						clearInterval(iInterval);
					}
				}.bind(this), 50);
			}
		},

		onAfterRendering: function () {
			if (this._install_num) {
				this._showInstallParamFilterData();
			}
			this._updateListCounts();
			this._loadAndApplyColumnsSettings(ALL_USER_TABLE_ID);
			this._loadAndApplyColumnsSettings(REQ_USER_TABLE_ID);
			this._loadAndApplyColumnsSettings(DEL_USER_TABLE_ID);
			this._loadAndApplyColumnsSettings(IMP_CONT_TABLE_ID);
			this._loadAndApplyColumnsSettings(USER_REP_TABLE_ID);
			if (this.getModel(MODEL_TAB).getProperty("/Tasks/SettingsEnabled")) {
				this._oDialogs.getDialog("SettingTasks").loadAndApplyColumnsSettings();
			}
		},

		onBeforeRendering: function () {
			//Check if login user belongs to CCC
			var oView = this.getView();
			var oModel = oView.getModel();
			var oFilterBar = this.getView().byId("filterBar4AR");
			if (oFilterBar) {
				var oFilterBarItems = oFilterBar.getFilterItems();
				var oUserReportTable = this.getView().byId(USER_REP_TABLE_ID);
				var oUserReportTableColumns = oUserReportTable.getColumns();

				oModel.read("/LogonUserInfoSet", {
					success: function (oData, oResponse) {
						oView.__logonUserID = oResponse.data.results[0].Userid;
						oView.__isCCC = oResponse.data.results[0].isCCC;
						oView.getParent().__function = oResponse.data.results[0].Function;
						this._setViewProperty("IsShowNotes",  
							oResponse.data.results[0].Function === "1SUPERADMIN" || 
							oResponse.data.results[0].Function === "1SUPERADMIN_CLOUD");
						var isAdminRole = oResponse.data.results[0].Function === "1SUPERADMIN" || 
							oResponse.data.results[0].Function === "1SUPERADMIN_CLOUD" ||
							oResponse.data.results[0].Function === "USERADMIN" ||
							oResponse.data.results[0].Function === "USERADMIN_CLOUD";	
						this._setViewProperty("IsDomainCheckEnabled", isAdminRole && 
							this.getModel("appSettings").getData().domainCheckActive);
						// as for now appSettings endpoint does not return isEmailCheckEnabled toggle state
						// so this toggle is outdated and cosindered "always on"
						// related code will be cleaned up in ticket UMT-1177
						var isEmailCheckEnabled = true;
						this._setViewProperty("IsEmailCheckEnabled", isAdminRole && isEmailCheckEnabled);  
						if (oView.__isCCC) {
							//Show Customer Name and Number columns for CCC user
							for (var i = 0; i < oUserReportTableColumns.length; i++) {
								if (oUserReportTableColumns[i].getId() === "__xmlview0--cust_num5" || oUserReportTableColumns[i].getId() ===
									"__xmlview0--cust_name5" ||
									oUserReportTableColumns[i].getId() === "__xmlview0--ccc5" || oUserReportTableColumns[i].getId() ===
									"__xmlview0--ccc_name5") {
									oUserReportTableColumns[i].setVisible(true);
								}
							}
						} else {
							//Show Customer Name and Number filter items for CCC user
							for (var i = 0; i < oFilterBarItems.length; i++) {
								if (oFilterBarItems[i].getProperty("name") === "Customers") {
									oFilterBarItems[i].setVisible(false);
								}
							}
						}
					}.bind(this),
					error: function (oError) {
						jQuery.sap.log.error("LogonUserInfoSet loading Error: " + oError.message);
					}
				});
			}
		},

		onExit: function () {
			if (this._oReqUserSortDialog) {
				this._oReqUserSortDialog.destroy();
			}

			if (this._oReqUserDialogSettings) {
				this._oReqUserDialogSettings.destroy();
			}

			if (this._oDelUserSortDialog) {
				this._oDelUserSortDialog.destroy();
			}

			if (this._oDelUserDialogSettings) {
				this._oDelUserDialogSettings.destroy();
			}

			if (this._oImportantContactsDialogFilter) {
				this._oImportantContactsDialogFilter.destroy();
			}

			if (this._oImportantContactsDialogSettings) {
				this._oImportantContactsDialogSettings.destroy();
			}

			if (this._oImportantContactsDialogSorting) {
				this._oImportantContactsDialogSorting.destroy();
			}

			if (this._oRADialogSettings) {
				this._oRADialogSettings.destroy();
			}

			if (this._oReportsAndUpdatesDialog) {
				this._oReportsAndUpdatesDialog.destroy();
			}
		},

		/**
		 * Get Users' IDs from Reports and Updates table
		 * @returns {string[]} list of users' IDs
		 * @function
		 * @private
		 */
		_getReportsUsersIds: function () {
			var oTable = this.getView().byId(USER_REP_TABLE_ID),
				oBinding = oTable.getBinding("items"),
				aContexts = oBinding && oBinding.getContexts() || [],
				aIDs = aContexts.map(function (oContext) {
					return oContext.getProperty("Susid");
				});

			return aIDs.sort().reduce(function (aList, sUserId) {
				if (sUserId !== aList[aList.length - 1]) {
					aList.push(sUserId);
				}
				return aList;
			}, []);
		},

		/**
		 * Get tasks table
		 * @returns {sap.m.Table} table
		 * @function
		 * @public
		 */
		getTasksTable: function () {
			return this.byId(TASKS_TABLE_ID);
		},

		/**
		 * Handle Authorization Package press
		 * Navigate to Auth Package Detail page
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		onAuthorizationPackageListItemPress: function (oEvent) {
			this._rememberCurrentTab();

			this.getRouter().navTo("authPackageDetail", {
				from: "Master",
				object: oEvent.getSource().getBindingContext("ap").getProperty("AuthPackId")
			}, false);
		},
		
		/**
		 * Open popover with legend showing Customer and Partner
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onCustomerPartnerLegendIconPress: function (oEvent) {
			if (!this._oCustomerPartnerLegendPopover) {
				this._oCustomerPartnerLegendPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.CustomerPartnerLegendPopover", this);
				this._oCustomerPartnerLegendPopover.setModel(this.getModel("i18n"), "i18n");
			}
			
			this._oCustomerPartnerLegendPopover.openBy(oEvent.getSource());
		},

		/**
		 * Handle Important Contact press
		 * Navigate to User Detail page
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		onImportantContactListItemPress: function (oEvent) {
			var sUserId = oEvent.getSource().getBindingContext().getProperty("UserId");

			this._rememberCurrentTab();
			this.getRouter().navTo(USER_DETAIL_ROUTE, {
				from: "Master",
				"user_id": sUserId
			}, false);
		},

		/**
		 * Open parent table settings
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		onParentTableSettings: function (oEvent) {
			var sDialogName = oEvent.getSource().getBindingContext("tab").getProperty("SettingsDialog");

			this._oDialogs.getDialog(sDialogName).open();
		},

		/**
		 * Handle Reports and Updates list item press
		 * Navigate to User Detail page
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		onReportsAndUpdatesListItemPress: function (oEvent) {
			var sUserId = oEvent.getSource().getBindingContext().getProperty("Susid");

			this._rememberCurrentTab();
			this.getRouter().navTo(USER_DETAIL_ROUTE, {
				from: "Master",
				"user_id": sUserId
			}, false);
		},

		/**
		 * Handle search box value change in user list
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onUserListSearch: function (oEvent) {
			this._delayedUserListSearch(oEvent.getSource().getValue());
		},

		/**
		 * Handle user list item press
		 * Navigate to User Detail page
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @public
		 */
		onUserListItemPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext(),
				sUserId = oContext.getProperty("Susid");

			this._rememberCurrentTab();
			this.getRouter().navTo(USER_DETAIL_ROUTE, {
				from: "Master",
				"user_id": sUserId
			}, false);
		},

		/**
		 * Open dialog for mass add authorizations
		 * @event
		 * @public
		 */
		openAddAuthorizationsDialog: function () {
			this._oDialogs.getDialogAndReset("MassAddDeleteAuthorizations")
				.setDeleteMode(false)
				.setUsersIds(this._getReportsUsersIds())
				.open();
		},

		/**
		 * Open new version of Assign Department dialog
		 * KNGMHM02-18151
		 * @event
		 * @public
		 */
		openAssignDepartmentNewDialog: function () {
			// var aSelectedItems = this.getView().byId(ALL_USER_TABLE_ID).getSelectedItems(),
			var aSelectedItems = this._getUserTable().getSelectedItems(),
				aSelectedIds = aSelectedItems.map(function (oItem) {
					return oItem.getBindingContext().getProperty("Susid");
				});

			this._oDialogs.getDialog("AssignDepartmentNew").clearData()
				.setUsersIds(aSelectedIds).syncStyleClass().open();
		},

		/**
		 * Open new version of Manage Department dialog
		 * KNGMHM02-18150
		 * @event
		 * @public
		 */
		openManageDepartmentNewDialog: function () {
			this._oDialogs.getDialog("ManageDepartmentNew").clearData()
				.syncStyleClass().open();
		},

		/**
		 * Open dialog to manage selected users' expiry date
		 * If any user has Requested status, just show warning message
		 * KNGMHM02-18909
		 * @event
		 * @public
		 */
		openManageExpiryDateDialog: function () {
			// var aSelectedItems = this.getView().byId(ALL_USER_TABLE_ID).getSelectedItems(),
			var aSelectedItems = this._getUserTable().getSelectedItems(),
				aSelectedContexts = aSelectedItems.map(function (oItem) {
					return oItem.getBindingContext();
				});
			
			// Showing warning message box if some of the users are not allowed to manage expiry date	
			// Likely to uncomment after business decides to return it back
			/*var oFormatter = this.formatter,
				bHasRequestedStatus = aSelectedContexts.some(function (oContext) {
					return oFormatter.isUserExpirationStatusRequested(oContext.getProperty("Status"));
				}),
				bHasAdmins = aSelectedContexts.some(function (oContext) {
					return !oFormatter.isUserRoleAllowedForManageExpiry(oContext.getProperty("UserCriticalRoleID"));
				}),
				bHasNoEmails = aSelectedContexts.some(function (oContext) {
					return !oContext.getProperty("Ipadr");
				});

			if (bHasRequestedStatus) {
				MessageBox.warning(this.getText("MESSAGE_SOME_USERS_HAVE_REQUESTED_STATUS"));
			} else if (bHasAdmins) {
				MessageBox.warning(this.getText("MESSAGE_SOME_USERS_ARE_ADMINS"));
			} else if (bHasNoEmails) {
				MessageBox.warning(this.getText("MESSAGE_SOME_USERS_HAVE_NO_EMAIL"));
			} else {*/
				this._oDialogs.getDialogAndReset("ManageExpiryDate")
					.setSelectedUsersFromContexts(aSelectedContexts)
					.open();
			/*}*/
		},
		
		/**
		 * Open dialog for managing self-service auth settings
		 * @event
		 * @public
		 */
		openManageSelfServiceAuthorizationDialog: function () {
			this._oDialogs.getDialogAndReset("ManageSelfServiceAuthorization")
				.syncStyleClass()
				.open();
		},

		/**
		 * Open dialog for mass removing authorizations
		 * @event
		 * @public
		 */
		openRemoveAuthorizationsDialog: function () {
			this._oDialogs.getDialogAndReset("MassAddDeleteAuthorizations")
				.setDeleteMode(true)
				.setUsersIds(this._getReportsUsersIds())
				.open();
		},
		
		/**
		 * Open popover with services
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		openServicesPopover: function (oEvent) {
			if (!this._oServicesPopover) {
				this._oServicesPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.ServicesFooterPopover", this);
				this._oServicesPopover.setModel(this.getModel("i18n"), "i18n");
				this.getView().addDependent(this._oServicesPopover);
			}
			
			this._oServicesPopover.openBy(oEvent.getSource());
		},

		/**
		 * Open Unassign Department dialog
		 * KNGMHM02-18533 
		 * @event
		 * @public
		 */
		openUnassignDepartmentNewDialog: function () {
			// var aSelectedItems = this.getView().byId(ALL_USER_TABLE_ID).getSelectedItems(),
			var aSelectedItems = this._getUserTable().getSelectedItems(),
				aSelectedIds = aSelectedItems.map(function (oItem) {
					return oItem.getBindingContext().getProperty("Susid");
				});

			Util.showConfirmationPromiseBox(this.getText("MESSAGE_CONFIRM_UNASSIGN_DEPARTMENTS", [aSelectedIds.length]))
				.then(function () {
					var oModel = this.getModel(),
						sBatchGroupId = "umUnassignDepartment",
						oParams = {
							groupId: sBatchGroupId
						};

					this.setBusy(true);
					oModel.setUseBatch(true);
					oModel.setDeferredGroups([sBatchGroupId]);

					aSelectedIds.forEach(function (sUserId) {
						var sPath = Util.formatMessage("/MassDepartmentUpdateSet(UserId=''{0}'',DepartmentId='''')", [sUserId]);

						oModel.update(sPath, {
							UserId: sUserId,
							DepartmentId: ""
						}, oParams);
					});

					var oPromise = Util.promiseSubmitChanges(oParams, oModel);

					oPromise.finally(function () {
						oModel.setUseBatch(false);
					});
					return oPromise;
				}.bind(this))
				.then(function (oData) {
					if (Util.getBatchMessage(oData) !== Util.Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData)) {
						sap.m.MessageToast.show(this.getText("MESSAGE_DEPT_UNASSIGNED"));
						this.refreshUsers();
						this._getUserTable().removeSelections();
						this._setViewProperty("IsAnyUserSelected", false);
						this.close();
					}
				}.bind(this))
				.finally(this.setBusy.bind(this, false));
		},

		showUAHelp: function () {
			/* eslint-disable sap-no-hardcoded-url */
			sap.m.URLHelper.redirect("http://support.sap.com/user-admin-help", true);
			/* eslint-enable sap-no-hardcoded-url */
		},
		
		/**
		 * Update user data after managing expiry date
		 * @function
		 * @public
		 */
		updateAfterManageExpiryDate: function () {
			// var oUserTable = this.byId(ALL_USER_TABLE_ID);
			var oUserTable = this._getUserTable();
			
			this._invalidateTabs(["AllUsers"]);
			if (oUserTable) {
				oUserTable.removeSelections();
				this._setViewProperty("IsAnyUserSelected", false);
			}
		},

		/**
		 * Handle selection in the user list
		 * Unlock footer buttons if any user is selected
		 * Unlonk Manage Expiry Date button if any user available for Manage is selected
		 * @param {sap.ui.base.Event} oEvent event
		 * @function
		 * @public
		 */
		onSelectedChange: function (oEvent) {
			var oFormatter = this.formatter,
				aSelItems = oEvent.getSource().getSelectedItems(),
				bIsAnyUserSelectedForManageExpDate = aSelItems.every(function (oItem) {
					var oObject = oItem.getBindingContext().getObject();
					return oFormatter.isUsersExpiryDateCanBeMassChanged(oObject.Status, oObject.UserCriticalRoleID, oObject.Erdat, oObject.Trdat);
				});
			if(oEvent.getParameters().selectAll) {
				this.onViewAllButtonPress(true);
			}
		    this._setViewProperty("IsTooManyUsersSelectedForMassExtention", aSelItems.length > Settings.maxUsersAllowedForMassUserExtentions );

			this._setViewProperty("IsAnyUserSelected", aSelItems.length > 0  );
			this._setViewProperty("IsAnyUserSelectedForManageExpDate", aSelItems.length > 0 && 
																	   aSelItems.length <= Settings.maxUsersAllowedForMassUserExtentions &&
																	   bIsAnyUserSelectedForManageExpDate);
		},

		// Sort dialog
		handleViewSortingDialog: function () {
			this._oDialogs.getDialog("SortUserList")
				.syncStyleClass()
				.open();
		},

		/**
		 * Download data of the smart table as CSV
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onSmartTableDownload: function (oEvent) {
			var oTable = Util.closest(oEvent.getSource(), SmartTable);
			if (oTable) {
				oTable.saveToFile();
			}
		},

		/**
		 * Download data of the smart table as CSV page by page
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onSmartTableDownloadPageByPage: function (oEvent) {
			var oButton = oEvent.getSource(),
				oTable = Util.closest(oEvent.getSource(), SmartTable);
			
			if (oTable) {
				oButton.setBusy(true);
				
				Util.showToast(this.getText("MESSAGE_DOWNLOADING_DATA"));
				oTable.getExportPageByPage(500)
					.then(function (oExport) {
						oExport.saveFile(oTable.getSaveFileName());
						Util.showToast(this.getText("MESSAGE_DOWNLOADING_DATA_PROGRESS", [100]));
					}.bind(this))
					.catch(function () {
						Util.showToast(this.getText("MESSAGE_DOWNLOADING_DATA_ERROR"));
					}.bind(this))
					.finally(function () {
						oButton.setBusy(false);
					});
			}
		},

		// Filter dialog
		handleViewFilterDialog: function () {
			this._oDialogs.getDialog("FilterUserList")
				.syncStyleClass()
				.open();
		},
		/**
		 * Open filter Deleted Users dialog
		 * @event
		 * @public
		 */
		onOpenFilterDeletedUserListDialog: function () {
			this._oDialogs.getDialog("FilterDeletedUserList")
				.syncStyleClass()
				.open();
		},

		/**
		 * Open filter Requested Users dialog
		 * @event
		 * @public
		 */
		onOpenFilterRequestedUserListDialog: function () {
			this._oDialogs.getDialog("FilterRequestedUserList")
				.syncStyleClass()
				.open();
		},

		// Button events

		onOpenRequestUserDialog: function () {
			if(this._getSettings().isRequestUserPageEnabled) {
				this.getRouter().navTo("requestUser", {}, false);
				return;
			}
			this._oDialogs.getDialogAndReset("RequestUser")
				.syncStyleClass()
				.open();
		},

		/**
		 * Get dialog controller from Dialogs object by name
		 * @param {string} sDialogName dialog name
		 * @returns {sap.support.useradministration.controller.dialog.BaseDialog} dialog controller
		 * @function
		 * @public
		 */
		getDialog: function (sDialogName) {
			return this._oDialogs.getDialog(sDialogName);
		},

		/**
		 * Get dialog controller from Dialogs object by name and reset corresponding data in dialog model
		 * @param {string} sDialogName dialog name
		 * @returns {sap.support.useradministration.controller.dialog.BaseDialog} dialog controller
		 * @function
		 * @public
		 */
		getDialogAndReset: function (sDialogName) {
			return this._oDialogs.getDialogAndReset(sDialogName);
		},

		/**
		 * Handles Manage Department button press
		 * Opens Manage Departments dialog 
		 * @event
		 * @public
		 */
		onManageDepartmentPress: function () {
			var bUsersTabOpened = this._getCurrentTabKey() === ALL_USERS_TAB,
				// bDepartmentListClickable = bUsersTabOpened && this.getView().byId(ALL_USER_TABLE_ID).getSelectedItems().length,
				bDepartmentListClickable = bUsersTabOpened && this._getUserTable().getSelectedItems().length,
				oManageDeptDialog = this.getDialogAndReset("ManageDepartments");
			oManageDeptDialog.setListClickable(bDepartmentListClickable);
			oManageDeptDialog.open();
		},

		handleAssignDept: function (sDepartmentName) {
			var BATCH_GROUP_ID = "idDeptAssignGroup";

			var that = this,
				oView = this.getView(),
				oModel = oView.getModel(),
				bUserTabActive = this._getCurrentTabKey() === ALL_USERS_TAB,
				// aSelectedItems = oView.byId(ALL_USER_TABLE_ID).getSelectedItems(),
				aSelectedItems = this._getUserTable().getSelectedItems(),
				fnAddDepartment = function (sUserId) {
					var sPath = "/DepartmentSet(UserId='" + sUserId + "',DepartmentDesc='" + escape(sDepartmentName) + "')",
						oDepartment = {
							UserId: sUserId,
							DepartmentDesc: sDepartmentName
						};
					oModel.update(sPath, oDepartment, {
						batchGroupId: BATCH_GROUP_ID
					});
				};

			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups([BATCH_GROUP_ID]);

			if (bUserTabActive && aSelectedItems.length) {
				aSelectedItems.forEach(function (oItem) {
					fnAddDepartment(oItem.getBindingContext().getProperty("Susid"));
				});
			} else {
				fnAddDepartment("");
			}

			oModel.submitChanges({
				batchGroupId: BATCH_GROUP_ID,
				success: function () {
					sap.m.MessageToast.show(that._oUABundle.getText("MESSAGE_DEPT_ASSIGNED"));
					oModel.setUseBatch(false);
					this._invalidateTabs();
				}.bind(this),
				error: function (oXhrError) {
					var sErrorText = oXhrError.responseText,
						oError = JSON.parse(sErrorText);
					sap.m.MessageToast.show(oError.error.message.value);
					oModel.setUseBatch(false);
				}
			});
		},

		handleDeleteUser: function () {
			var oBundle = this.getView().getModel("i18n");
			// var oUserTable = this.getView().byId(ALL_USER_TABLE_ID);
			var oUserTable = this._getUserTable();
			var oView = this.getView();
			oView.__deleteUserPopupWasShown = false;
			oView.__deleteUserConfirm = false;

			var aSelItems = oUserTable.getSelectedItems();

			if (aSelItems.some(function (item) {
					return item.getBindingContext().getObject().Susid === oView.__logonUserID;
				})) {
				sap.m.MessageBox.show(oBundle.getProperty("MESSAGE_USER_SELF_DELETE_WARNING"), {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: oBundle.getProperty("TOOLTIP_USER_DELETE"),
					actions: [sap.m.MessageBox.Action.OK]
				});
			} else {
				this._handleDeleteUserContinue(aSelItems);
			}
		},

		handleDeleteSingleUser: function (evt) {
			var oBundle = this.getView().getModel("i18n");
			var oView = this.getView();
			var oCurrentRow = evt.getSource().getParent().getParent();
			oView.__deleteUserPopupWasShown = false;
			oView.__deleteUserConfirm = false;

			if (oCurrentRow.getBindingContext().getObject().Susid === oView.__logonUserID) {
				sap.m.MessageBox.show(oBundle.getProperty("MESSAGE_USER_SELF_DELETE_WARNING"), {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: oBundle.getProperty("TOOLTIP_USER_DELETE"),
					actions: [sap.m.MessageBox.Action.OK]
				});
			} else if (oCurrentRow.getBindingContext().getProperty("UserCriticalRole") ||
						oCurrentRow.getBindingContext().getProperty("UserType") === UserType.PARTNER) { //Check if selected user has critical role assigned. IF it is - DON'T delete it but show it in message box
				sap.m.MessageBox.show(oBundle.getProperty("MASTER_CRITICAL_ROLE_USER"), {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: oBundle.getProperty("TOOLTIP_CRITICAL_ROLE_ASSIGNED"),
					actions: [sap.m.MessageBox.Action.OK]
				});
			} else {
				this._handleDeleteUserContinue([oCurrentRow]);
			}
		},

		handleManageUserExpDate: function (evt) {
			var oContext = evt.getSource().getBindingContext(),
				aContext = [];
			aContext.push(oContext);
			var emailRegexp = this.getView().getModel("appSettings").oData.emailRegexp;
			if (!Util.detail.validateEmail(oContext.getObject().Ipadr, emailRegexp)) {
					MessageBox.warning(this.getText("MESSAGE_USER_MUST_HAVE_VALID_EMAIL"));
			} else {
				this._oDialogs.getDialogAndReset("ManageExpiryDate")
					.setSelectedUsersFromContexts(aContext)
					.open();
			}
		},

		_handleDeleteUserContinue: function (aDelItems) {
			var oBundle = this.getView().getModel("i18n");
			var usersWithCriticalRoles = [];
			var oModel = this.getView().getModel();
			var oView = this.getView();

			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups(["idDeleteUserGroup"]);

			aDelItems.forEach(function (item) {
				if (item.getBindingContext().getObject().Susid === oView.__logonUserID) {
					//Remove own ID from the deletion list
					return;
				}
				if (item.getBindingContext().getProperty("UserCriticalRole") ||
					item.getBindingContext().getProperty("UserType") === UserType.PARTNER) {
					//Check if selected user has critical role assigned. IF it is - DON'T delete it but show it in message box
					usersWithCriticalRoles.push(item);
					return;
				}

				//create an array of batch changes and save  
				var sPath = item.getBindingContextPath();
				oModel.remove(sPath, {
					batchGroupId: "idDeleteUserGroup"
				});
			});

			if (!usersWithCriticalRoles.length) {
				if (!oView.__deleteUserPopupWasShown) { // we show the pop-up box only once
					oView.__deleteUserPopupWasShown = true;
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show(oBundle.getProperty("MESSAGE_USER_DELETE_WARNING"), {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: oBundle.getProperty("TOOLTIP_USER_DELETE"),
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function (oAction) {
							// Check selected action
							if (oAction === sap.m.MessageBox.Action.OK) {
								oView.__deleteUserConfirm = true;
								oView.getController()._processUserDeletion(oModel, oBundle);
							} else {
								oView.__deleteUserConfirm = false;
							}
						}
					});
				} else {
					oView.getController()._processUserDeletion(oModel, oBundle);
				}
			} else {

				var _DialogUsersWithCriticalRole = this._oDialogs.getDialog("UsersWithCriticalRole");
				_DialogUsersWithCriticalRole.setProperty("usersWithCriticalRoles", usersWithCriticalRoles);
				_DialogUsersWithCriticalRole.syncStyleClass().open();
	
			}
		},

		_processUserDeletion: function (oModel, oBundle) {

			//submit changes and refresh the table and display message  
			oModel.submitChanges({
				batchGroupId: "idDeleteUserGroup",
				success: function () {
					//Update table and number of users in tabs
					this._invalidateTabs();

					//Update launchpad KPIs
					sap.ui.getCore().getEventBus().publish("landingpage", "refresh", {
						source: "useradminnew",
						target: "userManagement"
					});
					
					this._getUserTable().removeSelections();
					this._setViewProperty("IsAnyUserSelected", false);

					sap.m.MessageToast.show(oBundle.getProperty("MESSAGE_USER_DELETED"));
					oModel.setUseBatch(false);
				}.bind(this),
				error: function (oError) {
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					sap.m.MessageToast.show(oErrorBodyObj.error.message.value);
					oModel.setUseBatch(false);
				}
			});
		},

		// Settings dialog
		handleSettings: function () {
			this._oDialogs.getDialogAndReset("SettingUserList")
				.syncStyleClass()
				.open();
		},

		/**
		 * Apply columns settings for the table
		 * @param {sap.ui.base.Event} oEvent event from P13N dialog
		 * @param {string} sBatchGroupId batch group id to send data to the backend
		 * @param {string} sTableName ID of the table
		 * @function
		 * @private
		 */
		_applyTableSettings: function (oEvent, sBatchGroupId, sTableName) {
			var oPayload = oEvent.getParameter("payload").columns,
				oBundle = this.getBundle(),
				 //UMT-1182: as name suggests this model is using PUT for updating elements (instead of default MERGE) 
				 //which works much faster for UserTableColumnSet (see comment in Component.js with detailed explanation)
				oModel = this.getModel("useradminsrvModelWithPutUpdate"),
				// Visible status for each column key { columnKey => visible }
				iSelectedNumber = oPayload.selectedItems.length,
				oSelection = Util.combineArray(oPayload.tableItems, Callbacks.getKey("columnKey"), Callbacks.self),
				oTable = this.getTableById(sTableName);

			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups([sBatchGroupId]);

			// Set lost indexes
			oPayload.tableItems.forEach(function (oItem, iIndex) {
				if (oItem.visible && !oItem.index && oItem.index !== 0) {
					oItem.index = iIndex;
				}
			});

			oTable.getColumns().forEach(function (oColumn) {
				var oItem = oSelection[oColumn.getKey()],
					bVisible = Boolean(oItem && oItem.visible);

				if (oItem) {
					oColumn.setVisible(bVisible);
					var sPath = jQuery.sap.formatMessage("/UserTableColumnSet(TableName=''{0}'',ColumnId=''{1}'')", [sTableName, oColumn.getKey()]),
						//UMT-1182: need to get current state of item from default mode, not from update model, because it is not loaded there
						oData = jQuery.extend(true, {}, oColumn.getModel().getProperty(sPath));

					if (oItem.index || oItem.index === 0) {
						oColumn.setOrder(oItem.index);
						oData.ColumnIndex = oItem.index;
					}
					oData.ColumnVisibility = bVisible;
					oModel.update(sPath, oData, {
						batchGroupId: sBatchGroupId
					});
				}
			});

			oTable.invalidate();

			this._submitChanges({
				batchGroupId: sBatchGroupId
			}, "useradminsrvModelWithPutUpdate").then(function () {
				sap.m.MessageToast.show(oBundle.getText("MESSAGE_SETTING_SAVED"));
				oTable.setVisible(Boolean(iSelectedNumber));
			}).fail(function (oError) {
				Util.showErrorMessageToast(oError);
				oEvent.getSource().getBinding("items").refresh();
				oEvent.getSource().getBinding("columnsItems").refresh();
			}).always(function () {
				oModel.setUseBatch(false);
			});

			oEvent.getSource().close();
		},

		_tableSettingsChange: function (oEvent, settingsTableGroup, tableId) {
			if (oEvent.getParameters().payload.columns.selectedItems.length) {
				this._applyTableSettings(oEvent, settingsTableGroup, tableId);
			} else {
				var oBundle = this.getView().getModel("i18n");
				sap.m.MessageBox.error(oBundle.getProperty("MESSAGE_ZERO_COLUMN"));
			}
		},

		handleIconTabBarSelect: function (oEvent) {
			var sKey = oEvent.getParameter("selectedKey");

			switch (sKey) {
			case "ReportsAndUpdates":
				this._loadReportsAndUpdatesFilters();
				break;
			case "TechnicalUsers":
				this.getRouter().navTo("technicalUsers", {}, false);
				break;
			}

			this._initTab();
			this._setViewProperty("TabKey", sKey);
		},

		/**
		 * Get sapUiSizeCompact style class if it exists
		 * @returns {string} style class
		 * @function
		 * @private
		 */
		_getStyleClass: function () {
			var sStyle = "sapUiSizeCompact";
			return this.getView().$().closest("." + sStyle).length ? sStyle : "";
		},

		/**
		 * Show message that user has authorizations at cluster level
		 * @function
		 * @private
		 */
		_showClusterExistingMessage: function () {
			var oBundle = this.getBundle();
			MessageBox.show(oBundle.getText("MASTER_CLUSTER_POPUP_MESSAGE"), {
				actions: [MessageBox.Action.CLOSE],
				contentWidth: "400px",
				details: [
					oBundle.getText("MASTER_CLUSTER_POPUP_DETAILS_FIRST"),
					oBundle.getText("MASTER_CLUSTER_POPUP_DETAILS_SECOND")
				].join("<br/><br/>"),
				icon: MessageBox.Icon.INFORMATION,
				styleClass: this._getStyleClass(),
				title: oBundle.getText("DETAIL_USER_IMPORTANT_INFO")
			});
		},

		afterTableUpdate: function (oEvent) {
			// var oUserTable = this.getView().byId(ALL_USER_TABLE_ID);
			var oUserTable = this._getUserTable();
			var mParams = oEvent.getParameters();
			this._toggleTableFooter(oUserTable, mParams.total === mParams.actual && mParams.actual);
			this._updateListCurrentLength(oUserTable.getBinding("items"), "Count/User");

			//Show CLUSTER existing message
			if (this.getView().__showClusterFlag && !this.getView().__showClusterFlagBeenShown) {
				this._showClusterExistingMessage();
				this.getView().__showClusterFlag = "";
				this.getView().__showClusterFlagBeenShown = "X";
			}

			//Get default language
			if (oUserTable.getItems()[0]) {
				var sDefaultLanguage = oUserTable.getItems()[0].getBindingContext().getProperty("Land1");
				this.getView().getModel("app").setProperty("/DefaultLang", sDefaultLanguage);
			}
			
			if (this._isUserTableFiltered) {
				this._isUserTableFiltered = false;
				oUserTable.removeSelections();
				this._setViewProperty("IsAnyUserSelected", false);
				this._setViewProperty("IsAnyUserSelectedForManageExpDate", false);
			}
		},

		//!---- Requested Users Tab ----------------
		_filterRequestedUsers: function() {
			var oFilter = {},
				aFilter = [];
			this._aRUFilter.forEach(function(filter) {
				var sPath = filter.sPath;
				if (oFilter[sPath]) {
					oFilter[sPath].push(filter);
				} else {
					oFilter[sPath] = [filter];
				}
			});
			if (this._sRUSearch) {
				oFilter.SearchField = [new Filter("SearchField", FilterOperator.EQ, "'" + this._sRUSearch + "'")];
			}
			
			for (var key in oFilter) {
				var filter = oFilter[key];
				if (!filter.length) {
					continue;
				}
				if (filter.length > 1) {
					filter = new sap.ui.model.Filter({
						filters: filter,
						and: false
					});
				} else {
					filter = filter[0];
				}
				aFilter.push(filter);
			}
			this.getView().byId(REQ_USER_TABLE_ID).getBinding("items")
				.filter([new sap.ui.model.Filter({
						filters: aFilter,
						and: true
					})]);
			
		},
		
		onReqUsersSearch: function (oEvent) {
			var sSearchQuery = oEvent.getSource().getValue();
			setTimeout(function (sQuery) {
				if (sQuery === this.getView().byId("searchFieldRequestedUsers").getValue()) {
					this._sRUSearch = (sQuery && sQuery.length > 0) ?  sQuery : "";
					this._filterRequestedUsers();
				} else {
					jQuery.sap.log.info("The search trip was skipped.");
				}
			}.bind(this, sSearchQuery), 500);
		},

		handleResendPasswordButtonPress: function (oEvent) {
			var BATCH_GROUP_ID = "idActivateUserGroup";

			var that = this,
				oView = this.getView(),
				oModel = oView.getModel(),
				oItem = oEvent.getSource().getParent().getParent(),
				fnActivateUser = function (sUserId) {
					var sPath = "/UserActivationSet",
						oUser = {
							UserId: sUserId
						};
					oModel.create(sPath, oUser, {
						batchGroupId: BATCH_GROUP_ID
					});
				};

			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups([BATCH_GROUP_ID]);

			if (oItem.getBindingContext().getProperty("Susid")) {
				fnActivateUser(oItem.getBindingContext().getProperty("Susid"));
			}

			oModel.submitChanges({
				batchGroupId: BATCH_GROUP_ID,
				success: function () {
					sap.m.MessageToast.show(that._oUABundle.getText("MESSAGE_ACTIVATE_USER"));
					oModel.setUseBatch(false);
					this._invalidateTabs();
				},
				error: function (oXhrError) {
					var sErrorText = oXhrError.responseText,
						oError = JSON.parse(sErrorText);
					sap.m.MessageToast.show(oError.error.message.value);
					oModel.setUseBatch(false);
				}
			});
		},

		// Sort dialog
		handleViewSortingDialog2: function () {
			this._oDialogs.getDialog("SortRequestedUserList")
				.syncStyleClass()
				.open();
		},

		// Settings dialog
		handleSettings2: function () {
			this._oDialogs.getDialogAndReset("SettingRequestedUserList")
				.syncStyleClass()
				.open();
		},

		_masterTableUpdate: function (event, tableId, countPath) {
			var 
				table = this.getTableById(tableId),
				params = event.getParameters();

			this._toggleTableFooter(table, params.total === params.actual && params.actual);

			this._updateListCurrentLength(table.getBinding("items"), countPath);
		},

		afterTableUpdate2: function (oEvent) {
			this._masterTableUpdate(oEvent, REQ_USER_TABLE_ID, "Count/ReqUser", "Count/TotalReqUser");
		},

		onRequestedUserPress: function (oEvent) {
			var oSource = oEvent.getSource();

			var sUserId = oSource.getBindingContext().getProperty("Susid");

			this._rememberCurrentTab();

			this.getRouter().navTo(USER_DETAIL_ROUTE, {
				from: "Master",
				"user_id": sUserId
			}, false);
		},

		//!---- Deleted Users Tab ----------------
		_filterDeletedUsers: function() {
			var oFilter = {},
				aFilter = [];
			this._aDUFilter.forEach(function(filter) {
				var sPath = filter.sPath;
				if (oFilter[sPath]) {
					oFilter[sPath].push(filter);
				} else {
					oFilter[sPath] = [filter];
				}
			});
			if (this._sDUSearch) {
				oFilter.SearchField = [new Filter("SearchField", FilterOperator.EQ, "'" + this._sDUSearch + "'")];
			}
			
			for (var key in oFilter) {
				var filter = oFilter[key];
				if (!filter.length) {
					continue;
				}
				if (filter.length > 1) {
					filter = new sap.ui.model.Filter({
						filters: filter,
						and: false
					});
				} else {
					filter = filter[0];
				}
				aFilter.push(filter);
			}
			this.getView().byId(DEL_USER_TABLE_ID).getBinding("items")
				.filter([new sap.ui.model.Filter({
						filters: aFilter,
						and: true
					})]);
			
		},
		
		onDelUsersSearch: function (oEvent) {
			var sSearchQuery = oEvent.getSource().getValue();
			setTimeout(function (sQuery) {
				if (sQuery === this.getView().byId("searchField3").getValue()) {
					this._sDUSearch = (sQuery && sQuery.length > 0) ?  sQuery : "";
					this._filterDeletedUsers();
				} else {
					jQuery.sap.log.info("The search trip was skipped.");
				}
			}.bind(this, sSearchQuery), 500);
		},

		// Sort dialog
		handleViewSortingDialog3: function () {
			this._oDialogs.getDialog("SortDeletedUserList")
				.syncStyleClass()
				.open();
		},

		// Settings dialog
		handleSettings3: function () {
			this._oDialogs.getDialogAndReset("SettingDeletedUserList")
				.syncStyleClass()
				.open();
		},

		afterTableUpdate3: function (oEvent) {
			this._masterTableUpdate(oEvent, DEL_USER_TABLE_ID, "Count/DelUser", "Count/TotalDelUser");
		},

		onImportantUsersSearch: function (oEvent) {
			var sSearchQuery = oEvent.getSource().getValue();
			setTimeout(function (sQuery) {
				if (sQuery === this.getView().byId("searchField4").getValue()) {
					this._oICSearch = (sQuery && sQuery.length > 0) ?  sQuery : "";

					this._filterImportantContacts();
				} else {
					jQuery.sap.log.info("The search trip was skipped.");
				}
			}.bind(this, sSearchQuery), 500);
		},
		
		_filterImportantContacts: function() {
			var oFilter = {},
				aFilter = [];
			this._aICFilter.forEach(function(filter) {
				var sPath = filter.sPath;
				if (oFilter[sPath]) {
					oFilter[sPath].push(filter);
				} else {
					oFilter[sPath] = [filter];
				}
			});
			if (this._oICSearch) {
				oFilter.SearchField = [new Filter("SearchField", FilterOperator.EQ, "'" + this._oICSearch + "'")];
			}
			
			for (var key in oFilter) {
				var filter = oFilter[key];
				if (!filter.length) {
					continue;
				}
				if (filter.length > 1) {
					filter = new Filter({
						filters: filter,
						and: false
					});
				} else {
					filter = filter[0];
				}
				aFilter.push(filter);
			}
			this.getView().byId(IMP_CONT_TABLE_ID).getBinding("items")
				.filter([new Filter({
						filters: aFilter,
						and: true
					})]);
			
		},

		// Sort dialog
		handleViewSortingDialog4: function () {
			this._oDialogs.getDialog("SortImportantContactsList")
				.syncStyleClass()
				.open();
		},

		// Filter dialog
		handleViewFilterDialog4: function () {
			this._oDialogs.getDialog("FilterImportantContactsList")
				.syncStyleClass()
				.open();
		},

		// Settings dialog
		handleSettings4: function () {
			this._oDialogs.getDialogAndReset("SettingImportantContactsList")
				.syncStyleClass()
				.open();
		},

		afterTableUpdate4: function (oEvent) {
			this._masterTableUpdate(oEvent, IMP_CONT_TABLE_ID, "Count/ImpContacts", "Count/TotalImpContacts");
		},

		handleMaintOwnClusters: function () {
			/* eslint-disable sap-no-hardcoded-url */
			sap.m.URLHelper.redirect("https://support.sap.com/content/launchpad/en_us/legacy/clusters.html", true);
			//sap.m.URLHelper.redirect("http://service.sap.com/sap/bc/bsp/spn/xsmpuser/cluster.do", true);
			/* eslint-enable sap-no-hardcoded-url */
		},

		handleMassUpdatesAuth: function () {
			/* eslint-disable sap-no-hardcoded-url */
			sap.m.URLHelper.redirect("https://support.sap.com/content/launchpad/en_us/legacy/massupdates.html", true);
			//sap.m.URLHelper.redirect("http://service.sap.com/~form/handler?_APP=00200682500000002332&_EVENT=DISPLAY&ACTION=MASSUPDATE", true);
			/* eslint-enable sap-no-hardcoded-url */
		},

		handleRunAuthReports: function () {
			/* eslint-disable sap-no-hardcoded-url */
			sap.m.URLHelper.redirect("https://support.sap.com/content/launchpad/en_us/legacy/authreports.html", true);
			//sap.m.URLHelper.redirect("http://service.sap.com/sap/bc/bsp/spn/xsmpuser/report.do?report_id=authselect", true);
			/* eslint-enable sap-no-hardcoded-url */
		},

		_showInstallParamFilterData: function () {
			var aFilters = [];

			var filter = new sap.ui.model.Filter("Installation", sap.ui.model.FilterOperator.EQ, this._install_num);
			aFilters.push(filter);

			// update table binding
			this.getView().byId(USER_REP_TABLE_ID).getBinding("items").filter(aFilters, "Application");
		},

		onSearchParamChange: function () {
			var oTable = this.getView().byId(USER_REP_TABLE_ID);

			if (!this._oUserAuthReportTemplate) {
				this._oUserAuthReportTemplate = oTable.getItems()[0].clone();
			}

			this.getModel().setUseBatch(true);

			oTable.bindItems("/UserAuthReportSet", this._oUserAuthReportTemplate);
			
			// add filter for search
			var oUsersTokens = this.getView().byId("idMIUserIdFilter").getTokens();
			var oCustomersTokens = this.getView().byId("idMICustNumFilter").getTokens();
			var oUserAuthTokens = this.getView().byId("idMIUserFilter").getTokens();
			var oInstallTokens = this.getView().byId("idMIInstNumFilter").getTokens();
			var oAPSelected = this.getView().byId("idAPFilter").getSelectedKeys();
			var oAuthObjSelected = this.getView().byId("idAuthorizationsFilter").getSelectedKeys();
			var oPrecisionSelected = this.getView().byId("idPrecision").getSelectedKey();

			var aFilters = [];

			var bDepartmentNewAPIEnabled = this._isNewDepartmentAPIEnabled(),
				oDepartmentControl = bDepartmentNewAPIEnabled ? this.getView().byId("idDepartmentNewFilter") : this.getView().byId(
					"idDepartmentFilter"),
				aDepartmentKeys = oDepartmentControl && oDepartmentControl.getSelectedKeys() || [];

			if (bDepartmentNewAPIEnabled) {
				aDepartmentKeys.forEach(function (sDepartmentId) {
					if (sDepartmentId !== "All") {
						aFilters.push(new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, (sDepartmentId === "None") ? "" :
							sDepartmentId));
					}
				});
			} else {
				aDepartmentKeys.forEach(function (element) {
					aFilters.push(new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, (element === "None") ? "" : element));
				});
			}

			oUsersTokens.forEach(function (element) {
				aFilters.push(new sap.ui.model.Filter("Susid", sap.ui.model.FilterOperator.EQ, element.getKey()));
			});

			oCustomersTokens.forEach(function (element) {
				aFilters.push(new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.EQ, element.getKey()));
			});

			oInstallTokens.forEach(function (element) {
				aFilters.push(new sap.ui.model.Filter("Installation", sap.ui.model.FilterOperator.EQ, element.getKey()));
			});

			oUserAuthTokens.forEach(function (element) {
				aFilters.push(new sap.ui.model.Filter("UserAuth", sap.ui.model.FilterOperator.EQ, element.getKey()));
			});

			oAuthObjSelected.forEach(function (element) {
				aFilters.push(new sap.ui.model.Filter("AuthObject", sap.ui.model.FilterOperator.EQ, element));
			});

			oAPSelected.forEach(function (element) {
				aFilters.push(new sap.ui.model.Filter("AuthPackage", sap.ui.model.FilterOperator.EQ, element));
			});

			aFilters.push(new sap.ui.model.Filter("Tmpzl", sap.ui.model.FilterOperator.EQ, oPrecisionSelected));

			this.getView()._aARFilters = aFilters;

			// update table binding
			this.getView().byId(USER_REP_TABLE_ID).getBinding("items").filter(aFilters, "Application");

			setTimeout(function(){
				this.getModel().setUseBatch(false);
			}.bind(this), 1);

			this.__searchPerformed = true;
		},

		/**
		 * Refresh all data connected with departments
		 * @param {object[]} aDepartmentList list of departments
		 * @function
		 * @public
		 */
		refreshDepartmentsData: function (aDepartmentList) {
			/*var oFilterUserDialog = this._oDialogs.getDialog("FilterUserList");
			oFilterUserDialog.refreshDepartmentNewFilters(aDepartmentList);*/
			this.refreshUsers();
		},

		/**
		 * Refresh Reports and Updates table
		 * @function
		 * @public
		 */
		refreshReportsAndUpdates: function () {
			var oBinding = this.getView().byId(USER_REP_TABLE_ID).getBinding("items");
			if (oBinding) {
				oBinding.refresh();
			}
		},

		/**
		 * Refresh Users table
		 * @function
		 * @public
		 */
		refreshUsers: function () {
			this._invalidateTabs(["AllUsers"]);
		},

		// Sort dialog
		handleRATableSorting: function () {
			this._oDialogs.getDialog("SortReportsAndUpdatesList")
				.syncStyleClass()
				.open();
		},

		_onClear: function (oEvent) {
			var f = this._applyData.bind(oEvent.getSource());
			f(null);
			this._onFilterChange();
		},

		_filterBarInitialized: function (oEvent) {
			var sID = oEvent.getSource().getCurrentVariantId();
			if (!sID || sID.length === 0) {
				oEvent.getSource().setFilterBarExpanded(true);
			}
		},

		_afterVariantSaved: function () {
			sap.ui.getCore().getEventBus().publish("landingpage", "refresh", {
				source: "useradminnew",
				target: "useradminnew"
			});
		},

		_onFilterChange: function (oEvent) {
			if (this.oFilterBar) {
				this.oFilterBar.fireFilterChange(oEvent);
				this.bEmptySearch = false;
			}
		},

		processAllSelectedItem: function (oEvent) {
			var oControl = oEvent.getSource();

			var aSelectedItems = oControl.getSelectedItems(),
				aItems = oControl.getItems(),
				oChangedItem = oEvent.getParameter("changedItem"),
				oAllItem, bAllSelect,
				oNoneItem, bNoneSelect;

			var i;
			for (i = 0; i < aItems.length; i++) {
				if (aItems[i].getKey() === "All") {
					oAllItem = aItems[i];
					bAllSelect = aSelectedItems.indexOf(oAllItem) !== -1;
					break;
				}
			}
			for (i = 0; i < aItems.length; i++) {
				if (aItems[i].getKey() === "None") {
					oNoneItem = aItems[i];
					bNoneSelect = aSelectedItems.indexOf(oNoneItem) !== -1;
					break;
				}
			}

			if (oChangedItem === oNoneItem) {
				oControl.removeAllSelectedItems();
				if (bNoneSelect) {
					oControl.addSelectedItem(oNoneItem);
				}
			} else if (oChangedItem === oAllItem) {
				if (bAllSelect) {
					oControl.setSelectedItems(aItems);
					oControl.removeSelectedItem(oNoneItem);
				} else {
					oControl.removeAllSelectedItems();
				}
			} else {
				if (aSelectedItems.length === aItems.length - 2 && !bAllSelect && !bNoneSelect) {
					oControl.addSelectedItem(oAllItem);
				} else {
					oControl.removeSelectedItem(oNoneItem);
					oControl.removeSelectedItem(oAllItem);
				}
			}
		},

		processAPFilterSelectedItem: function (oEvent) {
			var oControl = oEvent.getSource();
			var oPrecisionFilter = this.getView().byId("idPrecision");
			if (oControl.getSelectedItems().length) {
				oPrecisionFilter.setSelectedKey("");
				oPrecisionFilter.setEnabled(false);
			} else {
				oPrecisionFilter.setEnabled(true);
			}
		},

		_applyData: function (oJsonData) {
			var oItems = this.getAllFilterItems(true);
			var oView = this.getParent().getParent().getParent().getParent().getParent().getParent();

			for (var i = 0; i < oItems.length; i++) {
				var oControl = this.determineControlByFilterItem(oItems[i]);
				if (oControl) {
					if (oControl instanceof sap.m.MultiInput) {
						oControl.setTokens([]);
					} else if (oControl instanceof sap.m.MultiComboBox) {
						oControl.setSelectedKeys([]);
					} else if (oControl instanceof sap.m.Select) {
						oControl.setSelectedKey("");
					} else if (oControl.setValue) {
						oControl.setValue("");
					}
				}
			}

			var sGroupName;
			if (oJsonData === null || oJsonData === undefined) {
				return;
			}

			var bPrecisionEnabled = true;

			//Check if the installation number is passed in the URL. If yes, we need to retrieve data for that installation, not for the default filter
			if (!oView.getController()._install_num) {
				for (var i = 0; i < oJsonData.length; i++) {
					sGroupName = null;

					if (oJsonData[i].group_name) {
						sGroupName = oJsonData[i].group_name;
					}

					oControl = this.determineControlByName(oJsonData[i].name, sGroupName);
					if (!(oControl && oControl.getVisible())) {
						continue;
					}
					switch (oJsonData[i].name) {
					case "Users":
					case "UsersAuth":
					case "Customers":
					case "Installations":
						var oArray = oJsonData[i].value;
						var aToken = [];
						for (var j = 0; j < oArray.length; j++) {
							if (oArray[j].constructor === Array) {
								aToken.push(new sap.m.Token({
									key: oArray[j][0],
									text: oArray[j][1]
								}));
							} else {
								aToken.push(new sap.m.Token({
									key: oArray[j],
									text: oArray[j]
								}));
							}
						}
						oControl.setTokens(aToken);
						break;
					case "Department":
					case "DepartmentNew":
					case "Authorizations":
						if (oJsonData[i].value) {
							oControl.setSelectedKeys(oJsonData[i].value);
						}
						break;
					case "AP":
						if (oJsonData[i].value) {
							oControl.setSelectedKeys(oJsonData[i].value);
							var oPrecisionFilter = this.getView().byId("idPrecision");
							if (oJsonData[i].value.length) {
								bPrecisionEnabled = false;
								oPrecisionFilter.setSelectedKey("");
							}
							oPrecisionFilter.setEnabled(bPrecisionEnabled);
						}
						break;
					case "Precision":
						if (oJsonData[i].value && bPrecisionEnabled) {
							oControl.setSelectedKey(oJsonData[i].value);
						}
						break;
					default:
						oControl.setValue(oJsonData[i].value);
						break;
					}
				}
			} else {
				aToken = [];
				aToken.push(new sap.m.Token({
					key: oView.getController()._install_num,
					text: oView.getController()._install_num
				}));
				oView.byId("idMIInstNumFilter").setTokens(aToken);
				oView.getController()._install_num = "";
			}
		},

		_fetchData: function () {
			var sGroupName;
			var oJsonParam;
			var oJsonData = [];

			var oItems = this.getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				oJsonParam = {};
				sGroupName = null;
				if (oItems[i].getGroupName) {
					sGroupName = oItems[i].getGroupName();
					oJsonParam.group_name = sGroupName;
				}

				oJsonParam.name = oItems[i].getName();
				var oControl = this.determineControlByFilterItem(oItems[i]);
				if (!(oControl && oControl.getVisible())) {
					continue;
				}
				switch (oJsonParam.name) {
				case "Users":
				case "UsersAuth":
				case "Customers":
				case "Installations":
					var aTokens = oControl.getTokens();
					var oArray = new Array();
					for (var j = 0; j < aTokens.length; j++) {
						oArray.push([aTokens[j].getKey(), aTokens[j].getText()]);
					}
					oJsonParam.value = oArray;
					oJsonData.push(oJsonParam);
					break;
				case "Department":
				case "DepartmentNew":
				case "Authorizations":
				case "AP":
					oJsonParam.value = oControl.getSelectedKeys();
					oJsonData.push(oJsonParam);
					break;
				case "Precision":
					oJsonParam.value = oControl.getSelectedKey();
					oJsonData.push(oJsonParam);
					break;
				default:
					oJsonParam.value = oControl.getValue();
					oJsonData.push(oJsonParam);
					break;
				}

			}

			return oJsonData;
		},

		onRATableSelectedChange: function (evt) {
			var oUserTable = evt.getSource();
			var oAllItems = oUserTable.getItems();
			var oSelItem = evt.getParameter("listItem");

			for (var i = 0; i < oAllItems.length; i++) {
				if (oAllItems[i].getBindingContext().getProperty("Susid") === oSelItem.getBindingContext().getProperty("Susid")) {
					oAllItems[i].setSelected(oSelItem.isSelected());
				}
			}
		},

		// Settings dialog
		handleRATableSettings: function () {
			this._oDialogs.getDialog("SettingReportsAndUpdatesList")
				.syncStyleClass()
				.open();
		},

		/**
		 * Grow table if needed
		 * @param {sap.m.Table} oTable table
		 * @function
		 * @private
		 */
		_growTable: function (oTable) {
			var oDelegate = oTable._oGrowingDelegate;

			if (oDelegate && !oDelegate._bLoading) {
				setTimeout(function () {
					var oTrigger = oTable.getDomRef("triggerList");
					if (oTrigger && oTrigger.style.display !== "none") {
						oDelegate.requestNewPage();
					}
				}, 0);
			}
		},

		/**
		 * Toggle table footer
		 * @param {sap.m.Table} oTable table
		 * @param {boolean} bVisibility if footer should be visible
		 * @function
		 * @private
		 */
		_toggleTableFooter: function (oTable, bVisibility) {
			if (bVisibility) {
				oTable.removeStyleClass("umEndOfListFooterHidden", true);
			} else {
				oTable.addStyleClass("umEndOfListFooterHidden", true);
				var oTab = Util.closest(oTable, sap.m.IconTabFilter);
				if (oTab && oTab.getKey() === this._getCurrentTabKey()) {
					this._growTable(oTable);
				}
			}
		},

		onAPTableUpdateStarted: function (oEvent) {
			var oBinding = oEvent.getSource().getBinding("items"),
				aFilters = oBinding.aFilters;
			if (aFilters && aFilters.length) {
				this._loadTotalItemsCount(this.getModel("ap"), oBinding.getPath(), "APTotal");
			}
		},

		/**
		 * Toggle End of list statement visibility
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onAPTableUpdateFinished: function (oEvent) {
			var mParams = oEvent.getParameters();
			this._updateListCurrentLength(oEvent.getSource().getBinding("items"), "APActual");
			this._toggleTableFooter(oEvent.getSource(), mParams.total === mParams.actual && mParams.actual);
		},

		/**
		 * Toggle End of list statement visibility
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onReqAuthTableUpdateFinished: function (oEvent) {
			var mParams = oEvent.getParameters(),
				aFilters = oEvent.getSource().getBinding("items").aFilters;

			if (!(aFilters && aFilters.length)) {
				this._setViewProperty("ReqAuth/Total", mParams.total);
			}
			this._updateListCurrentLength(oEvent.getSource().getBinding("items"), "ReqAuth/Actual");
			this._toggleTableFooter(oEvent.getSource(), mParams.total === mParams.actual && mParams.actual);
		},

		/**
		 * Load number of all items in set
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel odata model
		 * @param {string} sPath path in the odata model
		 * @param {string} sPropertyName name of property in the view model to write a result
		 * @function
		 * @private
		 */
		_loadTotalItemsCount: function (oModel, sPath, sPropertyName) {
			oModel.read(sPath + "/$count", {
				success: function (iCount) {
					this._setViewProperty(sPropertyName, iCount);
				}.bind(this)
			});
		},

		afterTableUpdate5: function (oEvent) {
			var oBundle = this.getView().getModel("i18n");

			var oMasterView = this.getView();
			var oUserTable = oMasterView.byId(USER_REP_TABLE_ID);
			var oUsersTokens = this.getView().byId("idMIUserIdFilter").getTokens();
			var oCustomersTokens = this.getView().byId("idMICustNumFilter").getTokens();
			var oInstallTokens = this.getView().byId("idMIInstNumFilter").getTokens();
			var oUserAuthTokens = this.getView().byId("idMIUserFilter").getTokens();
			var oAPSelected = this.getView().byId("idAPFilter").getSelectedKeys();
			var oAuthObjSelected = this.getView().byId("idAuthorizationsFilter").getSelectedKeys();
			// var showEditAuthButtonFlag;

			var bDepartmentSelected = false;
			if (this._isNewDepartmentAPIEnabled()) {
				bDepartmentSelected = this.getView().byId("idDepartmentNewFilter").getSelectedKeys().length;
			} else {
				bDepartmentSelected = this.getView().byId("idDepartmentFilter").getSelectedKeys().length;
			}

			var mParams = oEvent.getParameters();
			this._toggleTableFooter(oUserTable, mParams.total === mParams.actual && mParams.actual);

			if (!oUserTable.getItems().length && this.__searchPerformed && (oUsersTokens || oCustomersTokens || oInstallTokens ||
					bDepartmentSelected ||
					oAuthObjSelected || oUserAuthTokens || oAPSelected)) {
				oUserTable.setNoDataText(oBundle.getProperty("MASTER_LIST_NODATA_TEXT3"));
			} else {
				oUserTable.setNoDataText(oBundle.getProperty("MASTER_LIST_NODATA_TEXT2"));
			}

			//Enable "Mass updates of authorizations" button and make user table selectable
			// if ((oInstallTokens.length === 1 && !oCustomersTokens.length) || (!oInstallTokens.length && oCustomersTokens.length === 1) || (
			// 		oUserAuthTokens.length === 1 && !oCustomersTokens.length) || (!oUserAuthTokens.length && oCustomersTokens.length === 1)) {
			// 	showEditAuthButtonFlag = true;
			// } else {
			// 	showEditAuthButtonFlag = false;
			// }

			//show number records
			var oRecordsCount = oUserTable.getBinding("items").getLength();
			this._setViewProperty("ReportsNumber", oRecordsCount);
		},

		/**
		 * Load columns settings from the backend then apply them
		 * @param {string} sTableName table ID
		 * @function
		 * @private
		 */
		_loadAndApplyColumnsSettings: function (sTableName) {
			var bIsReportTable = sTableName === USER_REP_TABLE_ID,
				oView = this.getView(),
				oTable = this.getTableById(sTableName);

			this.getModel().setUseBatch(false);
			this._read("/UserTableColumnSet", {
				filters: [new Filter("TableName", FilterOperator.EQ, sTableName)]
			}).then(function (oData) {
				var aResults = oData.results || [],
					oSelection = Util.combineArray(aResults, Callbacks.getKey("ColumnId"), Callbacks.self); // map {ColumnId => item}

				oTable.getColumns().forEach(function (oColumn) {
					var oItem = oSelection[oColumn.getKey()];
					// For Reports and Updates, hide CCC columns for non-CCC users
					if (bIsReportTable && !oView.__isCCC && ["cust_num5", "cust_name5", "ccc5", "ccc_name5"].indexOf(oColumn.getKey()) !== -1) {
						oColumn.setVisible(false);
					} else {
						oColumn.setVisible(Boolean(oItem && oItem.ColumnVisibility));
					}

					if (oColumn.getVisible()) {
						oColumn.setOrder(oItem.ColumnIndex);
					}
				});

				oTable.invalidate();
			}).fail(function (oError) {
				jQuery.sap.log.error("UserTableColumnSet loading Error: " + oError.message);
			});
		},

		/**
		 * Download Departments NEW for reports and updates filter bar
		 * @returns {Promise} promise
		 * @function
		 * @private
		 */
		_loadReportsAndUpdatesDepartmentNewFilter: function () {
			return Util.promiseRead.call(this, "/DepartmentNewSet")
				.then(function (oData) {
					var aDepartments = oData.results.map(Util.deepCopy).sort(function (oFirst, oSecond) {
						return sap.ui.model.Sorter.defaultComparator(oFirst.DepartmentName, oSecond.DepartmentName);
					});

					aDepartments = [{
						DepartmentId: "All",
						DepartmentName: this.getText("MISC_ALL")
					}, {
						DepartmentId: "None",
						DepartmentName: this.getText("MASTER_NONE")
					}].concat(aDepartments);
					this._setViewProperty("ReportsDepartmentsNew", aDepartments);
				}.bind(this));
		},

		/**
		 * Download filters for Reports and Updates tab
		 * @function
		 * @private
		 */
		_loadReportsAndUpdatesFilters: function () {
			Util.read.call(this, "/UserF4HelpSet", {
				filters: [new Filter("Department", FilterOperator.EQ, "X")]
			}).then(function (oData) {
				this._setViewProperty("ReportsDepartments", oData.results.filter(function (oDepartment) {
					return oDepartment.Department;
				}).map(Util.deepCopy));
			}.bind(this));

			this._loadReportsAndUpdatesDepartmentNewFilter();

			Util.read.call(this, "/AuthObjectF4HelpSet").then(function (oData) {
				this._setViewProperty("ReportsAuthorizations", oData.results.map(Util.deepCopy));
			}.bind(this));

			Util.read.call(this, "/auth_pack_for_custSet", {}, "ap").then(function (oData) {
				this._setViewProperty("ReportsAuthorizationPackages", oData.results.map(Util.deepCopy));
			}.bind(this));
		},

		_onUserSuggestionSelect: function (oEvent) {
			this.getView().byId("idMIUserIdFilter").setTokens(oEvent.getSource().getTokens());
		},

		_onUsersSuggest: function () {
			var that = this;
			var oModel18n = this.getView().getModel("i18n");
			var aTableItems = [];

			jQuery.sap.require("sap.ui.comp.valuehelpdialog.ValueHelpDialog");
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: that._oUABundle.getText("AUTH_OBJ_USER_LEVEL") + "{i18n>AUTH_OBJ_MULTIPLE}",
				modal: true,
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "Susid",
				descriptionKey: "FullName",

				ok: function (oControlEvent) {
					that.aUserFilterTokens = oControlEvent.getParameter("tokens");
					that.getView().byId("idMIUserIdFilter").setTokens(that.aUserFilterTokens);
					oValueHelpDialog.close();
				},

				cancel: function () {
					oValueHelpDialog.close();
				},

				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oValueHelpDialog);
			oValueHelpDialog.setModel(oModel18n, "i18n");

			var oColModel = this.createJSONModel();
			oColModel.setData({
				cols: [{
					label: that._oUABundle.getText("MASTER_COLUMN_USER_ID"),
					template: "Susid"
				}, {
					label: that._oUABundle.getText("MASTER_USER_FIRST_NAME"),
					template: "Namev"
				}, {
					label: that._oUABundle.getText("MASTER_USER_LAST_NAME"),
					template: "Name1"
				}, {
					label: that._oUABundle.getText("MASTER_COLUMN_USER_CUST_NUM"),
					template: "CustNum"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			//Get data
			var oView = this.getView();
			var oRowsModel = this.createJSONModel();
			var sUrl = oView.getModel().sServiceUrl + "/UserF4HelpSet";

			oRowsModel.loadData(sUrl, false);

			oRowsModel.attachRequestCompleted(function (oData) {
				aTableItems = oData.getSource().getData().d.results;
				oRowsModel.setData(aTableItems);
				oValueHelpDialog.setTokens(that.getView().byId("idMIUserIdFilter").getTokens());
				oValueHelpDialog.update();
			});

			oValueHelpDialog.getTable().setModel(oRowsModel);
			oValueHelpDialog.getTable().bindRows("/");

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				//			  showRestoreButton: false,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: [new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn1",
						name: "n1",
						label: that._oUABundle.getText("MASTER_COLUMN_USER_ID"),
						control: new sap.m.Input({
							id: "idMIFilterSusid"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn1",
						name: "n2",
						label: that._oUABundle.getText("MASTER_USER_FIRST_NAME"),
						control: new sap.m.Input({
							id: "idMIFilterNamev"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn1",
						name: "n3",
						label: that._oUABundle.getText("MASTER_USER_LAST_NAME"),
						control: new sap.m.Input({
							id: "idMIFilterName1"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn1",
						name: "n4",
						label: that._oUABundle.getText("MASTER_COLUMN_USER_CUST_NUM"),
						control: new sap.m.Input({
							id: "idMIFilterKunnr"
						})
					})
				],
				search: function () {
					that._onUserFilterSearch(oValueHelpDialog);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "idARUserSearchBox",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function () {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();
			oValueHelpDialog.update();
		},

		_onUserFilterSearch: function (oDialog) {
			//Get table of authorization objects
			var oTable = oDialog.getTable();
			var aFilters = [];
			var sSplitSymbol;

			//If value(s) in "Advance Mode selected
			var sUserIdQuery = sap.ui.getCore().byId("idMIFilterSusid").getValue();
			var sUserFirstNameQuery = sap.ui.getCore().byId("idMIFilterNamev").getValue();
			var sUserLastNameQuery = sap.ui.getCore().byId("idMIFilterName1").getValue();
			var sUserCustNumQuery = sap.ui.getCore().byId("idMIFilterKunnr").getValue();
			if (sUserIdQuery || sUserFirstNameQuery || sUserLastNameQuery) {
				sap.ui.getCore().byId("idARUserSearchBox").setValue("");
				if (sUserIdQuery && (sUserIdQuery.indexOf(";") !== -1 || sUserIdQuery.indexOf(",") !== -1)) {
					sSplitSymbol = (sUserIdQuery.indexOf(";") !== -1) ? ";" : ",";
					var oUserIdFilter = new sap.ui.model.Filter({
						filters: sUserIdQuery.split(" ").join("").split(sSplitSymbol).filter(function (sUserId) {
							return sUserId !== "";
						}).map(function (sUserId) {
							return new sap.ui.model.Filter("Susid", sap.ui.model.FilterOperator.Contains, sUserId);
						}),
						and: false
					});
					aFilters.push(oUserIdFilter);
				} else {
					aFilters.push(new sap.ui.model.Filter("Susid", sap.ui.model.FilterOperator.Contains, sUserIdQuery));
				}
				aFilters.push(new sap.ui.model.Filter("Namev", sap.ui.model.FilterOperator.Contains, sUserFirstNameQuery));
				aFilters.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sUserLastNameQuery));
				aFilters.push(new sap.ui.model.Filter("CustNum", sap.ui.model.FilterOperator.Contains, sUserCustNumQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			} else { //Basic search executed here, in case, if no values specified in the advanced search 
				var sQuery = sap.ui.getCore().byId("idARUserSearchBox").getValue();
				if (sQuery.indexOf(";") !== -1 || sQuery.indexOf(",") !== -1) {
					sSplitSymbol = (sQuery.indexOf(";") !== -1) ? ";" : ",";
					aFilters = sQuery.split(" ").join("").split(sSplitSymbol).filter(function (sUser) {
						return sUser !== "";
					}).map(function (sUser) {
						return new sap.ui.model.Filter("Susid", sap.ui.model.FilterOperator.Contains, sUser);
					});
				} else {
					aFilters.push(new sap.ui.model.Filter("Susid", sap.ui.model.FilterOperator.Contains, sQuery));
					aFilters.push(new sap.ui.model.Filter("Namev", sap.ui.model.FilterOperator.Contains, sQuery));
					aFilters.push(new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sQuery));
					aFilters.push(new sap.ui.model.Filter("CustNum", sap.ui.model.FilterOperator.Contains, sQuery));
				}
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: false
				}));
			}
		},

		_onCustomersSuggest: function () {
			var that = this;
			var oModel18n = this.getView().getModel("i18n");
			var aTableItems = [];

			jQuery.sap.require("sap.ui.comp.valuehelpdialog.ValueHelpDialog");
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: that._oUABundle.getText("AUTH_OBJ_CUSTOMER_LEVEL") + "{i18n>AUTH_OBJ_MULTIPLE}",
				modal: true,
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "CustNum",
				descriptionKey: "CustName",

				ok: function (oControlEvent) {
					that.aCustomerFilterTokens = oControlEvent.getParameter("tokens");
					that.getView().byId("idMICustNumFilter").setTokens(that.aCustomerFilterTokens);
					oValueHelpDialog.close();
				},

				cancel: function () {
					oValueHelpDialog.close();
				},

				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oValueHelpDialog);
			oValueHelpDialog.setModel(oModel18n, "i18n");

			var oColModel = this.createJSONModel();
			oColModel.setData({
				cols: [{
					label: that._oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
					template: "CustNum"
				}, {
					label: that._oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
					template: "CustName"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			//Get data
			var oView = this.getView();
			var oRowsModel = this.createJSONModel();
			var sUrl = oView.getModel().sServiceUrl + "/CustomersF4HelpSet";

			oRowsModel.loadData(sUrl, false);

			oRowsModel.attachRequestCompleted(function (oData) {
				aTableItems = oData.getSource().getData().d.results;
				oRowsModel.setData(aTableItems);
				oValueHelpDialog.setTokens(that.getView().byId("idMICustNumFilter").getTokens());
				oValueHelpDialog.update();
			});

			oValueHelpDialog.getTable().setModel(oRowsModel);
			oValueHelpDialog.getTable().bindRows("/");

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				//				  showRestoreButton: false,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: [new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn2",
						name: "n1",
						label: that._oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
						control: new sap.m.Input({
							id: "idMIFilterCustNum"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn2",
						name: "n2",
						label: that._oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
						control: new sap.m.Input({
							id: "idMIFilterCustName"
						})
					})
				],
				search: function () {
					that._onCustomerFilterSearch(oValueHelpDialog);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "idARCustomerSearchBox",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function () {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();
			oValueHelpDialog.update();
		},

		_onCustomerFilterSearch: function (oDialog) {
			//Get table of authorization objects
			var oTable = oDialog.getTable();
			var aFilters = [];

			//If value(s) in "Advance Mode selected
			var sCustNumQuery = sap.ui.getCore().byId("idMIFilterCustNum").getValue();
			var sCustNameQuery = sap.ui.getCore().byId("idMIFilterCustName").getValue();
			if (sCustNumQuery || sCustNameQuery) {
				sap.ui.getCore().byId("idARCustomerSearchBox").setValue("");
				aFilters.push(new sap.ui.model.Filter("CustNum", sap.ui.model.FilterOperator.Contains, sCustNumQuery));
				aFilters.push(new sap.ui.model.Filter("CustName", sap.ui.model.FilterOperator.Contains, sCustNameQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			} else { //Basic search executed here, in case, if no values specified in the advanced search 
				var sQuery = sap.ui.getCore().byId("idARCustomerSearchBox").getValue();
				aFilters.push(new sap.ui.model.Filter("CustNum", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("CustName", sap.ui.model.FilterOperator.Contains, sQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: false
				}));
			}
		},

		_onInstallSuggest: function () {
			var that = this;
			var oModel18n = this.getView().getModel("i18n");
			var aTableItems = [];

			jQuery.sap.require("sap.ui.comp.valuehelpdialog.ValueHelpDialog");
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: that._oUABundle.getText("AUTH_OBJ_INST_LEVEL") + "{i18n>AUTH_OBJ_MULTIPLE}",
				modal: true,
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "InstallationNum",
				descriptionKey: "InstallationDesc",

				ok: function (oControlEvent) {
					that.aInstallFilterTokens = oControlEvent.getParameter("tokens");
					that.getView().byId("idMIInstNumFilter").setTokens(that.aInstallFilterTokens);
					oValueHelpDialog.close();
				},

				cancel: function () {
					oValueHelpDialog.close();
				},

				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oValueHelpDialog);
			oValueHelpDialog.setModel(oModel18n, "i18n");

			var oColModel = this.createJSONModel();
			oColModel.setData({
				cols: [{
					label: that._oUABundle.getText("MASTER_COLUMN_INST_NUM"),
					template: "InstallationNum"
				}, {
					label: that._oUABundle.getText("MASTER_COLUMN_INST_NAME"),
					template: "InstallationDesc"
				}, {
					label: that._oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
					template: "CustNum"
				}, {
					label: that._oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
					template: "CustName"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			//Get data
			var oView = this.getView();
			var oRowsModel = this.createJSONModel();
			var sUrl = oView.getModel().sServiceUrl + "/InstallationsF4HelpSet";

			oRowsModel.loadData(sUrl, false);

			oRowsModel.attachRequestCompleted(function (oData) {
				aTableItems = oData.getSource().getData().d.results;
				oRowsModel.setData(aTableItems);
				oValueHelpDialog.setTokens(that.getView().byId("idMIInstNumFilter").getTokens());
				oValueHelpDialog.update();
			});

			oValueHelpDialog.getTable().setModel(oRowsModel);
			oValueHelpDialog.getTable().bindRows("/");

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				//					  showRestoreButton: false,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: [new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn3",
						name: "n1",
						label: that._oUABundle.getText("MASTER_COLUMN_INST_NUM"),
						control: new sap.m.Input({
							id: "idMIFilterInstallationNum"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn3",
						name: "n2",
						label: that._oUABundle.getText("MASTER_COLUMN_INST_NAME"),
						control: new sap.m.Input({
							id: "idMIFilterInstallationDesc"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn3",
						name: "n3",
						label: that._oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
						control: new sap.m.Input({
							id: "idMIFilterCustNum"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn3",
						name: "n4",
						label: that._oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
						control: new sap.m.Input({
							id: "idMIFilterCustName"
						})
					})
				],
				search: function () {
					that._onInstallFilterSearch(oValueHelpDialog);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "idARInstallSearchBox",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function () {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();
			oValueHelpDialog.update();
		},

		_onInstallFilterSearch: function (oDialog) {
			//Get table of authorization objects
			var oTable = oDialog.getTable();
			var aFilters = [];

			//If value(s) in "Advance Mode selected
			var sInstNumQuery = sap.ui.getCore().byId("idMIFilterInstallationNum").getValue();
			var sInstNameQuery = sap.ui.getCore().byId("idMIFilterInstallationDesc").getValue();
			var sCustNumQuery = sap.ui.getCore().byId("idMIFilterCustNum").getValue();
			var sCustNameQuery = sap.ui.getCore().byId("idMIFilterCustName").getValue();
			if (sInstNumQuery || sInstNameQuery || sCustNumQuery || sCustNameQuery) {
				sap.ui.getCore().byId("idARInstallSearchBox").setValue("");
				aFilters.push(new sap.ui.model.Filter("InstallationNum", sap.ui.model.FilterOperator.Contains, sInstNumQuery));
				aFilters.push(new sap.ui.model.Filter("InstallationDesc", sap.ui.model.FilterOperator.Contains, sInstNameQuery));
				aFilters.push(new sap.ui.model.Filter("CustNum", sap.ui.model.FilterOperator.Contains, sCustNumQuery));
				aFilters.push(new sap.ui.model.Filter("CustName", sap.ui.model.FilterOperator.Contains, sCustNameQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			} else { //Basic search executed here, in case, if no values specified in the advanced search 
				var sQuery = sap.ui.getCore().byId("idARInstallSearchBox").getValue();
				aFilters.push(new sap.ui.model.Filter("InstallationNum", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("InstallationDesc", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("CustNum", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("CustName", sap.ui.model.FilterOperator.Contains, sQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: false
				}));
			}
		},

		_onUserSuggest: function () {
			var that = this;
			var oModel18n = this.getView().getModel("i18n");
			var aTableItems = [];

			jQuery.sap.require("sap.ui.comp.valuehelpdialog.ValueHelpDialog");
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: "{i18n>AUTH_OBJ_USER_LEVEL}" + "{i18n>AUTH_OBJ_MULTIPLE}",
				modal: true,
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "UserId",
				descriptionKey: "UserName",

				ok: function (oControlEvent) {
					that.aUserFilterTokens = oControlEvent.getParameter("tokens");
					that.getView().byId("idMIUserFilter").setTokens(that.aUserFilterTokens);
					oValueHelpDialog.close();
				},

				cancel: function () {
					oValueHelpDialog.close();
				},

				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oValueHelpDialog);
			oValueHelpDialog.setModel(oModel18n, "i18n");

			var oColModel = this.createJSONModel();
			oColModel.setData({
				cols: [{
					label: that._oUABundle.getText("MASTER_COLUMN_USER_ID"),
					template: "UserId"
				}, {
					label: that._oUABundle.getText("AUTHORIZATION_LEVEL_USER_NAME"),
					template: "UserName"
				}, {
					label: that._oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
					template: "CustNum"
				}, {
					label: that._oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
					template: "CustName"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			//Get data
			var oView = this.getView();
			var oRowsModel = this.createJSONModel();
			var sUrl = oView.getModel().sServiceUrl + "/User4FilterSet";

			oRowsModel.loadData(sUrl, false);

			oRowsModel.attachRequestCompleted(function (oData) {
				aTableItems = oData.getSource().getData().d.results;
				oRowsModel.setData(aTableItems);
				oValueHelpDialog.setTokens(that.getView().byId("idMIUserFilter").getTokens());
				oValueHelpDialog.update();
			});

			oValueHelpDialog.getTable().setModel(oRowsModel);
			oValueHelpDialog.getTable().bindRows("/");

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				//					  showRestoreButton: false,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: [new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn3",
						name: "n1",
						label: that._oUABundle.getText("MASTER_COLUMN_USER_ID"),
						control: new sap.m.Input({
							id: "idMIFilterUserID"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn3",
						name: "n2",
						label: that._oUABundle.getText("AUTHORIZATION_LEVEL_USER_NAME"),
						control: new sap.m.Input({
							id: "idMIFilterUserName"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn3",
						name: "n3",
						label: that._oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
						control: new sap.m.Input({
							id: "idMIFilterCustNum"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn3",
						name: "n4",
						label: that._oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
						control: new sap.m.Input({
							id: "idMIFilterCustName"
						})
					})
				],
				search: function () {
					that._onUserAuthFilterSearch(oValueHelpDialog);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "idARUserSearchBox",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function () {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();
			oValueHelpDialog.update();
		},

		_onUserAuthFilterSearch: function (oDialog) {
			//Get table of authorization objects
			var oTable = oDialog.getTable();
			var aFilters = [];

			//If value(s) in "Advance Mode selected
			var sInstNumQuery = sap.ui.getCore().byId("idMIFilterUserID").getValue();
			var sInstNameQuery = sap.ui.getCore().byId("idMIFilterUserName").getValue();
			var sCustNumQuery = sap.ui.getCore().byId("idMIFilterCustNum").getValue();
			var sCustNameQuery = sap.ui.getCore().byId("idMIFilterCustName").getValue();
			if (sInstNumQuery || sInstNameQuery || sCustNumQuery || sCustNameQuery) {
				sap.ui.getCore().byId("idARUserSearchBox").setValue("");
				aFilters.push(new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.Contains, sInstNumQuery));
				aFilters.push(new sap.ui.model.Filter("UserName", sap.ui.model.FilterOperator.Contains, sInstNameQuery));
				aFilters.push(new sap.ui.model.Filter("CustNum", sap.ui.model.FilterOperator.Contains, sCustNumQuery));
				aFilters.push(new sap.ui.model.Filter("CustName", sap.ui.model.FilterOperator.Contains, sCustNameQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			} else { //Basic search executed here, in case, if no values specified in the advanced search 
				var sQuery = sap.ui.getCore().byId("idARUserSearchBox").getValue();
				aFilters.push(new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("UserName", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("CustNum", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("CustName", sap.ui.model.FilterOperator.Contains, sQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: false
				}));
			}
		},

		handleAuthUpdates: function (oEvent) {
			if (!this._actionSheet) {
				this._actionSheet = new sap.ui.xmlfragment("sap.support.useradministration.view.fragment.ActionSheet", this);
				this.getView().addDependent(this._actionSheet);
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._actionSheet);
			}
			this._actionSheet.openBy(oEvent.getSource());
		},

		handleViewSortingDialog6: function () {
			/*
			if (!this._oAPSortingDialog) {
				this._oAPSortingDialog = sap.ui.xmlfragment("sap.support.useradministration.view.DialogSort4AuthPackages", this);
				var oModel = this.getView().getModel("i18n");
				this._oAPSortingDialog.setModel(oModel, "i18n");
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oAPSortingDialog);
			this._oAPSortingDialog.open();
			*/
			this._oDialogs.getDialog("SortAuthorizationPackages")
				.syncStyleClass()
				.open();
		},

		onAuthPackagesSearch: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sSearchQuery = oEvent.getSource().getValue();
			setTimeout(function (sQuery) {
				if (sQuery === this.getView().byId("searchFieldAuthPackages").getValue()) {
					if (sQuery && sQuery.length > 0) {
						var filter = new sap.ui.model.Filter("Text", sap.ui.model.FilterOperator.Contains, sQuery);
						aFilters.push(filter);
					}

					// update table binding
					this.getView().byId(AUTH_PACK_TABLE_ID).getBinding("items").filter(aFilters);
				} else {
					jQuery.sap.log.info("The search trip was skipped.");
				}
			}.bind(this, sSearchQuery), 500);
		},
		
		onAPSelectedChange: function (evt) {
			var aSelItems = evt.getSource().getSelectedItems();
			var oModel = this.getModel("ap");
			var sUserFunction = this.oView.getParent().__function;

			var bEnabledBtn = aSelItems.length !== 0;
			var bEnabledDeleteBtn = aSelItems.length !== 0;
			var bEnabledRenameBtn = aSelItems.length === 1;
			var bEnabledOverviewBtn = aSelItems.length === 1;
			var bEnabledCopyBtn = aSelItems.length === 1;
			var bEnabledReportBtn = aSelItems.length === 1;

			if (bEnabledBtn && sUserFunction !== "1SUPERADMIN") {
				for (var i = 0; i < aSelItems.length; i++) {
					var sPath = aSelItems[i].getBindingContextPath();
					if (oModel.getProperty(sPath).Protected) {
						bEnabledDeleteBtn = false;
						bEnabledRenameBtn = false;
						break;
					}
				}
			}

			this._setViewProperty("APButtons/Protect", bEnabledBtn);
			this._setViewProperty("APButtons/Unprotect", bEnabledBtn);
			this._setViewProperty("APButtons/Report", bEnabledReportBtn);
			this._setViewProperty("APButtons/Overview", bEnabledOverviewBtn);
			this._setViewProperty("APButtons/Delete", bEnabledDeleteBtn);
			this._setViewProperty("APButtons/Rename", bEnabledRenameBtn);
			this._setViewProperty("APButtons/Copy", bEnabledCopyBtn);
			this._setViewProperty("APButtons/AssignUsers", bEnabledBtn);
		},

		removeAPSelections: function() {
			this.getTableById(AUTH_PACK_TABLE_ID).removeSelections();
			
			this._setViewProperty("APButtons/Protect", false);
			this._setViewProperty("APButtons/Unprotect", false);
			this._setViewProperty("APButtons/Report", false);
			this._setViewProperty("APButtons/Overview", false);
			this._setViewProperty("APButtons/Delete", false);
			this._setViewProperty("APButtons/Rename", false);
			this._setViewProperty("APButtons/Copy", false);
			this._setViewProperty("APButtons/AssignUsers", false);
		},
		
		handleAPCreate: function () {
			if(this.getView().getModel("appSettings").getData().useNewCreateAp === "X") {
				this.getRouter().navTo("createAuthPack", {}, false);
				return;
			}
			
			this._oDialogs.getDialog("APCreate")
				.clearData()
				.syncStyleClass()
				.open();
		},

		handleAPDelete: function () {
			var oBundle = this.getView().getModel("i18n");
			var that = this;

			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.show(oBundle.getProperty("MESSAGE_AP_DELETE_WARNING"), {
				icon: sap.m.MessageBox.Icon.WARNING,
				title: oBundle.getProperty("MISC_CONFIRM"),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
				onClose: function (oAction) {
					// Check selected action
					if (oAction === sap.m.MessageBox.Action.OK) {
						that.getView().getController().__APDelete();
					}
				}
			});
		},

		__APDelete: function () {
			var oView = this.getView();
			var oModel = oView.getModel("ap");
			var oBundle = this.getView().getModel("i18n");
			var sPath;
			var oAPList = oView.byId(AUTH_PACK_TABLE_ID);
			var oSelItems = oAPList.getSelectedItems();

			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups(["idDeleteAPGroup"]);

			for (var i = 0; i < oSelItems.length; i++) {
				//create an array of batch changes and save  
				sPath = oSelItems[i].getBindingContextPath();
				oModel.remove(sPath, {
					batchGroupId: "idDeleteAPGroup"
				});
			}

			oModel.submitChanges({
				batchGroupId: "idDeleteAPGroup",
				success: function () {
					oModel.setUseBatch(false);
					this._invalidateTabs(["AuthPackages"]);
					this.removeAPSelections();
					sap.m.MessageToast.show(oBundle.getProperty("MESSAGE_AP_DELETED"));
				}.bind(this),
				error: function (oError) {
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					sap.m.MessageToast.show(oErrorBodyObj.error.message.value);
					oModel.setUseBatch(false);
				}
			});

		},

		handleAPRename: function () {
			var oSelectedAP = this.getTableById(AUTH_PACK_TABLE_ID).getSelectedItem();
			this._oDialogs.getDialog("APRename")
				.setSelectedAP(oSelectedAP)
				.syncStyleClass()
				.open();
		},
		
		handleTableAPRename: function(evt) {
			var oContext = evt.getSource().getParent().getParent();
			this._oDialogs.getDialog("APRename")
				.setSelectedAP(oContext)
				.syncStyleClass()
				.open();
		},
		
		handleAPCopy: function () {
			if (this._getSettings().isAPCopyDialogEnabled) {
				var oSelectedAP = this.getTableById(AUTH_PACK_TABLE_ID).getSelectedItem();
				this._oDialogs.getDialog("APCopy")
					.clearData()
					.setSelectedAP(oSelectedAP)
					.syncStyleClass()
					.open();
			}
		},

		handleTableAPCopy: function (evt) {
			if (this._getSettings().isAPCopyDialogEnabled) {
				var oSelectedAP = evt.getSource().getParent().getParent();
				this._oDialogs.getDialog("APCopy")
					.clearData()
					.setSelectedAP(oSelectedAP)
					.syncStyleClass()
					.open();
			}
		},
		handleAPProtect: function () {
			var oView = this.getView();
			var oAPModel = oView.getModel("ap");
			var that = this;
			var oAPList = oView.byId(AUTH_PACK_TABLE_ID);
			var oSelAPItems = oAPList.getSelectedItems();

			oAPModel.setUseBatch(true);
			oAPModel.setDeferredBatchGroups(["idAPProtectGroup"]);

			var sData4batch = [];
			var sPath;

			for (var i = 0; i < oSelAPItems.length; i++) {
				//create an array of batch changes and save 
				sData4batch[i] = jQuery.extend(true, {}, oSelAPItems[i].getBindingContext("ap").getObject());
				Util.deleteODataExtensions(sData4batch[i]);
				sData4batch[i].Protected = true;

				sPath = oSelAPItems[i].getBindingContext("ap").getPath();
				oAPModel.update(sPath, sData4batch[i], {
					batchGroupId: "idAPProtectGroup"
				});
			}

			oAPModel.submitChanges({
				batchGroupId: "idAPProtectGroup",
				success: function (oData) {
					if (Util.getBatchMessage(oData) !== Util.Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData)){
						sap.m.MessageToast.show(that._oUABundle.getText("MESSAGE_AP_PROTECTED"));
						oAPModel.setUseBatch(false);
						this._invalidateTabs(["AuthPackages"]);
					} else {
						sap.m.MessageToast.show(Util.getBatchError(oData));
						oAPModel.setUseBatch(false);
					}
				}.bind(this),
				error: function (oError) {
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					sap.m.MessageToast.show(oErrorBodyObj.error.message.value);
					oAPModel.setUseBatch(false);
				}
			});
		},

		handleAPUnprotect: function () {
			var oView = this.getView();
			var oAPModel = oView.getModel("ap");
			var that = this;
			var oAPList = oView.byId(AUTH_PACK_TABLE_ID);
			var oSelAPItems = oAPList.getSelectedItems();

			oAPModel.setUseBatch(true);
			oAPModel.setDeferredBatchGroups(["idAPUnprotectGroup"]);

			var sData4batch = [];
			var sPath;

			for (var i = 0; i < oSelAPItems.length; i++) {
				//create an array of batch changes and save 
				sData4batch[i] = jQuery.extend(true, {}, oSelAPItems[i].getBindingContext("ap").getObject());
				Util.deleteODataExtensions(sData4batch[i]);
				sData4batch[i].Protected = false;

				sPath = oSelAPItems[i].getBindingContext("ap").getPath();
				oAPModel.update(sPath, sData4batch[i], {
					batchGroupId: "idAPUnprotectGroup"
				});
			}

			oAPModel.submitChanges({
				batchGroupId: "idAPUnprotectGroup",
				success: function (oData) {
					if (Util.getBatchMessage(oData) !== Util.Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData)){
						sap.m.MessageToast.show(that._oUABundle.getText("MESSAGE_AP_UNPROTECTED"));
						oAPModel.setUseBatch(false);
						this._invalidateTabs(["AuthPackages"]);
					} else {
						sap.m.MessageToast.show(Util.getBatchError(oData));
						oAPModel.setUseBatch(false);
					}
				}.bind(this),
				error: function (oError) {
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					sap.m.MessageToast.show(oErrorBodyObj.error.message.value);
					oAPModel.setUseBatch(false);
				}
			});
		},

		handleAPOverview: function () {
			var aSelectedAP = this.getTableById(AUTH_PACK_TABLE_ID).getSelectedItem();
			this._showAuthOwverviewDialog(aSelectedAP);
		},

		handleTableAPOverview: function(evt) {
			var oSelectedAP = evt.getSource().getParent().getParent();
			this._showAuthOwverviewDialog(oSelectedAP);
		
		},
		
		_showAuthOwverviewDialog: function (oSelectedAP) {
			var	oModel = this.getView().getModel("ap"),
				authPack = oModel.getData(oSelectedAP.getBindingContextPath());
			Util.promiseRead.call(this, "/Auth_pack_detailSet", {
				filters: [new sap.ui.model.Filter("AuthPackId", sap.ui.model.FilterOperator.EQ,authPack.AuthPackId)]
			}, "ap")
			.then(function(oData) {
				this._oDialogs.getDialog("APAuthOverview")
					.setSelectedAP(oSelectedAP)
					.setAuthCount(oData.results.length)
					.syncStyleClass()
					.open();
				}
			.bind(this));
		},
		
		handleAssignAP: function () {
			this._oDialogs.getDialog("APSelect")
				.syncStyleClass()
				.open();
				
		},
		
		handleAPReport: function () {
			var aSelectedAP = this.getTableById(AUTH_PACK_TABLE_ID).getSelectedItems();
			this.showAPReportHelper(aSelectedAP[0]);
		},

		handleTableAPReport: function(evt) {
			var oSelectedAP = evt.getSource().getParent().getParent();
			this.showAPReportHelper(oSelectedAP);
		},
		
		showAPReportHelper: function(ap) {
			var	oModel = this.getView().getModel("ap"),
				authPack = oModel.getData(ap.getBindingContextPath());
			Util.promiseRead.call(this, "/Users_for_auth_packSet", {
				filters: [new sap.ui.model.Filter("AuthPackId", sap.ui.model.FilterOperator.EQ,authPack.AuthPackId)]
			}, "ap")
			.then(function (oPackData) {
				if(oPackData.results.length === 0) {
					var messageBoxText = this.getText("AP_OVERVIEW_NO_USER_TEXT", [authPack.Text]),
						messageBoxTitle = this.getText("AP_OVERVIEW_NO_USER_TITLE"),
						formattedText = new sap.m.FormattedText("FormattedText", {
							htmlText: messageBoxText
						});
					sap.m.MessageBox.show(formattedText, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: messageBoxTitle,
						actions: [sap.m.MessageBox.Action.OK]
					});
				}else{
					this._oDialogs.getDialog("APReport")
						.setSelectedAP([ap])
						.setUsersCount(oPackData.results.length)
						.syncStyleClass()
						.open();  
				}
			}.bind(this)).catch(function () {
				log.error("Retrieving authPackage data failed");
			});			
		},
		
		/**
		 * Open Assign Users to AP dialog
		 * @event
		 * @public
		 */
		handleAssignUsersToAP: function () {
			var oDialog = this._oDialogs.getDialogAndReset("AssignUsersToAPs"),
				oList = this.getView().byId(AUTH_PACK_TABLE_ID);
			var aAuthPackIds = oList.getSelectedContexts().map(function (oContext) {
				return oContext.getProperty("AuthPackId");
			});

			oDialog.setAuthPackIds(aAuthPackIds);
			oDialog.syncStyleClass();
			oDialog.open();
		},

		sendEmail: function (oEvent) {
			var address = oEvent.getSource().getBindingContext().getProperty("Ipadr"),
				userID = oEvent.getSource().getBindingContext().getProperty("Susid"),
				password = oEvent.getSource().getBindingContext().getProperty("Password");
			if (address !== "" && userID !== "" && password !== "") {
				sap.m.URLHelper.triggerEmail(address, "", "");

				// sap.m.URLHelper.triggerEmail(address, "[CONFIDENTIAL] Your logon credentials for SAP Support websites", "UserID: " + userID +
				// 	"\nPassword: " + password);
			} else {
				sap.m.URLHelper.triggerEmail(address);
			}
		},
		/**
		 * Event handler for table items refreshing. Could use in pair with event
		 * handler for selec all as a method with boolean parameter
		 * @public
		 * @event
		 * @param {boolean|sap.ui.core.event} bSelectAll - Parameter for select all options. Can be as event object
		 */
		onViewAllButtonPress: function (bSelectAll) {
			var sTableId = this._getCurrentTabConfig().Table || "",
				oTable = sTableId && this.getTableById(sTableId);

			if (oTable) {
				oTable.setBusyIndicatorDelay(0);
				oTable.setBusy(true);
				oTable.setGrowing(false);
				oTable.attachEventOnce("updateFinished", function () {
					oTable.setBusy(false);
					if(bSelectAll && typeof bSelectAll === "boolean"){
						this.getTableById(sTableId).selectAll();	
					}
				}.bind(this));

				oTable.getBinding("items").refresh();
			}
		},

		handleUserReactivateButtonPress: function (oEvent) {
			var BATCH_GROUP_ID = "idReactivateUserGroup";

			var that = this,
				oView = this.getView(),
				oModel = oView.getModel(),
				oItem = oEvent.getSource().getParent().getParent(),
				fnReactivateUser = function (sUserId) {
					var sPath = "/UserReactivationSet",
						oUser = {
							UserId: sUserId
						};
					oModel.create(sPath, oUser, {
						batchGroupId: BATCH_GROUP_ID
					});
				};

			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups([BATCH_GROUP_ID]);

			if (oItem.getBindingContext().getProperty("Susid")) {
				fnReactivateUser(oItem.getBindingContext().getProperty("Susid"));
			}

			oModel.submitChanges({
				batchGroupId: BATCH_GROUP_ID,
				success: function () {
					sap.m.MessageToast.show(that._oUABundle.getText("MESSAGE_REACTIVATE_USER"));
					oModel.setUseBatch(false);
					this._invalidateTabs();
				}.bind(this),
				error: function (oXhrError) {
					var sErrorText = oXhrError.responseText,
						oError = JSON.parse(sErrorText);
					sap.m.MessageToast.show(oError.error.message.value);
					oModel.setUseBatch(false);
				}
			});
		},

		onTaskPress: function (oEvent) {
			this._rememberCurrentTab();
			this.getRouter().navTo("requestDetail", {
				requestId: this._getViewProperty(oEvent.getSource().getBindingContextPath().slice(8)).RequestId
			}, false);
		},

		/**
		 * Open filter dialog for Tasks
		 * @event
		 * @public
		 */
		handleViewFilterDialog8: function () {
			this._oDialogs.getDialog("FilterTasksList")
				.syncStyleClass()
				.open();
		},

		/**
		 * Open sort dialog for Tasks
		 * @event
		 * @public
		 */
		handleViewSortingDialog8: function () {
			this._oDialogs.getDialog("SortTasksList")
				.syncStyleClass()
				.open();
		},

		_loadTasksCount: function (oModel, sPath, sPropertyName, filter) {
			oModel.read(sPath, {
				filters: [filter],
				success: function (iCount) {
					this._setViewProperty(sPropertyName, iCount);
				}.bind(this)
			});
		},

		afterTableUpdate8: function (oEvent) {
			if (!this._isSelfAuthorizationRequestVisible()) {
				return;
			}

			var oTable = this.getTableById(TASKS_TABLE_ID),
				mParams = oEvent.getParameters();

			this._toggleTableFooter(oTable, mParams.total === mParams.actual && mParams.actual);
			this._setViewProperty("Count/Tasks", oTable.getBinding("items").getLength());
			this._updateListCurrentLength(oTable.getBinding("items"), "Count/PendingTasks");
			
		},

		_initActionRequiredTab: function () {
			if (!this._isSelfAuthorizationRequestVisible()) {
				return;
			}
			var oView = this.getView();
			this._setViewProperty("TasksList", []);
			this._loadTasksCount(oView.getModel(), "/AuthorizationRequestSet/$count", "Count/TotalPendingTasks",
				[new Filter("Status", FilterOperator.EQ, "O")]);
			var oFilterDialog = this._oDialogs.getDialog("FilterTasksList").getDialog();
			oFilterDialog.setSelectedFilterCompoundKeys({
				Status: {
					Status___EQ___O: true
				} 
			});
			oFilterDialog.fireConfirm({
				filterItems: oFilterDialog.getSelectedFilterItems(),
				filterString: "Filtered by: Status (Awaiting approval)"
			});
		},
		
		_updateActionRequiredList: function (aFilters) {
			this._setViewProperty("TasksListBusy", true);
			Util.promiseRead.call(this, "/AuthorizationRequestSet", {
				filters: (aFilters.length) ? aFilters : [new Filter("Status", FilterOperator.NE, "C")]
			}).then(function (oData) {
				var aTasksList = this._getViewProperty("TasksList"),
					aRequests = oData.results.reduce(function(arr, req) {
						if (!aTasksList.some(function(task) {
							return task.RequestId === req.RequestId;
						})) {
							arr.push(req);
						}
						return arr;
					}, []) || [],
					aUserIds = aRequests.map(function(req) {
						return req.UserId;
					}).filter(function(user, index, arr) {
						return arr.indexOf(user) === index;
					}),
					aPromises = aUserIds.map(function(id) {
						return new Filter("Susid", sap.ui.model.FilterOperator.EQ, id);
					}).reduce(function(acc, item){
						var length = acc.length;
						if (!length || acc[length - 1].length >= this._getSettings().maxFilterCount) {
							acc.push([]);
							length++;
						}
						acc[length - 1].push(item);
						return acc;
					}.bind(this), []).map(function(filters) {
						var oUserIdFilter = new Filter({
							filters: filters,
							and: false
						});
						return function () {
							return Util.promiseRead.call(this, "/UserSet", {
								filters: [oUserIdFilter]
							});
						}.bind(this);
					}.bind(this));
					
					if (!aPromises.length) {
						this._setViewProperty("TasksListBusy", false);
						return;
					}
					
					Util.promiseAll(aPromises).then(function(aData) {
						var aUserList = aData.reduce(function(acc, item) {
							return acc.concat(item.results);
						}, []),
							oUsers = Util.mapBy(aUserList, "Susid"),
							aRes = aRequests.map(function (request) {
								return Util.merge(request, {
									Name1: oUsers[request.UserId].Name1,
									Namev: oUsers[request.UserId].Namev,
									Ipadr: oUsers[request.UserId].Ipadr,
									KunnrName: oUsers[request.UserId].KunnrName,
									Kunnr: oUsers[request.UserId].Kunnr
								});
							});
							this._setViewProperty("TasksList", this._sortTasksList(aTasksList.concat(aRes)));
					}.bind(this))
					.finally(this._setViewProperty.bind(this, "TasksListBusy", false));
			}.bind(this));
		},
		
		_sortTasksList: function (aTasksList) {
			return aTasksList.filter(function(task) {
				return task.Status === "O";
			}).sort(function(a, b) {
				return a.CreatedAt - b.CreatedAt;
			}).concat(aTasksList.filter(function(task) {
				return task.Status !== "O";
			}).sort(function(a, b) {
				return a.ChangedAt - b.ChangedAt;
			}));
		},

		// disable not accessed rows for admin
		// _showAccessedTasks: function () {
		// 	var taskItems = this.oView.byId(TASKS_TABLE_ID).getItems();

		// 	var sUserFunction = this.oView.getParent().__function;
		// 	var iUserId = this.getView().__logonUserID;

		// 	if (sUserFunction !== "1SUPERADMIN") {
		// 		if(sUserFunction === "USERADMIN") {
		// 			var iUserCUstomerNumber = this._getCustNum(iUserId);
		// 			for (var i = 0; i < taskItems.length; i++) {
		// 				if(taskItems[i].getCells()[5].getNumber() !== iUserCUstomerNumber) {
		// 					taskItems[i].setType("Inactive");
		// 				}
		// 			}
		// 		}
		// 		else {
		// 			for (var i = 0; i < taskItems.length; i++) {
		// 				taskItems[i].setType("Inactive");
		// 				// taskItems[i].addStyleClass("sapMInputBaseDisabled");
		// 			}
		// 		}
		// 	}
		// },

		// _getCustNum: function(userId) {
		// 	var oMasterView = this.getView();
		// 	var oUserTable = oMasterView.byId(IMP_CONT_TABLE_ID);
		// 	for (var i = 0; i < oUserTable.getItems().length; i++) {
		// 		if(oUserTable.getItems()[i].getCells()[0].getTitle() === userId) {
		// 			return oUserTable.getItems()[i].getCells()[4].getText();
		// 		}
		// 	}
		// }
		
		onSettingsAuthReqEdit: function() {
			this._setViewProperty("Settings/AuthRequestEdit", true);
		},
		
		onSettingsAuthReqSave: function() {
			this._setViewProperty("Settings/AuthRequestEdit", false);
		},
		
		onSettingsAuthReqCancel: function() {
			this._setViewProperty("Settings/AuthRequestEdit", false);
		},
		
		openEmailDomain: function (oEvent) {
			this._oServicesPopover.close();
			this.getRouter().navTo("emailDomain", {}, false);
		},
		
		onTasksSearch: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sSearchQuery = oEvent.getSource().getValue();
			setTimeout(function (sQuery) {
				if (sQuery === this.getView().byId("searchFieldTasks").getValue()) {
					if (sQuery && sQuery.length > 0) {
						
						// search by last and first name, user id, customer name and customer id, email
						var filters = new sap.ui.model.Filter([
						      new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sQuery),
						      new sap.ui.model.Filter("Namev", sap.ui.model.FilterOperator.Contains, sQuery),
						      new sap.ui.model.Filter("UserId", sap.ui.model.FilterOperator.Contains, sQuery),
						      new sap.ui.model.Filter("KunnrName", sap.ui.model.FilterOperator.Contains, sQuery),
						      new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.Contains, sQuery),
						      new sap.ui.model.Filter("Ipadr", sap.ui.model.FilterOperator.Contains, sQuery)
						]);
						aFilters.push(filters);
					}
					this.getView().byId(TASKS_TABLE_ID).getBinding("items").filter(aFilters);
				} else {
					jQuery.sap.log.info("The search trip was skipped.");
				}
			}.bind(this, sSearchQuery), 500);
		},
		
		onAdditionalNotesPress: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext(),
				sNotes = oContext.getProperty("Notes");
			if (!this._oNotesPopover) {
				this._oNotesPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.NotesPopoverOnUserList", this);
				this._oNotesPopover.setModel(this.getModel("i18n"), "i18n");
			}
			this._oNotesPopover.getContent()[0].setText(this.formatter.detail.unescapeNotes(sNotes));
			this._oNotesPopover.setPlacement(sap.m.PlacementType.Bottom);
			this._oNotesPopover.openBy(oEvent.getSource());
		},
		
		onHighlightEmailPress: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			if (!this._oUnverifiedDomainPopover) {
				this._oUnverifiedDomainPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.UnverifiedDomainPopover", this);
				this._oUnverifiedDomainPopover.setModel(this.getModel("i18n"), "i18n");
			}
			var isEmailFormatValid = oContext.getProperty("IsEmailFormatValid");
			var isEmailNotShared = oContext.getProperty("IsEmailNotShared");
			var isEmailNotDuplicate = oContext.getProperty("IsEmailNotDuplicate");
			var isValidDomain = oContext.getProperty("IsValidDomain");
			
			this._oUnverifiedDomainPopover.setTitle(this.getText("DETAIL_NON_COMPLIANT_EMAIL_TITLE"));
			this._oUnverifiedDomainPopover.getContent()[0].setHtmlText(this.formatter.master.messageInvalidEmailOrDomain(this, isEmailFormatValid, isEmailNotShared, isEmailNotDuplicate, isValidDomain));
			this._oUnverifiedDomainPopover.setPlacement(sap.m.PlacementType.Bottom);
			this._oUnverifiedDomainPopover.openBy(oEvent.getSource());
		},
		
		onInvalidEmailOrDomainPress: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext();
			var isEmailFormatValid = oContext.getProperty("IsEmailFormatValid");
			var isEmailNotShared = oContext.getProperty("IsEmailNotShared");
			var isEmailNotDuplicate = oContext.getProperty("IsEmailNotDuplicate");
			var isValidDomain = oContext.getProperty("IsValidDomain");
			if (!this._oInvalidEmailOrDomainPopover) {
				this._oInvalidEmailOrDomainPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.InvalidEmailOrDomainPopover", this);
				this._oInvalidEmailOrDomainPopover.setModel(this.getModel("i18n"), "i18n");
			}
			this._oInvalidEmailOrDomainPopover.setTitle(this.getText("DETAIL_NON_COMPLIANT_EMAIL_TITLE"));
			this._oInvalidEmailOrDomainPopover.getContent()[0].setHtmlText(this.formatter.master.messageInvalidEmailOrDomain(this, isEmailFormatValid, isEmailNotShared, isEmailNotDuplicate, isValidDomain));
			this._oInvalidEmailOrDomainPopover.setPlacement(sap.m.PlacementType.Bottom);
			this._oInvalidEmailOrDomainPopover.openBy(oEvent.getSource());
		}
		
	});
});

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",

	"sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/util/Util"

], function (Controller, MessageBox, Dialogs, Util) {

	return Controller.extend("sap.support.useradministration.view.UserAuthorizationCloudAssign", {
		onInit: function () {
			var that = this;
			var oView = this.getView();
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function (evt) {
				// When detail navigation occurs, update the binding context
				if (evt.getParameter("name") === "userAuthorizationCloudAssign") {
					var oUserInfo = oView.getParent().__oUserInfo;
					var sPath = "/USER_AUTHSet(AuthObject='" + evt.getParameter("arguments").object + "',Userid='" + evt.getParameter("arguments").user +
						"')";
					//oView.bindElement(sPath);
					oView.__bindingPath = sPath;
					oView.getParent().__user_name = null;

					if (oUserInfo) {
						oView.byId("idCloudAuthObjLevelHeader").setTitle(oUserInfo.auth_object_text);
						var oUserFullName = oUserInfo.title + " " + oUserInfo.fname + " " + oUserInfo.lname;
					}
					oView.byId("idCloudUserName_OA").setText(oUserFullName + " (" + evt.getParameter("arguments").user + ")");
				}
				that.getView().getParent()._flagUAStopNav = true;
			}, this);

			//this._aKeys = ["AuthLevel", "AuthLevelDesc"];
			this._aTenantKeys = ["TenantNumber", "TenantName"];
			this._aInstKeys = ["InstNumber", "InstName"];
			this._oDialogs = new Dialogs(this);
		},

		/**
		 * Get user model from the launchpad
		 * @returns {sap.ui.model.json.JSONModel} model
		 * @function
		 * @private
		 */
		_getUserModel: function () {
			var oCore = sap.ui.getCore();
			return oCore.getModel("user");
		},

		__navUABack2Detail: function () {
			var oView = this.getView(),
				oButton = oView && oView.byId("btnSaveCloudAuth");

			if (oButton && oButton.getEnabled()) {
				if (oView.getParent()._flagUAStopNav) {
					var oUABundle = Util.getBundle.call(this);
					//var oBtnAuthObjEdit = this.getView().byId("btnAuthObjEdit");
					var that = this;

					/* eslint-disable no-alert, no-console */
					var r = confirm(oUABundle.getText("MESSAGE_USER_UNSAVE_WARNING"));
					if (r) {
						that.saveAuthObjects();
					} else {
						that.revertAuthObjects();
					}
					/* eslint-enable no-alert, no-console */

					that.getView().getParent()._flagUAStopNav = false;
				}
			}
		},

		onAfterRendering: function () {
			var that = this;
			this.getView().getParent()._flagUAStopNav = true;
			window.addEventListener("hashchange", function (e) {
				that.__navUABack2Detail(e);
			});
		},

		handleAddProdAuthorizations: function () {
			var oView = this.getView();
			var oContext = oView.getBindingContext();
			var _UARootPath = jQuery.sap.getModulePath("sap.support.useradministration");
			var oUABundle = jQuery.sap.resources({
				url: _UARootPath + "/i18n/messageBundle.properties"
			});

			//Check if user doesn't assign authority to himself
			if (this._getUserModel()) { //For LaunchPad Support Shell
				if (this._getUserModel().getProperty("/name") === oContext.getProperty("UserId")) {
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show(oUABundle.getText("MESSAGE_AUTHORITY_WARNING2"), {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: oUABundle.getText("MISC_WARNING"),
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							// Check selected action
							if (oAction === sap.m.MessageBox.Action.OK) {
								return;
							} else {
								return;
							}
						}
					});
					return;
				}
			}

			var m = this.createJSONModel();
			var sPath = oContext.getPath();
			var authObjUrl = oView.getModel().sServiceUrl + sPath + "/AuthObjectAuthLevelF4HelpSet?$filter=AuthLevelType eq 'DEBITOR'";

			m.loadData(authObjUrl, false);
			var that = this;

			m.attachRequestCompleted(function (oData) {
				that.aProdItems = oData.getSource().getData().d.results;

				//Set preselected objects
				var token;
				var aTokens = [];
				var i;
				for (i = 0; i < that.aProdItems.length; i++) {
					if (that.aProdItems[i].IsAssigned) {
						token = new sap.m.Token({
							key: that.aProdItems[i].AuthLevel,
							text: that.aProdItems[i].AuthLevelDesc
						});
						aTokens.push(token);
					}
				}
				that.onProdValueHelpRequest(aTokens, oContext);
			});
		},

		onProdValueHelpRequest: function (tokens, context) {
			var that = this;
			var oModel18n = this.getView().getModel("i18n");
			var _UARootPath = jQuery.sap.getModulePath("sap.support.useradministration");
			var oUABundle = jQuery.sap.resources({
				url: _UARootPath + "/i18n/messageBundle.properties"
			});

			jQuery.sap.require("sap.ui.comp.valuehelpdialog.ValueHelpDialog");
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: oUABundle.getText("AUTH_OBJ_CUSTOMER_LEVEL") + "{i18n>AUTH_OBJ_MULTIPLE}",
				modal: true,
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: this._aKeys[0],
				descriptionKey: this._aKeys[1],

				ok: function (oControlEvent) {
					//if (that._updateProdAuthObjects(oControlEvent, context)) {
					oValueHelpDialog.close();
					that._updateProdAuthObjects(oControlEvent, context);
					//}
				},

				cancel: function () {
					oValueHelpDialog.close();
				},

				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});

			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oValueHelpDialog);
			oValueHelpDialog.setModel(oModel18n, "i18n");

			var oColModel = this.createJSONModel();
			oColModel.setData({
				cols: [{
					label: oUABundle.getText("MASTER_COLUMN_PROD_NAME"),
					template: "ProdName"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_PROD_NUM"),
					template: "ProdNum"
				}, {
					label: oUABundle.getText("AUTH_OBJ_ASSIGN_DESCRIPTION"),
					template: "ProdDesc"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			var oRowsModel = this.createJSONModel();

			oRowsModel.setData(this.aProdItems);
			oValueHelpDialog.getTable().setModel(oRowsModel);
			oValueHelpDialog.getTable().bindRows("/");

			this._aProdAuthTokens = tokens;

			oValueHelpDialog.setTokens(this._aProdAuthTokens);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				//			  showRestoreButton: false,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: [new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn1",
						name: "n1",
						label: oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
						control: new sap.m.Input({
							id: "idProdName"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn1",
						name: "n2",
						label: oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
						control: new sap.m.Input({
							id: "idProdNum"
						})
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "foo",
						groupName: "gn1",
						name: "n3",
						label: oUABundle.getText("AUTH_OBJ_ASSIGN_DESCRIPTION"),
						control: new sap.m.Input({
							id: "idProdDesc"
						})
					})
				],
				search: function (evt) {
					that._onProdAuthObjSearch(evt);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "idProdSearchBox",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function () {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}
			oValueHelpDialog.setFilterBar(oFilterBar);
			oValueHelpDialog.open();
			oValueHelpDialog.update();
		},

		_updateProdAuthObjects: function (oEvent) {
			this._aProdAuthTokens = oEvent.getParameter("tokens");
			var oView = this.getView();
			var oProdAuthTableItem;
			var oProdAuthTable = oView.byId("idCloudProdAuthTable");
			var oColListItem;
			var btnSaveAuth = oView.byId("btnSaveCloudAuth");
			btnSaveAuth.setEnabled(true);
			btnSaveAuth.setVisible(true);
			var btnCancelAuth = oView.byId("btnCancelCloudAuth");
			btnCancelAuth.setEnabled(true);
			btnCancelAuth.setVisible(true);
			var _UARootPath = jQuery.sap.getModulePath("sap.support.useradministration");
			var oUABundle = jQuery.sap.resources({
				url: _UARootPath + "/i18n/messageBundle.properties"
			});

			//Get table of authorization objects
			var oHelpValueTable = oEvent.getSource().getTable();
			var oHelpValueTableItems = oHelpValueTable.getBinding().oList;

			if (this._aProdAuthTokens.length === oHelpValueTableItems.length) {
				sap.m.MessageBox.show(oUABundle.getText("AUTHORIZATION_LEVEL_ALL_ENTRIES_4_CCC"), {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: oUABundle.getText("HELP_TITLE"),
					actions: [sap.m.MessageBox.Action.CLOSE],
					onClose: function () {}
				});
				return false;
			}

			//We need to remove all existing items first
			oProdAuthTable.destroyItems();

			for (var i = 0; i < this._aProdAuthTokens.length; i++) {
				for (var y = 0; y < oHelpValueTableItems.length; y++) {
					if (oHelpValueTableItems[y].AuthLevel === this._aProdAuthTokens[i].getProperty("key")) {
						oProdAuthTableItem = oHelpValueTableItems[y];
						break;
					}
				}

				oColListItem = new sap.m.ColumnListItem({
					cells: [
						new sap.m.ObjectIdentifier({
							title: oProdAuthTableItem.AuthLevelDesc,
							text: oProdAuthTableItem.AuthLevel
						}),
						new sap.m.Text({
							text: oProdAuthTableItem.ProdDesc
						})
					]
				});

				oProdAuthTable.addItem(oColListItem);
			}
			this.__oProdFilter = false;
			return true;
		},

		saveAuthObjects: function () {
			
		},

		resetAuthObjects: function () {
			var oBundle = this.getView().getModel("i18n");
			var that = this;

			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.show(oBundle.getProperty("MESSAGE_AUTH_ITEMS_RESET"), {
				icon: sap.m.MessageBox.Icon.WARNING,
				title: oBundle.getProperty(oBundle.getProperty("MISC_RESET_SELECTED_ITEMS")),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
				onClose: function (oAction) {
					// Check selected action
					if (oAction === sap.m.MessageBox.Action.OK) {
						that.revertAuthObjects();
					}
				}
			});
		},

		revertAuthObjects: function () {
			var oModel = this.getView().getModel();
			var oProdAuthTable = this.getView().byId("idCloudProdAuthTable");
			var oInstAuthTable = this.getView().byId("idCloudInstAuthTable");

			oProdAuthTable.destroyItems();
			oInstAuthTable.destroyItems();
			oModel.refresh();

			//Disable buttons
			var btnSaveAuth = this.getView().byId("btnSaveCloudAuth");
			btnSaveAuth.setEnabled(false);
			var btnCancelAuth = this.getView().byId("btnCancelCloudAuth");
			btnCancelAuth.setEnabled(false);

			//Show/Hide buttons
			if (this.getView().getBindingContext().getProperty("CurrentAuthLevel") === "none") {
				btnSaveAuth.setVisible(true);
				btnCancelAuth.setVisible(true);
			} else {
				btnSaveAuth.setVisible(false);
				btnCancelAuth.setVisible(false);
			}

			this._aProdAuthTokens = undefined;
			this._aInstAuthTokens = undefined;
		},

		_onProdAuthObjSearch: function (evt) {
			//Get table of authorization objects
			var oTable = evt.getSource().getParent().getParent().getParent().getTable();
			var aFilters = [];

			//If value(s) in "Advance Mode selected
			var sProdNameQuery = sap.ui.getCore().byId("idCloudProdName").getValue();
			var sProdNumQuery = sap.ui.getCore().byId("idCloudProdNum").getValue();
			var sProdDescQuery = sap.ui.getCore().byId("idCloudProdDesc").getValue();
			if (sProdDescQuery || sProdNameQuery || sProdNumQuery) {
				sap.ui.getCore().byId("idCloudProdSearchBox").setValue("");
				aFilters.push(new sap.ui.model.Filter("ProdName", sap.ui.model.FilterOperator.Contains, sProdNameQuery));
				aFilters.push(new sap.ui.model.Filter("ProdNum", sap.ui.model.FilterOperator.Contains, sProdNumQuery));
				aFilters.push(new sap.ui.model.Filter("ProdDesc", sap.ui.model.FilterOperator.Contains, sProdDescQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			} else { //Basic search executed here, in case, if no values specified in the advanced search 
				var sQuery = sap.ui.getCore().byId("idCloudProdSearchBox").getValue();
				aFilters.push(new sap.ui.model.Filter("ProdName", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("ProdNum", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("ProdDesc", sap.ui.model.FilterOperator.Contains, sQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: false
				}));
			}
		},

		/**
		 * Append Products to the list
		 * @param {string[]} aProducts Product numbers
		 * @function
		 * @private
		 */
		_appendProductAuthObjects: function (aProducts) {
			var oView = this.getView(),
				oProdAuthTable = oView.byId("idCloudProdAuthTable"),
				aItems = oProdAuthTable.getItems(),
				aExistingProducts = aItems.map(function (oItem) {
					return oItem.getCells()[0].getText();
				});

			if (!aProducts.length) {
				return;
			}

			oView.setBusy(true);
			oView.getModel().read(oView.getBindingContext() + "/AuthObjectAuthLevelF4HelpSet", {
				filters: [new sap.ui.model.Filter("AuthLevelType", sap.ui.model.FilterOperator.EQ, "DEBITOR")],
				success: function (oData) {
					var oAllProducts = {};
					oView.setBusy(false);
					oData.results.forEach(function (oProduct) {
						oAllProducts[oProduct.AuthLevel] = oProduct;
					});

					aProducts.forEach(function (sProduct) {
						if (aExistingProducts.indexOf(sProduct) === -1) {
							var oProduct = oAllProducts[sProduct];
							if (oProduct) {
								oProdAuthTable.addItem(new sap.m.ColumnListItem({
									cells: [
										new sap.m.ObjectIdentifier({
											title: oProduct.AuthLevelDesc,
											text: oProduct.AuthLevel
										}),
										new sap.m.Text({
											text: oProduct.ProdDesc
										})
									]
								}));
							}
						}
					});
				},
				error: function () {
					oView.setBusy(false);
				}
			});
		},

		/**
		 * Get selected Product numbers
		 * @returns {string[]} array of Product numbers
		 * @function
		 * @public
		 */
		getSelectedProductNumbers: function () {
			var oTable = this.getView().byId("idCloudProdAuthTable"),
				aItems = oTable.getItems();

			return aItems.map(function (oItem) {
				return oItem.getCells()[0].getText().trim();
			});
		},

		removeAllAuthObjects: function () {
			var that = this;
			var _UARootPath = jQuery.sap.getModulePath("sap.support.useradministration");
			var oUABundle = jQuery.sap.resources({
				url: _UARootPath + "/i18n/messageBundle.properties"
			});

			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.show(oUABundle.getText("MESSAGE_AUTHORITY_REMOVE"), {
				icon: sap.m.MessageBox.Icon.WARNING,
				title: oUABundle.getText("MISC_WARNING"),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
				onClose: function (oAction) {
					// Check selected action
					if (oAction === sap.m.MessageBox.Action.OK) {
						that.saveAuthObjects();
					} else {
						return;
					}
				}
			});
		},

		//Handling Installations
		handleDeleteInstAuthorizations: function () {
			var oInstAuthTable = this.getView().byId("idCloudInstAuthTable");
			oInstAuthTable.destroyItems();

			var btnSaveAuth = this.getView().byId("btnSaveCloudAuth");
			btnSaveAuth.setEnabled(true);
			btnSaveAuth.setVisible(true);
			var btnCancelAuth = this.getView().byId("btnCancelCloudAuth");
			btnCancelAuth.setEnabled(true);
			btnCancelAuth.setVisible(true);
		},

		handleAddInstallAuthorizations: function () {
			var oView = this.getView();
			var oModel = oView.getModel("ca");
			var oData = oModel.getData(oView.__bindingPath);
			var _UARootPath = jQuery.sap.getModulePath("sap.support.useradministration");
			var oUABundle = jQuery.sap.resources({
				url: _UARootPath + "/i18n/messageBundle.properties"
			});

			//Check if user doesn't assign authority to himself
			if (this._getUserModel()) { //For LaunchPad Support Shell
				if (this._getUserModel().getProperty("/name") === oData.Userid) {
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show(oUABundle.getText("MESSAGE_AUTHORITY_WARNING2"), {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: oUABundle.getText("MISC_WARNING"),
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							// Check selected action
							if (oAction === sap.m.MessageBox.Action.OK) {
								return;
							} else {
								return;
							}
						}
					});

					return;
				}
			}

			var m = this.createJSONModel();
			var authObjUrl = oView.getModel("ca").sServiceUrl + "/cloud_installationsSet";

			m.loadData(authObjUrl, false);
			var that = this;

			m.attachRequestCompleted(function (oData) {
				that.aInstItems = oData.getSource().getData().d.results;

				//Set preselected objects
				var token;
				var aTokens = [];
				var i;
				for (i = 0; i < that.aInstItems.length; i++) {
					if (that.aInstItems[i].IsAssigned) {
						token = new sap.m.Token({
							key: that.aInstItems[i].InstNumber,
							text: that.aInstItems[i].InstName
						});
						aTokens.push(token);
					}
				}
				that.onInstValueHelpRequest(aTokens);
			});
		},

		onInstValueHelpRequest: function (tokens) {
			var that = this;
			var oModel18n = this.getView().getModel("i18n");
			var _UARootPath = jQuery.sap.getModulePath("sap.support.useradministration");
			var oUABundle = jQuery.sap.resources({
				url: _UARootPath + "/i18n/messageBundle.properties"
			});

			jQuery.sap.require("sap.ui.comp.valuehelpdialog.ValueHelpDialog");
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: "{i18n>AUTH_OBJ_INST_LEVEL}" + "{i18n>AUTH_OBJ_MULTIPLE}",
				modal: true,
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: this._aInstKeys[0],
				descriptionKey: this._aInstKeys[1],

				ok: function (oControlEvent) {
					oValueHelpDialog.close();
					that._updateInstAuthObjects(oControlEvent);
				},

				cancel: function () {
					oValueHelpDialog.close();
				},

				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oValueHelpDialog);
			oValueHelpDialog.setModel(oModel18n, "i18n");

			var oColModel = this.createJSONModel();
			oColModel.setData({
				cols: [{
					label: oUABundle.getText("MASTER_COLUMN_INST_NAME"),
					template: "InstName"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_INST_NUM"),
					template: "InstNumber"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
					template: "CustomerId"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
					template: "CustomerName"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			var oRowsModel = this.createJSONModel();

			oRowsModel.setData(this.aInstItems);
			var oInstTable = oValueHelpDialog.getTable();
			oInstTable.setModel(oRowsModel);
			oInstTable.bindRows("/");

			this._aInstAuthTokens = tokens;
			oValueHelpDialog.setTokens(this._aInstAuthTokens);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: [new sap.ui.comp.filterbar.FilterGroupItem({
					groupTitle: "foo",
					groupName: "gn1",
					name: "n1",
					label: oUABundle.getText("AUTH_OBJ_INST_LEVEL"),
					control: new sap.m.Input({
						id: "idInstLevelDesc"
					})
				})],
				search: function (evt) {
					that._onInstAuthObjSearch(evt);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "idCloudInstSearchBox",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function () {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}

			oValueHelpDialog.setFilterBar(oFilterBar);

			oValueHelpDialog.open();
			oValueHelpDialog.update();
		},

		_onInstAuthObjSearch: function (evt) {
			//Get table of authorization objects
			var oTable = evt.getSource().getParent().getParent().getParent().getTable();
			var aFilters = [];

			//If value(s) in "Advance Mode selected
			var sInstNameQuery = sap.ui.getCore().byId("idCloudInstSearchBox").getValue();
			if (sInstNameQuery) {
				sap.ui.getCore().byId("idCloudInstSearchBox").setValue("");
				aFilters.push(new sap.ui.model.Filter("InstName", sap.ui.model.FilterOperator.Contains, sInstNameQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			} else { //Basic search executed here, in case, if no values specified in the advanced search 
				var sQuery = sap.ui.getCore().byId("idCloudInstSearchBox").getValue();
				aFilters.push(new sap.ui.model.Filter("InstName", sap.ui.model.FilterOperator.Contains, sQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: false
				}));
			}
		},

		_updateInstAuthObjects: function (oEvent) {
			this._aInstAuthTokens = oEvent.getParameter("tokens");
			var oView = this.getView();
			var oInstAuthTable = oView.byId("idCloudInstAuthTable");
			var oColListItem;
			var oInstAuthTableItem;
			var btnSaveAuth = oView.byId("btnSaveCloudAuth");
			btnSaveAuth.setEnabled(true);
			btnSaveAuth.setVisible(true);
			var btnCancelAuth = oView.byId("btnCancelCloudAuth");
			btnCancelAuth.setEnabled(true);
			btnCancelAuth.setVisible(true);

			//We need to remove all existing items first
			oInstAuthTable.destroyItems();

			//Get table of authorization objects
			var oHelpValueTable = oEvent.getSource().getTable();
			var oHelpValueTableItems = oHelpValueTable.getBinding().oList;

			for (var i = 0; i < this._aInstAuthTokens.length; i++) {
				for (var y = 0; y < oHelpValueTableItems.length; y++) {
					if (oHelpValueTableItems[y].InstNumber === this._aInstAuthTokens[i].getProperty("key")) {
						oInstAuthTableItem = oHelpValueTableItems[y];
						break;
					}
				}

				oColListItem = new sap.m.ColumnListItem({
					cells: [
						new sap.m.ObjectIdentifier({
							title: oInstAuthTableItem.InstName,
							text: oInstAuthTableItem.InstNumber
						}),
						new sap.m.ObjectIdentifier({
							title: oInstAuthTableItem.CustomerName,
							text: oInstAuthTableItem.CustomerId
						})
					]
				});

				oInstAuthTable.addItem(oColListItem);
			}
			return true;
		},

		//Handling Tenants
		handleDeleteTenantAuthorizations: function () {
			var oTenantAuthTable = this.getView().byId("idCloudTenantAuthTable");
			oTenantAuthTable.destroyItems();

			var btnSaveAuth = this.getView().byId("btnSaveCloudAuth");
			btnSaveAuth.setEnabled(true);
			btnSaveAuth.setVisible(true);
			var btnCancelAuth = this.getView().byId("btnCancelCloudAuth");
			btnCancelAuth.setEnabled(true);
			btnCancelAuth.setVisible(true);
		},

		handleAddTenantAuthorizations: function () {
			var oView = this.getView();
			var oModel = oView.getModel("ca");
			var oData = oModel.getData(oView.__bindingPath);
			var _UARootPath = jQuery.sap.getModulePath("sap.support.useradministration");
			var oUABundle = jQuery.sap.resources({
				url: _UARootPath + "/i18n/messageBundle.properties"
			});

			//Check if user doesn't assign authority to himself
			if (this._getUserModel()) { //For LaunchPad Support Shell
				if (this._getUserModel().getProperty("/name") === oData.Userid) {
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show(oUABundle.getText("MESSAGE_AUTHORITY_WARNING2"), {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: oUABundle.getText("MISC_WARNING"),
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							// Check selected action
							if (oAction === sap.m.MessageBox.Action.OK) {
								return;
							} else {
								return;
							}
						}
					});

					return;
				}
			}

			var m = this.createJSONModel();
			var authObjUrl = oView.getModel("ca").sServiceUrl + "/cloud_tenantsSet";

			m.loadData(authObjUrl, false);
			var that = this;

			m.attachRequestCompleted(function (oData) {
				that.aTenantItems = oData.getSource().getData().d.results;

				//Set preselected objects
				var token;
				var aTokens = [];
				var i;
				for (i = 0; i < that.aTenantItems.length; i++) {
					if (that.aTenantItems[i].IsAssigned) {
						token = new sap.m.Token({
							key: that.aTenantItems[i].TenantNumber,
							text: that.aTenantItems[i].TenantName
						});
						aTokens.push(token);
					}
				}
				that.onTenantValueHelpRequest(aTokens);
			});
		},

		onTenantValueHelpRequest: function (tokens) {
			var that = this;
			var oModel18n = this.getView().getModel("i18n");
			var _UARootPath = jQuery.sap.getModulePath("sap.support.useradministration");
			var oUABundle = jQuery.sap.resources({
				url: _UARootPath + "/i18n/messageBundle.properties"
			});

			jQuery.sap.require("sap.ui.comp.valuehelpdialog.ValueHelpDialog");
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: "{i18n>AUTH_OBJ_TENANT_LEVEL}" + "{i18n>AUTH_OBJ_MULTIPLE}",
				modal: true,
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: this._aTenantKeys[0],
				descriptionKey: this._aTenantKeys[1],

				ok: function (oControlEvent) {
					oValueHelpDialog.close();
					//that._updateTenantAuthObjects(oControlEvent, context);
					that._updateTenantAuthObjects(oControlEvent);
				},

				cancel: function () {
					oValueHelpDialog.close();
				},

				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), oValueHelpDialog);
			oValueHelpDialog.setModel(oModel18n, "i18n");

			var oColModel = this.createJSONModel();
			oColModel.setData({
				cols: [{
					label: oUABundle.getText("MASTER_COLUMN_TENANT_NAME"),
					template: "TenantName"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_TENANT_NUM"),
					template: "TenantNumber"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_INST_NAME"),
					template: "InstProd"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_INST_NUM"),
					template: "InstNumber"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_CUST_NUM"),
					template: "CustomerId"
				}, {
					label: oUABundle.getText("MASTER_COLUMN_CUST_NAME"),
					template: "CustomerName"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			var oRowsModel = this.createJSONModel();

			oRowsModel.setData(this.aTenantItems);
			var oInstTable = oValueHelpDialog.getTable();
			oInstTable.setModel(oRowsModel);
			oInstTable.bindRows("/");

			this._aTenantAuthTokens = tokens;
			oValueHelpDialog.setTokens(this._aTenantAuthTokens);

			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				//					  showRestoreButton: false,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: [new sap.ui.comp.filterbar.FilterGroupItem({
					groupTitle: "foo",
					groupName: "gn1",
					name: "n1",
					label: oUABundle.getText("AUTH_OBJ_TENANT_DESCRIPTION"),
					control: new sap.m.Input({
						id: "idTenantLevelDesc"
					})
				})],
				search: function (evt) {
					that._onTenantAuthObjSearch(evt);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "idCloudTenantSearchBox",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function () {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}

			oValueHelpDialog.setFilterBar(oFilterBar);

			oValueHelpDialog.open();
			oValueHelpDialog.update();
		},

		_onTenantAuthObjSearch: function (evt) {
			//Get table of authorization objects
			var oTable = evt.getSource().getParent().getParent().getParent().getTable();
			var aFilters = [];

			//If value(s) in "Advance Mode selected
			var sTenantNameQuery = sap.ui.getCore().byId("idCloudTenantSearchBox").getValue();
			if (sTenantNameQuery) {
				sap.ui.getCore().byId("idCloudTenantSearchBox").setValue("");
				aFilters.push(new sap.ui.model.Filter("TenantName", sap.ui.model.FilterOperator.Contains, sTenantNameQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			} else { //Basic search executed here, in case, if no values specified in the advanced search 
				var sQuery = sap.ui.getCore().byId("idCloudTenantSearchBox").getValue();
				aFilters.push(new sap.ui.model.Filter("TenantName", sap.ui.model.FilterOperator.Contains, sQuery));
				oTable.getBinding().filter(new sap.ui.model.Filter({
					filters: aFilters,
					and: false
				}));
			}
		},

		_updateTenantAuthObjects: function (oEvent) {
			this._aTenantAuthTokens = oEvent.getParameter("tokens");
			var oView = this.getView();
			var oTenantAuthTable = oView.byId("idCloudTenantAuthTable");
			var oColListItem;
			var oTenantAuthTableItem;
			var btnSaveAuth = oView.byId("btnSaveCloudAuth");
			btnSaveAuth.setEnabled(true);
			btnSaveAuth.setVisible(true);
			var btnCancelAuth = oView.byId("btnCancelCloudAuth");
			btnCancelAuth.setEnabled(true);
			btnCancelAuth.setVisible(true);

			//We need to remove all existing items first
			oTenantAuthTable.destroyItems();

			//Get table of authorization objects
			var oHelpValueTable = oEvent.getSource().getTable();
			var oHelpValueTableItems = oHelpValueTable.getBinding().oList;

			for (var i = 0; i < this._aTenantAuthTokens.length; i++) {
				for (var y = 0; y < oHelpValueTableItems.length; y++) {
					if (oHelpValueTableItems[y].TenantNumber === this._aTenantAuthTokens[i].getProperty("key")) {
						oTenantAuthTableItem = oHelpValueTableItems[y];
						break;
					}
				}

				oColListItem = new sap.m.ColumnListItem({
					cells: [
						new sap.m.ObjectIdentifier({
							title: oTenantAuthTableItem.TenantName,
							text: oTenantAuthTableItem.TenantNumber
						}),
						new sap.m.ObjectIdentifier({
							title: oTenantAuthTableItem.InstProd,
							text: oTenantAuthTableItem.InstNumber
						}),
						new sap.m.ObjectIdentifier({
							title: oTenantAuthTableItem.CustomerName,
							text: oTenantAuthTableItem.CustomerId
						})
					]
				});

				oTenantAuthTable.addItem(oColListItem);
			}
			return true;
		}
	});
});
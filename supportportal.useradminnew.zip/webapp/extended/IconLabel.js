sap.ui.define([
	"sap/m/Label",
	"sap/m/LabelRenderer",
	"sap/m/LabelDesign",
	"sap/m/ObjectStatus",
	"sap/m/HyphenationSupport",
	"sap/ui/core/TextDirection",
	"sap/ui/core/ValueState",
	"sap/ui/core/ValueStateSupport",
	"sap/ui/core/LabelEnablement",
	"sap/ui/core/VerticalAlign",
	"sap/ui/core/IndicationColorSupport"
], function(Label, LabelRenderer, LabelDesign, ObjectStatus, HyphenationSupport,
			TextDirection, ValueState, ValueStateSupport, LabelEnablement, VerticalAlign, IndicationColorSupport) {
	"use strict";

	return Label.extend("sap.support.useradministration.extended.IconLabel", {
		metadata: {
			properties: {
				showIcon: {
					bindable: true,
					type: "boolean",
					defaultValue: "true",
					group: "Behavior"
				}
			},
			aggregations: {},
			events: {
				"iconPress" : {}
			}
		},
		
		iconControl: null,
		
		getIconControl: function () {
			if (!this.iconControl) {
				this.iconControl = new ObjectStatus({
					active: true,
					icon: "sap-icon://message-information",
					state: "Information"
				});
				this.iconControl.attachPress(function() {
					this.fireIconPress();
				}.bind(this));
			}
			
			return this.iconControl;
		},
		
		getDomRef: function() {
			return window.document.getElementById(this.getIconControl().getId() + "-link");
		},
		
		renderer: function(rm, oLabel) {
			if(!oLabel.getProperty("showIcon")) {
				LabelRenderer.render.call(this, rm, oLabel);
				return;
			}
			var renderIcon = function (oRm, oLabelControl) {
				var oObjStatus = oLabelControl.getIconControl();
				
				oRm.openStart("div", oObjStatus);
				oRm.style("position", "relative");
				oRm.style("top", "-2px");
				oRm.style("line-height", "1rem");
				oRm.style("width", "20px");
				oRm.style("text-align", "start");
				

				var sState = oObjStatus.getState();
				var bInverted = oObjStatus.getInverted();
				var sTextDir = oObjStatus.getTextDirection();
				var oCore = sap.ui.getCore();
				var bPageRTL = oCore.getConfiguration().getRTL();
				var oAccAttributes = {
					roledescription: oCore.getLibraryResourceBundle("sap.m").getText("OBJECT_STATUS")
				};
				var sValueStateText;
				var accValueText;
	
				if (sTextDir === TextDirection.Inherit) {
					sTextDir = bPageRTL ? TextDirection.RTL : TextDirection.LTR;
				}
	
				var sTooltip = oObjStatus.getTooltip_AsString();
				if (sTooltip) {
					oRm.attr("title", sTooltip);
				}
	
				oRm.class("sapMObjStatus");
				oRm.class("sapMObjStatus" + sState);
				if (bInverted) {
					oRm.class("sapMObjStatusInverted");
				}
	
				if (oObjStatus._isActive()) {
					oRm.class("sapMObjStatusActive");
					oRm.attr("tabindex", "0");
					oAccAttributes.role = "button";
				} else {
					oAccAttributes.role = "group";
				}
	
				oRm.accessibilityState(oObjStatus, oAccAttributes);
	
				oRm.openEnd();
	
				if (oObjStatus._isActive()) {
					oRm.openStart("span", oObjStatus.getId() + "-link");
					oRm.class("sapMObjStatusLink");
					oRm.openEnd();
				}
	
				if (oObjStatus.getIcon()) {
					oRm.openStart("span", oObjStatus.getId() + "-statusIcon");
					oRm.class("sapMObjStatusIcon");
					if (!oObjStatus.getText()) {
						oRm.class("sapMObjStatusIconOnly");
					}
					oRm.openEnd();
					oRm.renderControl(oObjStatus._getImageControl());
					oRm.close("span");
				}
	
				if (oObjStatus._isActive()) {
					oRm.close("span");
				}
				/* ARIA adding hidden node in span element */
				sValueStateText = ValueStateSupport.getAdditionalText(sState);
				if (sValueStateText) {
					accValueText = sValueStateText;
				} else {
					accValueText = IndicationColorSupport.getAdditionalText(sState);
				}
				if (accValueText) {
					oRm.openStart("span", oObjStatus.getId() + "sapSRH");
					oRm.class("sapUiPseudoInvisibleText");
					oRm.openEnd();
					oRm.text(accValueText);
					oRm.close("span");
				}
		
				oRm.close("div");
			};
			// convenience variable
			var r = LabelRenderer,
				sTextDir = oLabel.getTextDirection(),
				sTextAlign = oLabel.getTextAlign(),
				sWidth = oLabel.getWidth(),
				sLabelText = oLabel.getText(),
				sTooltip = oLabel.getTooltip_AsString(),
				sLabelForRendering = oLabel.getLabelForRendering(),
				bDisplayOnly = oLabel.isDisplayOnly(),
				sVerticalAlign = oLabel.getVAlign();
			// write the HTML into the render manager
			// for accessibility reasons when a label doesn't have a "for" attribute, pointing at a HTML element it is rendered as span
			rm.openStart("span", oLabel);
	
			// styles
			rm.class("sapMLabel");
			rm.class("sapUiSelectable");
			// rm.style("padding-left", "5px");
			// rm.style("box-sizing", "border-box");
	
			// label wrapping
			if (oLabel.isWrapping()) {
				rm.class("sapMLabelWrapped");
			}
			// set design to bold
			if (oLabel.getDesign() === LabelDesign.Bold) {
				rm.style("font-weight", "bold");
			}
	
			if (oLabel.isRequired()) {
				rm.class("sapMLabelRequired");
			}
	
			if (sLabelForRendering) {
				LabelEnablement.writeLabelForAttribute(rm, oLabel);
			} else if (oLabel.getParent() instanceof sap.m.Toolbar) {
				rm.class("sapMLabelTBHeader");
			}
	
			rm.accessibilityState({
				label: oLabel.getText()
			});
	
			// text direction
			if (sTextDir !== TextDirection.Inherit){
				rm.attr("dir", sTextDir.toLowerCase());
			}
	
			// style for width
			if (sWidth) {
				rm.style("width", sWidth);
			} else {
				rm.class("sapMLabelMaxWidth");
			}
	
			// style for text alignment
			if (sTextAlign) {
				sTextAlign = r.getTextAlign(sTextAlign, sTextDir);
				if (sTextAlign) {
					rm.style("text-align", sTextAlign);
				}
			}
	
			if (sLabelText === "") {
				rm.class("sapMLabelNoText");
			}
	
			if (bDisplayOnly) {
				rm.class("sapMLabelDisplayOnly");
			}
	
			if (sVerticalAlign !== VerticalAlign.Inherit) {
				rm.style("vertical-align", sVerticalAlign.toLowerCase());
			}
	
			HyphenationSupport.writeHyphenationClass(rm, oLabel);
	
			if (sTooltip) {
				rm.attr("title", sTooltip);
			}
	
			rm.openEnd();
	
			// wrap the label text
			rm.openStart("span", oLabel.getId() + "-text");
			rm.class("sapMLabelTextWrapper");
			rm.openEnd();
			
			renderIcon(rm, oLabel);
	
			// write the label text
			rm.openStart("bdi", oLabel.getId() + "-bdi");
			rm.openEnd();
	
			if (sLabelText) {
				sLabelText = HyphenationSupport.getTextForRender(oLabel, "main");
				rm.text(sLabelText);
			}
			rm.close("bdi");
			rm.close("span");
	
			// shows the colon and the required asterisk
			rm.openStart("span");
			rm.class("sapMLabelColonAndRequired");
			rm.openEnd();
			rm.close("span");
	
			rm.close("span");
		}
	});
});
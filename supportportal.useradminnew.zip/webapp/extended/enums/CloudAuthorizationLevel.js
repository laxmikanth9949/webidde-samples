jQuery.sap.declare("sap.support.useradministration.extended.enums.CloudAuthorizationLevel");
sap.support.useradministration.extended.enums.CloudAuthorizationLevel = {
    Prod: "Prod",
    Product: "Prod",
    Install: "Install",
    Installation: "Install",
    Tenant: "Tenant"
};
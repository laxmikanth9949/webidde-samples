sap.ui.define([
    "sap/ui/base/Object"
], function (BaseObject) {
    
    /**
     * Hash checker
     * @param {sap.ui.core.routing.Router} oRouter router to get routes
     * @class
     * @extends {sap.ui.base.Object}
     * @public
     * @alias sap.support.useradministration.extended.AdjustableListItem
     */
    return BaseObject.extend("sap.support.useradministration.extended.HashChecker", {
        _aRoutes: [],
        _oRouter: null,
        
        constructor: function(oRouter) {
            this._oRouter = oRouter;
            this._aRoutes = jQuery.map(this._oRouter._oRoutes, function (oRoute, sRouteName) {
                var oInnerRoute = oRoute._aRoutes[0];
                return {
                    Name: sRouteName,
                    RegExp: oInnerRoute && oInnerRoute._matchRegexp
                };
            });
        },
        
        /**
         * Get hash
         * @param {string} sUrl url
         * @returns {string} hash
         * @function
         * @private
         */
        _getHash: function(sUrl) {
            var oHash = /#(.*)$/.exec(sUrl);
            return oHash ? oHash[1] : sUrl;
        },
        
        /**
         * Get route name that matches given URL
         * @param {string} sUrl URL
         * @returns {string} route name
         * @function
         * @public
         */
        getMatchedRouteName: function(sUrl) {
            var sHash = this._getHash(sUrl),
                sRouteName = null;
            
            this._aRoutes.some(function (oRoute) {
                if (oRoute.RegExp && oRoute.RegExp.test(sHash)) {
                    sRouteName = oRoute.Name;
                    return true;
                }
            });
            return sRouteName;
        },
        
        /**
         * Check if URL matches route
         * @param {string} sUrl url
         * @param {string} sRouteName route name
         * @returns {boolean} result
         * @function
         * @private
         */
        match: function(sUrl, sRouteName) {
            var sHash = this._getHash(sUrl),
                oRoute = this._oRouter.getRoute(sRouteName),
                oInnerRoute = oRoute && oRoute._aRoutes[0],
                oRegExp = oInnerRoute && oInnerRoute._matchRegexp;
            
            return Boolean(oRegExp && oRegExp.test(sHash));
        }
    });
});
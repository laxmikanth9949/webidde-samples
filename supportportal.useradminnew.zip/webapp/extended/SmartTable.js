sap.ui.define([
	"sap/m/Table",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportColumn",
	"sap/ui/core/util/ExportCell",
	"sap/ui/model/json/JSONModel",
	"sap/support/useradministration/js/ExportTypeCSV",
	"sap/support/useradministration/extended/KeyColumn",
	"sap/support/useradministration/util/Util"
], function(Table, Export, ExportColumn, ExportCell, JSONModel, ExportTypeCSV, KeyColumn, Util) {
	"use strict";

	/**
	 * A table with extended functionality like getting export
	 * @class
	 * @extends sap.m.Table
	 * @alias sap.support.useradministration.extended.SmartTable
	 */
	return Table.extend("sap.support.useradministration.extended.SmartTable", {
		metadata: {
			aggregations: {
				columns: {
					type: "sap.support.useradministration.extended.KeyColumn",
					multiple: true,
					singularName: "column",
					dnd: {
						draggable: true,
						droppable: true,
						layout: "Horizontal"
					}
				}
			},
			
			properties: {
				saveFileName: {
					bindable: true,
					defaultValue: "",
					type: "string"
				}
			}
		},
		renderer: {},
		
		/**
		 * Get data template for given table cell
		 * @param {sap.ui.core.Control} oCell table cell
		 * @param {string} sModelName model name
		 * @returns {object} template or empty string
		 * @function
		 * @private
		 */
		_getCellTemplate: function(oCell, sModelName) {
			var oInfo;
			
			if (oCell) {
				// Search for binding
				["title", "text", "number", "state"].some(function (sName) {
					oInfo = oCell.getBindingInfo(sName);
					return oInfo;
				});
			}
			
			if (oInfo) {
				return {
					parts: jQuery.extend(true, [], oInfo.parts).map(function (oPart) {
						// I had to remove model name to make it work
						if (oPart.model === sModelName) {
							oPart.model = undefined;
						}
						return oPart;
					}),
					formatter: oInfo.formatter
				};
			}
			return "";
		},
		
		/**
		 * Get full path for binding
		 * @param {sap.ui.model.Binding} oBinding binding
		 * @returns {string} sPath
		 * @function
		 * @private
		 */
		_getFullBindingPath: function(oBinding) {
		    var sPath = oBinding.getPath();
		    if (oBinding.getContext && oBinding.getContext()) {
		        sPath = oBinding.getContext().getPath() + 
		        ((sPath[0] !== "/") ? "/" : "") + 
		        sPath;
		    }
		    return sPath;
		},
        
        /**
         * Get columns sorted by order
         * @returns {sap.support.useradministration.components.KeyColumn} columns list
         * @function
         * @private
         */
        _getOrderedColumns: function() {
            return this.getColumns().slice().sort(function(oFirst, oSecond) {
                return oFirst.getOrder() - oSecond.getOrder();
            });
        },

		/**
		 * Get export object
		 * @returns {sap.ui.core.util.Export} export
		 * @function
		 * @public
		 */
		getExport: function(bWithoutContext) {
			var oBinding = this.getBinding("items"),
				oBindingInfo = this.getBindingInfo("items"),
				aCells = oBindingInfo.template.getCells(),
				aAppFilters = oBinding.aApplicationFilters,
				aFilters = (aAppFilters && aAppFilters.length > 0 && oBinding.aFilters > 0) ?
					[
						new sap.ui.model.Filter({
							filters:[
								new sap.ui.model.Filter({filters: oBinding.aFilters}),
								new sap.ui.model.Filter({filters: aAppFilters})
							],
							and: true
						})
					] : oBinding.aFilters.concat(aAppFilters),
				aRows = oBinding && {
					path: (bWithoutContext) ? oBinding.getPath() : this._getFullBindingPath(oBinding),
					filters: aFilters,
					sorter: oBinding.aSorters
				};
			var oExport = new Export({
				exportType: new ExportTypeCSV({
					separatorChar: ";",
					charset: "utf-8"
				}),

				columns: this._getOrderedColumns().map(function(oColumn) {
					if (oColumn.getVisible() && oColumn.getExportable()) {
						var sText = oColumn.getHeader() && oColumn.getHeader().getText() || "";
						return new ExportColumn({
							name: sText,
							template: new ExportCell({
								content: this._getCellTemplate(aCells[oColumn.getInitialOrder()], oBindingInfo.model)
							})
						});
					}
					return null;
				}.bind(this)).filter(Boolean),

				rows: aRows || []
			});

			if (oBinding) {
				oExport.setModel(oBinding.getModel());
			}
			oExport.setModel(this.getModel("i18n"), "i18n");
			return oExport;
		},
		
		/**
		 * Get raw export object for page-by-page download
		 * @param {object} oBindingInfo binding info
		 * @param {string} sBindingPath binding path
		 * @returns {sap.ui.core.util.Export} export
		 * @function
		 * @private
		 */
		_getRawExport: function (oBindingInfo, sBindingPath) {
			var aCells = oBindingInfo.template.getCells();
			
			return new Export({
				exportType: new ExportTypeCSV({
					separatorChar: ";",
					charset: "utf-8"
				}),

				columns: this._getOrderedColumns().map(function(oColumn) {
					if (oColumn.getExportable()) {
						var sText = oColumn.getHeader() && oColumn.getHeader().getText() || "";
						return new ExportColumn({
							name: sText,
							template: new ExportCell({
								content: this._getCellTemplate(aCells[oColumn.getInitialOrder()], oBindingInfo.model)
							})
						});
					}
					return null;
				}.bind(this)).filter(Boolean),

				rows: {
					model: oBindingInfo.model,
					path: sBindingPath
				}
			});
		},
		
		/**
		 * Get count from oData response
		 * @param {object} oData response
		 * @returns {int} count
		 * @function
		 * @private
		 */
		_extractCountFromResponse: function (oData) {
			return oData;
		},
		
		/**
		 * Gather data for export page-by-page
		 * @param {string} sPath URI to call
		 * @param {object} oListParams params for data request
		 * @param {object} oCountParams params for count request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel oData model
		 * @param {int} iPageSize page size
		 * @function
		 * @return {Promise} promise with data
		 * @private
		 */
		_gatherDataPageByPage: function (sPath, oListParams, oCountParams, oModel, iPageSize) { 
			var that = this;
			
			return new Promise(function (resolve, reject) {
				var iCount = 0,
					aItems = [],
					
					sCountPath = sPath + "/$count",
					aInitialRequests = [
						Util.promiseRead(sCountPath, oCountParams, oModel),
						Util.promiseRead(sPath, oListParams, oModel)
					];
				
				Promise.all(aInitialRequests)
					.then(function (aPromiseResults) {
						iCount = Number(aPromiseResults[0]);
						aItems = aPromiseResults[1].results || [];
						
						var oPromise = Promise.resolve(aItems),
							oBundle = that.getModel("i18n").getResourceBundle(),
							sToastText = "";
						
						for (var iSkip = iPageSize; iSkip < iCount; iSkip += iPageSize) {
							if (iCount) {
								sToastText = oBundle.getText("MESSAGE_DOWNLOADING_DATA_PROGRESS", [Math.floor(iSkip * 100 / iCount)]);
							}
							oPromise = oPromise.then(that._getNextDataPage.bind(that, sPath, oListParams, oModel, iSkip, sToastText));
						}
						
						return oPromise;
					})
					.then(resolve)
					.catch(reject);
			});
		},
		
		/**
		 * Get next data page
		 * @param {string} sPath URI to call
		 * @param {object} oListParams params for data request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel oData model
		 * @param {int} iSkip items to skip
		 * @param {string} sToastText a text to show in message toast
		 * @param {object[]} aItems already collected items
		 * @returns {object[]} new items list
		 * @function
		 * @private
		 */
		_getNextDataPage: function(sPath, oListParams, oModel, iSkip, sToastText, aItems) {
			var oCurrentListParams = Util.merge({}, oListParams, {
				urlParameters: {
					$skip: iSkip
				}
			});
			
			Util.showToast(sToastText);
			return Util.promiseRead(sPath, oCurrentListParams, oModel)
				.then(function (oData) {
					return aItems.concat(oData.results || []);
				});
		},
		
		/**
		 * Get export object page-by-page
		 * @param {int} iPageSize page size
		 * @param {boolean} bWithoutContext get path without context
		 * @returns {Promise} promise with export
		 * @function
		 * @public
		 */
		getExportPageByPage: function (iPageSize, bWithoutContext) {
			var oBinding = this.getBinding("items"),
				oBindingInfo = this.getBindingInfo("items"),
				oModel = oBinding.getModel(),
				sBindingPath = (bWithoutContext) ? oBinding.getPath() : this._getFullBindingPath(oBinding),
				sModelName = oBindingInfo.model,
				aAppFilters = oBinding.aApplicationFilters,
				aFilters = (aAppFilters && aAppFilters.length > 0 && oBinding.aFilters > 0) ?
					[
						new sap.ui.model.Filter({
							filters:[
								new sap.ui.model.Filter({filters: oBinding.aFilters}),
								new sap.ui.model.Filter({filters: aAppFilters})
							],
							and: true
						})
					] : oBinding.aFilters.concat(aAppFilters),
				oSorter = oBinding.aSorters,
				oExport = this._getRawExport(oBindingInfo, sBindingPath);

			oExport.setModel(this.getModel("i18n"), "i18n");
			
			
			var oCountParams = {
				filters: aFilters,
				sorters: oSorter
			}, oListParams = {
				filters: aFilters,
				sorters: oSorter,
				urlParameters: {
					$top: iPageSize
				}
			};
			
			return this._gatherDataPageByPage(sBindingPath, oListParams, oCountParams, oModel, iPageSize)
				.then(function (aList) {
					var oTempModel = new JSONModel({});
					oTempModel.setProperty(sBindingPath, aList);
					oExport.setModel(oTempModel, sModelName);
					return oExport;
				});
		},
		
		/**
		 * Save the table to file
		 * @param {string} sFileName forced file name, if undefined then saveFileName property will be used
		 * @function
		 * @public
		 */
		saveToFile: function(sFileName, bWithoutContext) {
			var sName = sFileName || this.getSaveFileName();
			this.getExport(bWithoutContext).saveFile(sName);
		}
	});
});
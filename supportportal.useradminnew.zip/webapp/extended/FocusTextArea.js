sap.ui.define([
	"sap/m/TextArea"
], function (TextArea) {
	"use strict";
	
	/**
	 * A text area with event on focus
	 * @class
	 * @extends sap.m.TextArea
	 * @alias sap.support.useradministration.extended.FocusTextArea
	 */
	return TextArea.extend("sap.support.useradministration.extended.FocusTextArea", {
		metadata: {
			events: {
				focusIn: {},
				focusOut: {}
			}
		},
		
		renderer: {},
		
		/**
		 * Handle focus in then fire correspoding event
		 * @function
		 * @public
		 * @override
		 */
		onfocusin: function () {
			TextArea.prototype.onfocusin.apply(this, arguments);
			this.fireFocusIn();
		},
		
		/**
		 * Handle focus out then fire correspoding event
		 * @function
		 * @public
		 * @override
		 */
		onfocusout: function () {
			TextArea.prototype.onfocusout.apply(this, arguments);
			this.fireFocusOut();
		}
	});
});
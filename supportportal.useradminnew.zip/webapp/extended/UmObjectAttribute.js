sap.ui.define([
	"sap/m/ObjectAttribute"
], function (ObjectAttribute) {
	"use strict";
	
	/**
	 * A ObjectAttribute with event onmouseover
	 * @class
	 * @extends sap.m.ObjectAttribute
	 * @alias sap.support.useradministration.extended.UmObjectAttribute
	 */
	return ObjectAttribute.extend("sap.support.useradministration.extended.UmObjectAttribute", {
			metadata: {
			events: {
				onMouseOver: {},
				onMouseOut: {}
			}
		},
		
		renderer: {},
		
		/**
		 * Handle mouseover then fire correspoding event
		 * @function
		 * @public
		 * @override
		 */
		onmouseover: function () {
			this.fireOnMouseOver();
		},
		
		/**
		 * Handle mouseout then fire correspoding event
		 * @function
		 * @public
		 * @override
		 */
		onmouseout: function () {
			this.fireOnMouseOut();
		}
		
	
	});
});
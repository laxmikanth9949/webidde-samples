sap.ui.define([
	"sap/m/Select",
	"sap/m/SelectRenderer"
], function(Select, SelectRenderer) {
	/**
	 * Toolbar with predefined background colors
	 * @class
	 * @augments sap.m.Toolbar
	 */
	return Select.extend("sap.support.userprofile.extended.SelectWithLink", {
		metadata: {
			aggregations: {
				formattedValueStateText: {type : "sap.m.FormattedText", multiple: false}
			}
		},

		
		renderer: {},
		
		
		getFormattedValueStateText: function() {
			return this.getAggregation("formattedValueStateText");                         
		},
		
		_updatePickerValueStateContentText: function() {
			var oPicker = this.getPicker(),
				oPickerValueStateContent = oPicker && oPicker.getContent()[0].getFixContent();

			if (oPickerValueStateContent && this.getFormattedValueStateText()) {
				oPicker.getContent()[0].setFixContent(this.getFormattedValueStateText().addStyleClass(this.getRenderer().CSS_CLASS + "PickerValueState"));
			}
		},
		_updatePickerValueStateContentStyles: function() {
			var CSS_CLASS =  this.getRenderer().CSS_CLASS,
				PICKER_CSS_CLASS = CSS_CLASS + "Picker",
				sCssClass = PICKER_CSS_CLASS + "InformationState",
				sPickerWithSubHeader = PICKER_CSS_CLASS + "WithSubHeader",
				oPicker = this.getPicker(),
				oCustomHeader = oPicker && oPicker.getContent()[0].getFixContent();

			if (oCustomHeader) {
				this._removeValueStateClassesForPickerValueStateContent(oPicker);
				oCustomHeader.addStyleClass(sCssClass);
				oPicker.addStyleClass(sPickerWithSubHeader);
				oPicker.addStyleClass("upSelectList");
			}
		},
		
		getValueStateMessage: function(){}
	});
});
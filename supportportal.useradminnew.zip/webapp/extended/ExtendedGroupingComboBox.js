/* eslint-disable complexity */
sap.ui.define([
    "sap/m/ComboBox",
	"sap/support/useradministration/model/Constant"
], function(ComboBox,
	Constant) {
	
	return ComboBox.extend("sap/support/useradministration/extended/ExtendedGroupingComboBox", {
		metadata: {
            properties: {
                groupNamePattern: {
                    bindable: false,
                    type: "string",
                    defaultValue: "G_",
                    group: "Behavior"
                }
            }  
        },
        renderer: {},
		
		// onAfterRenderingList: function() {
		// 	var aItems = this._getList().getItems();
		// 	aItems.forEach(function (item, i) {
		// 		if(this.getItemAt(i).getKey().indexOf("G_") !== -1) {
		// 			item.getDomRef().classList.add("authObjectListAllItem");
		// 			item.getDomRef().classList.remove("sapMLIBTypeActive");
		// 			item.getDomRef().classList.remove("sapMLIBActionable");
		// 			item.getDomRef().classList.remove("sapMLIBHoverable");
		// 			item.getDomRef().classList.remove("sapMLIBFocusable");
		// 			// item.detachAllEventHandlers("press");
		// 		}
		// 	}.bind(this));
		// }, 
		
		/**
		 * Maps an item type of sap.ui.core.Item to an item type of sap.m.StandardListItem.
		 *
		 * @param {sap.ui.core.Item} oItem The item to be matched
		 * @returns {sap.m.StandardListItem | null} The matched StandardListItem
		 * @override
		 * @private
		 */
		_mapItemToListItem: function(oItem) {
			var oListItem, sListItem, sListItemSelected, sAdditionalText, sGroupNamePattern;
			var oRenderer = this.getRenderer();

			if (!oItem) {
				return null;
			}
            
			// UIDX-901 Disabling items 
			var sItemType = oItem.data("level");
			
			sAdditionalText = (oItem.getAdditionalText && this.getShowSecondaryValues()) ? oItem.getAdditionalText() : "";

			sListItem = oRenderer.CSS_CLASS_COMBOBOXBASE + "Item";
			sListItemSelected = (this.isItemSelected(oItem)) ? sListItem + "Selected" : "";

			sGroupNamePattern = this.getProperty("groupNamePattern") || "";
            
			if (oItem.isA("sap.ui.core.SeparatorItem") || oItem.getKey().indexOf(sGroupNamePattern) !== -1) {
				oListItem = this._mapSeparatorItemToGroupHeader(oItem, oRenderer);
			} else {
				if(sItemType === Constant.ComboboxItemType.DISABLED_WITH_MARK || sItemType === Constant.ComboboxItemType.ENABLED_WITH_MARK
				|| sItemType === Constant.ComboboxItemType.DISABLED_PENDING 
				){
					var sType = (sItemType === Constant.ComboboxItemType.ENABLED_WITH_MARK) ?  sap.m.ListType.Active : sap.m.ListType.Inactive;
					var sIconSrc = (sItemType === Constant.ComboboxItemType.DISABLED_PENDING) ?  "sap-icon://future" : "sap-icon://accept";
					var sColor = (sItemType === Constant.ComboboxItemType.ENABLED_WITH_MARK) ?  "black" : "lightgray";
					oListItem = new sap.m.CustomListItem({
						type: sType
					}).addContent(new sap.m.HBox()
					.addItem(new sap.ui.core.Icon({
                        src: sIconSrc,
						color: sColor
					}).addStyleClass("sapUiSmallMarginBegin sapUiSmallMarginTopBottom"))
					 .addItem(new sap.m.Text({
                        text: oItem.getText()
					}).addStyleClass("sapUiSmallMarginBegin sapUiSmallMarginTopBottom")));
					if(sItemType !== Constant.ComboboxItemType.ENABLED_WITH_MARK){
						oListItem.addStyleClass("disabledComboBoxItem");	
					}

					// Avoid error for standard call of getTitle() method, replace it with getText() for CustomListItem
					oListItem.getTitle = function(){
						return oItem.getText();
					};	
					oListItem.getText = function(){
						return oItem.getText();
					};			
				} else {
					oListItem = new sap.m.StandardListItem({
						type: sap.m.ListType.Active,
						info: sAdditionalText,
						visible: true
					}).addStyleClass(sListItem + " " + sListItemSelected);
					oListItem.setTitle(oItem.getText());
					if(sItemType === Constant.ComboboxItemType.DISABLED){
						oListItem.addStyleClass("disabledComboBoxItem");
						oListItem.setType(sap.m.ListType.Inactive);
					}
				}				
			}
			// 

			this.setSelectable(oItem, oItem.getEnabled());

			oListItem.setTooltip(oItem.getTooltip());
			oItem.data(oRenderer.CSS_CLASS_COMBOBOXBASE + "ListItem", oListItem);

			oItem.getCustomData().forEach(function(oCustomData){
				oListItem.addCustomData(oCustomData.clone());
			});

			this._oItemObserver.observe(oItem, {properties: ["text", "additionalText", "enabled", "tooltip"]});

			return oListItem;
		},

		/**
		 * Interrupt selection flow in case of Inactive item
		 * @function
		 * @param {sap.ui.base.Event} oControlEvent The control event
		 * @private
		 * @override
		 */
		onSelectionChange: function(oControlEvent) {
		    // UIDX-901 Interrupt selection flow in case of Inactive item
			if(oControlEvent.getParameter("listItem").getType() === sap.m.ListType.Inactive){
				return;
			}
			// 
			ComboBox.prototype.onSelectionChange.apply(this, arguments);
		},

		/**
		 * Interrupt input selection flow in case of Inactive item
		 *
		 * @param {sap.ui.core.Item | null} vItem The selected item
		 * @private
		 * @override
		 */
		setSelection: function(vItem) {
		    // UIDX-901 Interrupt selection flow in case of Inactive item
			if(this.getListItem(vItem) && this.getListItem(vItem).getType() !== sap.m.ListType.Active){
				return;
			}

			ComboBox.prototype.setSelection.apply(this, arguments);
		}
	});
});
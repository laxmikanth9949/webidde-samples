sap.ui.define([
    "sap/m/CustomListItem",
    "sap/m/CustomListItemRenderer"
], function(CustomListItem, CustomListItemRenderer) {
    var ExtendedCustomListItemLevel = {
        None: "None",
        Group: "Group",
        Top: "Top"
    };
    
    jQuery.sap.declare("sap.support.useradministration.extended.ExtendedCustomListItemLevel");
    sap.support.useradministration.extended.ExtendedCustomListItemLevel = ExtendedCustomListItemLevel;
    
    /**
     * Extended custom list item
     * Added level property to render in another way
     * @class
     * @extends {sap.m.CustomListItem}
     * @public
     * @alias sap.support.useradministration.extended.ExtendedCustomListItem
     */
    return CustomListItem.extend("sap/support/useradministration/extended/ExtendedCustomListItem", {
        metadata: {
            properties: {
                level: {
                    bindable: true,
                    type: "sap.support.useradministration.extended.ExtendedCustomListItemLevel",
                    defaultValue: ExtendedCustomListItemLevel.None,
                    group: "Behavior"
                }
            }  
        },
        renderer: {
            /**
             * Add style classes for Group or Top level
             * @param {sap.ui.core.RenderManager} oRm render manager
             * @param {sap.support.useradministration.extended.ExtendedCustomListItem} oControl rendered control
             * @function
             * @public
             * @override
             */
            renderLIAttributes: function(oRm, oControl) {
                var sLevel = oControl.getLevel();
                CustomListItemRenderer.renderLIAttributes.apply(this, arguments);
                if (sLevel === ExtendedCustomListItemLevel.Top) {
                    oRm.addClass("authObjectListAllItem");
                } else if (sLevel === ExtendedCustomListItemLevel.Group) {
                    oRm.addClass("authObjectListItem");
                }
        	}
        }
    });
});
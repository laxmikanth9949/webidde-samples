sap.ui.define([
	"sap/m/FormattedText"
], function(FormattedText) {
	"use strict";

	return FormattedText.extend("sap.support.userprofile.extended.FormattedTextWithLinks", {
		metadata: {
			properties: {},
			aggregations: {
				controls: {
					type: "sap.m.Link",
					multiple: true,
					singularName: "control"
				}
			}
		},
		renderer: function (oRm, oControl) {
			var sText = oControl._getDisplayHtml(),
				aControls = oControl.getAggregation("controls"),
				sNewText = "";
				
			function _placeholderReplacer (match, index, pos) {
				var iMatchLen = match.length;
				
				oRm.writeEscaped(sText.substr(0, pos));
				
				if (aControls[index] !== undefined) {
					oRm.renderControl(aControls[index]);
				} else {
					oRm.write(match);
				}
				sText = sText.substr(pos + iMatchLen);
			}
	
			oRm.write("<div"); //open div
			oRm.writeControlData(oControl);
			oRm.addClass("sapMFT");
			oRm.writeClasses();
			// render Tooltip
			if (oControl.getTooltip_AsString()) {
				oRm.writeAttributeEscaped("title", oControl.getTooltip_AsString());
			}
			oRm.addStyle("width", oControl.getWidth() || null);
			oRm.addStyle("height", oControl.getHeight() || null);
			oRm.writeStyles();
			oRm.write(">"); // open close div
	
			while (sText !== "" && sText !== sNewText) {
				sNewText = sText.replace(/(?:\%\%(\d+))/, _placeholderReplacer);
			}
			if (sText !== "") {
				oRm.writeEscaped(sText);
			}

			oRm.write("</div>"); //close div
			
			

	
		}
	});
});
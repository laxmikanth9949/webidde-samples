jQuery.sap.declare("sap.support.useradministration.extended.UsersReportFilterBar");
jQuery.sap.require("sap.ui.comp.filterbar.FilterBar");
jQuery.sap.require("sap.support.useradministration.extended.UsersReportSmartVariantManagement");
jQuery.sap.require("sap.ui.layout.GridRenderer");

sap.ui.comp.filterbar.FilterBar.extend("sap.support.useradministration.extended.UsersReportFilterBar", {

		metadata : {
			library : "sap.support.useradministration.extended",
			properties : {
				showNotificationFB: { type: "boolean", defaultValue: true },
				notificationLabelFB: { type: "string", defaultValue: "Notification" }
			}
		},
		
	renderer: sap.ui.layout.GridRenderer.render,
	
	_initializeVariantManagement: function() {
		var oPersInfo = new sap.ui.comp.smartvariants.PersonalizableInfo({
			type: "filterBar",
			keyName: "persistencyKey"
		});
		//oPersInfo.addControl(this);
		oPersInfo.setControl(this);

		this._oSmartVM.addPersonalizableControl(oPersInfo);
		sap.ui.comp.filterbar.FilterBar.prototype._initializeVariantManagement.apply(this, arguments);
	},

	_applyVariant: function(oVariant, sContext) {

		if (oVariant && oVariant.version === "V2") {
			oVariant = this.mergeVariant(this._getStandardVariant(), oVariant, sContext);
		}

		sap.ui.comp.filterbar.FilterBar.prototype._applyVariant.apply(this, arguments);
	},

	_createVariantManagement: function() {
//		this._oSmartVM = new sap.support.useradministration.extended.UsersReportSmartVariantManagement({
//			showExecuteOnSelection: true,
//			showNotification:  this.getShowNotificationFB(),
//			notificationLabel: this.getNotificationLabelFB(),
//			showShare: false,
//			initialise: [function() {
//				var sVariantID = this.getCurrentVariantId();
//				if (!sVariantID || sVariantID.length === 0) {
//					this.fireStandardVariant();
//				}
//			}, this]
//		});
		this._oSmartVM = new sap.ui.comp.smartvariants.SmartVariantManagement();
		//this._oSmartVM.setShowExecuteOnSelection(true);
		return this._oSmartVM;
	},

	init: function() {
		sap.ui.comp.filterbar.FilterBar.prototype.init.apply(this, arguments);

		this.setPersistencyKey("sap.support.useradministration");
		this._initializeVariantManagement();
	},

	getCurrentVariantId: function() {
		return this._oSmartVM.getCurrentVariantId();
	},

	setCurrentVariantId: function(sVariantKey, bDoNotApplyVariant) {
		return this._oSmartVM.setCurrentVariantId(sVariantKey, bDoNotApplyVariant);
	}

});
sap.ui.define([
    "sap/m/MultiComboBox",
    "sap/m/Tokenizer"//,
    //"sap/m/MultiComboBoxRenderer"
], function(MultiComboBox, Tokenizer/*, MultiComboBoxRenderer*/) {
	
	return MultiComboBox.extend("sap/support/useradministration/extended/ExtendedGroupingMultiComboBox", {
		metadata: {
            properties: {
                groupNamePattern: {
                    bindable: false,
                    type: "string",
                    defaultValue: "G_",
                    group: "Behavior"
                }
            }  
        },
        renderer: {},
        
        /**
		 * Map an item type of sap.ui.core.Item to an item type of sap.m.StandardListItem.
		 *
		 * @param {sap.ui.core.Item} oItem The item to be matched
		 * @returns {sap.m.StandardListItem | null} The matched StandardListItem
		 * @private
		 */
		_mapItemToListItem: function(oItem) {
			var oListItem, sListItem, sListItemSelected, sAdditionalText, sGroupNamePattern;
			var oRenderer = this.getRenderer();
	
			if (!oItem) {
				return null;
			}
			sAdditionalText = (oItem.getAdditionalText && this.getShowSecondaryValues()) ? oItem.getAdditionalText() : "";
	
			if (oItem.isA("sap.ui.core.SeparatorItem")) {
				oListItem = this._mapSeparatorItemToGroupHeader(oItem);
				oItem.data(oRenderer.CSS_CLASS_COMBOBOXBASE + "ListItem", oListItem);
				oListItem.addStyleClass(oRenderer.CSS_CLASS_MULTICOMBOBOX + "NonInteractiveItem");
				this._decorateListItem(oListItem);
	
				return oListItem;
			}
			
			sGroupNamePattern = this.getProperty("groupNamePattern") || "";
	
			sListItem = oRenderer.CSS_CLASS_MULTICOMBOBOX + "Item";
			sListItemSelected = (this.isItemSelected(oItem)) ? sListItem + "Selected" : "";
	
			oListItem = new sap.m.StandardListItem({
				type: sap.m.ListType.Active,
				info: sAdditionalText,
				visible: oItem.getEnabled()
			}).addStyleClass(sListItem + " " + sListItemSelected);
			
			if (oItem.getKey() === sGroupNamePattern + "ALL") {
				oListItem.addStyleClass("authObjectListAllItem");
			} else if (oItem.getKey().indexOf(sGroupNamePattern) !== -1) {
				oListItem.addStyleClass("authObjectListItem");
			}
	
			oListItem.setTooltip(oItem.getTooltip());
	
			oItem.data(oRenderer.CSS_CLASS_COMBOBOXBASE + "ListItem", oListItem);
			oListItem.setTitle(oItem.getText());
	
			if (sListItemSelected) {
				var oToken = new sap.m.Token({
					key: oItem.getKey()
				});
				oToken.setText(oItem.getText());
				oToken.setTooltip(oItem.getText());
	
				oItem.data(oRenderer.CSS_CLASS_COMBOBOXBASE + "Token", oToken);
				this._oTokenizer.addToken(oToken, true);
			}
	
			this.setSelectable(oItem, oItem.getEnabled());
			this._decorateListItem(oListItem);
			return oListItem;
		},
		
		_checkGroupSelection: function(oListItem, iItemIndex, bIsSelected) {
			var aListItems = this.getList().getItems();
			var sGroupNamePattern = this.getProperty("groupNamePattern") || "";
			var i;
			var iStartIndex, iEndIndex;
			
			for (i = iItemIndex - 1; i > 0; i--) {
				if (this._getItemByListItem(aListItems[i]).getKey().indexOf(sGroupNamePattern) !== -1) {
					iStartIndex = i;
					break;
				}
			}
			for (i = iItemIndex + 1; i < aListItems.length; i++) {
				if (this._getItemByListItem(aListItems[i]).getKey().indexOf(sGroupNamePattern) !== -1) {
					iEndIndex = i;
					break;
				}
			}
			
			var isSelect = bIsSelected && aListItems.slice(iStartIndex + 1, iEndIndex).every(function (item) {
				return item.getSelected() === bIsSelected;
			});
			var isUnselect = !bIsSelected && aListItems.slice(iStartIndex + 1, iEndIndex).some(function (item) {
				return item.getSelected() === bIsSelected;
			});
			
			if (isSelect || isUnselect) {
				this.getList().setSelectedItem(aListItems[iStartIndex], bIsSelected);
				this._checkAllSelection(bIsSelected);
			}
			
		},
		
		_checkAllSelection: function(bIsSelected) {
			var aListItems = this.getList().getItems();
			var sGroupNamePattern = this.getProperty("groupNamePattern") || "";
			
			var aListGroups = aListItems.slice(1).filter(function(item) {
				return this._getItemByListItem(item).getKey().indexOf(sGroupNamePattern) !== -1;
			}.bind(this));
			
			var isSelect = bIsSelected && aListGroups.every(function(group) {
				return group.getSelected() === bIsSelected;
			});
			var isUnselect = !bIsSelected && aListGroups.some(function(group) {
				return group.getSelected() === bIsSelected;
			});
			
			if (isSelect || isUnselect) {
				this.getList().setSelectedItem(aListItems[0], bIsSelected);
			}
		},
		
		/**
		 * Handle the selection change event on the List.
		 *
		 * @param {sap.ui.base.Event} oEvent The event object
		 * @private
		 */
		_handleSelectionLiveChange: function(oEvent) {
			var oListItem = oEvent.getParameter("listItem");
			var bIsSelected = oEvent.getParameter("selected");
			var oNewSelectedItem = this._getItemByListItem(oListItem);
			var oInputControl = this.isPickerDialog() ? this.getPickerTextField() : this;

			var aListItems = this.getList().getItems();
			var sNewSelectedItemKey = oNewSelectedItem.getKey();
			var sGroupNamePattern = this.getProperty("groupNamePattern") || "";
			var iStartIndex = aListItems.indexOf(oListItem), iEndIndex = iStartIndex + 1;
			
			var bCheckGroupSelection = true, bCheckAllSelection = false;
	
			if (oListItem.getType() === "Inactive") {
				return;
			}
	
			if (!oNewSelectedItem) {
				return;
			}
			
			if (sNewSelectedItemKey === sGroupNamePattern + "ALL") {
				iStartIndex = 0;
				iEndIndex = aListItems.length;
				bCheckGroupSelection = false;
			} else if (sNewSelectedItemKey.indexOf(sGroupNamePattern) !== -1) {
				for (var i = iStartIndex + 1; i < aListItems.length; i++) {
					if (this._getItemByListItem(aListItems[i]).getKey().indexOf(sGroupNamePattern) !== -1) {
						iEndIndex = i;
						bCheckGroupSelection = false;
						bCheckAllSelection = true;
						break;
					}
				}
			}
			
			var changeSelection = (bIsSelected) ? this.setSelection.bind(this) : this.removeSelection.bind(this);
			
			for (i = iStartIndex; i < iEndIndex; i++) {
				var item = this._getItemByListItem(aListItems[i]);
				var oParam = {
					item: item,
					id: item.getId(),
					key: item.getKey(),
					fireChangeEvent: true,
					suppressInvalidate: true,
					listItemUpdated: true
				};
				// update the selected item
				if (item.getKey().indexOf(sGroupNamePattern) === -1) {
					this.fireChangeEvent(item.getText());
					changeSelection(oParam);
				}
				this.getList().setSelectedItem(aListItems[i], bIsSelected);
			}
			
			if (bCheckGroupSelection) {
				this._checkGroupSelection(oListItem, iStartIndex, bIsSelected);
			} else if (bCheckAllSelection) {
				this._checkAllSelection(bIsSelected);
			}
	
			if (this._bCheckBoxClicked) {
				oInputControl.setValue(this._sOldInput);
	
				if (this.isOpen() && this.getPicker().oPopup.getOpenState() !== sap.ui.core.OpenState.CLOSING) {
					// workaround: this is needed because the List fires the "selectionChange" event during the popover is closing.
					// So clicking on list item description the focus should be replaced to input field. Otherwise the focus is set to
					// oListItem.
	
					// Scrolls an item into the visual viewport
					oListItem.focus();
				}
			} else {
				this._bCheckBoxClicked = true;
				this.setValue("");
				this.close();
			}
		},
		
		_handleTokenChange: function(oEvent) {
			var sType = oEvent.getParameter("type");
			var oToken = oEvent.getParameter("token");
			var oItem = null;
	
			if (sType !== Tokenizer.TokenChangeType.Removed && sType !== Tokenizer.TokenChangeType.Added) {
				return;
			}
	
			if (sType === Tokenizer.TokenChangeType.Removed) {
	
				oItem = (oToken && this._getItemByToken(oToken));
	
				if (oItem && this.isItemSelected(oItem)) {
	
					this.removeSelection({
						item: oItem,
						id: oItem.getId(),
						key: oItem.getKey(),
						tokenUpdated: true,
						fireChangeEvent: true,
						fireFinishEvent: true, // Fire selectionFinish if token is deleted directly in input field
						suppressInvalidate: true
					});
					
					var oListItem = this.getList().getItems().filter(function (item){
							return this._getItemByListItem(item) === oItem;
						}.bind(this))[0];
					
					this._checkGroupSelection(oListItem, this.getList().getItems().indexOf(oListItem) , false);
	
					if(!this.isPickerDialog() && !this.isFocusInTokenizer()) {
						this.focus();
					}
					this.fireChangeEvent("");
				}
			}
		}
	});
});
sap.ui.define([
	"sap/m/ViewSettingsItem"
], function (ViewSettingsItem) {

	/**
	 * View settings item with adjusted behavior
	 * @class
	 * @extends sap.m.ViewSettingsFilterItem
	 * @alias sap.support.useradministration.extended.ViewSettingsFilterItemIcon
	 */
	return ViewSettingsItem.extend("sap.support.useradministration.extended.ViewSettingsFilterItemIcon", {
		metadata: {},
        renderer: {}
	});
});
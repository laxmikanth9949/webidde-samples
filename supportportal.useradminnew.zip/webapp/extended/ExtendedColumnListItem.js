sap.ui.define([
    "sap/m/ColumnListItem",
    "sap/m/ColumnListItemRenderer"
], function(ColumnListItem, ColumnListItemRenderer) {
    var ExtendedColumnListItemLevel = {
        None: "None",
        Group: "Group",
        Top: "Top"
    };
    
    jQuery.sap.declare("sap.support.useradministration.extended.ExtendedColumnListItemLevel");
    sap.support.useradministration.extended.ExtendedColumnListItemLevel = ExtendedColumnListItemLevel;
    
    /**
     * Extended column list item
     * Added level property to render in another way
     * @class
     * @extends {sap.m.ColumnListItem}
     * @public
     * @alias sap.support.useradministration.extended.ExtendedColumnListItem
     */
    return ColumnListItem.extend("sap/support/useradministration/extended/ExtendedColumnListItem", {
        metadata: {
            properties: {
                level: {
                    bindable: true,
                    type: "sap.support.useradministration.extended.ExtendedColumnListItemLevel",
                    defaultValue: ExtendedColumnListItemLevel.None,
                    group: "Behavior"
                }
            }  
        },
        renderer: {
            /**
             * Add style classes for Group or Top level
             * @param {sap.ui.core.RenderManager} oRm render manager
             * @param {sap.support.useradministration.extended.ExtendedColumnListItem} oControl rendered control
             * @function
             * @public
             * @override
             */
            renderLIAttributes: function(oRm, oControl) {
                var sLevel = oControl.getLevel();
                ColumnListItemRenderer.renderLIAttributes.apply(this, arguments);
                if (sLevel === ExtendedColumnListItemLevel.Top) {
                    oRm.addClass("authObjectListAllItem");
                } else if (sLevel === ExtendedColumnListItemLevel.Group) {
                    oRm.addClass("authObjectListItem");
                }
        	}
        }
    });
});
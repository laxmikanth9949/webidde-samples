sap.ui.define([
    "sap/m/ColumnListItem",
    "sap/m/ColumnListItemRenderer"
], function(ColumnListItem, ColumnListItemRenderer) {
    /**
     * Extended column list item
     * Added level property to render in another way
     * @class
     * @extends {sap.m.ColumnListItem}
     * @public
     * @alias sap.support.useradministration.extended.ExtendedColumnListItem
     */
    return ColumnListItem.extend("sap/support/useradministration/extended/BlockedColumnListItem", {
        metadata: {
            properties: {
                block: {
                    bindable: true,
                    type: "boolean",
                    defaultValue: false,
                    group: "Behavior"
                }
            }  
        },
        renderer: {
            /**
             * Add style classes for Group or Top level
             * @param {sap.ui.core.RenderManager} oRm render manager
             * @param {sap.support.useradministration.extended.ExtendedColumnListItem} oControl rendered control
             * @function
             * @public
             * @override
             */
            renderLIAttributes: function(oRm, oControl) {
                var isBlock = oControl.getBlock();
                ColumnListItemRenderer.renderLIAttributes.apply(this, arguments);
                if (isBlock) {
                    oRm.addClass("umBlockedColumnListItem");
                }
        	}
        }
    });
});
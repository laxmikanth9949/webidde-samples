sap.ui.define([
    "sap/m/HBox"
], function (HBox) {
    
    /**
     * A HBox with key property for applying view settings properly
     * @class
     * @extends sap.m.HBox
     * @alias sap.support.useradministration.extended.HBox
     */
    return HBox.extend("sap.support.useradministration.extended.TextHBox", {
        metadata: {
            properties: {
                text: {
                	bindable: true,
                    type: "string",
                    defaultValue: ""
                }
            }
        },
        renderer: {}
    });
});
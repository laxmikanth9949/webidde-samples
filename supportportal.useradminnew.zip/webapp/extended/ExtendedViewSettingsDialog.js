sap.ui.define([
	"sap/m/ViewSettingsDialog",
	"sap/m/CustomListItem",
	"sap/m/ListType",
	"sap/ui/base/ManagedObject"
], function (ViewSettingsDialog, CustomListItem, ListType, ManagedObject) {
	
	/**
	 * View settings dialog with adjusted behavior
	 * @class
	 * @extends sap.m.ViewSettingsDialog
	 * @alias sap.support.useradministration.extended.ExtendedViewSettingsDialog
	 */
	return ViewSettingsDialog.extend("sap.support.useradministration.extended.ExtendedViewSettingsDialog", {
		metadata: {},
		renderer: {},
		
		/**
		 * Create "Select All" checkbox with adjusted text
		 * @returns {sap.m.Checkbox} checkbox
		 * @function
		 * @private
		 * @override
		 */
		_createSelectAllCheckbox: function () {
			var oCheckbox = ViewSettingsDialog.prototype._createSelectAllCheckbox.apply(this, arguments);
			
			if (oCheckbox) {
				oCheckbox.bindProperty("text", { 
					path: "i18n>DIALOG_FILTER_SELECT_ALL", 
					formatter: function (sString) {
						if (sString && sString.toUpperCase) {
							return sString.toUpperCase();
						}
						return "";
					}
				});
				oCheckbox.addStyleClass("umFixVSDCheckbox");
			}
			
			return oCheckbox;
		},

		_initFilterDetailItems: function(oItem){
            ViewSettingsDialog.prototype._initFilterDetailItems.apply(this, arguments);

			if (oItem.data("itemType") === 'Icon') {
				this._getPage2().removeContent(this._filterDetailList);

				var aSubFilters = oItem.getItems();

				aSubFilters.map(function(subFilter, i){
                   var oListItem = this._filterDetailList.getItems()[i];
				   if(oListItem && subFilter instanceof sap.support.useradministration.extended.ViewSettingsItemIcon
					  && subFilter.getShowIcon()) {
						this._filterDetailList.removeItem(i);
						this._filterDetailList.insertItem(new CustomListItem({		
							type : ListType.Active,
							selected : subFilter.getSelected(),
							content: [
								new sap.ui.core.Icon({
									src: subFilter.getSrc(),
									color: "Critical",
									size: "1rem",
									press: [subFilter._onIconPress, subFilter]
								}),
                                new sap.m.Text({
									text: ManagedObject.escapeSettingsValue(subFilter.getText())
								}).addStyleClass("sapUiSmallMarginBegin")
							]
						}).data("item", subFilter), i);
				   }
				}.bind(this));
				this._getPage2().addContent(this._filterDetailList);
		    }
		},

		_visibilityBySearchField: function(oItem) {
			if(oItem.getTitle){
				var sTitle = oItem.getTitle();
			} else if (oItem.getContent){
				sTitle = oItem.getContent()[1].getText();
			}
			var sQuery = this._filterSearchField.getValue(),
				fnStringFilter = this._getStringFilter(),
				bTitleSatisfiesTheQuery = fnStringFilter(sQuery, sTitle);
			return bTitleSatisfiesTheQuery;
		}
	});
});
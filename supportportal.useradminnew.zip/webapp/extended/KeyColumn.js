sap.ui.define([
    "sap/m/Column"
], function (Column) {
    
    /**
     * A column with key property for applying view settings properly
     * @class
     * @extends sap.m.Column
     * @alias sap.support.useradministration.extended.KeyColumn
     */
    return Column.extend("sap.support.useradministration.extended.KeyColumn", {
        metadata: {
            properties: {
                key: {
                    type: "string",
                    defaultValue: ""
                },
                exportable: {
                    type: "boolean",
                    defaultValue: true
                }
            }
        }
    });
});
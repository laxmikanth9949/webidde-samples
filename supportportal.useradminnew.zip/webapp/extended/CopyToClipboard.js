sap.ui.define([
    "sap/ui/core/Control"
], function (Control) {
    
	/**
	 * Control that copies data to clipboard
	 * @class
	 * @augments sap.ui.core.Control
	 */
    return Control.extend("sap.support.useradministration.extended.CopyToClipboard", {
        metadata: {},
        
        renderer: {
            render: function(oRm, oControl) {
        		oRm.write("<div");
        		oRm.writeControlData(oControl);
        		oRm.writeAttributeEscaped("style", "display: none");
		        oRm.write(">");
		        
		        oRm.write("<input");
		        oRm.writeAttributeEscaped("id", oControl.getId() + "-input");
		        oRm.write("></input>");
		        
		        oRm.write("</div>");
            }
        },
        
        /**
         * Get the document
         * @returns {Node} document
         * @function
         * @private
         */
        _getDocument: function() {
            return jQuery("document").context;  
        },
        
        /**
         * Copy given text to the clipboard
         * @param {string} sText text to copy
         * @function
         * @public
         */
        copyText: function(sText) {
            var oElement = this.$(),
                oInput = this.$("input");
                
            oElement.show();
            oInput.val(sText).select();
            this._getDocument().execCommand("copy");
            oInput.val("");
            oElement.hide();
        }
    });
});
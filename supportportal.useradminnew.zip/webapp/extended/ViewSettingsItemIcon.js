sap.ui.define([
	"sap/m/ViewSettingsItem",
	"sap/ui/core/Icon",
], function (ViewSettingsItem, Icon) {


	/**
	 * View settings item with adjusted behavior
	 * @class
	 * @extends sap.m.ViewSettingsItem
	 * @alias sap.support.useradministration.extended.ViewSettingsItemIcon
	 */
	return ViewSettingsItem.extend("sap.support.useradministration.extended.ViewSettingsItemIcon", {
		metadata: {
			properties: {
				src: { type: "string", defaultValue: "" },
				showIcon: { type: "boolean", defaultValue: false },
			},

			aggregations: {
				_icon: { type: "sap.ui.core.Icon", multiple: false, visibility: "hidden" },
				iconPopover: { type: "sap.m.Popover", multiple: false }
			}

		},

		init: function () {

			ViewSettingsItem.prototype.init.apply(this, arguments);
			this._createIcon();
			// .addEventDelegate({
			// 	onmouseover: this._onIconPopoverOpen.bind(this),
			// 	onmouseout: this._onIconPopoverClose.bind(this)
			// }));
		},

		_createIcon: function(){
			this._icon = new Icon({
				color: "Critical",
				size: "1rem",
				press: [this._onIconPress, this]
			});
		},

		setSrc: function (value) {
			this.setProperty("src", value);			
			// this.getAggregation("_icon").setSrc(value);
			this.getIcon().setSrc(value);
		},

		getSrc: function () {
			return this.getProperty("src");			
			// this.getAggregation("_icon").setSrc(value);
			// this.getIcon().setSrc(value);
		},


		getIcon: function () {
			if(!this._icon){
               this._createIcon();
			}
			// return this.getAggregation("_icon");
			return this._icon;
		},

		_onIconPress: function(oEvent){
            this.getAggregation("iconPopover").openBy(oEvent.getSource());
		},

		_onIconPopoverOpen: function (oEvent) {
			this.getAggregation("iconPopover").openBy(oEvent.srcControl);
		},

		_onIconPopoverClose: function (oEvent) {
			this.getAggregation("iconPopover").close();
		}
	});
});
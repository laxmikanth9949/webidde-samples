jQuery.sap.declare("sap.support.useradministration.extended.BackgroundStyle");
sap.support.useradministration.extended.BackgroundStyle = {
    Default: "Default",
    Gray: "Gray",
    Green: "Green",
    Orange: "Orange",
    Red: "Red"
};
sap.ui.define([
	"sap/m/Toolbar",
	"sap/m/ToolbarRenderer",
	"sap/support/useradministration/extended/BackgroundStyle"
], function(Toolbar, ToolbarRenderer, BackgroundStyle) {
	var STYLE_PREFIX = "umToolbarColor";
	
	/**
	 * Toolbar with predefined background colors
	 * @class
	 * @augments sap.m.Toolbar
	 */
	return Toolbar.extend("sap.support.useradministration.extended.ColoredToolbar", {
		metadata: {
			properties: {
				backgroundStyle: {
					type: "sap.support.useradministration.extended.BackgroundStyle",
					defaultValue: BackgroundStyle.Default
				}
			}
		},
		renderer: {
			/**
			 * Adds classes and styles to the root element of the toolbar
			 * @param {sap.ui.core.RenderManager} oRm render manager
			 * @param {sap.m.Toolbar} oToolbar toolbar control
			 * @function
			 * @public
			 * @override
			 */
			decorateRootElement: function(oRm, oToolbar) {
				ToolbarRenderer.decorateRootElement(oRm, oToolbar);
				
				var sBackgroundStyle = oToolbar.getBackgroundStyle();
				if (sBackgroundStyle !== BackgroundStyle.Default) {
					oRm.addClass(STYLE_PREFIX + sBackgroundStyle);
				}
			}
		}
	});
});
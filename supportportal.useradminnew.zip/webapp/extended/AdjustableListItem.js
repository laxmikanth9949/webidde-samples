sap.ui.define([
    "sap/m/StandardListItem",
    "sap/m/ListMode"
], function(StandardListItem, ListMode) {
    /**
     * List Item with adjustable deletable state
     * @class
     * @extends {sap.m.StandardListItem}
     * @public
     * @alias sap.support.useradministration.extended.AdjustableListItem
     */
    return StandardListItem.extend("sap/support/useradministration/extended/AdjustableListItem", {
        metadata: {
            properties: {
                deletable: {
                    type: "boolean",
                    defaultValue: true,
                    group: "Behavior"
                }
            }  
        },
        renderer: {},
        
        /**
         * Returns item mode
         * if item is not deletable, returns None instead of Delete
         * @returns {sap.m.ListMode} mode
         * @function
         * @public
         */
        getMode: function() {
            var sMode = StandardListItem.prototype.getMode.call(this);
            if (!this.getDeletable() && sMode === ListMode.Delete) {
                return ListMode.None;
            }
            return sMode;
        }
    });
});
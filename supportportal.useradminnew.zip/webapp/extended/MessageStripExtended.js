sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/MessageStrip",
	"sap/m/MessageStripRenderer"
], function(Control, MessageStrip, MessageStripRenderer) {
	"use strict";
	
	var INFO_STYLE_CLASS = "sapMMsgStripInformation",
		ERROR_STYLE_CLASS = "sapMMsgStripError",
		WARNING_STYLE_CLASS = "sapMMsgStripWarning",
		INFO_ICON = "sap-icon://message-information",
		ERROR_ICON = "sap-icon://message-error",
		WARNING_ICON = "sap-icon://message-warning",
		EXPAND_ARROW = "sap-icon://slim-arrow-down";
		
	return MessageStrip.extend("sap.support.userprofile.extended.MessageStripExtended", {
		
		metadata: {
			properties: {
				showExpandBtn: {
					type: "boolean",
					defaultValue: false
				},
				title: {
					type: "string",
					defaultValue: ""
				},
				description: {
					type: "string",
					defaultValue: ""
				},
				expand: {
					type: "boolean",
					defaultValue: false
				},
				styleClass: {
					type: "string",
					defaultValue: ""
				}
			},
			events: {
				"onTitleClick": {
					allowPreventDefault: true,
					parameters: {
						"material": {
							type: "object"
						},
						"materialDescription": {
							type: "string"
						}
					}
				},
				"onDescriptionClick": {
					allowPreventDefault: true,
				}				
			},
			
			aggregations: {
				_description: {type: "sap.m.FormattedText", multiple: false, visibility: "hidden"},
				_title: {type: "sap.m.FormattedText", multiple: false, visibility: "hidden"},
				_typeIcon: {type: "sap.ui.core.Icon", multiple: false, visibility: "hidden"},
				_expandIcon: {type: "sap.ui.core.Icon", multiple: false, visibility: "hidden"},
				formattedValueStateText: {type : "sap.m.FormattedText", multiple: false}
			}
		},
		init: function() {
			this.attachOnTitleClick(this.onTitleClick),
			this.attachOnDescriptionClick(this.onDescriptionClick);
		},
		
		onTitleClick: function(oEvent) {},
		
		_onTitleClick: function(oEvent) {
			this.fireOnTitleClick();
			// this.setExpand(!this.getExpand());
		},
		onDescriptionClick: function(oEvent) {},
		
		_onDescriptionClick: function(oEvent) {
			this.fireOnDescriptionClick();
			// this.setExpand(!this.getExpand());
		},
		renderer: function(oRm, oControl) {
			var sDescription = oControl.getDescription(),
				sTitle = "<strong>" + oControl.getTitle() + "</storng>",
				sType = oControl.getType(),
				sStyleTypeClass = "",
				sStyleClass = oControl.getStyleClass(),
				sIcon = "",
				isExpand = oControl.getExpand(),
				isShowExpandBtn = oControl.getShowExpandBtn();
				
			switch (sType) {
				case "Information": 
					sStyleTypeClass = INFO_STYLE_CLASS;
					sIcon = INFO_ICON;
					break;
				case "Error":
					sStyleTypeClass = ERROR_STYLE_CLASS;
					sIcon = ERROR_ICON;
					break;
				case "Warning":
					sStyleTypeClass = WARNING_STYLE_CLASS;
					sIcon = WARNING_ICON;
					break;	
				default:
					sStyleTypeClass = INFO_STYLE_CLASS;
					sIcon = INFO_ICON;
			}
			
			oControl.setAggregation("_typeIcon", new sap.ui.core.Icon({
				src: sIcon 
			}).addStyleClass("upPointerCursor")
			.attachBrowserEvent("click", oControl._onTitleClick.bind(oControl)));
			
			oControl.setAggregation("_expandIcon", new sap.ui.core.Icon({
				src: EXPAND_ARROW
			}).addStyleClass("upPointerCursor").addStyleClass("upExpandArrow")
			.attachBrowserEvent("click", oControl._onTitleClick.bind(oControl)));
			
			oControl.setAggregation("_title", new sap.m.FormattedText({
				htmlText: sTitle
			}).addStyleClass("upPointerCursor")
			.attachBrowserEvent("click", oControl._onTitleClick.bind(oControl)));
			
			oControl.setAggregation("_description", new sap.m.FormattedText({
				htmlText: sDescription,
				controls: [new sap.m.Link({
					text: "Show duplicates"
				}).attachBrowserEvent("click", oControl._onDescriptionClick.bind(oControl))],				
				visible: isExpand
			}).addStyleClass("sapUiSmallMarginTop")
			);

			oRm.write("<div");
			oRm.writeControlData(oControl);
			oRm.write('class="sapMMsgStrip ' + sStyleTypeClass + " " + sStyleClass + '">');
			oRm.write('<div class="sapMMsgStripIcon">');
			oRm.renderControl(oControl.getAggregation("_typeIcon"));
			oRm.write("</div>");
			oRm.write('<div class="sapMMsgStripMessage upExtendedMsgStrip">');
			oRm.renderControl(oControl.getAggregation("_title"));
			if(isShowExpandBtn) {
				oRm.renderControl(oControl.getAggregation("_expandIcon"));
			}
			oRm.renderControl(oControl.getAggregation("_description"));
			oRm.write("</div>");
			oRm.write("</div>");
		},

		getFormattedValueStateText: function() {
			return this.getAggregation("formattedValueStateText");                         
		},
		
		_updatePickerValueStateContentText: function() {
			var oPicker = this.getPicker(),
				oPickerValueStateContent = oPicker && oPicker.getContent()[0].getFixContent();

			if (oPickerValueStateContent && this.getFormattedValueStateText()) {
				oPicker.getContent()[0].setFixContent(this.getFormattedValueStateText().addStyleClass(this.getRenderer().CSS_CLASS + "PickerValueState"));
			}
		},
		_updatePickerValueStateContentStyles: function() {
			var CSS_CLASS =  this.getRenderer().CSS_CLASS,
				PICKER_CSS_CLASS = CSS_CLASS + "Picker",
				sCssClass = PICKER_CSS_CLASS + "InformationState",
				sPickerWithSubHeader = PICKER_CSS_CLASS + "WithSubHeader",
				oPicker = this.getPicker(),
				oCustomHeader = oPicker && oPicker.getContent()[0].getFixContent();

			if (oCustomHeader) {
				this._removeValueStateClassesForPickerValueStateContent(oPicker);
				oCustomHeader.addStyleClass(sCssClass);
				oPicker.addStyleClass(sPickerWithSubHeader);
			}
		},
		
		getValueStateMessage: function(){}		
	});
});

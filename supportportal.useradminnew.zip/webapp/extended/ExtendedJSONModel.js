sap.ui.define([
    "sap/ui/model/json/JSONModel"
], function(JSONModel) {
    
    /**
     * JSON Model with extensions
     * @class
     * @extends sap.ui.model.json.JSONModel
     * @alias sap.support.useradministration.extended.ExtendedJSONModel
     */
    return JSONModel.extend("sap.support.useradministration.extended.ExtendedJSONModel", {
        constructor: function() {
            JSONModel.apply(this, arguments);
        },
        
        /**
         * Return promise that resolves after model loaded
         * @returns {Promise} promise
         * @function
         * @public
         */
        getDataAsync: function() {
            var oPromise = this.pSequentialImportCompleted || Promise.resolve(),
                that = this;
            return oPromise.then(function() {
                return that.getData(); 
            });
        }
    });
});
sap.ui.define([
], function() {
    "use strict";
    
    /**
     * Create an error JSON with given message
     * @param {string} sMessage message
     * @returns {strng} error JSON
     * @function
     * @private
     */
    var _fnCreateErrorJSON = function (sMessage){
        return JSON.stringify({
            error: {
                message: {
                    value: sMessage
                }
            }  
        });
    };
    
    /**
     * Simulate Check selection behaviour
     * @param {function} fnResponse original handler
     * @returns {function} request handler
     * @function
     * @public
     */
    var fnCheckSelectionWrapper = function (fnResponse) {
        return function (/*oXhr, sURI, sParams*/) {
            // var oTypeCheck = /Type%20eq%20%27(.)%27/.exec(sParams),
            //     sType = oTypeCheck && oTypeCheck[1];
                
            // if (sType === "C") {
                
            // }
            return fnResponse.apply(this, arguments);
        };
    };
    
    /**
     * Simulate Insufficient Authorizations error message in User's Authorization page
     * @returns {function} request handler
     * @function
     * @public
     */
    var fnInsufficientAuthWrapper = function() {
        return function (oXhr) {
            oXhr.respond(501, {}, _fnCreateErrorJSON("User does not have the sufficient authorizations."));
            return true;
        };
    };
    
    /**
     * Simulate Gateway Timeout error in Reports and Updates page
     * @param {function} fnResponse original handler
     * @returns {function} request handler
     * @function
     * @public
     */
    var fnUserAuthReportWrapper = function (fnResponse) {
        return function (oXhr, sURI, sParams) {
            // Precision - Exactly one selected value simulates Gateway timeout error
            if (/\$filter=Tmpzl%20eq%20%27X%27$/.test(sParams)) {
                oXhr.respond(504, {}, _fnCreateErrorJSON("Simulated Error"));
            } else if (/\$filter=AuthObject%20eq%20%27None%27/.test(sParams)) {
                oXhr.respond(400, {}, "<html><head><title>Bad Request</title><body><h1>Bad Request</h1>Error<p>Error!</p></body></html>");
            } else {
                return fnResponse.apply(this, arguments);
            }
            return true;
        };
    };
    
    return {
        useradminsrv: {
            GET: {
                "/(UserAuthReportSet)\\/?(\\?(.*))?/": fnUserAuthReportWrapper,
                "/(UserAuthReportSet)\\/\\$count\\/?(.*)?/": fnUserAuthReportWrapper
            },
            MERGE: {
                "/(AuthObjectLevelSet)\\(([^\\/\\?#]+)\\)\\/?(.*)?/": fnInsufficientAuthWrapper
            }
        },
        toolservicesrv: {
            GET: {
                "/(Check_selectionSet)\\/?(\\?(.*))?/": fnCheckSelectionWrapper,
                "/(Check_selectionSet)\\(([^\\/\\?#]+)\\)\\/?(\\?(.*))?/": fnCheckSelectionWrapper
            }
        }
    };
});
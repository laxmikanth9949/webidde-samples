sap.ui.define([
	"sap/ui/core/util/MockServer",
	"sap/support/useradministration/localService/Wrappers",

	"sap/support/useradministration/localService/services/account/mockRequests"
], function (MockServer, Wrappers) {
	"use strict";
	var log = jQuery.sap.log.getLogger("MOCKSERVER", jQuery.sap.log.Level.INFO),
		oServers = {},
		oJsonServices = {};
	Array.prototype.slice.call(arguments, 2).forEach(function (oService) {
		oJsonServices[oService.name] = oService.requests;
	});

	/**
	 * Wrap requests to watch for called URI
	 * @param {object[]} aRequests requests
	 * @returns {object[]} requests
	 * @function
	 * @private
	 */
	function _wrapRequests(aRequests) {
		var oCons = console;
		aRequests.forEach(function (oRequest) {
			var fnResponse = oRequest.response;
			oRequest.response = function (oXhr) {
				var sUrl = oXhr.url || "",
					bBatch = /\$batch/.test(sUrl);

				log.info(oXhr.method + "\t" + unescape(sUrl) + "\n");
				if (!bBatch && !/GET/i.test(oXhr.method)) {
					var oBody = {};

					try {
						oBody = JSON.parse(oXhr.requestBody);
					} catch (e) {
						oBody = "Cannot parse request body!";
					}
					oCons.log(oBody);
				}
				if (bBatch) {
					log.warning("BATCH REQUEST STARTED");
				}
				var oResult = fnResponse.apply(this, arguments);
				if (bBatch) {
					log.warning("BATCH REQUEST COMPLETED");
				}
				return oResult;
			};
		});
		return aRequests;
	}

	/**
	 * Wrap mock request
	 * @param {object[]} aRequests array with all requests
	 * @param {string} sRegExp string representation of request RegExp
	 * @param {function} fnWrapper request wrapper
	 * @param {string} sMethod HTTP method
	 * @function
	 * @public
	 */
	function inject(aRequests, sRegExp, fnWrapper, sMethod) {
		var oWrappedRequest = aRequests.filter(function (oRequest) {
			return oRequest.method === sMethod && oRequest.path.toString() === sRegExp;
		}).shift();

		if (oWrappedRequest) {
			oWrappedRequest.response = fnWrapper(oWrappedRequest.response);
		}
	}

	return {
		init: function (sServerName, sServiceUri) {
			var oUriParameters = jQuery.sap.getUriParameters(),
				sPath = jQuery.sap.getModulePath("sap.support.useradministration.localService");

			var oMockServer = new MockServer({
				rootUri: sServiceUri,
				metadataPath: "../localService/" + sServerName + "/metadata.xml",
				appModulePath: "sap.support.useradministration/"
			});

			MockServer.config({
				autoRespond: true,
				autoRespondAfter: (oUriParameters.get("serverDelay") || 0)
			});

			oMockServer.simulate(sPath + "/" + sServerName + "/metadata.xml", {
				sMockdataBaseUrl: sPath + "/" + sServerName + "/mockdata",
				bSimulateMissingData: true
			});

			var oMethods = Wrappers[sServerName];
			var aRequests = oMockServer.getRequests();
			if (oMethods && aRequests && aRequests.length) {
				jQuery.each(oMethods, function (sMethod, oWrappers) {
					jQuery.each(oWrappers, function (sRegExp, fnWrapper) {
						inject(aRequests, sRegExp, fnWrapper, sMethod);
					});
				});
				oMockServer.setRequests(aRequests);
			}
			oMockServer.setRequests(_wrapRequests(oMockServer.getRequests()));

			// Inject Function Import Handling TODO:Clean up this code
			if (sServiceUri === "/services/odata/authpackagessrv/") {

				aRequests = oMockServer.getRequests();
				//FI GetSimilarAuthPkgsByAuthObjects
				aRequests.push({
					method: "GET",
					path: new RegExp("GetSimilarAuthPkgsByAuthObjects(.*)"),
					response: function (oXhr) {

						var oUrl = new URL("http:" + oXhr.url),
							authList = oUrl.searchParams.get("AuthorizationObjects");

						// Write each url parameter on a separate line
						var sUrl = oXhr.url.replace(/[\?&]/g, "\n\t\t").replace(/=/g, " = ");
						log.info(oXhr.method + "\t" + unescape(sUrl) + "\n");
						jQuery.sap.log.debug("Incoming request for GetSimilarAuthPkgsByAuthObjects");
						jQuery.ajax({
							url: "./localService/authpackagessrv/mockdata/GetSimilarAuthPkgsByAuthObjects.json",
							dataType: 'json',
							async: false,
							success: function (oData) {
								oXhr.respondJSON(200, {}, JSON.stringify(oData));
							}
						});

						return true;
					}
				});

				//auth_pack_for_custSet special mocking for rename AP
				aRequests.push({
					method: "MERGE",
					path: new RegExp("auth_pack_for_custSet(.*)"),
					response: function (oXhr) {

						// Write each url parameter on a separate line
						var sUrl = oXhr.url.replace(/[\?&]/g, "\n\t\t").replace(/=/g, " = ");
						log.info(oXhr.method + "\t" + unescape(sUrl) + "\n");
						jQuery.sap.log.debug("Incoming MERGE request for auth_pack_for_custSet");
						jQuery.ajax({
							url: "./localService/authpackagessrv/mockdata/auth_pack_for_custSet.json",
							dataType: "json",
							async: false,
							success: function (oData) {
								var oResponse = oData,
									sNewAauthPackName = JSON.parse(oXhr.requestBody).Text;
								oData.d.results.forEach(function (ap) {
									if (ap.Text === sNewAauthPackName) {
										oResponse = {
											"error": {
												"code": "SY/530",
												"message": {
													"lang": "en",
													"value": "Invalid input for Authorization Package Text"
												}
											}
										};
									}
								});

								oXhr.respondJSON(400, {}, JSON.stringify(oResponse));
							}
						});

						return true;
					}
				});

				oMockServer.setRequests(aRequests);
			}

			if (sServiceUri === "/services/odata/useradminsrv/") {
				aRequests = oMockServer.getRequests();
				aRequests.push({
					method: "GET",
					path: new RegExp("ExtendUserDate(.*)"),
					response: function (oXhr) {
						var sUrl = oXhr.url.replace(/[\?&]/g, "\n\t\t").replace(/=/g, " = ");

						log.info(oXhr.method + "\t" + unescape(sUrl) + "\n");
						jQuery.sap.log.debug("Incoming request for ExtendUserDate");
						var oResponse = jQuery.sap.sjax({
							url: sServiceUri + "UserSet"
						});
						oXhr.respondJSON(200, {}, JSON.stringify(oResponse.data));
						return true;
					}
				});
				//FI IsEmailDuplicate
				aRequests.push({
					method: "GET",
					path: new RegExp("IsEmailDuplicate(.*)"),
					response: function (oXhr) {

						var oUrl = new URL("http:" + oXhr.url),
							sEmail = oUrl.searchParams.get("Ipadr"),
							bIsDuplicate = sEmail === "'dup@mail.com'";

						// Write each url parameter on a separate line
						var sUrl = oXhr.url.replace(/[\?&]/g, "\n\t\t").replace(/=/g, " = ");
						log.info(oXhr.method + "\t" + unescape(sUrl) + "\n");
						jQuery.sap.log.debug("Incoming request for IsEmailDuplicate");

						var oResponse = {
							data: {
								d: {
									IsEmailDuplicate: {
										boolValue: bIsDuplicate
									}
								}
							},
							status: "success",
							statusCode: 200,
							success: true
						};

						oXhr.respondJSON(200, {}, JSON.stringify(oResponse.data));
						return true;
					}
				});

				//FI GetDuplicateEmails
				aRequests.push({
					method: "GET",
					path: new RegExp("GetDuplicateEmails(.*)"),
					response: function (oXhr) {

						var oUrl = new URL("http:" + oXhr.url),
							sEmail = oUrl.searchParams.get("Ipadr"),
							kunnr = oUrl.searchParams.get("Kunnr");

						// Write each url parameter on a separate line
						var sUrl = oXhr.url.replace(/[\?&]/g, "\n\t\t").replace(/=/g, " = ");
						log.info(oXhr.method + "\t" + unescape(sUrl) + "\n");
						jQuery.sap.log.debug("Incoming request for IsDuplicateEmail");

						var oResponse = {
							data: {
								d: {
									results: [{
										Ipadr: "dup@mail.com",
										Kunnr: "202418",
										KunnrName: "International Corp.",
										Namev: "Duplicate",
										Name1: "Test",
										Susid: "S0000315118"
									}]
								}
							},
							status: "success",
							statusCode: 200,
							success: true
						};

						oXhr.respondJSON(200, {}, JSON.stringify(oResponse.data));
						return true;
					}
				});

				// FI AppSettings
				aRequests.push({
					method: "GET",
					path: new RegExp("AppSettings(.*)"),
					response: function (oXhr) {

						// Write each url parameter on a separate line
						var sUrl = oXhr.url.replace(/[\?&]/g, "\n\t\t").replace(/=/g, " = ");
						log.info(oXhr.method + "\t" + unescape(sUrl) + "\n");
						jQuery.sap.log.debug("Incoming request for AppSettings");

						var oResponse = {
							data: {
								d: {
									results: [{
										backendLogicVersion: "V2",
										emailRegexp: "^[^.](?!.*(?:[.][.]))[A-ZA-Z0-9.!#$%&'*+/=?^_`{|}~-]+[^.]@[A-ZA-Z0-9](?:[A-ZA-Z0-9-]{0,61}[A-ZA-Z0-9])?(?:[.][A-ZA-Z0-9](?:[A-ZA-Z0-9-]{0,61}[A-ZA-Z0-9])?)+$",
										useNewCreateAp: "X",
										isEmailFilterEnabled: true
									}]
								}
							},
							status: "success",
							statusCode: 200,
							success: true
						};

						oXhr.respondJSON(200, {}, JSON.stringify(oResponse.data));
						return true;
					}
				});

				oMockServer.setRequests(aRequests);
			}

			if (sServiceUri === "/services/odata/toolservicesrv/") {
				aRequests = oMockServer.getRequests();
				aRequests.push({
					method: "GET",
					path: new RegExp("Check_selectionSet(.*)"),
					response: function (oXhr) {
						// Write each url parameter on a separate line
						var oUrl = new URL("http:" + oXhr.url),
							sFilterString = oUrl.searchParams.get("$filter");

						var regExKunnr = new RegExp("Kunnr eq '(\\d+)'", "g"),
							regExUserid = new RegExp("Userid eq '(S\\d+)'", "g"),
							regExTypeCustomer = new RegExp("Type eq 'C'", "g"),
							regExTypeUser = new RegExp("Type eq 'U'", "g"),
							isEditAtCustomerLevel = regExTypeCustomer.test(sFilterString),
							isEditAtUserLevel = regExTypeUser.test(sFilterString),
							matches = [],
							aSelectedItems = [];

						while (matches = regExKunnr.exec(sFilterString)) {
							aSelectedItems.push(
								matches[1]
							);
						}

						var sUrl = oXhr.url.replace(/[\?&]/g, "\n\t\t").replace(/=/g, " = ");
						log.info(oXhr.method + "\t" + unescape(sUrl) + "\n");
						jQuery.sap.log.debug("Incoming request for Check_selectionSet");

						if (isEditAtCustomerLevel) {
							jQuery.ajax({
								url: "./localService/authpackagessrv/mockdata/AuthorizedCustomersSet.json",
								dataType: 'json',
								async: false,
								success: function (oData) {
									var oResponse = {
										d: {
											results: []
										}
									};

									if (oData.d.results.length === aSelectedItems.length) {
										oXhr.respondJSON(200, {}, JSON.stringify(oResponse));

									} else {
										oXhr.respondJSON(200, {}, JSON.stringify(oData));
									}
								}
							});
						} else if (isEditAtUserLevel) {
							while (matches = regExUserid.exec(sFilterString)) {
								aSelectedItems.push(
									matches[1]
								);
							}

							jQuery.ajax({
								url: "./localService/authpackagessrv/mockdata/AuthorizedUsersSet.json",
								dataType: 'json',
								async: false,
								success: function (oData) {

									var oResponse = {
										d: {
											results: []
										}
									};
									var aAuthorizedUsers = oData.d.results.map(function (user) {
										return {
											uname: user.Uname,
											kunnr: user.Kunnr
										};
									});

									var oAuthorizedCustomerUsersCount = aAuthorizedUsers.reduce(function (obj, user) {
										var kunnr = user.kunnr;
										if (!obj[kunnr]) {
											obj[kunnr] = 1;

										} else {
											obj[kunnr]++;
										}
										return obj;
									}, {});

									var aSelectedCustomerUsers = aAuthorizedUsers.map(function (user) {
											if (aSelectedItems.indexOf(user.uname) !== -1) {
												return {
													uname: user.uname,
													kunnr: user.kunnr
												};
											}
										})
										.filter(Boolean);

									var oSelectedCustomerUsersCount =
										aSelectedCustomerUsers.reduce(function (obj, instalaltion) {
											var kunnr = instalaltion.kunnr;
											if (!obj[kunnr]) {
												obj[kunnr] = 1;

											} else {
												obj[kunnr]++;
											}
											return obj;
										}, {});

									var aProcessedCustomers = [];
									aSelectedCustomerUsers.forEach(function (user) {
										if (oAuthorizedCustomerUsersCount[user.kunnr] === oSelectedCustomerUsersCount[user.kunnr]) {
											if (aProcessedCustomers.indexOf(user.kunnr) === -1) {
												oResponse.d.results.push({
													Userid: "",
													Kunnr: user.kunnr,
													Type: "C"
												});
												aProcessedCustomers.push(user.kunnr);
											}
										} else {
											oResponse.d.results.push({
												Userid: user.uname,
												Kunnr: "",
												Type: "U"
											});
										}
									});

									if (oResponse.d.results.length) {
										oXhr.respondJSON(200, {}, JSON.stringify(oResponse));

									} else {
										oXhr.respondJSON(200, {}, JSON.stringify(oData));
									}
								}
							});

						} else {
							jQuery.ajax({
								url: "./localService/authpackagessrv/mockdata/AuthorizedInstallationsSet.json",
								dataType: 'json',
								async: false,
								success: function (oData) {

									var oResponse = {
										d: {
											results: []
										}
									};
									var aAuthorizedCustomerInstallations = oData.d.results.map(function (install) {
										return {
											installationNumber: install.InstallationNumber,
											kunnr: install.Kunnr
										};
									});

									var oAuthorizedCustomerInstallationsCount = aAuthorizedCustomerInstallations.reduce(function (obj, instalaltion) {
										var kunnr = instalaltion.kunnr;
										if (!obj[kunnr]) {
											obj[kunnr] = 1;

										} else {
											obj[kunnr]++;
										}
										return obj;
									}, {});

									var aSelectedCustomerInstallations = aAuthorizedCustomerInstallations.map(function (install) {
											if (aSelectedItems.indexOf(install.installationNumber) !== -1) {
												return {
													installationNumber: install.installationNumber,
													kunnr: install.kunnr
												};
											}
										})
										.filter(Boolean);

									var oSelectedCustomerInstallationsCount =
										aSelectedCustomerInstallations.reduce(function (obj, instalaltion) {
											var kunnr = instalaltion.kunnr;
											if (!obj[kunnr]) {
												obj[kunnr] = 1;

											} else {
												obj[kunnr]++;
											}
											return obj;
										}, {});

									var aProcessedCustomers = [];
									aSelectedCustomerInstallations.forEach(function (installation) {
										if (oAuthorizedCustomerInstallationsCount[installation.kunnr] === oSelectedCustomerInstallationsCount[installation.kunnr]) {
											if (aProcessedCustomers.indexOf(installation.kunnr) === -1) {
												oResponse.d.results.push({
													Userid: "",
													Kunnr: installation.kunnr,
													Type: "C"
												});
												aProcessedCustomers.push(installation.kunnr);
											}
										} else {
											oResponse.d.results.push({
												Userid: "",
												Kunnr: installation.installationNumber,
												Type: "T"
											});
										}
									});

									if (oResponse.d.results.length) {
										oXhr.respondJSON(200, {}, JSON.stringify(oResponse));

									} else {
										oXhr.respondJSON(200, {}, JSON.stringify(oData));
									}
								}
							});
						}

						return true;
					}
				});
				oMockServer.setRequests(aRequests);

			}
			// Inject Function Import Handling			
			oMockServer.start();

			oServers[sServerName] = oMockServer;
		},

		initService: function (sServerName, sServiceUri) {
			var oMockServer = new MockServer({
				rootUri: sServiceUri,
				requests: oJsonServices[sServerName]
			});

			oMockServer.start();

			oServers[sServerName] = oMockServer;
		},

		stop: function (sServerName) {
			var oServer = oServers[sServerName];
			if (oServer) {
				oServer.stop();
			}
		}
	};
});
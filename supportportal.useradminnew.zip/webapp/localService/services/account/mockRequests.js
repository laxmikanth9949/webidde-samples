sap.ui.define([
], function() {
    return {
        name: "account",
        requests: [
            {
                method: "GET",
                path: new RegExp("currentuser[\\/]?"),
                response: function(oXhr) {
                    oXhr.respondJSON(200, {}, {
                        name: "S0006269249",
                        firstName: "Mock",
                        lastName: "Test",
                        email: "mock.test@mockserver.com",
                        displayName: "Mock Test (S0006269249)"
                    }); 
                }
            }
        ]
    };
});
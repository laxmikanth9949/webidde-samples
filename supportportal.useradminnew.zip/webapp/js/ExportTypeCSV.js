jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");

jQuery.sap.declare("sap.support.useradministration.js.ExportTypeCSV");
sap.ui.core.util.ExportTypeCSV.extend("sap.support.useradministration.js.ExportTypeCSV", {
	
	_generate : function(oExport) {
		this._oExport = oExport;
		var sContent = this.generate();
		this._oExport = null;
		return "sep=" + this.getSeparatorChar() + "\n" + sContent;
	}

});
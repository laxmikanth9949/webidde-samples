(function () {
	jQuery.sap.registerModulePath("sap.support.usermanagmentcustomlib", "/applications/usermanagmentcustomlib/");
})();
sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/support/useradministration/controller/Dialogs",
    "sap/support/useradministration/extended/ExtendedJSONModel",
    "sap/support/useradministration/model/Formatter",
    "sap/support/useradministration/model/Models",
    "sap/support/useradministration/util/Settings",
    "sap/support/useradministration/util/Util",
    "sap/support/useradministration/util/odata/ODataUtil",
    "sap/support/useradministration/model/Constant",
    "sap/base/Log",
		"sap/ui/model/json/JSONModel"
], function(UIComponent, Dialogs, ExtendedJSONModel, Formatter, Models, Settings, Util, ODataUtil, Constant, Log, JSONModel) {
    
    var log = Log.getLogger("sap.support.useradministration.Component");
    
    var ReqConfigAction = Util.Constant.ReqConfigAction,
    	ReqConfigCategory = Util.Constant.ReqConfigCategory;
    
    return UIComponent.extend("sap.support.useradministration.Component", {
    	_bDepartmentNewActive: true, //If new Department API is active
    	_bDepartmentOldActive: true, //If old Department API is active
    	
    	metadata: {
    	    manifest: "json"
    	},
    
    	/**
    	 * Initialize models
    	 * @function
    	 * @private
    	 */
    	_initModels: function() {
            Models.configureODataModel.call(this, this.getModel());
            //model below is the same as default model above
            //except it is using PUT (instead of default MERGE) for update
            //which works faster in some cases e.g.: UMT-1182
            //reason for this is that MERGE is *partial* update
            //so on BE it first needs to read current state of entity from DB 
            //and combine it with fields sent in request, only then write
            //(which might work slow for some sets, especially when many entities sent in one batch)
            //but PUT sends the *whole* entity from FE
            //and it is writing it to DB right away, in one step
            //therefore ensure to send the whole entity if using the model below!
            Models.configureODataModel.call(this, this.getModel("useradminsrvModelWithPutUpdate"));
            Models.configureODataModel.call(this, this.getModel("ap"));
            Models.configureODataModel.call(this, this.getModel("domains"));
    		
    		this.setModel(Models.createDeviceModel(), "device");
    		
            this.setModel(new sap.ui.model.json.JSONModel({}), "dummy");
            this.setModel(Dialogs.prototype.getModel(), "dialog");
            this.setModel(Models.createAppModel(), "app");
            this.setModel(Models.createViewModel(), "view");
            this.setModel(new sap.ui.model.json.JSONModel(Settings), "settings");
            this.setModel(new ExtendedJSONModel("/services/account/currentuser"), "user");
            this.setModel(Models.createReqConfigModel(), "reqconfig");
            this.setModel(Models.createAppSettingsModel(), "appSettings");
    	},
    	
    	/**
    	 * Pre-load country set to determine country codes
    	 * @returns {Promise} promise
    	 * @function
    	 * @private
    	 */
    	_loadCountrySet: function () {
    		return Util.promiseRead.call(this, "/CountrySet")
    			.then(function (oData) {
    				Util._registerCountryList(oData && oData.results || []);
    			});
    	},
    	
    	/**
    	 * Load information text
    	 * @function
    	 * @private
    	 */
    	_loadInfoText: function () {
    		var oModel = this.getModel("view");
    		
    		this.getModel("ap").read("/UserInfoSet", {
    			success: function (oData) {
    				var oResult = oData.results[0] || {},
    					sInfoText = oResult.InfoText || "",
    					sUserId = oResult.Userid || "",
    					bButtonEnabled = !(sUserId === "");
    				
    				oModel.setProperty("/InfoBanner/InfoText", sInfoText);
    				oModel.setProperty("/InfoBanner/ButtonEnabled", bButtonEnabled);
    			}
    		});
    	},
    	
    	/**
    	 * Load initial data from the backend
    	 * @returns {Promise} promise
    	 * @function
    	 * @private
    	 */
    	_loadInitialData: function () {
    		return Promise.all([this._loadLoggedUserInfo(), this._loadCountrySet(), this.loadRequestSettings()]);
    	},
    	
    	/**
    	 * Load information about currently logged in user from the backend
    	 * @returns {Promise} promise
    	 * @function
    	 * @private
    	 */
    	_loadLoggedUserInfo: function () {
    		var oAppModel = this.getModel("app");
    		
    		return Util.promiseRead.call(this, "/LogonUserInfoSet")
    			.then(function (oData) {
					var oUser = oData.results && oData.results[0] || {},
						bIsUserNewSetEnabled = false;
						
					oAppModel.setProperty("/LogonUserCCC", Boolean(oUser.isCCC));
					oAppModel.setProperty("/LogonUserId", oUser.Userid);
					oAppModel.setProperty("/IsSUser", /^S/.test(oUser.Userid));
					oAppModel.setProperty("/showUiUniversalid", oUser.showUiUniversalid);
					oAppModel.setProperty("/FunctionId", oUser.Function);
					oAppModel.setProperty("/IsSuperAdmin", Formatter.isSuperAdmin(oUser.Function));
					oAppModel.setProperty("/IsUserNewSetEnabled", bIsUserNewSetEnabled);
					
					ODataUtil.init(bIsUserNewSetEnabled);
    			});
    	},
    	
    	/**
    	 * Load app settings from the backend
    	 * @returns {Promise} promise
    	 * @function
    	 * @private
    	 */
    	_loadAppSettings: function() {
    		var oAppSettingsModel = this.getModel("appSettings");
    		return Util.promiseCallFunction.call(this, Constant.Functions.AppSettings, {})
				.then(function (oData) {
					var results = oData.results[0];
					oAppSettingsModel.setProperty("/emailRegexp", results.emailRegexp);
					oAppSettingsModel.setProperty("/useNewCreateAp", results.useNewCreateAp);
					oAppSettingsModel.setProperty("/isEmailFilterEnabled", results.isEmailFilterEnabled);
					oAppSettingsModel.setProperty("/domainCheckActive", results.isDomainCheckEnabled);
					oAppSettingsModel.setProperty("/showUIDUserList", results.showUIDUserList);
					oAppSettingsModel.setProperty("/isDomainFilterEnabled", results.isDomainFilterEnabled);
					oAppSettingsModel.setProperty("/phoneRegexp", results.phoneRegexp);
					oAppSettingsModel.setProperty("/phoneMaxLength", results.phoneMaxLength);
					oAppSettingsModel.setProperty("/departmentRegexp", results.departmentRegexp);
				});
    	},
			
			_initDomainSettings: function () {
				this.getModel("domains").read("/DomainConfigs", {
					success: function (oData) {
						var aConfigs = oData && oData.results || [];
						var oConfig = {};
						aConfigs.forEach(function (o) {
							oConfig[o.Name] = o.VALUE;
						});
						this.setModel(new JSONModel(oConfig), "DomainConfig");

					}.bind(this),
					error: function (oError) {

					}
				});
			},
    	
    	init : function() {
    	    /*sap.ui.core.UIComponent.prototype.init.apply(this, arguments);*/
    	    UIComponent.prototype.init.apply(this, arguments);
    	    this._initModels();
    	    this._loadInfoText();
    	    this._loadAppSettings();
    	    this._initDomainSettings();
    	    // startup deferred, because we have to wait until the "app" model is loaded
    	    
    	    this._loadInitialData()
    	    	.catch(function () {
    	    		log.error("Initial data loading Error");
    	    	})
    	    	.finally(function () {
    	    		this.getRouter().initialize();
    	    	}.bind(this));
    	},
    	
    	getHelpUrl : function() {
    		/* eslint-disable sap-no-hardcoded-url */
    	    return "https://support.sap.com/user-admin-help";
    	    /* eslint-enable sap-no-hardcoded-url */
    	},	
    	
    	destroy : function() {
    		/*sap.ui.core.UIComponent.prototype.destroy.apply(this, arguments);*/
    		UIComponent.prototype.destroy.apply(this, arguments);
    	},
    	
    	/**
    	 * Check if refactored UserNewSet is enabled
    	 * @returns {boolean} check result
    	 * @function
    	 * @public
    	 */
    	isUserNewSetEnabled: function () {
    		return !!this.getModel("app").getProperty("/IsUserNewSetEnabled");
    	},
    	
    	/**
    	 * Load settings for self-auth request
    	 * @returns {Promise} promise
    	 * @function
    	 * @private
    	 */
    	loadRequestSettings: function () {
    		return Util.promiseRead.call(this, "/ReqConfigSet")
    			.then(this.updateRequestSettingsConfiguration.bind(this));
    	},
    	
    	/**
    	 * Update settings for self-auth request according to backend data
    	 * @param {object} oData data
    	 * @function
    	 * @public
    	 */
    	updateRequestSettingsConfiguration: function(oData) {
    		var oReqConfigModel = this.getModel("reqconfig"),
    			oConfig = Util.mapBy(oData.results || [], "Category"),
    			oSARConfig = oConfig[ReqConfigCategory.SELF_AUTH_REQUEST],
    			bIsAuthorized = false,
    			sCustomerId = "",
    			bIsSAREnabled = true,
    			bIsCustomMessageEnabled = false,
    			sCustomText = "";
    			
    			if (oSARConfig) {
    				switch (oSARConfig.Action) {
    					case ReqConfigAction.ADMIN_LIST:
    						bIsSAREnabled = false;
    						bIsCustomMessageEnabled = false;
    						break;
    					case ReqConfigAction.CUSTOM_MESSAGE:
    						bIsSAREnabled = false;
    						bIsCustomMessageEnabled = true;
    						break;
    				}
    				
    				sCustomText = oSARConfig.Notes || "";
    				bIsAuthorized = Formatter.isAbapTrue(oSARConfig.IsAuthorized);
    				sCustomerId = oSARConfig.CustNumber;
    			}
    			
				oReqConfigModel.setProperty("/CanEditSARSettings", bIsAuthorized);
				oReqConfigModel.setProperty("/SAR/IsEnabled", bIsSAREnabled);
				oReqConfigModel.setProperty("/SAR/CustomerId", sCustomerId);
				oReqConfigModel.setProperty("/SAR/IsCustomMessageEnabled", bIsCustomMessageEnabled);
				oReqConfigModel.setProperty("/SAR/CustomText", sCustomText);
    	}
    });
});
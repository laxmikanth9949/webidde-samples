sap.ui.define([
    "sap/support/useradministration/controller/BaseController",
	//"sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    
    "sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/model/Constant",
    "sap/support/useradministration/util/Util",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    
    "sap/ui/comp/filterbar/FilterBar"
], function(Controller, MessageBox, Dialogs, Constant, Util, Filter, FilterOperator) {
    var Callbacks = Util.callbacks;
    
    var ROUTE = "requestAuthorizationAssign",
    	EVENT_BUS_NAME = "RequestDetail";

	return Controller.extend("sap.support.useradministration.view.RequestAuthorizationAssign", {
		onInit: function() {
			var that = this;
			var oView = this.getView();
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function(evt) {
			    this._sCurrentRoute = evt.getParameter("name");
				// When detail navigation occurs, update the binding context
				if (evt.getParameter("name") === ROUTE) {
				    var oArgs = evt.getParameter("arguments"),
				        sPath = jQuery.sap.formatMessage("/AuthObjectSet(UserId=''{0}'',ObjectId=''{1}'')", [oArgs.user, oArgs.object]);
				    
				    if (!this._getViewProperty("Auth/Edit")) {
				    	this._loadRequestedAuth(oArgs.requestId, oArgs.object, sPath);
				    } else if (!oView.getElementBinding() || oView.getElementBinding().getPath() !== sPath) {
        				oView.bindElement(sPath, {
        				    expand: "AuthObjectAuthLevelSet"
        				});
        				oView.setBusy(true);
        				oView.getElementBinding().refresh();
        			    oView.getElementBinding().attachDataReceived(this._resetAuthDetails.bind(this));
    				} else {
    				    this._resetAuthDetails();
    				}
				}
				that.getView().getParent()._flagUAStopNav = true;
			}, this);

			this._aKeys = ["AuthLevel", "AuthLevelDesc"];
		    this._oDialogs = new Dialogs(this);
		    
    		this._bindViewModel("RequestDetail");
    		
	        this._attachBusEvent("updateLevels", this._updateLevels.bind(this));
		},
		
    	/**
    	 * Attach EventBus event
    	 * @param {string} sEventName event name
    	 * @param {function} fnHander event handler
    	 * @function
    	 * @private
    	 */
    	_attachBusEvent: function(sEventName, fnHander) {
            this.getOwnerComponent().getEventBus().subscribe(EVENT_BUS_NAME, sEventName, fnHander);
    	},
    	
        /**
         * Get extended copy of authorization level object
         * @param {object} oLevel level object
         * @returns {object} extended object
         * @function
         * @private
         */
    	_extendAuthorizationLevelObject: function(oLevel) {
    	    return jQuery.extend(true, {}, oLevel);
    	},
		
    	/**
    	 * Reset authorizations List and user data in view model
    	 * @param {sap.ui.base.Event} oEvent event data
    	 * @function
    	 * @private
    	 */
    	_resetAuthDetails: function(oEvent) {
    	    var oDetail = this._getViewProperty("Auth/Detail"),
    	        oAuth = oEvent && oEvent.getParameter("data"),
    	        aAuthLevelList = oAuth && oAuth.AuthObjectAuthLevelSet;
    	    
    	    if (!aAuthLevelList) {
        	    var oContext = this.getView().getBindingContext(),
        	        aURIList = oContext.getProperty("AuthObjectAuthLevelSet") || [];
        	    
        	    oAuth = oContext.getObject();
    	        aAuthLevelList = aURIList.map(function (sURI) {
    	            return oContext.getModel().getProperty("/" + sURI);
    	        });
    	    }
    	    
    	    // If Customers is null then no changes have been made yet
    	    if (oDetail && !oDetail.Customers) {
    	        aAuthLevelList = aAuthLevelList.map(this._extendAuthorizationLevelObject.bind(this));
    	        this._setViewProperty("Auth/Detail/Clusters", aAuthLevelList.filter(this.formatter.detail.isClusterLevel));
    	        this._setViewProperty("Auth/Detail/Customers", aAuthLevelList.filter(this.formatter.detail.isCustomerLevel));
    	        this._setViewProperty("Auth/Detail/Installations", aAuthLevelList.filter(this.formatter.detail.isInstallationOrUserLevel));
    	    }
    	    
    	    this.getView().setBusy(false);
    	},
    	
    	_loadRequestedAuth: function (sRequestId, sObjectId, sPath) {
    		if (this._getViewProperty("Auth/Detail/TempCurrentAuthLevel") === Constant.AuthLevel.FULL) {
    			return;
    		}
    		var oParams = {
				filters: [new sap.ui.model.Filter("RequestId", sap.ui.model.FilterOperator.EQ, sRequestId),
					new sap.ui.model.Filter("ObjectId", sap.ui.model.FilterOperator.EQ, sObjectId)]
			};
			
			this.setBusy(true);
			Util.promiseRead.call(this, "/RequestedAuthObjectSet", oParams)
			.then(this._processAuths.bind(this, sPath))
			.finally(this.setBusy.bind(this, false));
    	},
    	
    	_processAuths: function (sPath, oData) {
    		var aRequestedList = oData.results || [],
			aFilters = aRequestedList.reduce(function (arr, curItem) {
				if (curItem.Value !== "" && arr.indexOf(curItem.Value) === -1) {
					arr.push(curItem.Value);
				}
				return arr;
			}, []);//.map(function (sNum) {
				// return new Filter("AuthLevel", FilterOperator.EQ, sNum);
			// });
			
			Util.promiseRead.call(this, sPath + "/AuthObjectAuthLevelF4HelpSet", {
				// filters: aFilters
			}). then(function (oCustData) {
				var aList = oCustData.results.filter(function (a) {
					return aFilters.indexOf(a.AuthLevel) !== -1;
				}) || [];
				this._setViewProperty("Auth/Detail/Customers", aList.filter(function (a) {
					return a.AuthLevelType === Constant.AuthLevelType.DEBITOR;
				}));
				this._setViewProperty("Auth/Detail/Installations", aList.filter(function (a) {
					return a.AuthLevelType !== Constant.AuthLevelType.DEBITOR;
				}));
			}.bind(this));
			
			
    	},
	
    	/**
    	 * Trigger EventBus event
    	 * @param {string} sEventName event name
    	 * @function
    	 * @private
    	 */
    	_triggerBusEvent: function(sEventName) {
            this.getOwnerComponent().getEventBus().publish(EVENT_BUS_NAME, sEventName);
    	},
    	
    	/**
    	 * Update auth levels
    	 * @function
    	 * @private
    	 */
    	_updateLevels: function() {
    	    var oBinding = this.getView().getElementBinding();
    	    if (oBinding && this._sCurrentRoute === ROUTE) {
    	        oBinding.refresh();
    	    }
    	},
    	
    	/**
    	 * Set "Granted All" switch to true
    	 * @function
    	 * @public
    	 */
    	grantAll: function() {
    	    this._setViewProperty("Auth/Detail/TempSelected", true);
    	    this._triggerBusEvent("authTopLevelChange");
    	},
    	
    	/**
    	 * Clear clusters list
    	 * @event
    	 * @public
    	 */
    	onDeleteClusters: function() {
	        this._setViewProperty("Auth/Detail/Clusters", []);
			this._triggerBusEvent("authDetailsChange");
    	},
    	
		/**
		 * Edit restricted customers list
		 * @event
		 * @public
		 */
		onEditCustomers: function() {
            var oBundle = Util.getBundle.call(this),
                oContext = this.getView().getBindingContext(),
                oCore = sap.ui.getCore(),
                oUserModel = oCore.getModel("user");
                
            if (oUserModel && oUserModel.getProperty("/name") === oContext.getProperty("UserId")) {
                MessageBox.show(oBundle.getText("MESSAGE_AUTHORITY_WARNING2"), {
                    icon: MessageBox.Icon.WARNING,
                    title: oBundle.getText("MISC_WARNING"),
                    actions: [MessageBox.Action.OK]
                });
                return;
            }
            
            var oDialog = this._oDialogs.getDialog("SelectRestrictedCustomers"),
                aTokens = this._getViewProperty("Auth/Detail/Customers").map(function (oLevel) {
				    return new sap.m.Token({
						key: oLevel.AuthLevel,
						text: oLevel.AuthLevelDesc + " (" + oLevel.AuthLevel + ")"
				    });
				});
            oDialog.setModelName();
            oDialog.setContext(oContext.getPath());
            oDialog.setTokens(aTokens);
            oDialog.open();
		},
		
		/**
		 * Edit restricted installations list
		 * @event
		 * @public
		 */
		onEditInstallations: function() {
            var oBundle = Util.getBundle.call(this),
                oContext = this.getView().getBindingContext(),
                oCore = sap.ui.getCore(),
                oUserModel = oCore.getModel("user");
                
            if (oUserModel && oUserModel.getProperty("/name") === oContext.getProperty("UserId")) {
                MessageBox.show(oBundle.getText("MESSAGE_AUTHORITY_WARNING2"), {
                    icon: MessageBox.Icon.WARNING,
                    title: oBundle.getText("MISC_WARNING"),
                    actions: [MessageBox.Action.OK]
                });
                return;
            }
            
            var oDialog = this._oDialogs.getDialog("SelectRestrictedInstallations"),
                aTokens = this._getViewProperty("Auth/Detail/Installations").map(function (oLevel) {
				    return new sap.m.Token({
						key: oLevel.AuthLevel,
						text: oLevel.AuthLevelDesc + " (" + oLevel.AuthLevel + ")"
				    });
				});
            oDialog.setModelName();
            oDialog.setContext(oContext.getPath());
            oDialog.setTokens(aTokens);
            oDialog.setUsersMode(oContext.getProperty("AuthLevelId") === Constant.AuthLevelId.USER);
            oDialog.open();
		},
		
    	/**
    	 * Handle top level switch state change
    	 * Send auth to the Detail controller
    	 * @param {sap.ui.base.Event} oEvent event
    	 * @event
    	 * @public
    	 */
    	onTopLevelSwitchChange: function(oEvent) {
    	    this._setViewProperty("Auth/Detail/TempSelected", oEvent.getSource().getSelected());
    	    this._triggerBusEvent("authTopLevelChange");
    	},
		
		/**
		 * Append customers in the customers table 
		 * @param {object[]} aCustomers selected customers
		 * @function
		 * @public
		 */
		appendCustomers: function(aCustomers) {
		    var aExisting = this._getViewProperty("Auth/Detail/Customers") || [],
		        oExisting = Util.combineArray(aExisting, Callbacks.getKey("AuthLevel"), true);
		    
		    aCustomers.forEach(function(oCustomer) {
		        if (!oExisting[oCustomer.AuthLevel]) {
		            aExisting.push(oCustomer);   
		        }
		    });
		    this._setViewProperty("Auth/Detail/Customers", aExisting);
			this._triggerBusEvent("authDetailsChange");
		},
		
		/**
		 * Save customers to the customer table
		 * @param {object[]} aCustomers selected customers
		 * @function
		 * @public
		 */
		saveCustomers: function(aCustomers) {
		    this._setViewProperty("Auth/Detail/Customers", aCustomers);
			this._triggerBusEvent("authDetailsChange");
		},
		
		/**
		 * Save installations to the installation table
		 * @param {object[]} aInstallations selected installations
		 * @function
		 * @public
		 */
		saveInstallations: function(aInstallations) {
		    var aCustomers = this._getViewProperty("Auth/Detail/Customers") || [],
		        oCustomers = Util.combineArray(aCustomers, Callbacks.getKey("AuthLevel"), true),
		        bCrossCustomer = aInstallations && aInstallations.some(function (oInstallation) {
    		        return oCustomers[oInstallation.CustNum];
    		    });
		    
		    this._setViewProperty("Auth/Detail/Installations", aInstallations);
		    if (bCrossCustomer) {
				sap.m.MessageBox.show(this.getBundle().getText("AUTHORIZATION_LEVEL_CUST_SELECTED"), {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: this.getBundle().getText("HELP_TITLE"),
					actions: [sap.m.MessageBox.Action.CLOSE]
				});
		    }
			this._triggerBusEvent("authDetailsChange");
		},
		
		/**
		 * Get selected customer numbers
		 * @returns {string[]} array of customer numbers
		 * @function
		 * @public
		 */
		getSelectedCustomerNumbers: function() {
			var oTable = this.getView().byId("idCustAuthTable"),
			    aItems = oTable.getItems();
			    
		    return aItems.map(function(oItem) {
		        return oItem.getCells()[0].getText().trim();
		    });
		}
	});
});
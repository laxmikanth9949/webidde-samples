/* eslint-disable valid-jsdoc */
sap.ui.define([
	"../../model/Constant"
], function(
	Constant
) {
"use strict";

return {
    isDomainSelectorSUAFocused: function(){
        return this.getView().byId("domainSelectorSuperCloudAdmin").bIsFocused;
    },
    onMsgStripTitleClick: function(event) {
        this.updateValidationMessagesCollapse(event.getSource());
    },
    onDescriptionClick: function(event){
        var descPress = event.getSource().getBindingContext("view").getProperty("descPress");

        if(descPress){
            this[descPress.func].apply(this, descPress.args);
        }
    },
    updateValidationMessagesCollapse: function(source){
        var 
            msgPath = "ValidationMessages",
            ctx = source.getBindingContext("view"),
            sourceIndex = +(ctx.getPath().split("/").pop()),
            newState = !ctx.getProperty("expanded");

        this._getViewProperty(msgPath).forEach(function(msg, i){
            var currentExpand = i !== sourceIndex ? false : newState;

            this._setViewProperty(msgPath.concat("/", i, "/expanded"), currentExpand);
        }.bind(this));

        this.updateValueStates();
    },

    updateValueStates: function(){
        var 
            defaultValueState = sap.ui.core.ValueState.None,
            messages = this._getViewProperty("ValidationMessages") || [];

        messages.forEach(function(msg){
            (msg.valueStates || []).forEach(function(valState){
                this._setViewProperty(valState.path, defaultValueState);
            }.bind(this));
        }.bind(this));

        messages.filter(function(msg){ return msg.expanded; }).forEach(function(msg){
            (msg.valueStates || []).forEach(function(valState){
                this._setViewProperty(valState.path, valState.value);
            }.bind(this));
        }.bind(this));
    },

    getValidatorBlock: function(blockName){
        var block = Constant[blockName];

        return $.extend(true, Array.isArray(block) && [] || {}, block);
    },
    processInvalidValidationAreas: function(validationScope, result){
        this.getValidatorBlock(validationScope).filter(function(block){
            this.executeValidationConstraint(block.constraint, result);
        }.bind(this)).forEach(function(block){
            var setters = block.setters || [{
                properties: block.properties,
                value: block.value
            }];

            this.applyValidationValuesToProperties(setters);
        }.bind(this));

        return this;
    },

    applyValidationValuesToProperties: function(setters){
        setters.forEach(function(setter){
            var value = setter.value;

            if(typeof value === "object"){
                var path = value.path;

                value = value.i18n ? this.getText(path) : this._getViewProperty(path);
            }

            setter.properties.forEach(function(property){
                this._setViewProperty(property, value);
            }.bind(this));
        }.bind(this));
    },
    collectValidationMessages: function(validationBlockName){
        return this.getValidatorBlock(validationBlockName).filter(function(block){
            return this.executeValidationConstraint(block.constraint);
        }.bind(this)).map(function(block, i){
            return this.generateValidationMessageObject(block, i);
        }.bind(this));
    },

    getParsedValidationText: function(textBlock){
        if(!textBlock){
            return "";
        }
        
        if(!Array.isArray(textBlock)){
            return this.getText(textBlock);
        }

        return textBlock.map(function(block){
            if(typeof block === "string"){
                return this.getText(block);
            }
            
            return this.getText(block.path, (block.args || []).map(function(argBlock){
                var 
                    model = argBlock.model,
                    closure = argBlock.closure,
                    pth = argBlock.path,
                    isI18n = argBlock.i18n;

                if(closure){
                    return this[pth];
                } else if(isI18n){
                    return this.getText(pth);
                } else {
                    return model ? this.getModel(model).getProperty(pth) : this._getViewProperty(pth);
                }
            }.bind(this)));
        }.bind(this)).join(" ");
    },

    generateValidationMessageObject: function(block, index){
        var 
            descr = block.description ? this.getParsedValidationText(block.description) : "",
            description = this.getParsedValidationText(block.subtitle).concat(" ", descr);
        
        return {
            expanded: !index,
            title: this.getParsedValidationText(block.title),
            description: description,
            type: block.type,
            valueStates: block.valueStates || [],
            descPress: block.descPress
        };
    },
    /**
     * @description Universal check method through constant configuration
     * @param {object[]|undefined} constraint - Mandatory checks for message generation 
     * @param [object] readObject - Optional object where need to read properties in constraint 
     * @returns {boolean} Result of executed constraint
     */
    executeValidationConstraint: function(constraint, readObject){
        if(!constraint) return true;

        var 
            lastConstraint = constraint[constraint.length - 1],
            and = typeof lastConstraint === "boolean" ? lastConstraint : true;

        if(typeof lastConstraint === "boolean"){
            constraint.pop();
        }

        return constraint[and ? "every" : "some"](function(expression){
            if(Array.isArray(expression)){
                return this.executeValidationConstraint(expression);
            }

            if(expression.func){
                return this[expression.func]();
            }
                
            var 
                path = expression.path, model = expression.model, property = expression.property,
                value = null;

            if(property){
                value = readObject ? readObject[property] : this[property];
            } else {
                value = !model ? this._getViewProperty(path) : this.getModel(model).getProperty(path);
            }


            return expression.not ? !value : !!value;
        }.bind(this));
    }
};
});
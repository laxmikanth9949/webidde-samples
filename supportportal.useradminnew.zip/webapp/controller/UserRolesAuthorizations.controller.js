sap.ui.define([
    "sap/support/useradministration/controller/BaseController",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/support/useradministration/controller/Dialogs",
    "sap/support/useradministration/util/Util"
], function (BaseController, Filter, FilterOperator, Dialogs, Util) {
	"use strict";
	
	var MODEL_USER_REQUESTS = "UserRequests";
	
    return BaseController.extend("sap.support.useradministration.controller.UserRolesAuthorizations", {
        /**
         * Attach applying filters on opening page
         * @event
         * @public
         */
        onInit: function() {
        	this._oDialogs = new Dialogs(this);
        	this._setViewProperty("UserAuthsList");
        	this._setViewProperty("RequestAuthButton", true);
			this._setViewProperty("IsSelfAuthorizationRequestVisible", this._isIsSelfAuthorizationRequestVisible());
        	
        	this._bindViewModel("UserRolesAuthorizations");
    		this.createJSONModel([], MODEL_USER_REQUESTS);
            this.getRouter().getRoute("userRolesAuthorizations").attachPatternMatched(this._handlePageOpen.bind(this));
        },
        
        onSectionChange: function (oEvent) {
        	var sSectionId = oEvent.getParameter("section").getId();
        	this._setViewProperty("RequestAuthButton", sSectionId.indexOf("idRequestSection") !== -1);
        },

        
        /**
         * Get authorization package list
         * @returns {sap.m.ListBase} list
         * @function
         * @private
         */
        _getAPList: function() {
            return this.byId("userRolesAuthorizationsAPTable");
        },
        
        /**
         * Handle opening page
         * Apply filters to Auth Package list
         * @event
         * @private
         */
        _handlePageOpen: function() {
            var oList = this._getAPList(),
                oBinding = oList.getBinding("items"),
                oModel = this.getModel("user");
            
			this._setViewProperty("IsSelfAuthorizationRequestVisible", this._isIsSelfAuthorizationRequestVisible());
            // To be sure that user model is loaded
            oModel.getDataAsync().then(function(oData) {
                oBinding.filter([
                    new Filter("SUser", FilterOperator.EQ, oData.name)
                ]);
                
                if (this._isIsSelfAuthorizationRequestVisible()) {
                	this._getUserRequestsList(oData.name);
                }
                this._requestExistingAuthorizations(oData.name);
            }.bind(this));
        },
        
        /**
         * Load list with user's requests
         * @param {string} sUser User ID
         * @function
         * @private
         */
        _getUserRequestsList: function (sUser) {
        	var oRequestModel = this.getModel(MODEL_USER_REQUESTS);
        		
        	this._setViewProperty("RequestListBusy", true);
        	this._promiseRead("/AuthorizationRequestSet", {
        		filters: [new sap.ui.model.Filter("UserId", sap.ui.model.FilterOperator.EQ, sUser),
        		new sap.ui.model.Filter("TypeOfRequest", sap.ui.model.FilterOperator.EQ, "Authorization"),
        		new sap.ui.model.Filter("Flag", sap.ui.model.FilterOperator.EQ, true)]
        	}).then(function (oData) {
        		oRequestModel.setData(oData.results || []);
        	}).catch(function () {
        		oRequestModel.setData([]);
        	}).finally(this._setViewProperty.bind(this, "RequestListBusy", false));
        },
		
		/**
		 * Check if self authorization request functionality is visible
		 * @returns {boolean} enabled state
		 * @function
		 * @private
		 */
		_isIsSelfAuthorizationRequestVisible: function () {
			return !!this._getSettings().isSelfAuthorizationRequestVisible;
		},
        
        _manageExistingAuthorizations: function () {
			var aExistingGroups = [],
				oData = {};
			var addGroups = function(aAuths) {
				var aGroups = aAuths.filter(function (oAuth) {
					return oAuth.AuthLevelId === "group";
				});
				aGroups.forEach(function (oGroup) {
					if(!aExistingGroups.some(function(oExistingGroup){
						return oExistingGroup.ObjectId === oGroup.ObjectId;
					})) {
						aExistingGroups.push(Util.copy(oGroup));
						oData[oGroup.ObjectId] = [];
					}
				});
			};
			var addAuths = function(aAuths) {
				var aNewAuths = aAuths.filter(function(oAuth) {
					return oAuth.AuthLevelId !== "group";
				});
				aNewAuths.forEach(function(oAuth) {
					if(oData[oAuth.AuthLevelId] && !oData[oAuth.AuthLevelId].some(function(oExistingAuth){
						return oExistingAuth.ObjectId === oAuth.ObjectId &&
							oExistingAuth.AuthPackId === oAuth.AuthPackId &&
							oExistingAuth.Field === oAuth.Field &&
							oExistingAuth.Value === oAuth.Value;
					})) {
						oData[oAuth.AuthLevelId].push(Util.copy(oAuth));
					}
				});
			};
			var add = function (aAuths) {
				addGroups(aAuths);
				addAuths(aAuths);
			};
			var sort = function () {
				for (var key in oData) {
					oData[key].sort(function (a, b) {
						if(a.ObjectId < b.ObjectId) {
							return -1;
						} else if(a.ObjectId > b.ObjectId) {
							return 1;
						}
						return 0;
					});
				}
			};
			var toArray = function () {
				var result = [];
				sort();
				aExistingGroups.forEach(function (group) {
					if (oData[group.ObjectId].length > 0) {
						result.push(Util.copy(group));
						result = result.concat(oData[group.ObjectId]);
					}
				});
				return result;
			};
			
			return {
				add: add,
				toArray: toArray
			};
		},

		/**
		 * Request Existing Authorizations
		 * @param {string} sUserId user ID
		 * @function
		 * @private
		 */
		_requestExistingAuthorizations: function (sUserId) {
			var authManage = this._manageExistingAuthorizations(),
				promiseRead = Util.promiseRead.bind(this);
			
			promiseRead("/UserSet('" + sUserId + "')/UserExistingAuthorizationsSet")
			.then(function (oData) {
				var aResults = oData.results || [];
				authManage.add(aResults);
				
				return promiseRead("/auth_pack_set_for_userSet", {
					filters: [new sap.ui.model.Filter("SUser", sap.ui.model.FilterOperator.EQ, sUserId)]
				}, "ap");
			})
			.then(function (oData) {
				var aResults = oData.results || [];
				return Promise.all(aResults.map(function(oPack) {
					return promiseRead("/Auth_pack_detailSet", {
						filters: [
							new sap.ui.model.Filter("AuthPackId", sap.ui.model.FilterOperator.EQ, oPack.AuthPackId),
							new sap.ui.model.Filter("SkipAuthCheck", sap.ui.model.FilterOperator.EQ, true)
						]
					}, "ap")
					.then(function (oPackData) {
						var aPackResults = oPackData.results || [];
						aPackResults = aPackResults.map(function (oAuth) {
							oAuth.AuthPackId = oPack.AuthPackId;
							oAuth.AuthPackText = oPack.Text;
							oAuth.ValueDescription = oAuth.ValueDesc;
							oAuth.ObjectId = oAuth.Object;
							oAuth.isPackageAuth = true;
							
							return oAuth;
						});
						
						authManage.add(aPackResults);
					});
				}));
			})
			.finally(function() {
				this.createJSONModel(authManage.toArray(), "UserAuths");
			}.bind(this));
		},
		
		onDeleteButtonPress: function (oEvent) {
			var oRequest = oEvent.getSource().getParent().getParent().getBindingContext("UserRequests").getObject(),
				sRequestId = oRequest.RequestId;
			
			sap.m.MessageBox.show(this.getBundle().getText("DELETE_REQUEST_TEXT"), {
				icon: sap.m.MessageBox.Icon.WARNING,
				title: this.getBundle().getText("DELETE_REQUEST_TITLE"),
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.OK) {
						this.getModel().update("/AuthorizationRequestSet('" + sRequestId + "')", {
							Status: "C",
							Flag: true
						}, {
							success: function() {
								sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_AUTH_REQ_CANCELLED"));
								this.refreshUserRequestsList();
							}.bind(this)
						});
					}
				}.bind(this)
			});
		},
		
		onRequestPress: function (oEvent) {
			var oRequest = oEvent.getSource().getBindingContext("UserRequests").getObject(),
				sRequestId = oRequest.RequestId;
				
			this.getRouter().navTo("userRolesAuthorizationsRequestDetail", {
				requestId: sRequestId
			}, false);
		},
		
		openRequestAuthorizationDialog: function () {
			var oReqConfigModel = this.getOwnerComponent().getModel("reqconfig"),
				oSARConfig = oReqConfigModel.getProperty("/SAR") || {},
				oDialog;
			
			if (this._getSettings().isServicesSettingsDialogEnabled && !oSARConfig.IsEnabled) {
				if (oSARConfig.IsCustomMessageEnabled) {
					oDialog = this._oDialogs.getDialog("RequestAuthorizationCustomMessage");
				} else {
					oDialog = this._oDialogs.getDialog("RequestAuthorizationAdminList");
				}
			} else {
				oDialog = this._oDialogs.getDialog("RequestAuthorization");
			}
			
			oDialog.syncStyleClass().open();
		},
        
        /**
         * Refresh list with user's requests
         * @function
         * @public
         */
        refreshUserRequestsList: function () {
			var oUserModel = this.getModel("user");
			
			this._getUserRequestsList(oUserModel.getProperty("/name"));
        },
        
		/**
		 * Handle Info button press
		 * Open popover with rejection reason
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onInfoButtonPress: function (oEvent) {
			if (!this._oRequestInformationPopover) {
				this._oRequestInformationPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.RequestInformationPopover", this);
				this._oRequestInformationPopover.setModel(this.getModel("i18n"), "i18n");
				this._oRequestInformationPopover.setModel(new sap.ui.model.json.JSONModel({
					RejectReason: ""
				}), "dialog");
			}
			
			var sRejectReason = oEvent.getSource().getBindingContext("UserRequests").getProperty("RejectReason");
			this._oRequestInformationPopover.getModel("dialog").setProperty("/RejectReason", sRejectReason);
			this._oRequestInformationPopover.openBy(oEvent.getSource());
		}
    });
});
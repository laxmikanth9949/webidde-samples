sap.ui.define([
	"sap/support/useradministration/controller/BaseController",
	"sap/support/useradministration/util/Util"
], function (BaseController, Util) {
	
	var USER_DETAIL_CHECK_ROUTE = "userDetailCheckNew",
		USER_DETAIL_CHECK_VIEW_ROUTE = "userDetailCheckView",
		USER_DETAIL_ROUTE = "userDetailNew",
		USER_DETAIL_VIEW_ROUTE = "userDetailView";
	
	var History = sap.ui.core.routing.History,
		HistoryDirection = sap.ui.core.routing.HistoryDirection;
	
	return BaseController.extend("sap.support.useradministration.view.UserDetailCheck", {
		onInit: function () {
			var oHistory = History.getInstance();
			
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function (evt) {
				var bMainRoute = evt.getParameter("name") === USER_DETAIL_CHECK_ROUTE,
					bViewRoute = evt.getParameter("name") === USER_DETAIL_CHECK_VIEW_ROUTE;

				if (bMainRoute || bViewRoute) {

					if (oHistory.getDirection() === HistoryDirection.Backwards && oHistory.getPreviousHash() !== undefined) {
						window.history.go(-1);
						return;
					}
					
					var sUserId = evt.getParameter("arguments").user_id,
						sPath = this.getUserSetODataUtil().getUserSetPathWithParams(sUserId);
						
					Util.promiseRead.call(this, sPath)
						.then(function () {
							this.getRouter().navTo(bViewRoute ? USER_DETAIL_VIEW_ROUTE : USER_DETAIL_ROUTE, {
								"user_id": sUserId
							});
						}.bind(this))
						.catch(function (){
							this.getRouter().navTo("UA_main_search", {
								searchterm: sUserId
							});
						}.bind(this));
				}
			}, this);
		}
	});
});
sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialog) {
    
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.FilterTasksList", {
        _fnDataFactory: function() {
	    	this.Days = {
	    		"0": 0,
	    		"7": 7,
	    		"31": 31,
	    		"365": 365
	    	};
	    },
        _sDialogName: "FilterTasksList",
        
        _findTile: function(item, arr) {
        	var count;
        	for (var i = 0; i < arr.length; i++) {
        		count = 0;
        		if (arr[i].TileId === item.TileId) {
        			count++;
        		}
        	}
        	return count > 0;
        },
         
        _beforeOpen: function() {
        	if (!this._oDialogModel.getProperty("/TasksFilterDialog")) {
        		this._oDialogModel.setProperty("/TasksFilterDialog", {});
        	}
        	this.getDialog().bindElement("dialog>/TasksFilterDialog");
        	if (!this._oDialogModel.getProperty("/TasksFilterDialog/AppList")) {
        		this.getModel().read("/AuthorizationRequestSet", {
        			success: function (oData) {
						var aList = oData.results || [];
						var aMap = [];
						var aResult = [];
						for (var i = 0; i < aList.length; i++) {
						    var item = aList[i];
						    if(!this._findTile(item, aMap)){
						        aMap.push(item);
						        aResult.push({
						            "TileId": item.TileId
						        });
						    }
						}
						this._oDialogModel.setProperty("/TasksFilterDialog/AppList", aResult);
					}.bind(this)
        		});
        	}
        	if (!this._bItemsDeleted) {
        		this._deleteItems();
        	}
        },
        
        /**
         * Delete filters that should not be visible
         * @function
         * @private
         */
        _deleteItems: function () {
        	var bLifetimeEnabled = this._getSettings().isSUserLifetimeEnabled,
        		oDialog = this.getDialog();
        	
    		oDialog.getFilterItems().filter(function (oItem) {
    			switch (oItem.getKey())  {
    				case "TypeOfRequest":
    					return !bLifetimeEnabled;
    				default:
    					return false;
    			}
    		}).forEach(function (oItem) {
    			oDialog.removeFilterItem(oItem);
    		});	
    		this._bItemsDeleted = true;
        },
        
        onSubmit: function(oEvent) {
			var oTable = this._oView.byId("idTasksTable");

			var mParams = oEvent.getParameters();
			var oBinding = oTable.getBinding("items");
			
			var aFilters = (mParams.filterItems && mParams.filterItems.map(function (oItem) {
				var aSplit = oItem.getKey().split("___");
				var sPath = aSplit[0];
				var sOperator = aSplit[1];
				var sValue1 = aSplit[2];
				if (sPath === 'ChangedAt'){
					sValue1 = new Date(sValue1);
				}
				return new sap.ui.model.Filter(sPath, sOperator, sValue1);
			})) || [];

			this._getController()._updateActionRequiredList(aFilters);
			oBinding.filter(aFilters, "Control");

			this._oView.byId("vsdFilterBar8").setVisible(aFilters.length > 0);
			this._oView.byId("vsdFilterLabel8").setText(mParams.filterString);
        }
   
    });
});
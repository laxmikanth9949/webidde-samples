sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
    "sap/support/useradministration/util/Util"
], function(BaseDialog, Util) {
	
    var _fnFactory = function() {
    	this.CustomText = "";
    	this.isEnableAuth = true;
    	this.isCustomText = false;
    	this.isAdminList = false;
    	this.isValidText = true;
    };
    
    var OPT_SAR_ENABLED = 0,
    	OPT_ADMIN_LIST = 1,
    	OPT_CUSTOM_MSG = 2;
    
    var ReqConfigAction = Util.Constant.ReqConfigAction,
    	ReqConfigCategory = Util.Constant.ReqConfigCategory;
    
    /**
     * Dialog for settings of Self-Authorization
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.ManageSelfServiceAuthorization
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.ManageSelfServiceAuthorization", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "ManageSelfServiceAuthorization",
        
        beforeOpen: function () {
        	this.setBusy(true);
        	
        	Util.promiseRead.call(this, "/ReqConfigSet")
        		.then(function (oData) {
        			var oReqConfigModel = this._getComponent().getModel("reqconfig");
        			this._getComponent().updateRequestSettingsConfiguration(oData);
        			
        			var sCustomText = oReqConfigModel.getProperty("/SAR/CustomText"),
        				iOption = OPT_ADMIN_LIST;
        				
        			if (oReqConfigModel.getProperty("/SAR/IsEnabled")) {
        				iOption = OPT_SAR_ENABLED;
        			} else if (oReqConfigModel.getProperty("/SAR/IsCustomMessageEnabled")) {
        				iOption = OPT_CUSTOM_MSG;
        			}
        			this.setProperty("isValidText", true);
        			this._setSelection(iOption, sCustomText);
        		}.bind(this))
        		.finally(this.setBusy.bind(this, false));
        },
        
        /**
         * Get default custom text
         * @returns {string} text
         * @function
         * @private
         */
        _getDefaultText: function () {
        	return this.getText("MESSAGE_SAR_DEFAULT_CUSTOM_MESSAGE");
        },

        /**
         * Set selection
         * @param {int} iOption selected option in radiobutton group
         * @param {string} sCustomText custom message
         * @function
         * @private
         */
        _setSelection: function (iOption, sCustomText) {
        	this.setProperty("isEnableAuth", true);
        	if (iOption === OPT_ADMIN_LIST) {
        		this.setProperty("isAdminList", true);
        	} else if (iOption === OPT_CUSTOM_MSG) {
        		this.setProperty("isCustomText", true);
        	}
        	this.setProperty("CustomText", sCustomText);
        	
        },
        
        _getSelectedOption: function () {
        	var iSelectedOption = OPT_SAR_ENABLED;
        	if (this.getProperty("isAdminList")) {
        		iSelectedOption = OPT_ADMIN_LIST;
        	}
        	if (this.getProperty("isCustomText")) {
        		iSelectedOption = OPT_CUSTOM_MSG;
        	}
        	return iSelectedOption;
        },
        
        onInputChange: function () {
    		this.setProperty("isValidText", true);
        },
        
        /**
         * Save settings
         * @event
         * @public
         */
        onSave: function () {
        	var sCustomerId = this._getComponent().getModel("reqconfig").getProperty("/SAR/CustomerId"),
        		//oRBGroup = this._getRadioButtonGroup(),
        		//iSelectedOption = oRBGroup && oRBGroup.getSelectedIndex(),
        		iSelectedOption = this._getSelectedOption(),
        		sAction = ReqConfigAction.SAR_ENABLED;
        	if (iSelectedOption === OPT_ADMIN_LIST) {
        		sAction = ReqConfigAction.ADMIN_LIST;
        	} else if (iSelectedOption === OPT_CUSTOM_MSG) {
        		sAction = ReqConfigAction.CUSTOM_MESSAGE;
        		if (!this.getProperty("CustomText")) {
        			this.setProperty("isValidText", false);
        			sap.ui.getCore().byId("idInputCustomText").focus();
        			return;
        		}
        	}
        	
        	var sPath = Util.formatMessage("/ReqConfigSet(CustNumber=''{0}'',Category=''{1}'',Action=''{2}'')",  [sCustomerId, ReqConfigCategory.SELF_AUTH_REQUEST, sAction]),
        		oData = {
        			Notes: this.getProperty("CustomText") || ""
        		};
        	
        	this.setBusy(true);
        	Util.promiseUpdate.call(this, sPath, oData)
        		.then(function () {
        			Util.showToast(this.getText("MESSAGE_SSA_SETTINGS_SAVED"));
        			this._getComponent().loadRequestSettings();
        			this.close();
        		}.bind(this))
        		.finally(function () {
        			this.setBusy(false);
        		}.bind(this));
        }
    });
});
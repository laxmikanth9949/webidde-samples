sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDepartmentDialog",
	"sap/support/useradministration/util/Util"
], function(BaseDialog, Util) {

    /**
     * Dialog for editing departments using new department API
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.EditDepartmentNew
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.EditDepartmentNew", {
        _sDialogName: "EditDepartmentNew",
        
        /**
         * Delete department
         * @event
         * @public
         */
        onDeleteDept: function () {
        	var sDepartmentId = this.getProperty("DepartmentId");
        		
        	if (!sDepartmentId) {
        		this._getLogger.error("No department ID provided");
        	} else {
        		Util.showConfirmationPromiseBox(this.getText("MESSAGE_CONFIRM_DEPT_DELETION"))
        			.then(function () {
		        		var sPath = Util.formatMessage("/DepartmentNewSet(''{0}'')", [sDepartmentId]);
			        	this.setBusy(true);
			        	Util.promiseDelete.call(this, sPath)
			        		.then(function () {
				        		sap.m.MessageToast.show(this.getText("MESSAGE_DEPT_DELETED"));
				        		this._getRequester().loadDepartments();
				        		this.close();
				        	}.bind(this))
			        		.finally(this.setBusy.bind(this, false));
        			}.bind(this));
        	}
        },
        
		/**
         * Run on the Department name input change
         * @param {sap.ui.base.Event} oEvent input change event
         * @function
		 * @public
         */
        onInputChange: function (oEvent) {
    		this.setProperty("ErrorMessage", "");

			var sDepartmentNameInput = oEvent.getParameter("value");
			this.runInputChecks(sDepartmentNameInput);
			this.setProperty("IsEditBtnEnabled", !(this.getProperty("ErrorMessage") || this.getProperty("SameInput")));
        },

        /**
         * Save department changes
         * @event
         * @public
         */
        onSaveDept: function () {
        	if (!this.getProperty("Input")) {
        		this.setProperty("EmptyInput", true);
        		this.setProperty("ErrorMessage", this.getText("MESSAGE_DEPT_EMPTY_NAME"));
	        	this.getDialog().getControlsByFieldGroupId("umEditDepartmentInput")[0].focus();
        		return;
        	}
        	var sDepartmentId = this.getProperty("DepartmentId"),
        		sDepartmentName = this.getProperty("DepartmentName"),
        		oEntry = {
        			DepartmentName: this.getProperty("Input")
        		};
        		
        	if (!sDepartmentId) {
        		this._getLogger.error("No department ID provided");
        	} else if (sDepartmentName === oEntry.DepartmentName) {
		        sap.m.MessageToast.show(this.getText("MESSAGE_NO_CHANGES"));
		        this.close();
        	} else {
        		var sPath = Util.formatMessage("/DepartmentNewSet(''{0}'')", [sDepartmentId]);
	        	this.setBusy(true);
	        	Util.promiseUpdate.call(this, sPath, oEntry)
	        		.then(function () {
		        		sap.m.MessageToast.show(this.getText("MESSAGE_DEPT_UPDATED"));
		        		this._getRequester().loadDepartments();
		        		this.close();
		        	}.bind(this))
	        		.finally(this.setBusy.bind(this, false));
        	}
        },
        
        /**
         * Set initial data
         * @param {string} sDepartmentId department ID
         * @param {string} sDepartmentName department name
         * @returns {sap.support.useradministration.controller.dialog.EditDepartmentNew} this for chaining
         * @function
         * @public
         */
        setInitialData: function (sDepartmentId, sDepartmentName) {
			var aExistingDeparmentList = sap.ui.getCore().byId("idListDepartmentList").getBinding("items").getContexts();
			this.setProperty("ExistingDepartmentNames", aExistingDeparmentList.map(function(oDepartment) {
				return {
					"name": oDepartment.getProperty("DepartmentName"),
					"id": oDepartment.getProperty("DepartmentId")
				};
			}));
			this.setProperty("DepartmentId", sDepartmentId);
        	this.setProperty("DepartmentName", sDepartmentName);
        	this.setProperty("Input", sDepartmentName);
			this.runInputChecks(sDepartmentName);
			
			return this;
        }
    });
});
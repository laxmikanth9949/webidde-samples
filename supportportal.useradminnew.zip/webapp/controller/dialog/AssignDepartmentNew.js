sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util"
], function(BaseDialog, Constant, Util) {
	
	var LIST = "List",
		SEARCH = "Search",
		USERS = "Users",
		VALUE_HELP_MODE = "ValueHelpMode";
	
	var Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator;
	
    var _fnFactory = function() {
        this[LIST] = [];
        this[SEARCH] = "";
        this[USERS] = [];
        this[VALUE_HELP_MODE] = false;
    };
    
    /**
     * Dialog for assigning departments using new department API
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.AssignDepartmentNew
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.AssignDepartmentNew", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "AssignDepartmentNew",
        
        /**
         * Perform a request to assign department
         * @param {string} sDepartmentId department ID
         * @param {string[]} aUsersIds users' IDs
         * @returns {Promise} promise
         * @function
         * @private
         */
        _assignDepartment: function (sDepartmentId, aUsersIds) {
        	var oModel = this.getModel(),
        		sBatchGroupId = "umAssignDepartment",
        		oParams = {
        			groupId: sBatchGroupId
        		};
        	
        	if (aUsersIds.length) {
        		oModel.setUseBatch(true);
        		oModel.setDeferredGroups([sBatchGroupId]);
        		
        		aUsersIds.forEach(function (sUserId) {
        			var sPath = Util.formatMessage("/MassDepartmentUpdateSet(UserId=''{0}'',DepartmentId=''{1}'')", [sUserId, sDepartmentId]);
        			
        			oModel.update(sPath, {
        				UserId: sUserId,
        				DepartmentId: sDepartmentId
        			}, oParams);
        		});
        		
        		var oPromise = Util.promiseSubmitChanges(oParams, oModel);
        		
        		oPromise.finally(function () {
        			oModel.setUseBatch(false);
        		});
        		return oPromise;
        	} else {
        		this._getLogger().error("No Users selected to assign department");
        		return Promise.resolve();
        	}
        },
        
        /**
         * Get department list
         * @returns {sap.m.List} list
         * @function
         * @private
         */
        _getList: function () {
        	return this.getDialog().getControlsByFieldGroupId("departmentList")[0];
        },
        
        /**
         * Process department list from backend
         * @param {object} oData backend response
         * @function
         * @private
         */
        _processDepartments: function (oData) {
        	var aList = oData && oData.results || [];
        	
        	this.setProperty(LIST, aList.map(function (oDept) {
        		return {
        			DepartmentId: oDept.DepartmentId,
        			DepartmentName: oDept.DepartmentName,
        			_UsersCount: 0
        		};
        	}));
        },
        
        /**
         * Load data before opening
         * @function
         * @public
         * @override
         */
        beforeOpen: function () {
        	this.loadDepartments();
        	this.onDeptSearch();
        },
        
        /**
         * Get value help mode (not to assign department, but just to provide department data)
         * @returns {boolean} if value help mode is active
         * @function
         * @public
         */
        isValueHelpMode: function () {
        	return this.getProperty(VALUE_HELP_MODE);
        },
        
        /**
         * Load department list from backend
         * @function
         * @public
         */
        loadDepartments: function () {
        	this.setBusy(true);
        	
        	Util.promiseRead.call(this, "/DepartmentNewSet")
        		.then(this._processDepartments.bind(this))
        		.catch(this._processDepartments.bind(this, {}))
        		.finally(this.setBusy.bind(this, false));
        },
        
        /**
         * Open add department dialog
         * @function
         * @private
         */
        onAddDepartment: function () {
        	this._oController._oDialogs.getDialog("AddDepartmentNew")
        		.clearData()
        		.syncStyleClass()
        		.open(this);
        },
        
        /**
         * Handle department search
         * @event
         * @public
         */
        onDeptSearch: function () {
        	var sQuery = this.getProperty(SEARCH),
        		aFilters = sQuery ? [new Filter("DepartmentName", FilterOperator.Contains, sQuery)] : [];
        		
        	this._getList().getBinding("items").filter(aFilters);
        },
        
        /**
         * Assign selected department to previously selected users
         * @param {sap.ui.base.Event} oEvent event data
         * @event 
         * @public
         */
        onSelectDepartment: function (oEvent) {
        	var oListItem = oEvent.getParameter("listItem"),
        		aUsersIds = this.getProperty(USERS),
        		oDepartment = oListItem.getBindingContext("dialog").getObject();
        	
        	if (this.isValueHelpMode()) {
        		this._getRequester().setNewDepartment(oDepartment.DepartmentId, oDepartment.DepartmentName);
        		this.close();
        	} else {
        		var formattedText = new sap.m.FormattedText("FormattedText", {
    				htmlText: this.getText(
    					"MESSAGE_CONFIRM_CHANGE_DEPARTMENTS", 
    					["<strong>" + oDepartment.DepartmentName + "</strong>",
    					"<strong>" + aUsersIds.length + "</strong>"])
        		});
	        	Util.showConfirmationPromiseBoxWithCustomAction(
	        		formattedText,
	        		this.getText("MASTER_DEPT_ASSIGN"),
	        		this.getText("BUTTON_ASSIGN")
	        	)
	        		.then(this.setBusy.bind(this, true))
	        		.then(this._assignDepartment.bind(this, oDepartment.DepartmentId, aUsersIds))
	        		.then(function (oData) {
						if (Util.getBatchMessage(oData) !== Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData)) {
		        			sap.m.MessageToast.show(this.getText("MESSAGE_DEPT_CHANGED"));
		        			this._oController.refreshUsers();
		        			this._oController._getUserTable().removeSelections();
							this._oController._setViewProperty("IsAnyUserSelected", false);
		        			this.close();
						}
	        		}.bind(this))
	        		.finally(this.setBusy.bind(this, false));
        	}
        },
        
        /**
         * Set value help mode (not to assign department, but just to provide department data)
         * @returns {sap.support.useradministration.controller.dialog.AssignDepartmentNew} this for chaining
         * @param {boolean} bValueHelpMode if value help mode is active
         * @function
         * @public
         */
        setValueHelpMode: function (bValueHelpMode) {
        	return this.setProperty(VALUE_HELP_MODE, !!bValueHelpMode);
        },
        
        /**
         * Set affected users' IDs
         * @param {string[]} aUsersIds users' IDs
         * @returns {sap.support.useradministration.controller.dialog.AssignDepartmentNew} this for chaining
         * @function
         * @public
         */
        setUsersIds: function (aUsersIds) {
        	return this.setProperty(USERS, aUsersIds);
        },
        
        onRemoveDepartment: function() {
        	var aSelectedIds = this.getProperty(USERS);
        	if (this.isValueHelpMode()) {
        		this._getRequester().setNewDepartment();
        		this.close();
        	} else {
        		var formattedText = new sap.m.FormattedText("FormattedText", {
    				htmlText: this.getText("MESSAGE_CONFIRM_REMOVE_DEPARTMENTS", ["<strong>" + aSelectedIds.length + "</strong>"])
        		});
			
        		Util.showWarningPromiseBox(
        			formattedText,
        			this.getText("MASTER_DEPT_REMOVE"),
        			this.getText("BUTTON_REMOVE"))
				.then(function () {
					var oModel = this.getModel(),
						sBatchGroupId = "umUnassignDepartment",
						oParams = {
							groupId: sBatchGroupId
						};

					this.setBusy(true);
					oModel.setUseBatch(true);
					oModel.setDeferredGroups([sBatchGroupId]);

					aSelectedIds.forEach(function (sUserId) {
						var sPath = Util.formatMessage("/MassDepartmentUpdateSet(UserId=''{0}'',DepartmentId='''')", [sUserId]);

						oModel.update(sPath, {
							UserId: sUserId,
							DepartmentId: ""
						}, oParams);
					});

					var oPromise = Util.promiseSubmitChanges(oParams, oModel);

					oPromise.finally(function () {
						oModel.setUseBatch(false);
					});
					return oPromise;
				}.bind(this))
				.then(function (oData) {
					if (Util.getBatchMessage(oData) !== Util.Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData)) {
						sap.m.MessageToast.show(this.getText("MESSAGE_DEPT_CHANGED"));
		        		this._oController.refreshUsers();
		        		this._oController._getUserTable().removeSelections();
						this._oController._setViewProperty("IsAnyUserSelected", false);
						this.close();
					}
				}.bind(this))
				.finally(this.setBusy.bind(this, false));
        	}
        }
    });
});
sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
    "sap/support/useradministration/util/Util"
], function(BaseDialogNew, Util) {
    var _fnFactory = function() {};
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.FilterExpDateHistory
     */
    return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.FilterExpDateHistory", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "FilterExpDateHistory",

        beforeOpen: function() {
	        this._loadProcessedByList();
	        this._prepareExpiryDateFilter();
	        this._prepareLastUpdateFilter();
        },
        
        _loadProcessedByList: function () {
        	var oExpDateHistory =  this.getRequester().getProperty("FullExpDateHistory");
			var oProcessors = [];
			var map = new Map();
			for (var item in oExpDateHistory) {
				if(!map.has(oExpDateHistory[item].ProcessorId)){
					map.set(oExpDateHistory[item].ProcessorId, true);
					oProcessors.push({
						ProcessorId: oExpDateHistory[item].ProcessorId,
						ProcessorName: oExpDateHistory[item].ProcessorName
					});
				}
			}
			this.setProperty("/Processor", oProcessors);
        },
        
        _prepareExpiryDateFilter: function() {
			var oMonthValues = {};
			var oCurDate = new Date();
			["1", "2", "3", "24", "60"].forEach(function (sMonths) {
				var oDate = new Date();
				oDate.setMonth(oDate.getMonth() - (parseInt(sMonths, 10) || 0));
				oMonthValues[sMonths] = "ExpirationDate___BT___" + Util.date.formatFilterDate(oDate) + "___" + Util.date.formatFilterDate(oCurDate);
			});
			oMonthValues["0"] = "ExpirationDate___GT___" + Util.date.formatFilterDate(oCurDate);
			this.setProperty("/ExpirationDate", oMonthValues);
        },
        
        _prepareLastUpdateFilter: function() {
			var oMonthValues = {};
			["1", "3", "6", "12", "60"].forEach(function (sMonths) {
				var oDate = new Date();
				oDate.setMonth(oDate.getMonth() - (parseInt(sMonths, 10) || 0));
				oMonthValues[sMonths] = "LastUpdate___GE___" + Util.date.formatFilterDate(oDate);
			});
			/*var oStartDate = new Date();
			oStartDate.setMonth(oStartDate.getMonth() - 12);
			oMonthValues["60"] = "LastUpdate___LT___" + Util.date.formatFilterDate(oStartDate); */
			this.setProperty("/LastUpdate", oMonthValues);
        },
        
        onSubmit: function(oEvent) {
			var oTable = this.getRequester().getTable();

			var mParams = oEvent.getParameters();
			
			var aFilters = (mParams.filterItems && mParams.filterItems.map(function (oItem) {
				var aSplit = oItem.getKey().split("___");
				var sPath = aSplit[0];
				var sOperator = aSplit[1];
				var sValue1 = aSplit[2];
				var sValue2 = aSplit[3];
				
				return new sap.ui.model.Filter(sPath, sOperator, sValue1, sValue2);
			})) || [];

			this.getRequester().requestExtensionHistoryCount(aFilters);
			this.getRequester().requestExtensionHistory(aFilters);
			// update filter bar
			oTable.getInfoToolbar().setVisible(aFilters.length > 0);
			oTable.getInfoToolbar().getContent()[0].setText(mParams.filterString);
        }
   
    });
});
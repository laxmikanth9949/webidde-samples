sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/util/Util"
], function(BaseDialog, Util) {
	
	var EDIT_MODE = "EditMode",
		LIST = "List",
		SEARCH = "Search";
		
	var MODEL_DIALOG = "dialog";
	
	var Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator;
	
    var _fnFactory = function() {
    	this[EDIT_MODE] = false;
        this[LIST] = [];
        this[SEARCH] = "";
    };
    
    /**
     * Dialog for managing departments using new department API
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.ManageDepartmentNew
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.ManageDepartmentNew", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "ManageDepartmentNew",
        
        /**
         * Get department list
         * @returns {sap.m.List} list
         * @function
         * @private
         */
        _getList: function () {
        	return this.getDialog().getControlsByFieldGroupId("departmentList")[0];
        },
        
        /**
         * Process department list from backend
         * @param {object} oData backend response
         * @function
         * @private
         */
        _processDepartments: function (oData) {
        	var aList = oData && oData.results || [];
        	
            try {
                // set empty array first to avoid strange standard error with JSON model update
                this.setProperty(LIST, []);
                this.setProperty(LIST, aList.map(function (oDept) {
                    return {
                        DepartmentId: oDept.DepartmentId,
                        DepartmentName: oDept.DepartmentName,
                        DepartmentCount: oDept.DepartmentCount || 0,
                        _DepartmentTempName: oDept.DepartmentName,
                        _IsEdited: false
                    };
                }));
            } catch (oError) {
            }
        },
        
        /**
         * Refresh users list after close
         * @function
         * @public
         * @override
         */
        afterClose: function () {
        	this._oController.refreshDepartmentsData(this.getProperty(LIST));
        },
        
        /**
         * Load data before opening
         * @function
         * @public
         * @override
         */
        beforeOpen: function () {
        	this.loadDepartments();
        	this.onDeptSearch();
        },
        
        /**
         * Load department list from backend
         * @returns {Promise} promise
         * @function
         * @public
         */
        loadDepartments: function () {
        	this.setBusy(true);
        	
        	return Util.promiseRead.call(this, "/DepartmentNewSet")
        		.then(this._processDepartments.bind(this))
        		.catch(this._processDepartments.bind(this, {}))
        		.finally(this.setBusy.bind(this, false));
        },
        
        /**
         * Open add department dialog
         * @function
         * @private
         */
        onAddDepartment: function () {
        	this._oController._oDialogs.getDialog("AddDepartmentNew")
        		.clearData()
        		.syncStyleClass()
        		.open(this);
        },
        
        
        /**
         * Handle delete department button click
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onDeleteDept: function (oEvent) {
        	var oContext = oEvent.getSource().getBindingContext(MODEL_DIALOG),
        		sDepartmentId = oContext.getProperty("DepartmentId");
        		
        	if (!sDepartmentId) {
        		this._getLogger.error("No department ID provided");
        	} else {
        		Util.showConfirmationPromiseBox(this.getText("MESSAGE_CONFIRM_DEPT_DELETION"))
        			.then(function () {
		        		var sPath = Util.formatMessage("/DepartmentNewSet(''{0}'')", [sDepartmentId]);
			        	this.setBusy(true);
			        	Util.promiseDelete.call(this, sPath)
			        		.then(function () {
				        		sap.m.MessageToast.show(this.getText("MESSAGE_DEPT_DELETED"));
				        		return this.loadDepartments();
				        	}.bind(this))
			        		.finally(this.setBusy.bind(this, false));
        			}.bind(this));
        	}
        },
        
        /**
         * Handle department search
         * @event
         * @public
         */
        onDeptSearch: function () {
        	var sQuery = this.getProperty(SEARCH),
        		aFilters = sQuery ? [new Filter("DepartmentName", FilterOperator.Contains, sQuery)] : [];
        		
        	this._getList().getBinding("items").filter(aFilters);
        },
        
        /**
         * Handle edit department button click
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onEditDepartment: function (oEvent) {
        	var oContext = oEvent.getSource().getBindingContext(MODEL_DIALOG),
        		oDepartment = oContext.getObject();
        	
        	this._oController._oDialogs.getDialog("EditDepartmentNew")
        		.clearData()
        		.setInitialData(oDepartment.DepartmentId, oDepartment.DepartmentName)
        		.syncStyleClass()
        		.open(this);
        }
    });
});
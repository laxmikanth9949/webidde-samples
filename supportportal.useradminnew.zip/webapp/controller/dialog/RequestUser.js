sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    "sap/support/useradministration/util/Settings",
    "sap/support/useradministration/util/Util",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function(BaseDialog, Settings, Util, Filter, FilterOperator) {
	"use strict";
	
    var _fnFactory = function() {
    	this.CustomerNumber = "";
    	this.CustomerSelectionDisabled = false;
    	this.CustomerText = "";
    	this.SalutationKey = "Mr";
    	this.FirstName = "";
    	this.LastName = "";
    	this.Email = "";
    	this.LanguageCode = Util.getSAPLogonLanguage();
    	this.Department = "";
    	this.DepartmentId = "";
    	this.APs = [];
    	
    	var oDate = new Date();
    	
    	this.MinExpiryDate = Util.date.getMinExpiryDate(Util.date.shiftDate(oDate, 0, 0, 1)); // 1 days after today
    	this.MaxExpiryDate = Util.date.shiftDate(oDate, Settings.maxYearsForUserCreation, 0, 0); // 2 years after today
    	this.DefaultExpiryDate = Util.date.shiftDate(oDate, Settings.prefilledYearsForUserCreation, 0, 0); // 2 years after today
    	this.SelectedExpiryDate = this.DefaultExpiryDate;
    	this.IsExpiryDateValid = true;
    	this.IsExpiryDateOverRange = false;
    	
    	this.IsValidEmail = true;
    	this.IsSharedEmail = false;
    	this.ValidationEmailText = Util.getText("MESSAGE_EMAIL_INVALID");
    	this.EmailLocalPart = "";
    	
    	this.IsSubmitBtnEnabled = true;
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.RequestUser
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.RequestUser", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "RequestUser",
        _aCustomerList: [],
        
        _beforeOpen: function() {
        	this._resetModel();
        },
        
        /**
         * Load customers data after opening then perform a check if only one customer is present
         * @function
         * @private
         * @override
         */
        _afterOpen: function () {
        	if (!this._aCustomerList.length) {
        		this.setBusy(true);
				Util.promiseRead.call(this, "/CustomerSet")
					.then(function (oData) {
						this._aCustomerList = oData.results.slice();
						this._checkForSingleCustomer();
					}.bind(this))
					.finally(this.setBusy.bind(this, false));
        	}
        	this._checkForSingleCustomer();
        },
        
        /**
         * Check if only one customer is present
         * If yes, pick this one then disable selection box
         * @function
         * @private
         */
        _checkForSingleCustomer: function () {
        	if (this._aCustomerList.length === 1) {
        		var oCustomer = this._aCustomerList[0];
        		this.setCustomer(oCustomer.Kunnr, oCustomer.Name1 + " (" + oCustomer.Kunnr + ")");
        		this._setDialogProperty("CustomerSelectionDisabled", true);
        	}
        },
        
        /**
         * Check if requested user is not exists in the system
         * @param {object} oUserData requested user's data
         * @property {string} oUserData.CustomerNumber requested user's customer number
         * @property {string} oUserData.Email requested user's email address
         * @returns {Promise} resolved if no duplication found
         * @function
         * @public
         */
        _checkUserDuplication: function (oUserData) {
        	var sCustomerNumberForFilter = Util.normalizeCustomerNumber(oUserData.CustomerNumber),
        		sEmail = oUserData.Email,
        		oParams = {
					filters: [
						new Filter("Kunnr", FilterOperator.EQ, sCustomerNumberForFilter),
						new Filter("Ipadr", FilterOperator.EQ, sEmail)
					]
	        	};
        	
        	return Util.promiseRead.call(this, "/UserSet", oParams)
        		.then(function (oData) {
        			if (oData.results.length > 0) {
        				Util.showErrorBox(this.getText("REQUEST_USER_DUPLICATION_ERROR"));
        				throw new TypeError("User Duplication");
        			}
        		}.bind(this));
        },
        
        /**
         * Submit a request to create new user
         * @param {object} oUserData requested user's data
         * @property {string} oUserData.CustomerNumber requested user's customer number
         * @property {string} oUserData.Email requested user's email address
         * @property {string} oUserData.FirstName requested user's first name
         * @property {string} oUserData.FirstName requested user's first name
         * @property {string} oUserData.LanguageCode requested user's language code, e.g. FR
         * @property {string} [oUserData.Department] requested user's department name
         * @property {string[]} [oUserData.APs] requested user's authorization packages IDs
         * @returns {Promise} resolved on successful request
         * @function
         * @public
         */
        _createUser: function (oUserData) {
			var	oEntry = {
    			Kunnr: oUserData.CustomerNumber,
    			Anred: oUserData.SalutationKey,
    			Name1: Util.trimString(oUserData.LastName),
    			Namev: Util.trimString(oUserData.FirstName),
    			Ipadr: oUserData.Email,
    			ParlaExt: oUserData.LanguageCode,
    			Department: unescape(oUserData.Department),
    			DepartmentId: oUserData.DepartmentId || ""
    		};
        		
        	if (oUserData.APs && oUserData.APs.length) {
        		oEntry.AuthPackages = oUserData.APs.join("|");
        	}
        	
        	if (this._getSettings().isSUserLifetimeEnabled && !Util.date.isSameDay(oUserData.SelectedExpiryDate, oUserData.DefaultExpiryDate)) {
        		oEntry.ExpDate = Util.date.dateToUTCDate(oUserData.SelectedExpiryDate);
        	}
        	
        	return Util.promiseCreate.call(this, "/UserSet", oEntry)
        		.then(this._handleRequestSuccess.bind(this))
        		.catch(this._handleRequestError.bind(this));
        },
        
        /**
         * Handle error request
         * @param {object} oXhr request object
         * @function
         * @private
         */
        _handleRequestError: function(/* oXhr */) {
        	
        	//I521000 - error message is already displayed in odata model request failed event handler, check Model.js _fnShowDialog
        	/*var oError = Util.parseError(oXhr),
        		sMessage = this.getText(oError.getCode() + "_TITLE");
        		
        	Util.showErrorBox(sMessage);
        	this.close();*/
        },
        
        /**
         * Handle success request
         * @function
         * @private
         */
        _handleRequestSuccess: function() {
        	sap.m.MessageBox.show(this.getText("REQUEST_NEW_USER_CREATE_SUCCESS2"), {
        		title: this.getText("REQUEST_NEW_USER_CREATE_SUCCESS")
        	});
        	this.close();
        	
        	this.getModel().refresh();
        	
        	this.getRequester()._invalidateTabs(["RequestedUsers"]);
        	//Update launchpad KPIs
			sap.ui.getCore().getEventBus().publish("landingpage", "refresh", {
				source: "useradminnew",
				target: "userManagement"
			});
        },
        
		/**
		 * Open new Department Value Help
		 * @event
		 * @public
		 */
		onDepartmentNewValueHelp: function () {
			this._oController.getDialog("AssignDepartmentNew").clearData().setValueHelpMode(true)
				.syncStyleClass().open(this);
		},
		
		/**
		 * Handle expiry date change on user interaction
		 * Update valid state
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onExpiryDateChange: function (oEvent) {
			var sNewValue = oEvent.getParameter("newValue"),
				bValid =  oEvent.getParameter("valid") && sNewValue;
		
			this._setDialogProperty("IsExpiryDateValid", !!bValid);
		},
		
		/**
		 * Trim extra spaces in first or last name
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onNameChange: function (oEvent) {
			var oSource = oEvent.getSource(),
				oBinding = oSource.getBinding("value");
				
			oBinding.getModel().setProperty(oBinding.getPath(), Util.trimString(oBinding.getValue()), oBinding.getContext());
		},
        
        /**
         * Handle Submit button press
         * Check for user duplication. If not, create a user
         * @event
         * @public
         */
        onSubmit: function() {
        	var oData = this.getProperty("");
        	
        	this.setProperty("IsSubmitBtnEnabled", false);
        	this.setBusy(true);
        	//this._checkUserDuplication(oData)
        		//.then(this._createUser.bind(this, oData))
        	this._createUser(oData)
        		.catch(function (oError) {
        			this.log.error("Error: " + (oError && oError.message));
        		}.bind(this))
        		.finally(function(){
        			this.setBusy(false);
        			this.setProperty("IsSubmitBtnEnabled", true);
        		}.bind(this));
        },
        
        /**
         * Open Customers F4 Help
         * @event
         * @public
         */
        openCustomerValueHelp: function() {
        	this._oController.getDialog("SelectUserCustomer")
        		.syncStyleClass()
        		.open(this);
        },
        
        /**
         * Open Department F4 Help
         * @event
         * @public
         */
        openDepartmentValueHelp: function() {
        	this._oController.getDialog("SelectUserDepartment")
        		.setValueHelpMode(true)
        		.syncStyleClass()
        		.open(this);
        },
        
        /**
         * Set department
         * @param {string} sDeptName department name
         * @function
         * @public
         */
        selectDepartment: function(sDeptName) {
        	this._setDialogProperty("Department", sDeptName || "");
        },
        
        /**
         * Set customer
         * @param {string} sCustNum customer number
         * @param {string} sCustText customer text
         * @function
         * @public
         */
        setCustomer: function(sCustNum, sCustText) {
        	this._setDialogProperty("CustomerNumber", sCustNum || "");
        	this._setDialogProperty("CustomerText", sCustText || "");
        },
		
		/**
		 * Set deparment got from the Assign Department Dialog
		 * @param {string} sDepartmentId department id
		 * @param {string} sDepartmentName department name
		 * @function
		 * @public
		 */
		setNewDepartment: function (sDepartmentId, sDepartmentName) {
			this._setDialogProperty("DepartmentId", sDepartmentId || "");
			this._setDialogProperty("Department", sDepartmentName || "");
		},
		
		/**
		 * Validate user's Email
		 * @param {object} oEvent live change event
		 * @function
		 * @public
		 */
		validateEmail: function(oEvent) {
			var sEmail = oEvent.getSource().getValue(),
				emailRegexp = this.getView().getModel("appSettings").oData.emailRegexp,
				isValid = Util.detail.validateEmail(sEmail,	emailRegexp),
				sLocalPart = sEmail.split("@")[0].toUpperCase();
			if (!isValid) {
				this._setDialogProperty("ValidationEmailText", this.getText("MESSAGE_EMAIL_INVALID"));
				this._setDialogProperty("IsValidEmail", isValid && !this._getDialogProperty("IsSharedEmail"));
				return;
			}
			if(!this._getSettings().isSharedEmailCheckEnabled) {
				this._setDialogProperty("IsValidEmail", isValid);
				return;
			}
			if (this._getDialogProperty("EmailLocalPart") !== sLocalPart) {
				this._setDialogProperty("EmailLocalPart", sLocalPart);
				this._setDialogProperty("ValidationEmailText", this.getText("MESSAGE_SHARED_EMAIL"));
				Util.promiseRead.call(this, "/SharedMailsSet", {
					filters: [new Filter("EMail", FilterOperator.EQ, sLocalPart)]
				})
				.then(function (oData) {
					var aSharedEmailList = oData.results;
					this._setDialogProperty("IsSharedEmail", aSharedEmailList.length > 0);
					this._setDialogProperty("IsValidEmail", isValid && !this._getDialogProperty("IsSharedEmail"));
				}.bind(this));
			} else {
				this._setDialogProperty("ValidationEmailText", this.getText("MESSAGE_SHARED_EMAIL"));
				this._setDialogProperty("IsValidEmail", isValid && !this._getDialogProperty("IsSharedEmail"));
			}
		},
		
		onEmailIconPress: function(oEvent) {
			if (!this._oEmailValidationPopover) {
				this._oEmailValidationPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.EMailValidationPopover", this);
				this._oEmailValidationPopover.setModel(this.getModel("i18n"), "i18n");
			}
			this._oEmailValidationPopover.setPlacement(sap.m.PlacementType.Right);
			this._oEmailValidationPopover.openBy(oEvent.getSource());
		}
    });
});
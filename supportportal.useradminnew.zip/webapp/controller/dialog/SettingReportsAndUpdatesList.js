sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SettingReportsAndUpdatesList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SettingReportsAndUpdatesList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SettingReportsAndUpdatesList",
        
        onSubmit: function(oEvent) {
        	this._getRequester()._tableSettingsChange(oEvent, "idUserSettingsTableGroup5", "idUserReportTable");
        },
        
        onCancel: function() {
        	this.close();
        }
   
    });
});
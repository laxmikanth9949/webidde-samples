sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",

	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function(BaseDialog, Constant, Util, Filter, FilterOperator) {
	var _fnFactory = function() {
		this.Search = "";
	};

	/**
	 * Dialog for assigning authorization packages to user
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseDialog
	 * @alias sap.support.useradministration.controller.dialog.AssignDepartmentToUser
	 */
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.AssignDepartmentToUser", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "AssignDepartmentToUser",
		
		beforeOpen: function() {
			this.loadDepartments();
		},

		_getList: function () {
			return this._oDialog.getContent()[0];
		},
		
		onSearch: function() {
			var itemsLength = this._getList().getBinding("items").oList.length;
			this.getDialog().setContentHeight(itemsLength*2+"rem");
            var sValue = this.getProperty("Search"),
                aFilters = sValue ? [new Filter("DepartmentName", FilterOperator.Contains, sValue)] : [];
            this._getList().getBinding("items").filter(aFilters);
        },
        
        onDepartmentPress: function (oEvent) {
        	var oDepartment = oEvent.getSource().getBindingContext("dialog").getObject();
        	
        	if (this._getRequester().setDepartment) {
        		this._getRequester().setDepartment(oDepartment.DepartmentId, oDepartment.DepartmentName);
        	}
        	this.close();
        },
        
        onAssign: function () {
        	var oDepartment = this._getList().getSelectedItem().getBindingContext().getObject();
        	if (this._getRequester().setDepartment) {
        		this._getRequester().setDepartment(oDepartment.DepartmentId, oDepartment.DepartmentName);
        	}
        	this.close();
        },

		onClose: function() {
			this.close();
		},
		
		onAddDepartment: function () {
        	this._oController._oDialogs.getDialog("AddDepartmentNew")
        		.clearData()
        		.syncStyleClass()
        		.open(this);
        },
        
        loadDepartments: function () {
        	this.setBusy(true);
        	
        	return Util.promiseRead.call(this, "/DepartmentNewSet")
        		.then(this._processDepartments.bind(this))
        		.catch(this._processDepartments.bind(this, {}))
        		.finally(this.setBusy.bind(this, false));
        },
        
        _processDepartments: function (oData) {
        	var aList = oData && oData.results || [];
        	
        	this.setProperty("List", aList.map(function (oDept) {
        		return {
        			DepartmentId: oDept.DepartmentId,
        			DepartmentName: oDept.DepartmentName,
        			DepartmentCount: oDept.DepartmentCount || 0,
        			_DepartmentTempName: oDept.DepartmentName,
        			_IsEdited: false
        		};
        	}));
        }
	});
});
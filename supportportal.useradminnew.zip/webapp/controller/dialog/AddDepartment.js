sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    "sap/support/useradministration/model/Constant"
], function(BaseDialog, Constant) {
    var _fnFactory = function() {
        this.Input = "";  
    };
    
    /**
     * Dialog for adding new department
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.AddDepartment
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.AddDepartment", {
        _fnDataFactory: _fnFactory,
        _sDialogName: Constant.Dialog.ADD_DEPT,
        
        /**
         * Get input control
         * @returns {sap.m.Input} input
         * @function
         * @private
         */
        _getInputControl: function() {
            return this.getDialog().getContent()[0];
        },
        
        /**
         * Handle saving new department
         * @event
         * @public
         */
        onSaveDept: function() {
            var sInput = this._getDialogProperty("Input");
            var oParent = this._oParentDialog;
            this._oController.handleAssignDept(sInput);
            this.close();
            if (oParent) {
                oParent.close();
            }
        }
    });
});
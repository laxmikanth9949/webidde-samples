sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    "sap/support/useradministration/model/Constant",
    "sap/support/useradministration/util/Util",
    
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast"
], function(BaseDialog, Constant, Util, Filter, FilterOperator, MessageToast) {
    var _fnFactory = function() {
    	this.InitialIds = [];
    	this.InactiveIds = [];
    	this.List = [];
        this.Search = "";
        this.UserId = "";
    };
    
    /**
     * Dialog for assigning authorization packages to user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.AssignUserAuthPackages
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.AssignUserAuthPackages", {
        _fnDataFactory: _fnFactory,
        _sDialogName: Constant.Dialog.ASSIGN_USER_APS,
        
        /**
         * Do things before open
         * @function
         * @private
         * @override
         */
        _beforeOpen: function () {
        	this.setBusy(true);
        	this._loadAuthPackagesList().finally(this.setBusy.bind(this, false));
        },
        
        /**
         * Get list with APs
         * @returns {sap.m.ListBase} list
         * @function
         * @private
         */
        _getList: function() {
            return sap.ui.getCore().byId("assignUserAPDialogList");
        },
        
        /**
         * Load available authorization packages
         * @returns {Promise} promise
         * @function
         * @private
         */
        _loadAuthPackagesList: function () {
        	this.setProperty("List", []);
        	return Util.promiseRead("/auth_pack_for_custSet", {}, this._oView.getModel("ap"))
        		.then(function (oData) {
        			var aPackages = oData.results || [],
        				aInitialSelection = this.getProperty("InitialIds") || [],
        				aInactiveSelection = this.getProperty("InactiveIds") || [];
        			
        			this.setProperty("List", aPackages.map(function (oPackage) {
        				return Util.merge({}, oPackage, {
        					IsAssigned: aInitialSelection.indexOf(oPackage.AuthPackId) !== -1,
        					IsBlocked: aInactiveSelection.indexOf(oPackage.AuthPackId) !== -1
        				});
        			}));
        		}.bind(this));
        },
        
        /**
         * Reset list filter
         * @returns {object} promise
         * @function
         * @private
         */
        _resetFilter: function() {
            var oBinding = this._getList().getBinding("items"),
                oPromise = $.Deferred();
            
            oBinding.attachEventOnce("dataReceived", function(oEvent) {
                if (oEvent.getParameter("data")) {
                    oPromise.resolve();
                } else {
                    oPromise.reject();
                }
            });
            oBinding.filter([]);
            return oPromise.promise();
        },
        
        /**
         * Send authorization packages data to backend
         * @param {boolean} bForceUpdate create requests for already exisiting or non-exisiting APs
         * @returns {object} promise
         * @function
         * @private
         */
        _sendAPData: function(bForceUpdate) {
            var BATCH_GROUP_ID = "idAssignUserAPs";
            var that = this,
                oPromise = $.Deferred(),
                aItems = this._getList().getItems(),
                sUserId = this._getDialogProperty("UserId"),
                oAPModel = this._oView.getModel("ap"),
                bHasUpdates = false,
                oModelParameters = {
                    batchGroupId: BATCH_GROUP_ID
                };
            var oMessageText;    
            
            oAPModel.setUseBatch(true);
            oAPModel.setDeferredGroups([BATCH_GROUP_ID]);
            aItems.forEach(function(oItem) {
                var sAuthPackId = oItem.getBindingContext("ap").getProperty("AuthPackId"),
                    sURI = Util.formatMessage("/auth_pack_set_for_userSet(AuthPackId=''{0}'',SUser=''{1}'')", [sAuthPackId, sUserId]),
                    bPropertyExists = Boolean(oAPModel.getProperty(sURI));
                
                if (oItem.getSelected()) {
                    if (bForceUpdate || !bPropertyExists) {
                        oAPModel.update(sURI, {
                            SUser: sUserId,
                            AuthPackId: sAuthPackId
                        }, oModelParameters);
                        bHasUpdates = true;
                        oMessageText = that.getText("MESSAGE_AP_ASSIGNED");
                    }
                } else if (bForceUpdate || bPropertyExists) {
                    oAPModel.remove(sURI, oModelParameters);
                    bHasUpdates = true;
                    oMessageText = that.getText("MESSAGE_AP_REMOVED");
                }
            });
            
            if (bHasUpdates) {
                oAPModel.submitChanges({
                    batchGroupId: BATCH_GROUP_ID,
                    success: function() {
                        MessageToast.show(oMessageText);
    					oAPModel.setUseBatch(false);
    					oAPModel.refresh();
    					oPromise.resolve();
                    },
                    error: function(oXhrError) {
    				    var sResponseText = oXhrError.responseText,
    				        oError = JSON.parse(sResponseText);
    				    MessageToast.show(oError.error.message.value);
    				    oAPModel.setUseBatch(false);
    				    oPromise.reject();
                    }
                });
            } else {
                oPromise.resolve();
            }
            return oPromise.promise();
        },
        
        /**
         * Load user's APs then update list selections
         * @returns {object} promise
         * @function
         * @private
         */
        _updateAuthorizations: function() {
            var oPromise = $.Deferred(),
                that = this;
            this._oView.getModel("ap").read(Constant.APModel.AUTH_PACK_FOR_USER, {
                filters: [new Filter("SUser", FilterOperator.EQ, this._getDialogProperty("UserId"))],
                success: function(oData) {
                    that._updateSelections(oData && oData.results || []);
                    oPromise.resolve();
                },
                error: function() {
                    oPromise.reject();
                }
            });
            return oPromise.promise();
        },
        
        /**
         * Update list selections according to backend data
         * @param {object[]} aSelectedAPs selected authorization packages
         * @function
         * @private
         */
        _updateSelections: function(aSelectedAPs) {
            var oList = this._getList(),
                oBinding = oList.getBinding("items"),
                aContextPaths = aSelectedAPs.map(function(oAP) {
                	return Util.formatMessage("/auth_pack_for_custSet(''{0}'')", [oAP.AuthPackId]);
                });
            
            oList.setSelectedContextPaths(aContextPaths);
            oBinding.refresh();
        },
        
        /**
         * Remove filters and close dialog
         * @function
         * @public
         * @override
         */
        close: function() {
            var oList = this._getList();
            oList.setSelectedContextPaths([]);
            oList.getBinding("items").filter([]);
            this._resetModel();
            BaseDialog.prototype.close.call(this);
        },
        
        /**
         * Handles authorization package search
         * @event
         * @public
         */
        onAPSearch: function() {
        	var itemsLength = this._getList().getBinding("items").oList.length;
			this.getDialog().setContentHeight(itemsLength*2+"rem");
            var sValue = this.getProperty("Search"),
                aFilters = sValue ? [new Filter("Text", FilterOperator.Contains, sValue)] : [];
            this._getList().getBinding("items").filter(aFilters);
        },
        
        /**
         * Save selections to controller
         * @event
         * @public
         */
        onApplySelections: function () {
        	if (this._getRequester().setAssignedAuthorizationPackages) {
        		this._getRequester().setAssignedAuthorizationPackages(this.getProperty("List").filter(function (oPackage) {
        			return oPackage.IsAssigned;
        		}));
        	}
        	this.close();
        },
        
        /**
         * Assign or unassign authorization packages according to selections
         * @event
         * @public
         */
        onAssignAP: function() {
            this.setBusy(true);
            this._resetFilter()
                .then(this._sendAPData.bind(this))
                .then(this.close.bind(this))
                .always(this.setBusy.bind(this, false));
        },
        
        /**
         * Loads user's authorizations
         * @event
         * @public
         */
        onDialogOpen: function() {
            this.setBusy(true);
            this._updateAuthorizations()
                .always(this.setBusy.bind(this, false));
        },
        
        /**
         * Set initially selected auth packages
         * @param {string[]} aSelectedIds AP ids
         * @returns {sap.support.useradministration.controller.dialog.AssignUserAuthPackages} this for chaining
         * @function
         * @public
         */
        setInitialSelection: function (aSelectedIds, aInactiveIds) {
        	this.setProperty("/InitialIds", aSelectedIds);
        	this.setProperty("/InactiveIds", aInactiveIds);
        	return this;
        },
        
        /**
         * Set User Id
         * @param {string} sUserId user Id
         * @function
         * @public
         */
        setUserId: function(sUserId) {
            this._setDialogProperty("UserId", sUserId);
        }
    });
});
sap.ui.define([
	"sap/support/useradministration/controller/dialog/SmartValueHelpDialog",
	"sap/support/useradministration/extended/enums/CloudAuthorizationLevel"
], function(SmartValueHelpDialog, CloudAuthorizationLevel) {
	"use strict";
	
	/**
	 * Dialog for resticted installations of cloud authorization selection
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.SmartValueHelpDialog
	 * @alias sap.support.useradministration.controller.dialog.SelectRestrictedCloudInstallations
	 */
	return SmartValueHelpDialog.extend("sap.support.useradministration.controller.dialog.SelectRestrictedCloudInstallations", {
		_sDialogName: "SelectRestrictedCloudInstallations",
		_sModelName: "ca",
		_sPath: "/xSVTxC_InstallAuthAssign",

		/**
		 * Handle dialog confirmation
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onConfirm: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens"),
			    aItems = this._getItemsByTokens(aTokens);
			
			if (this._getRequester().saveLevel) {
			    this._getRequester().saveLevel(CloudAuthorizationLevel.Installation, aItems);
			}
			this.close();
		},
		
		/**
		 * Set context
		 * @param {string} sUserId user ID
		 * @param {String} sObjectId authorization object ID
		 * @function
		 * @public
		 */
		setContext: function(sUserId, sObjectId) {
			this._sPath = jQuery.sap.formatMessage("/xSVTxC_InstallAuthAssign(sUser=''{0}'',authObject=''{1}'')/Set", [sUserId, sObjectId]);
			this.invalidate();
		}
	});
});
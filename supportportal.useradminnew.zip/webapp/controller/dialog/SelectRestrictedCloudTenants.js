sap.ui.define([
	"sap/support/useradministration/controller/dialog/SmartValueHelpDialog",
	"sap/support/useradministration/extended/enums/CloudAuthorizationLevel"
], function(SmartValueHelpDialog, CloudAuthorizationLevel) {
	"use strict";
	
	var PATH = "/xSVTxC_TenantAuthAssign";
	
	/**
	 * Dialog for resticted tenants of cloud authorization selection
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.SmartValueHelpDialog
	 * @alias sap.support.useradministration.controller.dialog.SelectRestrictedCloudTenants
	 */
	return SmartValueHelpDialog.extend("sap.support.useradministration.controller.dialog.SelectRestrictedCloudTenants", {
		_sDialogName: "SelectRestrictedCloudTenants",
		_sModelName: "ca",
		_sPath: PATH,

		/**
		 * Handle dialog confirmation
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onConfirm: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens"),
			    aItems = this._getItemsByTokens(aTokens);
			
			if (this._getRequester().saveLevel) {
			    this._getRequester().saveLevel(CloudAuthorizationLevel.Tenant, aItems);
			}
			this.close();
		},
		
		/**
		 * Set context
		 * @param {string} sUserId user ID
		 * @param {String} sObjectId authorization object ID
		 * @function
		 * @public
		 */
		setContext: function(sUserId, sObjectId) {
			this._sPath = jQuery.sap.formatMessage(PATH + "(sUser=''{0}'',authObject=''{1}'')/Set", [sUserId, sObjectId]);
			this.invalidate();
		}
	});
});
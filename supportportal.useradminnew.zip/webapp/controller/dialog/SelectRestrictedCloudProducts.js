sap.ui.define([
	"sap/support/useradministration/controller/dialog/SmartValueHelpDialog",
	"sap/support/useradministration/extended/enums/CloudAuthorizationLevel",
	
    "sap/m/Token"
], function(SmartValueHelpDialog, CloudAuthorizationLevel, Token) {
	"use strict";
	
	var PATH = "/xSVTxC_ProdAuthAssign";
	
	/**
	 * Dialog for resticted products of cloud authorization selection
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.SmartValueHelpDialog
	 * @alias sap.support.useradministration.controller.dialog.SelectRestrictedCloudProducts
	 */
	return SmartValueHelpDialog.extend("sap.support.useradministration.controller.dialog.SelectRestrictedCloudProducts", {
		_sDialogName: "SelectRestrictedCloudProducts",
		_sModelName: "ca",
		_sPath: PATH,
		
		/**
		 * Get key for product
		 * @param {object} oProduct product
		 * @returns {string} key
		 * @function
		 * @private
		 */
		_getProductKey: function(oProduct) {
			return oProduct.InstProdDescr + "\n" + oProduct.CustomerId;
		},
		
		/**
		 * Get text for product token
		 * @param {object} oProduct product
		 * @returns {string} text
		 * @function
		 * @private
		 */
		_getProductTokenText: function(oProduct) {
			return oProduct.InstProdDescr + " (" + oProduct.CustomerId + ")";
		},
		
		/**
		 * Extend Product with new properties
		 * @param {object} oProduct product
		 * @returns {object} extended product
		 * @function
		 * @private
		 * @override
		 */
		_extendItem: function(oProduct) {
			return jQuery.extend(true, {}, oProduct, {
				_sKey: this._getProductKey(oProduct),
				_sDescr: this._getProductTokenText(oProduct)
			});
		},
		
		/**
		 * Handle dialog confirmation
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onConfirm: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens"),
			    aItems = this._getItemsByTokens(aTokens);
			
			if (this._getRequester().saveLevel) {
			    this._getRequester().saveLevel(CloudAuthorizationLevel.Product, aItems);
			}
			this.close();
		},
		
		/**
		 * Set context
		 * @param {string} sUserId user ID
		 * @param {String} sObjectId authorization object ID
		 * @function
		 * @public
		 */
		setContext: function(sUserId, sObjectId) {
			this._sPath = jQuery.sap.formatMessage(PATH + "(sUser=''{0}'',authObject=''{1}'')/Set", [sUserId, sObjectId]);
			this.invalidate();
		},
		
        /**
         * Set tokens using context objects
         * @param {object[]} aObjects objects
         * @function
         * @public
         */
        updateTokens: function(aObjects) {
        	var oDialog = this.getDialog(),
        		aTokens = [];
        	if (aObjects) {
        		aTokens = aObjects.map(function (oObject) {
        			return new Token({
        				key: this._getProductKey(oObject),
        				text: this._getProductTokenText(oObject)
        			});
        		}.bind(this));
        	}
            oDialog.setTokens([]);
            oDialog.setTokens(aTokens);
        }
	});
});
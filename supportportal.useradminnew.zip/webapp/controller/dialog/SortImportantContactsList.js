sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SortImportantContactsList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SortImportantContactsList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SortImportantContactsList",
        
        onSubmit: function(oEvent) {
        	var mParams = oEvent.getParameters();
			var oBinding = this._oView.byId("idImportantContactsTable").getBinding("items");
			var aSorters = [];
			
			if (mParams.sortItem) {
				var sPath = mParams.sortItem.getKey();
				var bDescending = mParams.sortDescending;
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
				oBinding.sort(aSorters);
			}
        }
   
    });
});
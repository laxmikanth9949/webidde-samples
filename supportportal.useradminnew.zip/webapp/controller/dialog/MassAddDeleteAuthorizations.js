sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialog",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",

	"sap/m/MessageBox"
], function(BaseDialog, Constant, Util, MessageBox) {
	var _fnFactory = function() {
		this.DeleteMode = false;
		this.Items = [];
		this.UsersIds = [];
	};

    var Callbacks = Util.callbacks;
    
	var BATCH_GROUP_ID = "idMassAuthObjAssignGroup",
	    DETAIL_PAGE = "umMassAddAuthDialogDetailPage";
	
	var CLEAR_OBJECT_REGEX = /^_([^_]|$)/;

	/**
	 * Dialog for mass adding of authorizations at the Reports and Updates tab
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseDialog
	 * @alias sap.support.useradministration.controller.dialog.MassAddDeleteAuthorizations
	 */
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.MassAddDeleteAuthorizations", {
		_fnDataFactory: _fnFactory,
		_bSyncStyleClass: true,
		_sDialogName: "MassAddDeleteAuthorizations",
		
		/**
		 * Clear object from aggregations and properties added locally
		 * @param {object} oObject object 
		 * @function
		 * @private
		 */
		_clearObject: function(oObject) {
            jQuery.each(oObject, function (sKey, vValue) {
                if (CLEAR_OBJECT_REGEX.test(sKey) || (vValue instanceof Object)) {
                    delete oObject[sKey];
                }
            });
		},

		/**
		 * Starts a backend request to save dialog data
		 * @param {object[]} aObjects auth objects
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_doRequest: function(aObjects, oModel) {
		    var aTopLevelObjects = aObjects.filter(function (oObject) {
		            return oObject._isGrantedToAll;
		        }),
		        aLowLevelObjects = aObjects.filter(function (oObject) {
		            return oObject._isRestricted;
		        }),
		        aUsersIds = this._getUsersIds() || [],
		        bDeleteMode = this.isDeleteMode();
		    
		    // If nothing to save
		    if (!(aTopLevelObjects.length || aLowLevelObjects.length) || !aUsersIds) {
		        return this._getPromise().resolve({}).promise();
		    }
		    
    	    oModel.setUseBatch(true);
    	    oModel.setDeferredBatchGroups([BATCH_GROUP_ID]);
    	    
            aUsersIds.forEach(function (sUserId) {
                aTopLevelObjects.forEach(this._updateSingleTopLevelAuth.bind(this, oModel, sUserId, bDeleteMode));
                aLowLevelObjects.forEach(this._updateSingleLowLevelAuth.bind(this, oModel, sUserId, bDeleteMode));
            }.bind(this));
            
    	    return this._oController._submitChanges({batchGroupId: BATCH_GROUP_ID});
		},

		/**
		 * Save dialog
		 * @param {object[]} aObjects auth objects
		 * @function
		 * @private
		 */
		_doSave: function(aObjects) {
		    var oModel = this._oController.getModel();
		    
			this.setBusy(true);
			this._doRequest(aObjects, oModel)
    	        .then(function (oData) {
    	            if (Util.getBatchMessage(oData) !== Constant.HTTP_REQUEST_FAILED) {
    	                sap.m.MessageToast.show(this.getText("MESSAGE_MASS_AUTH_REQUEST_SENT_SUCCESSFULLY"));
    	                // this._oController.refreshReportsAndUpdates();
    	            }
    	        }.bind(this))
    	        .always(function() {
    	            this.close();
    	            this.setBusy(false);
    	            oModel.setUseBatch(false);
    	        }.bind(this));
		},

		/**
		 * Extend authorization object with additional properties
		 * @param {object} oAuthObject auth object
		 * @returns {object} extended object
		 * @function
		 * @private
		 */
		_extendAuthObject: function(oAuthObject) {
			var oAuth = jQuery.extend(true, {}, oAuthObject);
			return jQuery.extend(oAuth, {
				_aCustomers: [],
				_aInstallations: [],
				_isHeader: /^G_/.test(oAuth.ObjectId),
				_isGrantedToAll: false,
				_isGroupHeader: /^G_/.test(oAuth.ObjectId) && oAuth.ObjectId !== Constant.AuthGroup.ALL,
				_isTopHeader: oAuth.ObjectId === Constant.AuthGroup.ALL,
				_isRestricted: false,
				_isSelected: false,
				_hasCustomerLevel: this.formatter.detail.isAuthTopLevelCCC(oAuth.TopLevel),
				_hasInstallationLevel: oAuth.AuthLevelId === Constant.AuthLevelId.INSTALL,
				_hasLowLevel: this.formatter.master.isAuthWithLowLevel(oAuth.AuthLevelId),
				_hasUserLevel: oAuth.AuthLevelId === Constant.AuthLevelId.USER,
				_sURI: oAuth.__metadata.uri
			});
		},

		/**
		 * Get all auth items
		 * @returns {object[]} auth objects list
		 * @function
		 * @private
		 */
		_getAllItems: function() {
			return this._getDialogProperty("Items") || [];
		},

		/**
		 * Get binding context for detail view
		 * @returns {sap.ui.model.Context} context
		 * @function
		 * @private
		 */
		_getDetailContext: function() {
			var oPage = this._getNavContainer().getPage(DETAIL_PAGE);
			return oPage && oPage.getBindingContext("dialog");
		},
		
		/**
		 * Get navigation container
		 * @return {sap.m.NavContainer} container
		 * @function
		 * @private
		 */
		_getNavContainer: function() {
			return sap.ui.getCore().byId("umMassAddAuthNavContainer");
		},

		/**
		 * Get children for given header authorization
		 * @param {object} oAuth authorization
		 * @returns {object[]} children list
		 * @function
		 * @private
		 */
		_getChildrenFor: function(oAuth) {
			return this._getAllItems().filter(function(oInner) {
				if (oAuth._isGroupHeader) {
					return oAuth.ObjectId === oInner.AuthObjectGroup && !oInner._isHeader;
				}
				return oInner._isGroupHeader;
			});
		},

		/**
		 * Get parent for given non-top authorization
		 * @param {object} oAuth authorization
		 * @returns {object} parent
		 * @function
		 * @private
		 */
		_getParentFor: function(oAuth) {
			return Util.arrayFind(this._getAllItems(), function(oInner) {
				if (!oAuth._isHeader) {
					return oAuth.AuthObjectGroup === oInner.ObjectId && oInner._isGroupHeader;
				}
				return oInner._isTopHeader;
			});
		},

		/**
		 * Get users IDs
		 * @returns {string[]} a list of users' IDs
		 * @function
		 * @private
		 */
		_getUsersIds: function() {
			return this._getDialogProperty("UsersIds");
		},

		/**
		 * Load auth items from backend
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_loadItems: function() {
			var oPromise = this._getPromise();
			this._oView.getModel().read("/AuthObjectSet", {
				success: function(oData) {
					var aResult = oData.results || [];
					this._setDialogProperty("Items", aResult.map(this._extendAuthObject.bind(this)));
					// this.getDialog().setContentHeight("auto");
					oPromise.resolve();
				}.bind(this),
				error: function(oXhr) {
					oPromise.reject(oXhr);
				}
			});
			return oPromise.promise();
		},

		/**
		 * Propagate selection down to authorization's children
		 * @param {object} oAuth authorization
		 * @function
		 * @private
		 */
		_propagateDown: function(oAuth) {
			if (oAuth._isHeader) {
				this._getChildrenFor(oAuth).forEach(function(oInner) {
					oInner._isSelected = oAuth._isSelected;
					if (oInner._isHeader) {
					    this._propagateDown(oInner);
					} else {
        		        oInner._aCustomers = [];
        		        oInner._aInstallations = [];
        		        oInner._isGrantedToAll = oInner._isSelected;
        		        oInner._isRestricted = false;
					}
				}.bind(this));
			}
		},

		/**
		 * Propagate selection of the given authorization
		 * @param {object} oAuth authorization
		 * @param {boolean} bKeepDetails whether to keep detail level settings
		 * @function
		 * @private
		 */
		_propagateSelection: function(oAuth, bKeepDetails) {
		    var bHasDetails = Boolean(bKeepDetails && (oAuth._aCustomers.length || oAuth._aInstallations.length));
		    
		    if (!bKeepDetails) {
		        oAuth._aCustomers = [];
		        oAuth._aInstallations = [];
		    } else {
		        oAuth._isSelected = bHasDetails;
		    }
		    if (oAuth._isSelected) {
		        oAuth._isGrantedToAll = !bHasDetails;
		        oAuth._isRestricted = bHasDetails;
		    } else {
		        oAuth._isGrantedToAll = false;
		        oAuth._isRestricted = false;
		    }
			this._propagateDown(oAuth);
			this._propagateUp(oAuth);
			this._synchronizeList();
		},
		
		/**
		 * Propagate selection up to authorization's parent
		 * @param {object} oAuth authorization
		 * @function
		 * @private
		 */
		_propagateUp: function(oAuth) {
			var oParent = !oAuth._isTopHeader && this._getParentFor(oAuth);
			if (oParent) {
				oParent._isSelected = this._getChildrenFor(oParent).every(function(oInner) {
					return oInner._isSelected;
				});
				this._propagateUp(oParent);
			}
		},
		
		/**
		 * Update unsynchronized changes in the list
		 * @function
		 * @private
		 */
		_synchronizeList: function() {
		    this._setDialogProperty("Items", this._getDialogProperty("Items"));
		},

		/**
		 * Update single low level authorization in the model
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {string} sUserId user ID
		 * @param {boolean} bDeleteMode delete mode
		 * @param {object} oAuth authorization
		 * @function
		 * @private
		 */
		_updateSingleLowLevelAuth: function (oModel, sUserId, bDeleteMode, oAuth) {
		    var sPattern = "/MassAuthObjectLevelSet(UserId=''{0}'',ObjectId=''{1}'',AuthLevel=''{2}'',AuthLevelType=''{3}'')",
		    	oParams = {
		    		batchGroupId: BATCH_GROUP_ID
		    	};
		    
            if (oAuth._hasCustomerLevel && oAuth._aCustomers) {
                oAuth._aCustomers.forEach(function (oCustomer) {
                    var sPath = Util.formatMessage(sPattern, [sUserId, oCustomer.ObjectId, oCustomer.AuthLevel, "DEBITOR"]),
                    	oEntry = {
	                        Selected: !bDeleteMode,
	                        
                    		AuthLevel: oCustomer.AuthLevel,
                    		AuthLevelDesc: oCustomer.AuthLevelDesc,
	                    	AuthLevelType: "DEBITOR",
	                    	AuthLevelTypeDesc: oCustomer.AuthLevelTypeDesc,
	                    	CustDesc: oCustomer.CustDesc,
	                    	CustName: oCustomer.CustName,
	                    	CustNum: oCustomer.CustNum,
	                    	ObjectDesc: oCustomer.ObjectDesc,
	                    	ObjectId: oCustomer.ObjectId,
	                    	TopLevel: oCustomer.TopLevel,
	                    	UserId: sUserId
	                    };
	                    
                    oModel.update(sPath, oEntry, oParams);
                });
            }
            if ((oAuth._hasInstallationLevel || oAuth._hasUserLevel) && oAuth._aInstallations) {
                oAuth._aInstallations.forEach(function (oInstallation) {
                    var sPath = Util.formatMessage(sPattern, [sUserId, oInstallation.ObjectId, oInstallation.AuthLevel, oAuth.AuthLevelId]),
                    	oEntry = Util.merge(oModel.getProperty(sPath), {
	                        Selected: !bDeleteMode,
	                        
	                    	AuthLevel: oInstallation.AuthLevel,
	                    	AuthLevelDesc: oInstallation.AuthLevelDesc,
	                    	AuthLevelType: oAuth.AuthLevelId,
	                    	AuthLevelTypeDesc: oInstallation.AuthLevelTypeDesc,
	                    	CustDesc: oInstallation.CustDesc,
	                    	CustName: oInstallation.CustName,
	                    	CustNum: oInstallation.CustNum,
	                    	ObjectDesc: oInstallation.ObjectDesc,
	                    	ObjectId: oInstallation.ObjectId,
	                    	TopLevel: oInstallation.TopLevel,
	                    	UserId: sUserId
	                    });
	                    
                    oModel.update(sPath, oEntry, oParams);
                });
            }
		},
		
		/**
		 * Update single top level authorization in the model
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {string} sUserId user ID
		 * @param {boolean} bDeleteMode delete mode
		 * @param {object} oAuth authorization
		 * @function
		 * @private
		 */
		_updateSingleTopLevelAuth: function (oModel, sUserId, bDeleteMode, oAuth) {
            var sPath = Util.formatMessage("/MassAuthObjectTopSet(UserId=''{0}'',ObjectId=''{1}'')", [sUserId, oAuth.ObjectId]),
            	oParams = {
		    		batchGroupId: BATCH_GROUP_ID
		    	},
            	oEntry = {
                	Selected: !bDeleteMode,
                	
                	AuthLevelDesc: oAuth.AuthLevelDesc,
                	AuthLevelId: oAuth.AuthLevelId,
                	AuthObjectGroup: oAuth.AuthObjectGroup,
                	CurrentLevel: oAuth.CurrentAuthLevel,
                	ObjectDesc: oAuth.ObjectDesc,
                	ObjectId: oAuth.ObjectId,
                	TopLevel: oAuth.TopLevel,
                	UserId: sUserId
                };
                
            oModel.update(sPath, oEntry, oParams);
		},
		
		/**
		 * Append customers in the customers table 
		 * @param {object[]} aCustomers selected customers
		 * @function
		 * @public
		 */
		appendCustomers: function(aCustomers) {
		    var oAuth = this._getDetailContext().getObject(),
		        oExisting = Util.combineArray(oAuth._aCustomers, Callbacks.getKey("AuthLevel"), true);
		  
		    aCustomers.forEach(function(oCustomer) {
		        if (!oExisting[oCustomer.AuthLevel]) {
		            oAuth._aCustomers.push(oCustomer);   
		        }
		    });
		    oAuth._isSelected = aCustomers.length ? true : oAuth._isSelected;
		    this._propagateSelection(oAuth, true);
		},
		
		/**
		 * Close dialog then move to the master page 
		 * @function
		 * @public
		 * @override
		 */
		close: function() {
			BaseDialog.prototype.close.call(this);
			this.navToMaster();
		},
		
		/**
		 * Get selected authorization non-group objects
		 * @returns {object[]} auth objects
		 * @function
		 * @public
		 */
		getSelectedAutorizationObjects: function() {
			return this._getDialogProperty("Items").filter(function(oAuth) {
				return oAuth._isSelected && !oAuth._isHeader;
			});
		},

    	/**
    	 * Set "Granted All" switch to true
    	 * @function
    	 * @public
    	 */
    	grantAll: function() {
    	    var oAuth = this._getDetailContext().getObject();
	        oAuth._isSelected = true;
	        this._propagateSelection(oAuth);
    	},
    	
		/**
		 * Check if the dialog is in Delete mode
		 * @returns {boolean} true if Delete mode, false if Add mode
		 * @function
		 * @public
		 */
		isDeleteMode: function() {
			return this._getDialogProperty("DeleteMode");
		},
		
		/**
		 * Open dialog for level selection
		 * @param {sap.ui.base.Event} oEvent event data to get context
		 * @param {boolean} bCustomers whether to open customers dialog
		 * @function
		 * @private
		 */
		_openDialog: function(oEvent, bCustomers) {
            var oAuth = oEvent.getSource().getBindingContext("dialog").getObject(),
                sPath = Util.formatMessage("/AuthObjectSet(UserId=''{0}'',ObjectId=''{1}'')", [oAuth.UserId, oAuth.ObjectId]);
            
            var oDialog = this._oController.getDialogAndReset(bCustomers ? "SelectRestrictedCustomers" : "SelectRestrictedInstallations"),
                aLevels = bCustomers ? oAuth._aCustomers : oAuth._aInstallations,
                aTokens = aLevels.map(function (oLevel) {
				    return new sap.m.Token({
						key: oLevel.AuthLevel,
						text: oLevel.AuthLevelDesc + " (" + oLevel.AuthLevel + ")"
				    });
				});
            oDialog.setModelName();
            oDialog.setContext(sPath);
            oDialog.setTokens(aTokens);
            if (!bCustomers) {
                oDialog.setUsersMode(oAuth._hasUserLevel);
            }
            oDialog.syncStyleClass();
            oDialog.open(this);
		},
		
		/**
		 * Edit restricted customers list
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onEditCustomers: function(oEvent) {
            this._openDialog(oEvent, true);
		},
		
		/**
		 * Edit restricted installations list
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onEditInstallations: function(oEvent) {
            this._openDialog(oEvent);
		},
		
		/**
		 * Open confirmation box to save dialog data
		 * @event
		 * @public
		 */
		onSaveDialog: function() {
			var aAuthList = this.getSelectedAutorizationObjects(),
				sTextKey = this.isDeleteMode() ? "MESSAGE_CONFIRM_MASS_REMOVE_AUTH" : "MESSAGE_CONFIRM_MASS_ADD_AUTH";

			MessageBox.show(this.getText(sTextKey), {
				icon: MessageBox.Icon.WARNING,
				title: this.getText("MESSAGE_COPY_AUTH_2_USERS_APPROVE_TITLE"),
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						this._doSave(aAuthList);
					}
				}.bind(this)
			});
		},

		/**
		 * Handle selection change
		 * Update selection state of the group
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onSelectionChange: function(oEvent) {
			this._propagateSelection(oEvent.getSource().getBindingContext("dialog").getObject());
		},
		
		/**
		 * Handle selection change at top level switch
		 * Propagate selection of the current auth
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onToggleTopLevelSwitch: function(oEvent) {
		    var bSelected = oEvent.getParameter("selected"),
		        oAuth = oEvent.getSource().getBindingContext("dialog").getObject();
		    
		    oAuth._isSelected = Boolean(bSelected);
			this._propagateSelection(oAuth);
		},

		/**
		 * Clear list selections then open dialog
		 * @function
		 * @public
		 * @override
		 */
		open: function() {
			BaseDialog.prototype.open.apply(this, arguments);
			this.setBusy(true);
			this._loadItems().always(this.setBusy.bind(this, false));
		},

		/**
		 * Navigate to detail assign
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		navToDetail: function(oEvent) {
			var oContext = oEvent.getSource().getBindingContext("dialog"),
				oContainer = this._getNavContainer(),
				oPage = oContainer.getPage(DETAIL_PAGE);

			if (oPage) {
				oPage.bindElement("dialog>" + oContext.getPath());
				oContainer.to(DETAIL_PAGE);
			}
		},

		/**
		 * Navigate to auth list
		 * @event
		 * @public
		 */
		navToMaster: function() {
			if (this._getNavContainer()) {
				this._getNavContainer().backToTop();
			}
		},

		/**
		 * Save customers to the customer table
		 * @param {object[]} aCustomers selected customers
		 * @function
		 * @public
		 */
		saveCustomers: function(aCustomers) {
		    var oAuth = this._getDetailContext().getObject();
		    
		    oAuth._aCustomers = aCustomers;
		    oAuth._isSelected = aCustomers.length ? true : oAuth._isSelected;
		    this._propagateSelection(oAuth, true);
		},
		
		/**
		 * Save installations to the installation table or users to the users table
		 * @param {object[]} aInstallations selected installations
		 * @function
		 * @public
		 */
		saveInstallations: function(aInstallations) {
		    var oAuth = this._getDetailContext().getObject(),
		        aCustomers = oAuth._aCustomers,
		        oCustomers = Util.combineArray(aCustomers, Callbacks.getKey("AuthLevel"), true),
		        bCrossCustomer = aInstallations && aInstallations.some(function (oInstallation) {
    		        return oCustomers[oInstallation.CustNum];
    		    });
		    
		    oAuth._aInstallations = aInstallations;
		    if (bCrossCustomer) {
				sap.m.MessageBox.show(this.getText("AUTHORIZATION_LEVEL_CUST_SELECTED"), {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: this.getText("HELP_TITLE"),
					actions: [sap.m.MessageBox.Action.CLOSE]
				});
		    }

		    oAuth._isSelected = aInstallations.length ? true : oAuth._isSelected;
		    this._propagateSelection(oAuth, true);
		},
		
		/**
		 * Set delete mode for the dialog
		 * @param {boolean} bDeleteMode if true, dialog will be in Delete mode, otherwise it will be in Add mode
		 * @returns {sap.support.useradministration.controller.dialog.MassAddDeleteAuthorizations} this for chaining
		 * @function
		 * @public
		 */
		setDeleteMode: function(bDeleteMode) {
			return this._setDialogProperty("DeleteMode", Boolean(bDeleteMode));
		},

		/**
		 * Set users IDs
		 * @param {string[]} aUsersIds a list of users' IDs
		 * @returns {sap.support.useradministration.controller.dialog.MassAddDeleteAuthorizations} this for chaining
		 * @function
		 * @public
		 */
		setUsersIds: function(aUsersIds) {
			return this._setDialogProperty("UsersIds", aUsersIds || []);
		}
	});
});
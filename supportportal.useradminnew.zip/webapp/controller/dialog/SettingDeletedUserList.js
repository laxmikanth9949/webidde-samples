sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SettingDeletedUserList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SettingDeletedUserList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SettingDeletedUserList",
        
        onSubmit: function(oEvent) {
        	this._getRequester()._tableSettingsChange(oEvent,  "idUserSettingsTableGroup3", "idDelUserTable");
        },
        
        onCancel: function() {
        	this.close();
        }
   
    });
});
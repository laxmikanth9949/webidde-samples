sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialogNew) {
	var _fnFactory = function() {
		this.Input="";                        
	};
	
	return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.APCreate", {
		_sDialogName: "APCreate",
		_fnDataFactory: _fnFactory,
	
		beforeOpen: function() {
			if (this._oView.getParent().__function === "1SUPERADMIN") {
				this.getDialog().getContent()[2].setVisible(true);
			} else {
				this.getDialog().getContent()[2].setVisible(false);
			}
		},
		
		onAPCreate: function() {
			this.setProperty("isEnabled", false);
			var sPath = "/auth_pack_for_custSet",
				oView = this._oView,
				oModel = oView.getModel("ap"),
				oEntry = {};

			oEntry.Text = this.getProperty("Input");
			oEntry.Protected = !!this.getProperty("Selected");
			

			// Mandatory field validation check
			// Validate AP name
			if (!this.getProperty("Input")) {
				this.setProperty("State", sap.ui.core.ValueState.Error);
				this.setProperty("StateText",
					this.getText("MESSAGE_AP_EMPTY"));
				
				this.setProperty("isEnabled", true);
				return;
			} else {
				this.setProperty("State",
					sap.ui.core.ValueState.None);
					this.setProperty("StateText","");
			}


			//Send request for the authorization package
			oModel.create(sPath, oEntry, {
				success: function () {
					sap.m.MessageToast.show(this.getText("CREATE_NEW_AP_SUCCESS"));
					this._oController._invalidateTabs(["AuthPackages"]);
					this.getDialog().close();
				}.bind(this),

				error: function (oError) {
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					sap.m.MessageToast.show(this._oUABundle.getText(oErrorBodyObj.error.code + "_TITLE"));
					this.getDialog().close();
				}.bind(this)
			});	
		}
	});
});
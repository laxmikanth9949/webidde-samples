sap.ui.define([
	"sap/support/useradministration/controller/dialog/SmartValueHelpDialog"
	
], function(SmartValueHelpDialog) {
	"use strict";
	
	var Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator;
	
	/**
	 * Dialog for new user's customer selection
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.SmartValueHelpDialog
	 * @alias sap.support.useradministration.controller.dialog.SelectUserCustomer
	 */
	return SmartValueHelpDialog.extend("sap.support.useradministration.controller.dialog.SelectUserCustomer", {
		_sDialogName: "SelectUserCustomer",
		_aFilters: [new Filter("Sortl", FilterOperator.EQ, "cust_num")],
		_sPath: "/CustomerSet",

		/**
		 * Handle dialog confirmation
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onConfirm: function(oEvent) {
			var oToken = oEvent.getParameter("tokens")[0],
			    oItem = this._getItemByToken(oToken);          
			
			if (this._getRequester().setCustomer) {
			    this._getRequester().setCustomer(oItem && oItem.Kunnr, oToken && oToken.getText());
			}
			this.close();
		}
	});
});
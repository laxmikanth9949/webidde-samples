sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/model/Constant"
], function (BaseDialogNew, Util, Constant) {
	var AUTH_PACK_TABLE_ID = "idAuthPackagesTable";

	return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.APRename", {
		_sDialogName: "APRename",

		beforeOpen: function () {
			this.clearMessages();
		},

		setSelectedAP: function (oSelAP) {
			var oView = this._oView,
				oModel = oView.getModel("ap"),
				oItemData = oModel.getData(oSelAP.getBindingContextPath());
			this.setProperty("AuthPack", oSelAP);

			return this.setProperty("Input", oItemData.Text);
		},

		onValidateAuthName: function(){
			this.setProperty("Input", this.getProperty("Input").trim());
			
			var sReasonCode = this._getInvalidAuthNameReason();

			this.clearMessages();
			// Mandatory field validation check
			// Validate AP name
			if (sReasonCode) {
				this.setProperty("State", sap.ui.core.ValueState.Error);

				this.setProperty("StateText", this.getText(sReasonCode));

				sap.ui.getCore().byId("idAPRenameName").focus();
			}
		},

		_getInvalidAuthNameReason: function(){
			var 
				iIndex = 0,
				aChecks = ["_reasonEmpty", "_reasonGiven"],
				sReasonCode = "";

			while(!sReasonCode){
				sReasonCode = this[aChecks[iIndex]]();

				iIndex++;
			}

			return sReasonCode;
		},

		_reasonEmpty: function(){
			return !this.getProperty("Input") && "MESSAGE_AP_EMPTY_NEW" || "";
		},

		_reasonGiven: function(){
			var 
				sTableId = "idAuthPackagesTable",
				sValue = this.getProperty("Input"),
				oTable = this._oController.byId(sTableId),
				sCurrAuthPackId = this.getProperty("AuthPack").getBindingContext("ap").getProperty("AuthPackId");

			if(!oTable){
				return "";
			}

			return oTable.getBinding("items").getContexts().some(function(oCtx){
				var oData = oCtx.getObject();

				return oData.AuthPackId !== sCurrAuthPackId && (oData.Text || "").toUpperCase() === (sValue || "").toUpperCase();
			}) && "MESSAGE_CREATE_AUTH_PACK_DUPLICATE_NAME" || "";
		},

		_isAuthNameValid: function(){
			return this.getProperty("State") !== sap.ui.core.ValueState.Error;
		},

		onAPRename: function () {
			var 
				oView = this._oView,
				oModel = oView.getModel("ap"),
				oSelAP = this.getProperty("AuthPack"),
				sPath = oSelAP.getBindingContextPath(),
				oItemData = {};

			this.onValidateAuthName();

			if(!this._isAuthNameValid()){
				return;
			}

			oItemData.Text = this.getProperty("Input");

			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups(["idAPRenameGroup"]);

			oModel.update(sPath, oItemData, {
				batchGroupId: "idAPRenameGroup"
			});

			oModel.submitChanges({
				batchGroupId: "idAPRenameGroup",
				success: function () {
					sap.m.MessageToast.show(this.getText("CHANGE_NEW_AP_SUCCESS"));
					oModel.setUseBatch(false);
					this._oController._invalidateTabs();
					this.getDialog().close();
				}.bind(this),
				error: function (oError) {
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					sap.m.MessageToast.show(oErrorBodyObj.error.message.value);
					oModel.setUseBatch(false);
					this.getDialog().close();
				}.bind(this)
			});
		},
		
		clearMessages: function(){
			this.setProperty("State", sap.ui.core.ValueState.None);
			this.setProperty("StateText", "");
		}
	});
});
sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",

	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseDialog, Constant, Util, Filter, FilterOperator) {
	var _fnFactory = function() {
		this.InitialIds = [];
		this.InactiveIds = [];
		this.List = [];
		this.Search = "";
		this.UserId = "";
		this.SelectedList = [];
	};

	/**
	 * Dialog for assigning authorization packages to user
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseDialog
	 * @alias sap.support.useradministration.controller.dialog.AssignAPsToUser
	 */
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.AssignAPsToUser", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "AssignAPsToUser",
		
		beforeOpen: function () {
			this.setBusy(true);
			this._loadAuthPackagesList()
				.finally(this.setBusy.bind(this, false));
		},

		/**
		 * Load available authorization packages
		 * @returns {Promise} promise
		 * @function
		 * @private
		 */
		_loadAuthPackagesList: function () {
			this.setProperty("List", []);
			return Util.promiseRead.call(this, "/auth_pack_for_custSet", {}, "ap")
				.then(function (oData) {
					var aPackages = oData.results || [],
						aSelectedPackages = this.getProperty("SelectedList");

					this.setProperty("List", aPackages.map(function (oPackage) {
						var isAssigned = aSelectedPackages.some(function (oSelectedPackage) {
							return oSelectedPackage.AuthPackId === oPackage.AuthPackId;
						});
        				return Util.merge({}, oPackage, {
        					IsAssigned: isAssigned
        				});
        			}));
				}.bind(this));
		},
		
		_getList: function () {
			return this._oDialog.getContent()[0];
		},
		
		onAPSearch: function() {
			var itemsLength = this._getList().getBinding("items").oList.length;
			this.getDialog().setContentHeight(itemsLength * 2 + "rem");
            var sValue = this.getProperty("Search"),
                aFilters = sValue ? [new Filter("Text", FilterOperator.Contains, sValue)] : [];
            this._getList().getBinding("items").filter(aFilters);
        },
        
        onApplySelections: function () {
        	if (this._getRequester().setAssignedAuthorizationPackages) {
        		this._getRequester().setAssignedAuthorizationPackages(this.getProperty("List").filter(function (oPackage) {
        			return oPackage.IsAssigned;
        		}));
        	}
        	this.close();
        },

		onClose: function() {
			this.close();
		}
	});
});
sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialogNew) {
    
    /**
     * Dialog for filtering Deleted user list
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.FilterDeletedUserList
     */
    return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.FilterDeletedUserList", {
        _sDialogName: "FilterDeletedUserList",
        
        /**
         * Apply filters
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onSubmit: function(oEvent) {
        	var mParams = oEvent.getParameters(),
				aFilterItems = mParams.filterItems || [];
				
			var aFilters = (aFilterItems && aFilterItems.map(function (oItem) {
				var aSplit = oItem.getKey().split("___");
				var sPath = aSplit[0],
					sOperator = aSplit[1],
					sValue1 = aSplit[2],
					sValue2 = aSplit[3];
				return new sap.ui.model.Filter(sPath, sOperator, sValue1, sValue2);
			})) || [];
			this._getController()._aDUFilter = aFilters;
					
			this._getController()._filterDeletedUsers();                         
			
			// update filter bar
			this._oController._setViewProperty("DeletedUserFilterString", mParams.filterString);
        }
   
    });
});
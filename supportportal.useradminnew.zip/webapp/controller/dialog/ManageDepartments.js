sap.ui.define([
    "sap/support/useradministration/controller/dialog/SelectUserDepartment",
    "sap/support/useradministration/model/Constant"
], function(SelectUserDepartment, Constant) {
    var _fnFactory = function() {
        this.DeptClickable = false;
        this.EditMode = false;
    };
    
    /**
     * Dialog for managing departments
     * @class
     * @extends sap.support.useradministration.controller.dialog.SelectUserDepartment
     * @alias sap.support.useradministration.controller.dialog.ManageDepartments
     */
    return SelectUserDepartment.extend("sap.support.useradministration.controller.dialog.ManageDepartments", {
        _fnDataFactory: _fnFactory,
        _sDialogName: Constant.Dialog.MANAGE_DEPTS,
        _sListId: "manageDeptDialogList",
        
        /**
         * Open add department dialog
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onAddDeptButtonPress: function() {
            var oAddDeptDialog = this._oController.getDialogAndReset("AddDepartment");
            oAddDeptDialog.open(this);
        },
        
        /**
         * Add NONE item to the list after update if list clickable
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         * @override
         */
        onDeptListUpdateFinished: function(oEvent) {
            if (this._getDialogProperty("DeptClickable")) {
                SelectUserDepartment.prototype.onDeptListUpdateFinished.call(this, oEvent);
            }
        },
        
        /**
         * Assign selected dept to users
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         * @override
         */
        onDeptSelect: function(oEvent) {
            var oSelectedItem = oEvent.getSource();
            if (oSelectedItem) {
                this._oController.handleAssignDept(oSelectedItem.getTitle());
            }
            this.close();
        },
        
        /**
         * Set dept list clickable state
         * @param {boolean} bClickable if list clickable
         * @function
         * @public
         */
        setListClickable: function(bClickable) {
            this._setDialogProperty("DeptClickable", Boolean(bClickable));
        }
    });
});
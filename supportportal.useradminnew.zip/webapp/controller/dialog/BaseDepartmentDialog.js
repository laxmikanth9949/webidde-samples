sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialog) {

    var _fnFactory = function() {
        this.Input = "";
    	this.Duplicate = false;
		this.SameInput = true;
    	this.EmptyInput = false;
		this.InvalidSymbols = false;
		this.ExistingDepartmentNames = null;
    	this.ErrorMessage = "";
        this.IsAddBtnEnabled = false;
    	this.DepartmentId = "";
    	this.DepartmentName = "";
        this.IsEditBtnEnabled = false;
    };

    /**
     * Base Department dialog controller
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.BaseDepartmentDialog
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.BaseDepartmentDialog", {
        _fnDataFactory: _fnFactory,

        /**
         * Check wheter the entered Department name became empty
         * @param {string} sDepartmentName department name
         * @function
         * @private
         */
		_nameBecameEmpty: function (sDepartmentName) {
			this.setProperty("EmptyInput", !sDepartmentName.length);
		},

		/**
         * Check whether the entered Department name contains invalid symbols
         * The RegExp is coming from the backend
         * @param {string} sDepartmentName department name
         * @function
         * @private
         */
		_nameHasInvalidSymbols: function (sDepartmentName) {
			var sDepartmentNameInvalidSymbols = this.getModel("appSettings").getProperty("/departmentRegexp");
			var reDepartmentName = new RegExp(sDepartmentNameInvalidSymbols, "g");
			this.setProperty("InvalidSymbols", reDepartmentName.test(sDepartmentName));
		},

		/**
         * Check whether the entered Department name already exists in the table of Departments
         * @param {string} sDepartmentName the entered Department name
         * @function
         * @private
         */
		_nameAlreadyExists: function (sDepartmentName) {
            if (this.getDialogName() === "AddDepartmentNew") {
                if (!this.getProperty("ExistingDepartmentNames")) {
                    var aExistingDeparmentList = sap.ui.getCore().byId("idListDepartmentList").getBinding("items").getContexts();
                    this.setProperty("ExistingDepartmentNames", aExistingDeparmentList.map(function(oDepartment) {
                        return oDepartment.getProperty("DepartmentName");
                    }));
                }
                this.setProperty("Duplicate", this.getProperty("ExistingDepartmentNames").includes(sDepartmentName));
            } else if (this.getDialogName() === "EditDepartmentNew"){
                this.setProperty("Duplicate", !!this.getProperty("ExistingDepartmentNames").find(function(oDepartment) {
                    return oDepartment.name === sDepartmentName && oDepartment.id !== this.getProperty("DepartmentId");
                }.bind(this)));
                this.setProperty("SameInput", sDepartmentName === this.getProperty("DepartmentName"));
            }
		},

        /**
		 * Update the shown error message depending on the error type
		 * @function
		 * @public
		 */
        updateErrorMessage: function() {
        	if (this.getProperty("EmptyInput")) {
        		this.setProperty("ErrorMessage", this.getText("MESSAGE_DEPT_EMPTY_NAME"));
        	} else if (this.getProperty("InvalidSymbols")) {
				this.setProperty("ErrorMessage", this.getText("DIALOG_DEPARTMENT_NAME_INVALID_SLASH_UPDATE"));
        	} else if (this.getProperty("Duplicate")) {
				this.setProperty("ErrorMessage", this.getText("MESSAGE_DEPT_DUPLICATE"));
        	} else {
				this.setProperty("ErrorMessage", "");
			}
        },

		/**
         * Execute the Department name validity checks
         * @param {string} sDepartmentName the entered Department name
		 * @function
         * @public
         */
		runInputChecks: function (sDepartmentName) {
			this._nameBecameEmpty(sDepartmentName);
			this._nameHasInvalidSymbols(sDepartmentName);
			this._nameAlreadyExists(sDepartmentName);
			this.updateErrorMessage();
		}
    });
});
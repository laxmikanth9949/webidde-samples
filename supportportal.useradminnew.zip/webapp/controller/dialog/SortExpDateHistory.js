sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SortDeletedUserList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SortExpDateHistory", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SortExpDateHistory",
        
        onSubmit: function(oEvent) {
        	var mParams = oEvent.getParameters();
			var oBinding = this._oParentDialog.getTable().getBinding("items");
			var aSorters = [];
            
            if (mParams.sortItem) {
				var sPath = mParams.sortItem.getKey();
				var bDescending = mParams.sortDescending;
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
				oBinding.sort(aSorters);
        	}
        }
   
    });
});
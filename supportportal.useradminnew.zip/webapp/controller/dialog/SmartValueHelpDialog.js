sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
	"sap/support/useradministration/util/Util",
    
    "sap/m/SearchField",
    "sap/m/Token",
    "sap/ui/Device",
    "sap/ui/model/Filter"
], function(BaseDialog, Util, SearchField, Token, Device, Filter) {
   "use strict";
   
	/**
	 * Factory for dialog model
	 * @function
	 * @private
	 */
	var _fnFactory = function() {
		this.Items = [];
	};
	
    /**
     * Returns comparator for case-insensitive search
     * @param {string} sSubstring substring to find
     * @returns {function} comparator
     * @function
     * @private
     */
    var _fnContainsIgnoreCase = function(sSubstring) {
        return function(sValue) {
            if (!sSubstring) {
                return true;
            } else if (!sValue) {
                return false;
            } else {
                return sValue.toLowerCase().indexOf(sSubstring.toLowerCase()) !== -1;
            }
        };
    };
    
	var ITEMS = "Items";
    
    /**
     * Base for value help dialogs
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SmartValueHelpDialog
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SmartValueHelpDialog", {
		_fnDataFactory: _fnFactory,
        _aFilters: null,			// Table filters
        _bInvalidate: true, 		// A flag to refresh data
        _oItemMap: {},				// All items mapped by their keys
        _sModelName: undefined,		// A name of the model to download the data
        _sPath: null,				// A path in the model to download the data
    	_sResultPath: "/results",	// A path to result in the response
        
        /**
         * Add basic search field to the filter bar
         * @param {sap.ui.comp.filterbar.FilterBar} oFilterBar filter bar
         * @function
         * @protected
         */
        _addSearchField: function(oFilterBar) {
            if (!oFilterBar.getBasicSearch()) {
                oFilterBar.setBasicSearch(new SearchField({
 					showSearchButton: Device.system.phone, 
 					placeholder: "Search",
 					search: oFilterBar.search.bind(oFilterBar)
 				}));
            }
        },
        
        /**
         * Create columns model for table
         * @returns {sap.ui.model.json.JSONModel} model
         * @function
         * @protected
         */
        _createColumnsModel: function() {
            var oFilterBar = this.getDialog().getFilterBar(),
                aFilterItems = oFilterBar && oFilterBar.getFilterGroupItems() || [];
                
            return this.createJSONModel({
                cols: aFilterItems.map(function (oItem) {
                    return {
    					label: oItem.getLabel(),
    					template: "dialog>" + oItem.getName()
    				};
                })
            });
        },
        
		/**
		 * Extend item with new properties
		 * @param {object} oItem item
		 * @returns {object} extended product
		 * @function
		 * @private
		 */
		_extendItem: function(oItem) {
			return oItem;
		},
        
        /**
         * Get items from model
         * @returns {object[]} items
         * @function
         * @protected
         */
        _getItems: function() {
            return this.getProperty(ITEMS) || [];
        },
        
		/**
		 * Get single item by token
		 * @param {sap.m.Token} oToken token
		 * @returns {object} item
		 * @function
		 * @private
		 */
        _getItemByToken: function (oToken) {
        	var oItemMap = this._oItemMap || {},
        		oTokenItem = oToken && oItemMap[oToken.getKey()];
			return oTokenItem && jQuery.extend(true, {}, oTokenItem);
		},
        
		/**
		 * Get items by their tokens
		 * @param {sap.m.Token[]} aTokens token lsit
		 * @returns {object[]} items list
		 * @function
		 * @private
		 */
		_getItemsByTokens: function(aTokens) {
			return aTokens.map(this._getItemByToken.bind(this)).filter(Boolean);
		},
		
		/**
		 * Get search field
		 * @returns {sap.m.SearchField} search field
		 * @function
		 * @protected
		 */
		_getSearchField: function() {
		    var oFilterBar = this.getDialog().getFilterBar(),
		        sId = oFilterBar && oFilterBar.getBasicSearch();
		    
            return sId && sap.ui.getCore().byId(sId);
		},
        
		/**
		 * Load items from backend
		 * @function
		 * @public
		 */
		_loadItems: function() {
			var oModel = Util.getModel.call(this._oController, this._sModelName),
				oPromise = Util.getPromise();

			this.setBusy(true);
			if (this._oLoader && this._oLoader.abort) {
				this._oLoader.abort();
			}

			this.setProperty(ITEMS, []);
			this._oLoader = oModel && oModel.read(this._sPath || "", {
				filters: this._aFilters || [],
				success: function(oData) {
					this._updateItems(oData.results || []);
					this.getDialog().update();
					oPromise.resolve();
				}.bind(this),
				error: function() {
					oPromise.reject();
				}
			});
			
			if (!this._oLoader) {
				oPromise.reject();
			}
			oPromise.always(this.setBusy.bind(this, false));
		},
		
        /**
         * Prepare table when opening dialog
         * @param {sap.ui.table.Table} oTable table
         * @function
         * @protected
         */
        _prepareTable: function(oTable) {
            if (!oTable.getModel("columns")) {
                oTable.setModel(this._createColumnsModel(), "columns");
            }
            
            if (!oTable.getBinding("rows")) {
				oTable.bindRows({
					path: "dialog>" + ITEMS
				});
            }
        },
        
		/** 
		 * Update items in the dialog model
		 * @param {object[]} aItems items retrieved from the backend
		 * @function
		 * @private
		 */
		_updateItems: function(aItems) {
			var aList = aItems && aItems.map(this._extendItem.bind(this)) || [];
			this.setProperty(ITEMS, aList);
			this._oItemMap = Util.mapBy(aList, this.getDialog().getKey());
			this._bInvalidate = false;
		},
		
        /**
         * Clear filters
         * @function
         * @public
         */
        clearFilters: function() {
            var oFilterBar = this.getDialog().getFilterBar(),
                oBasicSearch = this._getSearchField(),
                aItems = oFilterBar.getFilterGroupItems();
            
            aItems.forEach(function (oItem) {
                oItem.getControl().setValue("");
            });
            if (oBasicSearch) {
                oBasicSearch.setValue("");
            }
            oFilterBar.search();
        },
        
        /**
         * Invalidate data
         * @function
         * @public
         */
        invalidate: function() {
        	this._bInvalidate = true;
        	if (this.getDialog().isOpen()) {
        		this._loadItems();
        	}
        },
        
        /**
         * Handle filter bar search
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onSearch: function(oEvent) {
            var oBasicSearch = this._getSearchField(),
                aSelectionSet = oEvent.getParameter("selectionSet") || [],
                bAnd = true;
            
            var aFilters = aSelectionSet.filter(function (oInput) {
                return oInput.getName() && oInput.getValue();
            }).map(function (oInput) {
                return new Filter({
                    path: oInput.getName(), 
                    test: _fnContainsIgnoreCase(oInput.getValue())
                });
            });
            
            if (aFilters.length) {
                oBasicSearch.setValue("");
            } else {
                var sBasicSearch = oBasicSearch.getValue();
                aFilters = aSelectionSet.map(function (oInput) {
                    return new Filter({
                        path: oInput.getName(), 
                        test: _fnContainsIgnoreCase(sBasicSearch)
                    });
                });
                bAnd = false;
            }
            this.getDialog().getTable().getBinding().filter(new Filter({
                filters: aFilters,
                and: bAnd
            }));
        },
        
        /**
         * Prepare and open dialog
         * @function
         * @public
         * @override
         */
        open: function() {
            var oDialog = this.getDialog();
            
            this._addSearchField(oDialog.getFilterBar());
            this._prepareTable(oDialog.getTable());
            oDialog.getFilterBar().clear();
            BaseDialog.prototype.open.apply(this, arguments);
			if (this._bInvalidate) {
				this._loadItems();
			}
			if (!oDialog.getSupportMultiselect()) {
			    oDialog.setTokens([]);
			}
        },
        
        /**
         * Set backend filter
         * @param {sap.ui.model.Filter[]} aFilters filters
         * @function
         * @public
         */
        setFilters: function(aFilters) {
            this._aFilters = aFilters; 
        },

		/**
		 * Set model name
		 * @param {string} sModelName model name
		 * @function
		 * @public
		 */
		setModelName: function(sModelName) {
			this._sModelName = sModelName;
		},
		
		/**
		 * Set binding path
		 * @param {string} sPath path to obtain the data
		 * @function
		 * @public
		 */
		setPath: function(sPath) {
			this._sPath = sPath;
		},
        
        /**
         * Set tokens
         * @param {sap.m.Token[]} aTokens tokens
         * @function
         * @public
         */
        setTokens: function(aTokens) {
            this.getDialog().setTokens(aTokens);
        },
        
        /**
         * Set tokens using context objects
         * @param {object[]} aObjects objects
         * @function
         * @public
         */
        updateTokens: function(aObjects) {
        	var oDialog = this.getDialog(),
        		aTokens = [];
        	if (aObjects) {
        		aTokens = aObjects.map(function (oObject) {
        			var sKey = oObject[oDialog.getKey()];
					
					if (oDialog.getDescriptionKey()) {
	        			return new Token({
	        				key: sKey,
	        				text: oObject[oDialog.getDescriptionKey()] + " (" + sKey + ")"
	        			});
					} else {
	        			return new Token({
	        				key: sKey,
	        				text: sKey
	        			});
					}
        		});
        	}
            oDialog.setTokens([]);
            oDialog.setTokens(aTokens);
        }
    });
});
sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
    "sap/support/useradministration/model/Constant",
    "sap/support/useradministration/util/Util",
    
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function(BaseDialogNew, Constant, Util, Filter, FilterOperator) {
	"use strict";

    var _fnFactory = function() {
        this.AuthLevelId = "";
        this.ObjectDesc = "";
        this.TempCurrentAuthLevel = "";
    };
    
    var AuthLevel = Constant.AuthLevel;
    
    return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.CopyLevelsCreateAP", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "CopyLevelsCreateAP",

        beforeOpen: function() {
        	this._filter();
        },

        setAuthorization: function (oAuthorization) {
            this.setProperty("", Util.deepCopy(oAuthorization));
            return this;
        },
        
        onSearch: function(oEvent) {
            this._filter(oEvent.getParameter("value"));
        },

        _copyAuthLevelsLocally: function(aAuthObjects) {
            var oAuth = this.getProperty(""),
            	oPromise = Util.getPromise();
            
    		if (oAuth.TempCurrentAuthLevel === AuthLevel.RESTRICTED) {
    			aAuthObjects.forEach(this._updateLowLevelAuthLocally.bind(this, oAuth));
    		} else {
    			aAuthObjects.forEach(this._updateTopLevelAuthLocally.bind(this, oAuth.TempSelected));
    		}
    		return oPromise.resolve().promise();
        },
        
        _updateLowLevelAuthLocally: function(oSource, oDest) {
        	oDest.Customers = oSource.Customers ? oSource.Customers.map(Util.deepCopy) : [];
        	oDest.Installations = oSource.Installations ? oSource.Installations.map(Util.deepCopy) : [];
        	oDest.Customers.forEach(function (oCustomer) {
        		oCustomer.PackId = oDest.PackageId;
        		oCustomer.ObjectId = oDest.ObjectId;
        		oCustomer.AuthLevelType = "DEBITOR";
        	});
        	oDest.Installations.forEach(function (oInstallation) {
        		oInstallation.PackId = oDest.PackageId;
        		oInstallation.ObjectId = oDest.ObjectId;
        		oInstallation.AuthLevelType = oDest.AuthLevelId;
        	});
        	this._getRequester()._handleAuthorizationObjectSelectChange(oDest, /* bKeepDetails = */ true);
        },
        
        _updateTopLevelAuthLocally: function(bSelected, oAuth) {
        	oAuth.TempSelected = bSelected;
        	this._getRequester()._handleAuthorizationObjectSelectChange(oAuth, /* bKeepDetails = */ false);
        },
        
        onConfirm: function(oEvent) {
            var oController = this._getRequester(),
            	aAuthObjects = oEvent.getParameter("selectedContexts")
	                .map(function (oContext) {
	                    return oContext.getObject();
	                });
            if (aAuthObjects.length) {
	            var sMessage = this.getText("MESSAGE_CONFIRM_COPY_AUTHORIZATION_LEVELS", [this.getProperty("ObjectDesc")]);
	            
	            this.showConfirmationBox(sMessage, this.getText("MESSAGE_COPY_AUTH_2_USERS_APPROVE_TITLE"))
	            	.then(function() {
						oController.setBusy(true);
	            		this._copyAuthLevelsLocally(aAuthObjects);
	            	}.bind(this))
	            	.then(oController._updateAuthorizationListChanges.bind(oController))
	            	.always(oController.setBusy.bind(oController, false));
            }
        },
        
        showConfirmationBox: function(sMessage, sTitle) {
            var oPromise = Util.getPromise();
            sap.m.MessageBox.show(sMessage, 
            {
                icon: sap.m.MessageBox.Icon.WARNING,
                actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
                title: sTitle,
                onClose: function(oAction) {
                    if (oAction === sap.m.MessageBox.Action.OK) {
                        oPromise.resolve();
                    } else {
                        oPromise.reject();
                    }
                }
            });
            return oPromise.promise();
        },
        
        _filter: function(sSearchValue) {
            var aFilters = [],
                sAuthLevelId = this.getProperty("AuthLevelId");
            if (sAuthLevelId) {
                aFilters.push(new Filter("AuthLevelId", FilterOperator.EQ, sAuthLevelId));
            }
            if (sSearchValue) {
                aFilters.push(new Filter("ObjectDesc", FilterOperator.Contains, sSearchValue));
            }
            this.getDialog().getBinding("items").filter(aFilters);
        }
    });
});
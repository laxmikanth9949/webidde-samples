sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew"
], function (BaseDialogNew) {

	var _fnFactory = function () {
		this.List = [];
		this.ViewModel = {};

	};

	return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.SimilarAuthPacks", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "SimilarAuthPacks",

		setViewModel: function(oModel){
			return this.setProperty("ViewModel", oModel);
		}
	});
});
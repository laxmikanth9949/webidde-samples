sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
	var USER_DETAIL_ROUTE = "userDetailNew",
		AUTH_PACK_TABLE_ID = "idAuthPackagesTable";
		
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.APReport", {
		_sDialogName: "APReport",
		_beforeOpen: function () {
			var oView = this._oView;
			var oModel = oView.getModel("ap");
			var oSelItems = this._getSelectedAP();
			var oAPReportTable = this.getDialog().getContent()[1];
			var sAuthPackName = oModel.getData(oSelItems[0].getBindingContextPath()).Text;

			var aFilters = (oSelItems && oSelItems.map(function (item) {
				var sPath = item.getBindingContextPath();
				var oItemData = oModel.getData(sPath);
				return new sap.ui.model.Filter("AuthPackId", sap.ui.model.FilterOperator.EQ, oItemData.AuthPackId);
			})) || [];
			oView._aAPReportFilters = aFilters;
			oAPReportTable.getBinding("items").filter(aFilters);
			this.setProperty("description", this.getText("MESSAGE_DESCRIPTION_AUTH_PACK_USER_OVERVIEW", [sAuthPackName]));
		},
		
		setSelectedAP: function(aSelectedAP) {
			return this.setProperty("AuthPacks", aSelectedAP);
		},
		
		_getSelectedAP: function() {
			return this.getProperty("AuthPacks");
		},
		
		onSmartTableDownload: function (oEvent) {
			this._oController.onSmartTableDownload(oEvent);
		}, 
		
		handleListItemPressDialogAPReport: function (oEvent) {
			var sUserId = oEvent.getSource().getBindingContext("ap").getProperty("SuserId");

			this._oController._rememberCurrentTab();

			this._oController.getRouter().navTo(USER_DETAIL_ROUTE, {
				from: "Master",
				"user_id": sUserId
			}, false);
		},
		
		setUsersCount: function (iCount) {
			return this.setProperty("usersCount", iCount);
		}
	});
});
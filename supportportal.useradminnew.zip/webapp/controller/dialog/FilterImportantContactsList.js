sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialogNew) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.FilterImportantContactsList
     */
    return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.FilterImportantContactsList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "FilterImportantContactsList",
        
        _onlyUnique: function(value, index, self) { 
    		return self.indexOf(value) === index;
        },
        
        beforeOpen: function() {
        	if (!this._oDialogModel.getProperty("/FilterImportantContactsDialog")) {
        		this._oDialogModel.setProperty("/FilterImportantContactsDialog", {});
        	}
        	this.getDialog().bindElement("dialog>/FilterImportantContactsDialog");
        	if (!this._oDialogModel.getProperty("/FilterImportantContactsDialog/UserCustNumList")) {
        		this.getModel().read("/ImportantRolesSet", {
        			success: function (oData) {
						var aList = oData.results || [];
						var aMap = [];
						var aResult = [];
						aMap = aList.map(function(item){
							return item.UserCustNum;
						}).filter(this._onlyUnique);
						aResult = aMap.map(function (item) {
							var sItem = item.toString();
							if (sItem.length !== 10){
								var add = 10 - sItem.length;
								for (var i = 0; i < add; i++){
									sItem = "0" + sItem;
								}
							}
							return {"UserCustNumber": item,
									"UserCustNumberFilter": sItem
							};
						});
						this._oDialogModel.setProperty("/FilterImportantContactsDialog/UserCustNumList", aResult);
					}.bind(this)
        		});
        	}
        	
        	if (!this._oDialogModel.getProperty("/FilterImportantContactsDialog/InstNumList")) {
        		this.getModel().read("/ImportantRolesSet", {
        			success: function (oData) {
						var aList = oData.results || [];
						var aMap = [];
						var aResult = [];
						aMap = aList.map(function(item){
							return item.Inst;
						}).filter(this._onlyUnique);
						aResult = aMap.map(function (item) {
							for (var i = 0; i < aList.length; i++) {
								if (item === aList[i].Inst)	{
									return {
										"InstNum": item,
							            "InstName": aList[i].InstName
									};
								}
							}
						});
						this._oDialogModel.setProperty("/FilterImportantContactsDialog/InstNumList", aResult);
					}.bind(this)
        		});
        	}
        	if (!this._bItemsDeleted) {
        		this._deleteItems();
        	}
        },
        
                /**
         * Delete filters that should not be visible
         * @function
         * @private
         */
        _deleteItems: function () {
        	var oDialog = this.getDialog(),
        		bIsEmailFilterEnabled = this.getModel("appSettings").getData().isEmailFilterEnabled;
    		oDialog.getFilterItems().filter(function (oItem) {
    			switch (oItem.getKey())  {
					case "EmailFilter":
						return !bIsEmailFilterEnabled;
    				default:
    					return false;
    			}
    		}).forEach(function (oItem) {
    			oDialog.removeFilterItem(oItem);
    		});	
    		this._bItemsDeleted = true;
        },
        
        onSubmit: function(oEvent) {
			var mParams = oEvent.getParameters();
			
			var aFilters = (mParams.filterItems && mParams.filterItems.map(function (oItem) {
				var aSplit = oItem.getKey().split("___");
				var sPath = aSplit[0];
				var sOperator = aSplit[1];
				var sValue1 = aSplit[2];
				return new sap.ui.model.Filter(sPath, sOperator, sValue1);
			})) || [];
			
			this._getController()._aICFilter = aFilters;
			this._getController()._filterImportantContacts();
			
			// update filter bar
			this._oView.byId("vsdFilterBar4").setVisible(aFilters.length > 0);
			this._oView.byId("vsdFilterLabel4").setText(mParams.filterString);
        }
   
    });
});
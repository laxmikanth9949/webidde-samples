sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SettingRequestedUserList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SettingRequestedUserList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SettingRequestedUserList",
        
        onSubmit: function(oEvent) {
        	this._getRequester()._tableSettingsChange(oEvent, "idUserSettingsTableGroup2", "idReqUserTable");
        },
        
        onCancel: function() {
        	this.close();
        }
   
    });
});
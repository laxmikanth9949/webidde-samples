sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialogNew) {
    
    /**
     * Dialog for filtering Requested user list
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.FilterRequestedUserList
     */
    return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.FilterRequestedUserList", {
    	 _fnDataFactory: function() {
	    	this.Months = {
	    		"1": 1,
	    		"2": 2,
	    		"3": 3,
	    		"6": 6,
	    		"12": 12,
	    		"24": 24,
	    		"60": 60
	    	};
	    	
	    	this.ExpiryDateMonths = [1, 2, 3, 24, 60].map(function (iMonth) {
	    		return {
	    			Month: iMonth
	    		};
	    	});
	    },
        _sDialogName: "FilterRequestedUserList",
        
        /**
         * Apply filters
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onSubmit: function(oEvent) {
			var mParams = oEvent.getParameters(),
				aFilterItems = mParams.filterItems || [];
				
			var aFilters = (aFilterItems && aFilterItems.map(function (oItem) {
				var aSplit = oItem.getKey().split("___");
				var sPath = aSplit[0],
					sOperator = aSplit[1],
					sValue1 = aSplit[2],
					sValue2 = aSplit[3];
				return new sap.ui.model.Filter(sPath, sOperator, sValue1, sValue2);
			})) || [];
			this._getController()._aRUFilter = aFilters;
					
			this._getController()._filterRequestedUsers();                         
			
			// update filter bar
			this._oController._setViewProperty("RequestedUserFilterString", mParams.filterString);
        }
   
    });
});
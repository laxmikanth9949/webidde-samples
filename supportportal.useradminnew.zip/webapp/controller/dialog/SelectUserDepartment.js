sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    "sap/support/useradministration/model/Constant",
    
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function(BaseDialog, Constant, Filter, FilterOperator, MessageBox, MessageToast) {
    var _fnFactory = function() {
        this.EditMode = false;
        this.Search = "";
        this.ValueHelpMode = false; 
    };
    
    /**
     * Dialog for selecting user's department
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SelectUserDepartment
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SelectUserDepartment", {
        _fnDataFactory: _fnFactory,
        _sDialogName: Constant.Dialog.SELECT_USER_DEPT,
        _sListId: "selectUserDeptDialogList",
        _oNoneItem: null,
        
        /**
         * Get department list
         * @returns {sap.m.ListBase} list
         * @function
         * @private
         */
        _getList: function() {
            return sap.ui.getCore().byId(this._sListId);  
        },
        
        /**
         * Get or create NONE dept item using list's template
         * @param {sap.m.ListBase} oList list to get template from
         * @returns {sap.support.useradministration.extended.AdjustableListItem} item
         * @function
         * @private
         */
        _getNoneItem: function(oList) {
            if (!this._oNoneItem || this._oNoneItem.bIsDestroyed) {
                var oTemplate = oList.getBindingInfo("items").template,
                    oItem = oTemplate.clone();
                oItem.bindProperty("title", "i18n>DIALOG_DEPT_NONE");
                oItem.setDeletable(false);
                this._oNoneItem = oItem;
            }
            return this._oNoneItem;
        },
        
        /**
         * Deletes dept according to confirmation box result
         * @param {sap.ui.base.Event} oEvent data of list's delete event
         * @param {sap.m.MessageBox.Action} oAction confirmation box result
         * @function
         * @private
         */
        _onConfirmDeptDelete: function(oEvent, oAction) {
           	if (oAction === MessageBox.Action.OK) {
           	    var oList = oEvent.getSource(),
           	        oListItem = oEvent.getParameter("listItem"),
           	        oContext = oListItem.getBindingContext();
				oList.removeItem(oListItem);
				if (oContext) {
			        var sPath  = "/DepartmentSet(UserId='',DepartmentDesc='" + oContext.getProperty("DepartmentDesc") + "')",
			            oModel = oContext.getModel(),
			            oBundle = this._getResourceBundle();

					oModel.remove(sPath, {
						success: function() {				
				    	    oModel.refresh();
				    	},
						error: function(oXhrError) {
						    var sResponseText = oXhrError.responseText,
						        oError = JSON.parse(sResponseText);
							MessageToast.show(oBundle.getText(oError.error.code + "_TITLE"));
						}
					});
				}												
           	}
        },
        
        /**
         * Remove filters, clear search, and close dialog
         * @function
         * @public
         * @override
         */
        close: function() {
            this._getList().getBinding("items").filter([]);
            BaseDialog.prototype.close.call(this);
        },
        
        /**
         * Destroy dialog
         * @function
         * @public
         * @override
         */
        destroy: function() {
            BaseDialog.prototype.destroy.call(this);
            this._oNoneItem = null;
        },
        
        /**
         * Open confirmation box to delete dept
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onDeptDelete: function(oEvent) {
            var oBundle = this._getResourceBundle(),
                oEventClone = jQuery.extend(true, {}, oEvent);
            MessageBox.show(oBundle.getText("MESSAGE_DEPARTMENT_DELETE_WARNING"), {
                icon: MessageBox.Icon.WARNING,
                title: oBundle.getText("TOOLTIP_DEPT_DELETE"),
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                onClose: this._onConfirmDeptDelete.bind(this, oEventClone)
            });
        },

        /**
         * Add NONE item to the list after update
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onDeptListUpdateFinished: function(oEvent) {
        	if (!this._getDialogProperty("ValueHelpMode")) {
	            var oList = oEvent.getSource(),
	                oNoneItem = this._getNoneItem(oList);
	            if (oList.indexOfItem(oNoneItem) === -1) {
	                oList.insertItem(oNoneItem, 0);
	            }
        	}
        },
        
        /**
         * Handle dept search
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onDeptSearch: function(oEvent) {
            var sValue = oEvent.getParameter("newValue").toLowerCase();
            this._getList().getBinding("items").filter([
                new Filter("DepartmentDesc", FilterOperator.Contains, sValue)
            ]);
        },
        
        /**
         * Assign selected dept to user
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onDeptSelect: function(oEvent) {
            var oSelectedItem = oEvent.getSource();
            if (oSelectedItem && this._getRequester().selectDepartment) {
                this._getRequester().selectDepartment(oSelectedItem.getTitle());
            }
            this.close();
        },
        
        /**
         * Exit edit mode
         * @event
         * @public
         */
        onDoneButtonPress: function() {
            this._setDialogProperty("EditMode", false);
        },
        
        /**
         * Enter edit mode
         * @event
         * @public
         */
        onEditDeptListButtonPress: function() {
            this._setDialogProperty("EditMode", true);
        },
        
        /**
         * Set Value Help mode
         * @param {boolean} bValueHelpMode mode
         * @returns {sap.support.useradministration.controller.dialog.SelectUserDepartment} this for chaining
         * @function
         * @public
         */
        setValueHelpMode: function (bValueHelpMode) {
        	return this.setProperty("ValueHelpMode", Boolean(bValueHelpMode));
        }
    });
});
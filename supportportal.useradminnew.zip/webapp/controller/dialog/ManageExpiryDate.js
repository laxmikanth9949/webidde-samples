sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Settings",
	"sap/support/useradministration/util/Util"
], function (BaseDialog, Constant, Settings, Util) {
	var _fnAddYearToDate = function (date, year) {
		var futureDate = new Date(date.setFullYear(date.getFullYear() + year));
		return futureDate;
	};
	var _fnFactory = function () {
		this.question = "";
		this.aSelectedContext = [];
		this.minDate = Util.date.getMinExpiryDate();
		this.maxDate = _fnAddYearToDate(new Date(), Settings.maxYearsForUserExtension);
		this.expDate = _fnAddYearToDate(new Date(), Settings.prefilledYearsForUserExtension);
		this.massUpdate = false;
		
		this.Users = [];
	};

	/**
	 * Dialog for managing Expiry Date of User
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseDialog
	 * @alias sap.support.useradministration.controller.dialog.ManageExpiryDate
	 */
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.ManageExpiryDate", {
		_fnDataFactory: _fnFactory,
		_sDialogName: Constant.Dialog.MANAGE_EXPIRY_DATE,

		/**
		 * Clear date selection and format question text
		 * @function
		 * @private
		 * @override
		 */
		beforeOpen: function () {
			var sText = "";
			
			this._clearDates();
			if (this._isMassEdit()) {
				sText = this.getText("DIALOG_MSG_MANAGE_EXP_DATE_MASS");
				this.setProperty("maxDate", _fnAddYearToDate(new Date(), Settings.maxYearsForMassExtension));
			} else {
				var oUser = this._getSelectedUser();
				sText = this.getText("DIALOG_MSG_MANAGE_EXP_DATE_STRONG_FULL_NAME", [oUser.FirstName, oUser.LastName, oUser.UserId]);
			}

			this.setProperty("question", sText);
		},
		
		/**
		 * Handle selected date change
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onDateChange: function (oEvent) {
			var oDatePicker = oEvent.getSource(),
				bValid =  oEvent.getParameter("valid");
				
			if (!bValid) {
				// KNGMHM02-19883 Removed "date over range check"
				/*var sNewValue = evt.getParameter("newValue"),
					bIsDateValid = !!oDatePicker._parseValue(sNewValue);*/
				
				oDatePicker.setValueState(sap.ui.core.ValueState.Error);
				oDatePicker.setValueStateText(this.formatter.request.invalidExpiryDateValueStateText(/*bIsDateValid*/ false,
					this._isMassEdit()? Settings.maxYearsForMassExtension : Settings.maxYearsForUserExtension));
			} else {
				oDatePicker.setValueState(sap.ui.core.ValueState.None);
			}
		},

		/**
		 * Handle saving Expiry Date for User
		 * @event
		 * @public
		 */
		onOK: function () {
			var oDatePicker = this._getExpiryDatePicker();
			if (oDatePicker.getDateValue() && oDatePicker._bValid) {
				this._extendUsers();
			}
		},
		
		/**
		 * Set selected users
		 * @param {object[]} aUsers users frontend objects
		 * @returns {sap.support.useradministration.controller.dialog.ManageExpiryDate} this for chaining
		 * @function
		 * @public
		 */
		setSelectedUsers: function (aUsers) {
			return this.setProperty("Users", aUsers);
		},
		
		/**
		 * Set selected users from backend binding contexts
		 * @param {sap.ui.model.ContextBinding[]} aContexts contexts bound directly to backend
		 * @returns {sap.support.useradministration.controller.dialog.ManageExpiryDate} this for chaining
		 * @function
		 * @public
		 */
		setSelectedUsersFromContexts: function (aContexts) {
			var aUsers = aContexts.map(function (oContext) {
				var oObject = oContext.getObject();
				return this.getUserSetODataUtil().toFrontendEntry(oObject);
			}.bind(this));
			return this.setSelectedUsers(aUsers);
		},
		
		/**
		 * Clear calendar dates
		 * @function
		 * @private
		 */
		_clearDates: function() {
			this.setProperty("minDate", Util.date.getMinExpiryDate());
			this.setProperty("maxDate", _fnAddYearToDate(new Date(), Settings.maxYearsForUserExtension));
			this.setProperty("expDate", _fnAddYearToDate(new Date(), Settings.prefilledYearsForUserExtension));
		},
		
		/**
		 * Extend selected users' expiry dates
		 * @function
		 * @private
		 */
		_extendUsers: function () {
			var oModel = this.getModel(),
				expDate = this.getProperty("expDate"),
				aUsers = this.getProperty("Users"),
				aUserIds = aUsers.map(function (oUser) {
					if (oUser.Function !== Constant.UserCriticalRole.SUPERADMIN && oUser.Function !== Constant.UserCriticalRole.SUPERADMIN_CLOUD) {
						return oUser.UserId;
					}
					return null;
				}).filter(Boolean),
				bIsSingleUser = aUserIds.length === 1,
				sSuserIds = aUserIds.join(",");

			var sPath = "/ExtendUserDate",
				oOptions = {
					method: "GET",
					urlParameters: {
						UserIds: sSuserIds,
						ExpDat: Util.date.dateToUTCDate(expDate)
					},
					refreshAfterChange: true
				};
			
			if (sSuserIds) {
				this.setBusy(true);
				oModel.setUseBatch(true);
				Util.promiseCallFunction.call(this, sPath, oOptions, oModel)
					.then(function () {
						Util.showToast(this.getText(bIsSingleUser ? "MESSAGE_OK_MANAGE_EXPIRY_DATE_FULL_SINGLE" : "MESSAGE_OK_MANAGE_EXPIRY_DATE_FULL_MULTIPLE"));
						oModel.setUseBatch(false);
						
						if (this._oController.updateAfterManageExpiryDate) {
							this._oController.updateAfterManageExpiryDate();
						}
						this.close();
					}.bind(this))
					.finally(function () {
						this.setBusy(false);
						oModel.setUseBatch(false);
					}.bind(this));
			} else {
				sap.m.MessageToast.show(this.getText("MESSAGE_OK_MANAGE_EXPIRY_DATE_FULL_NEW"));
				this.close();
			}
		},
		
		/**
		 * Get date picker
		 * @returns {sap.m.DatePicker} picker
		 * @function
		 * @private
		 */
		_getExpiryDatePicker: function () {
			return sap.ui.getCore().byId("idDatePicker-ManageExpDate");
		},
		
		/**
		 * Get selected user for single user mode
		 * @returns {object} user data
		 * @function
		 * @private
		 */
		_getSelectedUser: function () {
			var aUsers = this.getProperty("Users") || [];
			return aUsers[0];
		},
		
		/**
		 * Check if multiple users are edited
		 * @returns {boolean} result
		 * @function
		 * @private
		 */
		_isMassEdit: function () {
			var aUsers = this.getProperty("Users") || [];
			return aUsers.length > 1;
		}
	});
});
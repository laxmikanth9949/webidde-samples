sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialog",
	"sap/support/useradministration/util/Util"
], function(BaseDialog, Util) {
	"use strict";
	
	var BACKUP = "Backup",
		ITEMS = "Items";

	var _fnFactory = function() {
		this[BACKUP] = [];
		this[ITEMS] = [];
	};

	/**
	 * Base view settings dialog controller
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseDialog
	 * @alias sap.support.useradministration.controller.dialog.BaseViewSettingsDialog
	 */
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.BaseViewSettingsDialog", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "BaseViewSettingsDialog",
		_sTableName: "",
		_sPath: "",
		_aFilters: [],
		
        /**
         * Apply settings
         * @function
         * @protected
         */
		_applySettings: function() {
			var oTable = this._getTable(),
				aSettings = this.getProperty(ITEMS),
				oSettings = {};
			
			aSettings.forEach(function (oSetting) {
				oSettings[oSetting.ColumnId] = {
					Visible: oSetting.ColumnVisibility,
					Index: oSetting.ColumnIndex
				};
			});
			
			oTable.getColumns().map(function (oColumn) {
				var sColumnId = oColumn.getKey(),
					oSetting = oSettings[sColumnId],
					bVisible = oSetting && oSetting.Visible;
					
				oColumn.setVisible(!!bVisible);
				if (bVisible) {
					oColumn.setOrder(oSetting.Index);
				}
			});
			
			oTable.invalidate();
		},
		
		/**
		 * Load data before open
		 * @function
		 * @protected
		 * @override
		 */
		_beforeOpen: function () {
			if (!this._isDataLoaded()) {
				this.setBusy(true);
				this._loadData()
					.finally(this.setBusy.bind(this, false));
			}
		},
		
		/**
		 * Store items into backup
		 * @function
		 * @private
		 */
		_doBackup: function () {
			var aList = this.getProperty(ITEMS) || [];
			this.setProperty(BACKUP, aList.map(Util.copy));
		},
		
		/**
		 * Extract postfix ID from the column
		 * @param {sap.m.Column} oColumn column
		 * @returns {string} postfix
		 * @function
		 * @private
		 */
		_extractColumnIdPostfix: function (oColumn) {
			return (/[A-Za-z0-9_]+$/.exec(oColumn.getId()) || [])[0] || "";
		},
        
        /**
         * Get dialog fragment for current controller
         * @returns {sap.m.Dialog} dialog
         * @function
         * @private
         * @override
         */
        _getDialogFragment: function () {
        	return sap.ui.xmlfragment("sap.support.useradministration.view.dialog.BaseViewSettingsDialog", this);
        },
		
		/**
		 * Get table to set up
		 * @returns {sap.m.Table} table
		 * @function
		 * @protected
		 */
		_getTable: function () {
			return null;
		},
        
        /**
         * Check if data is loaded
         * @returns {boolean} result
         * @function
         * @private
         */
        _isDataLoaded:  function() {
        	var aItems = this.getProperty(ITEMS);
        	return Boolean(aItems && aItems.length);
        },
        
        /**
         * Load data
         * @returns {Promise} promise
         * @function
         * @private
         */
        _loadData: function () {
			return Util.promiseRead.call(this._oController, this._sPath, {
					filters: this._aFilters
				}, this._sModelName)
				.then(this._processList.bind(this));
        },
        
        /**
         * Prepare item got from the backend
		 * @param {sap.m.Column[]} aColumns table columns
         * @param {object} oItem item
         * @returns {object} prepared item
         * @function
         * @public
         */
        _prepareItem: function (aColumns, oItem) {
        	return {
        		ColumnId: oItem.ColumnId,
        		ColumnText: Util.getText.call(this, oItem.ColumnText),
        		ColumnIndex: oItem.ColumnIndex,
        		ColumnVisibility: Boolean(oItem.ColumnVisibility)
        	};
        },
        
        /**
         * Process list came from the backend
         * @param {object} oData  odata response
         * @function
         * @private
         */
        _processList: function (oData) {
			var aList = oData.results || [];
			aList = aList.map(this._prepareItem.bind(this, this._getTable().getColumns()));
			this.setProperty(ITEMS, aList);
			this._doBackup();
        },
		
		/**
		 * Restore items from backup
		 * @function
		 * @private
		 */
		_restoreBackup: function () {
			var aList = this.getProperty(BACKUP) || [];
			this.setProperty(ITEMS, aList.map(Util.copy));
		},
		
		/**
		 * Save settings at the backend
		 * @returns {Promise} promise
		 * @function
		 * @private
		 */
		_saveSettings: function () {
			var aSettings = this.getProperty(ITEMS) || [],
				sBatchGroupId = this._sDialogName,
				oModel = this._oView.getModel();
			
			if (!aSettings.some(Util.callbacks.getKey("ColumnVisibility"))) {
				sap.m.MessageBox.error(this.getText("MESSAGE_ZERO_COLUMN"));
				return Promise.reject();
			}
			
			oModel.setUseBatch(true);
			oModel.setDeferredGroups([sBatchGroupId]);
			
			aSettings.forEach(function (oColumn) {
				var sColumnId = oColumn.ColumnId,
					bColumnVisible = !!oColumn.ColumnVisibility,
					iColumnIndex = oColumn.ColumnIndex,
					sPath = Util.formatMessage("/UserTableColumnSet(TableName=''{0}'',ColumnId=''{1}'')", [this._sTableName, sColumnId]),
					oModelItem = Util.merge({}, oModel.getProperty(sPath));
					
				if (iColumnIndex || iColumnIndex === 0) {
					oModelItem.ColumnIndex = iColumnIndex;
				}
				
				oModelItem.ColumnVisibility = bColumnVisible;
				oModel.update(sPath, oModelItem, {
					groupId: sBatchGroupId
				});
			}.bind(this));
			
			var oPromise = Util.promiseSubmitChanges.call(this._oController, {
				groupId: sBatchGroupId
			});
			
			oPromise.then(function () {
				sap.m.MessageToast.show(this.getText("MESSAGE_SETTING_SAVED"));
			}.bind(this)).finally(function () {
				oModel.setUseBatch(false);
			});
			
			return oPromise;
		},
		
		/**
		 * Load columns's data from the backend then apply settings to corresponding table
		 * @function
		 * @public
		 */
		loadAndApplyColumnsSettings: function () {
			this._loadData()
				.then(this._applySettings.bind(this));
		},

		/** 
		 * Handle filter cancel
		 * @event
		 * @public
		 */
		onCancel: function() {
		    this._restoreBackup();
			this.close();
		},

		/** 
		 * Handle filter confirmation
		 * @event
		 * @public
		 */
		onConfirm: function() {
			this.setBusy(true);
			
			this._saveSettings()
				.then(function () {
				    this._applySettings();
				    this._doBackup();
				}.bind(this))
				.finally(function () {
					this.setBusy(false);
					this.close();
				}.bind(this));
		}
	});
});
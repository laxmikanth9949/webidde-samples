sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseValueHelpDialog",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",

	"sap/m/Token"
], function(BaseValueHelpDialog, Constant, Util, Token) {
	/**
	 * Factory for dialog model
	 * @function
	 * @private
	 */
	var _fnFactory = function() {
		this.ModelName = undefined;
		this.Items = [];
		this.Search = "";
	};

	var ITEMS = "Items";
	var MODEL_NAME = "ModelName";
	
	var Callbacks = Util.callbacks;

	/**
	 * Dialog for selecting restricted tenants
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseValueHelpDialog
	 * @alias sap.support.useradministration.controller.dialog.SelectRestrictedTenants
	 */
	return BaseValueHelpDialog.extend("sap.support.useradministration.controller.dialog.SelectRestrictedTenants", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "SelectRestrictedTenants",

		/**
		 * Get installation items from model
		 * @returns {object[]} installations
		 * @function
		 * @private
		 */
		_getItems: function() {
			return this._getDialogProperty(ITEMS) || [];
		},

		/**
		 * Load items from backend
		 * @returns {object} promise
		 * @function
		 * @public
		 */
		_loadItems: function() {
			var oModel = Util.getModel.call(this._oController, this._getDialogProperty(MODEL_NAME)),
				oPromise = this._getPromise();

			if (this._oLoader && this._oLoader.abort) {
				this._oLoader.abort();
			}

			this._setDialogProperty(ITEMS, []);
			this._oLoader = oModel.read("/cloud_tenantsSet", {
				success: function(oData) {
					this._updateItems(oData.results || []);
					this.getDialog().update();
					oPromise.resolve();
				}.bind(this),
				error: function() {
					oPromise.reject();
				}
			});

			return oPromise.promise();
		},

		/**
		 * Prepare table when opening dialog
		 * @param {sap.ui.table.Table} oTable table
		 * @function
		 * @private
		 * @override
		 */
		_prepareTable: function(oTable) {
			if (!oTable.getModel("columns")) {
				oTable.setModel(this.createJSONModel({
					cols: [{
						label: this.getText("MASTER_COLUMN_TENANT_NAME"),
						template: "dialog>TenantName"
					}, {
						label: this.getText("MASTER_COLUMN_TENANT_NUM"),
						template: "dialog>TenantNumber"
					}, {
						label: this.getText("MASTER_COLUMN_INST_NAME"),
						template: "dialog>InstProd"
					}, {
						label: this.getText("MASTER_COLUMN_INST_NUM"),
						template: "dialog>InstNumber"
					}, {
						label: this.getText("MASTER_COLUMN_CUST_NUM"),
						template: "dialog>CustomerId"
					}, {
						label: this.getText("MASTER_COLUMN_CUST_NAME"),
						template: "dialog>CustomerName"
					}]
				}), "columns");
			}

			oTable.bindRows({
				path: "dialog>" + ITEMS
			});
		},

		/**
		 * Updates tenats list in the parent controller
		 * @param {sap.m.Token[]} aTokens array of tokens
		 * @function
		 * @private
		 */
		_saveTenants: function(aTokens) {
		    var aItems = this._getItems(),
		        oKeyToItem = Util.combineArray(aItems, Callbacks.getKey("AuthLevel"), Callbacks.self), // Create map { Item.AuthLevel => Item }
			    aTenants = aTokens.map(function (oToken) {
                    var oTokenItem = oKeyToItem[oToken.getKey()];
                    return oTokenItem && jQuery.extend(true, {}, oTokenItem);
    			}).filter(Boolean);
    	    
			this._oController.saveTenants(aTenants);
		},

		/** 
		 * Update items in the dialog model
		 * @param {object[]} aItems items retrieved from the backend
		 * @function
		 * @private
		 */
		_updateItems: function(aItems) {
			this._setDialogProperty(ITEMS, aItems);
		},

		/**
		 * Handle dialog confirmation
		 * Ask user to confirm changes
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onConfirmDialog: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this.close();
			this._saveTenants(aTokens);
		},

		/**
		 * Open dialog and load items
		 * @function
		 * @public
		 * @override
		 */
		open: function() {
			BaseValueHelpDialog.prototype.open.call(this);
			this.setBusy(true);
			this._loadItems().always(this.setBusy.bind(this, false));
		},

		/**
		 * Set model name property
		 * @param {string} sModelName model name
		 * @function
		 * @public
		 */
		setModelName: function(sModelName) {
			this._setDialogProperty(MODEL_NAME, sModelName);
		},

		/**
		 * Update tokens from tenants
		 * @param {object[]} aTenants tenants
		 * @function
		 * @public
		 */
		updateTokens: function(aTenants) {
		    var aTokens = aTenants.map(function (oTenant) {
			    return new Token({
					key: oTenant.TenantNumber,
					text: oTenant.TenantName + " (" + oTenant.TenantNumber + ")"
			    });
			});
			this.getDialog().setTokens(aTokens);
		}
	});
});
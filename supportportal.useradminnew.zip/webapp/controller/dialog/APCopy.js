sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew"
], function (BaseDialogNew) {
	var AUTH_PACK_TABLE_ID = "idAuthPackagesTable";

	return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.APCopy", {
		_sDialogName: "APCopy",

		beforeOpen: function () {
			var oSelAP = this._getSelectedAP(),
				oModel = this._oView.getModel("ap"),
				oItemData = oModel.getData(oSelAP.getBindingContextPath());
			this.setProperty("Description", this.getText("MESSAGE_DESCRIPTION_AUTH_PACK_COPY", [oItemData.Text]));
			// this.setProperty("Input", oItemData.Text + "-Copy");
			this.setProperty("Selected", false);
			this.setProperty("isShowProtection", this._oView.getParent().__function === "1SUPERADMIN");

			// if (this._oView.getParent().__function === "1SUPERADMIN") {
			// 	this.getDialog().getContent()[2].setVisible(true);
			// } else {
			// 	this.getDialog().getContent()[2].setVisible(false);
			// }
		},
		setSelectedAP: function (oSelectedAP) {
			return this.setProperty("AuthPack", oSelectedAP);
		},
		_getSelectedAP: function () {
			return this.getProperty("AuthPack");
		},
		
		onAuthPackNameCopyChange: function() {
			this.setProperty("State", sap.ui.core.ValueState.None);
		},
		
		onAPCopy: function () {
			this.setProperty("isEnabled", false);
			var oModel = this._oView.getModel("ap"),
				oSelItem = this._getSelectedAP(),
				sPackId = oModel.getData(oSelItem.getBindingContextPath()).AuthPackId,
				sPath = "/auth_pack_copy_for_custSet",
				oItemData = {};
			// Mandatory field validation check
			// Validate AP name
			if (!this.getProperty("Input")) {
				this.setProperty("State", sap.ui.core.ValueState.Error);
				this.setProperty("StateText",
					this.getText("MESSAGE_AP_EMPTY_NEW"));
				sap.ui.getCore().byId("authPackNameCopy").focus();

				this.setProperty("isEnabled", true);
				return;
			} else {
				this.setProperty("State",
					sap.ui.core.ValueState.None);
				this.setProperty("StateText", "");
			}

			oItemData.Text = this.getProperty("Input");
			oItemData.Protected = !!this.getProperty("Selected");
			oItemData.CopyauthPackID = sPackId;

			oModel.create(sPath, oItemData, {
				success: function () {
					sap.m.MessageToast.show(this.getText("COPY_AP_SUCCESS"));
					this._oController._invalidateTabs(["AuthPackages"]);
					this.getDialog().close();
				}.bind(this),

				error: function (oError) {
					if (oError.statusCode === "400") {
						this.setProperty("State", sap.ui.core.ValueState.Error);
						this.setProperty("StateText",
							this.getText("MESSAGE_CREATE_AUTH_PACK_DUPLICATE_NAME"));
						return;
					}
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					sap.m.MessageToast.show(this._oUABundle.getText(oErrorBodyObj.error.code + "_TITLE"));
					this.getDialog().close();
				}.bind(this)
			});
			this.setProperty("isEnabled", true);
		}
	});
});
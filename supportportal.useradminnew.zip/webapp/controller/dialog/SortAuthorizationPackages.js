sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for sorting authorization packages
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SortAuthorizationPackages
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SortAuthorizationPackages", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SortAuthorizationPackages",
        
        onSubmit: function(oEvent) {
			var mParams = oEvent.getParameters(),
				oBinding = this._oView.byId("idAuthPackagesTable").getBinding("items"),
				aSorters = [],
				sPath = mParams.sortItem.getKey(),
				bDescending = mParams.sortDescending;
			aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
			oBinding.sort(aSorters);
        }
   
    });
});
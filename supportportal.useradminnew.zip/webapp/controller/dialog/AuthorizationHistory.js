sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/extended/SmartTable"
], function(BaseDialog, Util, SmartTable) {
	
    var _fnFactory = function() {
    	this.User = "";
    	this.Count = 0;
    };
    
    var oSearchRequest = null;
    var bSizeFixed = false;
    
    /**
     * Dialog for showing user's authorization history
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
     * @alias sap.support.useradministration.controller.dialog.AuthorizationHistory
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.AuthorizationHistory", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "AuthorizationHistory",
        
        beforeOpen: function () {
        	if (!this._getSettings().isAuthorizationAssignmentHistoryEnabled) {
		 		return;
		 	}
		 	this.requestHistoryCount();
        	this.requestHistory();
        },
        
        beforeClose: function () {
        	if (this.getTable()) {
        		this.getTable().getInfoToolbar().setVisible(false);
        		this._oController._oDialogs.getDialog("SortAuthorizationHistory").destroy();
        		this._oController._oDialogs.getDialog("FilterAuthorizationHistory").destroy();
        	}
        	bSizeFixed = false;
        },
        
        setUser: function (sUser) {
			return this.setProperty("User", sUser);
		},
		
		getUser: function() {
			return this.getProperty("User");
		},
		
		setTable: function (oEvent) {
			if (!this._oTable) {
				this._oTable = Util.closest(oEvent.getSource(), SmartTable);
			}
		},
		
		getTable: function () {
			return this._oTable;
		},
		
		requestHistoryCount: function (aSearchFilters) {
			var aFilters = [new sap.ui.model.Filter("Ubname", sap.ui.model.FilterOperator.EQ, this.getProperty("User"))];
			if (aSearchFilters && aSearchFilters.length) {
				aFilters = aFilters.concat(aSearchFilters);
			}
			
			Util.promiseRead.call(this, "/AuthAssignmentHistorySet/$count", {
				filters: aFilters
			}).then(function (count) {
        			this.setProperty("Count", count);
        			if (!bSizeFixed) {
						if (count === "0") {
        				    this.getDialog().setContentHeight("12rem");
						} else { 
							this.getDialog().setContentHeight(count * 2 + 15.5 + "rem");
						}
						bSizeFixed = true;
        			}
        		}.bind(this))
        		.catch(function () {
        			this.setProperty("Count", 0);
        			if (!bSizeFixed) {
						this.getDialog().setContentHeight("12rem");
						bSizeFixed = true;
        			}
        		}.bind(this, {}));
		},
 
		requestHistory: function () {
		 	var oTable = sap.ui.getCore().byId("idAuthAssignHistoryTable"),
		 		oBindingInfo = oTable && oTable.getBindingInfo("items");
		 		
		 	oTable.bindItems({
		 		path: "/AuthAssignmentHistorySet",
		 		filters: [
		 			new sap.ui.model.Filter("Ubname", sap.ui.model.FilterOperator.EQ, this.getProperty("User"))
		 		],
		 		sorter: [
		 			new sap.ui.model.Sorter("Logdate", true),
		 			new sap.ui.model.Sorter("Logtime", true)
		 		],
		 		template: oBindingInfo.template
		 	});
		 	oTable.getBinding("items").refresh(true);
		},
		
		onSearch: function (oEvent) {
			// add filter for search
			var aFilters = [],
				aSearchFilters = [];

			var sSearchQuery = oEvent.getSource().getValue();
			
			if (oSearchRequest) {
				clearTimeout(oSearchRequest);
			}
			oSearchRequest = setTimeout(function (sQuery) {
				if (sQuery && sQuery.length > 2) {
					aSearchFilters = ["Otext", "PgroupText", "ProfnaText", "Profna", "Loguser", "Namev", "Name1", "AuthPackText"
						].map(function (column) {
							return new sap.ui.model.Filter(column, sap.ui.model.FilterOperator.Contains, sQuery);
						});
					aSearchFilters.push(
						new sap.ui.model.Filter("Search", sap.ui.model.FilterOperator.EQ, true)
					);
					aFilters = [new sap.ui.model.Filter({
						filters: aSearchFilters,
						and: true
					})];
				}
				
				// update table binding
				this.getDialog().getContent()[0].getBinding("items").filter(aFilters);
				
				this.requestHistoryCount(aSearchFilters);
			}.bind(this, sSearchQuery), 500);
		},
		
		pressDownload: function (oEvent) {
			var oTable = Util.closest(oEvent.getSource(), SmartTable);
		 	
		 	Util.showToast(this.getText("MESSAGE_DOWNLOADING_DATA"));
		 	
			if (oTable) {
				oTable.saveToFile(null, true);
			}
		},
		
		pressSort: function (oEvent) {
			this.setTable(oEvent);
			this._oController._oDialogs.getDialog("SortAuthorizationHistory")
				.open(this);
		},
		
		pressFilter: function (oEvent) {
			this.setTable(oEvent);
			this._oController._oDialogs.getDialog("FilterAuthorizationHistory")
				.open(this);
		}
    });
});
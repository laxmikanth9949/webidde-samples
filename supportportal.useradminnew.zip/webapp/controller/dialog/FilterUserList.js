sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
    "sap/support/useradministration/util/Util",
	"sap/ui/model/Filter"
], function(BaseDialogNew, Util, Filter) {
    "use strict";

    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
     * @alias sap.support.useradministration.controller.dialog.FilterUserList
     */
    return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.FilterUserList", {
        _fnDataFactory: function() {
	    	this.Months = {
	    		"1": 1,
	    		"2": 2,
	    		"3": 3,
	    		"6": 6,
	    		"12": 12,
	    		"24": 24,
	    		"60": 60
	    	};
	    	
	    	this.ExpiryDateMonths = [1, 2, 3, 24, 60].map(function (iMonth) {
	    		return {
	    			Month: iMonth
	    		};
	    	});
	    },
        _sDialogName: "FilterUserList",
        
        beforeOpen: function() {
        	this.setProperty("IsNewDepartmentAPIEnabled", this._getSettings().isNewDepartmentAPIEnabled);
        	if (!this.getProperty("/DepartmentList") || this._bInvalid) {
        		this._loadDepartmentList();
        	}
        	if (!this._bItemsDeleted) {
        		this._deleteItems();
        	}
        	this._loadAuthObjectList();
			this._loadDomainList();
        },
        
        /**
         * Delete filters that should not be visible
         * @function
         * @private
         */
        _deleteItems: function () {
        	var bNewDepartmentAPI = this._getSettings().isNewDepartmentAPIEnabled,
        		bLifetimeEnabled = this._getSettings().isSUserLifetimeEnabled,
        		bIsEmailFilterEnabled = this.getModel("appSettings").getData().isEmailFilterEnabled,
				bIsLocalUIDListEnabled = this.getModel("appSettings").getData().showUIDUserList,
				bIsDomainFilterEnabled = this.getModel("appSettings").getData().isDomainFilterEnabled,
        		oDialog = this.getDialog();
    		oDialog.getFilterItems().filter(function (oItem) {
    			switch (oItem.getKey())  {
    				case "DepartmentNew":
    					return !bNewDepartmentAPI;
    				case "DepartmentLong":
    					return bNewDepartmentAPI;
    				case "Status":
    				case "ExpDate":
    					return !bLifetimeEnabled;
					case "EmailFilter":
						return !bIsEmailFilterEnabled;
					case "IsUidAssigned":
						return !bIsLocalUIDListEnabled;
					case "DomainFilter":
						return !bIsDomainFilterEnabled;
					default:
    					return false;
    			}
    		}).forEach(function (oItem) {
    			oDialog.removeFilterItem(oItem);
    		});	
    		this._bItemsDeleted = true;
        },
        
        /**
         * Load department list
         * @function
         * @private
         */
        _loadDepartmentList: function () {
        	var bNewDepartmentAPI = this._getSettings().isNewDepartmentAPIEnabled;
        	
        	this.setBusy(true);
        	Util.promiseRead.call(this, bNewDepartmentAPI ? "/DepartmentNewSet" : "/DepartmentSet")
        		.then(this._processDepartmentList.bind(this))
				.finally(this.setBusy.bind(this, false));
        },
        
        /**
         * Process department list came from backend
         * @param {object} oData data
         * @function
         * @private
         */
        _processDepartmentList: function (oData) {
        	var bNewDepartmentAPI = this._getSettings().isNewDepartmentAPIEnabled;
        	
			this._bInvalid = false;
			var aList = oData.results || [];
			aList = aList.map(function (oItem) {
				return jQuery.extend(bNewDepartmentAPI ? {
					ContextId: "_" + oItem.DepartmentId,
					_Type: 1
				} : {
					Key: oItem.DepartmentDesc
				}, oItem);
			}).sort(Util.getSorter("DepartmentName"));
			aList.unshift(bNewDepartmentAPI ? {
				DepartmentId: "",
				DepartmentName: this._getResourceBundle().getText("MASTER_NONE"),
				ContextId: "NONE",
				_Type: 0
			} : {
				UserId: "",
				DepartmentDesc: this._getResourceBundle().getText("MASTER_NONE"),
				Key: ""
			});
			this.setProperty("DepartmentList", bNewDepartmentAPI ? Util.mapBy(aList, "ContextId") : aList);
        },
        
        _loadAuthObjectList: function() {
        	this.setBusy(true);
        	Util.promiseRead.call(this, "/AuthObjectSet")
        		.then(function (oData) {
        			var aList = oData.results || [];
        			this.setProperty("AuthObjectList", aList.filter(function (oItem) {
        				return oItem.AuthLevelId !== "group";
        			}));
        		}.bind(this))
				.finally(this.setBusy.bind(this, false));
        },
        
        /**
         * Invalidate local data
         * @function
         * @public
         */
        invalidate: function () {
        	this._bInvalid = true;
        },
        
		_loadDomainList: function () {
			this.setBusy(true);

				this._getDomainList()
				  .then(function (oData) {
					// var domains = this._removeDuplicatesAndSort(values.flat(1));
					this.setProperty("DomainList", oData);
				  }.bind(this))
				  .finally(this.setBusy.bind(this,false));
		},

		_getDomainList: function() {
			// this is needed by utils library to get the list of domains
			// this.oDataDomain = new sap.ui.model.odata.v2.ODataModel('/services/odata/emaildomain/', {json: true});
			this.oDataDomain = this.getModel("domains");
			var oPromise = {},
			domainCheckActive = this.getModel("appSettings").oData.domainCheckActive;
			if (domainCheckActive) {
				// var sKunnr = sCustomerNumber;
				var oPromise = Util.promiseRead.call(this, "/DomainsUsed", {

				}, this.oDataDomain)
				.then(function (aResults){
					return aResults.results;
				});
				return oPromise;
			} else {
				oPromise = new Promise(function (resolve) {
					resolve([]);
				});
			}
			return oPromise;
		},

		_removeDuplicatesAndSort: function(aDomains) {
			var aUniqueDomainList = Array.from(new Set(aDomains.map(function(item) {
				return item.Ipadr;
			}))).map(function(ipadr) {
				return aDomains.find(function(item) {
					return item.Ipadr == ipadr;
				});
			});

			var aSortedDomainList = aUniqueDomainList.sort(function(a,b) {
				var ipadrA = a.Ipadr.toLowerCase();
				var ipadrB = b.Ipadr.toLowerCase();
				return ipadrA.localeCompare(ipadrB);
			})
			return aSortedDomainList;
		},

        onSubmit: function(oEvent) {
			var 
				table = this._oController._getUserTable(),
				params = oEvent.getParameters();
			
			var filters = (params.filterItems && params.filterItems.map(function (item) {
				var split = item.getKey().split("___");
				//0 - path, 1 - operator, 2 - value1, 3 - value2 
				return new Filter(split[0], split[1], split[2], split[3]);
			})) || [];

			table.getBinding("items").filter(filters, "Control");

			table._aCUFilters = filters;

			// update filter bar
			table.getInfoToolbar().setVisible(!!filters.length);
			table.getInfoToolbar().getContent()[0].setText(params.filterString);
			
			this._getController()._isUserTableFiltered = true;                       
        },
        
        /**
         * Refresh filters for Department New
         * @param {object[]} aDepartmentList list of departments
         * @function
         * @public
         */
        refreshDepartmentNewFilters: function (aDepartmentList) {
        	if (this.getProperty("/DepartmentList")) {
        		this._processDepartmentList({
        			results: aDepartmentList
        		});
        	}
        }
   
    });
});
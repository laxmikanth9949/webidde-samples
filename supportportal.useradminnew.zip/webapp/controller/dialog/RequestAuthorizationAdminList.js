sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
    "sap/support/useradministration/util/Util"
], function(BaseDialog, Util) {
	"use strict";
	
	var Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator,
		ImportantContactFunction = Util.Constant.ImportantContactFunction;
		
	var MODEL_DIALOG = "dialog",
		MODEL_LPUI = "lpui",
		MODEL_UA;
	
    var _fnFactory = function() {
    	this.AdminList = [];
    	this.SelectedAdmin = null;
    	this.SelectedAuth = null;
    	this.SelectedAuthKey = null;
    };
    
    /**
     * Dialog for requesting authorizations by writing email to admin
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
     * @alias sap.support.useradministration.controller.dialog.RequestAuthorizationAdminList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.RequestAuthorizationAdminList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "RequestAuthorizationAdminList",
        _oSelectedAdmin: null,
        _bIsLaunchpadModel: false, // if we should use launchpaduisrv model
        
        beforeOpen: function () {
        	this._removeAuthSelections();
        	this._loadAdminList();
        	this._setFilters([]);
        },
        
        /**
         * Get admin list control
         * @returns {sap.m.List} list
         * @function
         * @private
         */
        _getList: function () {
        	return this.getDialog().getControlsByFieldGroupId("adminList")[0];
        },
        
        /**
         * Load data from backend
         * @function
         * @private
         */
        _loadAdminList: function () {
        	if (!this.getProperty("AdminList").length) {
        		var oPromise;
        		
        		this.setBusy(true);
        		if (this._bIsLaunchpadModel) {
        			oPromise = Util.promiseRead.call(this, "/AdminUserSet", {}, MODEL_LPUI);
        		} else {
        			oPromise = Util.promiseRead.call(this, "/ImportantRolesSet", {
        				filters: [
	        				new Filter("FunctionId", FilterOperator.EQ, ImportantContactFunction.SUPERADMIN),
	        				new Filter("FunctionId", FilterOperator.EQ, ImportantContactFunction.SUPERADMIN_CLOUD),
	        				new Filter("IS_4_SETTINGS", FilterOperator.EQ, true)
	        			]
        			}, MODEL_UA);
        		}
        		oPromise.then(this._processAdminList.bind(this))
        			.finally(this.setBusy.bind(this, false));
        	}
        },
        
        /**
         * Process admin list retrieved from backend
         * @param {object} oData backend data
         * @function
         * @private
         */
        _processAdminList: function (oData) {
        	var bIsLaunchpadModel = this._bIsLaunchpadModel,
        		aRawAdminList = oData && oData.results || [];
        		
	    	this.setProperty("AdminList", aRawAdminList.map(function (oEntry) {
				return {
					LastName: bIsLaunchpadModel ? oEntry.AdminLastname : oEntry.LastName,
					FirstName: bIsLaunchpadModel ? oEntry.AdminFirstname : oEntry.FirstName,
					Email: bIsLaunchpadModel ? oEntry.AdminEmail : oEntry.Email,
					Location: bIsLaunchpadModel ? oEntry.AdminLocation : "",
					UserId: oEntry.UserId
				};
    		}));
        },
        
        /**
         * Remove selection for admin list
         * @function
         * @private
         */
        _removeAdminSelections: function () {
        	var oList = this._getList();
        	
        	this.setProperty("SelectedAdmin", null);
        	if (oList) {
        		oList.removeSelections();
        	}
        },
        
        /**
         * Remove selection for auth select
         * @function
         * @private
         */
        _removeAuthSelections: function () {
        	this.setProperty("SelectedAuth", null);
        	this.setProperty("SelectedAuthKey", null);
        },
        
        /**
         * Set filters for admin list
         * @param {sap.ui.model.Filter[]} aFilters filters
         * @function
         * @private
         */
        _setFilters: function (aFilters) {
        	this._removeAdminSelections();
        	this._getList().getBinding("items").filter(aFilters);
        },
        
        /**
         * Handle admin selection
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onAdminSelect: function(oEvent) {
        	var oList = oEvent.getSource(),
        		oSelectedAdmin = oList.getSelectedItem().getBindingContext(MODEL_DIALOG).getObject();
        		
        	this.setProperty("SelectedAdmin", oSelectedAdmin);
        },
        
        /**
         * Handle search for admins
         * @param {sap.ui.base.Event} oEvent event data
         * @event
         * @public
         */
        onAdminLiveSearch: function(oEvent) {
			var sQuery = oEvent.getSource().getValue(),
				fnGetFilter = function (sPropertyName) {
					return new Filter({
						path: sPropertyName,
                        operator: FilterOperator.Contains,
                        value1: sQuery,
                        caseSensitive: false
					});
				};
			
			if (sQuery) {
				this._setFilters([
					new Filter({
						filters: ["LastName", "Firstname", "Location", "Email"].map(fnGetFilter),
						and: false
					})
				]);
			} else {
				this._setFilters([]);
			}
        },
        
        /**
         * Handle authorization select
         * @param {sap.ui.base.Event} oEvent event data
         * @event
         * @public
         */
        onAuthSelect: function (oEvent) {
        	var oItem = oEvent.getParameter("selectedItem"),
        		oAuth = oItem.getBindingContext().getObject();
        		
        	this.setProperty("SelectedAuth", oAuth);
        },
        
        /**
         * Open outlook with prefilled email
         * @event
         * @public
         */
        onEmailButtonPress: function() {
			var oAdmin = this.getProperty("SelectedAdmin"),
				//oAuth = this.getProperty("SelectedAuth"),
				sEmailAddress = oAdmin.Email;
				
			var sBody = ""; 
			/*this.getText("EMAIL_AUTH_REQUEST_BODY", [
					oAdmin.Firstname,
					oAuth.ObjectDesc, // Name of the authorization
					oAdmin.UserId, // Current User's ID
					[oAdmin.Firstname, oAdmin.Lastname].filter(Boolean).join(" ") // Current User's last name
			]);*/
			// Send email
			sap.m.URLHelper.triggerEmail(sEmailAddress, "" /*this.getText("EMAIL_AUTH_REQUEST_SUBJ")*/, sBody);
			this.close();
        }
    });
	
});
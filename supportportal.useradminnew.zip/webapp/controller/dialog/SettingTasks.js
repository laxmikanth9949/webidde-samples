sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseViewSettingsDialog",
	"sap/support/useradministration/util/Util"
], function(BaseViewSettingsDialog, Util) {
	"use strict";
	
	var Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator;
	
	/**
	 * View settings for Tasks table
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseViewSettingsDialog
	 * @alias sap.support.useradministration.controller.dialog.SettingTasks
	 */
	return BaseViewSettingsDialog.extend("sap.support.useradministration.controller.dialog.SettingTasks", {
		_sDialogName: "SettingTasks",
		_sTableName: "idTasksTable",
		_sPath: "/UserTableColumnSet",
		_aFilters: [new Filter("TableName", FilterOperator.EQ, "idTasksTable")],
		
		/**
		 * Get table to set up
		 * @returns {sap.m.Table} table
		 * @function
		 * @protected
		 * @override
		 */
		_getTable: function () {
			return this._oController.getTasksTable();
		},
        
        /**
         * Temporarily override function to hide TypeOfRequest column
         * Process list came from the backend
         * @param {object} oData  odata response
         * @function
         * @private
         * @override
         */
        _processList: function (oData) {
			var aList = oData.results || [];
			
			aList = aList.map(Util.copy);
			aList.forEach(function (oItem) {
				if (oItem.ColumnText === "MASTER_REQUESTED_ON") {
					oItem.ColumnText = "MASTER_LAST_UPDATE";
				}
			});
			
			aList = aList.map(this._prepareItem.bind(this, this._getTable().getColumns()));
			this.setProperty("Items", aList);
			this._doBackup();
        }
	});
});
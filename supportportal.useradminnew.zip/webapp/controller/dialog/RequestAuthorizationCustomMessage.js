sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialog) {
	"use strict";
	
    var _fnFactory = function() {
    	this.CustomText = "";
    };
    
    /**
     * Dialog for showing custom message about disabled self-auth request
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
     * @alias sap.support.useradministration.controller.dialog.RequestAuthorizationCustomMessage
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.RequestAuthorizationCustomMessage", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "RequestAuthorizationCustomMessage",
        
        beforeOpen: function () {
        	var oReqConfigModel = this._getComponent().getModel("reqconfig");
        	this.setProperty("CustomText", oReqConfigModel.getProperty("/SAR/CustomText") || this.getText("MESSAGE_SAR_DEFAULT_CUSTOM_MESSAGE"));
        }
    });
	
});
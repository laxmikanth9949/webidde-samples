sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SortTasksList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SortTasksList",
        
        _beforeOpen: function() {
        	if (!this._bItemsDeleted) {
        		this._deleteItems();
        	}
        },
        
        /**
         * Delete sorters that should not be visible
         * @function
         * @private
         */
        _deleteItems: function () {
        	var bLifetimeEnabled = this._getSettings().isSUserLifetimeEnabled,
        		oDialog = this.getDialog();
        	
    		oDialog.getSortItems().filter(function (oItem) {
    			switch (oItem.getKey())  {
    				case "TypeOfRequest":
    					return !bLifetimeEnabled;
    				default:
    					return false;
    			}
    		}).forEach(function (oItem) {
    			oDialog.removeSortItem(oItem);
    		});	
    		this._bItemsDeleted = true;
        },
        
        onSubmit: function(oEvent) {
        	var mParams = oEvent.getParameters();
			var oBinding = this._oView.byId("idTasksTable").getBinding("items");
			var aSorters = [];

			var sPath = mParams.sortItem.getKey();
			var bDescending = mParams.sortDescending;
			aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
			oBinding.sort(aSorters);
        }
   
    });
});
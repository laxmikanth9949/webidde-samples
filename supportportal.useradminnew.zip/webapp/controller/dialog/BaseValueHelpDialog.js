sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    
    "sap/m/SearchField",
    "sap/ui/Device",
    "sap/ui/model/Filter"
], function(BaseDialog, SearchField, Device, Filter) {
   "use strict";
   
    /**
     * Returns comparator for case-insensitive search
     * @param {string} sSubstring substring to find
     * @returns {function} comparator
     * @function
     * @private
     */
    var _fnContainsIgnoreCase = function(sSubstring) {
        return function(sValue) {
            if (!sSubstring) {
                return true;
            } else if (!sValue) {
                return false;
            } else {
                return sValue.toLowerCase().indexOf(sSubstring.toLowerCase()) !== -1;
            }
        };
    };
    
    /**
     * Base for value help dialogs
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.BaseValueHelpDialog
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.BaseValueHelpDialog", {
        /**
         * Add basic search field to the filter bar
         * @param {sap.ui.comp.filterbar.FilterBar} oFilterBar filter bar
         * @function
         * @protected
         */
        _addSearchField: function(oFilterBar) {
            if (!oFilterBar.getBasicSearch()) {
                oFilterBar.setBasicSearch(new SearchField({
 					showSearchButton: Device.system.phone, 
 					placeholder: "Search",
 					search: oFilterBar.search.bind(oFilterBar)
 				}));
            }
        },
        
        /**
         * Prepare table when opening dialog
         * @param {sap.ui.table.Table} oTable table
         * @function
         * @protected
         */
        _prepareTable: function(oTable) {
            if (!oTable.getModel("columns")) {
                oTable.setModel(this.createJSONModel({
                    cols: []
                }), "columns");
            }
        },
        
        /**
         * Clear filters
         * @function
         * @public
         */
        clearFilters: function() {
            var oFilterBar = this.getDialog().getFilterBar(),
                oBasicSearch = sap.ui.getCore().byId(oFilterBar.getBasicSearch()),
                aItems = oFilterBar.getFilterGroupItems();
            
            aItems.forEach(function (oItem) {
                oItem.getControl().setValue("");
            });
            if (oBasicSearch) {
                oBasicSearch.setValue("");
            }
            oFilterBar.search();
        },
        
        /**
         * Handle filter bar search
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onSearch: function(oEvent) {
            var oFilterBar = oEvent.getSource(),
                oBasicSearch = sap.ui.getCore().byId(oFilterBar.getBasicSearch()),
                aSelectionSet = oEvent.getParameter("selectionSet") || [],
                bAnd = true;
            
            var aFilters = aSelectionSet.filter(function (oInput) {
                return oInput.getName() && oInput.getValue();
            }).map(function (oInput) {
                return new Filter({
                    path: oInput.getName(), 
                    test: _fnContainsIgnoreCase(oInput.getValue())
                });
            });
            
            if (aFilters.length) {
                oBasicSearch.setValue("");
            } else {
                var sBasicSearch = oBasicSearch.getValue();
                aFilters = aSelectionSet.map(function (oInput) {
                    return new Filter({
                        path: oInput.getName(), 
                        test: _fnContainsIgnoreCase(sBasicSearch)
                    });
                });
                bAnd = false;
            }
            this.getDialog().getTable().getBinding().filter(new Filter({
                filters: aFilters,
                and: bAnd
            }));
        },
        
        
        /**
         * Prepare and open dialog
         * @function
         * @public
         * @override
         */
        open: function() {
            var oDialog = this.getDialog();
            
            this._addSearchField(oDialog.getFilterBar());
            this._prepareTable(oDialog.getTable());
            BaseDialog.prototype.open.apply(this, arguments);
        },
        
        /**
         * Set tokens
         * @param {sap.m.Token[]} aTokens tokens
         * @function
         * @public
         */
        setTokens: function(aTokens) {
            this.getDialog().setTokens(aTokens);
        }
    });
});
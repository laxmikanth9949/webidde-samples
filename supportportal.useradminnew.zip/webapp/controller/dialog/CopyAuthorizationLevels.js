sap.ui.define([
"sap/support/useradministration/controller/dialog/BaseDialogNew",
    "sap/support/useradministration/util/Util",
    "sap/support/useradministration/model/Constant"
], function(BaseDialog, Util, Constant) {
	
	var AUTH_LIST = "AuthList";
	
	var AuthLevel = Constant.AuthLevel;
	
	var Filter = sap.ui.model.Filter,
		FilterOperator = sap.ui.model.FilterOperator,
		MessageBox = sap.m.MessageBox,
		MessageToast = sap.m.MessageToast;
	
	var _fnFactory = function() {
		this.LevelId = "";
	    this.ObjectId = "";
	    this.ObjectDesc = "";
	    this.UserId = ""; 
	    this[AUTH_LIST] = [];
	};
	
	/**
	 * Dialog for copying authorization levels
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
	 * @alias sap.support.useradministration.controller.dialog.CopyAuthorizationLevels
	 */
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.CopyAuthorizationLevels", {
	    _fnDataFactory: _fnFactory,
	    _sDialogName: "CopyAuthorizationLevels",
	    
	    beforeOpen: function() {
	    	this.loadAuthorizationsList();
	    },
	    
	    initAuthorization: function (sLevelId, sObjectId, sObjectDesc) {
	    	this.setProperty("LevelId", sLevelId);
	    	this.setProperty("ObjectId", sObjectId);
	    	this.setProperty("ObjectDesc", sObjectDesc);
	    	return this;
	    },
	    
	    initUser: function (sUserId) {
	    	this.setProperty("UserId", sUserId);
	    	return this;
	    },
	    
	    loadAuthorizationsList: function () {
	    	var aFilters = [
	    		new Filter("AuthLevelId", FilterOperator.EQ, this.getProperty("LevelId"))
	    		];
	    	this.getUserSetODataUtil().readAuthObjectSet.call(this, this.getProperty("UserId"), {
	    		filters: aFilters,
	    		}).then(function (aResults) {
	    			var ObjectId = this.getProperty("ObjectId");
	    			this.setProperty(AUTH_LIST, aResults.filter(function (oItem) {
	    				return ObjectId !== oItem.ObjectId; 
	    			}));
				}.bind(this));
	    },
	    
	    onSearch: function (oEvent) {
	    	var sQuery = oEvent.getParameter("value");
	    	
			var aFilters = [];
			if (sQuery && sQuery.length > 0) {
				aFilters.push(new Filter("ObjectDesc", FilterOperator.Contains, sQuery));
			}
			
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(aFilters);
	    },
	    
	    onConfirm: function (oEvent) {
			var aAuthObjects = oEvent.getParameter("selectedContexts")
	                .map(function (oContext) {
	                	return this._getAuthObjectById(oContext.getObject().ObjectId);
	                }.bind(this)),
	            oController = this._getRequester();
			if (aAuthObjects.length) {
				var oPromise = Util.getPromise();
				MessageBox.show(this.getText("MESSAGE_CONFIRM_COPY_AUTHORIZATION_LEVELS", [this.getProperty("ObjectDesc")]), {
					icon: MessageBox.Icon.WARNING,
					title: this.getText("MESSAGE_COPY_AUTH_2_USERS_APPROVE_TITLE"),
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					onClose: function (oAction) {
                    	if (oAction === sap.m.MessageBox.Action.OK) {
                        	oPromise.resolve();
                    	} else {
                    	 oPromise.reject();
                    	}
					}});
				oPromise.promise().then(function() {
						oController.setBusy(true);
	            		this._copyAuthLevelsLocally(aAuthObjects);
	            	}.bind(this))
	            	.then(oController._updateAuthorizationListChanges.bind(oController))
	            	.always(oController.setBusy.bind(oController, false));
			}
		},

		_copyAuthLevelsLocally: function(aAuthObjects) {
            var oAuth = this._getAuthObjectById(this.getProperty("ObjectId")),
				sUserId = this.getProperty("UserId"),
            	oPromise = Util.getPromise();
    		if (oAuth.TempCurrentAuthLevel === AuthLevel.RESTRICTED) {
    			if (oAuth.Customers) { // Levels already exist
    				aAuthObjects.forEach(this._updateLowLevelAuthLocally.bind(this, oAuth));
    			} else {
					return this._downloadLevels(sUserId, oAuth.ObjectId)
						.then(function (oData) {
							var aLevels = oData && oData.AuthObjectAuthLevelSet.results || [];
							aLevels = aLevels.map(Util.deepCopy);
							oAuth.Customers = aLevels.filter(this.formatter.detail.isCustomerLevel);
							oAuth.Installations = aLevels.filter(this.formatter.detail.isInstallationOrUserLevel);
    						aAuthObjects.forEach(this._updateLowLevelAuthLocally.bind(this, oAuth));
						}.bind(this));
    			}				
    		} else {
    			aAuthObjects.forEach(this._updateTopLevelAuthLocally.bind(this, oAuth.TempSelected));
    		}
    		return oPromise.resolve().promise();
        },
        /**
         * Download authorization levels to copy
         * @param {string} sUserID SUser Id
         * @param {string} sObjectId authorization object ID
         * @returns {object} promise
         * @function
         * @public
         */
		 _downloadLevels: function(sUserID, sObjectId) {
        	var sPath = jQuery.sap.formatMessage("/AuthObjectSet(UserId=''{0}'',ObjectId=''{1}'')", [sUserID, sObjectId]);
        	return Util.read.call(this, sPath, {
				urlParameters: {
					"$expand": "AuthObjectAuthLevelSet",
				  },
			});
        },

	    _updateLowLevelAuthLocally: function(oSource, oDest) {
        	oDest.Customers = oSource.Customers ? oSource.Customers.map(Util.deepCopy) : [];
        	oDest.Installations = oSource.Installations ? oSource.Installations.map(Util.deepCopy) : [];
        	oDest.Customers.forEach(function (oCustomer) {
        		oCustomer.UserId = oDest.UserId;
        		oCustomer.ObjectId = oDest.ObjectId;
        		oCustomer.AuthLevelType = "DEBITOR";
        	});
        	oDest.Installations.forEach(function (oInstallation) {
        		oInstallation.UserId = oDest.UserId;
        		oInstallation.ObjectId = oDest.ObjectId;
        		oInstallation.AuthLevelType = oDest.AuthLevelId;
        	});
        	this._getRequester()._handleAuthorizationObjectSelectChange(oDest, /* bKeepDetails = */ true);
        },
        
        _updateTopLevelAuthLocally: function(bSelected, oAuth) {
        	oAuth.TempSelected = bSelected;
        	this._getRequester()._handleAuthorizationObjectSelectChange(oAuth, /* bKeepDetails = */ false);
        },
		
		_processObjectLevelsAuthorizationsCopy: function (aContexts) {
			var oModel = this.getModel(),
				sPath = "/AuthorizationObjectCopySet",
				sUserId = this.getProperty("UserId");
	
			this._copyTopLevelAuthInfoToTargets(aContexts); //+I521000 UMT-133
			
			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups(["idAuthObjLevelCopyGroup"]);
	
			//Create entry for source objects
			var oEntry = {};
			oEntry.UserId = sUserId; //Source user
			oEntry.ObjectId = this.getProperty("ObjectId");
			oEntry.Value = "X"; //Flag shows that it's a source objects (for backend)
			oModel.create(sPath, oEntry, {
				batchGroupId: "idAuthObjLevelCopyGroup"
			});
	
			//Get table of authorization objects
			aContexts.forEach(function (oItem) {
				oModel.create(sPath, {
					UserId: sUserId,
					ObjectId: oItem.getObject().ObjectId
				}, {
					batchGroupId: "idAuthObjLevelCopyGroup"
				});
			});
	
			oModel.submitChanges({
				batchGroupId: "idAuthObjLevelCopyGroup",
				success: function () {
					MessageToast.show(this.getText("MESSAGE_COPY_AUTH_2_USERS_SUCCESS"));
					oModel.setUseBatch(false);
					oModel.refresh();
				}.bind(this),
				error: function (oError) {
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					MessageToast.show(oErrorBodyObj.error.message.value);
					oModel.setUseBatch(false);
				}
			});
		},
		_getAuthObjectById: function(id){
			var oAuthList = this._oController.getModel("view").getProperty("/UserDetail/Auth/List");
			var oAuthObject = {};
			oAuthList.forEach(function(item){
			   if(item.ObjectId === id){
			      oAuthObject = item;
			    }
			});
			return oAuthObject;
		},
		
		_copyTopLevelAuthInfoToTargets: function(aContexts){
			var oSourceAuthObject = this._getAuthObjectById(this.getProperty("ObjectId")),
		    oTargetAuthObject = {};
		    
			aContexts.forEach(function (oItem) {
				oTargetAuthObject = this._getAuthObjectById(oItem.getObject().ObjectId);
				oTargetAuthObject.TempCurrentAuthLevel = oSourceAuthObject.TempCurrentAuthLevel;
				oTargetAuthObject.TempSelected = oSourceAuthObject.TempSelected;
			}.bind(this));
	    
		}
	});
	});
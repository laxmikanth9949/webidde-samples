sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SettingImportantContactsList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SettingImportantContactsList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SettingImportantContactsList",
        
        onSubmit: function(oEvent) {
        	this._getRequester()._tableSettingsChange(oEvent, "idUserSettingsTableGroup4", "idImportantContactsTable");
        },
        
        onCancel: function() {
        	this.close();
        }
   
    });
});
sap.ui.define([
    "sap/ui/base/Object",
    "sap/m/MessageBox",
    
    "sap/base/Log",
	"sap/support/useradministration/model/Formatter",
	"sap/support/useradministration/util/Settings",
    "sap/support/useradministration/util/Util"
], function (BaseObject, MessageBox, Log, Formatter, Settings, Util) {
	"use strict";
	
    var _fnFactory = function() {};
    var _fnDeferred = jQuery.Deferred;
    
    var JSONModel = sap.ui.model.json.JSONModel;
    
    /**
     * Base dialog controller
     * @param {sap.ui.core.mvc.Controller} oParentController parent controller
     * @param {sap.support.useradministration.model.DialogModelController} oDialogModelController dialog model controller
     * @constructor
     * @class
     * @extends sap.ui.base.Object
     * @alias sap.support.useradministration.controller.dialog.BaseDialog
     */
    return BaseObject.extend("sap.support.useradministration.controller.dialog.BaseDialog", {
        formatter: Formatter,
        log: Log,
        
        _bSyncStyleClass: false,
        _fnDataFactory: _fnFactory,
        _oController: null,
        _oDialog: null,
        _oDialogModel: null,
        _oDialogModelController: null,
        _oParentDialog: null,
        _oView: null,
        _sDialogName: null,
        
        constructor: function(oParentController, oDialogModelController) {
            this._oController = oParentController;
            this._oView = oParentController.getView();
            this._oDialogModelController = oDialogModelController;
            this._oDialogModel = oDialogModelController.getModel();
        },
        
        /**
         * Do some stuff after opening a dialog
         * @function
         * @protected
         */
        _afterOpen: function() {
        	// To be overriden	
        },
        
        /**
         * Do some stuff before opening a dialog
         * @function
         * @protected
         */
        _beforeOpen: function() {
        	// To be overriden	
        },
        
        /**
         * Get new promise object
         * @returns {object} jQuery deferred promise object
         * @function
         * @private
         */
        _getPromise: function() {
            return _fnDeferred();
        },
        
        /**
         * Get component
         * @returns {sap.ui.core.UIComponent} component
         * @function
         * @private
         */
        _getComponent: function () {
        	return this._oController.getOwnerComponent();
        },
        
        /**
         * Get dialog fragment for current controller
         * @returns {sap.m.Dialog} dialog
         * @function
         * @private
         */
        _getDialogFragment: function () {
        	return sap.ui.xmlfragment("sap.support.useradministration.view.dialog." + this._sDialogName, this);
        },
        
        /**
         * Get corresponding property from dialog model
         * @param {string} sPropertyName property name
         * @returns {any} value
         * @function
         * @private
         */
        _getDialogProperty: function(sPropertyName) {
            return this._oDialogModel.getProperty(this._getPropertyPath(sPropertyName));
        },
        
        /**
         * Construct property path in the dialog model
         * @param {string} sPropertyName property name
         * @returns {string} full property path
         * @function
         * @private
         */
        _getPropertyPath: function(sPropertyName) {
            var sName = sPropertyName || "",
                sSlash = sName[0] === "/" ? "" : "/";
            return "/" + this._sDialogName + sSlash + sName;
        },
        
        /**
         * Return requester of the current dialog
         * @returns {sap.ui.core.mvc.Controller|sap.support.useradministration.controller.dialog.BaseDialog} requester
         * @function
         * @protected
         */
        _getRequester: function() {
            return this._oParentDialog || this._oController;  
        },
        
        /**
         * Get i18n resource bundle
         * @returns {sap.ui.core.util.ResourceBundle} bundle
         * @function
         * @private
         */
        _getResourceBundle: function() {
            return Util.getBundle.call(this._oController);
        },
        
        /**
         * Get settings
         * @returns {sap.support.useradministration.util.Settings} settings
         * @function
         * @private
         */
        _getSettings: function () {
        	return Settings;
        },
        
        /**
         * Set corresponding property value in dialog model
         * @param {string} sPropertyName property name
         * @param {any} vValue value
         * @returns {sap.support.useradministration.controller.dialog.BaseDialog} this for chaining
         * @function
         * @private
         */
        _setDialogProperty: function(sPropertyName, vValue) {
            this._oDialogModel.setProperty(this._getPropertyPath(sPropertyName), vValue);
            return this;
        },
        
        /**
         * Reset corresponding data in the model
         * @function
         * @private
         */
        _resetModel: function() {
            this._oDialogModelController.resetProperty(this._sDialogName);
        },
        
        /**
         * Close dialog
         * @function
         * @public
         */
        close: function() {
            this.getDialog().close();
            this._oParentDialog = null;
        },
        
		/**
		 * Create JSON model with extended size limit then add it to view if necessary
		 * @param {object} oData initial data
		 * @param {string} [sName] if provided, model will be set to view using given name
		 * @returns {sap.ui.model.json.JSONModel} created model
		 * @function
		 * @public
		 */
		createJSONModel: function (oData, sName) {
			var oModel = new JSONModel(oData || {});
			oModel.setSizeLimit(10000);
			if (sName) {
				this.setModel(oModel, sName);
			}
			return oModel;
		},
        
        /**
         * Destroy dialog
         * @function
         * @public
         */
        destroy: function() {
            if (this._oDialog) {
                this._oDialog.unbindElement("dialog");
                this._oDialog.destroy();
                this._oDialog = null;
            }
        },
        
        /**
         * Get dialog
         * @returns {sap.m.Dialog} dialog
         * @function
         * @public
         */
        getDialog: function() {
            if (!this._oDialog) {
                if (this._sDialogName) {
                    this._oDialog = this._getDialogFragment();
                    this._oView.addDependent(this._oDialog);
                    if (this._bSyncStyleClass) {
                        jQuery.sap.syncStyleClass("sapUiSizeCompact", this._oView, this._oDialog);
                    }
                } else {
                    jQuery.sap.log.error("Empty dialog name");
                }
            }
            return this._oDialog;
        },
        
        /**
         * Get data factory for dialog model
         * @returns {function} factory
         * @function
         * @public
         */
        getDataFactory: function() {
            return this._fnDataFactory;
        },
        
        /**
         * Get model with given name
         * @param {string} sName name
         * @returns {sap.ui.model.Model} model
         * @function
         * @public
         */
        getModel: function(sName) {
        	return this._oView.getModel(sName);
        },
        
        /**
         * Get dialog name
         * @returns {string} name
         * @function
         * @public
         */
        getName: function() {
            return this._sDialogName;
        },
        
        /**
         * Get corresponding property from dialog model
         * @param {string} sPropertyName property name
         * @returns {any} value
         * @function
         * @public
         */
        getProperty: function(sPropertyName) {
            return this._getDialogProperty(sPropertyName);
        },
        
        /**
         * Get text from i18n bundle
         * @param {string} sKey i18n key
         * @param {any[]} aArgs i18n arguments
         * @returns {string} text
         * @function
         * @public
         */
        getText: function(sKey, aArgs) {
            return this._getResourceBundle().getText(sKey, aArgs);
        },
        
        /**
         * Open dialog
         * @param {sap.m.Dialog} oParentDialog parent dialog
         * @function
         * @public
         */
        open: function(oParentDialog) {
            var oDialog = this.getDialog();
            oDialog.bindElement({
                path: this._getPropertyPath(""),
                model: "dialog"
            });
            this._oParentDialog = oParentDialog || null;
            this._beforeOpen();
            oDialog.open();
            this._afterOpen();
        },
        
        /**
         * Show confirmation box handled by promise
         * @param {string} sMessage confirmation box
         * @param {object} oOptions confirmation box options
         * @returns {object} promise that will be resolved on OK
         * @function
         * @public
         */
        showConfirmationBox: function(sMessage, oOptions) {
            var oPromise = this._getPromise();
            MessageBox.show(sMessage, jQuery.extend({
                icon: MessageBox.Icon.WARNING,
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                onClose: function(oAction) {
                    if (oAction === MessageBox.Action.OK) {
                        oPromise.resolve();
                    } else {
                        oPromise.reject();
                    }
                }
            }, oOptions));
            return oPromise.promise();
        },
        
        /**
         * Set dialog busy state
         * @param {boolean} bBusyState busy state
         * @function
         * @public
         */
        setBusy: function(bBusyState) {
            this.getDialog().setBusy(bBusyState);
        },

		/**
		 * Set model
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.support.useradmininstration.controller.dialog.BaseDialog} instance itself for chaining
		 * @function
		 * @public
		 */
		setModel: function(oModel, sName) {
			this.getDialog().setModel(oModel, sName);
			return this;
		},
        
        /**
         * Set corresponding property value in dialog model
         * @param {string} sPropertyName property name
         * @param {any} vValue value
         * @returns {sap.support.useradmininstration.controller.dialog.BaseDialog} this for chaining
         * @function
         * @public
         */
        setProperty: function(sPropertyName, vValue) {
            this._setDialogProperty(sPropertyName, vValue);
            return this;
        },
        
        /**
         * Sync style class
         * @returns {sap.support.useradmininstration.controller.dialog.BaseDialog} this for chaining
         * @function
         * @public
         */
        syncStyleClass: function() {
		    jQuery.sap.syncStyleClass("sapUiSizeCompact", this._oView, this.getDialog());
            return this;
        }
    });
});
sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.APSelect", {
		_sDialogName: "APSelect",
		_handleAPValueHelpSearch: function (oEvent) {
			var aFilters = [];
			var sQuery = oEvent.getParameter("value").toLowerCase();
			var filter = new sap.ui.model.Filter("Text", sap.ui.model.FilterOperator.Contains, sQuery);
			aFilters.push(filter);

			// update table binding
			sap.ui.getCore().byId("idAPListDialog").getBinding("items").filter(aFilters);
		},
		
		_handleAPValueHelpSave: function (oEvent) {
			var oView = this._oView;
			var oBundle = oView.getModel("i18n");
			var oAPItems = oEvent.getSource().getItems();

			// get selected APs
			var selAPItems = [];
			for (var i = 0; i < oAPItems.length; i++) {
				if (oAPItems[i].getSelected()) {
					selAPItems.push(oAPItems[i]);
				}
			}

			jQuery.sap.require("sap.m.MessageBox");
			var continueText = this.getText("CONTINUE");
			sap.m.MessageBox.show(oBundle.getProperty("MESSAGE_AP_ASSIGN_2_USER_INFO"), {
				icon: sap.m.MessageBox.Icon.WARNING,
				title: oBundle.getProperty("MESSAGE_COPY_AUTH_2_USERS_APPROVE_TITLE"),
				actions: [continueText, sap.m.MessageBox.Action.CANCEL],
				emphasizedAction: continueText,
				onClose: function (oAction) {
					// Check selected action
					if (oAction === continueText) {
						this._assignAP2User(selAPItems);
					}
					this.destroy();
				}.bind(this)
			});
		},
		
		_assignAP2User: function (selAPItems) {
			var oView = this._oView;
			var oAPModel = oView.getModel("ap");

			// get selected users
			// var oUserTable = oView.byId(ALL_USER_TABLE_ID);
			var oUserTable = this._oController._getUserTable();
			var selUserItems = oUserTable.getSelectedItems();

			oAPModel.setUseBatch(true);
			oAPModel.setDeferredBatchGroups(["idAPAssignGroup"]);

			var sData = oAPModel.getData("/aut_pack_set_for_userSet");
			var sData4batch = [];
			var sPath;
			var iRecCount = 0;

			for (var i = 0; i < selUserItems.length; i++) {
				//create an array of batch changes and save 
				selUserItems[i].setType("Inactive");
				for (var y = 0; y < selAPItems.length; y++) {
					sData4batch[iRecCount] = jQuery.extend(true, {}, sData);
					sData4batch[iRecCount].SUser = selUserItems[i].getBindingContext().getProperty("Susid");
					sData4batch[iRecCount].AuthPackId = selAPItems[y].getBindingContext("ap").getProperty("AuthPackId");

					//redefine the path for each selected user
					sPath = "/auth_pack_set_for_userSet(SUser='" + sData4batch[iRecCount].SUser + "',AuthPackId='" + sData4batch[iRecCount].AuthPackId +
						"')";
					oAPModel.update(sPath, sData4batch[iRecCount], {
						batchGroupId: "idAPAssignGroup"
					});

					iRecCount++;
				}
			}

			oAPModel.submitChanges({
				batchGroupId: "idAPAssignGroup",
				success: function () {
                    sap.m.MessageBox.success(this.getText("REQUEST_SUBMITTED_TEXT"), {
                        title: this.getText("REQUEST_SUBMITTED_TITLE"),
                        emphasizedAction: null,  
                    });
					oAPModel.setUseBatch(false);
					this._invalidateTabs(["AuthPackages"]);
					this._getUserTable().removeSelections();
					this._setViewProperty("IsAnyUserSelected", false);
					for (var i = 0; i < selUserItems.length; i++) {
						selUserItems[i].setType("Navigation");
					}
				}.bind(this._oController),
				error: function (oError) {
					var oErrorBody = oError.responseText;
					var oErrorBodyObj = JSON.parse(oErrorBody);
					sap.m.MessageToast.show(oErrorBodyObj.error.message.value);
					oAPModel.setUseBatch(false);
				}
			});
		}
	});
});
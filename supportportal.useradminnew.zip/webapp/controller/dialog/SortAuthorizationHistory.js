sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
     * @alias sap.support.useradministration.controller.dialog.SortAuthorizationHistory
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SortAuthorizationHistory", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SortAuthorizationHistory",
        
        onSubmit: function(oEvent) {
        	var mParams = oEvent.getParameters(),
				oBinding = this.getRequester().getTable().getBinding("items"),
				aPath = mParams.sortItem.getKey().split(","),
				bDescending = mParams.sortDescending;
			oBinding.sort(aPath.map(function(sPath) {
				return new sap.ui.model.Sorter(sPath, bDescending);
			}));
        }
   
    });
});
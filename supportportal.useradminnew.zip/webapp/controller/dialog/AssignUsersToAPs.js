sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseValueHelpDialog",
    "sap/support/useradministration/model/Constant",
    "sap/support/useradministration/util/Util",
    
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/odata/OperationMode"
], function(BaseValueHelpDialog, Constant, Util, Filter, FilterOperator, JSONModel, OperationMode) {
    /**
     * Factory for dialog model
     * @function
     * @private
     */
    var _fnFactory = function() {
        this.Search = "";
        this.AuthPackIds = [];
    };

    /**
     * Returns comparator for case-insensitive search
     * @param {string} sSubstring substring to find
     * @returns {function} comparator
     * @function
     * @private
     */
    var _fnContainsIgnoreCase = function(sSubstring) {
        return function(sValue) {
            if (!sSubstring) {
                return true;
            } else if (!sValue) {
                return false;
            } else {
                return sValue.toLowerCase().indexOf(sSubstring.toLowerCase()) !== -1;
            }
        };
    };


    
    /**
     * Dialog for assigning users to authorization packages
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseValueHelpDialog
     * @alias sap.support.useradministration.controller.dialog.AssignUsersToAPs
     */
    return BaseValueHelpDialog.extend("sap.support.useradministration.controller.dialog.AssignUsersToAPs", {
        _fnDataFactory: _fnFactory,
        _sDialogName: Constant.Dialog.ASSIGN_USERS_TO_APS,
        
        /**
         * Send backend request to assign selected users to APs
         * @param {string[]} aUserIds user IDs
         * @function
         * @private
         */
        _assignUsers: function(aUserIds) {
            var BATCH_GROUP_ID = "idAssignAPUsers";
            var that = this,
                oPromise = this._getPromise(),
                aAPIds = this._getDialogProperty("AuthPackIds") || [],
                oModel = this._oView.getModel("ap"),
                oModelParameters = {
                    batchGroupId: BATCH_GROUP_ID
                };
            
            this.setBusy(true);
            oModel.setUseBatch(true);
            oModel.setDeferredGroups([BATCH_GROUP_ID]);
            
            aAPIds.forEach(function (sAPId) {
                aUserIds.forEach(function (sUserId) {
                    var sPath = Util.formatMessage("/auth_pack_set_for_userSet(AuthPackId=''{0}'',SUser=''{1}'')", [sAPId, sUserId]);
                    oModel.update(sPath, {
                        SUser: sUserId,
                        AuthPackId: sAPId
                    }, oModelParameters);
                });
            });
            
            oModel.submitChanges({
				batchGroupId: BATCH_GROUP_ID, 
				success: oPromise.resolve, 
				error: oPromise.reject
			});
			
			oPromise.then(function() {
                sap.m.MessageBox.success(that.getText("REQUEST_SUBMITTED_TEXT"), {
                    title: that.getText("REQUEST_SUBMITTED_TITLE"),
                    emphasizedAction: null,  
                });
                oModel.refresh();
            }).fail(Util.JSONError.showToast)
    			.always(function() {
    			    oModel.setUseBatch(false);
    			    that.setBusy(false);
    			    that.close();
    			});
        },
        
        /**
         * Prepare table when opening dialog
         * @param {sap.ui.table.Table} oTable table
         * @function
         * @private
         * @override
         */
        _prepareTable: function(oTable) {
            if (!oTable.getModel("columns")) {
                oTable.setModel(this.createJSONModel({
                    cols: [
                        {label: this.getText("MASTER_COLUMN_USER_ID"), template: "Susid"},
                        {label: this.getText("DETAIL_USER_LAST_NAME"), template: "Name1"},
                        {label: this.getText("DETAIL_USER_FIRST_NAME"), template: "Namev"},
                        {label: this.getText("MASTER_COLUMN_USER_CUST_NUM"), template: "CustNum"}
                    ]
                }), "columns");
            }
            
            oTable.bindRows({
                path: "/UserF4HelpSet",
                parameters: {
                    operationMode: OperationMode.Client
                }
            });
        },

        /**
         * Add basic search field to the filter bar, with a specific id for multi value search
         * @param {sap.ui.comp.filterbar.FilterBar} oFilterBar filter bar
         * @function
         * @protected
         */
        _addSearchField: function(oFilterBar) {
            if (!oFilterBar.getBasicSearch()) {
                oFilterBar.setBasicSearch(new sap.m.SearchField({
                        id: "filterBar4AssignUsersToAPs",
                        showSearchButton: sap.ui.Device.system.phone, 
                        placeholder: "Search",
                        search: oFilterBar.search.bind(oFilterBar)
                    }));
            }

        },

        /**
         * Handle filter bar search
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onSearch: function(oEvent) {

            // if the triggering event came from pressing the GO button
            var sQuery = sap.ui.getCore().byId("filterBar4AssignUsersToAPs").getValue();
            if (sQuery.indexOf(";") !== -1 || sQuery.indexOf(",") !== -1) {
                // THIS might be a problem long term
                // if there is a , or ; in the Query, enable only Susid search
                this.handleSearchBasicSearchMultiValue(oEvent, sQuery);
            } else {
                // use base functionality
                BaseValueHelpDialog.prototype.onSearch.call(this, oEvent);
            }
        },


        /**
         * Handle filter input search
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        handleSearchBasicSearchMultiValue: function(oEvent, sQuery) {
            var oTable = this.getDialog().getTable(),
			    aFilters = [],
			    sSplitSymbol,
                bAnd = true;
            // if there is a , or ; in the Query, enable only Susid search
            aFilters = sQuery.split(" ").join("").split(/,|;/).filter(function (sUser) {
                return sUser !== "";
            }).map(function (sUser) {
                return new sap.ui.model.Filter(
                    {path: "Susid", 
                    test: function(sValue) {
                        return sValue.toLowerCase().indexOf(sUser.toLowerCase()) !== -1;
                    },
                    value: sUser}
                    );
            });
            bAnd = false;

            oTable.getBinding().filter(
                new sap.ui.model.Filter(
                    {
                    filters: aFilters,
                    and: bAnd
                    }
                )
            );
        },


        /**
         * Handle all filter Enter pressed/submit
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        submitInput: function(oEvent) {
            // works if the submit comes from one of the four inputs 
            var oFilterBar  = oEvent.getSource().getParent().getParent().getParent();
            // trigger the normal search, in order to use all filter+basicSearch
            oFilterBar.search();
        },


        /**
         * Handle dialog confirmation
         * Ask user to confirm changes
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onConfirmDialog: function(oEvent) {
            var aUserIds = oEvent.getParameter("tokens").map(function (oToken) {
                return oToken.getKey(); 
            });
            
            if (aUserIds.length) {
                var continueText = this.getText("CONTINUE");
                this.showConfirmationBox(this.getText("MESSAGE_USER_ASSIGN_2_AP_INFO"), {
                    title: this.getText("MESSAGE_COPY_AUTH_2_USERS_APPROVE_TITLE"),
                    actions: [continueText, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: continueText,
                    onClose: function (oAction) {
                    	if (oAction === continueText) {
                            this._assignUsers(aUserIds);
                    	}
					}.bind(this)
                });
            } else {
                this.close();
            }
        },

        /**
         * Set Auth Pack ids
         * @param {string[]} aAuthPackIds id list
         * @function
         * @public
         */
        setAuthPackIds: function(aAuthPackIds) {
            this._setDialogProperty("AuthPackIds", aAuthPackIds);
        }
    });
});
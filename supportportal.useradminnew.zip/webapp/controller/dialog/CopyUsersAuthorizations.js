sap.ui.define([
//    "sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/controller/dialog/SmartValueHelpDialog",
    "sap/support/useradministration/util/Util",
	"sap/support/useradministration/util/odata/ODataUtil"
], function(SmartValueHelpDialog, Util, ODataUtil) {
	"use strict";
	
	var FilterOperator = sap.ui.model.FilterOperator;
	
    var _fnFactory = function() {
    	this.UserId = null;
    	this.UserData = null;
    };
    
    var UserSet = Util.Constant.UserSet,
    Filter = sap.ui.model.Filter;
    
    /**
     * Dialog for copying user's authorizations to another users in User Detail
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
     * @alias sap.support.useradministration.controller.dialog.CopyUsersAuthorizations
     */
    return SmartValueHelpDialog.extend("sap.support.useradministration.controller.dialog.CopyUsersAuthorizations", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "CopyUsersAuthorizations",
        _bUserNewSetEnabled: false,
        _sPath: "/User4CopyAuthSet",
        _aFilters: [],
        
        _beforeOpen: function () {
			this.getDialog().getTable().setVisibleRowCount(8);
        },
		
		_getODataUtil: function (sSetName) {
			return sSetName ? ODataUtil[sSetName] : ODataUtil;
		},
		/**
		 * Send requests to copy user's authorizations
		 * @param {sap.ui.model.ContextBinding[]} aContexts binding contexts
		 * @param {string} sUserId user ID
		 * @function
		 * @private
		 */
		_copyUsersAuthorizations: function (aContexts, sUserId) {
			var oModel = this.getModel(),
				oUserSetODataUtil = this._getODataUtil("UserSet"),
				sBatchGroupId = "idUserAuthObjCopyGroup",
				oRequestParams = {
					groupId: sBatchGroupId
				};
			
			if (!aContexts || !aContexts.length) {
				return;
			}
			
			oModel.setUseBatch(true);
			oModel.setDeferredGroups([sBatchGroupId]);
			
			aContexts.forEach(function (oContext) {
				var sPath = Util.formatMessage("/AuthorizationObjectCopySet(''{0}'')", [sUserId]),
					oEntry = {
						Value: sUserId,
						UserId: oContext.getKey()
					};
				
				oModel.update(sPath, oEntry, oRequestParams);
			});
			
			Util.promiseSubmitChanges(oRequestParams, oModel)
				.then(function () {
					Util.showToast(this.getText("MESSAGE_COPY_AUTH_2_USERS_SUCCESS"));
				}.bind(this))
				.finally(function () {
					oModel.setUseBatch(false);	
				});
		},
        
		/**
		 * Get current dialog name according to UserNewSet enabled state
		 * @returns {string} name
		 * @function
		 * @private
		 * @override
		 */
        _getDialogName: function () {
        	this._bUserNewSetEnabled = this.getUserSetODataUtil().isUserNewSetEnabled();
        	return this._bUserNewSetEnabled ? "CopyUsersAuthorizations4UserNewSet" : "CopyUsersAuthorizations";
        },
        
		/**
		 * Handle confirmation of selection
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onConfirm: function (oEvent) {
			var aContexts = oEvent.getParameter("tokens");

			if (aContexts.length) {
				var oUserData = this.getProperty("UserData"),
					sUserId = this.getProperty("UserId"),
					sUserFullName = Util.formatMessage(" {0} {1} ({2})", [oUserData.FirstName, oUserData.LastName, sUserId]),
					sMessage = this.getText("MESSAGE_COPY_AUTH_2_USERS_APPROVE_MSG_FULL", [sUserFullName]);
					
				// Util.showConfirmationPromiseBox(sMessage, this.getText("MESSAGE_COPY_AUTH_2_USERS_APPROVE_TITLE"))
				// 	.then(this._copyUsersAuthorizations.bind(this, aContexts, sUserId));
				
				// new logic of coping auth 
				var oContinueDialog = this._oController._oDialogs.getDialog("CopyUsersAuthorizationsOptions");
				oContinueDialog.setUserFullName(sUserFullName);
				oContinueDialog.setUserId(sUserId);
				oContinueDialog.setContexts(aContexts);
				oContinueDialog.syncStyleClass().open();
			}
		},

		/**
		 * Handle users search
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onUsersSearch: function (oEvent) {
			var sQuery = oEvent.getParameter("value");
//				fnGetFilter = this.getUserSetODataUtil().getBackendFilter;  //-I521000

			// update table binding
			var oBinding = oEvent.getSource().getBinding("items"),
				aFilters = [];
				
			if (sQuery && sQuery.length > 0) {
				//I521000 Search filter re-deign
				/*aFilters = [
					fnGetFilter("UserId", FilterOperator.Contains, sQuery),
					fnGetFilter("FirstName", FilterOperator.Contains, sQuery),
					fnGetFilter("LastName", FilterOperator.Contains, sQuery),
					fnGetFilter("CustomerId", FilterOperator.Contains, sQuery),
					fnGetFilter("CustomerName", FilterOperator.Contains, sQuery),
					fnGetFilter("Email", FilterOperator.Contains, sQuery),
					fnGetFilter("CountryName", FilterOperator.Contains, sQuery),
					fnGetFilter("DepartmentName", FilterOperator.Contains, sQuery),
					fnGetFilter("FlagDialogSearch", FilterOperator.EQ, "X"),
					//KNGMHM02-18693 adding department id, backend applies blank filter for this field and when not passed filtering breaks
					fnGetFilter("DepartmentId", FilterOperator.Contains, sQuery)
				];*/
				
				//I521000- Send only search term, backend will search in all fields
  				aFilters.push(new Filter(UserSet.SEARCH_FIELD, FilterOperator.Contains, sQuery ));

			}
			
			oBinding.filter(aFilters);
		},
		
        /**
         * Set User data
         * @param {string} sUserId user ID
         * @param {object} oUserData user data
         * @returns {sap.support.useradministration.controller.dialog.CopyUsersAuthorizations} this for chaining
         * @function
         * @public
         */
        setUserData: function (sUserId, oUserData) {
        	return this.setProperty("UserId", sUserId)
        		.setProperty("UserData", oUserData);
        }
    });
	
});
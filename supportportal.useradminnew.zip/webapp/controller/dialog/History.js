sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/extended/SmartTable"
], function(BaseDialog, Util, SmartTable) {
	
    var _fnFactory = function() {
    	this.User = "";
    	this.Count = 0;
    };
    
    var oSearchRequest = null;
    var bSizeFixed = false;
    
    /**
     * Dialog for showing user's authorization history
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
     * @alias sap.support.useradministration.controller.dialog.AuthorizationHistory
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.History", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "History",
        
        beforeOpen: function () {
        	if (!this._getSettings().isAuthorizationAssignmentHistoryEnabled) {
		 		return;
		 	}
			this.requestAuthHistory();
		 	this.requestExtensionHistory();
		 	Promise.all([this.requestHistoryCount(), this.requestExtensionHistoryCount()]).then(this.adjustSize.bind(this));
        },
        
        beforeClose: function () {
        	if (this._oAuthTable) {
        		this._oAuthTable.getInfoToolbar().setVisible(false);
        	}
        	if (this._oExtensionTable) {
        		this._oExtensionTable.getInfoToolbar().setVisible(false);
        	}
        	this._oController._oDialogs.getDialog("SortAuthorizationHistory").destroy();
        	this._oController._oDialogs.getDialog("FilterAuthorizationHistory").destroy();
        	this._oController._oDialogs.getDialog("SortExpDateHistory").destroy();
        	this._oController._oDialogs.getDialog("FilterExpDateHistory").destroy();
        	
        	bSizeFixed = false;
        },
        
        setUser: function (sUser) {
			return this.setProperty("User", sUser);
		},
		
		getUser: function() {
			return this.getProperty("User");
		},
		
		setTable: function (oEvent) {
			this._oTable = Util.closest(oEvent.getSource(), SmartTable);
		},
		
		getTable: function () {
			return this._oTable;
		},
		
		adjustSize: function() {
			var count =  Math.max(this.getProperty("AuthCount"), this.getProperty("ExpiryDateCount"));
			if (!bSizeFixed) {
				if (count === "0") {
        			this.getDialog().setContentHeight("12rem");
				} else { 
					this.getDialog().setContentHeight(count * 2 + 15.5 + "rem");
					}
				bSizeFixed = true;
        	}
		},
		
		requestHistoryCount: function (aSearchFilters) {
			var aFilters = [new sap.ui.model.Filter("Ubname", sap.ui.model.FilterOperator.EQ, this.getProperty("User"))];
			if (aSearchFilters && aSearchFilters.length) {
				aFilters = aFilters.concat(aSearchFilters);
			}
			var oPromise = Util.promiseRead.call(this, "/AuthAssignmentHistorySet/$count", {
				filters: aFilters
			}).then(function (count) {
        			this.setProperty("AuthCount", count);
        		}.bind(this))
        		.catch(function () {
        			this.setProperty("AuthCount", 0);
        			if (!bSizeFixed) {
						this.getDialog().setContentHeight("12rem");
						bSizeFixed = true;
        			}
        		}.bind(this, {}));
        	return oPromise;
		},
 
		requestAuthHistory: function () {
		 	var oTable = sap.ui.getCore().byId("idAuthAssignHistoryTable"),
		 		oBindingInfo = oTable && oTable.getBindingInfo("items");
		 		
		 	oTable.bindItems({
		 		path: "/AuthAssignmentHistorySet",
		 		filters: [
		 			new sap.ui.model.Filter("Ubname", sap.ui.model.FilterOperator.EQ, this.getProperty("User"))
		 		],
		 		sorter: [
		 			new sap.ui.model.Sorter("Logdate", true),
		 			new sap.ui.model.Sorter("Logtime", true)
		 		],
		 		template: oBindingInfo.template
		 	});
		 	oTable.getBinding("items").refresh(true);
		},
		
		onAuthSearch: function (oEvent) {
			// add filter for search
			var aFilters = [],
				aSearchFilters = [];

			var sSearchQuery = oEvent.getSource().getValue();
			
			if (oSearchRequest) {
				clearTimeout(oSearchRequest);
			}
			oSearchRequest = setTimeout(function (sQuery) {
				if (sQuery && sQuery.length > 2) {
					aSearchFilters = ["Otext", "PgroupText", "ProfnaText", "Profna", "Loguser", "Namev", "Name1", "AuthPackText"
						].map(function (column) {
							return new sap.ui.model.Filter(column, sap.ui.model.FilterOperator.Contains, sQuery);
						});
					aSearchFilters.push(
						new sap.ui.model.Filter("Search", sap.ui.model.FilterOperator.EQ, true)
					);
					aFilters = [new sap.ui.model.Filter({
						filters: aSearchFilters,
						and: true
					})];
				}
				
				// update table binding
				sap.ui.getCore().byId("idAuthAssignHistoryTable").getBinding("items").filter(aFilters);
				
				this.requestHistoryCount(aSearchFilters);
			}.bind(this, sSearchQuery), 500);
		},
		
		pressAuthDownload: function (oEvent) {
			var oTable = Util.closest(oEvent.getSource(), SmartTable);
		 	
		 	Util.showToast(this.getText("MESSAGE_DOWNLOADING_DATA"));
		 	
			if (oTable) {
				oTable.saveToFile(null, true);
			}
		},
		
		pressAuthSort: function (oEvent) {
			this.setTable(oEvent);
			this._oController._oDialogs.getDialog("SortAuthorizationHistory")
				.open(this);
		},
		
		pressAuthFilter: function (oEvent) {
			this.setTable(oEvent);
			this._oAuthTable = Util.closest(oEvent.getSource(), SmartTable);
			this._oController._oDialogs.getDialog("FilterAuthorizationHistory")
				.open(this);
		},
		
		requestExtensionHistoryCount: function(aSearchFilters) {
			var oPromise = Util.promiseRead.call(this, "/UserSet('" + this.getUser() + "')/UserExpirationDateHistory/$count", {
				filters: aSearchFilters
			}).then(function (count) {
        			this.setProperty("ExpiryDateCount", count);
        		}.bind(this))
        		.catch(function () {
        			this.setProperty("ExpiryDateCount", 0);
        		}.bind(this, {}));
        	return oPromise;
		},
		
		requestExtensionHistory: function(aFilters) {
			this.getModel().read("/UserSet('" + this.getUser() + "')/UserExpirationDateHistory", {
				filters: aFilters,
				success: function (oData) {
					var aHistory = oData.results || []; 
					this.setProperty("ExpDateHistory", aHistory);
					if (!aFilters || !aFilters.length) {
						this.setProperty("FullExpDateHistory", aHistory);
					}
				}.bind(this),
				error: function () {
					this.setProperty("ExpDateHistory", []);
				}.bind(this)
			});
		},
		
		pressDownloadExpDateHistory: function (oEvent) {
			var oTable = Util.closest(oEvent.getSource(), SmartTable);
		 	
		 	Util.showToast(this.getText("MESSAGE_DOWNLOADING_DATA"));
		 	
			if (oTable) {
				oTable.saveToFile(null, true);
			}
		},
		
		pressSortExpDateHistory: function (oEvent) {
			this.setTable(oEvent);
			this._oController._oDialogs.getDialog("SortExpDateHistory")
				.syncStyleClass()
				.open(this);
		},
		
		pressFilterExpDateHistory: function (oEvent) {
			this.setTable(oEvent);
			this._oExtensionTable = Util.closest(oEvent.getSource(), SmartTable);
			this._oController._oDialogs.getDialog("FilterExpDateHistory")
				.syncStyleClass()
				.open(this);
		},
		
		onSearchExpDateHistory: function(oEvent) {
			var aFilters = [],
				aSearchFilters = [];

			var sSearchQuery = oEvent.getSource().getValue();
			
			if (oSearchRequest) {
				clearTimeout(oSearchRequest);
			}
			oSearchRequest = setTimeout(function (sQuery) {
				if (sQuery && sQuery.length > 2) {
					aSearchFilters = ["ProcessorName", "ProcessorId"
						].map(function (column) {
							return new sap.ui.model.Filter(column, sap.ui.model.FilterOperator.Contains, sQuery);
						});
					aFilters = [new sap.ui.model.Filter({
						filters: aSearchFilters
					})];
				}

				sap.ui.getCore().byId("idExpDateHistoryTable").getBinding("items").filter(aFilters);
				
			}.bind(this, sSearchQuery), 500);
		}
    });
});
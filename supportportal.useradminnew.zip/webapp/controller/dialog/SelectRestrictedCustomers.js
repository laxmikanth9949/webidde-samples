sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseValueHelpDialog",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",

	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseValueHelpDialog, Constant, Util, Token, Filter, FilterOperator) {
	"use strict";

	/**
	 * Factory for dialog model
	 * @function
	 * @private
	 */
	var _fnFactory = function() {
		this.Context = "";
		this.ModelName = undefined;
		this.Items = [];
		this.Search = "";
	};

	var Callbacks = Util.callbacks;

	var _oFilter = new Filter("AuthLevelType", FilterOperator.EQ, Constant.AuthLevelType.DEBITOR);

	var CONTEXT = "Context";
	var ITEMS = "Items";
	var MODEL_NAME = "ModelName";

	/**
	 * Dialog for selecting restricted customers
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseValueHelpDialog
	 * @alias sap.support.useradministration.controller.dialog.SelectRestrictedCustomers
	 */
	return BaseValueHelpDialog.extend("sap.support.useradministration.controller.dialog.SelectRestrictedCustomers", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "SelectRestrictedCustomers",

		/**
		 * Perform a backend check if the list of customers is full and it's need to recommend a "Granted for All" functionality
		 * @param {string[]} aCustomersIds customers IDs
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_checkCustomersIds: function(aCustomersIds) {
			var oPromise = this._getPromise();
			if (aCustomersIds && aCustomersIds.length) {
    			this._oView.getModel("ts").read("/Check_selectionSet", {
    				filters: [
    					new Filter("Type", FilterOperator.EQ, "C"),
    					new Filter({
    						filters: aCustomersIds.map(function(sCustId) {
    							return new Filter("Kunnr", FilterOperator.EQ, sCustId);
    						}),
    						and: false
    					})
    				],
    
    				success: function(oData) {
    					oPromise.resolve({
    						AllSelected: !(oData.results && oData.results.length),
    						Customers: aCustomersIds
    					});
    				},
    				error: function() {
    					oPromise.reject();
    				}
    			});
			} else {
			    oPromise.resolve({
			        AllSelected: false,
			        Customers: []
			    });
			}
			return oPromise.promise();
		},

		/**
		 * Show confirmation box to choose "Granted for All"
		 * On OK, choose "Granted for All", otherwise update customers' list
		 * @param {string[]} aCustomers list of customer numbers
		 * @function
		 * @private
		 */
		_confirmSelectGrantedForAll: function(aCustomers) {
			var oBundle = this._getResourceBundle();
			this.showConfirmationBox(oBundle.getText("AUTHORIZATION_LEVEL_ALL_ENTRIES_4_CCC_CONFIRM"), {
					title: oBundle.getText("DETAIL_USER_IMPORTANT_INFO")
				})
				.then(this._grantAll.bind(this))
				.fail(this._saveCustomers.bind(this, aCustomers))
				.always(this.close.bind(this));
		},

		/**
		 * Get installation items from model
		 * @returns {object[]} installations
		 * @function
		 * @private
		 */
		_getItems: function() {
			return this._getDialogProperty(ITEMS) || [];
		},

		/**
		 * Get customers items with one of given IDs
		 * @param {string[]} aIds ID list
		 * @returns {object[]} customers list
		 * @function
		 * @private
		 */
		_getItemsByIds: function(aIds) {
			var oKeyToItem = Util.combineArray(this._getItems(), Callbacks.getKey("CustNum"), Callbacks.self); // Create map { Item.AuthLevel => Item }
			return aIds.map(function(sCustId) {
		        var iLen = Math.max(0, 10 - sCustId.length),
		            sNormalId = "0000000000".slice(0, iLen) + sCustId,
		            oTokenItem = oKeyToItem[sNormalId];
				return oTokenItem && jQuery.extend(true, {}, oTokenItem);
			}).filter(Boolean);
		},

		/**
		 * Set "Granted All" in the parent view to true
		 * @function
		 * @private
		 */
		_grantAll: function() {
		    var oParent = this._oParentDialog || this._oController;
			oParent.grantAll();
		},

		/**
		 * Load items from backend
		 * @returns {object} promise
		 * @function
		 * @public
		 */
		_loadItems: function() {
			var oModel = Util.getModel.call(this._oController, this._getDialogProperty(MODEL_NAME)),
				oPromise = this._getPromise();

			if (this._oLoader && this._oLoader.abort) {
				this._oLoader.abort();
			}

			this._setDialogProperty(ITEMS, []);
			this._oLoader = oModel.read(this._getDialogProperty(CONTEXT) + "/AuthObjectAuthLevelF4HelpSet", {
				filters: [_oFilter],
				success: function(oData) {
					this._updateItems(oData.results || []);
					this.getDialog().update();
					oPromise.resolve();
				}.bind(this),
				error: function() {
					oPromise.reject();
				}
			});

			return oPromise.promise();
		},

		/**
		 * Prepare table when opening dialog
		 * @param {sap.ui.table.Table} oTable table
		 * @function
		 * @private
		 * @override
		 */
		_prepareTable: function(oTable) {
			if (!oTable.getModel("columns")) {
				oTable.setModel(this.createJSONModel({
					cols: [{
						label: this.getText("MASTER_COLUMN_CUST_NAME"),
						template: "dialog>CustName"
					}, {
						label: this.getText("MASTER_COLUMN_CUST_NUM"),
						template: "dialog>CustNum"
					}, {
						label: this.getText("AUTH_OBJ_ASSIGN_DESCRIPTION"),
						template: "dialog>CustDesc"
					}]
				}), "columns");
			}

			oTable.bindRows({
				path: "dialog>" + ITEMS
			});
		},

		/**
		 * Updates customer list in the parent controller
		 * @param {object[]} aCustomers array of customers
		 * @function
		 * @private
		 */
		_saveCustomers: function(aCustomers) {
		    var oParent = this._oParentDialog || this._oController;
			oParent.saveCustomers(aCustomers);
		},

		/** 
		 * Update items in the dialog model
		 * @param {object[]} aItems items retrieved from the backend
		 * @function
		 * @private
		 */
		_updateItems: function(aItems) {
			this._setDialogProperty(ITEMS, aItems);
		},

		/**
		 * Handle dialog confirmation
		 * Ask user to confirm changes
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onConfirmDialog: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens"),
				aCustomersIds = aTokens.map(function(oToken) {
					return oToken.getKey();
				});
			this.setBusy(true);
			this._checkCustomersIds(aCustomersIds)
				.then(function(oData) {
					var aCustomers = oData.Customers || [],
						bGrantAll = oData.AllSelected;
					if (bGrantAll) {
						this._confirmSelectGrantedForAll(this._getItemsByIds(aCustomers));
					} else {
						this._saveCustomers(this._getItemsByIds(aCustomers));
						this.close();
					}
				}.bind(this))
				.always(this.setBusy.bind(this, false));
		},

		/**
		 * Open dialog and load items
		 * @function
		 * @public
		 * @override
		 */
		open: function() {
			BaseValueHelpDialog.prototype.open.apply(this, arguments);
			this.setBusy(true);
			this._loadItems().always(this.setBusy.bind(this, false));
		},

		/**
		 * Set context property
		 * @param {string} sContext context path
		 * @function
		 * @public
		 */
		setContext: function(sContext) {
			this._setDialogProperty(CONTEXT, sContext);
		},

		/**
		 * Set model name property
		 * @param {string} sModelName model name
		 * @function
		 * @public
		 */
		setModelName: function(sModelName) {
			this._setDialogProperty(MODEL_NAME, sModelName);
		}
	});
});
sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    "sap/support/useradministration/model/Constant",
    "sap/support/useradministration/util/Util",
    
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function(BaseDialog, Constant, Util, Filter, FilterOperator) {
	"use strict";
	
	var AuthLevel = Constant.AuthLevel;
	
    var _fnFactory = function() {
        this.AuthLevelId = "";
        this.AuthPackId = "";
        this.TempCurrentAuthLevel = "";
        this.ObjectId = "";
        this.ObjectDesc = "";
        this.TempSelected = false;
    };
    
    var BATCH_GROUP = "apAuthObjCopyGroup";
    //var PATH = "/AuthorizationObjectCopySet";
    
    /**
     * Dialog for copying authorization levels in Auth Package Detail
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.CopyAPAuthorizationLevels
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.CopyAPAuthorizationLevels", {
        _fnDataFactory: _fnFactory,
        _sDialogName: Constant.Dialog.COPY_AP_AUTH_LEVELS,
        
        /**
         * Clear search before opening a dialog
         * @function
         * @protected
         * @override
         */
        _beforeOpen: function() {
        	this._filter();
        },
        
        /**
         * Copy auth levels
         * @param {object[]} aAuthObjects authorization objects
         * @function
         * @private
         */
        _copyAuthLevels: function(aAuthObjects) {
            var oModel = this._oView.getModel("ap"),
            	oAuth = this._getDialogProperty("Auth");
    		
    		oModel.setUseBatch(true);
    		oModel.setDeferredGroups([BATCH_GROUP]);
    		if (oAuth.TempCurrentAuthLevel === AuthLevel.RESTRICTED) {
				this._downloadLevels(oAuth.AuthPackId, oAuth.ObjectId)
					.then(function (oData) {
						var aLevels = oData && oData.results || [];
						aLevels = aLevels.map(function (oLevel) {
			        		var oCopy = jQuery.extend(true, {}, oLevel);
			        		if (this.formatter.detail.isCustomerLevel(oLevel)) {
			        			oCopy.AuthLevelType = "DEBITOR";
			        		} else if (this.formatter.detail.isInstallationOrUserLevel(oLevel)) {
			        			oCopy.AuthLevelType = oAuth.AuthLevelId;
			        		}
			        		return oCopy;
						}.bind(this));
						
    					aAuthObjects.forEach(this._updateLowLevelAuth.bind(this, oModel, aLevels));
					}.bind(this))
					.then(this._submitChanges.bind(this))
					.fail(function () {
						oModel.setUseBatch(false);
						this._getRequester().refreshBinding();
					}.bind(this));
    		} else {
    			aAuthObjects.forEach(this._updateTopLevelAuth.bind(this, oModel, oAuth.TempSelected));
    			this._submitChanges();
    		}
        },
        
        /**
         * Copy authorization levels locally
         * @param {object[]} aAuthObjects authorization objects to copy into
         * @return {object} promise
         * @function
         * @private
         */
        _copyAuthLevelsLocally: function(aAuthObjects) {
            var oAuth = this._getDialogProperty(""),
            	oPromise = Util.getPromise();
            
    		if (oAuth.TempCurrentAuthLevel === AuthLevel.RESTRICTED) {
    			if (oAuth.Customers) { // Levels already exist
    				aAuthObjects.forEach(this._updateLowLevelAuthLocally.bind(this, oAuth));
    			} else {
					return this._downloadLevels(oAuth.AuthPackId, oAuth.ObjectId)
						.then(function (oData) {
							var aLevels = oData && oData.results || [];
							aLevels = aLevels.map(Util.deepCopy);
							oAuth.Customers = aLevels.filter(this.formatter.detail.isCustomerLevel);
							oAuth.Installations = aLevels.filter(this.formatter.detail.isInstallationOrUserLevel);
    						aAuthObjects.forEach(this._updateLowLevelAuthLocally.bind(this, oAuth));
						}.bind(this));
    			}
    		} else {
    			aAuthObjects.forEach(this._updateTopLevelAuthLocally.bind(this, oAuth.TempSelected));
    		}
    		return oPromise.resolve().promise();
        },
        
        /**
         * Download authorization levels to copy
         * @param {string} sAuthPackId authorization package ID
         * @param {string} sObjectId authorization object ID
         * @returns {object} promise
         * @function
         * @public
         */
        _downloadLevels: function(sAuthPackId, sObjectId) {
        	var sPath = jQuery.sap.formatMessage("/AuthObjectSet(PackageId=''{0}'',ObjectId=''{1}'')/AuthObjectAuthLevelSet", [sAuthPackId, sObjectId]);
        	return Util.read.call(this, sPath, {}, "ap");
        },
        
        /**
         * Filter authorization list
         * @param {string} sSearchValue search value
         * @function
         * @private
         */
        _filter: function(sSearchValue) {
            var aFilters = [],
                sAuthLevelId = this._getDialogProperty("AuthLevelId");
            if (sAuthLevelId) {
                aFilters.push(new Filter("AuthLevelId", FilterOperator.EQ, sAuthLevelId));
            }
            if (sSearchValue) {
                aFilters.push(new Filter("ObjectDesc", FilterOperator.Contains, sSearchValue));
            }
            this.getDialog().getBinding("items").filter(aFilters);
        },
        
        /**
         * Submit changes
         * @function
         * @private
         */
        _submitChanges: function() {
        	Util.submitChanges.call(this, {
	        		groupId: BATCH_GROUP
	        	}, "ap")
        		.then(function () {
        			sap.m.MessageToast.show(this.getText("MESSAGE_COPY_AUTH_2_USERS_SUCCESS"));
        		}.bind(this))
        		.always(function() {
					this.getModel("ap").setUseBatch(false);
					this._getRequester().refreshBinding();
        		}.bind(this));
        },
        
        /**
         * Update low-level authorization
         * @param {sap.ui.model.odata.v2.ODataModel} oModel model to change data
         * @param {object[]} aLevels authorization levels to copy from
         * @param {object} oAuth authorization object to copy into
         * @function
         * @private
         */
        _updateLowLevelAuth: function(oModel, aLevels, oAuth) {
        	aLevels.forEach(function (oLevel) {
        		var sPath = jQuery.sap.formatMessage("/AuthObjectLevelSet(PackId=''{0}'',ObjectId=''{1}'',AuthLevel=''{2}'',AuthLevelType=''{3}'')", [
					oAuth.PackageId, oAuth.ObjectId, oLevel.AuthLevel, oLevel.AuthLevelType
				]);
				
				oModel.update(sPath, {
					PackId: oAuth.PackageId,
					ObjectId: oAuth.ObjectId,
					AuthLevel: oLevel.AuthLevel,
					AuthLevelType: oLevel.AuthLevelType,
					IsAssigned: true
				}, {
					groupId: BATCH_GROUP
				});
        	});
        },
        
        
        /**
         * Update low-level authorization locally
         * @param {object} oSource authorization object to copy from
         * @param {object} oDest authorization object to copy into
         * @function
         * @private
         */
        _updateLowLevelAuthLocally: function(oSource, oDest) {
        	oDest.Customers = oSource.Customers ? oSource.Customers.map(Util.deepCopy) : [];
        	oDest.Installations = oSource.Installations ? oSource.Installations.map(Util.deepCopy) : [];
        	oDest.Customers.forEach(function (oCustomer) {
        		oCustomer.PackId = oDest.PackageId;
        		oCustomer.ObjectId = oDest.ObjectId;
        		oCustomer.AuthLevelType = "DEBITOR";
        	});
        	oDest.Installations.forEach(function (oInstallation) {
        		oInstallation.PackId = oDest.PackageId;
        		oInstallation.ObjectId = oDest.ObjectId;
        		oInstallation.AuthLevelType = oDest.AuthLevelId;
        	});
        	this._getRequester()._handleAuthorizationObjectSelectChange(oDest, /* bKeepDetails = */ true);
        },
        
        /**
         * Update top-level authorization
         * @param {sap.ui.model.odata.v2.ODataModel} oModel model to change data
         * @param {boolean} bSelected selection state
         * @param {object} oAuth authorization object to update
         * @function
         * @private
         */
        _updateTopLevelAuth: function(oModel, bSelected, oAuth) {
        	var sPath = jQuery.sap.formatMessage("/AuthObjectSet(PackageId=''{0}'',ObjectId=''{1}'')", [oAuth.PackageId, oAuth.ObjectId]);
			oModel.update(sPath, {
				Selected: bSelected
			}, {
				groupId: BATCH_GROUP
			});
        },
        
        /**
         * Update top-level authorization locally
         * @param {boolean} bSelected selection state
         * @param {object} oAuth authorization object to update
         * @function
         * @private
         */
        _updateTopLevelAuthLocally: function(bSelected, oAuth) {
        	oAuth.TempSelected = bSelected;
        	this._getRequester()._handleAuthorizationObjectSelectChange(oAuth, /* bKeepDetails = */ false);
        },
        
        /**
         * Handle dialog confirm
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onConfirm: function(oEvent) {
            var oController = this._getRequester(),
            	aAuthObjects = oEvent.getParameter("selectedContexts")
	                .map(function (oContext) {
	                    return oContext.getObject();
	                });
            
            if (aAuthObjects.length) {
	            var sMessage = this.getText("MESSAGE_CONFIRM_COPY_AUTHORIZATION_LEVELS", [this._getDialogProperty("ObjectDesc")]);
	            
	            this.showConfirmationBox(sMessage, {
	                title: this.getText("MESSAGE_COPY_AUTH_2_USERS_APPROVE_TITLE")
	            })
	            	.then(function() {
						oController.setBusy(true);
	            		this._copyAuthLevelsLocally(aAuthObjects);
	            	}.bind(this))
	            	.then(oController._updateAuthorizationListChanges.bind(oController))
	            	.always(oController.setBusy.bind(oController, false));
            }
        },
        
        /**
         * Handle search
         * @param {sap.ui.base.Event} oEvent event
         * @event
         * @public
         */
        onSearch: function(oEvent) {
            this._filter(oEvent.getParameter("value"));
        },
        
        /**
         * Set authorization data
         * @param {object} oAuthorization authorization object
         * @function
         * @public
         */
        setAuthorization: function (oAuthorization) {
            this._setDialogProperty("", Util.deepCopy(oAuthorization));
        },
        
        /**
         * Set authorization package data
         * @param {object} oPackage authorization package
         * @function
         * @public
         */
        setAuthPackage: function (oPackage) {
            this._setDialogProperty("AuthPackId", oPackage.AuthPackId);
        }
    });
});
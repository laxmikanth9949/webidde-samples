sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/model/Constant"
], function (BaseDialogNew, Util, Constant) {

	var _fnFactory = function () {
		this.List = [];
		this.ViewModel = {};

	};

	return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.EmailDuplicates", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "EmailDuplicates",
		_sExcludeUser: "",

		beforeOpen: function () {
			this._loadDuplicateList();
		},
		
		afterClose: function(){
			this._oController.handleEmailDuplicateDialogClose();
		},

		setViewModel: function(oModel){
			return this.setProperty("ViewModel", oModel);
		},

		setExcludeUser: function(sExludeUser) {
			this._sExcludeUser = sExludeUser;
		},

		_loadDuplicateList: function () {
			var oModel = this.getModel();
			var oDialogModel = this.getProperty("ViewModel");
			var oFunctionParamsIsDuplicateEmail = {
				method: "GET",
				urlParameters: {
					Ipadr: oDialogModel.Email,
					Kunnr: oDialogModel.CustomerNumber
				},
				refreshAfterChange: true
			};
			Util.promiseCallFunction.call(this, Constant.Functions.GetDuplicateEmails, oFunctionParamsIsDuplicateEmail, oModel)
				.then(function (oData) {
					var excludedUser = this._sExcludeUser;
					var dupArr = oData.results.filter(function(item) {
						return item.Susid !== excludedUser;
					})
					this.setProperty("List", dupArr);
				}.bind(this));
		}

	});
});
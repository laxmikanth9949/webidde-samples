sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.UsersWithCriticalRole", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "UsersWithCriticalRole",
        
        beforeOpen: function() {
			this.setProperty("List", this.getProperty("usersWithCriticalRoles")
				.map(function (user) {
					return {
						Name: user.getBindingContext().getProperty("Name1") + ", " + user.getBindingContext()
							.getProperty("Namev"),
						Susid: user.getBindingContext().getProperty("Susid")
					};
					
				}));
        },
        
        onHelpButton: function () {
			sap.m.MessageBox.show(this.getText("MASTER_DEL_USER_WITH_IMP_FUNC_TOOLTIP"), {
				icon: sap.m.MessageBox.Icon.INFORMATION,
				title: this.getText("HELP_TITLE"),
				actions: [sap.m.MessageBox.Action.CLOSE]
			});
		},
		
		onOKButton: function () {
			var oModel = this._oView.getModel();

			this._oController._processUserDeletion(oModel, this._oView.getModel("i18n"));

			//sap.ui.getCore().byId("idActionLabel").setVisible(true);
			//sap.ui.getCore().byId("idDialogUsersWithCriticalRoleOKButton").setVisible(true);
			//sap.ui.getCore().byId("idDialogUsersWithCriticalRoleCancelButton").setVisible(true);

			this.getDialog().close();
		}
   
    });
});
sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SettingUserList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SettingUserList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SettingUserList",
        
        _beforeOpen: function() {
        },
        
        onSubmit: function(oEvent) {
        	this._getRequester()._tableSettingsChange(oEvent, "idUserSettingsTableGroup", "idUserTable");
        },
        
        onCancel: function() {
        	this.close();
        }
   
    });
});
sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",

	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function (BaseDialog, Constant, Util, Filter, FilterOperator) {
	var _fnFactory = function () {
		this.Search = "";
	};

	/**
	 * Dialog for assigning authorization packages to user
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseDialog
	 * @alias sap.support.useradministration.controller.dialog.AssignCustomerToUser
	 */
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.AssignCustomerToUser", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "AssignCustomerToUser",

		_getList: function () {
			return this._oDialog.getContent()[0];
		},

		onSearch: function () {
			var itemsLength = this._getList().getBinding("items").aAllKeys.length;
			this.getDialog().setContentHeight(itemsLength * 5 + "rem");
			var sValue = this.getProperty("Search"),
				aFilters = sValue ? [new Filter({
					filters: [
						new Filter("Name1", FilterOperator.Contains, sValue),
						new Filter("Kunnr", FilterOperator.Contains, sValue)
					]
				})] : [];
			this._getList().getBinding("items").filter(aFilters);
		},

		onCustomerPress: function (oEvent) {
			var oCustomer = oEvent.getSource();
			if (this._getRequester().setCustomer) {
				this._getRequester().setCustomer(oCustomer.getDescription(), oCustomer.getTitle());
				this._getRequester().updateErrorMessagesNew();
			}
			this.close();
		},

		onAssign: function () {
			var oCustomer = this._getList().getSelectedItem();
			if (this._getRequester().setCustomer) {
				this._getRequester().setCustomer(oCustomer.getDescription(), oCustomer.getTitle());
			}
			this.close();
		},

		onClose: function () {
			this.close();
		}
	});
});
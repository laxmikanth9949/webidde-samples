sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    "sap/support/useradministration/util/Util",
    "sap/support/useradministration/extended/SmartTable"
], function(BaseDialog, Util, SmartTable) {
	return BaseDialog.extend("sap.support.useradministration.controller.dialog.APAuthOverview", {
		_sDialogName: "APAuthOverview",
		_beforeOpen: function () {
			var oView = this._oView;
			var oModel = oView.getModel("ap");
			var oSelAP = this._getSelectedAP();
			var sPath = oSelAP.getBindingContextPath();
			var oItemData = oModel.getData(sPath);
			var sAuthPackName = oItemData.Text;

			var APOverviewAuthTable = this.getDialog().getContent()[1];
			var iCount = this._getAuthCount();
			var aFilters = [];
			//Set new filter
			var filter = new sap.ui.model.Filter("AuthPackId", sap.ui.model.FilterOperator.EQ, oItemData.AuthPackId);
			aFilters.push(filter);
			APOverviewAuthTable.getBinding("items").filter(aFilters);
			this.setProperty("description", this.getText("MESSAGE_DESCRIPTION_AUTH_PACK_OVERVIEW", [sAuthPackName]));
			this.setProperty("authCountText", this.getText("DETAIL_AUTH_OBJECTS") + " (" + iCount + ")");
		},
		
		setSelectedAP: function(oSelectedAP) {
			return this.setProperty("AuthPack", oSelectedAP);
		},
		
		_getSelectedAP: function() {
			return this.getProperty("AuthPack");                                                 
		},
		
		onSmartTableDownload: function (oEvent) {
			var oTable = Util.closest(oEvent.getSource(), SmartTable);
			if (oTable) {
				oTable.saveToFile();
			}
		},
		
		setAuthCount: function (iCount) {
			return this.setProperty("authCount", iCount);
		},
		
		_getAuthCount: function () {
			return this.getProperty("authCount");
		}
	});
});
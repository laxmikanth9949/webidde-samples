sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialogNew",
    "sap/support/useradministration/util/Util"
], function(BaseDialogNew, Util) {
    "use strict";

    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
     * @alias sap.support.useradministration.controller.dialog.FilterAuthorizationHistory
     */
    return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.FilterAuthorizationHistory", {
        _fnDataFactory: function() {
	    },
        _sDialogName: "FilterAuthorizationHistory",
        
        beforeOpen: function() {
        	var sUser = this.getRequester().getUser();
        	this.setBusy(true);
        	Promise.all([this._loadAuthObjectsList(), this._loadProcessedByList(sUser), this._loadProfnaList(sUser), this._loadAPList(sUser)])
        		.finally(this.setBusy.bind(this, false));
        	this._processProcessedOnList();
        },
        
        /**
         * Load Authhorization objects list
         * @param {string} sUserId S-User id
         * @return {Promise} Authorization Object List
         * @function
         * @private
         */
        _loadAuthObjectsList: function () {
        	var aList = this.getProperty("AuthAssignHistoryAuthObjects");
        	if (aList && aList.length) {
        		return true;
        	}
        	return Util.promiseRead.call(this, "/AuthObjectF4HelpSet")
        		.then(this._processAuthObjectsList.bind(this));
        },
        
        /**
         * Process Processed By list came from backend
         * @param {object} oData data
         * @function
         * @private
         */
        _processAuthObjectsList: function (oData) {
			var aList = oData.results || [];
			aList = aList.filter(function (oItem) {
				return oItem.ObjectId !== "None" && oItem.ObjectId !== "All";
			}).sort();
			
			this.setProperty("AuthAssignHistoryAuthObjects", aList);
        },
        
        /**
         * Load Processed By list
         * @param {string} sUserId S-User id
         * @function
         * @return {Promise} Processed By List
         * @private
         */
        _loadProcessedByList: function (sUserId) {
        	return Util.promiseRead.call(this, "/AuthAssignmentHistoryF4HelpSet", {
        		filters:[
		 			new sap.ui.model.Filter("Ubname", sap.ui.model.FilterOperator.EQ, sUserId)
		 		]
        	})
        		.then(this._processProcessedByList.bind(this));
        },
        
        /**
         * Process Processed By list came from backend
         * @param {object} oData data
         * @function
         * @private
         */
        _processProcessedByList: function (oData) {
			this._bInvalid = false;
			var aList = oData.results || [];
			
			this.setProperty("AuthAssignHistoryProcessedBy", aList);
        },
        
        /**
         * Load Authorization Level list
         * @param {string} sUserId S-User id
         * @function
         * @return {Promise} Profna List
         * @private
         */
        _loadProfnaList: function (sUserId) {
        	return Util.promiseRead.call(this, "/AuthAssignmentHisProfnaF4HelpSet", {
        		filters:[
		 			new sap.ui.model.Filter("Ubname", sap.ui.model.FilterOperator.EQ, sUserId)
		 		]
        	})
        		.then(this._processProfnaList.bind(this));
        },
        
        /**
         * Process Authorization Level came from backend
         * @param {object} oData data
         * @function
         * @private
         */
        _processProfnaList: function (oData) {
			this._bInvalid = false;
			var aList = oData.results || [],
				aResProfna = [],
				aResProfnaText = [],
				oProfnaObject = {},
				oProfnaTextObject = {};
			aList.forEach(function (oItem) {
				oProfnaObject["Profna" + oItem.Profna] = {
					Pgroup: oItem.Pgroup,
					Profna: oItem.Profna
				};
				oProfnaTextObject["ProfnaText" + oItem.ProfnaText] = {
					ProfnaText: oItem.ProfnaText
				};
			});
			
			aResProfna = Object.keys(oProfnaObject).map(function(key) {
				return oProfnaObject[key];
			});
			aResProfnaText = Object.keys(oProfnaTextObject).map(function(key) {
				return oProfnaTextObject[key];
			});
			
			this.setProperty("AuthAssignHistoryProfna", aResProfna);
			this.setProperty("AuthAssignHistoryProfnaText", aResProfnaText);
        },
        
        
        
        /**
         * Load Authorization Package list
         * @param {string} sUserId S-User id
         * @function
         * @return {Promise} AP List
         * @private
         */
        _loadAPList: function (sUserId) {
        	return Util.promiseRead.call(this, "/AuthAssignmentHisPackF4HelpSet", {
        		filters:[
		 			new sap.ui.model.Filter("Ubname", sap.ui.model.FilterOperator.EQ, sUserId)
		 		]
        	})
        		.then(this._processAPList.bind(this));
        },
        
        /**
         * Process AP list came from backend
         * @param {object} oData data
         * @function
         * @private
         */
        _processAPList: function (oData) {
			var aList = oData.results || [];
			
			this.setProperty("AuthAssignHistoryAP", aList);
        },
        
        /**
         * Process Processed On list
         * @function
         * @private
         */
        _processProcessedOnList: function () {
	    	var Months = {
	    		"1": 1,
	    		"3": 3,
	    		"6": 6,
	    		"12": 12,
	    		"60": 60
	    	},
        	oMonthValues = {};
			Object.keys(Months).forEach(function (sMonths) {
				
				var oDate = new Date();

				oDate.setMonth(oDate.getMonth() - (parseInt(sMonths, 10) || 0));
				
				oMonthValues[sMonths] = "Logdate___GE___" + Util.date.formatFilterDate(oDate);
			});
			this.setProperty("AuthAssignHistoryProcessedOn", oMonthValues);
        },
        
        /**
         * Invalidate local data
         * @function
         * @public
         */
        invalidate: function () {
        	this._bInvalid = true;
        },
        
        onSubmit: function(oEvent) {
			var oTable = this.getRequester().getTable();

			var mParams = oEvent.getParameters();
			var oBinding = oTable.getBinding("items");
			
			var aFilters = (mParams.filterItems && mParams.filterItems.map(function (oItem) {
				var aSplit = oItem.getKey().split("___");
				var sPath = aSplit[0];
				var sOperator = aSplit[1];
				var sValue1 = aSplit[2];
				
				return new sap.ui.model.Filter(sPath, sOperator, sValue1);
			})) || [];

			oBinding.filter(aFilters);

			this.getRequester().requestHistoryCount(aFilters);

			// update filter bar
			oTable.getInfoToolbar().setVisible(aFilters.length > 0);
			oTable.getInfoToolbar().getContent()[0].setText(mParams.filterString);
        }
   
    });
});
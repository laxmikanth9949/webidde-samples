sap.ui.define([
    "sap/ui/base/Object",
    "sap/base/Log",
    "sap/ui/core/syncStyleClass",
    
	"sap/support/useradministration/model/Formatter",
	"sap/support/useradministration/util/Settings",
	"sap/support/useradministration/util/odata/ODataUtil"
], function (BaseObject, Log, syncStyleClass, Formatter, Settings, ODataUtil) {
    "use strict";
    var _fnFactory = function() {};
    
    var MODEL_DIALOG = "dialog";
    var JSONModel = sap.ui.model.json.JSONModel;
    
    /**
     * Base dialog controller
     * @param {sap.ui.core.mvc.Controller} oParentController parent controller
     * @constructor
     * @class
     * @extends sap.ui.base.Object
     * @alias sap.support.useradministration.controller.dialog.BaseDialog
     */
    return BaseObject.extend("sap.support.useradministration.controller.dialog.BaseDialog", {
        formatter: Formatter,
        _bSyncStyleClass: false,
        _fnDataFactory: _fnFactory,
        _oController: null,
        _oDialog: null,
        _oDialogController: null,
        _oDialogModel: null,
        _oRequester: null,
        _oView: null,
        _sDialogName: null,
        
        constructor: function(oParentController) {
            this._oController = oParentController;
            this._oView = oParentController.getView();
            this._oDialogModel = new sap.ui.model.json.JSONModel();
            this._oDialogModel.setSizeLimit(10000);
            this.clearData();
        },
        
        /**
         * Construct property path in the dialog model
         * @param {...string} sParts path parts
         * @returns {string} full property path
         * @function
         * @private
         */
        _buildPropertyPath: function() {
        	var aParts = Array.prototype.slice.call(arguments);
        	
        	return "/" + aParts.filter(Boolean).map(function (sPart) {
        		return sPart.replace && sPart.replace(/(^\/*)|(\/*$)/g, "") || "";
        	}).join("/");
        },
        
        /**
         * Get component
         * @returns {sap.ui.core.UIComponent} component
         * @function
         * @private
         */
        _getComponent: function () {
        	return this._oController.getOwnerComponent();
        },
        
		/**
		 * Get controller
		 * @returns {sap.ui.core.mvc.Controller} controller
		 * @function
		 * @private
		 */
		_getController: function() {
			return this._oController;
		},
        
        /**
         * Get text for table column
         * @param {sap.m.Column|sap.ui.table.Column} oColumn column
         * @returns {string} text
         * @function
         * @protected
         */
        _getColumnText: function(oColumn) {
			if (oColumn instanceof sap.m.Column) {
				return oColumn.getHeader().getText();
			} else if (oColumn instanceof sap.ui.table.Column) {
				var oLabel = oColumn.getLabel() || "";
				return oLabel.getText && oLabel.getText() || oLabel;
			}
			return "";
        },
        
		/**
		 * Get model with given name from context
		 * @param {string} sModelName model name
		 * @returns {sap.ui.model.Model} model
		 * @function
		 * @public
		 */
		_getContextModel: function(sModelName) {
			var oModel = null;
			if (this) {
				var oView = this.getView && this.getView(),
					oComponent = this.getOwnerComponent && this.getOwnerComponent();
				oModel = this.getModel && this.getModel(sModelName);
				if (!oModel && oView && oView.getModel) {
					oModel = oView.getModel(sModelName);
				}
				if (!oModel && oComponent && oComponent.getModel) {
					oModel = oComponent.getModel(sModelName);
				}
			}
			return oModel;
		},

        /**
         * Get dialog by name
         * @param {string} sName dialog name
         * @returns {sap.m.Dialog} dialog
         * @function
         * @public
         */
        _getDialogByName: function(sName) {
            if (sName) {
                var oDialog = sap.ui.xmlfragment("sap.support.useradministration.view.dialog." + sName, this);
                this._oView.addDependent(oDialog);
                
                this._oDialog = oDialog; // overcome endless loop bug
                oDialog.setModel(this._oDialogModel, MODEL_DIALOG);
	            oDialog.bindElement({
	                path: "/",
	                model: MODEL_DIALOG
	            });
                if (this._bSyncStyleClass) {
                    syncStyleClass("sapUiSizeCompact", this._oView, oDialog);
                }
                return oDialog;
            } else {
                Log.error("Empty dialog name");
				return null;
            }
        },
        
        /**
         * Get logger
         * @returns {object} logger
         * @function
         * @private
         */
        _getLogger: function () {
        	if (!this._oLogger) {
        		this._oLogger = Log.getLogger(this.getMetadata().getName());
        	}
        	return this._oLogger;
        },
		
        /**
         * Return requester of the current dialog
         * @returns {sap.ui.core.Control} requester
         * @function
         * @protected
         */
        _getRequester: function() {
            return this._oRequester || this._oController;  
        },
        
        /**
         * Get i18n resource bundle
         * @returns {sap.ui.core.util.ResourceBundle} bundle
         * @function
         * @private
         */
        _getResourceBundle: function() {
			var oModel = this._getContextModel.call(this._oController, "i18n") || this.getModel("i18n");
			return oModel && oModel.getResourceBundle();
        },
        
        /**
         * Get settings
         * @returns {sap.support.useradministration.util.Settings} settings
         * @function
         * @private
         */
        _getSettings: function () {
        	return Settings;
        },
        
        /**
         * Get XML fragment
         * @param {string} sFragmentName fragment name
         * @returns {sap.ui.core.Fragment} XML fragment
         * @function
         * @private
         */
        _getXmlFragment: function (sFragmentName) {
        	return sap.ui.xmlfragment("sap.support.useradministration.view.fragment." + sFragmentName, this);
        },
        
        /**
         * Reset corresponding data in the model
         * @function
         * @private
         */
        _resetModel: function() {
        	var oData = {};
        	this._fnDataFactory.call(oData);
        	this._oDialogModel.setData(oData);
        },
        
        /**
         * Clear dialog model data
         * @returns {sap.support.useradministration.controller.dialog.BaseDialog} this for chaining
         * @function
         * @public
         */
        clearData: function() {
        	var oData = {};
        	this._fnDataFactory.call(oData);
        	this._oDialogModel.setData(oData);
        	return this;
        },
        
        /**
         * Close dialog
         * @function
         * @public
         */
        close: function() {
        	if (this.beforeClose) {
        		this.beforeClose();
        	}
            this.getDialog().close();
            this._oRequester = null;
            
        	if (this.afterClose) {
        		this.afterClose();
        	}
        },
        
		/**
		 * Create JSON model with extended size limit then add it to view if necessary
		 * @param {object} oData initial data
		 * @param {string} [sName] if provided, model will be set to view using given name
		 * @returns {sap.ui.model.json.JSONModel} created model
		 * @function
		 * @public
		 */
		createJSONModel: function (oData, sName) {
			var oModel = new JSONModel(oData || {});
			oModel.setSizeLimit(10000);
			if (sName) {
				this.setModel(oModel, sName);
			}
			return oModel;
		},
        
        /**
         * Destroy dialog
         * @function
         * @public
         */
        destroy: function() {
            if (this._oDialog) {
                this._oDialog.unbindElement(MODEL_DIALOG);
                this._oDialog.destroy();
                this._oDialog = null;
            }
        },
        
		/**
		 * Get current dialog name
		 * @returns {string} name
		 * @function
		 * @public
		 */
		getDialogName: function() {
			return this._sDialogName;
		},
        
        /**
         * Get dialog
         * @returns {sap.m.Dialog} dialog
         * @function
         * @public
         */
        getDialog: function() {
            if (!this._oDialog) {
                this._oDialog = this._getDialogByName(this.getDialogName());
            }
            return this._oDialog;
        },
        
        /**
         * Get data factory for dialog model
         * @returns {function} factory
         * @function
         * @public
         */
        getDataFactory: function() {
            return this._fnDataFactory;
        },
        
        /**
         * Get dialog controls by field group id
         * @param {string} sFieldGroupId field group id
         * @returns {sap.ui.core.Control[]} controls
         * @function
         * @public
         */
        getFGControls: function(sFieldGroupId) {
        	return this.getDialog().getControlsByFieldGroupId(sFieldGroupId);
        },
        
        /**
         * Get model
         * @param {string} sName model name
         * @returns {sap.ui.model.Model} model
         * @function
         * @public
         */
        getModel: function(sName) {
        	return this.getDialog().getModel(sName);
        },
        
        /**
         * Get dialog name
         * @returns {string} name
         * @function
         * @public
         */
        getName: function() {
            return this._sDialogName;
        },
        
        /**
         * Get corresponding property from dialog model
         * @param {string} sPropertyName property name
         * @returns {any} value
         * @function
         * @public
         */
        getProperty: function(sPropertyName) {
            return this._oDialogModel.getProperty(this._buildPropertyPath(sPropertyName));
        },
        
        /**
         * Return requester of the current dialog
         * @returns {sap.ui.core.Control} requester
         * @function
         * @protected
         */
        getRequester: function() {
        	return this._getRequester();
        },
        
        /**
         * Get text from i18n bundle
         * @param {string} sKey i18n key
         * @param {any[]} aArgs i18n arguments
         * @returns {string} text
         * @function
         * @public
         */
        getText: function(sKey, aArgs) {
            return this._getResourceBundle().getText(sKey, aArgs);
        },
        
        /**
         * Check if dialog is open
         * @returns {boolean} check result
         * @function
         * @public
         */
        isOpen: function () {
        	return this.getDialog().isOpen();
        },
        
        /**
         * Open dialog
         * @param {sap.ui.core.Control} oRequester requester
         * @function
         * @public
         */
        open: function(oRequester) {
            var oDialog = this.getDialog();
            this.syncStyleClass();
            this._oRequester = oRequester || null;
            
            if (this.beforeOpen) {
            	this.beforeOpen();
            }
            
            if (oDialog.openBy) {
            	oDialog.openBy(oRequester);
            } else {
            	oDialog.open();
            }
            
            if (this.afterOpen) {
            	this.afterOpen();
            }
        },
        
        /**
         * Set dialog busy state
         * @param {boolean} bBusyState busy state
         * @function
         * @public
         */
        setBusy: function(bBusyState) {
            this.getDialog().setBusy(bBusyState);
        },

		/**
		 * Set model
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.support.useradmininstration.controller.dialog.BaseDialog} instance itself for chaining
		 * @function
		 * @public
		 */
		setModel: function(oModel, sName) {
			this.getDialog().setModel(oModel, sName);
			return this;
		},
        
        /**
         * Set corresponding property value in dialog model
         * @param {string} sPropertyName property name
         * @param {any} vValue value
         * @returns {sap.support.useradministration.controller.dialog.BaseDialog} this for chaining
         * @function
         * @public
         */
        setProperty: function(sPropertyName, vValue) {
            this._oDialogModel.setProperty(this._buildPropertyPath(sPropertyName), vValue);
            return this;
        },
        
        /**
         * Sync style class
         * @returns {sap.support.useradministration.controller.dialog.BaseDialog} this for chaining
         * @function
         * @public
         */
        syncStyleClass: function() {
		    syncStyleClass("sapUiSizeCompact", this._oView, this.getDialog());
		    return this;
        },
        
        /**
		 * Get OData utility instance
		 * @param {string} [sSetName] get set-specified utility
		 * @returns {sap.support.useradministration.util.odata.ODataUtil} utility
		 * @function
		 * @public
		 */
		getODataUtil: function (sSetName) {
			return sSetName ? ODataUtil[sSetName] : ODataUtil;
		},
		
		/**
		 * Get OData utility instance for UserSet
		 * @returns {sap.support.useradministration.util.odata.ODataUtil} utility
		 * @function
		 * @public
		 */
		getUserSetODataUtil: function () {
			return this.getODataUtil("UserSet");
		}
    });
});
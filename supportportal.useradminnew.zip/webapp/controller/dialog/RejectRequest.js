sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    "sap/support/useradministration/util/Util"
], function(BaseDialog, Util) {
	"use strict";
	
	var PROP_EXPIRY_DATE = "ExpiryDate",
		PROP_REQUEST_ID = "RequestId",
		PROP_REJECT_REASON = "RejectReason",
		PROP_TYPE_OF_REQUEST = "TypeOfRequest";
	
    var _fnFactory = function() {
    	this[PROP_REQUEST_ID] = "";
    	this[PROP_REJECT_REASON] = "";
    	this[PROP_TYPE_OF_REQUEST] = "";
    };
    
    /**
     * Dialog to enter reject reason and reject Authorization or Expiry request
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.RejectRequest
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.RejectRequest", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "RejectRequest",
        
        /**
         * Reject request
         * @event
         * @public
         */
        onRejectRequest: function() {
        	var sRequestId = this._getDialogProperty(PROP_REQUEST_ID),
        		sTypeOfRequest = this._getDialogProperty(PROP_TYPE_OF_REQUEST),
        		// sRejectReason = Util.encodeString(this._getDialogProperty(PROP_REJECT_REASON)),
        		sRejectReason = this._getDialogProperty(PROP_REJECT_REASON),
        		oExpiryDate = this._getDialogProperty(PROP_EXPIRY_DATE),
        		oController = this._oController,
        		oData = {
	        		TypeOfRequest: sTypeOfRequest,
	        		Status: "R",
	        		RejectReason: sRejectReason
	        	};
        	if (!sRejectReason) {
        		var oInput = sap.ui.getCore().byId("idRejectReason");
        		oInput.setValueState(sap.ui.core.ValueState.Error);
        		oInput.setValueStateText(this.getText("MESSAGE_REJECTION_REASON_INVALID"));
        		oInput.focus();
        		return;
        	}	
        	if (oExpiryDate && this.formatter.request.isExpiryRequest(sTypeOfRequest)) {
        		oData.ExpDate = Util.date.dateToUTCDate(oExpiryDate);
        	}
        	this.setBusy(true);
        	Util.promiseUpdate.call(this, "/AuthorizationRequestSet('" + sRequestId + "')", oData)
	        	.then(function () {
	        		sap.m.MessageToast.show(this.formatter.request.requestTypeRejectionMessageText.call(this, sTypeOfRequest), {
	        			closeOnBrowserNavigation: false
	        		});
	        		oController._triggerBusEventMaster("tasksTableRefresh");
	        		oController.getRouter().navTo("UA_main", {
	        			tab: "Tasks"
	        		});
	        	}.bind(this))
	        	.finally(function () {
	        		this.setBusy(false);
	        		this.close();
	        	}.bind(this));
        },
        
        /**
         * Set request data
         * @param {string} sRequestId request ID
         * @param {string} sTypeOfRequest type of request
         * @param {Date} oExpiryDate expiry date
         * @returns {sap.support.useradministration.controller.dialog.RejectRequest} this for chaining
         * @function
         * @public
         */
        setRequestData: function (sRequestId, sTypeOfRequest, oExpiryDate) {
        	this._setDialogProperty(PROP_REQUEST_ID, sRequestId);
        	this._setDialogProperty(PROP_TYPE_OF_REQUEST, sTypeOfRequest);
        	this._setDialogProperty(PROP_EXPIRY_DATE, oExpiryDate);
        	return this;
        },
        
        onInputChange: function () {
        	sap.ui.getCore().byId("idRejectReason").setValueState(sap.ui.core.ValueState.None);	
        },
        
        onClose: function () {
        	sap.ui.getCore().byId("idRejectReason").setValueState(sap.ui.core.ValueState.None);
        	this.close();
        }
    });
});
sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog"
], function(BaseDialog) {
    var _fnFactory = function() {
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.SortUserList
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.SortUserList", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "SortUserList",
        
        _beforeOpen: function() {
        	if (!this._bItemsDeleted) {
        		this._deleteItems();
        	}
        },
        
        /**
         * Delete sorters that should not be visible
         * @function
         * @private
         */
        _deleteItems: function () {
        	var bShowUniversalId = this.getModel("app").getData().showUiUniversalid,
        		bLifetimeEnabled = this._getSettings().isSUserLifetimeEnabled,
        		oDialog = this.getDialog();
        	
    		oDialog.getSortItems().filter(function (oItem) {
    			switch (oItem.getKey())  {
    				case "IsUidAssigned":
    				case "UidFirstName":
    				case "UidLastName":
    					return !bShowUniversalId;
    				case "StatusOrder":
    				case "ExpDate":
    					return !bLifetimeEnabled;
    				default:
    					return false;
    			}
    		}).forEach(function (oItem) {
    			oDialog.removeSortItem(oItem);
    		});	
    		this._bItemsDeleted = true;
        },
        
        onSubmit: function(oEvent) {
        	var mParams = oEvent.getParameters();
			// var oBinding = this._oView.byId("idUserTable").getBinding("items");
			var oBinding = this._oController._getUserTable().getBinding("items");
			var aSorters = [];
			
			if (mParams.sortItem) {
				var sPath = mParams.sortItem.getKey();
				var bDescending = mParams.sortDescending;
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
				oBinding.sort(aSorters);
			}
        }
   
    });
});
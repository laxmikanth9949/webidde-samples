sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDepartmentDialog",
	"sap/support/useradministration/util/Util"
], function(BaseDialog, Util) {
	
    /**
     * Dialog for adding departments using new department API
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.AddDepartmentNew
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.AddDepartmentNew", {
        _sDialogName: "AddDepartmentNew",
        
        /**
         * Check department name for duplication
         * @param {string} sDepartmentName department name
         * @returns {Promise} promise
         * @function
         * @private
         */
        _duplicateNameCheck: function (sDepartmentName) {
        	return Util.promiseRead.call(this, "/DepartmentNewSet")
        		.then(function (oData) {
        			var aList = oData && oData.results || [],
        				bExists = aList && aList.some(function (oDepartment) {
        					return oDepartment.DepartmentName === sDepartmentName;
        				});
        			
        			if (bExists) {
    					this.setProperty("Duplicate", true);
        				return Promise.reject();
        			} else {
        				return Promise.resolve();
        			}
        		}.bind(this));
        },

		/**
         * Run on the Department name input change
         * @param {sap.ui.base.Event} oEvent input change event
         * @function
		 * @public
         */
        onInputChange: function (oEvent) {
    		this.setProperty("ErrorMessage", "");

			var sDepartmentNameInput = oEvent.getParameter("value");
			this.runInputChecks(sDepartmentNameInput);
			this.setProperty("IsAddBtnEnabled", !this.getProperty("ErrorMessage"));
        },
		
        /**
         * Save department
         * @event
         * @public
         */
        onSaveDept: function () {
        	if (!this.getProperty("Input")) {
        		this.setProperty("EmptyInput", true);
        		this.updateErrorMessage();
	        	this.getDialog().getControlsByFieldGroupId("umAddDepartmentNewInput")[0].focus();
        		return;
        	}
        	var oEntry = {
        		DepartmentName: this.getProperty("Input")
        	};
        	
        	this.setBusy(true);
        	this.setProperty("IsAddBtnEnabled", false);
			this.setProperty("ExistingDepartmentNames", null);
        	this._duplicateNameCheck(oEntry.DepartmentName)
        		.then(Util.promiseCreate.bind(this, "/DepartmentNewSet", oEntry, {}))
        		.then(function () {
	        		sap.m.MessageToast.show(this.getText("MESSAGE_DEPT_CREATED"));
	        		this._getRequester().loadDepartments();
	        		this.close();
	        	}.bind(this))
	        	.catch(function () {
	        		this.updateErrorMessage();
	        		this.getDialog().getControlsByFieldGroupId("umAddDepartmentNewInput")[0].focus();
	        	}.bind(this))
        		.finally(function(){
        			this.setBusy(false);
        			this.setProperty("IsAddBtnEnabled", true);
        		}.bind(this));
        }
    });
});
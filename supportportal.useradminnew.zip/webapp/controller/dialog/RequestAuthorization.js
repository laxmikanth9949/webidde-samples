sap.ui.define([
    "sap/support/useradministration/controller/dialog/BaseDialog",
    "sap/support/useradministration/util/Util",
	"sap/ui/core/ValueState"
], function(BaseDialog,
	Util,
	ValueState) {
	"use strict";
	
    var _fnFactory = function() {
    	this.Comment = "";
    	this.SelectedAuths = "";
    	this.UserId = "";
		this.AuthValueState = ValueState.None;
    };
    
    /**
     * Dialog for requesting new user
     * @class
     * @extends sap.support.useradministration.controller.dialog.BaseDialog
     * @alias sap.support.useradministration.controller.dialog.RequestAuthorization
     */
    return BaseDialog.extend("sap.support.useradministration.controller.dialog.RequestAuthorization", {
        _fnDataFactory: _fnFactory,
        _sDialogName: "RequestAuthorization",
        
        // _beforeOpen: function() {
        // 	Util.promiseRead.call(this, "/AuthObjectForUserSet").then(function (oData) {
        // 		var aResults = oData.results || [];
        // 		var oKeys = {}
        // 		aResults.forEach(function (res) {
        // 			oKeys[res.AuthObjectGroup] = true;
        // 		});
        // 		var aKeys = Object.keys(oKeys);
        		
        // 	});
        // },
        
        _createRequestAuthorization: function (oRequestData) {
        	var	oEntry = {
    			Description: oRequestData.Comment,
    			UserId: this.getModel("user").getData().name,
    			TileId: "SELF_REQUEST",
    			AuthObjId: oRequestData.SelectedAuths,
    			Flag: true
    		};
        		
        	// if (oRequestData.SelectedAuths && oRequestData.SelectedAuths.length) {
        	// 	oEntry.AuthObjId = oRequestData.SelectedAuths.join(",");
        	// }
        	return Util.promiseCreate.call(this, "/AuthorizationRequestSet", oEntry)
        		.then(this._handleRequestSuccess.bind(this))
        		.catch(this._handleRequestError.bind(this));
        },
 
        _handleRequestError: function(oXhr) {
        	// var oError = Util.parseError(oXhr),
        	// 	sMessage = this.getText(oError.getCode() + "_TITLE");
        		
        	// Util.showErrorBox(sMessage);
        	this.onClose();
        },
        
        _handleRequestSuccess: function() {
        	sap.m.MessageToast.show(this.getText("MESSAGE_REQUEST_NEW_AUTHORIZATION_CREATE_SUCCESS"));
        	this._oController.refreshUserRequestsList();
        	this.onClose();
        },

		onAuthChange: function (oEvent) {
			if (!oEvent.getSource().getSelectedKey()) {
				// oEvent.getSource().setValueState(ValueState.Error);
				this.setProperty("/AuthValueState", ValueState.Error);
			} else {
				// oEvent.getSource().setValueState(ValueState.None);
				this.setProperty("/AuthValueState", ValueState.None);
			}
		},

        
        onSubmit: function() {
        	var oData = this.getProperty("");
        	
        	this.setBusy(true);
        	this._createRequestAuthorization(oData)
        		.catch(function (oError) {
        			this.log.error("Error: " + (oError && oError.message));
        		}.bind(this))
        		.finally(this.setBusy.bind(this, false));
        },
        
        onClose: function() {
        	this.setProperty("SelectedAuths", []);
        	this.setProperty("Comment", "");
        	this.setProperty("UserId", "");
			this.setProperty("/AuthValueState", ValueState.None);
        	this.destroy();
        }
    });
});
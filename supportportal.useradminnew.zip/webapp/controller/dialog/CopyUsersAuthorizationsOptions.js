sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseDialogNew",
	"sap/support/useradministration/util/Util"
], function (BaseDialogNew, Util) {
	"use strict";

	var _fnFactory = function () {
		// this.isAddAuthorization = true;
		// this.isOverwriteAuthorization = false;
		this.sUserFullName = "";
		this.sUserId = {};
		this.aContexts = [];
		this.AddMessageText = "";
		this.OverwriteMessageText = "";
	};

	/**
	 * Dialog for options of copying user's authorizations to another users in User Detail
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseDialogNew
	 * @alias sap.support.useradministration.controller.dialog.CopyUsersAuthorizationsOptions
	 */
	return BaseDialogNew.extend("sap.support.useradministration.controller.dialog.CopyUsersAuthorizationsOptions", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "CopyUsersAuthorizationsOptions",

		beforeOpen: function () {
			this.setProperty("isAddAuthorization", true);
			this.setProperty("isOverwriteAuthorization", false);
			// this.setProperty("sUserFullName", "");
			// this.setProperty("sUserId", {});
			// this.setProperty("aContexts", []);
			// this.setProperty("AddMessageText", "");
			// this.setProperty("OverwriteMessageText", "");
			
			this._setsAddMessageText();
			this._setsOverwriteMessageText();
		},

		setUserFullName: function (sUserFullName) {
			// this.setProperty("sUserFullName", sUserFullName);
			this.sUserFullName = sUserFullName;
		},

		setUserId: function (sUserId) {
			this.setProperty("sUserId", sUserId);
		},

		setContexts: function (aContexts) {
			this.setProperty("aContexts", aContexts);
		},
		
		setAddAuthorizationMode: function (oEvent) {
			this.setProperty("isAddAuthorization", oEvent.getSource().getSelected());
		},
		
		setOverwriteAuthorizationMode: function (oEvent) {
			this.setProperty("isOverwriteAuthorization", oEvent.getSource().getSelected());
		},
		
		onContinuePress: function () {
			this.setBusy(true);
			var sUserd = this.getProperty("sUserId");
			var aContexts = this.getProperty("aContexts");
			var sOption = this._getOptionString(this.getProperty("isAddAuthorization"), this.getProperty("isOverwriteAuthorization"));
			this._copyUsersAuthorizations(aContexts, sUserd, sOption);
		},

		_setsAddMessageText: function () {
			var sAddMessageText = this.getText("DETAIL_COPY_AUTH_OPTIONS_ADD_MESSAGE", [this.sUserFullName]);
			this.setProperty("AddMessageText", sAddMessageText);
		},

		_setsOverwriteMessageText: function () {
			var sOverwriteMessageText = this.getText("DETAIL_COPY_AUTH_OPTIONS_OVERWRITE_MESSAGE", [this.sUserFullName]);
			this.setProperty("OverwriteMessageText", sOverwriteMessageText);
		},

		_getOptionString: function (bIsAdd, bIsOverwrite) {
			if (bIsAdd) {
				return "X";
			}
			if (bIsOverwrite) {
				return "";
			}
		},

		_copyUsersAuthorizations: function (aContexts, sUserId, sOption) {
			var oModel = this.getModel(),
				sBatchGroupId = "idUserAuthObjCopyGroup",
				oRequestParams = {
					groupId: sBatchGroupId
				};

			if (!aContexts || !aContexts.length) {
				return;
			}

			oModel.setUseBatch(true);
			oModel.setDeferredGroups([sBatchGroupId]);

			aContexts.forEach(function (oContext) {
				var sPath = Util.formatMessage("/AuthorizationObjectCopySet(''{0}'')", [sUserId]),
					oEntry = {
						Value: sUserId,
						UserId: oContext.getKey(),
						AddFlag: sOption // X - add, empty - overwrite
					};

				oModel.update(sPath, oEntry, oRequestParams);
			});

			Util.promiseSubmitChanges(oRequestParams, oModel)
				.then(function () {
					this._oController._oDialogs.getDialog("CopyUsersAuthorizationsOptions").close();
					this._oController._oDialogs.getDialog("CopyUsersAuthorizations").close();
					sap.m.MessageBox.success(this.getText("REQUEST_SUBMITTED_TEXT"), {
						title: this.getText("REQUEST_SUBMITTED_TITLE"),
						emphasizedAction: null,
					});  
				}.bind(this))
				.finally(function () {
					this.setBusy(false);
					oModel.setUseBatch(false);
					this._clearDialogModel();
				}.bind(this));
		},
		
		_clearDialogModel: function () {
			this.setProperty("isAddAuthorization", true);
			this.setProperty("isOverwriteAuthorization", false);
		},
		
		onClose: function () {
			this._clearDialogModel();
			this._oController._oDialogs.getDialog("CopyUsersAuthorizationsOptions").close();
		} 
	});
});
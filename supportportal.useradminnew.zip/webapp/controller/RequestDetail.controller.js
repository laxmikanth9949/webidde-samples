sap.ui.define([
	"sap/support/useradministration/controller/BaseController",
	"sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	
	"sap/support/useradministration/extended/HashChecker"
	], function (BaseController, Dialogs, Constant, Util, HashChecker) {
	"use strict";
	
	var REQUEST_DETAIL_ROUTE = "requestDetail",
		REQUEST_AUTH_ASSIGN_ROUTE = "requestAuthorizationAssign",
		USER_DETAIL_VIEW_ROUTE = "userDetailView";
		
	var EVENT_BUS_NAME = "RequestDetail";
	
	var PROP_LIST = "AuthObjects",
		PROP_EDIT = "Auth/Edit",
		PROP_ACCEPTABLE = "Acceptable",
		PROP_IS_ACTIVE = "IsActive",
		PROP_IS_EXPIRY_DATE_INVALID = "IsExpiryDateInvalid",
	//  PROP_IS_EXPIRY_DATE_OVER_RANGE = "IsExpiryDateOverRange",
		
		PROP_MAXIMUM_EXPIRY_DATE = "MaxExpiryDate", // A maximum expiry date to choose
		PROP_MINIMAL_EXPIRY_DATE = "MinExpiryDate", // A minimum expiry date to choose
		PROP_SELECTED_EXPIRY_DATE = "SelectedExpiryDate", // A new expiry date selected in a date picker
		PROP_PREFILLED_EXPIRY_DATE = "PrefilledExpiryDate", // A pre-filled expiry date
		
		PROP_IS_AUTH_REQUEST = "IsAuthorizationRequest",
		PROP_IS_EXPIRY_REQUEST = "IsExpiryRequest",
		PROP_TYPE_OF_REQUEST = "TypeOfRequest";
		
	var History = sap.ui.core.routing.History,
		HistoryDirection = sap.ui.core.routing.HistoryDirection,
		
		TypeOfRequest = Util.Constant.TypeOfRequest;
		
	return BaseController.extend("sap.support.useradministration.view.RequestDetail", {
		_oHistory: History.getInstance(),
		
		onInit: function() {
			this._oDialogs = new Dialogs(this);
			this._oHashChecker = new HashChecker(this.getRouter());
			this.getRouter().getRoute(REQUEST_DETAIL_ROUTE).attachPatternMatched(this._onRouteMatched, this);
			
			this._bindViewModel(EVENT_BUS_NAME);
			this._attachBusEvent("authTopLevelChange", this._handleDetailAuthTopLevelChange.bind(this, false));
			this._attachBusEvent("authDetailsChange", this._handleDetailAuthTopLevelChange.bind(this, true));
		},
		
		_onRouteMatched: function (oEvent) {
			var requestId = oEvent.getParameters().arguments.requestId;
			
			this._setViewProperty("RequestId", requestId);
			
			if (this._getViewProperty(PROP_EDIT) && this._oHistory.getDirection() === HistoryDirection.Backwards) {
				var sPreviousHash = this._oHistory.aHistory[this._oHistory.iHistoryPosition + 1],
					sRouteName = sPreviousHash && this._oHashChecker.getMatchedRouteName(sPreviousHash);
				
				if (sRouteName === USER_DETAIL_VIEW_ROUTE || sRouteName === REQUEST_AUTH_ASSIGN_ROUTE) {
					return;
				}
			}
			this._setEditMode(false);
			this._setViewProperty(PROP_ACCEPTABLE, false); 
			this._setViewProperty("RequestId", requestId);
			this.setBusy(true);
			this._loadRequestData(requestId);
		},

		/**
		 * Attach EventBus event
		 * @param {string} sEventName event name
		 * @param {function} fnHander event handler
		 * @function
		 * @private
		 */
		_attachBusEvent: function (sEventName, fnHander) {
			this.getOwnerComponent().getEventBus().subscribe(EVENT_BUS_NAME, sEventName, fnHander);
		},
		
		/**
		 * Clear auth request data
		 * @function
		 * @private
		 */
		_clearRequestData: function () {
			this._setTypeOfRequest(null);
			
			this._setViewProperty(PROP_ACCEPTABLE, false);
			this._setViewProperty("App", "");
			this._setViewProperty(PROP_LIST, []);
			this._setViewProperty("ChangedOn", null);
			this._setViewProperty("CreatedOn", null);
			this._setViewProperty("Desc", "");
			// this._setViewProperty("RequestedLevels", []);
			this._setViewProperty("Status", "");
			this._setViewProperty("System", "");
			this._setViewProperty("UserId", "");
			this._setViewProperty("ApplName", "");
		
			this._setViewProperty(PROP_IS_ACTIVE, false);
			this._setViewProperty(PROP_SELECTED_EXPIRY_DATE, null);
			this._setViewProperty(PROP_PREFILLED_EXPIRY_DATE, null);
			this._setViewProperty(PROP_IS_EXPIRY_DATE_INVALID, false);
		},
		
		/**
		 * Trigger EventBus event
		 * @param {string} sEventName event name
		 * @function
		 * @private
		 */
		_triggerBusEventMaster: function (sEventName) {
			this.getOwnerComponent().getEventBus().publish("Master", sEventName);
		},

		/**
		 * Get extended copy of authorization object
		 * @param {object} oAuthObject authorization object
		 * @returns {object} extended object
		 * @function
		 * @private
		 */
		_extendAuthorizationObject: function (oAuthObject) {
			var oFormatter = this.formatter.detail;

			return Util.merge({
				Clusters: null, // List of clusters from detail assign; null if no changes at all
				Customers: null, // List of customers from detail assign
				Installations: null, // List of installations from detail assign,
				IsGroupHeader: /^G_/.test(oAuthObject.ObjectId),
				IsTopHeader: oAuthObject.ObjectId === Constant.AuthGroup.ALL,
				TempChanges: false, // Has changes in detail assign
				TempCurrentAuthLevel: oAuthObject.CurrentAuthLevel,
				TempSelected: oFormatter.isAuthorizationSelected(oAuthObject.CurrentAuthLevel)
			}, oAuthObject);
		},

		/**
		 * Get authorization list
		 * @returns {object[]} list
		 * @function
		 * @private
		 */
		_getAuthorizationList: function () {
			return this._getViewProperty(PROP_LIST) || [];
		},
		
		_getAuthObjList: function (sObjects) {
			return sObjects.split(",").map(function (sAuthObjectId) {
				return {
					RequestAuthObjId: sAuthObjectId,
					Acceptable: false
				};
			});
		},
		
		/**
		 * Get current user's ID
		 * @returns {string} id
		 * @function
		 * @private
		 */
		_getUserId: function () {
			return this._getViewProperty("Auth/User/Susid");
		},
		
		/**
		 * Handle selection change for auth object
		 * Change its data according to selected state
		 * Propagate selected state to group(s) if needed
		 * @param {object} oAuth authorization object
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleAuthorizationObjectSelectChange: function (oAuth, bKeepDetails) {
			oAuth.TempChanges = bKeepDetails;
			
			if (bKeepDetails) {
				oAuth.TempSelected = Boolean((oAuth.Clusters && oAuth.Clusters.length) || (oAuth.Customers && oAuth.Customers.length) ||
					(oAuth.Installations && oAuth.Installations.length));
				oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.RESTRICTED : Constant.AuthLevel.EMPTY;
			} else {
				oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.FULL : Constant.AuthLevel.EMPTY;
				oAuth.Clusters = [];
				oAuth.Customers = [];
				oAuth.Installations = [];
			}
			
			this._updateAuthorizationListChanges();
		},

		/**
		 * Handle top level change for auth in detailed assign
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleDetailAuthTopLevelChange: function (bKeepDetails) {
			var oAuth = this._getViewProperty("Auth/Detail");
			if (oAuth) {
				this._handleAuthorizationObjectSelectChange(oAuth, bKeepDetails);
			}
		},
		
		/**
		 * Check if current request is Authorization Request
		 * @returns {boolean} check result
		 * @function
		 * @private
		 */
		_isAuthorizationRequest: function () {
			return this._getViewProperty(PROP_IS_AUTH_REQUEST);	
		},
		
		/**
		 * Check if current request is Expiry Request
		 * @returns {boolean} check result
		 * @function
		 * @private
		 */
		_isExpiryRequest: function () {
			return this._getViewProperty(PROP_IS_EXPIRY_REQUEST);	
		},
		
		/**
		 * Load request data
		 * @param {string} sRequestId request ID
		 * @function
		 * @private
		 */
		_loadRequestData: function (sRequestId) {
			var oParams = {
				filters: [new sap.ui.model.Filter("RequestId", sap.ui.model.FilterOperator.EQ, sRequestId)]
			};
			
			this._clearRequestData();
			Util.promiseRead.call(this, "/AuthorizationRequestSet", oParams)
				.then(this._processRequestData.bind(this))
				.then(this._loadUserData.bind(this))
				.then(this._processUserData.bind(this))
				.then(this._loadRequestedObjectData.bind(this))
				.then(this._processRequestedObjectData.bind(this))
				.finally(this.setBusy.bind(this, false));
		},
		
		/**
		 * Load user data
		 * @param {string} sUserId user ID
		 * @returns {Promise} promise
		 * @function
		 * @private
		 */
		_loadUserData: function (sUserId) {
			var oParams = {};
			
			if (this._isAuthorizationRequest()) {
				oParams.urlParameters = {
					"$expand": "UserAuthObjectSet"
				};
			}
			
			return Util.promiseRead.call(this, Util.formatMessage("/UserSet(''{0}'')", [sUserId]), oParams);
		},
		
		/**
		 * Load Requested object data
		 * @returns {Promise} promise
		 * @function
		 * @private
		 */
		_loadRequestedObjectData: function () {
			if (!this._getSettings().isRequestedAuthObjectEnabled) {
				return;
			}
			var oParams = {
				filters: [new sap.ui.model.Filter("RequestId", sap.ui.model.FilterOperator.EQ, this._getViewProperty("RequestId"))]
			};
			
			if (this._isExpiryRequest() || this._getViewProperty("Status") !== "A") {
				return [];
			}
			
			return Util.promiseRead.call(this, "/RequestedAuthObjectSet", oParams);
		},
		
		
		/**
		 * Process Request's backend data
		 * @param {object} oData data
		 * @returns {string} request's user ID
		 * @function
		 * @private
		 */
		_processRequestData: function (oData) {
			var oRequest = (oData.results && oData.results[0]) || {},
				bIsOpenRequest = this.formatter.request.isOpenRequest(oRequest.Status);
			
			this._setTypeOfRequest(oRequest.TypeOfRequest);
			
			this._setViewProperty(PROP_ACCEPTABLE, false);
			this._setViewProperty("ChangedOn", oRequest.ChangedAt);
			this._setViewProperty("ChangedBy", oRequest.ChangedBy);
			this._setViewProperty("CreatedOn", oRequest.CreatedAt);
			this._setViewProperty("Desc", oRequest.Description);
			this._setViewProperty("Status", oRequest.Status);
			this._setViewProperty("System", oRequest.SrcSys);
			this._setViewProperty("UserId", oRequest.UserId);
			this._setViewProperty("RejectReason", oRequest.RejectReason);
			this._setViewProperty("ApplName", oRequest.ApplName);
			
			if (this._isAuthorizationRequest()) {
				this._setViewProperty("App", oRequest.TileId);
				this._setViewProperty(PROP_LIST, this._getAuthObjList(oRequest.AuthObjId));
				// this._setViewProperty("RequestedLevels", this._getAuthObjList(oRequest.AuthObjId));
			} else if (this._isExpiryRequest()) {
				 // No date restrictions for closed request
				 // today + N yrs for open request
				var oDate = new Date(),
					oMinDate = bIsOpenRequest ? Util.date.getMinExpiryDate() : null,
					oPreFilledDate = bIsOpenRequest ? Util.date.shiftDate(oDate, this._getSettings().prefilledYearsForUserExtension) : null,
					oMaxDate = bIsOpenRequest ? Util.date.shiftDate(oDate, this._getSettings().maxYearsForUserExtension) : null,
					oExpDate = oRequest.ExpDate;
					
				if (!bIsOpenRequest && oExpDate && oExpDate.getFullYear() < 1972) { // backend can give 1971 year date instead of null one
					oExpDate = null;
				}
				
				this._setViewProperty(PROP_MINIMAL_EXPIRY_DATE, oMinDate);
				this._setViewProperty(PROP_MAXIMUM_EXPIRY_DATE, oMaxDate); // N yrs after today
				this._setViewProperty(PROP_PREFILLED_EXPIRY_DATE, oPreFilledDate);
				this._setViewProperty(PROP_SELECTED_EXPIRY_DATE, bIsOpenRequest ? oPreFilledDate : oExpDate);
				this._setViewProperty(PROP_ACCEPTABLE, !!bIsOpenRequest);
			}
			
			return oRequest.UserId;
		},
		
		/**
		 * Process Request User's backend data
		 * @param {object} oData data
		 * @function
		 * @private
		 */
		_processUserData: function (oData) {
			var oUserInfo = oData || {},
				aUsersAuthorizationList = oUserInfo.UserAuthObjectSet && oUserInfo.UserAuthObjectSet.results || [];
			
			this._setViewProperty("Auth/User", oUserInfo);
			
			if (this._isAuthorizationRequest()) {
				this._updateAuthorizationStatuses(aUsersAuthorizationList);
			}
		},
		
		/**
		 * Process Requested object data
		 * @param {object} oData data
		 * @function
		 * @private
		 */
		_processRequestedObjectData: function (oData) {
			if (!this._getSettings().isRequestedAuthObjectEnabled) {
				return;
			}
			var aRequestedList = oData.results || [],
			aObjectIds = aRequestedList.reduce(function (arr, curItem) {
				if (arr.indexOf(curItem.ObjectId) === -1) {
					arr.push(curItem.ObjectId);
				}
				return arr;
			}, []),
			aAuthsList = aObjectIds.map(function (sId) {
				var aList = aRequestedList.filter(function (oAuth) {
					return oAuth.ObjectId === sId;
				}),
				oRes = {},
				aFullAuths = aList.filter(function (oAuth) {
					return oAuth.Value === "";
				});
				if (aFullAuths.length) {
					oRes = Util.deepCopy(aFullAuths[0]);
					oRes.CurrentAuthLevel = "full";
					oRes.TempCurrentAuthLevel = "full";
					return oRes;
				}
				aList = aList.filter(function (oAuth) {
					return oAuth.Value !== "";
				}).sort(function (a, b) {
					if (a.AuthLevelId === Constant.AuthLevelId.DEBITOR) {
						return 1;
					} else if (a.AuthLevelId === Constant.AuthLevelId.INSTALL) {
						return (b.AuthLevelId === Constant.AuthLevelId.DEBITOR) ? -1 : 1;
					} else if (a.AuthLevelId === Constant.AuthLevelId.USER) {
						return -1;
					}
					return 1;
				});
				oRes = Util.deepCopy(aList[0]);
				oRes.CurrentAuthLevel = "restricted";
				oRes.TempCurrentAuthLevel = "restricted";
				return oRes;
			});
			
			if (aAuthsList.length && this._isAuthorizationRequest() && this._getViewProperty("Status") === "A") {
				this._updateAuthorizationStatuses(aAuthsList);
			}
		},
		
		/**
		 * Accept expiry request
		 * @function
		 * @private
		 */
		_saveExpiryRequest: function () {
			var sRequestId = this._getViewProperty("RequestId"),
				sTypeOfRequest = this._getViewProperty(PROP_TYPE_OF_REQUEST),
				sUserId = this._getViewProperty("UserId"),
				oExpirationDate = Util.date.dateToUTCDate(this._getViewProperty(PROP_SELECTED_EXPIRY_DATE)),
				oModel = this.getModel(),
				oExtensionRequestParams = {
					method: "GET",
					urlParameters: {
						UserIds: sUserId,
						ExpDat: oExpirationDate
					},
					refreshAfterChange: true
				},
				oAuthRequestEntry = {
					Status: "A",
					TypeOfRequest: sTypeOfRequest,
					ExpDate: oExpirationDate
				};
				
			this.setBusy(true);
			oModel.setUseBatch(true);
			Util.promiseCallFunction.call(this, "/ExtendUserDate", oExtensionRequestParams, oModel)
				.then(function () {
					oModel.setUseBatch(false);
					Util.promiseUpdate.call(this, "/AuthorizationRequestSet('" + sRequestId + "')", oAuthRequestEntry);
				}.bind(this))
				.then(function () {
					sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_EXPIRY_DATE_APPROVED"), {
						closeOnBrowserNavigation: false
					});
				}.bind(this))
				.catch(function (oError) {
					Util.JSONError.showToast(oError);
				})
				.finally(function () {
					oModel.setUseBatch(false);
					this.setBusy(false);
					this._triggerBusEventMaster("tasksTableRefresh");
					this.getRouter().navTo("UA_main", {
						tab: "Tasks"
					});
				}.bind(this));
		},

		/**
		 * Update single authorization in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oAuth authorization to update
		 * @returns {int} saving requests count
		 * @function
		 * @private
		 */
		_saveSingleAuth: function (sGroupId, oModel, oAuth) {
			var iSaved = 0;
			
			if (!/^G_/.test(oAuth.ObjectId)) { // Skip group items
				if (!oAuth.TempSelected || oAuth.TempCurrentAuthLevel === Constant.AuthLevel.FULL) { // top level auth
					var sPath = jQuery.sap.formatMessage("/AuthObjectSet(UserId=''{0}'',ObjectId=''{1}'')", [oAuth.UserId, oAuth.ObjectId]),
						oData = jQuery.extend(true, {}, oModel.getProperty(sPath));
					oData.Selected = oAuth.TempSelected;
					delete oData.AuthObjectAuthLevelSet; // because {__list: [...]} causes an error
					oModel.update(sPath, oData, {
						batchGroupId: sGroupId
					});
					iSaved++;
				} else if (oAuth.TempChanges) {
					if (oAuth.Customers && this.formatter.detail.isAuthTopLevelCCC(oAuth.TopLevel)) {
						oAuth.Customers.map(function (oCust) {
							return jQuery.extend({}, oCust, {
								AuthLevelType: "DEBITOR"
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
						iSaved += oAuth.Customers.length;
					}
					if (oAuth.Installations && this.formatter.detail.isInstallationsTableVisible(oAuth.AuthLevelId)) {
						oAuth.Installations.map(function (oInst) {
							return jQuery.extend({}, oInst, {
								AuthLevelType: oAuth.AuthLevelId
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
						iSaved += oAuth.Installations.length;
					}
					if (oAuth.Clusters) {
						oAuth.Clusters.map(function (oClust) {
							return jQuery.extend({}, oClust, {
								AuthLevel: oClust.AuthLevelDesc,
								AuthLevelType: oClust.AuthLevelDesc
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
						iSaved += oAuth.Clusters.length;
					}
				}
			}
			
			return iSaved;
		},

		/**
		 * Update single authorization level in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oLevel level
		 * @function
		 * @private
		 */
		_saveSingleAuthLevel: function (sGroupId, oModel, oLevel) {
			var sPath = jQuery.sap.formatMessage("/AuthObjectLevelSet(UserId=''{0}'',ObjectId=''{1}'',AuthLevel=''{2}'',AuthLevelType=''{3}'')", [
					oLevel.UserId, oLevel.ObjectId, oLevel.AuthLevel, oLevel.AuthLevelType
				]),
				oData = jQuery.extend(true, {
					AuthLevel: oLevel.AuthLevel,
					AuthLevelType: oLevel.AuthLevelType,
					ObjectId: oLevel.ObjectId,
					UserId: oLevel.UserId
				}, oModel.getProperty(sPath));

			oData.IsAssigned = true;
			oModel.update(sPath, oData, {
				batchGroupId: sGroupId
			});
		},
		
		/**
		 * Set edit mode
		 * @param {boolean} bEditMode edit mode
		 * @function
		 * @private
		 */
		_setEditMode: function (bEditMode) {
			this._setViewProperty(PROP_EDIT, !!bEditMode);
		},
		
		/**
		 * Set acceptable state for Requested authorization
		 * @param {object} oRequestedAuth Requested authorization
		 * @function
		 * @private
		 */
		_setAcceptableState: function (oRequestedAuth) {
			var sCurrentLevel = oRequestedAuth.TempCurrentAuthLevel;
			
			oRequestedAuth.Acceptable = this.formatter.detail.isAuthorizationSelected(sCurrentLevel);
		},
		
		/**
		 * Set type of current request
		 * @param {string} sTypeOfRequest type of request
		 * @function
		 * @private
		 */
		_setTypeOfRequest: function (sTypeOfRequest) {
			this._setViewProperty(PROP_TYPE_OF_REQUEST, sTypeOfRequest);
			
			this._setViewProperty(PROP_IS_AUTH_REQUEST, sTypeOfRequest === TypeOfRequest.AUTHORIZATION);
			this._setViewProperty(PROP_IS_EXPIRY_REQUEST, sTypeOfRequest === TypeOfRequest.EXPIRY_DATE);
		},

		/**
		 * Update authorization list local changes (made without setProperty)
		 * @function
		 * @private
		 */
		_updateAuthorizationListChanges: function () {
			var aList = this._getAuthorizationList() || [];
			
			aList.forEach(this._setAcceptableState.bind(this));
			
			this._setViewProperty(PROP_LIST, aList);
			this._setViewProperty(PROP_ACCEPTABLE, !aList.some(function (oItem) {
				return !oItem.Acceptable;
			})); 
		},
		
		/**
		 * Update statuses of requested authorizations
		 * @param {object[]} aUsersAuthorizations user's current authorizations
		 * @function
		 * @private
		 */
		_updateAuthorizationStatuses: function (aUsersAuthorizations) {
			var aRequestedAuthorizations = this._getViewProperty(PROP_LIST),
				oUsersAuthorizationsByObjectId = Util.mapBy(aUsersAuthorizations, "ObjectId");
				
			aRequestedAuthorizations.forEach(function (oRequestedAuth) {
				var sAuthId = oRequestedAuth.RequestAuthObjId,
					oCurrentAuth = oUsersAuthorizationsByObjectId[sAuthId];
					
				if (oCurrentAuth) {
					Util.merge(oRequestedAuth, this._extendAuthorizationObject(oCurrentAuth));
				}
			}.bind(this));
			
			this._updateAuthorizationListChanges();
		},
		
		/**
		 * Navigate to current user's detail page
		 * @ui5ignore
		 * @event
		 * @public
		 */
		navToUserDetail: function () {
			var sUserId = this._getUserId();
			
			this.getRouter().navTo(USER_DETAIL_VIEW_ROUTE, {
				"user_id": sUserId
			}, false);
		},
		
		/**
		 * Accept request
		 * @event
		 * @public
		 */
		onAcceptRequest: function () {
			this._setEditMode(false);
			if (this._isAuthorizationRequest()) {
				this.onSaveAuthorizations();
			} else if (this._isExpiryRequest()) {
				this._saveExpiryRequest();
			}
		},
		
		onCancelRequest: function() {
			this.getRouter().navTo("UA_main", {
    			tab: "Tasks"
    		});
		},
		
		onAuthorizationObjectPress: function (oEvent) {
			var oAuth = oEvent.getSource().getBindingContext("view").getObject();
			this._setViewProperty("Auth/Detail", oAuth);
			this._setEditMode((this._getViewProperty("Status") === "O"));
			var UserId = this._getViewProperty("UserId");
			var RequestId = this._getViewProperty("RequestId");
			this.getRouter().navTo(REQUEST_AUTH_ASSIGN_ROUTE, {
					user: UserId,
					object: oAuth.RequestAuthObjId,
					requestId: RequestId
				}, /* bReplace= */ false);
		},
		
		/**
		 * Handle expiry date change on user interaction
		 * Update acceptable state
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onExpiryDateChange: function (oEvent) {
			var bValid = oEvent.getParameter("valid");
			
			// KNGMHM02-19883 Removed "date over range check"
			/*if (!bValid) {
				var oDatePicker = oEvent.getSource(),
					sInputValue = oEvent.getParameter("newValue"),
					bIsDateValid = !!oDatePicker._parseValue(sInputValue);
				this._setViewProperty(PROP_IS_EXPIRY_DATE_OVER_RANGE, bIsDateValid);
			}*/
			
			this._setViewProperty(PROP_IS_EXPIRY_DATE_INVALID, !bValid);
			this._setViewProperty(PROP_ACCEPTABLE, !!(bValid && this._getViewProperty(PROP_SELECTED_EXPIRY_DATE)));
		},
		
		/**
		 * Reject request
		 * @event
		 * @public
		 */
		onRejectRequest: function () {
			var sRequestId = this._getViewProperty("RequestId"),
				sTypeOfRequest = this._getViewProperty(PROP_TYPE_OF_REQUEST),
				oPrefilledExpiryDate = this._getViewProperty(PROP_PREFILLED_EXPIRY_DATE);
				
			this._setEditMode(false);
			this._oDialogs.getDialogAndReset("RejectRequest")
				.setRequestData(sRequestId, sTypeOfRequest, oPrefilledExpiryDate).open();
		},
		
		_saveRequestedAuths: function(sGroupId, oModel, oAuth) {
			var isSaved = false,
				sRequestId = this._getViewProperty("RequestId"),
				sPath = "/RequestedAuthObjectSet",
				oData = {
					RequestId: sRequestId,
					ObjectId: oAuth.ObjectId,
					AuthLevelId: oAuth.AuthLevelId,
					ObjectDesc: oAuth.ObjectDesc,
					AuthLevelDesc: oAuth.AuthLevelDesc
				};

			if (!/^G_/.test(oAuth.ObjectId)) {
				if (!oAuth.TempSelected || oAuth.TempCurrentAuthLevel === Constant.AuthLevel.FULL) {
					var oFullData = Util.deepCopy(oData);
					oFullData.Value = "";
					oModel.create(sPath, oFullData, {
						batchGroupId: sGroupId
					});
					isSaved = true;
				} else if (oAuth.TempChanges) {
					if (oAuth.Customers && this.formatter.detail.isAuthTopLevelCCC(oAuth.TopLevel)) {
						oAuth.Customers.forEach(function(oCust) {
							var oCustData = Util.deepCopy(oData);
							oCustData.Value = oCust.AuthLevel;
							oModel.create(sPath, oCustData, {
								batchGroupId: sGroupId
							});
						}.bind(this));
						isSaved = true;
					}
					if (oAuth.Installations && this.formatter.detail.isInstallationsTableVisible(oAuth.AuthLevelId)) {
						oAuth.Installations.forEach(function(oInst) {
							var oInstData = Util.deepCopy(oData);
							oInstData.Value = oInst.AuthLevel;
							oModel.create(sPath, oInstData, {
								batchGroupId: sGroupId
							});
						}.bind(this));
						isSaved = true;
					}
				}
			}

			return isSaved;
		},
		
		/**
		 * Save changes in authorizations
		 * @event
		 * @private
		 */
		onSaveAuthorizations: function () {
			var sBatchGroupId = "idUserAuthObjAssignGroup",
				sRequestedObjectBatchGroupId = "idRequestedObjGroup",
				oModel = this.getModel(),
				sRequestId = this._getViewProperty("RequestId"),
				sTypeOfRequest = this._getViewProperty(PROP_TYPE_OF_REQUEST);
				
			this.setBusy(true);

			oModel.setUseBatch(true);
			oModel.setDeferredBatchGroups([sBatchGroupId, sRequestedObjectBatchGroupId]);
			var aSavedAuths = this._getAuthorizationList().filter(this._saveSingleAuth.bind(this, sBatchGroupId, oModel)),
				oSavePromise = aSavedAuths.length ? Util.promiseSubmitChanges.call(this, {batchGroupId: sBatchGroupId}) : Promise.resolve();
			
			oSavePromise.then(function (oData) {
				if (!oData || (Util.getBatchMessage(oData) !== Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData))) {
					return Util.promiseUpdate.call(this, "/AuthorizationRequestSet('" + sRequestId + "')", {
						TypeOfRequest: sTypeOfRequest,
						Status: "A"
					}).then(function () {
						sap.m.MessageToast.show(this.getBundle().getText("MESSAGE_AUTH_REQ_ACCEPTED"), {
							closeOnBrowserNavigation: false
						});
						
						this.setBusy(false);
						oModel.setUseBatch(false);
						this._triggerBusEventMaster("tasksTableRefresh");
						this.getRouter().navTo("UA_main", {
							tab: "Tasks"
						});
					}.bind(this));
				}
				return null;
			}.bind(this))
			.then(function (oData) {
				if (!this._getSettings().isRequestedAuthObjectEnabled) {
					return oData;
				}
				if (!oData || (Util.getBatchMessage(oData) !== Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(oData))) {
					var aRequestedAuths = this._getAuthorizationList().filter(this._saveRequestedAuths.bind(this, sRequestedObjectBatchGroupId, oModel));
					return aRequestedAuths.length ? Util.promiseSubmitChanges.call(this, {batchGroupId: sRequestedObjectBatchGroupId}) : Promise.resolve();
				}
				return oData;
			}.bind(this))
			.catch(function (oError) {
				Util.JSONError.showToast(oError);
			})
			.finally(function () {
				this.setBusy(false);
				oModel.setUseBatch(false);
			}.bind(this));
		}
	});
});
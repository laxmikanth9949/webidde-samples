sap.ui.define([
	"sap/support/useradministration/controller/BaseController",
	"sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/extended/enums/CloudAuthorizationLevel",
	"sap/support/useradministration/util/Util"
], function(Controller, Dialogs, CloudAuthorizationLevel, Util) {
	var MODEL = "ca",
		DETAIL = "Cloud/Detail/",
		LEVEL_INSTALL = "Install",
		LEVEL_TENANT = "Tenant",
		LEVEL_PROD = "Prod",
		ROUTE = "userCloudAuthorizationAssign";
		
	/**
	 * Controller for detailed cloud authorization assigning
	 * @extends sap.support.useradministration.controller.BaseController
	 * @alias sap.support.useradministration.controller.UserCloudAuthorizationAssign
	 */
	return Controller.extend("sap.support.useradministration.controller.UserCloudAuthorizationAssign", {
		_sAuthObject: null,
		_sUserId: null,
		
		/**
		 * Init controller
		 * Attach events and bind view
		 * @function
		 * @public
		 */
		onInit: function() {
			this.getRouter().attachRouteMatched(this._handleRouteMatched, this);

			this._aLevels = [CloudAuthorizationLevel.Product, CloudAuthorizationLevel.Installation, CloudAuthorizationLevel.Tenant];
			this._oDialogs = new Dialogs(this);
			this._bindViewModel("UserDetail");
		},

		/**
		 * Update bindings on opening cloud assign details
		 * @param {sap.ui.base.Event} oEvent event data
		 * @event
		 * @private
		 */
		_handleRouteMatched: function(oEvent) {
			this._sCurrentRoute = oEvent.getParameter("name");
			if (this._sCurrentRoute === ROUTE) {
				var oDetail = this._getObject();
				
				if (oDetail && oDetail.AuthObject) {
					if (this._isEditMode() && oDetail._Prods && this._sAuthObject === oDetail.AuthObject && this._sUserId === oDetail.Userid) {
						// Edit mode, levels are loaded and object is the same
						this._resetAuthDetails();
					} else  {
						this._sAuthObject = oDetail.AuthObject;
						this._sUserId = oDetail.Userid;
						this._loadAuthDetails();
					}
				}
			}
		},

		/**
		 * Attach EventBus event
		 * @param {string} sEventName event name
		 * @param {function} fnHander event handler
		 * @function
		 * @private
		 */
		_attachBusEvent: function(sEventName, fnHander) {
			this.getOwnerComponent().getEventBus().subscribe("UserDetail", sEventName, fnHander);
		},
		
		/**
		 * Get property name for level
		 * @param {string} sLevel level name - "Tenant", "Install" or "Prod"
		 * @param {boolean} bVisible if we need visibility property
		 * @returns {string} property name
		 * @function
		 * @private
		 */
		_getLevelPropertyName: function (sLevel, bVisible) {
			switch (sLevel) {
				case LEVEL_INSTALL:
					return bVisible ? "_InstallsVisible" : "_Installs";
				case LEVEL_PROD:
					return bVisible ? "_ProdsVisible" : "_Prods";
				case LEVEL_TENANT:
					return bVisible ? "_TenantsVisible" : "_Tenants";
				default:
					return Util.formatMessage(bVisible ? "_{0}sVisible" : "_{0}s", [sLevel]);
			}	
		},
		
		/**
		 * Get backend set name for level
		 * @param {string} sLevel level name - "Tenant", "Install" or "Prod"
		 * @returns {string} set name
		 * @function
		 * @private
		 */
		_getLevelSetName: function (sLevel) {
			switch (sLevel) {
				case LEVEL_INSTALL:
					return "/xSVTxC_InstallAuthAssign";
				case LEVEL_PROD:
					return "/xSVTxC_ProdAuthAssign";
				case LEVEL_TENANT:
					return "/xSVTxC_TenantAuthAssign";
				default:
					return Util.formatMessage("/xSVTxC_{0}AuthAssign", [sLevel]);
			}	
		},
		
		/**
		 * Get cloud auth object
		 * @returns {object} cloud auth
		 * @function
		 * @private
		 */
		_getObject: function() {
			return this._getViewProperty(DETAIL) || {};
		},
		
		/**
		 * Check edit mode
		 * @returns {boolean} check result
		 * @function
		 * @private
		 */
		_isEditMode: function() {
			return Boolean(this._getViewProperty("Cloud/Edit"));
		},

		/**
		 * Load cloud auth details
		 * @function
		 * @private
		 */
		_loadAuthDetails: function() {
			this.setBusy(true);
			this._loadLevels()
				.finally(this.setBusy.bind(this, false));
		},
		
		/**
		 * Load any level by its name "Tenant", "Install" or "Prod"
		 * @param {string} sName level name
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_loadLevel: function(sName) {
		    var oDetail = this._getObject(),
		    	sProperty = this._getLevelPropertyName(sName),
		    	sVisibleProperty = this._getLevelPropertyName(sName, true);
		    	
		    if (oDetail && !oDetail[sProperty] && oDetail[sVisibleProperty]) {
		    	var sPath = Util.formatMessage(this._getLevelSetName() + "(sUser=''{1}'',authObject=''{2}'')/Set",
		    		[sName, oDetail.Userid, oDetail.AuthObject]);
    			return Util.promiseRead.call(this, sPath, {}, MODEL)
    				.then(this._resetLevel.bind(this, sName))
    				.catch(this._resetLevel.bind(this, sName, {
    					results: []
    				}));
		    } else {
		        return Promise.resolve();
		    }
		},
		
		/**
		 * Load all levels
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_loadLevels: function() {
			return Promise.all(this._aLevels.map(this._loadLevel.bind(this)));
		},

		/**
		 * Reset cloud auth details
		 * @function
		 * @private
		 */
		_resetAuthDetails: function() {
			this._aLevels.forEach(this._resetLevel.bind(this));
		},

		/**
		 * Reset cloud auth level
		 * @param {sap.support.useradministration.extended.enums.CloudAuthorizationLevel} sLevel level
		 * @param {object} oData backend response to get tenants
		 * @function
		 * @private
		 */
		_resetLevel: function(sLevel, oData) {
			var oDetail = this._getObject(),
				sProperty = "_" + sLevel + "s",
				aList = oData && oData.results || oDetail[sProperty];

			if (oDetail) {
				this._setViewProperty(DETAIL + sProperty, aList || []);
			}
		},
		
		/**
		 * Trigger EventBus event
		 * @param {string} sEventName event name
		 * @function
		 * @private
		 */
		_triggerBusEvent: function(sEventName) {
			this.getOwnerComponent().getEventBus().publish("UserDetail", sEventName);
		},

		/**
		 * Edit restricted installations list
		 * @event
		 * @public
		 */
		onEditInstallations: function() {
			var oDialog = this._oDialogs.getDialog("SelectRestrictedCloudInstallations"),
				oDetail = this._getObject() || {};
			oDialog.updateTokens(oDetail._Installs || []);
			oDialog.setContext(oDetail.Userid, oDetail.AuthObject);
			oDialog.open();
		},
		
		/**
		 * Edit restricted tenants list
		 * @event
		 * @public
		 */
		onEditProducts: function() {
			var oDialog = this._oDialogs.getDialog("SelectRestrictedCloudProducts"),
				oDetail = this._getObject() || {};
			oDialog.updateTokens(oDetail._Prods || []);
			oDialog.setContext(oDetail.Userid, oDetail.AuthObject);
			oDialog.open();
		},
		
		/**
		 * Edit restricted tenants list
		 * @event
		 * @public
		 */
		onEditTenants: function() {
			var oDialog = this._oDialogs.getDialog("SelectRestrictedCloudTenants"),
				oDetail = this._getObject() || {};
			oDialog.updateTokens(oDetail._Tenants || []);
			oDialog.setContext(oDetail.Userid, oDetail.AuthObject);
			oDialog.open();
		},

		/**
		 * Save items of any level from F4 help dialog
		 * @param {sap.support.useradministration.extended.enums.CloudAuthorizationLevel} sLevel level
		 * @param {object[]} aItems items
		 * @function
		 * @public
		 */
		saveLevel: function(sLevel, aItems) {
			this._setViewProperty(DETAIL + this._getLevelPropertyName(sLevel), aItems || []);
			this._triggerBusEvent("cloudAuthDetailsChange");
		}
	});
});
sap.ui.define([
	"sap/support/useradministration/controller/BaseController",
	"sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/util/Settings",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	"sap/m/Link",
	"sap/support/usermanagmentcustomlib/userheader/util/EmailValidator",
	"./mixins/RequestUserValidationMessages.mixin"
], function (BaseController, Dialogs, Constant, Util, Settings, MessagePopover, MessageItem, Link, EmailValidator, RUVM) {
	"use strict";

	var History = sap.ui.core.routing.History;

	var REQUEST_USER_ROUTE = "requestUser";
	return BaseController.extend("sap.support.useradministration.view.RequestUser", $.extend({}, RUVM, {
		_oHistory: History.getInstance(),

		onInit: function () {
			this._oDialogs = new Dialogs(this);
			this.getRouter().getRoute(REQUEST_USER_ROUTE).attachPatternMatched(this._onRouteMatched, this);
			this._bindViewModel("RequestUser");
		},

		onBeforeRendering: function () {
			var oView = this.getView();
			var oModel = oView.getModel();

			oModel.read("/LogonUserInfoSet", {
				success: function (oData, oResponse) {
					this._setViewProperty("IsShowNotes",
						(oResponse.data.results[0].Function === "1SUPERADMIN" ||
						oResponse.data.results[0].Function === "1SUPERADMIN_CLOUD") &&
						Settings.isAdditionalNoteEnabled);
				}.bind(this),
				error: function (oError) {
					jQuery.sap.log.error("LogonUserInfoSet loading Error: " + oError.message);
				}
			});
		},

		_onRouteMatched: function () {
			this._refreshInputs();
		},

		/**
		 * Trigger EventBus event
		 * @param {string} sEventName event name
		 * @function
		 * @private
		 */
		_triggerBusEvent: function (sEventName) {
			this.getOwnerComponent().getEventBus().publish("Master", sEventName);
		},

		_refreshInputs: function(){
			var 
				oDate = new Date(),
				defaultExpityDate = Util.date.shiftDate(oDate, Settings.prefilledYearsForUserCreation, 0, 0),
				domainSelectorUserAdmin = this.getView().byId("domainSelectorUserAdmin"),
				domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");

			this._initializeViewProperties()
				._initInitialValuesForProperties("INIT_DATE_PROPS", defaultExpityDate);

			this._setViewProperty("SalutationKey", "Mr");
			this._setViewProperty("LanguageCode", Util.getSAPLogonLanguage());
			this._setViewProperty("MinExpiryDate", Util.date.getMinExpiryDate(Util.date.shiftDate(oDate, 0, 0, 1)));
			this._setViewProperty("MaxExpiryDate", Util.date.shiftDate(oDate, Settings.maxYearsForUserCreation, 0, 0));
			this._setViewProperty("ValidationEmailText", Util.getText("MESSAGE_EMAIL_INVALID"));
			this._setViewProperty("Validation", this._createInitValidationState());
			this._setViewProperty("IsSuperAdmin", this.getView().getModel("app").getProperty("/IsSuperAdmin"));
			this._setViewProperty("IsDomainCheckEnabled", this.getModel("appSettings").getData().domainCheckActive);
			
			domainSelectorSuperCloudAdmin.setValue("");

			this._addOnFocusHandler();
			
			this._initDomainCheckFunctions();

			if(this._getViewProperty("IsSuperAdmin") && domainSelectorUserAdmin) {
				domainSelectorUserAdmin.destroy();
			} else if (domainSelectorSuperCloudAdmin){
				domainSelectorSuperCloudAdmin.destroy();
			}
		},

		_initDomainCheckFunctions: function() {
			if (this._getViewProperty("IsDomainCheckEnabled")) {
				this._checkAnyDomainsAllowedAllCustomers();
				this._removeUserAdminDomainSelectorIfNotNeeded();
				this._removeSuperCloudAdminSelectorIfNotNeeded();
				this._removeTitle();
			}
		},

		// _refreshInputs: function () {
		// 	this._setViewProperty("submitEnabled", false);	
		// 	var oDate = new Date(),
		// 		defaultExpityDate = Util.date.shiftDate(oDate, Settings.prefilledYearsForUserCreation, 0, 0);
		// 	var domainSelectorUserAdmin = this.getView().byId("domainSelectorUserAdmin");
		// 	var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");

		// 	this._setViewProperty("CustomerNumber", "");
		// 	this._setViewProperty("CustomerText", "");
		// 	this._setViewProperty("SalutationKey", "Mr");
		// 	this._setViewProperty("FirstName", "");
		// 	this._setViewProperty("LastName", "");
		// 	this._setViewProperty("Email", "");
		// 	this._setViewProperty("Notes", "");
		// 	this._setViewProperty("LanguageCode", Util.getSAPLogonLanguage());
		// 	this._setViewProperty("Department", "");
		// 	this._setViewProperty("DepartmentId", "");
		// 	this._setViewProperty("APs", []);
		// 	this._setViewProperty("MinExpiryDate", Util.date.getMinExpiryDate(Util.date.shiftDate(oDate, 0, 0, 1)));
		// 	this._setViewProperty("MaxExpiryDate", Util.date.shiftDate(oDate, Settings.maxYearsForUserCreation, 0, 0));
		// 	this._setViewProperty("DefaultExpiryDate", defaultExpityDate);
		// 	this._setViewProperty("SelectedExpiryDate", defaultExpityDate);
		// 	this._setViewProperty("ValidationEmailText", Util.getText("MESSAGE_EMAIL_INVALID"));
		// 	this._setViewProperty("EmailLocalPart", "");
		// 	this._setViewProperty("EmailInputValueState", sap.ui.core.ValueState.None);
		// 	this._setViewProperty("Validation", this._createInitValidationState());
		// 	this._setViewProperty("Errors", []);
		// 	this._setViewProperty("DuplicateUsers", []);
		// 	this._setViewProperty("IsSuperAdmin", this.getView().getModel("app").getProperty("/IsSuperAdmin"));
		// 	this._setViewProperty("IsDomainCheckEnabled", this.getModel("appSettings").getData().domainCheckActive);
		// 	this._setViewProperty("NoAllowedDomainsPresent", true);
		// 	this._setViewProperty("AllowedDomainsList", []);
		// 	this._setViewProperty("NamePartOfEmail", "");
		// 	this._setViewProperty("DomainPartOfEmail", "");
		// 	this._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
		// 	this._setViewProperty("emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
		// 	this._setViewProperty("valueStateForNotesArea", sap.ui.core.ValueState.None);
		// 	this._setViewProperty("EmailValueState", sap.ui.core.ValueState.None);
		// 	domainSelectorSuperCloudAdmin.setValue("");
		// 	this._addOnFocusHandler();
			
		// 	if (this._getViewProperty("IsDomainCheckEnabled")) {
		// 		this._checkAnyDomainsAllowedAllCustomers();
		// 		this._removeUserAdminDomainSelectorIfNotNeeded();
		// 		this._removeSuperCloudAdminSelectorIfNotNeeded();
		// 		this._removeTitle();
		// 	}

		// 	if(this._getViewProperty("IsSuperAdmin")) {
		// 		if(domainSelectorUserAdmin) {
		// 			domainSelectorUserAdmin.destroy();
		// 		}
		// 	}

 		// 	if(!this._getViewProperty("IsSuperAdmin")) {
		// 		if(domainSelectorSuperCloudAdmin) {
		// 			domainSelectorSuperCloudAdmin.destroy();
		// 		}
		// 	}
		// },

		_initializeViewProperties: function(){
			Constant.INITIAL_PROPS.forEach(function(area){
				this._initInitialValuesForProperties(area.block, area.defValue);
			}.bind(this));

			return this;
		},

		_initInitialValuesForProperties: function(blockName, defValue){
			Constant[blockName].forEach(function(path){
				this._setViewProperty(path, defValue);
			}.bind(this));

			return this;
		},

		_createInitValidationState: function(){
			return Object.assign({}, Constant.INIT_VALIDATION_STATE);
		},

		/**
		 * Add event listeners in _refreshInputs function to prevent multiple click issue
		 */
		_addOnFocusHandler: function () {
			var that = this;
			var oEmailNamePartInput = this.getView().byId("namePartOfEmail");
			var domainSelectorUserAdmin = this.getView().byId("domainSelectorUserAdmin");
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");

			oEmailNamePartInput.addEventDelegate({
				onsapfocusleave : function () {
					if(that._getViewProperty("emailDomainSuperCloudAdminValueState") == "Information") {
						that._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
					}
				}
			});

			domainSelectorSuperCloudAdmin.addEventDelegate({
				onfocusin : function() {
					if(that._getViewProperty("emailDomainSuperCloudAdminValueState") == "None") {
						that._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Information);
					}					
					if(!domainSelectorSuperCloudAdmin.isOpen()) {
						that._validateDomainSuperCloudAdmin();
					}
				}.bind(this)
			});

			domainSelectorSuperCloudAdmin.addEventDelegate({
				onsapfocusleave : function() {
					if(!domainSelectorSuperCloudAdmin.isOpen() && that._getViewProperty("emailDomainSuperCloudAdminValueState") == "Information") {
						that._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.None);
					}
				}.bind(this)
			});

			domainSelectorUserAdmin.addEventDelegate({
				onfocusin : function() {
					if(!domainSelectorUserAdmin.isOpen()){
						that._validateDomainUserAdmin();
					}
				}.bind(this)
			});
		},
		
		_ifOnlyOneCustomerThenSelectItAutomatically: function () {
			if (this._aCustomerList.length == 1) {
				this.setCustomer(
					this._aCustomerList[0].Kunnr, this._aCustomerList[0].Name1);
			}
		},

		_removeUserAdminDomainSelectorIfNotNeeded: function () {
			// if user is Super/Cloud admin domain selector for User Admin will be deleted in controller _refreshInputs
			// usually we don't need to delete controls that we don't need, we just set them invisible
			// but layout of sap.ui.layout.form.SimpleForm breaks if it has invisible element, therefore we explicitly delete it here
			if (this._getViewProperty("IsSuperAdmin")) {
				this.getView().byId("domainSelectorUserAdmin").destroy();
			}
		},

		_removeSuperCloudAdminSelectorIfNotNeeded: function () {
			if (!this._getViewProperty("IsSuperAdmin")) {
				this.getView().byId("domainSelectorSuperCloudAdmin").destroy();
			}
		},	

		_removeTitle: function () {
			var titlePersonal = this.getView().byId("titlePersonal");
			var titleCompany = this.getView().byId("titleCompany");
			titlePersonal.destroy();
			titleCompany.destroy();

			if (!this._getViewProperty("IsSuperAdmin")) {
				var titleEmailNote = this.getView().byId("titleEmailNote");
				titleEmailNote.destroy();
			}
		},
		
		_checkAnyDomainsAllowedAllCustomers: function () {
			// this is needed by utils library to get the list of domains
			this.oDataDomain = this.getOwnerComponent().getModel("domains");
			// this.oDataDomain = new sap.ui.model.odata.v2.ODataModel('/services/odata/emaildomain/', {json: true});
			Util.promiseRead.call(this, "/CustomerSet")
				.then(function (oData) {
					this._aCustomerList = oData.results.slice();
					var promisesArray = [];
					var domainsArray = [];
					this._aCustomerList.forEach(function (item, index) {
					  promisesArray.push(
							EmailValidator.getDomainList.call(this, item.Kunnr)
						);
					}.bind(this));
					Promise.all(promisesArray).then(function (values) {
					  var domains = values.flat(1);
						// domains = []; //code for testing: no domains all customers
						if (domains.length == 0 ) {
							this._showNoAllowedDomainsAllCustomersErrorBanner();
						} else {
							this._ifOnlyOneCustomerThenSelectItAutomatically();
						}
					}.bind(this));
				}.bind(this));
		},
		
		_showNoAllowedDomainsAllCustomersErrorBanner: function () {
			var errorMessageTitle, errorMessageBody, buttonText, closeBannerUrl;
			var i18nModel = this.getModel("i18n");
			var bIsUserSuperAdmin = this._getViewProperty("IsSuperAdmin");
			
			if (bIsUserSuperAdmin) {
				errorMessageTitle = i18nModel.getProperty("ERROR_BANNER_TITLE__NO_ALLOWED_DOMAINS__SUPER_ADMIN");
				errorMessageBody = i18nModel.getProperty("ERROR_BANNER_BODY__NO_ALLOWED_DOMAINS_ALL_CUSTOMERS__SUPER_ADMIN");
				buttonText = i18nModel.getProperty("ERROR_BANNER_BUTTON__COMPANY_DOMAIN_TOOL");
				closeBannerUrl = "/#/emaildomain";
			} else {
				errorMessageTitle = i18nModel.getProperty("ERROR_BANNER_TITLE__NO_ALLOWED_DOMAINS__USER_ADMIN");
				errorMessageBody = i18nModel.getProperty("ERROR_BANNER_BODY__NO_ALLOWED_DOMAINS_ALL_CUSTOMERS__USER_ADMIN");
				buttonText = i18nModel.getProperty("ERROR_BANNER_BUTTON__MY_IMPORTANT_CONTACTS");
				closeBannerUrl = "/#/importantcontacts";
			}
			var formattedText = new sap.m.FormattedText({
				htmlText: errorMessageBody
			});
			sap.m.MessageBox.error(formattedText, {
				contentWidth: "35rem",
				title: errorMessageTitle,
				emphasizedAction: buttonText,
				actions: [buttonText, sap.m.MessageBox.Action.CANCEL],
				onClose: function (oAction) {
					if(oAction == buttonText) {
						window.location.replace(closeBannerUrl);
					} else {
						window.location.replace("/#/user/management/");
					}
				}			
			});				
		},
		
		_showNoAllowedDomainsSelectedCustomerErrorBanner: function (sName) {
			var errorMessageTitle, errorMessageBody, buttonText, closeBannerUrl;
			var i18nModel = this.getModel("i18n");
			var bIsUserSuperAdmin = this._getViewProperty("IsSuperAdmin");

			if (bIsUserSuperAdmin) {
				errorMessageTitle = i18nModel.getProperty("ERROR_BANNER_TITLE__NO_ALLOWED_DOMAINS__SUPER_ADMIN");
				errorMessageBody = i18nModel.getProperty("ERROR_BANNER_BODY__NO_ALLOWED_DOMAINS_SELECTED_CUSTOMER__SUPER_ADMIN");
				buttonText = i18nModel.getProperty("ERROR_BANNER_BUTTON__COMPANY_DOMAIN_TOOL");
				closeBannerUrl = "/#/emaildomain";
			} else {
				errorMessageTitle = i18nModel.getProperty("ERROR_BANNER_TITLE__NO_ALLOWED_DOMAINS__USER_ADMIN");
				errorMessageBody = i18nModel.getProperty("ERROR_BANNER_BODY__NO_ALLOWED_DOMAINS_SELECTED_CUSTOMER__USER_ADMIN");
				buttonText = i18nModel.getProperty("ERROR_BANNER_BUTTON__MY_IMPORTANT_CONTACTS");
				closeBannerUrl = "/#/importantcontacts";
			}
			errorMessageBody = Util.formatMessage(errorMessageBody,
				[this._getViewProperty("CustomerText"), this._getViewProperty("CustomerNumber")] );
			var formattedText = new sap.m.FormattedText({
				htmlText: errorMessageBody
			});
			sap.m.MessageBox.error(formattedText, {
				contentWidth: "35rem",
				title: errorMessageTitle,
				emphasizedAction: buttonText,
				actions: [buttonText, i18nModel.getProperty("CONTINUE")],
				onClose: function (oAction) {
					if(oAction == buttonText) {
						window.location.replace(closeBannerUrl);
					}
				}			
			});				
		},
		
		_validateName: function (sName) {
			return !(this.formatter.dialog.isNameBlank(sName) ||
				this.formatter.dialog.isNameReserved(sName) ||
				this.formatter.dialog.isNameHasInvalidChars(sName));
		},

		onNameChange: function (oEvent) {
			var oBinding = oEvent.getSource().getBinding("value"),
				sName = Util.trimString(oBinding.getValue()),
				sPath = oBinding.getPath();

			this._setViewProperty("Validation/" + sPath, this._validateName(sName));
			this._setViewProperty(sPath, sName);
			this.updateErrorMessagesNew();
		},

		onEmailIconPress: function (oEvent) {
			if (!this._oEmailValidationPopover) {
				this._oEmailValidationPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.EMailValidationPopover", this);
				this._oEmailValidationPopover.setModel(this.getModel("i18n"), "i18n");
				this.getView().addDependent(this._oEmailValidationPopover);
			}
			this._oEmailValidationPopover.setPlacement(sap.m.PlacementType.Right);
			this._oEmailValidationPopover.openBy(oEvent.getSource());
		},

		getSettings: function () {
			return Settings.requestUserView;
		},

		// validateEmailNew: function(){
		// 	this._clearValidations();

		// 	this._checkEmailValidity().then(function (oResult) {
		// 		this.processInvalidValidationAreas("ValidatorRequestUser", oResult);
				
		// 		this.updateErrorMessagesNew();
		// 	}.bind(this));
		// },

		validateEmail: function () {
			this._clearValidations();
			this._checkEmailValidity().then(function (oResult) {
				if (oResult.bEmailValid) {
					this._setViewProperty("Validation/Email", true);
					this._setViewProperty("Validation/SharedEmail", true);
					this._setViewProperty("Validation/DuplicateEmail", true);
					this._setViewProperty("EmailInputValueState", sap.ui.core.ValueState.None);
				} else {
					if (!oResult.bEmailFormatValid) {
						this._setViewProperty("Validation/Email", false);
						this._setViewProperty("ValidationEmailText", this.getText("MESSAGE_EMAIL_INVALID"));
						this._setViewProperty("EmailInputValueState", sap.ui.core.ValueState.Error);
					} else if (oResult.bInvalidLength) {
						this._setViewProperty("Validation/Email", false);
						this._setViewProperty("Validation/validLength", false);
						this._setViewProperty("ValidationEmailText", this.getText("MESSAGE_EMAIL_LENGTH_INVALID"));
						this._setViewProperty("EmailInputValueState", sap.ui.core.ValueState.Error);
					} else if (oResult.bEmailShared) {
						this._setViewProperty("Validation/Email", false);
						this._setViewProperty("Validation/SharedEmail", false);
						this._setViewProperty("ValidationEmailText", this.getText("MESSAGE_SHARED_EMAIL_NEW"));
						this._setViewProperty("EmailInputValueState", sap.ui.core.ValueState.Error);
					} else if (oResult.bEmailDuplicate) {
						this._setViewProperty("Validation/Email", true);
						this._setViewProperty("Validation/DuplicateEmail", false);
						this._setViewProperty("ValidationEmailText", this.getText("MESSAGE_EMAIL_ALREADY_EXISITS"));
						this._setViewProperty("EmailInputValueState", sap.ui.core.ValueState.Error);
					}
				}
				this.updateErrorMessagesNew();
			}.bind(this));
		},
		onEmailNameChange: function() {
			this.onEmailDomainChange();
		},

		onEmailDomainChange: function () {
			this._setFullEmailToViewProperty();
			
			if(this._getViewProperty("IsSuperAdmin")){
				this._validateDomainSuperCloudAdmin();
			} else {
				this._validateDomainUserAdmin();
			}
		},

		_validateDomainUserAdmin: function() {
			this._clearDomainValidations();
			if(this.getView().byId("domainSelectorUserAdmin").getSelectedItem() !== null) {
				if(this.getView().byId("domainSelectorUserAdmin").getSelectedItem().getEnabled()) {
					this._setViewProperty("/isEmailDomainVerified", true);
					this._setViewProperty("emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
				} else {
					this._setViewProperty("/isEmailDomainVerified", false);
					this._setViewProperty("emailDomainUserAdminValueState", sap.ui.core.ValueState.Error);
				}
			} else {
				this._setViewProperty("/isEmailDomainVerified", true);
				this._setViewProperty("emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
			}

			var bLocalEmailPart = this.getView().byId("namePartOfEmail").getValue() !== "";
			if (bLocalEmailPart) {
				this.newEmailValidation();
			}
		},

		_validateDomainSuperCloudAdmin: function() {
			this._clearDomainValidations();
			var isSelectedFromAllowedDomainList = this.getView().byId("domainSelectorSuperCloudAdmin").getSelectedItem() !== null;
			if (isSelectedFromAllowedDomainList) {
				this._setViewProperty("valueStateForNotesArea", "None");									
			}
			this.newEmailValidation();
			this._checkIfAdditionalNoteNeeded();			
			this.updateErrorMessagesNew();
		},

		_getFullEmail: function () {
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
			var domain = domainSelectorSuperCloudAdmin ? domainSelectorSuperCloudAdmin.getValue() : this._getViewProperty("DomainPartOfEmail");			

			return [
				this.getView().byId("namePartOfEmail").getValue(), 
				domain
			].join("@");

		}, 
		_getDomain: function () {
			var domain = this._getViewProperty("DomainPartOfEmail");
			var aAllowedDomains = this._getViewProperty("AllowedDomainsList");
			var checkDomain = aAllowedDomains.some(function(e) {
				return e.email === domain;
			})
			if (checkDomain) {
				return domain;
			} else {
				return aAllowedDomains[0]["email"];
			}
		},
		
		newEmailValidation: function () {
			this._clearValidations();
			var sEmail = this._getFullEmail();

			this._checkEmailValidity(sEmail).then(function (oResult) {
				if(oResult.iMaxLength && !this._emailMaxLength){
					this._emailMaxLength = oResult.iMaxLength;
				}
				if (oResult.bEmailValid) {
					this._setViewProperty("Validation/Email", true);
					this._setViewProperty("Validation/SharedEmail", true);
					this._setViewProperty("Validation/DuplicateEmail", true);
					this._setViewProperty("Validation/InvalidLength", true);
				} else {
					this._showEmailValidationError(oResult, false, sEmail);
				}
			this._showBordersForEmailParts();
			this._showBordersForDomainParts();
			this.updateErrorMessagesNew();
			}.bind(this));
		},

		_isLocalPartInvalid: function () {
			var emailRegexp = this.getView().getModel("appSettings").oData.emailRegexp;
			var localPartRegex = emailRegexp.split("@")[0] + "$";
			var oEmailRegex = new RegExp(localPartRegex, "i");
			var localEmailPart = this.getView().byId("namePartOfEmail").getValue();
			var isLocalPartValid = Boolean(oEmailRegex.test(localEmailPart));
			return !isLocalPartValid;
		},

		_showEmailValidationError: function (oResult, bShowEmailDuplicateDialog, sCheckedEmail) {
			var sEmail = this._getFullEmail();

			if (this._isLocalPartInvalid()) {
				this._showErrorEmailInvalidFormat();
			} else {
				this._setViewProperty("Validation/validFormat", true);
			}

			if (oResult.bInvalidLength) {
				this._showErrorEmailInvalidLength();
			} else {
				this._setViewProperty("Validation/validLength", true);
			}

			if (oResult.bEmailShared) {
				this._showErrorEmailShared();
			} else {
				this._setViewProperty("Validation/SharedEmail",true);
			}

			if (oResult.bEmailDuplicate) {
				this._showErrorEmailIsDuplicate(bShowEmailDuplicateDialog, sEmail);
			} else {
				this._setViewProperty("Validatoin/DuplicateEmail", true);

			}
		},

		_showErrorEmailInvalidFormat: function () {
			this._setViewProperty("Validation/Email", false);
			this._setViewProperty("Validation/validFormat", false);
		},

		_showErrorEmailInvalidLength: function () {
			this._setViewProperty("Validation/Email", false);
			this._setViewProperty("Validation/validLength", false);
		},

		_showErrorEmailShared: function () {
			this._setViewProperty("Validation/Email", false);
			this._setViewProperty("Validation/SharedEmail",false);
		},

		_showErrorEmailIsDuplicate: function(bShowEmailDuplicateDialog, sCheckedEmail) {
			var sEmail = sCheckedEmail? sCheckedEmail: this._getFullEmail();

			this._setViewProperty("Validation/Email", true);
			this._setViewProperty("Validation/DuplicateEmail", false);
			
			var oData = {
				Email: sEmail,
				CustomerNumber: this._getViewProperty("CustomerNumber")
			};

			if(bShowEmailDuplicateDialog){				
				this._oDialogs.getDialog("EmailDuplicates")
					.setViewModel(this._getViewProperty(""))
					.syncStyleClass()
					.open(this);
			}
			return false;
		},

		_showBordersForEmailParts: function () {
			var oValid = this._getViewProperty("Validation");

			if(oValid.Email) {
				if(oValid.DuplicateEmail) {
					this._setViewProperty("EmailValueState", sap.ui.core.ValueState.None);
				} else {
					this._setViewProperty("EmailValueState", sap.ui.core.ValueState.Error);
					this._getViewProperty("IsSuperAdmin") ? this._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Error) : this._setViewProperty("emailDomainUserAdminValueState", sap.ui.core.ValueState.Error);
				}
			} else {
				if(!oValid.validFormat) {
					this._setViewProperty("EmailValueState", sap.ui.core.ValueState.Error);
				}
				if (!oValid.validLength) {
					this._setViewProperty("EmailValueState", sap.ui.core.ValueState.Error);
				}
				if (!oValid.SharedEmail) {
					this._setViewProperty("EmailValueState", sap.ui.core.ValueState.Error);
				}
			}
		},

		_showBordersForDomainParts: function () {
			var oValid = this._getViewProperty("Validation");
			var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");

				if(!oValid.EmailDomainPresent || !oValid.EmailDomainCorrectFormat || !oValid.DuplicateEmail) {
					this._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Error);
				} else if (oValid.AdditionalNoteNeeded) {
					this._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Warning);
				} else if (this._getViewProperty("IsSuperAdmin") && domainSelectorSuperCloudAdmin.bIsFocused) {
					this._setViewProperty("emailDomainSuperCloudAdminValueState", sap.ui.core.ValueState.Information);
				} else {
					this._setViewProperty("emailDomainUserAdminValueState", sap.ui.core.ValueState.None);
				}
		},

		_clearValidations: function () {
			this._setViewProperty("Validation/Email", true);
			this._setViewProperty("Validation/SharedEmail", true);
			this._setViewProperty("Validation/validLength", true);
			this._setViewProperty("Validation/DuplicateEmail", true);

			if(this._getViewProperty("IsDomainCheckEnabled")) {
				this._setViewProperty("Validation/validFormat", true);
			} 

			this._crearValidationsValueStates();
		},

		_crearValidationsValueStates: function(){
			this._initInitialValuesForProperties("INIT_VALUESTATE_PROPS", sap.ui.core.ValueState.None);
		},

		// _crearValidationsValueStates: function(){
		// 	var 
		// 		domainCheckEnabled = this._getViewProperty("IsDomainCheckEnabled"),
		// 		none = sap.ui.core.ValueState.None;
			
		// 	this._setViewProperty(domainCheckEnabled ? "EmailValueState" : "EmailInputValueState", none);
		// },

		_clearDomainValidations: function () {
			this._setViewProperty("Validation/EmailDomainPresent", true);
			this._setViewProperty("Validation/EmailDomainCorrectFormat", true);
			this._setViewProperty("Validation/AdditionalNoteNeeded", false);

			this._crearValidationsValueStates();
		},

		// _clearDomainValidationsValueStatuses: function(){
		// 	this._setViewProperty("valueStateForNotesArea", "None");
		// 	this._setViewProperty("emailDomainUserAdminValueState", "None");

		// 	if(this._getViewProperty("emailDomainSuperCloudAdminValueState") !== "Information") {
		// 		this._setViewProperty("emailDomainSuperCloudAdminValueState", "None");
		// 	}
		// },

		_checkEmailValidity: function () {
			var 
				email = this._getViewProperty("Email"), 
				userData = {
					customerNumber: this._getViewProperty("CustomerNumber")
				},
				duplicateCheck = true, 
				sharedEmailCheck = true, 
				uidCheck = false, 
				lengthCheck = true;

			if ( this._getViewProperty("IsDomainCheckEnabled") ) {
				this._setFullEmailToViewProperty();
			}

			return EmailValidator.setConcurrentCheck(true).validate.call(this, 
				email, 
				userData, 
				duplicateCheck, 
				sharedEmailCheck, 
				uidCheck, 
				lengthCheck
			);
		},
		
		_setFullEmailToViewProperty: function () {
			var sFullEmail = this._getFullEmail();
			this._setViewProperty("Email", sFullEmail);
		},

		openCustomerDialogOpen: function () {
			this._oDialogs.getDialog("AssignCustomerToUser")
				.syncStyleClass()
				.open(this);
		},

		setCustomer: function (sCustNum, sCustText) {
			this._setViewProperty("CustomerNumber", sCustNum || "");
			this._setViewProperty("CustomerText", sCustText || "");
			this._setViewProperty("Validation/Customer", !!sCustNum && !!sCustText);
			
			if (this._getViewProperty("IsDomainCheckEnabled")) {
				this._setAllowedDomainsForCustomer();
			}
		},
		
		_setAllowedDomainsForCustomer: function() {
			// this._setViewProperty("CustomerNumber", 456456); //code for testing: no domains specific customer
			this._setViewProperty("AllowedDomainsList", []);
			EmailValidator.getDomainList.call(this, this._getViewProperty("CustomerNumber"))
				.then(function (aDomainList) {
					if (aDomainList.length == 0) {
						this._showNoAllowedDomainsSelectedCustomerErrorBanner();
					} else {
						var extendedList = aDomainList.map(function (sValue){
								return {
									email: sValue
								};
							});
							
						this._setViewProperty("AllowedDomainsList", extendedList);
						this._setViewProperty("NoAllowedDomainsPresent", false);
						this._setViewProperty("DomainPartOfEmail", this._getDomain());

						var sLocalPart = this.getView().byId("namePartOfEmail").getValue();
						var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
						var domain = domainSelectorSuperCloudAdmin ? domainSelectorSuperCloudAdmin.getValue() : this._getViewProperty("DomainPartOfEmail");		
		
						if (sLocalPart !== "") {
							this.onEmailNameChange();
						}
						if (domain != "") {
							this.onEmailDomainChange();				
						}
						setTimeout(function () {
							if (this._getViewProperty("emailDomainSuperCloudAdminValueState") == "Information") {
								this._setViewProperty("emailDomainSuperCloudAdminValueState", "None");
							}								
						}.bind(this), 500);		
					}					
				}.bind(this));
		},

		onCustomerChange: function () {
			var isValid = !!this._getViewProperty("CustomerNumber") &&
				!!this._getViewProperty("CustomerText");
			this._setViewProperty("Validation/Customer", isValid);
		},

		onDepartmentDialogOpen: function () {
			this._oDialogs.getDialog("AssignDepartmentToUser")
				.syncStyleClass()
				.open(this);
		},

		setDepartment: function (sDepartmentId, sDepartmentName) {
			this._setViewProperty("DepartmentId", sDepartmentId || "");
			this._setViewProperty("Department", sDepartmentName || "");
		},

		openDepartmentValueHelp: function () {
			this._oDialogs.getDialog("SelectUserDepartment")
				.setValueHelpMode(true)
				.syncStyleClass()
				.open(this);
		},

		selectDepartment: function (sDeptName) {
			this._setViewProperty("Department", sDeptName || "");
		},

		openAPDialog: function () {
			this._oDialogs.getDialog("AssignAPsToUser")
				.syncStyleClass()
				.setProperty("SelectedList", this._getViewProperty("APs"))
				.open(this);
		},

		setAssignedAuthorizationPackages: function (aPackages) {
			this._setViewProperty("APs", aPackages);
		},

		onSave: function () {
			this.getView().byId("requestUserBtn").setEnabled(false);
			
				var aAllowedDomains = this._getViewProperty("AllowedDomainsList");
				if (aAllowedDomains.length == 0 && this._getViewProperty("IsDomainCheckEnabled")) {
					this._showNoAllowedDomainsSelectedCustomerErrorBanner();
				} else {
					this._validateAllFields().then(function (isValid) {
						if (isValid) {
							if(this._getViewProperty("IsDomainCheckEnabled")) {
								this._setViewProperty("Validation/validFormat", true);
								this._setViewProperty("EmailValueState", sap.ui.core.ValueState.None);
								if (this._getViewProperty("IsSuperAdmin")) {
									if (this._getViewProperty("emailDomainSuperCloudAdminValueState") == "Information") {
										this.getView().byId("domainSelectorSuperCloudAdmin").setValueState(sap.ui.core.ValueState.None);
									}
								} else {
									this.getView().byId("domainSelectorUserAdmin").setValueState(sap.ui.core.ValueState.None);
								}
							} else {
								this._setViewProperty("EmailInputValueState", sap.ui.core.ValueState.None);
							}	
		
							var oModelData = this._getViewProperty("");
							this.setBusy(true);
							this._createUser(oModelData)
								.then(this._handleRequestSuccess.bind(this))
								.catch(function (oError) {
									this.getView().byId("requestUserBtn").setEnabled(true);
									this.log.error("Error: " + (oError && oError.message));
								}.bind(this))
								.finally(this.setBusy.bind(this, false));
						} else {
							this._showErrorMessages();
							this.getView().byId("requestUserBtn").setEnabled(true);
						}
					}.bind(this));
				}
		},

		_showErrorMessages: function () {
			this._createMessagePopover();
			this._setViewProperty("EmailInputValueState", sap.ui.core.ValueState.Error);
			var isDuplicateEmail = !this._getViewProperty("Validation/DuplicateEmail");
			if (isDuplicateEmail) {

				this._setViewProperty("Validation/Email", true);
				this._oDialogs.getDialog("EmailDuplicates")
					.setViewModel(this._getViewProperty(""))
					.syncStyleClass()
					.open(this);

			} else {
				setTimeout(function () {
					this.oMP.openBy(this._getErrorMessagePopoverButton());
				}.bind(this), 200);

			}
			this._showBordersForEmailParts();
			this._showBordersForDomainParts();
			this.updateErrorMessagesNew();
		},

		_validateAllFields: function () {
			return new Promise(function (resolve) {
				this._checkEmailValidity().then(function (oResult) {
					var oData = this._getViewProperty(""),
						isValid = true,
						isFirstNameValid = oData.Validation.FirstName && oData.FirstName.length > 0,
						isLastNameValid = oData.Validation.LastName && oData.LastName.length > 0,
						isCustomerValid = oData.CustomerNumber.length > 0 && oData.CustomerText.length > 0,
						isEmailValid = oResult.bEmailValid,
						isEmailShared = oResult.bEmailShared,
						isEmailDuplicate = oResult.bEmailDuplicate,
						isExpiryDateValid = oData.Validation.ExpiryDate,
						isAdditionalNoteNeeded = this._checkIfAdditionalNoteNeeded(),
						isEmailDomainPresent = this._isEmailDomainPresent(),
						isEmailDomainCorrectFormat = this._isEmailDomainCorrectFormat(),
						isEmailLengthInvalid = oResult.bInvalidLength;

					this._setViewProperty("Validation/FirstName", isFirstNameValid);
					this._setViewProperty("Validation/LastName", isLastNameValid);
					this._setViewProperty("Validation/Email", isEmailValid);
					this._setViewProperty("Validation/SharedEmail", !isEmailShared);
					this._setViewProperty("Validation/DuplicateEmail", !isEmailDuplicate);
					this._setViewProperty("Validation/Customer", isCustomerValid);
					this._setViewProperty("Validation/AdditionalNoteNeeded", isAdditionalNoteNeeded);
					this._setViewProperty("Validation/EmailDomainPresent", isEmailDomainPresent);
					this._setViewProperty("Validation/EmailDomainCorrectFormat", isEmailDomainCorrectFormat);
                    this._setViewProperty("Validation/validLength", !isEmailLengthInvalid);

					isValid = isFirstNameValid && isLastNameValid && isEmailValid && isCustomerValid && isExpiryDateValid && isEmailDomainPresent && isEmailDomainCorrectFormat &&  !isAdditionalNoteNeeded;

					resolve(isValid);
				}.bind(this));
			}.bind(this));
		},
		
		_isEmailDomainPresent: function () {
			if (this._getViewProperty("IsDomainCheckEnabled")) {
				var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
				var sDomain = domainSelectorSuperCloudAdmin ? domainSelectorSuperCloudAdmin.getValue() : this._getViewProperty("DomainPartOfEmail");

				return sDomain.length > 0;
			} else {
				return true;
			}
		},

		_isEmailDomainCorrectFormat: function () {
			if (this._getViewProperty("IsDomainCheckEnabled")) {
				var domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin");
				var sDomain = domainSelectorSuperCloudAdmin ? domainSelectorSuperCloudAdmin.getValue() : this._getViewProperty("DomainPartOfEmail");
				return this._isDomainCorrectFormat(sDomain);
			} else {
				return true;
			}
		},
		
		_isDomainCorrectFormat: function(sDomainName) {
			var oDomainConfigModel = this.getView().getModel("DomainConfig"),
				sRegex = oDomainConfigModel.getProperty("/REGEX_VALID_DOMAIN");
			var pattern = new RegExp(sRegex);
			var isDomainMatchingRegexp =  pattern.test(sDomainName);
			
			if (sDomainName.length < 1 || !isDomainMatchingRegexp) {
				return false;
			} else {
				return true;
			}
		},

		_checkIfAdditionalNoteNeeded: function () { 
			if (this._getViewProperty("IsDomainCheckEnabled") && this._getViewProperty("IsSuperAdmin")) {
				var aAllowedDomains = this._getViewProperty("AllowedDomainsList");
				var sCurrentDomain = this.getView().byId("domainSelectorSuperCloudAdmin").getValue();

				if(this._isEmailDomainPresent()) {
					if (this._isDomainCorrectFormat(sCurrentDomain)) {
						var checkDomain = aAllowedDomains.some(function(e) {
							return e.email === sCurrentDomain;
						})			
	
						this._setViewProperty("Validation/EmailDomainCorrectFormat", true);
						if (checkDomain) {
							this._setViewProperty("valueStateForNotesArea", "None");
							this._setViewProperty("Validation/AdditionalNoteNeeded", false);
							this._setViewProperty("emailDomainSuperCloudAdminValueState", "Information");
							return false;
						} else if (!checkDomain && this._getViewProperty("Notes").length > 0) {
							this._setViewProperty("valueStateForNotesArea", "Warning");
							this._setViewProperty("Validation/AdditionalNoteNeeded", true);
							this._setViewProperty("emailDomainSuperCloudAdminValueState", "Warning");
							return false;
						} else {
							this._setViewProperty("valueStateForNotesArea", "Warning");
							this._setViewProperty("Validation/AdditionalNoteNeeded", true);
							this._setViewProperty("emailDomainSuperCloudAdminValueState", "Warning");
							return true;
						}
					} else {
						this._setViewProperty("valueStateForNotesArea", "None");
						this._setViewProperty("Validation/AdditionalNoteNeeded", false);
						this._setViewProperty("emailDomainSuperCloudAdminValueState", "Error");
						this._setViewProperty("Validation/EmailDomainCorrectFormat", false);
						return false;
			  		}	
			  	}
			}			
		},
		
		_createUser: function (oUserData) {
			var oEntry = {
				Kunnr: oUserData.CustomerNumber,
				Anred: oUserData.SalutationKey,
				Name1: Util.trimString(oUserData.LastName),
				Namev: Util.trimString(oUserData.FirstName),
				Ipadr: oUserData.Email,
				ParlaExt: oUserData.LanguageCode,
				Department: unescape(oUserData.Department),
				DepartmentId: oUserData.DepartmentId || "",
				Notes: Util.trimString(oUserData.Notes)
			};
			if (oUserData.APs && oUserData.APs.length) {
				oEntry.AuthPackages = oUserData.APs.map(function (oPackage) {
					return oPackage.AuthPackId;
				}).join("|");
			}
			if (this._getSettings().isSUserLifetimeEnabled && !Util.date.isSameDay(oUserData.SelectedExpiryDate, oUserData.DefaultExpiryDate)) {
				oEntry.ExpDate = Util.date.dateToUTCDate(oUserData.SelectedExpiryDate);
			}
			return Util.promiseCreate.call(this, "/UserSet", oEntry);
		},

		_handleRequestSuccess: function () {
			// this.getView().byId("requestUserBtn").setEnabled(true);
			this._triggerBusEvent("requestedUsersRefresh");
			sap.m.MessageBox.success(this.getText("REQUEST_NEW_USER_CREATE_SUCCESS3"), {
				title: this.getText("REQUEST_NEW_USER_CREATE_SUCCESS1"),
				onClose: function () {
					this.getRouter().navTo("UA_main", {}, false);
				}.bind(this)
			});
			this.getModel().refresh();
			this.getView().byId("requestUserBtn").setEnabled(true);
			//Update launchpad KPIs
			sap.ui.getCore().getEventBus().publish("landingpage", "refresh", {
				source: "useradminnew",
				target: "userManagement"
			});

		},

		onCancel: function () {
			this.getRouter().navTo("UA_main", {}, false);
		},
		onAdditonalNoteChange: function (oEvent) {
			this.updateErrorMessagesNew();
		},

		onExpiryDateChange: function (oEvent) {
			var sNewValue = oEvent.getParameter("newValue"),
				bValid = oEvent.getParameter("valid") && sNewValue;

			this._setViewProperty("Validation/ExpiryDate", !!bValid);
			this._setViewProperty("Validation/ExpiryDateOverRange", !!oEvent.getSource()._parseValue(sNewValue));

			this.updateErrorMessagesNew();
		},

		handleMessagePopoverPress: function (oEvent) {
			var oBtn = oEvent.getSource();
			this._createMessagePopover();
			this.updateErrorMessagesNew();
			setTimeout(function () {
				this.oMP.toggle(oBtn);
			}.bind(this), 100);
		},

		handleEmailDuplicateDialogClose: function () {
			this._createMessagePopover();
			this.updateErrorMessagesNew();
			setTimeout(function () {
				this.oMP.openBy(this._getErrorMessagePopoverButton());
			}.bind(this), 200);
		},

		_getErrorMessagePopoverButton: function () {
			return this.getView().byId("messagePopoverBtn");
		},

		_createMessagePopover: function () {
			if (!this.oMP) {
				var oLink = new Link({
					text: "{linkText}",
					press: function () {
						this._oDialogs.getDialog("EmailDuplicates")
							.setViewModel(this._getViewProperty(""))
							.syncStyleClass()
							.open(this);
					}.bind(this)
				});

				if (this.getModel("appSettings").getData().domainCheckActive) {
					var oMessageTemplate = new MessageItem({
						title: "{title}",
						description: "{description}",
						subtitle: "{subtitle}",
						link: oLink,
						markupDescription: true,
						type: "{type}"
					});
				} else {
						oMessageTemplate = new MessageItem({
						title: "{title}",
						description: "{description}",
						subtitle: "{subtitle}",
						link: oLink
						});
				}

				this.oMP = new MessagePopover({
					items: {
						path: "/",
						template: oMessageTemplate
					}
				});

				if (this.getModel("appSettings").getData().domainCheckActive) {
					this.oMP.setAsyncURLHandler(function (config) {
						config.promise.resolve({
							allowed: true,
							id: config.id
						});
					});
					this.oMP.setAsyncDescriptionHandler(function (config) {
						config.promise.resolve({
							allowed: true,
							id: config.id
						});
					});
				}

				var oData = [];
				var oOMPModel = new sap.ui.model.json.JSONModel(oData);
				this.oMP.setModel(oOMPModel);
				this.getView().byId("messagePopoverBtn").addDependent(this.oMP);

				this.oMP.getBinding("items").attachChange(function () {
					setTimeout(function () {
						this.oMP.navigateBack();
					}.bind(this), 200);
					//	this._MessageManager.removeAllMessages();
				}.bind(this));

			}
		},

		_initValidationDuplicateEmailCheck: function () {
			this._setViewProperty("Validation/DuplicateEmail", true);
		},

		updateErrorMessagesNew: function () {
			var 
				validationBlockName = "ValidationRequestUser",
				errors = this.collectValidationMessages(validationBlockName);

			this._setViewProperty("ValidationMessages", errors);
			this._setViewProperty("submitEnabled", this.isSubmitEnabled(errors));
			this.updateValueStates();
		},

		isSubmitEnabled: function(errors){
			return (!errors.length || this.isErrorOnlyAboutAdditionalNote(errors)) && !!this._validateAllFieldsNotEmpty();
		},

		isErrorOnlyAboutAdditionalNote: function(errors){
			var
				isSuperAdmin =  this._getViewProperty("IsSuperAdmin"),
				additionalNoteNeed = this._getViewProperty("Validation/AdditionalNoteNeeded"),
				notes = this._getViewProperty("Notes");

			return isSuperAdmin && errors.length === 1 && additionalNoteNeed && !!notes.length;
		},

		// _updateErrorMessages: function () {

		// 	var oValid = this._getViewProperty("Validation"),
		// 		aErrors = [];

		// 	if (!oValid.FirstName) {
		// 		aErrors.push({
		// 			title: this.getText("VALUE_STATE_FIRST_NAME"),
		// 			subtitle: this.getText("DETAIL_USER_FIRST_NAME"),
		// 			description: "",
		// 			type: sap.ui.core.MessageType.Error
		// 		});
		// 	}

		// 	if (!oValid.LastName) { 
		// 		aErrors.push({
		// 			title: this.getText("VALUE_STATE_LAST_NAME"),
		// 			subtitle: this.getText("DETAIL_USER_LAST_NAME"),
		// 			description: "",
		// 			type: sap.ui.core.MessageType.Error
		// 		});
		// 	}

		// 	if (this.getModel("appSettings").getData().domainCheckActive) {				
		// 		if (!oValid.Email) {
		// 			if (!oValid.SharedEmail) {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_SHARED_EMAIL_NEW2"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: this.getText("MESSAGE_SHARED_EMAIL_POLICY_NEW2"),
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			}
		// 			if (!oValid.validFormat) {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_EMAIL_INVALID_NEW"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: this.getText("MESSAGE_EMAIL_INVALID_POLICY"),
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			}
		// 			if (!oValid.validLength) {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_EMAIL_LENGTH_INVALID"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: this.getText("MESSAGE_EMAIL_LENGTH_POLICY", [this._emailMaxLength]),
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			}
		// 		} else {
		// 			if (!oValid.DuplicateEmail) {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_EMAIL_ALREADY_EXISITS_NEW"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: this.getText("MESSAGE_DUPLICATE_EMAIL_POLICY_NEW2"),
		// 					linkText: this.getText("MISC_SHOW_DUPLICATES"),
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			}
		// 			if (!oValid.SharedEmail) {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_SHARED_EMAIL_NEW2"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: this.getText("MESSAGE_SHARED_EMAIL_POLICY_NEW2"),
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			}
		// 		}
		// 	} else {
		// 		if (!oValid.Email) {
		// 			if (!oValid.SharedEmail) {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_SHARED_EMAIL_NEW_TWO_LINE"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: this.getText("MESSAGE_SHARED_EMAIL_POLICY_NEW"),
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			} else {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_EMAIL_INVALID"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: "",
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			}
		// 			if (!oValid.validLength) {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_EMAIL_LENGTH_INVALID"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: this.getText("MESSAGE_EMAIL_LENGTH_POLICY", [this._emailMaxLength]),
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			}
		// 		} else {
		// 			if (!oValid.DuplicateEmail) {
		// 				aErrors.push({
		// 					title: this.getText("MESSAGE_EMAIL_ALREADY_EXISITS_TWO_LINE"),
		// 					subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 					description: this.getText("MESSAGE_DUPLICATE_EMAIL_POLICY_NEW"),
		// 					linkText: this.getText("MISC_SHOW_DUPLICATES"),
		// 					type: sap.ui.core.MessageType.Error
		// 				});
		// 			}
		// 		}
		// 	}

		// 	if (oValid.AdditionalNoteNeeded) {
		// 		aErrors.push({
		// 			title: this.getText("MESSAGE_TITLE__UNVERIFIED_EMAIL_DOMAIN__SUPER_ADMIN"),
		// 			subtitle: this.getText("DETAIL_USER_CONTACT_IPADR") + ", " + this.getText("DETAIL_ADDITIONAL_NOTES"),
		// 			description: this.getText("MESSAGE_DESCRIPTION__UNVERIFIED_EMAIL_DOMAIN__SUPER_ADMIN"),
		// 			type: sap.ui.core.MessageType.Warning
		// 		});
		// 	}

		// 	if(this._getViewProperty("IsSuperAdmin")) {
		// 		if(!oValid.EmailDomainPresent || !oValid.EmailDomainCorrectFormat) {
		// 			aErrors.push({
		// 				title: this.getText("MESSAGE_TITLE__EMAIL_INCORRECT_FORMAT"),
		// 				subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 				description: this.getText("MESSAGE_DESCRIPTION__EMAIL_INCORRECT_FORMAT"),
		// 				type: sap.ui.core.MessageType.Error	
		// 			});
		// 		}
		// 	} else if (!oValid.EmailDomainPresent) {
		// 		aErrors.push({
		// 			title: this.getText("MESSAGE_TITLE__EMAIL_DOMAIN_MISSING"),
		// 			subtitle: this.getText("DETAIL_USER_CONTACT_IPADR"),
		// 			description: this.getText("MESSAGE_DESCRIPTION__EMAIL_DOMAIN_MISSING"),
		// 			type: sap.ui.core.MessageType.Error
		// 		});
		// 	} 
				
		// 	if (!oValid.ExpiryDate) {
		// 		aErrors.push({
		// 			title: this.getText("MESSAGE_PLEASE_ENTER_A_VALID_DATE"),
		// 			subtitle: this.getText("LABEL_EXPIRY_DATE"),
		// 			description: "",
		// 			linkText: "",
		// 			type: sap.ui.core.MessageType.Error
		// 		});
		// 	}
		// 	if (!oValid.Customer) {
		// 		aErrors.push({
		// 			title: this.getText("VALUE_STATE_CUSTOMER"),
		// 			subtitle: this.getText("CUSTOMER"),
		// 			description: "",
		// 			linkText: "",
		// 			type: sap.ui.core.MessageType.Error
		// 		});
		// 	}
		// 	this._setViewProperty("Errors", aErrors);
		// 	if (this.oMP && aErrors.length) {
		// 		setTimeout(function () {
		// 			this.oMP.getModel().setProperty("/", aErrors);
		// 		}.bind(this), 200);
		// 	} 
			
		// 	/**
		// 	 * The unverified email domain error should be visible even though the additional note field has been fill in,
		// 	 * But super administrators should still be able to submit the request, if the additional note field is not empty. 
		// 	 * See{@link https://jira.tools.sap/browse/UMT-1206}
		// 	 */
		// 	var errorIsOnlyAboutAdditionalNote = this._getViewProperty("IsSuperAdmin") &&
		// 		aErrors.length == 1 && 
		// 		oValid.AdditionalNoteNeeded &&
		// 		this._getViewProperty("Notes").length > 0;
				
		// 	if ((aErrors.length == 0 || errorIsOnlyAboutAdditionalNote) && this._validateAllFieldsNotEmpty()) {
		// 		this._setViewProperty("submitEnabled", true);	
		// 	} else {
		// 		this._setViewProperty("submitEnabled", false);	
		// 	}
		// },

		_validateAllFieldsNotEmpty: function () {
			var oData = this._getViewProperty(""),
				isFirstNameFilledIn = oData.Validation.FirstName && oData.FirstName.length > 0,
				isLastNameFilledIn = oData.Validation.LastName && oData.LastName.length > 0,
				isCustomerFilledIn = oData.CustomerNumber.length > 0 && oData.CustomerText.length > 0,
				domainSelectorSuperCloudAdmin = this.getView().byId("domainSelectorSuperCloudAdmin"),
				emailFilledIn = false;
				if(this._getViewProperty("IsDomainCheckEnabled")) {
					var domainPartFilledIn = domainSelectorSuperCloudAdmin ? domainSelectorSuperCloudAdmin.getValue() : this._getViewProperty("DomainPartOfEmail"),

						namePartFilledIn = this.getView().byId("namePartOfEmail").getValue();
					emailFilledIn = domainPartFilledIn && namePartFilledIn;
				} else {
					emailFilledIn = this._getViewProperty("Email");
				}
			return isFirstNameFilledIn && isLastNameFilledIn && isCustomerFilledIn && emailFilledIn;
		},

		onRemoveAuthPackPress: function (oEvent) {
			var aAPs = this._getViewProperty("APs");
			var sPath = oEvent.getSource().getParent().getBindingContextPath();
			var aPathParts = sPath.split("/");
			var iIndex = aPathParts[aPathParts.length - 1];
			aAPs.splice(iIndex, 1);
			this.setAssignedAuthorizationPackages(aAPs);
			var Label = this.getView().byId("authPackListLabelId");
			Label.setText(this.formatter.master.setAPTitle(aAPs));
		},

		onNotesIconPress: function (oEvent) {
			if (!this._oNotesPopover) {
				this._oNotesPopover = sap.ui.xmlfragment("sap.support.useradministration.view.fragment.NotesPopover", this);
				this._oNotesPopover.setModel(this.getModel("i18n"), "i18n");
			}
			this._oNotesPopover.setPlacement(sap.m.PlacementType.Bottom);
			this._oNotesPopover.openBy(oEvent.getSource());
		}
	}));
});
sap.ui.define([
    "sap/ui/base/Object",
    "sap/support/useradministration/model/DialogModelController",
    
    "sap/support/useradministration/controller/dialog/AddDepartment",
    "sap/support/useradministration/controller/dialog/AssignUserAuthPackages",
    "sap/support/useradministration/controller/dialog/AssignAPsToUser",
    "sap/support/useradministration/controller/dialog/AssignCustomerToUser",
    "sap/support/useradministration/controller/dialog/AssignDepartmentToUser",
    "sap/support/useradministration/controller/dialog/AssignUsersToAPs",
    "sap/support/useradministration/controller/dialog/AuthorizationHistory",
    "sap/support/useradministration/controller/dialog/CopyAPAuthorizationLevels",
    "sap/support/useradministration/controller/dialog/CopyAuthorizationLevels",
    "sap/support/useradministration/controller/dialog/CopyUsersAuthorizations",
    "sap/support/useradministration/controller/dialog/CopyUsersAuthorizationsOptions",
    "sap/support/useradministration/controller/dialog/ManageDepartments",
    "sap/support/useradministration/controller/dialog/ManageSelfServiceAuthorization",
    "sap/support/useradministration/controller/dialog/MassAddDeleteAuthorizations",
    "sap/support/useradministration/controller/dialog/RejectRequest",
    "sap/support/useradministration/controller/dialog/RequestAuthorization",
    "sap/support/useradministration/controller/dialog/RequestAuthorizationAdminList",
    "sap/support/useradministration/controller/dialog/RequestAuthorizationCustomMessage",
    "sap/support/useradministration/controller/dialog/RequestUser",
    "sap/support/useradministration/controller/dialog/SelectUserDepartment",
    "sap/support/useradministration/controller/dialog/SelectRestrictedCustomers",
    "sap/support/useradministration/controller/dialog/SelectRestrictedCloudInstallations",
    "sap/support/useradministration/controller/dialog/SelectRestrictedCloudProducts",
    "sap/support/useradministration/controller/dialog/SelectRestrictedCloudTenants",
    "sap/support/useradministration/controller/dialog/SelectRestrictedInstallations",
    "sap/support/useradministration/controller/dialog/SelectRestrictedTenants",
    "sap/support/useradministration/controller/dialog/SelectUserCustomer",
    "sap/support/useradministration/controller/dialog/FilterUserList",
    "sap/support/useradministration/controller/dialog/FilterRequestedUserList",
    "sap/support/useradministration/controller/dialog/FilterDeletedUserList",
    "sap/support/useradministration/controller/dialog/FilterImportantContactsList",
    "sap/support/useradministration/controller/dialog/FilterTasksList",
    "sap/support/useradministration/controller/dialog/FilterAuthorizationHistory",
    "sap/support/useradministration/controller/dialog/FilterExpDateHistory",
    "sap/support/useradministration/controller/dialog/SortUserList",
    "sap/support/useradministration/controller/dialog/SortRequestedUserList",
    "sap/support/useradministration/controller/dialog/SortDeletedUserList",
    "sap/support/useradministration/controller/dialog/SortImportantContactsList",
    "sap/support/useradministration/controller/dialog/SortReportsAndUpdatesList",
    "sap/support/useradministration/controller/dialog/SortTasksList",
    "sap/support/useradministration/controller/dialog/SortAuthorizationHistory",
    "sap/support/useradministration/controller/dialog/SortAuthorizationPackages",
    "sap/support/useradministration/controller/dialog/SortExpDateHistory",
    "sap/support/useradministration/controller/dialog/SettingUserList",
    "sap/support/useradministration/controller/dialog/SettingRequestedUserList",
    "sap/support/useradministration/controller/dialog/SettingDeletedUserList",
    "sap/support/useradministration/controller/dialog/SettingImportantContactsList",
    "sap/support/useradministration/controller/dialog/SettingReportsAndUpdatesList",
	"sap/support/useradministration/controller/dialog/SettingTasks",
	
	"sap/support/useradministration/controller/dialog/AddDepartmentNew",
	"sap/support/useradministration/controller/dialog/AssignDepartmentNew",
	"sap/support/useradministration/controller/dialog/EditDepartmentNew",
	"sap/support/useradministration/controller/dialog/ManageDepartmentNew",
	"sap/support/useradministration/controller/dialog/ManageExpiryDate",
	"sap/support/useradministration/controller/dialog/APAuthOverview",
	"sap/support/useradministration/controller/dialog/APSelect",
	"sap/support/useradministration/controller/dialog/APReport",
	"sap/support/useradministration/controller/dialog/APRename",
	"sap/support/useradministration/controller/dialog/APCreate",
	"sap/support/useradministration/controller/dialog/APCopy",
	"sap/support/useradministration/controller/dialog/UsersWithCriticalRole",
	"sap/support/useradministration/controller/dialog/EmailDuplicates",
	"sap/support/useradministration/controller/dialog/SimilarAuthPacks",
	"sap/support/useradministration/controller/dialog/AuthorizedCustomers",
	"sap/support/useradministration/controller/dialog/CopyLevelsCreateAP",
	"sap/support/useradministration/controller/createAuthPackage/AuthorizedInstallations",
	"sap/support/useradministration/controller/createAuthPackage/AuthorizedUsers",
	"sap/support/useradministration/controller/dialog/History"
], function(BaseObject, DialogModelController) {
    // Retrieve arguments skipping N first
    var aDialogs = Array.prototype.slice.call(arguments, 2);
    // Singleton dialog model
    var oDialogModel = new DialogModelController(aDialogs);
    
    /**
     * An object used to control dialogs and their data
     * @param {sap.ui.core.mvc.Controller} oParentController parent controller
     * @constructor
     * @class
     * @extends sap.ui.base.Object
     * @alias sap.support.useradministration.controller.Dialogs
     */
    return BaseObject.extend("sap.support.useradministration.controller.Dialogs", {
        _oDialogs: null,
        _oFactories: null,
        _oParentController: null,
        
        constructor: function(oParentController) {
            var oFactories = {};
            
            aDialogs.forEach(function(DialogController) {
                oFactories[DialogController.prototype.getName()] = DialogController; 
            });
            this._oDialogs = {};
            this._oFactories = oFactories;
            this._oModelController = oDialogModel;
            this._oParentController = oParentController;
        },
        
        /**
         * Get dialog controller by name
         * @param {string} sDialogName dialog name
         * @returns {sap.support.useradministration.controller.dialog.BaseDialog} dialog controller
         * @function
         * @public
         */
        getDialog: function(sDialogName) {
            if (!this._oDialogs[sDialogName]) {
                // lazy initaliziation
                var Factory = this._oFactories[sDialogName];
                if (Factory) {
                    this._oDialogs[sDialogName] = new Factory(this._oParentController, this._oModelController);
                }
            }
            return this._oDialogs[sDialogName];
        },
        
        /**
         * Get dialog controller by name and reset corresponding data in dialog model
         * @param {string} sDialogName dialog name
         * @returns {sap.support.useradministration.controller.dialog.BaseDialog} dialog controller
         * @function
         * @public
         */
        getDialogAndReset: function(sDialogName) {
            oDialogModel.resetProperty(sDialogName);
            return this.getDialog(sDialogName);
        },
        
        /**
         * Get dialog model
         * @returns {sap.ui.model.json.JSONModel} model
         * @function
         * @public
         */
        getModel: function() {
            return oDialogModel.getModel();
        }
    });
});
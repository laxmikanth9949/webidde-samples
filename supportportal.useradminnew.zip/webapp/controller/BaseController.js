sap.ui.define([ 
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	
	"sap/support/useradministration/model/Formatter",
	"sap/support/useradministration/util/Settings",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/util/odata/ODataUtil"
], function(Controller, UIComponent, Formatter, Settings, Util, ODataUtil) {
	"use strict";
	
	var VIEW = "view";
	var JSONModel = sap.ui.model.json.JSONModel;

	/**
	 * @class
	 * Base controller class
	 * @extends sap.ui.core.mvc.Controller
	 * @public
	 * @alias sap.support.useradministration.controller.BaseController
	 */
	return Controller.extend("sap.support.useradministration.controller.BaseController", {
	    formatter: Formatter,
	    
        /**
         * Bind view to corresponding "view" model property
         * @param {string} sPropertyName property to bind
         * @function
         * @protected
         */
        _bindViewModel: function(sPropertyName) {
            var sName = sPropertyName || this._getShortName();
            this._sViewBindName = sName;
            this.getView().bindElement(VIEW + ">/" + sName);
        },
        
        /**
         * Get user model from the core
         * @returns {sap.ui.mode.json.JSONModel} model
         * @function
         * @protected
         */
        _getCoreUserModel: function() {
            var oCore = sap.ui.getCore();
            return oCore.getModel("user");
        },
        
        /**
         * Get settings
         * @returns {sap.support.useradministration.util.Settings} settings
         * @function
         * @private
         */
        _getSettings: function () {
        	return Settings;
        },
        
        /**
         * Get controller's short name
         * @returns {string} short name
         * @function
         * @protected
         */
        _getShortName: function() {
            var sFullName = this.getMetadata().getName();
            return /(\w+)$/.exec(sFullName)[1];
        },
        
        /**
         * Get "view" model
         * @returns {sap.ui.mode.json.JSONModel} model
         * @function
         * @protected
         */
        _getViewModel: function() {
            return this.getModel(VIEW) || this.getOwnerComponent().getModel(VIEW);
        },
        
        /**
         * Get corresponding "view" model property
         * @param {string} sProperty property name
         * @returns {any} property value
         * @function
         * @protected
         */
        _getViewProperty: function(sProperty) {
            var sName = this._sViewBindName || this._getShortName(),
                oModel = this._getViewModel();
            return oModel.getProperty("/" + sName + "/" + sProperty);
        },
        
		/**
		 * Read data from given model with given options
		 * @param {string} sPath path
		 * @param {object} oOptions options
		 * @param {string} sModelName model name
		 * @returns {Promise} native promise
		 * @function
		 * @private
		 */
		_promiseRead: function(sPath, oOptions, sModelName) {
			return Util.promiseRead.call(this, sPath, oOptions, sModelName);
		},
        
		/**
		 * Read data from given model with given options
		 * @param {string} sPath path
		 * @param {object} oOptions options
		 * @param {string} sModelName model name
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_read: function(sPath, oOptions, sModelName) {
		    var oPromise = jQuery.Deferred();
		    
		    this.getModel(sModelName).read(sPath, jQuery.extend({}, oOptions, {
		        success: function(oData) {
		            oPromise.resolve(oData);
		        },
		        error: function(oError) {
		            oPromise.reject(oError);
		        }
		    }));
		    return oPromise.promise();
		},
		
        /**
         * Set corresponding "view" model property
         * @param {string} sProperty property name
         * @param {any} vValue value
         * @function
         * @protected
         */
        _setViewProperty: function(sProperty, vValue) {
            var sName = this._sViewBindName || this._getShortName(),
                oModel = this._getViewModel();
            oModel.setProperty("/" + sName + "/" + (sProperty || ""), vValue);
        },
		
		/**
		 * Run submitChanges for given model with given options
		 * @param {object} oOptions options
		 * @param {string} sModelName model name
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_submitChanges: function(oOptions, sModelName) {
		    var oPromise = jQuery.Deferred();
		    
		    this.getModel(sModelName).submitChanges(jQuery.extend({}, oOptions, {
		        success: function(oData) {
		            oPromise.resolve(oData);
		        },
		        error: function(oError) {
		            oPromise.reject(oError);
		        }
		    }));
		    return oPromise.promise();
		},
		
		/**
		 * Create JSON model with extended size limit then add it to view if necessary
		 * @param {object} oData initial data
		 * @param {string} [sName] if provided, model will be set to view using given name
		 * @returns {sap.ui.model.json.JSONModel} created model
		 * @function
		 * @public
		 */
		createJSONModel: function (oData, sName) {
			var oModel = new JSONModel(oData || {});
			oModel.setSizeLimit(10000);
			if (sName) {
				this.setModel(oModel, sName);
			}
			return oModel;
		},

		/**
		 * Get I18N bundle
		 * @returns {sap.ui.model.resource.ResourceBundle} resource bundle
		 * @function
		 * @public
		 */
        getBundle: function() {
            return Util.getBundle.call(this);
        },

		/**
		 * Get model
		 * @param {string} [name] model name
		 * @returns {sap.ui.model.Model} the model instance
		 * @function
		 * @public
		 */
		getModel: function(name) {
			var model = this.getView().getModel(name);

			if(!model && this.getOwnerComponent()){
				model = this.getOwnerComponent().getModel(name);
			}

			return model || sap.ui.getCore().getModel(name);
		},
		
		/**
		 * Get OData utility instance
		 * @param {string} [sSetName] get set-specified utility
		 * @returns {sap.support.useradministration.util.odata.ODataUtil} utility
		 * @function
		 * @public
		 */
		getODataUtil: function (sSetName) {
			return sSetName ? ODataUtil[sSetName] : ODataUtil;
		},
		
		/**
		 * Get router for this controller
		 * @returns {sap.ui.core.routing.Router} router
		 * @function
		 * @public
		 */
		getRouter: function() {
			return UIComponent.getRouterFor(this);
		},
		
		/**
		 * Get text from i18N model
		 * @param {string} sKey i18n key
		 * @param [any[]] vArgs arguments
		 * @returns {string} text
		 * @function
		 * @public
		 */
		getText: function(sKey, vArgs) {
			return this.getBundle().getText(sKey, vArgs);	
		},
		
		/**
		 * Get OData utility instance for UserSet
		 * @returns {sap.support.useradministration.util.odata.ODataUtil} utility
		 * @function
		 * @public
		 */
		getUserSetODataUtil: function () {
			return this.getODataUtil("UserSet");
		},
		
		/**
		 * Set view busy
		 * @param {boolean} bBusy busy state
		 * @function
		 * @public
		 */
		setBusy: function(bBusy) {
			this.getView().setBusy(Boolean(bBusy));	
		},

		/**
		 * Set model
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.support.useradministration.controller.BaseController} instance itself for chaining
		 * @function
		 * @public
		 */
		setModel: function(oModel, sName) {
			this.getView().setModel(oModel, sName);
			return this;
		}
	});
});
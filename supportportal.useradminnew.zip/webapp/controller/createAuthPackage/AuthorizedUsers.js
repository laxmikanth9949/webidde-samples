sap.ui.define([
	"sap/support/useradministration/controller/dialog/BaseValueHelpDialog",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",

	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseValueHelpDialog, Constant, Util, Token, Filter, FilterOperator) {
	"use strict";

	/**
	 * Factory for dialog model
	 * @function
	 * @private
	 */
	var _fnFactory = function () {
		this.AuthObject = {};
		this.Context = "";
		this.ModelName = undefined;
		this.Items = [];
		this.Search = "";
		this.UsersMode = false;
	};

	var Callbacks = Util.callbacks;

	var AUTH_OBJ = "AuthObject";
	var CONTEXT = "Context";
	var ITEMS = "Items";
	var MODEL_NAME = "ModelName";

	// Types for check request
	var PROP_CUST_NUM = "Kunnr",
		PROP_USER_ID = "Userid";

	// Types for check request
	var TYPE_CUST = "C",
		TYPE_INST = "T",
		TYPE_USER = "U";

	/**
	 * Dialog for selecting restricted installation
	 * @class
	 * @extends sap.support.useradministration.controller.dialog.BaseValueHelpDialog
	 * @alias sap.support.useradministration.controller.dialog.SelectRestrictedInstallations
	 */
	return BaseValueHelpDialog.extend("sap.support.useradministration.controller.createAuthPackage.AuthorizedUsers", {
		_fnDataFactory: _fnFactory,
		_sDialogName: "AuthorizedUsers",

		/**
		 * Get dialog fragment for current controller
		 * @returns {sap.m.Dialog} dialog
		 * @function
		 * @private
		 */
		_getDialogFragment: function () {
			return sap.ui.xmlfragment("sap.support.useradministration.view.createAuthPackage." + this._sDialogName, this);
		},

		/**
		 * Perform a backend check of installations if all installations are selected for any customers
		 * @param {string[]} aInstallationIds installation IDs
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_checkUserIds: function (aInstallationIds) {
			var oPromise = this._getPromise(),
				sProperty = PROP_USER_ID,
				sType = TYPE_USER,
				sAuthObjectGroup = this._getDialogProperty(AUTH_OBJ + "/AuthObjectGroup"),
				sAuthObjectId = this._getDialogProperty(AUTH_OBJ + "/ObjectId");

			// KNGMHM02-20863 Disable check if group is CLOUD
			if (sAuthObjectGroup === "G_CLOUD" || sAuthObjectId === "ESRCDISP" || sAuthObjectId === "CLOUDAUTH") {
				oPromise.resolve({
					Customers: [],
					Installations: aInstallationIds
				});
			} else if (aInstallationIds && aInstallationIds.length) {
				this._oView.getModel("ts").read("/Check_selectionSet", {
					filters: [
						new Filter("Type", FilterOperator.EQ, sType),
						new Filter({
							filters: aInstallationIds.map(function (sInstId) {
								return new Filter(sProperty, FilterOperator.EQ, sInstId);
							}),
							and: false
						})
					],

					success: function (oData) {
						var aList = oData.results || [],
							aCustList = [],
							aInstList = [];

						aCustList = aList.map(function (oEntry) {
							return oEntry.Type === TYPE_CUST && oEntry.Kunnr;
						}).filter(Boolean);

						aInstList = aList.map(function (oEntry) {
							return oEntry.Type === sType && oEntry[sProperty];
						}).filter(Boolean);

						oPromise.resolve({
							Customers: aCustList,
							Installations: aInstList
						});
					},
					error: function () {
						oPromise.reject();
					}
				});
			} else {
				oPromise.resolve({
					Customers: [],
					Installations: []
				});
			}
			return oPromise.promise();
		},

		/**
		 * Show confirmation box and update customers and installations on OK
		 * @param {string[]} aCustomers list of customer numbers
		 * @param {string[]} aInstallations list of installations Ids
		 * @function
		 * @private
		 */
		_confirmSaveCustomersAndUsers: function (aCustomers, aUsers) {
			var oBundle = this._getResourceBundle();
			this.setBusy(true);
			this.showConfirmationBox(oBundle.getText("AUTHORIZATION_LEVEL_ALL_ENTRIES_4_CUSTOMERS", [aCustomers.join(", ")]), {
					title: oBundle.getText("DETAIL_USER_IMPORTANT_INFO")
				}).then(this._saveCustomers.bind(this, aCustomers || []))
				.then(function () {
					this._saveUsers(aUsers);
					this.close();
				}.bind(this))
				.always(this.setBusy.bind(this, false));
		},

		/**
		 * Get installation items from model
		 * @returns {object[]} installations
		 * @function
		 * @private
		 */
		_getItems: function () {
			return this._getDialogProperty(ITEMS) || [];
		},

		/**
		 * Get installation items with one of given IDs
		 * @param {string[]} aIds ID list
		 * @returns {object[]} installation list
		 * @function
		 * @private
		 */
		_getItemsByIds: function (aIds) {
			var oKeyToItem = Util.combineArray(this._getItems(), Callbacks.getKey("Uname"), Callbacks.self); // Create map { Item.AuthLevel => Item }
			return aIds.map(function (sInstId) {
				var oTokenItem = oKeyToItem[sInstId];
				return oTokenItem && jQuery.extend(true, {}, oTokenItem);
			}).filter(Boolean);
		},

		/**
		 * Check if the dialog is in Users selection mode
		 * @returns {boolean} true if dialog is in Users mode
		 * @function
		 * @private
		 */
		_isUsersMode: function () {
			return this._getDialogProperty("UsersMode");
		},

		/**
		 * Load items from backend
		 * @returns {object} promise
		 * @function
		 * @public
		 */
		_loadItems: function () {
			var oModel = Util.getModel.call(this._oController, this._getDialogProperty(MODEL_NAME)),
				oPromise = this._getPromise();

			if (this._oLoader && this._oLoader.abort) {
				this._oLoader.abort();
			}

			this._setDialogProperty(ITEMS, []);
			this._oLoader = oModel.read("/AuthorizedUsersSet", {
				success: function (oData) {
					this._updateItems(oData.results || []);
					this.getDialog().update();
					oPromise.resolve();
				}.bind(this),
				error: function () {
					oPromise.reject();
				}
			});

			return oPromise.promise();
		},

		/**
		 * Prepare table when opening dialog
		 * @param {sap.ui.table.Table} oTable table
		 * @function
		 * @private
		 * @override
		 */
		_prepareTable: function (oTable) {
			if (!oTable.getModel("columns")) {
				oTable.setModel(this.createJSONModel({
					cols: [{
						label: this.getText("AUTHORIZATION_LEVEL_NAME"),
						template: "dialog>Name"
					}, {
						label: this.getText("AUTHORIZATION_LEVEL_NUMBER"),
						template: "dialog>Uname"
					}, {
						label: this.getText("MASTER_COLUMN_CUST_NAME"),
						template: "dialog>CustomerName"
					}, {
						label: this.getText("MASTER_COLUMN_CUST_NUM"),
						template: "dialog>Kunnr"
					}]
				}), "columns");
			}

			oTable.bindRows({
				path: "dialog>" + ITEMS
			});
		},

		/**
		 * Updates customer list in the parent controller
		 * @param {string[]} aCustNumbers array of customer numbers
		 * @returns {object} promise
		 * @function
		 * @private
		 */
		_saveCustomers: function (aCustNumbers) {
			var oModel = Util.getModel.call(this._oController, this._getDialogProperty(MODEL_NAME)),
				oParent = this._oParentDialog || this._oController,
				oPromise = this._getPromise();

			if (aCustNumbers && aCustNumbers.length) {
				oModel.read("/AuthorizedCustomersSet", {
					success: function (oData) {
						var aCustomers = oData.results || [],
							oCustomers = Util.combineArray(aCustomers, Callbacks.getKey("Kunnr"), Callbacks.self); // Create map { Cust.AuthLevel => Cust }

						var aCustomersLevelAuths = this._prepareCustomerLevelAuths(aCustNumbers.map(function (sNumber) {
							return oCustomers[sNumber];
						}).filter(Boolean));

						oParent.appendCustomers(aCustomersLevelAuths);
						oPromise.resolve();
					}.bind(this),
					error: function () {
						oPromise.reject();
					}
				});
			} else {
				oPromise.resolve();
			}
			return oPromise.promise();
		},

		/**
		 * Updates installation list in the parent controller
		 * @param {string[]} aInstallationIds array of installation IDs
		 * @function
		 * @private
		 */
		_saveUsers: function (aUsers) {
			var oParent = this._oParentDialog || this._oController,
				aItems = this._getItemsByIds(aUsers);
			var aUserLevelAuth = this._prepareUserLevelAuths(aItems);
			oParent.saveInstallations(aUserLevelAuth);
		},

		_prepareUserLevelAuths: function (aUserIds) {
			var aInstallationLevelAuths = [];
			var ObjectId = this._getObjectId();
			aUserIds.forEach(function (item) {
				aInstallationLevelAuths.push({
					AuthLevel: item.Uname,
					AuthLevelDesc: item.Name,
					AuthLevelType: "USER",
					AuthLevelTypeDesc: "User",
					CustDesc: item.CustomerName,
					CustName: item.CustomerName,
					CustNum: item.Kunnr,
					ObjectId: ObjectId,
					Value: item.Uname,
					Field: "USER"
				});
			});

			return aInstallationLevelAuths;
		},

		_prepareCustomerLevelAuths: function (aCustomers) {
			var aCustLevelAuths = [];
			var ObjectId = this._getObjectId();
			aCustomers.forEach(function (item) {
				aCustLevelAuths.push({
					AuthLevel: item.Kunnr,
					AuthLevelDesc: item.CustomerName,
					AuthLevelType: "DEBITOR",
					AuthLevelTypeDesc: "Customer",
					CustDesc: item.Description,
					CustName: item.CustomerName,
					CustNum: item.Kunnr,
					ObjectId: ObjectId,
					Value: item.Kunnr,
					Field: "DEBITOR"
				});
			});

			return aCustLevelAuths;
		},

		/** 
		 * Update items in the dialog model
		 * @param {object[]} aItems items retrieved from the backend
		 * @function
		 * @private
		 */
		_updateItems: function (aItems) {
			this._setDialogProperty(ITEMS, aItems);
		},

		/**
		 * Handle dialog confirmation
		 * Ask user to confirm changes
		 * @param {sap.ui.base.Event} oEvent event
		 * @event
		 * @public
		 */
		onConfirmDialog: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens"),
				aAllUserIds = aTokens.map(function (oToken) {
					return oToken.getKey();
				});
			this.setBusy(true);
			this._checkUserIds(aAllUserIds)
				.then(function (oData) {
					var aCustomers = oData.Customers || [],
						aFilteredUserIds = oData.Installations || [];
					if (aCustomers.length) {
						this._confirmSaveCustomersAndUsers(aCustomers, aFilteredUserIds);
					} else {
						this._saveUsers(aFilteredUserIds);
						this.close();
					}
				}.bind(this))
				.always(this.setBusy.bind(this, false));
		},

		/**
		 * Open dialog and load items
		 * @function
		 * @public
		 * @override
		 */
		open: function () {
			BaseValueHelpDialog.prototype.open.apply(this, arguments);
			this.setBusy(true);
			this._loadItems().always(this.setBusy.bind(this, false));
		},

		/**
		 * Set Authorization object data
		 * @param {object} oData data
		 * @function
		 * @public
		 */
		setAuthObjectData: function (oData) {
			this._setDialogProperty(AUTH_OBJ, oData);
		},

		/**
		 * Set context property
		 * @param {string} sContext context path
		 * @function
		 * @public
		 */
		setContext: function (sContext) {
			this._setDialogProperty(CONTEXT, sContext);
		},

		/**
		 * Set model name property
		 * @param {string} sModelName model name
		 * @function
		 * @public
		 */
		setModelName: function (sModelName) {
			this._setDialogProperty(MODEL_NAME, sModelName);
		},

		/**
		 * Set Users mode
		 * @param {boolean} bUsersMode users mode
		 * @function
		 * @public
		 */
		setUsersMode: function (bUsersMode) {
			this._setDialogProperty("UsersMode", bUsersMode);
		},

		_getObjectId: function () {
			var oParent = this._oParentDialog || this._oController;
			return oParent._getViewProperty("AuthLevel/ObjectId");
		}
	});
});
sap.ui.define([
	"sap/support/useradministration/controller/BaseController",
	"sap/support/useradministration/controller/Dialogs",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/model/Constant",
	"sap/m/MessagePopover",
	"sap/m/MessageItem",
	"sap/m/Link"
], function (BaseController, Dialogs, Util, Constant, MessagePopover, MessageItem, Link) {
	"use strict";

	var PATH_AUTH_PACK_FOR_CUSTSET = "/auth_pack_for_custSet",
		PATH_AUTH_OBJECT_SET = "/AuthObjectSet",
		PATH_AUTH_PACKAGES = "/AuthPackages";

	var CREATE_AP_ROUTE = "createAuthPack",
		MODEL_NAME = "CreateAP";

	return BaseController.extend("sap.support.useradministration.view.CreateAP", {

		onInit: function () {
			this._oDialogs = new Dialogs(this);
			this.getRouter().getRoute(CREATE_AP_ROUTE).attachPatternMatched(this._onRouteMatched, this);
			this._bindViewModel(MODEL_NAME);
			this._initAuthorizations();
			this._attachBusEvent("authTopLevelChange", this._handleDetailAuthTopLevelChange.bind(this, false));
			this._attachBusEvent("authLevelChange", this._handleDetailAuthTopLevelChange.bind(this, true));
		},

		_onRouteMatched: function () {
			if (!this._getViewProperty("isPrevAuthLevelPage")) {
				this._refreshInputs();
				this._clearMessages();
				// this._setViewProperty("isPrevAuthLevelPage", false);
			}
			this._setViewProperty("isPrevAuthLevelPage", false);
		},

		_refreshInputs: function () {
			this._setViewProperty("AuthPackName", "");
			this._setViewProperty("Protection", false);
			this._setViewProperty("validation/isAuthPackNameEmpty", false);
			this._setViewProperty("validation/isAuthPackNameDuplicate", false);
			this._setViewProperty("validation/isAuthPackNameValid", true);
			this._setViewProperty("AuthPackNameValueStateText", "");
			this._setViewProperty("isInfoMessage", false);
			this._setViewProperty("isInputChanged", false);
			this._setViewProperty("isAuthChanged", false);
			this._initAuthorizations();
		},

		_initAuthorizations: function () {
			Util.promiseRead.call(this, PATH_AUTH_OBJECT_SET, {
					filters: [new sap.ui.model.Filter("PackageId", sap.ui.model.FilterOperator.EQ, "")]
				}, "ap")
				.then(function (oData) {
					var aAuthList = oData && oData.results || [];
					aAuthList = aAuthList.map(this._extendAuthorizationObject.bind(this));
					this._setViewProperty("AuthList", aAuthList);
					this._setViewProperty("AuthCount", 	this._countAuth(aAuthList));
				}.bind(this));
		},

		_extendAuthorizationObject: function (oAuthObject) {
			var oFormatter = this.formatter.detail;

			return jQuery.extend(true, {
				Customers: null, // List of customers from detail assign
				Installations: null, // List of installations from detail assign,
				IsGroupHeader: /^G_/.test(oAuthObject.ObjectId),
				IsTopHeader: oAuthObject.ObjectId === Constant.AuthGroup.ALL,
				TempChanges: false, // Has changes in detail assign
				TempCurrentAuthLevel: oAuthObject.CurrentAuthLevel,
				TempSelected: oFormatter.isAuthorizationSelected(oAuthObject.CurrentAuthLevel),
				URI: oAuthObject.__metadata.uri
			}, oAuthObject);
		},

		onSwitchChange: function () {
			this._setViewProperty("Protection", this.getView().byId("writeProtectionSwitch").getState());
		},

		handleAuthPackInputLiveChange: function (oEvent) {
			
			var isAuthPackNameEmpty = !oEvent.getSource().getValue();
			this._setViewProperty("validation/isAuthPackNameEmpty", isAuthPackNameEmpty);
			this._setViewProperty("validation/isAuthPackNameValid", true);
			this._setViewProperty("isInputChanged", true);
			if (!isAuthPackNameEmpty) {
				this._checkDuplicateName().then( function() {
					this._updateMessages();
				}.bind(this));
			} else {
				this._setViewProperty("validation/isAuthPackNameDuplicate", false);
				this._updateMessages();
			}
		},

		onAuthorizationObjectPress: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view"),
				oAuth = oContext.getObject();

			if (this.formatter.detail.authorizationHasDetails(oAuth.AuthLevelId)) {
				this._setViewProperty("AuthLevel", oAuth);
				this.getRouter().navTo("createAPAuthorizationItem", {
					from: "createAPAuthorizationItem",
					object: oAuth.ObjectId
				}, /* bReplace= */ false);
				this._setViewProperty("isPrevAuthLevelPage", true);
			}
		},

		onAuthorizationObjectTopLevelSelect: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("view");
			this._handleAuthorizationObjectSelectChange(oContext.getObject());
			if (!this._isEmptyAuthorizations()) {
				this._showSimilarPackages();
			} else {
				this._setSimilarAuthPacksAvailable(false);
				this._updateMessages();
			}
		},

		handleCopyAuthorizationLevels: function (oEvent) {
			var oAuthorization = oEvent.getSource().getBindingContext("view").getObject(),
				oDialog = this._oDialogs.getDialog("CopyLevelsCreateAP");

			oDialog.setAuthorization(oAuthorization)
				.syncStyleClass()
				.open();

		},

		_getAuthorizationList: function () {
			return this._getViewProperty("AuthList") || [];
		},

		_getAuthorizationObjectGroup: function (sAuthObjectGroup) {
			return this._getAuthorizationList().filter(function (oAuth) {
				return oAuth.AuthObjectGroup === sAuthObjectGroup;
			});
		},

		_getAuthorizationObjectGroupHeaders: function () {
			return this._getAuthorizationList().filter(function (oAuth) {
				return oAuth.IsGroupHeader && !oAuth.IsTopHeader;
			});
		},

		_getAuthorizationObjectGroupHeader: function (sAuthObjectGroup) {
			var aList = this._getAuthorizationList();
			for (var iIndex = 0; iIndex < aList.length; iIndex++) {
				if (aList[iIndex].ObjectId === sAuthObjectGroup) {
					return aList[iIndex];
				}
			}
			return null;
		},

		_updateAuthorizationListChanges: function () {
			return this._setViewProperty("AuthList", this._getAuthorizationList());
		},

		/**
		 * Handle selection change for auth object
		 * Change its data according to selected state
		 * Propagate selected state to group(s) if needed
		 * @param {object} oAuth authorization object
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleAuthorizationObjectSelectChange: function (oAuth, bKeepDetails) {
			this._setViewProperty("isAuthChanged", true);
			var aGroup = [];
			if (oAuth.IsGroupHeader) {
				if (oAuth.IsTopHeader) {
					aGroup = this._getAuthorizationList();
				} else {
					aGroup = this._getAuthorizationObjectGroup(oAuth.ObjectId);
				}
				aGroup.forEach(function (oInnerAuth) {
					oInnerAuth.TempSelected = oAuth.TempSelected;
					if (!oInnerAuth.IsGroupHeader) {
						oInnerAuth.TempChanges = false;
						oInnerAuth.TempCurrentAuthLevel = oInnerAuth.TempSelected ? Constant.AuthLevel.FULL : Constant.AuthLevel.EMPTY;
						oInnerAuth.Customers = [];
						oInnerAuth.Installations = [];
					}
				});
			} else {
				var oGroupHeader = this._getAuthorizationObjectGroupHeader(oAuth.AuthObjectGroup);
				oAuth.TempChanges = bKeepDetails;
				if (bKeepDetails) {
					oAuth.TempSelected = Boolean((oAuth.Customers && oAuth.Customers.length) || (oAuth.Installations && oAuth.Installations.length));
					oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.RESTRICTED : Constant.AuthLevel.EMPTY;
				} else {
					oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.FULL : Constant.AuthLevel.EMPTY;
					oAuth.Customers = [];
					oAuth.Installations = [];
				}

				// Set checkbox for group header
				if (oAuth.TempSelected) {
					aGroup = this._getAuthorizationObjectGroup(oAuth.AuthObjectGroup);
					oGroupHeader.TempSelected = aGroup.every(function (oInnerAuth) {
						return oInnerAuth.TempSelected;
					});
				} else {
					oGroupHeader.TempSelected = false;
				}
			}
			var aHeaders = this._getAuthorizationObjectGroupHeaders(),
				oTopAuth = this._getAuthorizationList()[0] || {};
			oTopAuth.TempSelected = aHeaders.every(function (oInnerAuth) {
				return oInnerAuth.TempSelected;
			});

			this._updateAuthorizationListChanges();
		},

		onSave: function () {
			this._setViewProperty("isAuthChanged", true);
			this._setViewProperty("isInputChanged", true);
			this._updateMessages();
			if (this._isValidAuthPackage()) {
				this._createAuthPackage();
			}
			else {
				this._showWarningSimilarAuthPacks();
			}
		},

		onCancel: function () {
			this._initAuthorizations();
			this.getRouter().navTo("UA_main_tab", {}, false);
		},

		handleMessagePopoverPress: function () {
			this._showWarningSimilarAuthPacks();
		},

		_showSimilarPackages: function () {
			this._getSimilarAuthPackages().then(function (aList) {
				if (aList.results.length) {
					this._setSimilarAuthPacksAvailable(true);
					this._setViewProperty("similarAuthPackages", aList.results);
				} else {
					this._setSimilarAuthPacksAvailable(false);
					this._setViewProperty("similarAuthPackages", []);
				}
				this._updateMessages();
			}.bind(this));
		},

		_clearMessages: function () {
			this._setAuthPackValid();
			this._setViewProperty("Messages", []);
			this._setViewProperty("validation/isAuthPackNameEmpty", false);
			this._setViewProperty("validation/isAuthPackNameDuplicate", false);
		},

		_setAuthPackInvalid: function () {
			this._setViewProperty("isAuthPackValid", false);
		},

		_setAuthPackValid: function () {
			this._setViewProperty("isAuthPackValid", true);
		},

		_showErrorAuthPackInvalid: function () {
			this._setAuthPackInvalid();
		},

		_showWarningSimilarAuthPacks: function () {
			var oButton = this._getMessagePopoverButton();
			this._createMessagePopover();
			setTimeout(function () {
				this.oMP.toggle(oButton);
			}.bind(this), 100);
		},

		_isValidAuthPackage: function () {
			return this._isValidAuthPackName() && !this._isEmptyAuthorizations();
		},

		_getSimilarAuthPackages: function () {
			var oModel = this._getAuthPackModel();
			var oAuthObj = [];
			this._setSimilarAuthPacksAvailable(false);
			this._getAuthList().forEach(function (o) {
				if (o.TempSelected) {
					if (o.Customers) {
						o.Customers.forEach(function (cust) {
							oAuthObj.push(cust);
						});
					}

					if (o.Installations) {
						o.Installations.forEach(function (install) {
							oAuthObj.push(install);
						});
					}
					
					if ((!o.Installations || !o.Installations.length) && (!o.Customers || !o.Customers.length)){
					    oAuthObj.push(o);
					}
				}
			});

			oAuthObj.forEach(function (i) {
				delete i.__metadata;
				delete i.AuthObjectAuthLevelF4HelpSet;
				delete i.AuthObjectAuthLevelSet;
			});

			var oPromise = new Promise(function (resolve, reject) {
				oModel.setUseBatch(true);
				oModel.callFunction("/GetSimilarAuthPkgsByAuthObjects", {
					method: "GET",
					urlParameters: {
						AuthorizationObjects: JSON.stringify(oAuthObj)
					},
					success: resolve,
					error: reject
				});
			});
			oPromise.finally(function () {
				oModel.setUseBatch(false);
			});
			return oPromise;
		},

		_createMessagePopover: function () {
			if (!this.oMP) {
				var oLink = new Link({
					text: "{linkText}",
					press: function () {
						// this._getSimilarAuthPackages().then(function (aList) {
						var aSimilarAuthPackages = this._getViewProperty("similarAuthPackages");
						this._oDialogs.getDialog("SimilarAuthPacks")
							.setProperty("List", aSimilarAuthPackages)
							.syncStyleClass()
							.open(this);
						// });
					}.bind(this)
				});

				var oMessageTemplate = new MessageItem({
					type: "{type}",
					title: "{title}",
					description: "{description}",
					subtitle: "{subtitle}",
					link: oLink
				});

				this.oMP = new MessagePopover({
					items: {
						path: "/",
						template: oMessageTemplate
					}
				});
				var oData = [];
				var oOMPModel = new sap.ui.model.json.JSONModel(oData);
				this.oMP.setModel(oOMPModel);
				this._getMessagePopoverButton().addDependent(this.oMP);
			}

			this._updateMessages();
		},

		_updateMessages: function () {
			var aMessages = [],
				isEmptyName = this._isEmptyAuthPackName(),
				isEmptyAuth = this._isEmptyAuthorizations(),
				isDuplicateName = this._isDuplicateAuthPackName(),
				isSimilarAuthPacksAvailable = this._isSimilarAuthPacksAvailable(),
				isNameChecked = this._getViewProperty("isInputChanged"),
				isAuthChecked = this._getViewProperty("isAuthChanged");
			this._updateAuthPackNameValueStateText();
			this._updateAuthPackNameValueState();

			if (isNameChecked && isEmptyName) {
				aMessages.push({
					type: sap.ui.core.MessageType.Error,
					title: this.getText("MESSAGE_CREATE_AUTH_PACK_EMPTY_NAME"),
					subtitle: this.getText("MESSAGE_CREATE_AUTH_PACK_NAME_SUBTITLE")
				});
			}

			if (isAuthChecked && isEmptyAuth) {
				aMessages.push({
					type: sap.ui.core.MessageType.Error,
					title: this.getText("MESSAGE_CREATE_AUTH_PACK_EMPTY_AUTH"),
					subtitle: this.getText("MESSAGE_CREATE_AUTH_PACK_SIMILAR_EXISTS_SUBTITLE")
				});
			}

			if (isDuplicateName) {
				aMessages.push({
					type: sap.ui.core.MessageType.Error,
					title: this.getText("MESSAGE_CREATE_AUTH_PACK_DUPLICATE_NAME"),
					subtitle: this.getText("MESSAGE_CREATE_AUTH_PACK_NAME_SUBTITLE"),
					description: this.getText("MESSAGE_CREATE_AUTH_PACK_DUPLICATE_NAME_DESCRIPTION")
				});
			}

			if (isSimilarAuthPacksAvailable) {
				this._setViewProperty("isInfoMessage", true);
				aMessages.push({
					type: sap.ui.core.MessageType.Warning,
					title: this.getText("MESSAGE_CREATE_AUTH_PACK_SIMILAR_EXISTS_TITLE"),
					subtitle: this.getText("MESSAGE_CREATE_AUTH_PACK_SIMILAR_EXISTS_SUBTITLE"),
					description: this.getText("MESSAGE_CREATE_AUTH_PACK_SIMILAR_EXISTS_DESCRIPTION"),
					linkText: this.getText("MESSAGE_CREATE_AUTH_PACK_SIMILAR_EXISTS_LINK")
				});
			}

			this._setTypeOfMessagePopoverBtn();
			this._setErrorMessageIcon();

			this._setViewProperty("Messages", aMessages);
			if (this.oMP) {
				this.oMP.getModel().setProperty("/", aMessages);
				if (aMessages.length > 1) {
					this.oMP.navigateBack();
				}
			}
		},

		_getMessagePopoverButton: function () {
			return this.getView().byId("CreateAP-messagePopoverBtn");
		},

		_getAuthList: function () {
			return this._getViewProperty("AuthList");
		},

		_getAuthPackModel: function () {
			return this.getView().getModel("ap");
		},

		_createAuthPackObject: function () {
			var oObject = {
				Text: this._getViewProperty("AuthPackName"),
				Protected: this._getViewProperty("Protection")
			};
			return oObject;
		},

		_isValidAuthPackName: function () {
			return !this._getViewProperty("isInputChanged") || (!this._isEmptyAuthPackName() && !this._isDuplicateAuthPackName());
		},

		_isEmptyAuthPackName: function () {
			return !this._getViewProperty("AuthPackName").length > 0;
		},

		_isEmptyAuthorizations: function () {
			var isEmpty = true;
			this._getAuthList().forEach(function (item) {
				if (item.TempSelected) {
					isEmpty = false;
				}
			});
			return isEmpty;
		},

		_isDuplicateAuthPackName: function () {
			//return this._checkDuplicateName();
			return this._getViewProperty("validation/isAuthPackNameDuplicate");
		},

		_checkDuplicateName: function() {
			return Util.promiseRead.call(this, PATH_AUTH_PACKAGES, {
				filters: [new sap.ui.model.Filter("Text", sap.ui.model.FilterOperator.EQ, this._getViewProperty("AuthPackName"))]
			}, "ap")
			.then(function (oData) {
				var aAuthPackList = oData && oData.results || [];
				if (aAuthPackList.length > 0) {
					this._setViewProperty("validation/isAuthPackNameDuplicate", true);
				} else {
					this._setViewProperty("validation/isAuthPackNameDuplicate", false);
				}
			}.bind(this));
		},
		
		_setTypeOfMessagePopoverBtn: function () {
			if (this._isValidAuthPackage()) {
				if (this._isSimilarAuthPacksAvailable()) {
					this._setViewProperty("MessagePopoverBtnType", sap.m.ButtonType.Critical);
				}
			} else {
				this._setViewProperty("MessagePopoverBtnType", sap.m.ButtonType.Negative);
			}
		},

		/**
		 * Attach EventBus event
		 * @param {string} sEventName event name
		 * @param {function} fnHander event handler
		 * @function
		 * @private
		 */
		_attachBusEvent: function (sEventName, fnHander) {
			this.getOwnerComponent().getEventBus().subscribe("CreateAP", sEventName, fnHander);
		},
		/**
		 * Handle top level change for auth in detailed assign
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleDetailAuthTopLevelChange: function (bKeepDetails) {
			var oAuth = this._getViewProperty("AuthLevel");
			if (oAuth) {
				this._handleAuthorizationObjectSelectChange(oAuth, bKeepDetails);
				if (!this._isEmptyAuthorizations()) {
					this._showSimilarPackages();
				} else {
					this._setSimilarAuthPacksAvailable(false);
					this._updateMessages();
				}
			}
		},

		_createAuthPackage: function () {
			var oModel = this._getAuthPackModel();
			var oEntry = this._createAuthPackObject();
			var authList = this._getAuthList();
			this.setBusy(true);
			var that = this;
			Util.promiseCreate(PATH_AUTH_PACK_FOR_CUSTSET, oEntry, {}, oModel)
				.then(function (oData) {
					var sBatchGroupId = "idPackAuthObjAssignGroup";
					var authPackId = oData.AuthPackId.match(/\d/g).join("");
					oModel.setUseBatch(true);
					oModel.setDeferredBatchGroups([sBatchGroupId]);
					authList.forEach(function (auth) {
						that._saveSingleAuth(authPackId, sBatchGroupId, oModel, auth);
					});
					Util.promiseSubmitChanges({
							batchGroupId: sBatchGroupId
						}, oModel)
						.then(function (response) {
							if (Util.getBatchMessage(response) !== Constant.HTTP_REQUEST_FAILED && !Util.getBatchError(response)) {
								this._triggerBusEvent("createAuthPackRefresh");
								this.getRouter().navTo("UA_main_tab", {}, false);
								that._initAuthorizations();
								sap.m.MessageToast.show(this.getText("MESSAGE_CREATE_AUTH_PACK_SUCCESS"));
							} else {
								//sap.m.MessageToast.show(Util.getBatchError(response));
							}
							this.setBusy(false);
						}.bind(that));
				}).catch(function (oError) {
					that.setBusy(false);
					if (oError.statusCode === 400) {
						that._setViewProperty("validation/isAuthPackNameDuplicate", true);
						that._updateAuthPackNameValueState();
						that._updateAuthPackNameValueStateText();
						that._updateMessages();
						that._showWarningSimilarAuthPacks();
					}
				});
		},

		/**
		 * Update single authorization in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oAuth authorization to update
		 * @function
		 * @private
		 */
		_saveSingleAuth: function (authPackId, sGroupId, oModel, oAuth) {
			if (!/^G_/.test(oAuth.ObjectId)) { // Skip group items
				if (!oAuth.TempSelected || oAuth.TempCurrentAuthLevel === Constant.AuthLevel.FULL) { // top level auth
					var sPath = jQuery.sap.formatMessage("/AuthObjectSet(PackageId='''',ObjectId=''{0}'')", [oAuth.ObjectId]),
						oData = jQuery.extend(true, {}, oModel.getProperty(sPath));
					oData.Selected = oAuth.TempSelected;
					oData.PackageId = authPackId;
					Util.deleteODataExtensions(oData); // because {__list: [...]} causes an error
					oModel.update(sPath, oData, {
						batchGroupId: sGroupId
					});
				} else if (oAuth.TempChanges) {
					if (oAuth.Customers && this.formatter.detail.isAuthTopLevelCCC(oAuth.TopLevel)) {
						oAuth.Customers.map(function (oCust) {
							return jQuery.extend({}, oCust, {
								AuthLevelType: "DEBITOR",
								PackId: authPackId
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
					if (oAuth.Installations && this.formatter.detail.isInstallationsTableVisible(oAuth.AuthLevelId)) {
						oAuth.Installations.map(function (oInst) {
							return jQuery.extend({}, oInst, {
								AuthLevelType: oAuth.AuthLevelId,
								PackId: authPackId
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
				}
			}
		},

		/**
		 * Update single authorization level in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oLevel level
		 * @function
		 * @private
		 */
		_saveSingleAuthLevel: function (sGroupId, oModel, oLevel) {
			var sPath = jQuery.sap.formatMessage(
					"/AuthObjectLevelSet(PackId=''{0}'',ObjectId=''{1}'',AuthLevel=''{2}'',AuthLevelType=''{3}'')", [
						oLevel.PackId, oLevel.ObjectId, oLevel.AuthLevel, oLevel.AuthLevelType
					]),
				oData = jQuery.extend(true, {
					AuthLevel: oLevel.AuthLevel,
					AuthLevelType: oLevel.AuthLevelType,
					ObjectId: oLevel.ObjectId,
					PackId: oLevel.PackId
				}, oModel.getProperty(sPath));

			oData.IsAssigned = true;
			oModel.update(sPath, oData, {
				batchGroupId: sGroupId
			});
		},

		_isSimilarAuthPacksAvailable: function () {
			return this._getViewProperty("isSimilarAuthPacksAvailable");
		},

		_setSimilarAuthPacksAvailable: function (bVal) {
			this._setViewProperty("isSimilarAuthPacksAvailable", bVal);
		},

		_updateAuthPackNameValueStateText: function () {
			if (this._isEmptyAuthPackName()) {
				this._setViewProperty("AuthPackNameValueStateText", this.getText("MESSAGE_CREATE_AUTH_PACK_EMPTY_NAME"));
			}
			if (this._isDuplicateAuthPackName()) {
				this._setViewProperty("AuthPackNameValueStateText", this.getText("MESSAGE_CREATE_AUTH_PACK_DUPLICATE_NAME"));
			}
		},

		_updateAuthPackNameValueState: function () {
			var isAuthPackNameValid = this._isValidAuthPackName();
			this._setViewProperty("validation/isAuthPackNameValid", isAuthPackNameValid);
		},
		
		_setErrorMessageIcon: function () {
			if (this._getViewProperty("MessagePopoverBtnType") === sap.m.ButtonType.Negative) {
				this._setViewProperty("errorMessageIcon", "sap-icon://message-error");
			}
			else {
				this._setViewProperty("errorMessageIcon", "sap-icon://message-warning");
			}
		},
		
		_triggerBusEvent: function (sEventName) {
			this.getOwnerComponent().getEventBus().publish("CreateAuthPack", sEventName);
		},
		
		_countAuth: function (aAuthList) {
			var iCount = 0;
			for (var i = 0; i < aAuthList.length; i++) {
				if (!/^G_/.test(aAuthList[i].ObjectId)) { // Skip group items
					iCount++;
				}
			}
			return iCount;
		}
	});
});
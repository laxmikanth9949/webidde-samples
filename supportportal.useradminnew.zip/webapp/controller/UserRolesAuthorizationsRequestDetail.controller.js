sap.ui.define([
	"sap/support/useradministration/controller/BaseController",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	
	"sap/support/useradministration/extended/HashChecker"
	], function (BaseController, Constant, Util, HashChecker) {
	"use strict";
	
	var REQUEST_DETAIL_ROUTE = "userRolesAuthorizationsRequestDetail",
		REQUEST_AUTH_ASSIGN_ROUTE = "requestAuthorizationAssign",
		USER_DETAIL_VIEW_ROUTE = "userDetailView";
		
	var EVENT_BUS_NAME = "RequestDetail";
	
	var PROP_LIST = "AuthObjects",
		PROP_EDIT = "Auth/Edit",
		PROP_ACCEPTABLE = "Acceptable";
		
	var History = sap.ui.core.routing.History,
		HistoryDirection = sap.ui.core.routing.HistoryDirection;
		
	return BaseController.extend("sap.support.useradministration.view.UserRolesAuthorizationsRequestDetail", {
		_oHistory: History.getInstance(),
		
		onInit: function() {
			this._oHashChecker = new HashChecker(this.getRouter());
			this.getRouter().getRoute(REQUEST_DETAIL_ROUTE).attachPatternMatched(this._onRouteMatched, this);
			
			this._bindViewModel(EVENT_BUS_NAME);
		},
		
		_onRouteMatched: function (oEvent) {
			var requestId = oEvent.getParameters().arguments.requestId;
			
			if (this._getViewProperty(PROP_EDIT) && this._oHistory.getDirection() === HistoryDirection.Backwards) {
				var sPreviousHash = this._oHistory.aHistory[this._oHistory.iHistoryPosition + 1],
					sRouteName = sPreviousHash && this._oHashChecker.getMatchedRouteName(sPreviousHash);
				
				if (sRouteName === USER_DETAIL_VIEW_ROUTE || sRouteName === REQUEST_AUTH_ASSIGN_ROUTE) {
					return;
				}
			}
			this._setViewProperty("RequestId", requestId);
			this.setBusy(true);
			this._loadRequestData(requestId);
		},

		/**
		 * Get extended copy of authorization object
		 * @param {object} oAuthObject authorization object
		 * @returns {object} extended object
		 * @function
		 * @private
		 */
		_extendAuthorizationObject: function (oAuthObject) {
			var oFormatter = this.formatter.detail;

			return Util.merge({
				Clusters: null, // List of clusters from detail assign; null if no changes at all
				Customers: null, // List of customers from detail assign
				Installations: null, // List of installations from detail assign,
				IsGroupHeader: /^G_/.test(oAuthObject.ObjectId),
				IsTopHeader: oAuthObject.ObjectId === Constant.AuthGroup.ALL,
				TempChanges: false, // Has changes in detail assign
				TempCurrentAuthLevel: oAuthObject.CurrentAuthLevel,
				TempSelected: oFormatter.isAuthorizationSelected(oAuthObject.CurrentAuthLevel)
			}, oAuthObject);
		},

		/**
		 * Get authorization list
		 * @returns {object[]} list
		 * @function
		 * @private
		 */
		_getAuthorizationList: function () {
			return this._getViewProperty(PROP_LIST) || [];
		},
		
		_getAuthObjList: function (sObjects) {
			return sObjects.split(",").map(function (sAuthObjectId) {
				return {
					RequestAuthObjId: sAuthObjectId,
					Acceptable: false
				};
			});
		},
		
		/**
		 * Get current user's ID
		 * @returns {string} id
		 * @function
		 * @public
		 */
		_getUserId: function () {
			return this._getViewProperty("Auth/User/Susid");
		},
		
		/**
		 * Handle selection change for auth object
		 * Change its data according to selected state
		 * Propagate selected state to group(s) if needed
		 * @param {object} oAuth authorization object
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleAuthorizationObjectSelectChange: function (oAuth, bKeepDetails) {
			oAuth.TempChanges = bKeepDetails;
			
			if (bKeepDetails) {
				oAuth.TempSelected = Boolean((oAuth.Clusters && oAuth.Clusters.length) || (oAuth.Customers && oAuth.Customers.length) ||
					(oAuth.Installations && oAuth.Installations.length));
				oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.RESTRICTED : Constant.AuthLevel.EMPTY;
			} else {
				oAuth.TempCurrentAuthLevel = oAuth.TempSelected ? Constant.AuthLevel.FULL : Constant.AuthLevel.EMPTY;
				oAuth.Clusters = [];
				oAuth.Customers = [];
				oAuth.Installations = [];
			}
			
			this._updateAuthorizationListChanges();
		},

		/**
		 * Handle top level change for auth in detailed assign
		 * @param {boolean} bKeepDetails don't clear details (cluster, customers, installations)
		 * @function
		 * @private
		 */
		_handleDetailAuthTopLevelChange: function (bKeepDetails) {
			var oAuth = this._getViewProperty("Auth/Detail");
			if (oAuth) {
				this._handleAuthorizationObjectSelectChange(oAuth, bKeepDetails);
			}
		},
		
		/**
		 * Load request data
		 * @param {string} sRequestId request ID
		 * @function
		 * @private
		 */
		_loadRequestData: function (sRequestId) {
			var oParams = {
				filters: [new sap.ui.model.Filter("RequestId", sap.ui.model.FilterOperator.EQ, sRequestId)]
			};
			
			Util.promiseRead.call(this, "/AuthorizationRequestSet", oParams)
				.then(this._processRequestData.bind(this))
				.then(this._loadUserData.bind(this))
				.then(this._processUserData.bind(this))
				.finally(this.setBusy.bind(this, false));
		},
		
		/**
		 * Load user data
		 * @param {string} sUserId user ID
		 * @returns {Promise} promise
		 * @function
		 * @private
		 */
		_loadUserData: function (sUserId) {
			return Util.promiseRead.call(this, Util.formatMessage("/UserSet(''{0}'')", [sUserId]), {
				urlParameters: {
					"$expand": "UserAuthObjectSet"
				}
			});
		},
		
		/**
		 * Process Request's backend data
		 * @param {object} oData data
		 * @returns {string} request's user ID
		 * @function
		 * @private
		 */
		_processRequestData: function (oData) {
			var oRequest = (oData.results && oData.results[0]) || {};
			this._setViewProperty(PROP_ACCEPTABLE, false);
			this._setViewProperty("App", oRequest.TileId);
			this._setViewProperty(PROP_LIST, this._getAuthObjList(oRequest.AuthObjId));
			this._setViewProperty("ChangedOn", oRequest.ChangedAt);
			this._setViewProperty("CreatedOn", oRequest.CreatedAt);
			this._setViewProperty("Desc", oRequest.Description);
			this._setViewProperty("RequestedLevels", this._getAuthObjList(oRequest.AuthObjId));
			this._setViewProperty("Status", oRequest.Status);
			this._setViewProperty("System", oRequest.SrcSys);
			this._setViewProperty("UserId", oRequest.UserId);
			
			return oRequest.UserId;
		},
		
		/**
		 * Process Request User's backend data
		 * @param {object} oData data
		 * @function
		 * @private
		 */
		_processUserData: function (oData) {
			var oUserInfo = oData || {},
				aUsersAuthorizationList = oUserInfo.UserAuthObjectSet && oUserInfo.UserAuthObjectSet.results || [];
			
			this._setViewProperty("Auth/User", oUserInfo);
			this._updateAuthorizationStatuses(aUsersAuthorizationList);
		},

		/**
		 * Update single authorization in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oAuth authorization to update
		 * @function
		 * @private
		 */
		_saveSingleAuth: function (sGroupId, oModel, oAuth) {
			if (!/^G_/.test(oAuth.ObjectId)) { // Skip group items
				if (!oAuth.TempSelected || oAuth.TempCurrentAuthLevel === Constant.AuthLevel.FULL) { // top level auth
					var sPath = jQuery.sap.formatMessage("/AuthObjectSet(UserId=''{0}'',ObjectId=''{1}'')", [oAuth.UserId, oAuth.ObjectId]),
						oData = jQuery.extend(true, {}, oModel.getProperty(sPath));
					oData.Selected = oAuth.TempSelected;
					delete oData.AuthObjectAuthLevelSet; // because {__list: [...]} causes an error
					oModel.update(sPath, oData, {
						batchGroupId: sGroupId
					});
				} else if (oAuth.TempChanges) {
					if (oAuth.Customers && this.formatter.detail.isAuthTopLevelCCC(oAuth.TopLevel)) {
						oAuth.Customers.map(function (oCust) {
							return jQuery.extend({}, oCust, {
								AuthLevelType: "DEBITOR"
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
					if (oAuth.Installations && this.formatter.detail.isInstallationsTableVisible(oAuth.AuthLevelId)) {
						oAuth.Installations.map(function (oInst) {
							return jQuery.extend({}, oInst, {
								AuthLevelType: oAuth.AuthLevelId
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
					if (oAuth.Clusters) {
						oAuth.Clusters.map(function (oClust) {
							return jQuery.extend({}, oClust, {
								AuthLevel: oClust.AuthLevelDesc,
								AuthLevelType: oClust.AuthLevelDesc
							});
						}).forEach(this._saveSingleAuthLevel.bind(this, sGroupId, oModel));
					}
				}
			}
		},

		/**
		 * Update single authorization level in the model
		 * @param {string} sGroupId batch group ID for batch save request
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @param {object} oLevel level
		 * @function
		 * @private
		 */
		_saveSingleAuthLevel: function (sGroupId, oModel, oLevel) {
			var sPath = jQuery.sap.formatMessage("/AuthObjectLevelSet(UserId=''{0}'',ObjectId=''{1}'',AuthLevel=''{2}'',AuthLevelType=''{3}'')", [
					oLevel.UserId, oLevel.ObjectId, oLevel.AuthLevel, oLevel.AuthLevelType
				]),
				oData = jQuery.extend(true, {
					AuthLevel: oLevel.AuthLevel,
					AuthLevelType: oLevel.AuthLevelType,
					ObjectId: oLevel.ObjectId,
					UserId: oLevel.UserId
				}, oModel.getProperty(sPath));

			oData.IsAssigned = true;
			oModel.update(sPath, oData, {
				batchGroupId: sGroupId
			});
		},
		
		/**
		 * Set acceptable state for Requested authorization
		 * @param {object} oRequestedAuth Requested authorization
		 * @function
		 * @private
		 */
		_setAcceptableState: function (oRequestedAuth) {
			var sCurrentLevel = oRequestedAuth.TempCurrentAuthLevel;
			
			oRequestedAuth.Acceptable = this.formatter.detail.isAuthorizationSelected(sCurrentLevel);
		},

		/**
		 * Update authorization list local changes (made without setProperty)
		 * @function
		 * @private
		 */
		_updateAuthorizationListChanges: function () {
			var aList = this._getAuthorizationList() || [];
			
			aList.forEach(this._setAcceptableState.bind(this));
			
			this._setViewProperty(PROP_LIST, aList);
			this._setViewProperty(PROP_ACCEPTABLE, !aList.some(function (oItem) {
				return !oItem.Acceptable;
			})); 
		},
		
		/**
		 * Update statuses of requested authorizations
		 * @param {object[]} aUsersAuthorizations user's current authorizations
		 * @function
		 * @private
		 */
		_updateAuthorizationStatuses: function (aUsersAuthorizations) {
			var aRequestedAuthorizations = this._getViewProperty(PROP_LIST),
				oUsersAuthorizationsByObjectId = Util.mapBy(aUsersAuthorizations, "ObjectId");
				
			aRequestedAuthorizations.forEach(function (oRequestedAuth) {
				var sAuthId = oRequestedAuth.RequestAuthObjId,
					oCurrentAuth = oUsersAuthorizationsByObjectId[sAuthId];
					
				if (oCurrentAuth) {
					Util.merge(oRequestedAuth, this._extendAuthorizationObject(oCurrentAuth));
				}
			}.bind(this));
			
			this._updateAuthorizationListChanges();
		},
		
		onAuthorizationObjectPress: function (oEvent) {
			var oAuth = oEvent.getSource().getBindingContext("view").getObject();
			this._setViewProperty("Auth/Detail", oAuth);
			var UserId = this._getViewProperty("UserId");
			var RequestId = this._getViewProperty("RequestId");
			this.getRouter().navTo(REQUEST_AUTH_ASSIGN_ROUTE, {
					user: UserId,
					object: oAuth.RequestAuthObjId,
					requestId: RequestId
				}, /* bReplace= */ false);
		}
	});
});
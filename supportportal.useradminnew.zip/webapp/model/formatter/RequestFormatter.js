sap.ui.define([
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/model/formatter/DetailFormatter",
	"sap/support/useradministration/model/Formatter"
	
], function (Constant, Util, DetailFormatter, Formatter) {

	var IconColor = sap.ui.core.IconColor,
		ValueState = sap.ui.core.ValueState,
		
		TypeOfRequest = Constant.TypeOfRequest;
	
	/**
	 * A formatter for authorization and expiration requests
     * Naming rules:
     * 
     * is* - boolean value
     * *Count / Number - numeric value
     * *IconColor - sap.ui.core.IconColor value
     * *Link - a string value used as a link
     * *MessageType - sap.ui.core.MessageType value
     * *String - a string value not used as a control text or used to construct a control text
     * *Text - a string value used as a control text
     * *URI - URI for icons
     * *ValueState - sap.ui.core.ValueState value
	 */
	var RequestFormatter = {
		
		/**
		 * Get color for authorization's icon
		 * @param {boolean} bIsReady if authorization is ready
		 * @returns {sap.ui.core.IconColor} icon color
		 * @function
		 * @public
		 */
		authorizationIconColor: function (bIsReady) {
			return bIsReady ? IconColor.Positive : IconColor.Negative;
		},
		
		/**
		 * Get URI for authorization's icon
		 * @param {boolean} bIsReady if authorization is ready
		 * @returns {sap.ui.core.URI} icon URI
		 * @function
		 * @public
		 */
		authorizationIconURI: function (bIsReady) {
			return bIsReady ? "sap-icon://accept" : "sap-icon://decline";
		},
		
		/**
		 * Get value state text for Expiry Date input
		 * @param {boolean} bIsDateOverRange if expiry date is valid but over range
		 * @param {int} iMaxYears max years to extend
		 * @returns {string} text
		 * @function
		 * @public
		 */
		invalidExpiryDateValueStateText: function (bIsDateOverRange, iMaxYears) {
			if (bIsDateOverRange) {
				return Util.getText.call(this, "MESSAGE_INVALID_EXPIRY_DATE", [iMaxYears]);
			} else {
				return Util.getText.call(this, "MESSAGE_PLEASE_ENTER_A_VALID_DATE");
			}
		},
		
		/**
		 * Check if request can be approved
		 * @param {string} sStatus status
		 * @param {boolean} bAcceptable if request is acceptable
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isAcceptableRequest: function (sStatus, bAcceptable) {
			return !!bAcceptable && RequestFormatter.isOpenRequest(sStatus);
		},
		
		/**
		 * Check if request type is Manage Expiry Date
		 * @param {string} sTypeOfRequest type of request
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isExpiryRequest: function (sTypeOfRequest) {
			return sTypeOfRequest === TypeOfRequest.EXPIRY_DATE;
		},
		
		/**
		 * Check if request status is open
		 * @param {string} sStatus status
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isOpenRequest: function (sStatus) {
			return sStatus === "O";
		},
		
		/**
		 * Check if request status is open
		 * @param {string} sStatus status
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isNavigatableAuthsList: function (sStatus) {
			return (RequestFormatter.isRequestNotReject(sStatus)) ? sap.m.ListType.Navigation : sap.m.ListType.Inactive;
		},
		
		/**
		 * Get authorization status for Request Detail
		 * @param {string} sCurrentAuthLevel current auth level
		 * @param {string} sAuthLevelId current auth level id
		 * @param {string} sTopLevel top level property
		 * @returns {string} status text
		 * @function
		 * @public
		 */
		authorizationStatusForRequestDetail: function (sCurrentAuthLevel, sAuthLevelId, sTopLevel, sStatus) {
			var sText = DetailFormatter.authorizationStatus.call(this, sCurrentAuthLevel, sAuthLevelId, sTopLevel);
			if (sText) {
				return sText;
			} 
			return (RequestFormatter.isOpenRequest(sStatus)) ? Util.getText.call(this, "DETAIL_PLEASE_SELECT_LEVEL_FOR_AUTH") : "";
		},
		
		/**
		 * Format mailto link with subject for authorization request's creator
		 * @param {string} sEmail e-mail address
		 * @returns {string} link
		 * @function
		 * @public
		 */
		mailToAuthorizationRequestLink: function (sEmail) {
			return sEmail ? "mailto:" + sEmail + "?subject=Authorization Request" : "";
		},
		
		/**
		 * Get text for request title according to its type
		 * @param {string} sTypeOfRequest type of request
		 * @returns {string} text
		 * @function
		 * @public
		 */
		requestTypeTitleText: function (sTypeOfRequest) {
			switch (sTypeOfRequest) {
				case TypeOfRequest.AUTHORIZATION:
					return Util.getText.call(this, "AUTH_REQUEST");
				case TypeOfRequest.EXPIRY_DATE:
					return Util.getText.call(this, "TITLE_MANAGE_EXPIRY_DATE");
				default:
					return sTypeOfRequest;
			}
		},
		
		/**
		 * Get text for message after rejecting request title according to its type
		 * @param {string} sTypeOfRequest type of request
		 * @returns {string} text
		 * @function
		 * @public
		 */
		requestTypeRejectionMessageText: function (sTypeOfRequest) {
			switch (sTypeOfRequest) {
				case TypeOfRequest.AUTHORIZATION:
					return Util.getText.call(this, "MESSAGE_AUTH_REQ_REJECTED");
				case TypeOfRequest.EXPIRY_DATE:
					return Util.getText.call(this, "MESSAGE_EXPIRY_REQ_REJECTED");
				default:
					return Util.getText.call(this, "MESSAGE_REQ_REJECTED");
			}
		},
		
		/**
		 * Format full address
		 * @param {string} sStreet street
		 * @param {string} sAddress address
		 * @param {string} sCity city
		 * @param {string} sCountry country
		 * @returns {string} full address
		 * @function
		 * @public
		 */
		streetAddressCityCountryText: function (sStreet, sAddress, sCity, sCountry) {
			return Util.formatMessage("{0}, {1} {2}, {3}", [sStreet, sAddress, sCity, sCountry]);
		},
		
		/**
		 * Format requested task status`s color
		 * @param {string} sStatus status field
		 * @returns {sap.ui.core.ValueState} formatted status's color
		 * @function
		 * @public
		 */
		taskColorStatus: function (sStatus) {
			return {
				O: ValueState.Warning,
				R: ValueState.Error,
				A: ValueState.Success
			}[sStatus] || ValueState.None;
		},
		
		/**
		 * Format requested task status
		 * @param {string} sStatus status field
		 * @returns {string} formatted status text
		 * @function
		 * @public
		 */
		taskTextStatus: function (sStatus) {
			switch (sStatus) {
				case "O":
					return Util.getText.call(this, "MASTER_TASK_AWAITING_APPROVAL");
				case "C":
					return Util.getText.call(this, "MASTER_TASK_CANCELED");
				case "R":
					return Util.getText.call(this, "MISC_REJECTED");
				case "A":
					return Util.getText.call(this, "MASTER_TASK_APPROVED");
				default:
					return Util.getText.call(this, "MASTER_TASK_UNNOWN");
			}
		},
		
		taskStatusTooltip: function (sStatus) {
			switch (sStatus) {
				case "O":
					return Util.getText.call(this, "MASTER_TOOLTIP_AWAITING_APPROVAL");
				case "C":
					return Util.getText.call(this, "MASTER_TASK_CANCELED");
				case "R":
					return Util.getText.call(this, "MASTER_TOOLTIP_REJECTED");
				case "A":
					return Util.getText.call(this, "MASTER_TOOLTIP_APPROVED");
				default:
					return Util.getText.call(this, "MASTER_TASK_UNNOWN");
			}
		},
		
		/**
		 * @param {string} sStatus status field
		 * @returns {boolean} 
		 * @function
		 * @public
		 */
		isRequestOpen: function (sStatus) {
			return sStatus === "O";
		},
		
		/**
		 * @param {string} sStatus status field
		 * @returns {boolean} 
		 * @function
		 * @public
		 */
		isRequestNotOpen: function (sStatus) {
			return sStatus !== "O";
		},
		
		/**
		 * @param {string} sStatus status field
		 * @returns {boolean} 
		 * @function
		 * @public
		 */
		isRequestNotReject: function (sStatus) {
			return sStatus !== "R";
		},
		/**
		 * @param {string} sStatus status field
		 * @returns {boolean} 
		 * @function
		 * @public
		 */
		isRequestReject: function (sStatus) {
			return sStatus === "R";
		},
		
		/**
		 * @param {string} sStatus status field
		 * @returns {boolean} 
		 * @function
		 * @public
		 */
		isRequestNotApproved: function (sStatus) {
			return sStatus !== "A";
		},
		
		/**
		 * Format date or Reject string
		 * @param {string|Date} sDate backend date
		 * @param {string} sStatus status field
		 * @returns {string} formatted date or Reject string
		 * @function
		 * @public
		 */
		dateOrReject: function (sDate, sStatus) {
			return sStatus === "R" ? Util.getText.call(this, "MISC_REJECTED") : this.formatter.dateOrEmpty(sDate);
		},
		
		validationEmailText: function (bDomainCheckEnabled, sValidationEmailText) {
			return bDomainCheckEnabled ? "" : sValidationEmailText;
		},

		/**
		 * Get enhanced combobox item type by auth level
		 * @param {string} sLevel User's current auth level
		 * @returns {string} Type of enhanced combobox item
		 * @function
		 * @public
		 */
		getComboboxItemTypeByLevel: function(sLevel){
			switch(sLevel){
				case Constant.AuthLevel.FULL:
				  return Constant.ComboboxItemType.DISABLED_WITH_MARK;
				case Constant.AuthLevel.REQUESTED:
				  return Constant.ComboboxItemType.DISABLED_PENDING;
				case Constant.AuthLevel.RESTRICTED:
				  return Constant.ComboboxItemType.ENABLED_WITH_MARK;
				default:
				  return Constant.ComboboxItemType.ENABLED;
			}
		},

		/**
		 * Get enhanced combobox tooltip by auth level
		 * @param {string} sLevel User's current auth level
		 * @returns {string} Tooltip text
		 * @function
		 * @public
		 */
		getComboboxTooltipByLevel: function(sLevel) {
			switch(sLevel){				
				case Constant.AuthLevel.FULL:
					// this.getModel("i18n")?.getResourceBundle().getText("RequestFormatter.AuthorizationAssigned")
				  return Util.getText.call(this, "RequestFormatter.AuthorizationAssigned");
				case Constant.AuthLevel.REQUESTED:
					// this.getModel("i18n")?.getResourceBundle().getText("RequestFormatter.AuthorizationRequested")
				  return Util.getText.call(this, "RequestFormatter.AuthorizationRequested");
				case Constant.AuthLevel.RESTRICTED:
					// this.getModel("i18n")?.getResourceBundle().getText("RequestFormatter.AuthorizationRestricted")
				  return Util.getText.call(this, "RequestFormatter.AuthorizationRestricted");
				default:
				  return "";
			}
		}
	};
	
	return RequestFormatter;
});
sap.ui.define([
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/util/Settings"
], function (Constant, Util, Settings) {
	var ALL_USERS = "AllUsers",
		REQUESTED_USERS = "RequestedUsers",
		DELETED_USERS = "DeletedUsers",
		IMPORTANT_CONTACTS = "ImportantContacts",
		AUTHORIZATION_PACKAGES_TAB = "AuthPackages",
		REPORTS_AND_UPDATES = "ReportsAndUpdates",
		TASKS = "Tasks";

	var ValueState = sap.ui.core.ValueState,
		ListType = sap.m.ListType;
        
	var RequestStatus = Constant.RequestStatus,
		UserExpirationStatus = Constant.UserExpirationStatus;

	/**
	 * Get i18n bundle
	 * @returns {sap.ui.model.resource.ResourceBundle} bundle
	 * @function
	 * @private
	 */
	var _getBundle = function () {
		return Util.getBundle.call(this);
	};

	/**
	 * Get i18n text
	 * @param {string} sKey key
	 * @param {any[]} aArgs arguments
	 * @returns {string} text
	 * @function
	 * @private
	 */
	var _getText = function (sKey, aArgs) {
		return _getBundle.call(this).getText(sKey, aArgs);
	};
	
	var MasterFormatter = {
		/**
		 * Format i18n All or None text if needed
		 * @param {string} sValue backend value
		 * @returns {string} text
		 * @function
		 * @pbulic
		 */
		allOrNoneText: function (sValue) {
			if (sValue === "All") {
				return Util.getText.call(this, "MISC_ALL");
			} else if (sValue === "None") {
				return Util.getText.call(this, "MASTER_NONE");
			}
			return sValue;
		},
		
		/**
		 * Get status text for authorization object
		 * @param {boolean} bGrantedAll if auth is granted for all
		 * @param {boolean} bRestricted if auth is restricted
		 * @param {string} sAuthLevelId authorization level
		 * @param {boolean} bRemoveMode whether the mode is remove
		 * @returns {string} status text
		 * @function
		 * @public
		 */
		authorizationStatusText: function (bGrantedAll, bRestricted, sAuthLevelId, bRemoveMode) {
			var sKey = "",
				oStatus = bRemoveMode ? Constant.AuthStatusTextRemove : Constant.AuthStatusText;
			if (bGrantedAll) {
				sKey = oStatus.full[sAuthLevelId];
			} else if (bRestricted) {
				sKey = oStatus.restricted[sAuthLevelId];
			}
			return sKey && Util.getText.call(this, sKey) || "";
		},

		/**
		 * Get title for restricted customers table
		 * @param {boolean} bRemoveMode whether the mode is remove
		 * @returns {string} title
		 * @function
		 * @public
		 */
		customersTableTitle: function (bRemoveMode) {
			return Util.getText.call(this, bRemoveMode ? "AUTH_OBJ_CUSTOMER_LEVEL_TITLE_REMOVED" : "AUTH_OBJ_CUSTOMER_LEVEL_TITLE");
		},
		
		/**
		 * Format deleted user status
		 * @param {string} sStatus status field
		 * @returns {string} formatted status
		 * @function
		 * @public
		 */
		deletedUserStatus: function (sStatus) {
			switch (sStatus) {
				case "D":
					return Util.getText.call(this, "MISC_DELETED");
				case "P":
					return Util.getText.call(this, "MISC_PENDING_DELETION");
				default:
					return "";
			}
		},
		
		deletedUserStatusState: function (sStatus) {
			return sStatus === "D" ? ValueState.Success : ValueState.None;
		},
		
		deletedUserStatusTooltip: function (sStatus) {
			switch (sStatus) {
				case "D":
					return Util.getText.call(this, "TOOLTIP_DELETED_USER_DELETED_STATUS");
				case "P":
					return Util.getText.call(this, "TOOLTIP_DELETED_USER_PENDING_STATUS");
				default:
					return "";
			}
		},
		
		/**
		 * Get value state for dept name input
		 * @param {string} sName dept name
		 * @returns {sap.ui.core.ValueState} Error for invalid name
		 * @function
		 * @public
		 */
		departmentValueState: function (sName) {
			return (!sName || MasterFormatter.isDepartmentNameValid(sName)) ? ValueState.None : ValueState.Error;
		},
		
		departmentIsEmptyState: function (sName, bEmpty) {
			return (!bEmpty && !sName || MasterFormatter.isDepartmentNameValid(sName)) ? ValueState.None : ValueState.Error;
		},

		/**
		 * Return true enabled state if reports list is not empty
		 * @param {int} iReportsNumber number of rports
		 * @returns {boolean} true if number is positive
		 * @function
		 * @public
		 */
		enabledForNonEmptyReportsList: function (iReportsNumber) {
			return iReportsNumber > 0;
		},

		/**
		 * Get text for full auth switch
		 * @param {string} sAuthLevelId auth level
		 * @param {boolean} bRemoveMode whether the mode is remove
		 * @returns {string} text
		 * @function
		 * @public
		 */
		fullAuthSwitchText: function (sAuthLevelId, bRemoveMode) {
			var oStatus = bRemoveMode ? Constant.AuthStatusTextRemove.full : Constant.AuthStatusText.full,
				sKey = oStatus[sAuthLevelId];

			return sKey ? Util.getText.call(this, sKey) : "";
		},

		/**
		 * Get row type for important contact user
		 * @param {string} sUserID User ID
		 * @returns {sap.m.ListType} row type
		 * @function
		 * @public
		 */
		importantContactUserRowType: function (sUserID) {
			return sUserID === "NA" ? ListType.Inactive : ListType.Navigation;
		},
		
		/**
		 * Get text for column in restricted installations table
		 * @param {boolean} bUserMode if Users mode is active
		 * @returns {string} text
		 * @function
		 * @public
		 */
		installationsTableColumnText: function (bUserMode) {
			return Util.getText.call(this, bUserMode ? "AUTHORIZATION_LEVEL_USER_NAME" : "AUTHORIZATION_LEVEL_INST_NAME");
		},

		/**
		 * Get tooltip for edit button in restricted installations table
		 * @param {boolean} bUserMode if Users mode is active
		 * @returns {string} text
		 * @function
		 * @public
		 */
		installationsTableEditButtonTooltip: function (bUserMode) {
			return Util.getText.call(this, bUserMode ? "BUTTON_USER_AUTH_ADD" : "BUTTON_INST_AUTH_ADD");
		},

		/**
		 * Get no data text for restricted installations table
		 * @param {boolean} bUserMode if Users mode is active
		 * @returns {string} text
		 * @function
		 * @public
		 */
		installationsTableNoDataText: function (bUserMode) {
			return Util.getText.call(this, bUserMode ? "AUTH_OBJ_NO_USER_AUTH_DATA_TEXT" : "AUTH_OBJ_NO_INST_AUTH_DATA_TEXT");
		},

		/**
		 * Get title for restricted installations table
		 * @param {boolean} bUserMode if Users mode is active
		 * @param {boolean} bRemoveMode whether the mode is remove
		 * @returns {string} title
		 * @function
		 * @public
		 */
		installationsTableTitle: function (bUserMode, bRemoveMode) {
			if (bRemoveMode) {
				return Util.getText.call(this, bUserMode ? "AUTH_OBJ_USER_LEVEL_TITLE_REMOVED" : "AUTH_OBJ_INST_LEVEL_TITLE_REMOVED");
			}
			return Util.getText.call(this, bUserMode ? "AUTH_OBJ_USER_LEVEL_TITLE" : "AUTH_OBJ_INST_LEVEL_TITLE");
		},
		
		/**
		 * Check if tab is any user list tab
		 * @param {string} sTabKey current tab key
		 * @returns {boolean} false if tab key is users, requested users and so on
		 * @function
		 * @public
		 */
		isAnyUserTab: function (sTabKey) {
			return [ALL_USERS, REQUESTED_USERS, DELETED_USERS, IMPORTANT_CONTACTS, TASKS, AUTHORIZATION_PACKAGES_TAB, REPORTS_AND_UPDATES].indexOf(sTabKey) !== -1;
		},

		/**
		 * Check if tab is Authorization Packages
		 * @param {string} sTabKey current tab key
		 * @returns {boolean} true if tab key is Authorization Packages
		 * @function
		 * @public
		 */
		isAuthorizationPackagesTab: function (sTabKey) {
			return sTabKey === AUTHORIZATION_PACKAGES_TAB;
		},
		
		/**
		 * Check if tab is Authorization Packages
		 * @param {string} sTabKey current tab key
		 * @param {boolean} bFlag flag
		 * @returns {boolean} true if tab key is Authorization Packages
		 * @function
		 * @public
		 */
		isAuthorizationPackagesTabAndTrue: function (sTabKey, bKey) {
			return !!bKey && sTabKey === AUTHORIZATION_PACKAGES_TAB;
		},

		/**
		 * Check if tab is Authorization Packages
		 * @param {string} sTabKey current tab key
		 * @returns {boolean} true if tab key is Authorization Packages
		 * @function
		 * @public
		 */
		isAuthorizationPackagesTabAndSuperAdmin: function (sTabKey) {
			var oUserFunction = this.oView.getParent().__function;
			
			if (sTabKey === AUTHORIZATION_PACKAGES_TAB && oUserFunction === "1SUPERADMIN") {
				return true;
			}
			else {
				return false;
			}
		},

		/**
		 * Check if authorization has a low-level assign
		 * @param {string} sAuthLevelId auth level id
		 * @returns {boolean} true if auth has a low-level assign
		 * @function
		 * @public
		 */
		isAuthWithLowLevel: function (sAuthLevelId) {
			return sAuthLevelId !== Constant.AuthLevelId.GLOBAL && sAuthLevelId !== Constant.AuthLevelId.GROUP;
		},

		/**
		 * Check if dept name is valid
		 * @param {string} sName dept name
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isDepartmentNameValid: function (sName) {
			return /^[\w \.\-\/]+$/.test(sName);
		},
		
		/**
		 * Check if Manage Department NEW button is visible
		 * @param {string} sTabKey current tab key
		 * @param {boolean} bNewDepartmentAPIEnabled if new Department API is enabled
		 * @returns {boolean} visible state
		 * @function
		 * @public
		 */
		isManageDepartmentNewButtonVisible: function (sTabKey, bNewDepartmentAPIEnabled) {
			return !!(bNewDepartmentAPIEnabled && MasterFormatter.isAnyUserTab(sTabKey));
		},
		
		/**
		 * Check if Manage Department OLD button is visible
		 * @param {string} sTabKey current tab key
		 * @param {boolean} bNewDepartmentAPIEnabled if new Department API is enabled
		 * @returns {boolean} visible state
		 * @function
		 * @public
		 */
		isManageDepartmentOldButtonVisible: function (sTabKey, bNewDepartmentAPIEnabled) {
			return !!(!bNewDepartmentAPIEnabled && MasterFormatter.isNotRUorAPTab(sTabKey));
		},

		/**
		 * Check if tab is not Authorization Packages
		 * @param {string} sTabKey current tab key
		 * @returns {boolean} false if tab key is Authorization Packages
		 * @function
		 * @public
		 */
		isNotAuthorizationPackagesTab: function (sTabKey) {
			return sTabKey !== AUTHORIZATION_PACKAGES_TAB;
		},
		
		/**
		 * Check if tab is not Authorization Packages
		 * @param {string} sTabKey current tab key
		 * @returns {boolean} false if tab key is Authorization Packages
		 * @function
		 * @public
		 */
		isNotRUorAPTab: function (sTabKey) {
			return sTabKey !== AUTHORIZATION_PACKAGES_TAB && sTabKey !== REPORTS_AND_UPDATES;
		},

		/**
		 * Check if request rejection reason should be visible
		 * @param {string} sRequestStatus request status
		 * @param {string} sRejectReason rejection reason
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isRejectionReasonVisible: function (sRequestStatus, sRejectReason) {
			return !!sRejectReason && sRequestStatus === RequestStatus.REJECTED;
		},

		/**
		 * Check if tab is Reports and Updates
		 * @param {string} sTabKey current tab key
		 * @returns {boolean} true if tab key is Reports and Updates
		 * @function
		 * @public
		 */
		isReportsAndUpdatesTab: function (sTabKey) {
			return sTabKey === REPORTS_AND_UPDATES;
		},

		/**
		 * Check if tab is Users
		 * @param {string} sTabKey current tab key
		 * @returns {boolean} true if tab key is Users
		 * @function
		 * @public
		 */
		isUsersTab: function (sTabKey) {
			return sTabKey === ALL_USERS;
		},

		/**
		 * Check if tab is Users and flag is true
		 * @param {string} sTabKey current tab key
		 * @param {boolean} bFlag flag
		 * @returns {boolean} true if tab key is Users
		 * @function
		 * @public
		 */
		isUsersTabAndTrue: function (sTabKey, bFlag) {
			return !!bFlag && sTabKey === ALL_USERS;
		},

		/**
		 * Get title for MassAddDeleteAuthorizations dialog
		 * @param {boolean} bDeleteMode if dialog is in delete mode
		 * @returns {string} title
		 * @function
		 * @public
		 */
		massAddDeleteAuthDialogTitle: function (bDeleteMode) {
			return Util.getText.call(this, bDeleteMode ? "DIALOG_REMOVE_AUTHORIZATIONS_TITLE" : "DIALOG_ADD_AUTHORIZATIONS_TITLE");
		},

		/**
		 * Get Navigation or Inactive list item type
		 * @param {boolean} bNavigable if type is Navigation
		 * @returns {sap.m.ListType} Navigation if true, Inactive otherwise
		 * @function
		 * @public
		 */
		navigableOrInactive: function (bNavigable) {
			return bNavigable ? sap.m.ListType.Navigation : sap.m.ListType.Inactive;
		},

		/**
		 * Get value state for request status
		 * @param {string} sStatus status
		 * @returns {sap.ui.core.ValueState} value state
		 * @function
		 * @public
		 */
		requestStatusState: function (sStatus) {
			if (sStatus === "Pending") {
				return ValueState.Warning;
			}
			return ValueState.None;
		},
		
		/**
		 * Format requested user's password for non-success users
		 * @param {string} sPassword password
		 * @param {string} sStatus status field
		 * @returns {string} password or empty string
		 * @function
		 * @public
		 */
		requestedUserPassword: function (sPassword, sStatus) {
			return sStatus === "S" ? "" : sPassword;
		},
		
		/**
		 * Get row type for requested user
		 * @param {string} sStatus status field
		 * @returns {sap.m.ListType} row type
		 * @function
		 * @public
		 */
		requestedUserRowType: function (sStatus) {
			return (sStatus === "S" || sStatus === "A") ? ListType.Navigation : ListType.Inactive;
		},
	
		/**
		 * Format requested user status
		 * @param {string} sStatus status field
		 * @returns {string} formatted status text
		 * @function
		 * @public
		 */
		requestedUserStatus: function (sStatus) {
			switch (sStatus) {
				case "S": case "A":
					return Util.getText.call(this, "MISC_SUCCESS");
				case "E":
					return Util.getText.call(this, "MISC_ERROR");
				case "R":
					return Util.getText.call(this, "MISC_REJECTED");
				default:
					return Util.getText.call(this, "MISC_PROCESS");
			}
		},
		
		requestedUserStatusState: function (sStatus) {
			switch (sStatus) {
				case "S": case "A":
					return ValueState.Success;
				case "E":
					return ValueState.Error;
				case "R":
					return ValueState.Error;
				default:
					return ValueState.None;
			}
		},
		
		requestedUserStatusTooltip: function (sStatus) {
			switch (sStatus) {
				case "S": case "A":
					return "";
				case "E":
					return Util.getText.call(this, "TOOLTIP_REQUESTED_USER_ERROR_STATUS");
				default:
					return Util.getText.call(this, "TOOLTIP_REQUESTED_USER_IN_PROCESS_STATUS");
			}
		},
		/**
		 * Get success state for requested user
		 * @param {string} sStatus status field
		 * @returns {boolean} success state
		 * @function
		 * @public
		 */
		requestedUserSuccessful: function (sStatus) {
			return sStatus === "S";
		},
		
		/**
		 * Format user's requester name
		 * @param {string} sUserName requester's user name
		 * @param {string} [sUserId] requester's user ID
		 * @returns {string} formatted name with id
		 * @function
		 * @public
		 */
		requesterName: function (sUserName, sUserId) {
			if (sUserName === "self") {
				return Util.getText.call(this, "MISC_SELF");
			} else if (sUserId) {
				return sUserName + " (" + sUserId + ")";
			}
			return sUserName;
		},
		
		/**
		 * Show Universal ID status text
		 * @param {boolean} bStatus Universal ID status
		 * @returns {string} status text
		 * @function
		 * @public
		 */
		uidStatus: function (bStatus) {
			return Util.getText.call(this, bStatus ? "UID_STATUS_LINKED" : "UID_STATUS_NOT_LINKED");
		},
		
		/**
		 * Get tooltip for button
		 * @param {string} sTooltip default tooltip
		 * @param {string} sInfoText info text about any disruption in the system
		 * @param {boolean} bButtonEnabled if button is allowed to use (there is no disruption)
		 * @returns {string} tooltip
		 * @function
		 * @public
		 */
		buttonTooltip: function (sTooltip, sInfoText, bButtonEnabled) {
			if (bButtonEnabled) {
				return sTooltip;
			}
			
			var sText = sInfoText || "",
				iHtmlTagPosition = sText.indexOf("<");
			
			if (sText.indexOf("<") === -1) {
				return sInfoText;
			}
			return sText.slice(0, iHtmlTagPosition);
		},
		
		/**
		 * Get tooltip for manage expiry button
		 * @param {string} sDisableTooltip default tooltip
		 * @param {boolean} isEnable if button is enable
		 * @param {string} sEnableTooltip tooltip
		 * @param {string} sInfoText info text about any disruption in the system
		 * @param {boolean} bButtonEnabled if button is allowed to use (there is no disruption)
		 * @returns {string} tooltip
		 * @function
		 * @public
		 */
		manageExpiryButtonuttonTooltip: function (sDisableTooltip, isEnable, sEnableTooltip, sInfoText, bButtonEnabled, sTooManyUsers ,bTooManyUsersSelectedForMassExtention) {
			
			if(bTooManyUsersSelectedForMassExtention){
				return Util.getText.call(this,sTooManyUsers,Settings.maxUsersAllowedForMassUserExtentions );
			}
			
			if (bButtonEnabled) {
				return isEnable ? sEnableTooltip : sDisableTooltip;
			}
			
			var sText = sInfoText || "",
				iHtmlTagPosition = sText.indexOf("<");
			
			if (sText.indexOf("<") === -1) {
				return sInfoText;
			}
			return sText.slice(0, iHtmlTagPosition);
		},
		
		enabledDeleteButton: function (sTabKey, bBUttonStatus) {
			return (sTabKey === "AllUsers") && bBUttonStatus;
		},
		
		userCountLabelText: function (count) {
			return _getText("MASTER_USERS") + " (" + count + ")";
		},
		
		RACountLabelText: function (count) {
			return _getText("MISC_ITEMS") + " (" + count + ")";
		},
		
		reqAuthLableText: function (pendingTasks) {
			return _getText("MASTER_TASK_AWAITING_APPROVAL") + " (" + pendingTasks + ")";
		},
		
		requestVisibleButton: function (sStatus) {
			return sStatus === "O";
		},
		
		requestProcessedByText: function (sStatus, sText) {
			return (sStatus === "A") ? sText : "";
		},
		
		/**
		 * Translate Type of Request
		 * @param {string} sTypeOfRequest type of request text
		 * @returns {string} formatted type of request text
		 * @function
		 * @public
		 */
		typeOfRequestText: function (sTypeOfRequest) {
			if (/^authorization$/i.test(sTypeOfRequest)) {
				return Util.getText.call(this, "DETAIL_AUTHORIZATION");
			}
			if (/^expiry_date$/i.test(sTypeOfRequest)) {
				return Util.getText.call(this, "DETAIL_MANAGE_EXPIRY_DATE");
			}
			return sTypeOfRequest;
		},
		
		/**
		 * Get value state for User Status field in the user detail page
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {sap.ui.core.ValueState} value state
		 * @function
		 * @public
		 */
		userExpirationStatusIcon: function (sExpirationStatus) {
			switch (sExpirationStatus) {
				case UserExpirationStatus.EXPIRED:
					return "sap-icon://status-negative";
				case UserExpirationStatus.EXPIRING:
					return "sap-icon://status-critical";
				case UserExpirationStatus.REQUESTED:
					return "sap-icon://status-critical";
				case UserExpirationStatus.ACTIVE:
					return "sap-icon://status-positive";
				default:
					return "sap-icon://status-inactive";
			}
		},
	
		selfRequest: function(userId, requestedBy) {
			if(userId === requestedBy) {
				return Util.getText.call(this, "MISC_SELF");
			}
			else return requestedBy;
		},
		
		appSelfRequest: function(appName) {
			if(appName === undefined || appName === "" ) {
				return Util.getText.call(this, "SELF_REQUEST");
			}
			else return appName;
		},

		appRequest: function(appName) {
			if(appName === undefined) {
				return "";
			}
			else return appName;
		},
		
		appAuthRequest: function(appName, ObjectDesc) {
			if(appName !== undefined && appName !== "") {
				return "";
			}
			else return ObjectDesc;
		},
		
		deletedByText : function(sVal){
			switch (sVal){
				case "PRM":
					return Util.getText.call(this, "DELETED_BY_PRM"); 
				default:
				   return sVal;
			}
		},
		
		showDeletedUserReactivateButton: function (sStatus) {
			return sStatus === "D";
		},
		
		truncateLeadingZeros: function (number) {
			return (number) ? number.replace(/^0+/, "") : "";
		},
		
		setAPTitle: function(aAP) {
			return Util.getText.call(this, "ASSIGNED_AP_TITLE") + " (" + aAP.length + ")";
		},
		
		massAddDeleteAuthDialogButton: function (bDeleteMode) {
			return Util.getText.call(this, bDeleteMode ? "BUTTON_USER_DELETE" : "BUTTON_ADD");
		},
		
		isDomainIconVisible: function (isValidDomain, Status) {
			return !isValidDomain && !(Status==="N");
		},
		isHighlightEmailUserList: function(isValidDomain, Status, isEmailCheckEnabled, isValidEmail) {
			return this.formatter.master.isDomainIconVisible(isValidDomain, Status) 
				|| (isEmailCheckEnabled && !isValidEmail && !(Status==="N"));
		},
		
		noteForExport: function(note) {
			return note ? "X": "";
		},
		
		isHighlightEmailImportantContact: function (isValidDomain, isEmailCheckEnabled, isValidEmail) {
			return isEmailCheckEnabled && (!isValidDomain || (isEmailCheckEnabled && !isValidEmail));
		},
		
		titleInvalidEmailOrDomain: function (isValidEmail, isValidDomain, isEmailCheckEnabled, isDomainCheckEnabled) {
			if (!isValidEmail && isEmailCheckEnabled) {
				return Util.getText.call(this, "MASTER_INVALID_EMAIL");
			}
			if (!isValidDomain && isDomainCheckEnabled) {
				return Util.getText.call(this, "MASTER_UNVERIFIED_DOMAIN_NEW");
			}
		},
		messageInvalidEmailOrDomain: function (that, isEmailFormatValid, isEmailNotShared, isEmailNotDuplicate, isValidDomain) {
			var sMessage = that.getBundle().getText("DETAIL_NON_COMPLIANT_EMAIL_START") + "<ul>";
			if (!isEmailFormatValid) {
				sMessage += "<li><strong>" + that.getBundle().getText("DETAIL_INCORRECT_EMAIL_FORMAT") + "</strong></li>";
			}
			if (!isEmailNotShared) {
				sMessage += "<li><strong>" + that.getBundle().getText("DETAIL_SHARED_EMAIL") + "</strong></li>";
			}
			if (!isEmailNotDuplicate) {
				sMessage += "<li><strong>" + that.getBundle().getText("DETAIL_DUPLICATE_EMAIL") + "</strong></li>";
			}
			if (!isValidDomain) {
				sMessage += "<li><strong>" + that.getBundle().getText("DETAIL_UNVERIFIED_EMAIL") + "</strong></li>";
			}
			sMessage += "</ul>" + that.getBundle().getText("DETAIL_NON_COMPLIANT_EMAIL_END", Constant.Links.EMAIL_HELP_PAGE );
			return sMessage;
		},
		
		messageInvalidEmail: function(isValidEmail, isEmailCheckEnabled) {
			if (!isValidEmail && isEmailCheckEnabled) {
				return Util.getText.call(this, "MASTER_INVALID_EMAIL_MSG_NEW", Constant.Links.EMAIL_HELP_PAGE);
			}
		},
		
		adminFunctionName: function(sFunction) {
			var SUPER_ADMIN = "Super Administrator",
				CLOUD_ADMIN = "Cloud Administrator",
				USER_ADMIN = "User Administrator",
				SECURITY_CONTACT = "Security Contact",
				TECH_CONTACT = "Technical Contact";
			switch (sFunction) {
				case SUPER_ADMIN:
					return Util.getText.call(this, "MASTER_CR_SUPER_ADMIN");
				case CLOUD_ADMIN:
					return Util.getText.call(this, "MASTER_CR_SUPER_ADMIN_CLOUD");
				case USER_ADMIN:
					return Util.getText.call(this, "MASTER_CR_USER_ADMIN");
				case SECURITY_CONTACT:
					return Util.getText.call(this, "MASTER_CR_SECU_COTNACT");
				case TECH_CONTACT:
					return Util.getText.call(this, "MASTER_CR_TECH_CONTACT");
				default:
					return sFunction;
			}
		},
		
		createEmailPolicyDomainList: function (sEmailValidFormat, sEmailPolicyNew, bIsSuperAdmin, sEmailPolicyGuideline) {
			var sPolicyDomain = "";
			if(this.getModel("appSettings").getData().domainCheckActive) {
				if(bIsSuperAdmin) {
					sPolicyDomain = Util.getText.call(this,"MESSAGE_EMAIL_POLICY_DOMAIN_SUPERADMIN");
				} else {
					sPolicyDomain = Util.getText.call(this,"MESSAGE_EMAIL_POLICY_DOMAIN_ADMIN");
				}
			} else {
				sPolicyDomain = Util.getText.call(this,"MESSAGE_EMAIL_POLICY_DOMAIN");
			}
			
			var sPolicyGuideline = jQuery.sap.formatMessage(sEmailPolicyGuideline, Constant.Links.EMAIL_HELP_PAGE);
			var sMessage = 	"<li>" + sEmailValidFormat + "</li><br>" +
							"<li>" + sEmailPolicyNew + "</li><br>" + 
							"<li>" + sPolicyDomain + "</li><br>" +
							"<li>" + sPolicyGuideline + "</li><br>";

			return 	"<ul style=\"padding-inline-start: 1rem;\">" + sMessage + "</ul>";
		}
	};

	return MasterFormatter;
});
sap.ui.define([
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util"
], function (Constant, Util) {
	var _oCachedBundle = null;

	var AuthLevelId = Constant.AuthLevelId,
		AuthLevelType = Constant.AuthLevelType;
		
	var UserExpirationStatus = Constant.UserExpirationStatus,
		UserCriticalRole = Constant.UserCriticalRole;

	/**
	 * Get i18n bundle
	 * @returns {sap.ui.model.resource.ResourceBundle} bundle
	 * @function
	 * @private
	 */
	var _getBundle = function () {
		if (!_oCachedBundle) {
			_oCachedBundle = Util.getBundle.call(this);
		}
		return _oCachedBundle;
	};

	/**
	 * Get i18n text
	 * @param {string} sKey key
	 * @param {any[]} aArgs arguments
	 * @returns {string} text
	 * @function
	 * @private
	 */
	var _getText = function (sKey, aArgs) {
		return _getBundle.call(this).getText(sKey, aArgs);
	};

	var DetailFormatter = {
		/**
		 * Format full address
		 * @param {string} sAddress address
		 * @param {string} sCity city
		 * @param {string} sCountry country
		 * @returns {string} full address
		 * @function
		 * @public
		 */
		addressCityCountry: function (sAddress, sCity, sCountry) {
			return Util.formatMessage("{0} {1}, {2}", [sAddress, sCity, sCountry]);
		},
		
		/**
		 * Format full address
		 * @param {string} sAddress address
		 * @param {string} sZip zip
		 * @param {string} sCity city
		 * @param {string} sCountry country
		 * @returns {string} full address
		 * @function
		 * @public
		 */
		streetAddressCityCountryText: function (sStreet, sZip, sCity, sCountry) {
			return Util.formatMessage("{0}, {1} {2} {3}", [sStreet, sZip, sCity, sCountry]);
		},
		
		/**
		 * Format user's administrative role
		 * @param {string} sUserCriticalRoleId UserCriticalRoleId property
		 * @returns {string} text
		 * @function
		 * @public
		 */
		administratorRoleText: function (sUserCriticalRoleId) {
			switch (sUserCriticalRoleId) {
				case UserCriticalRole.SUPERADMIN:
					return Util.getText.call(this, "MASTER_CR_SUPER_ADMIN");
				case UserCriticalRole.SUPERADMIN_CLOUD:
					return Util.getText.call(this, "MASTER_CR_SUPER_ADMIN_CLOUD");
				case UserCriticalRole.USERADMIN:
					return Util.getText.call(this, "MASTER_CR_USER_ADMIN");
				case UserCriticalRole.USERADMIN_CLOUD:
					return Util.getText.call(this, "MASTER_CR_USER_ADMIN_CLOUD");
				case UserCriticalRole.PARTNER_SEC_MANAGER:
					return Util.getText.call(this, "MASTER_CR_PARTNER_SEC_MANAGER");
				default:
					return "";
			}
		},
		
		/**
		 * Format message if all installations per customer are selected
		 * @param {string} sCustomerId customer ID
		 * @returns {string} message
		 * @function
		 * @public
		 */
		allEntriesPerCustomerSelectedMessage: function (sCustomerId) {
			var sId = sCustomerId || "";
			return _getText.call(this, "AUTHORIZATION_LEVEL_ALL_ENTRIES_4_CUST") + sId.replace(/^0+/, "") + ". " + _getText.call(this,
				"AUTHORIZATION_LEVEL_ALL_ENTRIES_4_CUST2");
		},

		/**
		 * Check if auth object has detail assign
		 * @param {string} sAuthLevelId current auth level id
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		authorizationHasDetails: function (sAuthLevelId) {
			return !(sAuthLevelId === AuthLevelId.GLOBAL || sAuthLevelId === AuthLevelId.GROUP);
		},

		/**
		 * Get authorization level (Top, Group or None)
		 * @param {string} sObjectId object id
		 * @returns {sap.support.useradministration.extended.ExtendedCustomListItemLevel} level
		 * @function
		 * @public
		 */
		authorizationLevel: function (sObjectId) {
			if (/^G_/.test(sObjectId)) {
				return sObjectId === "G_ALL" ? "Top" : "Group";
			}
			return "None";
		},

		/**
		 * Get list item type for auth item (Inactive for group items)
		 * @param {string} sAuthLevelId current auth level id
		 * @returns {sap.m.ListType} item type
		 * @function
		 * @public
		 */
		authorizationListItemType: function (sAuthLevelId) {
			if (sAuthLevelId === AuthLevelId.GLOBAL || sAuthLevelId === AuthLevelId.GROUP) {
				return sap.m.ListType.Inactive;
			}
			return sap.m.ListType.Navigation;
		},
		
		authorizationValueFormat: function(value, authType) {
			if (authType && authType === "GLOBAL") {
				return "";
			}
			if (authType && authType !== "INSTALL" && value) {
				var key = 0;
				for (var i = 0; i < value.length; i++) {
					if (value[i] !== "0") {
						key = i;
						break;
					}
				}
				return value.slice(key);
			}
			return value;	
		},
		
		/**
		 * Get list item type for auth item (Inactive for group items)
		 * @param {string} sAuthLevelId current auth level id
		 * @returns {sap.m.ListType} item type
		 * @function
		 * @public
		 */
		existingAuthorizationListItemType: function (sAuthLevelId, sField, isInactive) {
			if (sAuthLevelId === AuthLevelId.GLOBAL || sAuthLevelId === AuthLevelId.GROUP || sField === AuthLevelId.GLOBAL || isInactive) {
				return sap.m.ListType.Inactive;
			}
			return sap.m.ListType.Navigation;
		},
		
		/**
		 * Get list item type for auth item (Inactive for group items)
		 * @param {boolean} isInactive
		 * @returns {sap.m.ListType} item type
		 * @function
		 * @public
		 */
		existingAPListItemType: function (isInactive) {
			if (isInactive) {
				return sap.m.ListType.Inactive;
			}
			return sap.m.ListType.Navigation;
		},
		
		/**
		 * Get AP iditing
		 * @param {boolean} isProtected 
		 * @param {string} infoText
		 * @returns {boolean} status text
		 * @function
		 * @public
		 */
		authorizationPackageEdit: function (isProtected, isButtonEnabled) {
			return isButtonEnabled && isProtected;
		},
		
		/**
		 * Set selection mode for the list
		 * @param {boolean} bIsEnabled if button not disabled by info banner
		 * @param {boolean} bIsViewMode if view mode is active
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		listSelectionMode: function (bIsEnabled, bIsViewMode) {
			return (bIsEnabled && !bIsViewMode) ? sap.m.ListMode.MultiSelect : sap.m.ListMode.None;
		},

		/**
		 * Get authorization status
		 * @param {string} sCurrentAuthLevel current auth level
		 * @param {string} sAuthLevelId current auth level id
		 * @returns {string} status text
		 * @function
		 * @public
		 */
		authorizationStatus: function (sCurrentAuthLevel, sAuthLevelId, sTopLevel) {
			var oKeys = Constant.AuthStatusText[sCurrentAuthLevel];
			var sKey;
			//sKey = oKeys && oKeys[sAuthLevelId];

			if (sAuthLevelId === sTopLevel) {
				if (sAuthLevelId === "INSTALL") {
					sKey = oKeys && ((sCurrentAuthLevel === "full") ? "AUTH_OBJ_SWITCH_FULL4INST_ONLY_TEXT" : "AUTH_OBJ_SWITCH_REST4INST_ONLY_TEXT");
				} else {
					sKey = oKeys && oKeys[sTopLevel];
				}
			} else {
				sKey = oKeys && oKeys[sAuthLevelId];
			}

			return sKey ? _getText.call(this, sKey) : "";
		},

		/**
		 * Check if full auth can be assigned
		 * @param {string} sTopLevelAssigned top level assigned
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		canSwitchFullAuth: function (sTopLevelAssigned) {
			return sTopLevelAssigned === Constant.TopLevel.CCC || sTopLevelAssigned === Constant.TopLevel.DEBITOR ||
				sTopLevelAssigned === Constant.TopLevel.GLOBAL;
		},

		/**
		 * Get list item type for cloud auth item (Inactive for Global Flag)
		 * @param {string} sGlobalFlag global flag
		 * @returns {sap.m.ListType} item type
		 * @function
		 * @public
		 */
		cloudAuthorizationListItemType: function (sGlobalFlag) {
			return sGlobalFlag ? sap.m.ListType.Inactive : sap.m.ListType.Navigation;
		},

		/**
		 * Get visibility of Copy Levels button
		 * @param {string} sCurrentAuthLevel current auth level
		 * @param {string} sAuthLevelId current auth level id
		 * @param {boolean} bViewMode if view mode is active so button should be invisible
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		copyLevelsButtonVisible: function (sCurrentAuthLevel, sAuthLevelId, bViewMode) {
			return !bViewMode && sCurrentAuthLevel !== Constant.AuthLevel.NONE && sAuthLevelId !== AuthLevelId.GLOBAL &&
				sAuthLevelId !== AuthLevelId.GROUP && sAuthLevelId !== AuthLevelId.USER;
		},

		/**
		 * Get visibility of Copy Levels button for local edit
		 * @param {boolean} bEditMode edit mode state
		 * @param {boolean} bSelected selected state
		 * @param {string} sAuthLevelId current auth level id
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		copyLevelsLocalButtonVisible: function (bEditMode, bSelected, sAuthLevelId) {
			return Boolean(bEditMode && bSelected && sAuthLevelId !== AuthLevelId.GLOBAL && sAuthLevelId !== AuthLevelId.GROUP);
		},
		
		copyLevelsForCreateButtonVisible: function (bSelected, sAuthLevelId) {
			return Boolean(bSelected && sAuthLevelId !== AuthLevelId.GLOBAL && sAuthLevelId !== AuthLevelId.GROUP);
		},
		
		/**
		 * Format title for installations select dialog
		 * @param {boolean} bUserMode if user mode is active
		 * @returns {string} title
		 * @function
		 * @public
		 */
		installationsDialogTitle: function (bUserMode) {
			return Util.getText.call(this, bUserMode ? "AUTH_OBJ_USER_LEVEL_MULTIPLE" : "AUTH_OBJ_INST_LEVEL_MULTIPLE");
		},

		/**
		 * Get title for restricted installations table
		 * @param {string} sAuthLevelId auth level ID
		 * @returns {string} title
		 * @function
		 * @public
		 */
		installationsTableTitle: function (sAuthLevelId) {
			if (sAuthLevelId === AuthLevelId.USER) {
				return _getText.call(this, "AUTH_OBJ_USER_LEVEL_TITLE");
			} else if (sAuthLevelId === AuthLevelId.INSTALL) {
				return _getText.call(this, "AUTH_OBJ_INST_LEVEL_TITLE");
			}
			return "";
		},
		
		messageStripText: function (sAuthLevelId) {
			if (sAuthLevelId === AuthLevelId.USER) {
				return _getText.call(this, "MESSAGE_STRIP_AUTHORIZATION_RESTRICTED_USER");
			} else {
				return _getText.call(this, "MESSAGE_STRIP_AUTHORIZATION_RESTRICTED_INSTALL");
			}
		},

		/**
		 * Check if auth granted for all
		 * @param {string} sCurrentAuthLevel current auth level
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isAuthAllGranted: function (sCurrentAuthLevel) {
			return sCurrentAuthLevel === Constant.AuthLevel.FULL;
		},

		/**
		 * Get authorization selected state
		 * @param {string} sCurrentAuthLevel CurrentAuthLevel property
		 * @returns {boolean} selected state
		 * @function
		 * @public
		 */
		isAuthorizationSelected: function (sCurrentAuthLevel) {
			return sCurrentAuthLevel === Constant.AuthLevel.FULL || sCurrentAuthLevel === Constant.AuthLevel.RESTRICTED;
		},

		/**
		 * Check if authorization top level assigned is CCC
		 * @param {string} sTopLevelAssigned top level assigned
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isAuthTopLevelCCC: function (sTopLevelAssigned) {
			return sTopLevelAssigned === Constant.TopLevel.CCC;
		},

		/**
		 * Check if authorization top level assigned is Global
		 * @param {string} sTopLevelAssigned top level assigned
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isAuthTopLevelGlobal: function (sTopLevelAssigned) {
			return sTopLevelAssigned === Constant.TopLevel.GLOBAL;
		},

		/**
		 * Check if authorization is cloud administrator
		 * @param {string} sAuthId authorization ID
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isCloudAuthAdmin: function (sAuthId) {
			return sAuthId === "CL_ADMIN";
		},

		/**
		 * Get authorization selected state
		 * @param {string} sGlobalFlag GlobalFlag property
		 * @returns {boolean} selected state
		 * @function
		 * @public
		 */
		isCloudAuthSelected: function (sGlobalFlag) {
			return sGlobalFlag === Constant.AuthLevel.FULL || sGlobalFlag === Constant.AuthLevel.RESTRICTED;
		},

		/**
		 * Check if auth level is cluster
		 * @param {object} oAuthLevel auth level object
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isClusterLevel: function (oAuthLevel) {
			return oAuthLevel.AuthLevelType === AuthLevelType.CLUSTER;
		},

		/**
		 * Check if Copy User's Authorizations button should be enabled
		 * @param {string} sUserCriticalRoleId UserCriticalRoleId property
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isCopyUsersAuthorizationsButtonEnabled: function (sUserCriticalRoleId) {
			switch (sUserCriticalRoleId) {
				case UserCriticalRole.SUPERADMIN:
				case UserCriticalRole.SUPERADMIN_CLOUD:
				case UserCriticalRole.USERADMIN:
				case UserCriticalRole.USERADMIN_CLOUD:
					return true;
				default:
					return false;
			}
		},

		/**
		 * Check if auth level is customer
		 * @param {object} oAuthLevel auth level object
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isCustomerLevel: function (oAuthLevel) {
			return oAuthLevel.AuthLevelType === AuthLevelType.CUSTOMER || oAuthLevel.AuthLevelType === AuthLevelType.DEBITOR;
		},

		/**
		 * Check if auth level is installation or user
		 * @param {object} oAuthLevel auth level object
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isInstallationOrUserLevel: function (oAuthLevel) {
			return oAuthLevel.AuthLevelType === AuthLevelType.INSTALLATION || oAuthLevel.AuthLevelType === AuthLevelType.USER;
		},

		/**
		 * Check if installation levels table visible
		 * @param {string} sAuthLevelId auth level ID
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isInstallationsTableVisible: function (sAuthLevelId) {
			return sAuthLevelId === AuthLevelId.USER || sAuthLevelId === AuthLevelId.INSTALL;
		},
		
		/**
		 * Check if user is not expired or inactive
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {boolean} active status
		 * @function
		 * @public
		 */
		isUserActive: function (sExpirationStatus) {
			return sExpirationStatus !== UserExpirationStatus.EXPIRED && sExpirationStatus !== UserExpirationStatus.INACTIVE;
		},
		
		/**
		 * Check if user's expiration date should be shown
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {boolean} visibility
		 * @function
		 * @public
		 */
		isUserExpirationDateVisible: function (sExpirationStatus) {
			switch (sExpirationStatus) {
				case UserExpirationStatus.EXPIRED:
				case UserExpirationStatus.EXPIRING:
					return true;
				default:
					return false;
			}
		},
		
		/**
		 * Check if user is expired
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {boolean} expired status
		 * @function
		 * @public
		 */
		isUserExpired: function (sExpirationStatus) {
			return sExpirationStatus === UserExpirationStatus.EXPIRED;
		},
		
		/**
		 * Check if information button near User Status in User Detail should be visible
		 * KNGMHM02-19355
		 * @param {string} sExpirationStatus user expiration status
		 * @param {boolean} bIsAllowed if user's allowed to manage expiry date
		 * @param {boolean} bIsExtentionRequested if user's expriry date extention has been requested
		 * @param {boolean} bIsLifetimeEnabled if s-user lifetime is enabled
		 * @returns {boolean} visibility
		 * @function
		 * @public
		 */
		isUserStatusInformationButtonVisible: function (sExpirationStatus, bIsAllowed, bIsExtentionRequested, bIsLifetimeEnabled) {
			if (!bIsLifetimeEnabled) {
				return false;
			}
			switch (sExpirationStatus) {
				case UserExpirationStatus.REQUESTED:
				case UserExpirationStatus.INACTIVE:
					return true;
				case UserExpirationStatus.ACTIVE:
				case UserExpirationStatus.EXPIRING:
					return !!bIsAllowed && !!bIsExtentionRequested;
				default:
					return false;
			}
		}, 

		/**
		 * Get text for full auth switch
		 * @param {string} sAuthLevelId auth level
		 * @returns {string} text
		 * @function
		 * @public
		 */
		fullAuthSwitchText: function (sAuthLevelId) {
			var sKey = Constant.AuthSwitchText[sAuthLevelId];

			return sKey ? _getText.call(this, sKey) : "";
		},

		/**
		 * Format phone mask
		 * @param {string} sCountryCode country code
		 * @returns {string} mask
		 * @function
		 * @public
		 */
		phoneMask: function (sCountryCode) {
			return sCountryCode ? (sCountryCode.replace(/9/g, "^9") + "-999999999999999") : "";
		},

		/**
		 * Format phone number using hyphen
		 * @param {string} sCountryCode country code
		 * @param {string} sPhoneNumber phone number
		 * @returns {string} formatted number
		 * @function
		 * @public
		 */
		phoneNumberHyphen: function (sCountryCode, sPhoneNumber) {
			return sPhoneNumber ? sCountryCode + "-" + sPhoneNumber : "";
		},

		/**
		 * Format phone number using space
		 * @param {string} sCountryCode country code
		 * @param {string} sPhoneNumber phone number
		 * @returns {string} formatted number
		 * @function
		 * @public
		 */
		phoneNumberSpace: function (sCountryCode, sPhoneNumber) {
			return sPhoneNumber ? sCountryCode + " " + sPhoneNumber : "";
		},
		
		/**
		 * Get user expiration information text
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {string} user expiration status
		 * @function
		 * @public
		 */
		userExpirationStatusInfoText: function (sExpirationStatus) {
			switch (sExpirationStatus) {
				case UserExpirationStatus.REQUESTED:
					return Util.getText.call(this, "DETAIL_INFO_REQUESTED_USER_STATUS");
				case UserExpirationStatus.INACTIVE:
					return Util.getText.call(this, "DETAIL_INFO_INACTIVE_USER_STATUS");
				default:
					return "";
			}
		},
		
		/**
		 * Get text with info about requested extension date for Status popup in User Detail
		 * @param {string} sExpirationStatus user expiration status
		 * @param {Date} oExpDate requested extension date
		 * @returns {string} text
		 * @function
		 * @public
		 */
		userExpirationStatusDateInfo: function (sExpirationStatus,oExpDate) {
			switch (sExpirationStatus) {
				case UserExpirationStatus.REQUESTED:
					return Util.getText.call(this, "DATE_INFO_REQUESTED_USER_STATUS_BOLD", [Util.date.formatStandardUTCDate(oExpDate)]);
				default:
					return "";
			}
		},
		
		
		userExpirationStatusDateInfoVisible: function (sExpirationStatus) {
			return sExpirationStatus === UserExpirationStatus.REQUESTED;
		},

		/**
		 * Get text with info about user extension for Status popup in User Detail
		 * @param {string} sExpirationStatus user expiration status
		 * @param {Date} oExtendReqDate extention request date
		 * @returns {string} text
		 * @function
		 * @public
		 */
		userExpirationStatusMessageStripText: function (sExpirationStatus, oExtendReqDate) {
			switch (sExpirationStatus) {
				case UserExpirationStatus.ACTIVE:
				case UserExpirationStatus.EXPIRING:
				case UserExpirationStatus.REQUESTED:
					return oExtendReqDate ? Util.getText.call(this, "DETAIL_INFO_EXTEND_REQ_ON", [Util.date.formatStandardUTCDate(oExtendReqDate)]) : "";
				default:
					return "";
			}
		},
		
		/**
		 * Check if message strip should be visible in Status popup in User Detail
		 * @param {string} sExpirationStatus user expiration status
		 * @param {Date} oExtendReqDate extention request date
		 * @returns {boolean} visible state
		 * @function
		 * @public
		 */
		userExpirationStatusMessageStripVisible: function (sExpirationStatus, oExtendReqDate) {
			switch (sExpirationStatus) {
				case UserExpirationStatus.ACTIVE:
				case UserExpirationStatus.EXPIRING:
				case UserExpirationStatus.REQUESTED:
					return !!oExtendReqDate;
				default:
					return false;
			}
		},
		
		userExpirationStatusIsExpiring: function (sExpirationStatus) {
			return sExpirationStatus === UserExpirationStatus.EXPIRING;
		},
		
		userExpiringStatusText: function (sExpirationStatus, oExtendReqDate) {
			if (sExpirationStatus === UserExpirationStatus.EXPIRING) {
				if (oExtendReqDate) { 
					return Util.getText.call(this, "DATE_INFO_EXPIRING_USER_STATUS_EXTEND_REQUESTED", [Util.date.formatStandardUTCDate(oExtendReqDate)]);
				} else{
					return Util.getText.call(this, "DATE_INFO_EXPIRING_USER_STATUS_NO_EXTEND");
				}	
			} else {
				return "";
			}
		},
		
		userExpirationStatusPopover: function (sExpirationStatus) {
			switch (sExpirationStatus) {
			case UserExpirationStatus.EXPIRED:
				return Util.getText.call(this, "DETAIL_INFO_EXPIRED_USER_STATUS");
			case UserExpirationStatus.REQUESTED:
				return Util.getText.call(this, "DETAIL_INFO_CHANGE_REQUESTED");
			case UserExpirationStatus.ACTIVE:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_ACTIVE_TOOLTIP");
			case UserExpirationStatus.INACTIVE:
				return Util.getText.call(this, "DETAIL_INFO_INACTIVE_USER_STATUS_NEW");
			default:
				return "";
			}
		},
		
		userExpirationStatusPopoverWidth: function (sExpirationStatus) {
			switch (sExpirationStatus) {
			case UserExpirationStatus.ACTIVE:
				return "170px";
			case UserExpirationStatus.INACTIVE:
			case UserExpirationStatus.REQUESTED:
				return "280px";
			default:
				return "250px";
			}
		},
		
		userExpirationStatusNotExpiring: function (sExpirationStatus) {
			return sExpirationStatus !==  UserExpirationStatus.EXPIRING;
		},
		
		/**
		 * Get tooltip for user image
		 * @param {boolean} bCriticalRole critical role flag
		 * @returns {string} tooltip text
		 * @function
		 * @public
		 */
		userImageTooltip: function (bCriticalRole) {
			return _getText.call(this, bCriticalRole ? "TOOLTIP_CRITICAL_ROLE_ASSIGNED" : "TOOLTIP_NO_CRITICAL_ROLE");
		},

		/**
		 * Format user name and ID
		 * @param {string} sTitle name title
		 * @param {string} sFirstName first name
		 * @param {string} sLastName last name
		 * @param {string} sId ID
		 * @returns {string} formatted string
		 * @function
		 * @public
		 */
		userNameAndId: function (sTitle, sFirstName, sLastName, sId) {
			var sFmtId = sId && ("(" + sId + ")");
			return [sTitle, sFirstName, sLastName, sFmtId].filter(Boolean).join(" ");
		},

		/**
		 * Validate email
		 * @param {string} sEmail email
		 * @returns {sap.ui.core.ValueState} error or none value state
		 * @function
		 * @public
		 */
		validEmailState: function (sEmail) {
			return this.formatter.detail.setEmailValueState(!sEmail || Util.detail.validateEmail(sEmail));
		},
		
		/**
		 * Set email Value State
		 * @param {boolean} isValid email
		 * @returns {sap.ui.core.ValueState} error or none value state
		 * @function
		 * @public
		 */
		setEmailValueState: function (isValid) {
			return isValid ? sap.ui.core.ValueState.None : sap.ui.core.ValueState.Error;
		},

		/**
		 * Validate phone number
		 * @param {string} sNumber phone number
		 * @returns {sap.ui.core.ValueState} error or none value state
		 * @function
		 * @public
		 */
		validPhoneState: function (sNumber) {
			var sNumberWithoutCode = Util.detail.dividePhoneNumber(sNumber || "");
			return Util.detail.validatePhoneNumber(sNumberWithoutCode) ? sap.ui.core.ValueState.None : sap.ui.core.ValueState.Error;
		}, 
		
		/**
		 * Show Universal ID status text
		 * @param {boolean} bStatus Universal ID status
		 * @returns {string} status text
		 * @function
		 * @public
		 */
		uidStatus: function (bStatus) {
			return Util.getText.call(this, bStatus ? "UID_STATUS_LINKED" : "UID_STATUS_NOT_LINKED");
		},
		
		uidStatusState: function (bStatus) {
			return bStatus ? "Success" : "Warning";
		},
		
		/**
		 * Format subtitle of header with id and role
		 * @param {string} Susid ID
		 * @param {string} sUserCriticalRoleId UserCriticalRoleId property
		 * @returns {string} text
		 * @function
		 * @public
		 */
		headerSubtitleWithIdAndRole: function (Susid, sUserCriticalRoleID) {
			var userID = Util.formatMessage("{0}: {1} ", [Util.getText.call(this,"MASTER_COLUMN_USER_ID"), Susid]);
			var userRoleName = this.formatter.detail.administratorRoleText(sUserCriticalRoleID);
			var userRole = sUserCriticalRoleID ? 
				Util.formatMessage(" {0}: {1} ", [Util.getText.call(this,"MASTER_COLUMN_FUNCTION"), userRoleName]) : "";
			return Util.formatMessage("{0} \u00a0\u00a0\u00a0\u00a0 {1}", [userID, userRole]);
		},
		
		stateAuthAssignHistory: function(sDel) {
			return (sDel) ? sap.ui.core.ValueState.Error : sap.ui.core.ValueState.Success;
		},
		
		textAuthAssignHistory: function(sDel) {
			return Util.getText.call(this, ((sDel) ? "MISC_DELETED" : "MISC_ADDED"));
		},
		
		mailtoLink: function(email) {
			return "mailto:" + email;
		},
		
		requesterNameAndId: function(sName, sId) {
			return sName ? sName + " (" + sId + ")" : sId;
		},
		
		processorsName: function(sId, sNamev, sName1) {
			return sNamev ? sNamev + " " + sName1 + " (" + sId + ")" : sId;
		}, 
		
		uidLinkedDate: function (bUidAssigned, date) {
			return bUidAssigned ? this.formatter.shortDate(date) : "";
		},
		
		authCountLabelText: function (count) {
			return _getText("DETAIL_AUTH_OBJECTS") + " (" + count + ")";
		},
		
		extensionCountLabelText: function(count) {
			return _getText("DETAIL_EXTENSIONS") + " (" + count + ")";
		},
		
		isEnabledEdit: function (isEnableEdit, isActiveUserOrUnexpired, sUserId, sLogonUserId) {
			return isEnableEdit && isActiveUserOrUnexpired && sLogonUserId !== sUserId;
		},
		
		unescapeNotes: function(sNotes) {
			var el = document.createElement("div");
			el.innerHTML = sNotes;
			return el.innerText;
		},
		
		authCheckboxToolitip: function(isEditMode, isDisabled) {
			if (isEditMode && isDisabled) {
				return Util.getText.call(this, "TOOLTIP_NO_PERMISSION_TO_REMOVE");
			} else {
				return "";
			}
		},
		
		isDomainIconVisible: function (isEditMode, isValidDomain, Status) {
			return !isEditMode && !isValidDomain && !(Status==="N");
		},
		isHighlightEmailUserDetail: function(isEditMode, isValidDomain, Status, isEmailCheckEnabled, isValidEmail) {
			return this.formatter.detail.isDomainIconVisible(isEditMode, isValidDomain, Status) 
				|| (!isEditMode && isEmailCheckEnabled && !isValidEmail && !(Status==="N"));
		},
		
		noteText: function (sText1, sText2) {
			return sText1 + " " + sText2;
		},
		
		noteTextPopup: function (sText1, sText2) {
			return "<ul><li>" + sText1 + "</li><br><li>" + sText2 + "</li></ul>";
		} 
	};
	
	return DetailFormatter;
});
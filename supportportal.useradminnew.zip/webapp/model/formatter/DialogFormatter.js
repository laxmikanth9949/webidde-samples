sap.ui.define([
	"sap/support/useradministration/model/Constant",
	"sap/ui/core/Icon",
	"sap/support/useradministration/util/Util"
], function(Constant, Icon, Util) {
	/**
	 * Get i18n bundle
	 * @returns {sap.ui.model.resource.ResourceBundle} bundle
	 * @function
	 * @private
	 */
	var _getBundle = function() {
		return Util.getBundle.call(this);
	};
	/**
	 * Get i18n text
	 * @param {string} sKey key
	 * @param {any[]} aArgs arguments
	 * @returns {string} text
	 * @function
	 * @private
	 */
	var _getText = function(sKey, aArgs) {
		return _getBundle.call(this).getText(sKey, aArgs);
	};
	
	var ValueState = sap.ui.core.ValueState;
	
	var DialogFormatter = {
		/**
		 * Format column text
		 * @param {string} sColumnKey column's i18n key
		 * @returns {string} column text
		 * @function
		 * @public
		 */
		columnText: function (sColumnKey) {
			return Util.getText.call(this, sColumnKey);
		},
		
		/**
		 * Format full name
		 * @param {string} sLastName last name
		 * @param {string} sFirstName first name
		 * @returns {string} name
		 * @function
		 * @public
		 */
		fullName: function (sLastName, sFirstName) {
			return sLastName + ", " + sFirstName;
		},
		/**
		 * Check if string is blank
		 * @param {string} sString string to check
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isNameBlank: function (sString) {
			return !!sString && !/\S/.test(sString);
		},
		
		/**
		 * Check if string contains invalid chars
		 * @param {string} sString string to check
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isNameHasInvalidChars: function (sString) {
			return /[^0-9A-z\u00c4\u00e4\u00d6\u00f6\u00dc\u00fc\u00df' \-]/.test(sString);
		},
		
		/**
		 * Check if string contains special chars
		 * @param {string} sString string to check
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isNameHasSpecialChars: function (sString) {
			return /[~`!#$%\^&*+=\[\];,/\{\}|\\":<>\?\.()@_]/g.test(sString);
		},
		
		/**
		 * Check if user name is reserved
		 * @param {string} sName name to check
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isNameReserved: function (sName) {
			return sName === "---TECH-USER---";	
		},
		
		/**
		 * Get filter key for Last N months filter
		 * @param {int} iMonths number of last months
		 * @returns {string} filter key
		 * @function
		 * @public
		 */
		lastNMonthsFilter: function (iMonths) {
			var oDate = new Date();
			
			oDate.setMonth(oDate.getMonth() - (iMonths || 0));
			return "Trdat___GE___" + Util.date.formatFilterDate(oDate);
		},
		
		/**
		 * Get filter key for created on last N months filter
		 * @param {int} iMonths number of last months
		 * @returns {string} filter key
		 * @function
		 * @public
		 */
		lastNMonthsCreatedOnFilter: function (iMonths) {
			var oDate = new Date();
			
			oDate.setMonth(oDate.getMonth() - (iMonths || 0));
			return "Erdat___GE___" + Util.date.formatFilterDate(oDate);
		},
		
		/**
		 * Get filter key for Last N days created filter
		 * @param {int} iDays number of last days
		 * @returns {string} filter key
		 * @function
		 * @public
		 */
		lastNDaysCreationFilter: function (iDays) {
			var oDate = new Date();
			oDate.setDate(oDate.getDate() - (iDays || 0));
			return "CreatedAt___GE___" + Util.date.formatFilterDate(oDate);
		},
		
		/**
		 * Get filter key for Last N days changed filter
		 * @param {int} iDays number of last days
		 * @returns {string} filter key
		 * @function
		 * @public
		 */
		lastNDaysChangedFilter: function (iDays) {
			var oDate = new Date();
	
			oDate.setDate(oDate.getDate() - (iDays || 0));
			return "ChangedAt___GE___" + Util.date.formatFilterDate(oDate);
		},
		
		/**
		 * Get filter key for next N months filter
		 * @param {int} iMonths number of last months
		 * @returns {string} filter key
		 * @function
		 * @public
		 */
		nextNMonthsExpiryDateFilter: function (iMonths) {
			var oDate = new Date(),
				sStartDate = Util.date.formatFilterDate(oDate);
			
			oDate.setMonth(oDate.getMonth() + (iMonths || 0));
			return "ExpiryDate___BT___" + sStartDate + "___" + Util.date.formatFilterDate(oDate);
		},
		
		/**
		 * Get filter key for next N months filter
		 * @param {int} iMonths number of last months
		 * @returns {string} filter key
		 * @function
		 * @public
		 */
		nextNMonthsExpDateFilter: function (iMonths) {
			var oDate = new Date(),
				sStartDate = Util.date.formatFilterDate(oDate);
			
			oDate.setMonth(oDate.getMonth() + (iMonths || 0));
			return "ExpDate___BT___" + sStartDate + "___" + Util.date.formatFilterDate(oDate);
		},
		
		/**
		 * Get text for next N months filter
		 * @param {int} iMonths number of last months
		 * @returns {string} filter text
		 * @function
		 * @public
		 */
		nextNMonthsText: function (iMonths) {
			if (iMonths === 1) {
				return Util.getText.call(this, "FILTER_NEXT_MONTH");
			} else {
				return Util.getText.call(this, "FILTER_NEXT_N_MONTHS", [iMonths]);
			}
		},
		
		/**
		 * Check if form of user request is valid
		 * @param {boolean} isValidEmail user's email
		 * @param {string} sFirstName user's first name
		 * @param {string} sLastName user's last name
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		requestUserFormValid: function(isValidEmail, sEmail, sEmailRegexp, sFirstName, sLastName) {
			return [].slice.call(arguments).every(Boolean) && isValidEmail && Util.detail.validateEmail(sEmail, sEmailRegexp)
				&& DialogFormatter.userNameValueState(sFirstName) !== ValueState.Error
				&& DialogFormatter.userNameValueState(sLastName) !== ValueState.Error;	
		},
		
		messagePopoverBtnVisible: function(aErrors) {
			return aErrors && aErrors.length > 0;
		},
		
		messagePopoverBtnCounter: function(aErrors) {
			return aErrors ? aErrors.length : "";
		},
		
		messagePopoverBtnIcon: function(aErrors) {
			if(aErrors.some(function(e) { return e.type === "Error" ;})) {
				return "sap-icon://message-error";
			} else if (aErrors.length == 1 && aErrors.some(function(e) { return e.type === "Warning" ;})) {
				return "sap-icon://message-warning";
			}
		},

		messagePopoverBtnType: function(aErrors) {
			if(aErrors.some(function(e) { return e.type === "Error" ;})) {
				return "Negative";
			} else if (aErrors.length == 1 && aErrors.some(function(e) { return e.type === "Warning" ;})) {
				return "Critical";
			}
		},
		
		/**
		 * Check if Save button for SAR settings should be enabled
		 * @param {boolean} bIsSelfAuthRequestEnabled if SAR switch is true
		 * @param {boolean} bIsCustomMessageEnabled if Custom Message switch is true
		 * @param {boolean} bCustomTextExists if Custom Text exists
		 * @param {boolean} bCanEditSARSettings if user is available to edit SAR settings
		 * @returns {sap.ui.core.ValueState} value state
		 * @function
		 * @public
		 */
		isSARSettingsSaveButtonEnabled: function (bIsSelfAuthRequestEnabled, bIsCustomMessageEnabled, bCustomTextExists, bCanEditSARSettings) {
			return Boolean(bCanEditSARSettings && (bIsSelfAuthRequestEnabled || !bIsCustomMessageEnabled || bCustomTextExists));
		},
		
		/**
		 * Get value state for SAR Settings Custom Text input
		 * @param {boolean} bIsSelfAuthRequestEnabled if SAR switch is true
		 * @param {boolean} bIsCustomMessageEnabled if Custom Message switch is true
		 * @param {boolean} bCustomTextExists if Custom Text exists
		 * @param {boolean} bCanEditSARSettings if user is available to edit SAR settings
		 * @returns {sap.ui.core.ValueState} value state
		 * @function
		 * @public
		 */
		SARCustomTextValueState: function (bIsSelfAuthRequestEnabled, bIsCustomMessageEnabled, bCustomTextExists, bCanEditSARSettings) {
			return bCanEditSARSettings && !bIsSelfAuthRequestEnabled && bIsCustomMessageEnabled && !bCustomTextExists ? ValueState.Error : ValueState.None;
		},
		
		/**
		 * Format column name for user list
		 * @param {string} sColumnId column ID
		 * @param {string} [sSuggestedText] i18n key suggested by the backend
		 * @returns {string} column name
		 * @function
		 * @public
		 */
		userListColumnName: function (sColumnId, sSuggestedText) {
			var sKey = {
				lname: "DETAIL_USER_LAST_NAME",
				fname: "DETAIL_USER_FIRST_NAME",
				email: "MASTER_COLUMN_USER_EMAIL",
				userID: "MASTER_COLUMN_USER_ID",
				cust_name: "MASTER_COLUMN_CUST_NAME",
				cust_num: "MASTER_COLUMN_CUST_NUM",
				country: "DETAIL_USER_CONTACT_LAND1_REGION",
				department: "MASTER_COLUMN_DEPT",
				logon_date: "DETAIL_USER_LAST_LOGON_DATE",
				created_by: "REQUESTED_USER_REQUESTER_NAME",
				created_on: "DETAIL_USER_CREATED_ON",
				phone_number: "DETAIL_USER_PHONE_NUMBER",
				expiry_date: "DETAIL_USER_EXPIRY_DATE",
				status: "DETAIL_STATUS",
				uid_is_assigned: "DETAIL_USER_UID_STATUS",
				uid_last_name: "DETAIL_USER_UNIVERSAL_ID_LAST_NAME",
				uid_first_name: "DETAIL_USER_UNIVERSAL_ID_FIRST_NAME",
				action: "MASTER_MANAGE"
			}[sColumnId];
			
			return Util.getText.call(this, sKey || sSuggestedText);
		},
		
		/**
		 * Get value state for user's name input
		 * @param {string} sName name to check
		 * @returns {sap.ui.core.ValueState} None for valid name, Warning otherwise
		 * @function
		 * @public
		 */
		userNameValueState: function(sName) {
			if (DialogFormatter.isNameBlank(sName) || DialogFormatter.isNameReserved(sName) || DialogFormatter.isNameHasInvalidChars(sName)) {
				return ValueState.Error;
			}
			return ValueState.None;
		},
		
		/**
		 * Get value state text for user's name input
		 * @param {string} sName name to check
		 * @param {boolean} [bLastName] if name is last name
		 * @returns {sap.ui.core.ValueState} None for valid name, Warning otherwise
		 * @function
		 * @public
		 */
		userNameValueStateText: function(sName, bLastName) {
			if (DialogFormatter.isNameBlank(sName)) {
				return _getText.call(this, bLastName ? "VALUE_STATE_ENTER_LAST_NAME" : "VALUE_STATE_ENTER_FIRST_NAME");
			} else if (DialogFormatter.isNameReserved(sName)) {
				return _getText.call(this, "MESSAGE_RESERVED_NAME");
			} /*else if (DialogFormatter.isNameHasSpecialChars(sName)) {
				return _getText.call(this, "MESSAGE_NAME_SPECIAL_CHAR");
			}*/ else if (DialogFormatter.isNameHasInvalidChars(sName)) {
				return _getText.call(this, "DIALOG_USER_NAME_HAS_INVALID_SYMBOLS_LONG");
			}
			return "";
		},
		
		/**
		 * Get value state text for user's last name input
		 * @param {string} sName name to check
		 * @returns {sap.ui.core.ValueState} None for valid name, Warning otherwise
		 * @function
		 * @public
		 */
		userLastNameValueStateText: function(sName) {
			return DialogFormatter.userNameValueStateText.call(this, sName, true);
		},
		
		manageExpiryDateMsg: function(sText){
			var sKey = "DIALOG_MSG_MANAGE_EXP_DATE";
			return Util.getText.call(this, sKey );
		},
		
		manageDepartmentItemType: function(bActive) {
			return bActive ? "Active" : "Inactive";
		},
		
		manageDepartmentListMode: function(bDelete) {
			return bDelete ? "Delete" : "None";
		},
		
		showTwoValuesSecondInBrackets: function (val1, val2) {
			return val1 + " (" + val2 + ")";
		},
		
		showTwoValuesDashSeparated: function (val1, val2) {
			return val1 + " - " + val2;
		},
		
		isValuesNonEqual: function (val1, val2) {
			return val1 !== val2;
		},

		showMessageDuplicatesEmailPolicy: function (sDuplicatesEmailPolicy, sDuplicatesEmailPolicyNew) {
			return this.getModel("appSettings").getData().domainCheckActive ? sDuplicatesEmailPolicyNew : sDuplicatesEmailPolicy;
		},
		
		showMessageUseUniqueEmail: function (sUseUniqueEmail, sUseUniqueEmailNew) {
			return this.getModel("appSettings").getData().domainCheckActive ? sUseUniqueEmailNew : sUseUniqueEmail;
		},

		titleRequestUserDetail: function (bDomainCheckEnabled) {
			return bDomainCheckEnabled ?  _getText.call(this, "REQUEST_USER_DETAIL_NEW") : _getText.call(this, "REQUEST_USER_DETAIL");
		},

		titleRequestUserAuthPackages: function (bDomainCheckEnabled) {
			return bDomainCheckEnabled ? _getText.call(this, "MASTER_AUTH_PACKAGES_NEW") : _getText.call(this, "MASTER_AUTH_PACKAGES");
		},

		addWarningIcon: function(sIpadr, bIsValidDomain) {
	//		console.log(bIsValidDomain);
			//return bIsValidDomain? sIpadr : "sap-icon://message-warning" + sIpadr
//			return "sap-icon://message-warning " + sIpadr
			return new sap.ui.core.Icon({
				src: "sap-icon://message-warning",
			 }).addStyleClass("sapUiTinyMarginEnd") + sIpadr;			
		}
	};
	
	return DialogFormatter;
});
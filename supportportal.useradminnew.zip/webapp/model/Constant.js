sap.ui.define([
"./constant/ValidationMessages", 
"./constant/ValidationStatuses"
], function (ValMesConstants, ValidationStatuses) {
	return $.extend({}, ValMesConstants, ValidationStatuses, {
		ABAP_TRUE: "X",
		ABAP_FALSE: "",
		HTTP_REQUEST_FAILED: "HTTP request failed",

		APModel: {
			AUTH_PACK_FOR_CUST: "/auth_pack_for_custSet",
			AUTH_PACK_FOR_USER: "/auth_pack_set_for_userSet"
		},
		AuthGroup: {
			ALL: "G_ALL"
		},
		AuthLevel: {
			EMPTY: "",
			FULL: "full",
			NONE: "none",
			RESTRICTED: "restricted",
			REQUESTED: "requested"
		},
		AuthLevelId: {
			DEBITOR: "DEBITOR",
			GLOBAL: "GLOBAL",
			GROUP: "group",
			INSTALL: "INSTALL",
			USER: "USER"
		},
		AuthLevelType: {
			CLUSTER: "CLUSTER",
			CUSTOMER: "CUSTOMER",
			DEBITOR: "DEBITOR",
			INSTALLATION: "INSTALL",
			NONDEBITOR: "NONDEBITOR",
			USER: "USER"
		},
		AuthStatusText: {
			full: {
				CCC: "AUTH_OBJ_SWITCH_FULL4INST_TEXT",
				DEBITOR: "AUTH_OBJ_SWITCH_FULL4CUST_TEXT",
				GLOBAL: "AUTH_OBJ_SWITCH_FULL4CUST_TEXT",
				INSTALL: "AUTH_OBJ_SWITCH_FULL4INST_TEXT",
				USER: "AUTH_OBJ_SWITCH_FULL4USER_TEXT"
			},
			restricted: {
				CCC: "AUTH_OBJ_SWITCH_REST4INST_TEXT",
				DEBITOR: "AUTH_OBJ_SWITCH_REST4CUST_TEXT",
				INSTALL: "AUTH_OBJ_SWITCH_REST4INST_TEXT",
				USER: "AUTH_OBJ_SWITCH_REST4USER_TEXT"
			}
		},
		AuthStatusTextRemove: {
			full: {
				DEBITOR: "AUTH_OBJ_SWITCH_NO_FULL4CUST_TEXT",
				GLOBAL: "AUTH_OBJ_SWITCH_NO_FULL4INST_TEXT",
				INSTALL: "AUTH_OBJ_SWITCH_NO_FULL4INST_TEXT",
				USER: "AUTH_OBJ_SWITCH_NO_FULL4USER_TEXT"
			},
			restricted: {
				DEBITOR: "AUTH_OBJ_SWITCH_NO_REST4CUST_TEXT",
				INSTALL: "AUTH_OBJ_SWITCH_NO_REST4INST_TEXT",
				USER: "AUTH_OBJ_SWITCH_NO_REST4USER_TEXT"
			}
		},
		AuthSwitchText: {
			DEBITOR: "AUTH_OBJ_SWITCH_FULL4CUST_TEXT",
			INSTALL: "AUTH_OBJ_SWITCH_FULL4INST_TEXT",
			USER: "AUTH_OBJ_SWITCH_FULL4USER_TEXT"
		},
		ComboboxItemType: {			
			DISABLED: "D",
			DISABLED_WITH_MARK: "DM",
			DISABLED_PENDING: "DP",
			ENABLED: "E",
			ENABLED_WITH_MARK: "EM"
		},
		DeptDesc: {
			NONE: "NONE"
		},
		Dialog: {
			ADD_DEPT: "AddDepartment",
			ASSIGN_USER_APS: "AssignUserAuthPackages",
			ASSIGN_USERS_TO_APS: "AssignUsersToAPs",
			COPY_AP_AUTH_LEVELS: "CopyAPAuthorizationLevels",
			MANAGE_DEPTS: "ManageDepartments",
			SELECT_RESTRICTED_INST: "SelectRestrictedInstallations",
			SELECT_USER_DEPT: "SelectUserDepartment",
			MANAGE_EXPIRY_DATE: "ManageExpiryDate"
		},
		Error: {
			INSUFFICIENT_AUTH_EN: "User does not have the sufficient authorizations.",
			INSUFFICIENT_AUTH_DE: "keine ausreichende Berechtigung.",
			INSUFFICIENT_AUTH_FR: "pas les autorisations suffisantes.",
			INSUFFICIENT_AUTH_ES: "no tiene suficientes permisos.",
			INSUFFICIENT_AUTH_PT: "tem permiss\u00F5es suficientes.",
			INSUFFICIENT_AUTH_JA: "\u30E6\u30FC\u30B6\u306B\u306F\u5341\u5206\u306A\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093",
			DUPLICATE_NAME_AUTH_PACK: "Invalid input for Authorization Package Text",
			INTERNAL_ERROR: "Internal error occurred, contact your system administrator"
		},
		ImportantContactFunction: {
			SUPERADMIN: "1SUPERADMIN",
			SUPERADMIN_CLOUD: "1SUPERADMIN_CLOUD",
			USERADMIN: "USERADMIN"
		},
		ReqConfigAction: {
			SAR_ENABLED: "S_AUTH_REQ",
			ADMIN_LIST: "ADMIN_LIST",
			CUSTOM_MESSAGE: "CUST_MSG"
		},
		ReqConfigCategory: {
			SELF_AUTH_REQUEST: "SAR"
		},
		RequestStatus: {
			REJECTED: "R"
		},
		TopLevel: {
			CCC: "CCC",
			DEBITOR: "DEBITOR",
			GLOBAL: "GLOBAL"
		},
		TypeOfRequest: {
			AUTHORIZATION: "Authorization",
			EXPIRY_DATE: "Expiry_date"
		},
		UAModel: {

		},
		UserCriticalRole: {
			SUPERADMIN: "1SUPERADMIN",
			SUPERADMIN_CLOUD: "1SUPERADMIN_CLOUD",
			USERADMIN: "USERADMIN",
			USERADMIN_CLOUD: "USERADMIN_CLOUD",
			PARTNER_SEC_MANAGER: "PRM_SMGR"
		},
		UserExpirationStatus: {
			ACTIVE: "I",
			EXPIRING: "X",
			EXPIRED: "E",
			REQUESTED: "R",
			INACTIVE: "N"
		},
		UserSet: {
			COUNTRY: "Land1T",
			CUSTOMER_NAME: "KunnrName",
			CUSTOMER_NUMBER: "Kunnr",
			DEPARTMENT: "Department",
			EMAIL: "Ipadr",
			FIRST_NAME: "Namev",
			LAST_NAME: "Name1",
			USER_ID: "Susid",
			SEARCH_FIELD: "SearchField"
		},
		UserType: {
			CUSTOMER: "Customer",
			PARTNER: "Partner"
		},
		Functions: {
			IsEmailDuplicate: "/IsEmailDuplicate",
			GetDuplicateEmails: "/GetDuplicateEmails",
			AppSettings: "/AppSettings"
		},
		Response: {
			NotDuplicateEmail: {
				IsEmailDuplicate: {
					boolValue: false
				}
			}
		},
		Links: {
			EMAIL_HELP_PAGE: "https://support.sap.com/en/my-support/users/email-guidelines.html"
		},
		INITIAL_PROPS: [{
			block: "INIT_EMPTYSTRING_PROPS",
			defValue: ""
		}, {
			block: "INIT_FALSE_PROPS",
			defValue: false
		}, {
			block: "INIT_TRUE_PROPS",
			defValue: true
		}, {
			block: "INIT_ARRAY_PROPS",
			defValue: []
		}, {
			block: "INIT_VALUESTATE_PROPS",
			defValue: sap.ui.core.ValueState.None
		}],
		INIT_EMPTYSTRING_PROPS: ["CustomerNumber", "CustomerText", "FirstName", "LastName", 
		"Email", "Notes", "Department", "DepartmentId", 
		"EmailLocalPart", "NamePartOfEmail", "DomainPartOfEmail"],
		INIT_FALSE_PROPS: ["submitEnabled"],
		INIT_TRUE_PROPS: ["NoAllowedDomainsPresent"],
		INIT_ARRAY_PROPS: ["APs", "Errors", "ValidationMessages", "DuplicateUsers", "AllowedDomainsList"],
		INIT_VALUESTATE_PROPS: ["EmailInputValueState", "emailDomainSuperCloudAdminValueState", "emailDomainUserAdminValueState", 
			"valueStateForNotesArea", "EmailValueState", "FirstNameValueState", "LastNameValueState",
			"ExpiryDateValueState", "CustomerValueState"
		],
		INIT_DATE_PROPS: ["DefaultExpiryDate", "SelectedExpiryDate"],
		INIT_VALIDATION_STATE: {
			FirstName: true,
			LastName: true,
			Email: true,
			SharedEmail: true,
			DuplicateEmail: true,
			ExpiryDate: true,
			ExpiryDateOverRange: true,
			Customer: true,
			AdditionalNoteNeeded: false,
			EmailDomainPresent: true,
			EmailDomainCorrectFormat: true
		}
	});
});
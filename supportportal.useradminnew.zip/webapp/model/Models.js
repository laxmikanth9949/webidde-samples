sap.ui.define([
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	"sap/ui/Device",
	"sap/ui/model/json/JSONModel",
	"sap/m/ListMode",
	"sap/m/ListType"
], function (Constant, Util, Device, JSONModel, ListMode, ListType) {
	"use strict";
	var _oDialogs = {};
	var _bIsMissingAuthDialogOpen = false;

	var _showMissingAuthPopUpForNonAdmins = function (oData,oUABundle) {
		return new Promise(function(res){
			var oslpUrl = window.location.href.split("user/management")[0],
				myImportantContactsUrl = oslpUrl + "ImportantContacts",
				messageBoxText1 = oUABundle.getText("AUTH_MISSING_BODY_1"),
				messageBoxText2 = oUABundle.getText("AUTH_MISSING_BODY_2"),
				messageBoxText = messageBoxText1 + myImportantContactsUrl + messageBoxText2,
				messageBoxTitle = oUABundle.getText("AUTH_MISSING_TITLE"),
				bIsAdmin = false,
				formattedText = new sap.m.FormattedText({
					htmlText: messageBoxText
				});
			var oUser = oData.results && oData.results[0] || {};	
			var sUserId = oUser.Userid;	
			var sPath = Util.formatMessage("/UserSet(''{0}'')/UserExistingAuthorizationsSet", [sUserId]);
			var oDataUM = new sap.ui.model.odata.v2.ODataModel("/services/odata/useradminsrv", {
				json: true
			});	
			var oDataAP = new sap.ui.model.odata.v2.ODataModel("/services/odata/authpackagessrv/", {
				json: true
			});
			oDataUM.read(sPath, {
				success: function (aResults) {
					var authList = aResults && aResults.results || [];
					for(var authIndex in authList){
						if(authList[authIndex].ObjectId === "USER"){
							bIsAdmin = true;
						}
					}
					if(bIsAdmin || _bIsMissingAuthDialogOpen) {
						return res(true);
					}
					Util.promiseRead("/auth_pack_set_for_userSet", {
						filters: [new sap.ui.model.Filter("SUser", sap.ui.model.FilterOperator.EQ, sUserId)]
					}, oDataAP)
					.then(function(oRes) {
						var aRes = oRes.results || [];
						return Promise.all(aRes.map(function (oAuthPackObject) {
							var sAuthPackId = oAuthPackObject.AuthPackId,
							aFilters = [new sap.ui.model.Filter("AuthPackId",sap.ui.model.FilterOperator.EQ, sAuthPackId)],
							aSkipAuthFilters = aFilters.concat([new sap.ui.model.Filter("SkipAuthCheck", sap.ui.model.FilterOperator.EQ, true)]);

							return Util.promiseRead("/Auth_pack_detailSet", {
								filters: aSkipAuthFilters
							}, oDataAP)
							.then(function (oPackData) {
								var aPackResults = oPackData.results || [];
								return aPackResults.some(function (oAuth) {
									return oAuth.Object === "USER";
								});
							});
						}));
					})
					.then(function (aAPRes) {
						bIsAdmin = aAPRes.some(function(value) {
							return value;
						});
						if(!bIsAdmin && !_bIsMissingAuthDialogOpen) {
							_bIsMissingAuthDialogOpen = true;
							sap.m.MessageBox.show(formattedText, {
								contentWidth: "35rem",
								icon: sap.m.MessageBox.Icon.ERROR,
								title: messageBoxTitle,
								actions: [oUABundle.getText("GO_BACK")],
								onClose: function (oAction) {
									if (oAction === oUABundle.getText("GO_BACK")) {
										_bIsMissingAuthDialogOpen = false;
										window.location.replace(oslpUrl);
									}
								}			
							});				
						} else {
							res(true);
						}
					});
				}
			});
		});
	};

	/**
	 * Handle 403 Forbidden errors
	 * @param {object} oParameters error event parameters
	 * @param {sap.support.useradmininstration.model.ErrorResponse} oError error response object
	 * @param {jQuery.sap.util.ResourceBundle} oUABundle i18n bundle
	 * @returns {boolean} whether to stop error handling
	 * @function
	 * @private
	 */
	var _handleForbiddenResponse = function (oParameters, oError, oUABundle) {
		return new Promise(function(res){
			var sErrorMessage = oError.getMessage(),
			sCode = oError.getCode(),
			isAForbiddenAuthCode = sCode && sCode[0] !== "/" && "ERROR_NOT_AUTHORIZED".startsWith(sCode),
			isAForbiddenAuthResonse = Constant.Error.INSUFFICIENT_AUTH_EN.startsWith(sErrorMessage); 
			isAForbiddenAuthResonse = isAForbiddenAuthResonse || sErrorMessage.includes(Constant.Error.INSUFFICIENT_AUTH_DE);
			isAForbiddenAuthResonse = isAForbiddenAuthResonse || sErrorMessage.includes(Constant.Error.INSUFFICIENT_AUTH_FR);
			isAForbiddenAuthResonse = isAForbiddenAuthResonse || sErrorMessage.includes(Constant.Error.INSUFFICIENT_AUTH_ES);
			isAForbiddenAuthResonse = isAForbiddenAuthResonse || sErrorMessage.includes(Constant.Error.INSUFFICIENT_AUTH_PT);
			isAForbiddenAuthResonse = isAForbiddenAuthResonse || Constant.Error.INSUFFICIENT_AUTH_JA.startsWith(sErrorMessage);
			isAForbiddenAuthResonse = (sErrorMessage && sErrorMessage.trim() && isAForbiddenAuthResonse);
			if (Number(oParameters.response.statusCode) === 403  || isAForbiddenAuthResonse || isAForbiddenAuthCode) {

				var oDataUM = new sap.ui.model.odata.v2.ODataModel("/services/odata/useradminsrv", {
						json: true
					});
				oDataUM.read("/LogonUserInfoSet", {
					success: function (oData) {
						_showMissingAuthPopUpForNonAdmins(oData,oUABundle)
							.then(function(bNonAdmin){
									return res(!bNonAdmin);	
							});
					}
				});
				// return true;
			} else {
			   return res(false);	
			}
		});
		
	};
	/**
	 * Handle specific errors
	 * @param {object} oParameters error event parameters
	 * @param {sap.support.useradmininstration.model.ErrorResponse} oError error response object
	 * @param {jQuery.sap.util.ResourceBundle} oUABundle i18n bundle
	 * @returns {boolean} whether to stop error handling
	 * @function
	 * @private
	 */
	var _fnHandleSpecialErrors = function (oParameters, oError, oUABundle) {
		return new Promise(function(res){
			if (Number(oParameters.response.statusCode) === 504) {
				var oUserAuthReportSet = /UserAuthReportSet(\/\$count)?/.exec(oParameters.url);
				if (oUserAuthReportSet) {
					var bIsCountRequest = oUserAuthReportSet[1];
					if (!bIsCountRequest) {
						Util.Error.display({
							message: oUABundle.getText("MISC_ERROR"),
							messageBody: oUABundle.getText("MASTER_TIMEOUT")
						});
					}
					return res(true);
				}
			}
			if (Number(oParameters.response.statusCode) === 404) {
				var oUserDetailSet = /UserSet\(\'S[0-9]+\'\)/.exec(oParameters.url);
				if (oUserDetailSet) {
					return res(true);
				}
			}
			if (oError.isHTML() && oError.getTitle() === "Bad Request") {
				return res(true);
			}
			if (/Auth_pack_detailSet/.exec(oParameters.url)) {
				return res(true);
			}

            _handleForbiddenResponse(oParameters, oError, oUABundle)
		      .then(function(bResult){
                  res(bResult);
		       });
		});	
	};
	
	/**
	 * Show dialog if not exists
	 * @param {object} oOptions dialog options
	 * @function
	 * @private
	 */
	var _fnShowDialog = function (oOptions) {
		var sText = oOptions.message,
			oDialog = _oDialogs[sText];
		if (sText) {
			if (oDialog && !oDialog._bIsDestroyed) {
				if (!oDialog.isOpen()) {
					oDialog.open();
				}
				return;
			} else {
				_oDialogs[sText] = Util.Error.display(oOptions);
			}
		}
	};
	return {
		/**
		 * Set model size limit and attach error handlers
		 * @param {sap.ui.model.odata.v2.ODataModel} oModel model
		 * @function
		 * @public
		 */
		configureODataModel: function (oModel) {
			var oUABundle = Util.getBundle.call(this);
			oModel.setSizeLimit(10000);
			oModel.attachRequestSent(function (oEvent) {
				if (!oModel.bUseBatch) {
					if (oEvent.getParameter("url").length > 2000) {
						_fnShowDialog({
							message: oUABundle.getText("MESSAGE_LONG_URL"),
							messageBody: oUABundle.getText("MESSAGE_DECREASE_FILTERS_VALUES"),
							responseText: oEvent.getParameter("responseText"),
							statusCode: oEvent.getParameter("statusCode"),
							statusText: oEvent.getParameter("statusText")
						});
					}
				}
			});
			oModel.attachParseError(function (oEvent) {
				_fnShowDialog({
					message: oEvent.getParameter("message"),
					responseText: oEvent.getParameter("responseText"),
					statusCode: oEvent.getParameter("statusCode"),
					statusText: oEvent.getParameter("statusText")
				});
			});
			oModel.attachRequestFailed(function (oEvent) {
				var oError = Util.parseError(oEvent.getParameter("response").responseText || ""),
					sText = "",
					sBody = "";

				var sResponseText = oEvent.getParameter("responseText"),
				    sStatusCode = oEvent.getParameter("statusCode"),
				    sStatusText = oEvent.getParameter("statusText")

				var fnGeneralErrors = function(bSpecialErrorHandled){
					if (bSpecialErrorHandled) {
						return;
					}
					if (oError.isJSON()) {
						var sCode = oError.getCode(),
							sMessage = oError.getMessage();
						if (sMessage === Constant.Error.DUPLICATE_NAME_AUTH_PACK) {
							return;
						}
						if (sMessage === Constant.Error.INTERNAL_ERROR) {
							return;
						}
						sText = oUABundle.getText(sCode + "_TITLE");
						if (sCode && sCode[0] !== "/" && sCode !== 'SY/530') {							
							sBody = oUABundle.getText(sCode + "_MESSAGE");
						} else {
							sBody = oError.getMessage();
						}
					} else if (oError.isHTML()) {
						sBody = oError.getMessage();
						sText = oError.getTitle();
					} else {
						sText = oError.getMessage();
					}
					// Remove period from title
					if (/\.$/.test(sText)) {
						sText = sText.substring(0, sText.length - 2);
					}
					_fnShowDialog({
						message: sText,
						messageBody: sBody,
						responseText: sResponseText,
						statusCode: sStatusCode,
						statusText: sStatusText
					});
				};

				_fnHandleSpecialErrors(oEvent.getParameters(), oError, oUABundle)
				   .then(fnGeneralErrors.bind(this));				
			});
		},
		/**
		 * Create app model for app settings
		 * @returns {sap.ui.model.json.JSONModel} model
		 * @function
		 * @public
		 */
		createAppModel: function () {
			return new JSONModel({
				DefaultLang: "",
				LogonUserId: "",
				LogonUserCCC: false,
				showUiUniversalid: false,
				IsSUser: false,
				IsSuperAdmin: false
			});
		},

		createAppSettingsModel: function () {
			return new JSONModel({
				backendLogicVersion: "",
				emailRegexp: "",
				useNewCreateAp: "",
				isEmailFilterEnabled: false,
				isDomainFilterEnabled: false
			});
		},
		/**
		 * Create model for request config
		 * @returns {sap.ui.model.json.JSONModel} model
		 * @function
		 * @public
		 */
		createReqConfigModel: function () {
			return new JSONModel({
				CanEditSARSettings: false,
				SAR: {
					IsEnabled: true,
					IsCustomMessageEnabled: false,
					CustomText: "",
					CustomerId: ""
				}
			});
		},
		/**
		 * Create device model
		 * @returns {sap.ui.model.json.JSONModel} model
		 * @function
		 * @public
		 */
		createDeviceModel: function () {
			var oModel = new JSONModel({
				isTouch: Device.support.touch,
				isNoTouch: !Device.support.touch,
				isPhone: Device.system.phone,
				isNoPhone: !Device.system.phone,
				listMode: Device.system.phone ? ListMode.None : ListMode.SingleSelectMaster,
				listItemType: Device.system.phone ? ListType.Active : ListType.Navigation
			});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		/**
		 * Create View model for binding UI elements' properties
		 * @returns {sap.ui.model.json.JSONModel} model
		 * @function
		 * @public
		 */
		createViewModel: function () {
			var oModel = new JSONModel({
				InfoBanner: {
					InfoText: "",
					ButtonEnabled: true
				},
				APDetail: {
					Auth: {},
					EditAuthority: true,
					ViewMode: false
				},
				Master: {
					APActual: 0, // Number of actually visible entries in Auth. Packages tab
					APTotal: 0, // Number of all entries in Auth. Packages tab
					APButtons: {
						Protect: false,
						Unprotect: false,
						Report: false,
						Overview: false,
						Delete: false,
						Rename: false,
						AssignUsers: false,
						Copy: false
					},
					ReportsNumber: 0, // Number of selected reports in Reports and Updates tab
					TabKey: "",
					IsAnyUserSelected: false,
					IsAnyUserSelectedForManageExpDate: false,
					IsTooManyUsersSelectedForMassExtention: false,

					Count: {
						User: 0,
						TotalUser: 0,
						ReqUser: 0,
						TotalReqUser: 0,
						DelUser: 0,
						TotalDelUser: 0,
						ImpContacts: 0,
						TotalImpContacts: 0,
						AP: -1
					},

					Settings: {
						AuthRequestEdit: false
					},
					ReqAuth: {
						Actual: 0,
						List: [{
							LastName: "Test",
							FirstName: "Vladimir",
							Email: "test.vladimir@sap.com",
							UserId: "S0123456789",
							CustomerName: "SAP Test Account",
							CustomerNumber: "987654",
							RequestedBy: "S0098765432",
							RequestedOn: "2018-12-19T00:00:00",
							TypeOfRequest: "Authorization",
							RequestStatus: "Pending"
						}, {
							LastName: "Test",
							FirstName: "Request",
							Email: "test.request@sap.com",
							UserId: "S0555556789",
							CustomerName: "SAP New Test",
							CustomerNumber: "322144",
							RequestedBy: "S0011165432",
							RequestedOn: "2019-01-12T00:00:00",
							TypeOfRequest: "Authorization",
							RequestStatus: "Pending"
						}],
						Total: 0
					}
				},
				ReqAuthDetail: {
					AuthDetails: {
						Level: "",
						LevelName: ""
					},
					Edit: false
				},
				UserDetail: {
					Auth: {},
					AuthPackages: {},
					Cloud: {},
					Contact: {},
					EditAuthority: false,
					User: {},
					ViewMode: false,
					History: {}
				},
				RequestDetail: {
					Auth: {},
					Cloud: {},
					Contact: {},
					EditAuthority: false,
					User: {}
				},
				RequestUser: {
					CustomerNumber: "",
					CustomerText: "",
					SalutationKey: "",
					FirstName: "",
					LastName: "",
					Email: "",
					LanguageCode: "",
					Department: "",
					DepartmentId: "",
					Notes: "",
					APs: [],
					MinExpiryDate: null,
					MaxExpiryDate: null,
					DefaultExpiryDate: null,
					SelectedExpiryDate: null,
					ValidationEmailText: "",
					EmailLocalPart: "",
					Validation: {},
					Errors: [],
					DuplicateUsers: []
				},
				UserRolesAuthorizations: {

				},
				CreateAP: {
					AuthPackName: "",
					Protection: false,
					validation: {}
				}
			});

			oModel.setSizeLimit(10000);
			return oModel;
		}
	};
});
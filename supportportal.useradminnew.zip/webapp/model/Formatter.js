sap.ui.define([
	"sap/support/useradministration/model/formatter/DetailFormatter",
	"sap/support/useradministration/model/formatter/DialogFormatter",
	"sap/support/useradministration/model/formatter/MasterFormatter",
	"sap/support/useradministration/model/formatter/RequestFormatter",
	"sap/support/useradministration/model/Constant",
	"sap/support/useradministration/util/Util",
	"sap/support/useradministration/util/DateUtil"
], function (DetailFormatter, DialogFormatter, MasterFormatter, RequestFormatter, Constant, Util, DateUtil) {

	var ListType = sap.m.ListType,
		ValueState = sap.ui.core.ValueState;

	var UserExpirationStatus = Constant.UserExpirationStatus,
		UserCriticalRole = Constant.UserCriticalRole,
		UserType = Constant.UserType;

	var Formatter = {
		detail: DetailFormatter,
		dialog: DialogFormatter,
		master: MasterFormatter,
		request: RequestFormatter,

		/**
		 * Concat strings
		 * @returns {string} result
		 * @function
		 * @public
		 */
		concat: function () {
			return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
		},
		
		concatWithoutSpaces: function () {
			return Array.prototype.slice.call(arguments).filter(Boolean).join("");
		},
		
		/**
		 * Get icon URI according to user's role (Customer or Partner)
		 * @param {string} sUserType user type
		 * @returns {sap.ui.core.URI} icon URI
		 * @function
		 * @public
		 */
		customerOrPartnerIcon: function (sUserType) {
			switch (sUserType) {
				case UserType.CUSTOMER:
					return "sap-icon://customer";
				case UserType.PARTNER:
					return "sap-icon://group";
				default:
					return "";
			}
		},
		
		/**
		 * Get text according to user's role (Customer or Partner)
		 * @param {string} sUserType user type
		 * @returns {string} Customer or Partner text
		 * @function
		 * @public
		 */
		customerOrPartnerText: function (sUserType) {
			switch (sUserType) {
				case UserType.CUSTOMER:
					return Util.getText.call(this, "TOOLTIP_CUSTOMER");
				case UserType.PARTNER:
					return Util.getText.call(this, "TOOLTIP_PARTNER");
				default:
					return "";
			}
		},

		/**
		 * Format values separated with dash
		 * @param {string...} sString arguments
		 * @returns {string} strings separated with dash
		 * @function
		 * @public
		 */
		dash: function () {
			return Array.prototype.slice.call(arguments).join(" - ");
		},

		/**
		 * Format date or empty string
		 * @param {string|Date} sDate backend date
		 * @returns {string} formatted date or empty string if it is under 1970's
		 * @function
		 * @public
		 */
		dateOrEmpty: function (sDate) {
			var oDate = Util.date.getDate(sDate);
			if (oDate && oDate.getTime() <= 0) {
				return "";
			}
			return Util.date.formatDate(oDate);
		},

		/**
		 * Format date or Never label
		 * @param {string|Date} sDate backend date
		 * @returns {string} formatted date or Never if it is under 1970's
		 * @function
		 * @public
		 */
		dateOrNever: function (sDate) {
			var oDate = Util.date.getDate(sDate);
			if (!oDate || (oDate && oDate.getTime() <= 0)) {
				return Util.getText.call(this, "MISC_NEVER");
			}
			return Util.date.formatShortDate(oDate);
		},
		
		/**
		 * Get Error value state according on true, None otherwise
		 * @param {boolean} bIsError if show error
		 * @returns {sap.ui.core.ValueState} value state
		 * @function
		 * @public
		 */
		errorValueState: function (bIsError) {
			return bIsError ? ValueState.Error : ValueState.None;
		},

		/**
		 * Format date retrieved from the backend
		 * @param {string} sDate backend date
		 * @returns {string} formatted Date
		 * @function
		 * @public
		 */
		fromBackendDate: function (sDate) {
			return Util.date.formatBackendDate(sDate);
		},
		
		/**
		 * Check if value is ABAP true
		 * @param {string} sValue value
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isAbapTrue: function (sValue) {
			return sValue === Constant.ABAP_TRUE;
		},

		/**
		 * Check if any argument is true
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isAnyTrue: function () {
			return Array.prototype.some.call(arguments, Boolean);
		},

		/**
		 * Check if false
		 * @param {any} vValue value
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isFalse: function (vValue) {
			return !vValue;
		},

		/**
		 * Check if no true args
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isNoneTrue: function () {
			return !Array.prototype.some.call(arguments, Boolean);
		},

		/**
		 * Check if values are not equal
		 * @param {any} vFirst first value
		 * @param {any} vSecond second value
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isNotEqual: function (vFirst, vSecond) {
			return vFirst !== vSecond;
		},

		/**
		 * Check if true
		 * @param {any} vValue value
		 * @returns {boolean} result
		 * @function
		 * @public
		 */
		isTrue: function (vValue) {
			return Boolean(vValue);
		},

		/**
		 * Check if user expiration status is not Requested
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isUserExpirationStatusNotRequested: function (sExpirationStatus) {
			return sExpirationStatus !== UserExpirationStatus.REQUESTED;
		},

		/**
		 * Check if user expiration status is Requested
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isUserExpirationStatusRequested: function (sExpirationStatus) {
			return sExpirationStatus === UserExpirationStatus.REQUESTED;
		},

		/**
		 * Check if user's expiry date can be managed according to its role
		 * @param {string} sUserCriticalRoleID UserCriticalRoleID property
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isUserRoleAllowedForManageExpiry: function (sUserCriticalRoleID) {
			switch (sUserCriticalRoleID) {
				case UserCriticalRole.SUPERADMIN:
				case UserCriticalRole.SUPERADMIN_CLOUD:
				case UserCriticalRole.USERADMIN:
				case UserCriticalRole.USERADMIN_CLOUD:
					return false;
				default:
					return true;
			}
		},
		
		/**
		 * Check if user's expiry date can be changed
		 * @param {string} sExpirationStatus user expiration status
		 * @param {string} sUserCriticalRoleID user function
		 * @returns {boolean} enabled state
		 * @function
		 * @public
		 */
		isUsersExpiryDateCanBeChanged: function (sExpirationStatus, sUserCriticalRoleID) {
			switch (sExpirationStatus) {
				case UserExpirationStatus.ACTIVE:
				case UserExpirationStatus.EXPIRING:
				case UserExpirationStatus.EXPIRED:
					return Formatter.isUserRoleAllowedForManageExpiry(sUserCriticalRoleID);
				default:
					return false;
			}
		},
		
		/**
		 * Check if user's expiry date can be changed in the mass update
		 * @param {string} sExpirationStatus user expiration status
		 * @param {string} sUserCriticalRoleID user function
		 * @returns {boolean} enabled state
		 * @function
		 * @public
		 */
		isUsersExpiryDateCanBeMassChanged: function (sExpirationStatus, sUserCriticalRoleID, oCreatedOn, oLastLogin) {
			switch (sExpirationStatus) {
				case UserExpirationStatus.EXPIRING:
				case UserExpirationStatus.EXPIRED:
					return Formatter.isUserRoleAllowedForManageExpiry(sUserCriticalRoleID);
				case UserExpirationStatus.ACTIVE:
					var oDate = DateUtil.shiftDate(new Date(), 0, -12, 0),
					isCreatedOnLast12Month = oCreatedOn > oDate,
					isLoggedInLast12Month = oLastLogin > oDate;
					
					return (isCreatedOnLast12Month || isLoggedInLast12Month) ? Formatter.isUserRoleAllowedForManageExpiry(sUserCriticalRoleID) : false;
				default:
					return false;
			}
		},
		
		/**
		 * Check if user is a Super Admin
		 * @param {string} sUserCriticalRoleID UserCriticalRoleID property
		 * @returns {boolean} check result
		 * @function
		 * @public
		 */
		isSuperAdmin: function (sUserCriticalRoleID) {
			return sUserCriticalRoleID === UserCriticalRole.SUPERADMIN || sUserCriticalRoleID === UserCriticalRole.SUPERADMIN_CLOUD;
		},

		/**
		 * Get list item type
		 * @param {boolean} bNavigation if type is Navigation
		 * @returns {sap.m.ListType} Navigation if true, Inactive otherwise
		 * @function
		 * @public
		 */
		listItemNavigation: function (bNavigation) {
			return bNavigation ? ListType.Navigation : ListType.Inactive;
		},
		
		/**
		 * Get None value state on true, Error otherwise
		 * @param {boolean} bIsNotError if not show error
		 * @returns {sap.ui.core.ValueState} value state
		 * @function
		 * @public
		 */
		noneOrErrorValueState: function (bIsNotError) {
			return bIsNotError ? ValueState.None : ValueState.Error;
		},

		/**
		 * Get numeric value
		 * @param {any} vValue value
		 * @returns {number} numeric value
		 * @function
		 * @public
		 */
		number: function (vValue) {
			return Number(vValue) || 0;
		},

		/**
		 * Format phone code
		 * @param {string} sPhoneOrCountryCode country's phone code or country id
		 * @returns {string} phone code
		 * @function
		 * @public
		 */
		phoneCode: function (sPhoneOrCountryCode) {
			if (!/\+/.test(sPhoneOrCountryCode)) {
				var sCode = Util.getCountryPhoneCode(sPhoneOrCountryCode);
				return (sCode && "+" + sCode) || sPhoneOrCountryCode;
			}
			return sPhoneOrCountryCode;
		},

		/**
		 * Format phone number with phone code in User Detal Page
		 * @param {string} sPhoneOrCountryCode country's phone code or country id
		 * @param {string} sNumber phone number part without country's phone code
		 * @returns {string} phone number
		 * @function
		 * @public
		 */
		phoneNumber: function (sPhoneOrCountryCode, sHandy) {
			if (sHandy) {
				return Formatter.phoneCode(sPhoneOrCountryCode) + " " + sHandy;
			}
			return "";
		},

		/**
         * Get value state for phone field
         * @param {string} sPhone phone
		 * @param {string} sPhoneRegexp regular expression to exclude
		 * @param {string} sPhoneMaxLength maximal limit of characters for the field
         * @param {string} sPhoneField input field phone originates from (so we can track ValueStates for the each field)
		 * @returns {sap.ui.core.ValueState} None for valid phone, Error otherwise
         * @function
         * @public
         */
		phoneValueState: function (sPhone, sPhoneRegexp, sPhoneMaxLength, sPhoneField) {
			var phoneRegExp = new RegExp(sPhoneRegexp, "g");
			var isValidPhone = !sPhone || (!phoneRegExp.test(sPhone) && sPhone.length <= parseInt(sPhoneMaxLength));
			this._setViewProperty("Contact/Data/IsValid" + sPhoneField, isValidPhone);
			return isValidPhone  
				? ValueState.None 
				: ValueState.Error;
		},

		/**
         * Get value state text for phone field
         * @param {string} sPhone phone
		 * @param {string} sPhoneMaxLength maximal limit of characters for the field
         * @returns {string} the "length" error message if the length is more than 16 symbols, the "correct phone format" one otherwise
         * @function
         * @public
         */
		phoneValueStateText: function (sPhone, sPhoneMaxLength) {
			return (sPhone && sPhone.length > parseInt(sPhoneMaxLength)) 
				? Util.getText.call(this, "MESSAGE_PHONE_LENGTH_INVALID") 
				: Util.getText.call(this, "MESSAGE_PHONE_CORRECT_FORMAT");
		},

		/**
		 * Format short date
		 * @param {Date} oDate backend date
		 * @returns {string} formatted date
		 * @function
		 * @public
		 */
		shortDate: function (oDate) {
			return Util.date.formatShortDate(oDate);
		},

		/**
		 * Format title and number
		 * @param {string} sTitle title
		 * @param {any} vValue value to convert into number
		 * @returns {string} title with number
		 * @function
		 * @public
		 */
		titleAndNumber: function (sTitle, vValue) {
			return sTitle + " (" + vValue + ")";
		},

		/**
		 * Make string uppercase
		 * @param {string} sString string
		 * @returns {string} upper-cased string
		 * @function
		 * @public
		 */
		upperCase: function (sString) {
			if (sString && sString.toUpperCase) {
				return sString.toUpperCase();
			}
			return "";
		},

		/**
		 * Format text for User Status field in the user detail page
		 * Show if user is Active, Expiring or already Expired
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {string} user expiration status text
		 * @function
		 * @public
		 */
		userExpirationStatusText: function (sExpirationStatus) {
			switch (sExpirationStatus) {
			case UserExpirationStatus.EXPIRED:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_EXPIRED");
			case UserExpirationStatus.EXPIRING:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_EXPIRING");
			case UserExpirationStatus.REQUESTED:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_CHANGE_REQUESTED");
			case UserExpirationStatus.ACTIVE:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_ACTIVE");
			case UserExpirationStatus.INACTIVE:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_INACTIVE");
			default:
				return "";
			}
		},

		/**
		 * Get value state for User Status field in the user detail page
		 * @param {string} sExpirationStatus user expiration status
		 * @returns {sap.ui.core.ValueState} value state
		 * @function
		 * @public
		 */
		userExpirationStatusValueState: function (sExpirationStatus) {
			switch (sExpirationStatus) {
			case UserExpirationStatus.EXPIRED:
				return "Indication01";
			case UserExpirationStatus.EXPIRING:
				return "Indication02";
			case UserExpirationStatus.REQUESTED:
				return "Indication05";
			case UserExpirationStatus.ACTIVE:
				return "Indication04";
			case UserExpirationStatus.INACTIVE:
				return "Indication03";
			default:
				return ValueState.None;
			}
		},
		/**
		 * Get value state for UID Status field in the user list
		 * @param {string} uidStatus uid status
		 * @returns {sap.ui.core.ValueState} value state
		 * @function
		 * @public
		 */
		 uidStatusValueState: function (uidStatus) {
			return uidStatus ? "Success" : "Warning";
		},
		userExpirationStatusTooltip: function (sExpirationStatus, oExpDate) {
			switch (sExpirationStatus) {
			case UserExpirationStatus.EXPIRED:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_EXPIRED_TOOLTIP");
			case UserExpirationStatus.EXPIRING:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_EXPIRING_TOOLTIP");
			case UserExpirationStatus.REQUESTED:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_CHANGE_REQUESTED_TOOLTIP", [Util.date.formatStandardUTCDate(oExpDate)]);
			case UserExpirationStatus.ACTIVE:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_ACTIVE_TOOLTIP");
			case UserExpirationStatus.INACTIVE:
				return Util.getText.call(this, "USER_EXPIRATION_STATUS_INACTIVE_TOOLTIP");
			default:
				return "";
			}
		},
	
		/**
		 * Get enabled or not for Extend Action button
		 * @param {string} sExpirationStatus user expiration status
		 * @param {string} sUserCriticalRoleID user function
		 * @returns {boolean} enabled state
		 * @function
		 * @public
		 */
		userExpirationExtendActionEnable: function (sExpirationStatus, sUserCriticalRoleID) {
			 return sExpirationStatus !== UserExpirationStatus.REQUESTED && sExpirationStatus !== UserExpirationStatus.INACTIVE && Formatter.isUserRoleAllowedForManageExpiry(sUserCriticalRoleID);
		},
		
		/**
		 * Get date pattern as assigned in the User Profile
		 * @returns {string} date pattern
		 * @function
		 * @public
		 */
		userProfleDatePattern: function () {
			return Util.date.getUserProfileDatePattern();
		},

		/**
		 * Get value state
		 * @param {boolean} bError if state is Error
		 * @returns {sap.ui.core.ValueState} Error if true, None otherwise
		 * @function
		 * @public
		 */
		valueStateError: function (bError) {
			return bError ? ValueState.Error : ValueState.None;
		},
		
		getAPDescription: function (isProtected) {
			return ((isProtected) ? ("<strong>" + Util.getText.call(this, "MISC_PROTECTED") + "</strong> ") : "") +
				Util.getText.call(this, "MASTER_AUTH_PACKAGE");
		},
		
		getTooltipAuthAssignButton: function (AuthLevelId) {
			if (AuthLevelId === "USER") {
				return Util.getText.call(this, "BUTTON_USER_AUTH_ADD");
			} else if (AuthLevelId === "INSTALL") {
				return Util.getText.call(this, "BUTTON_INST_AUTH_ADD");
			}
			return "";
		},
		
		getlAuthObjColumnName: function (AuthLevelId) {
			if (AuthLevelId === "USER") {
				return Util.getText.call(this, "AUTHORIZATION_LEVEL_USER_NAME");
			} else if (AuthLevelId === "INSTALL") {
				return Util.getText.call(this, "AUTHORIZATION_LEVEL_INST_NAME");
			}
			return "";
		},

		getAuthObjRemoveTooltip: function (bIsDisabled) {
			if (bIsDisabled){
				return  Util.getText.call(this, "TOOLTIP_NO_PERMISSION_TO_REMOVE");	
			} else {
				return  Util.getText.call(this, "BUTTON_REMOVE");
			}
		},
		
		getAuthAssignNoDataText: function (AuthLevelId) {
			if (AuthLevelId === "USER") {
				return Util.getText.call(this, "AUTH_OBJ_NO_USER_AUTH_DATA_TEXT");
			} else if (AuthLevelId === "INSTALL") {
				return Util.getText.call(this, "AUTH_OBJ_NO_INST_AUTH_DATA_TEXT");
			}
			return "";
		},

		getIncorrectEmailText: function (bIsValidEmail, bIsValidDomain) {
			if (bIsValidEmail && bIsValidDomain){
				return  " ";	
			} else {
				return  "X";
			}
		},

		getEmailDomain: function (ipadr) {
			if(ipadr) {

				return  "@" + ipadr.split('@')[1];
			}
		},
		
		createList: function () {
			return "<ul style=\"padding-inline-start: 1rem;\">" + [].map.call(arguments, function (text) {
				return "<li>" + text + "</li>";
			}).join("<br>") + "</ul>";
		},
		
		addColon: function (sText) {
			return sText + ":";
		},
		
		emailGuidelinesHref: function(sText) {
			return jQuery.sap.formatMessage(sText, Constant.Links.EMAIL_HELP_PAGE);
		}            
	};

	return Formatter;
});
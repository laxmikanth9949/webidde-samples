sap.ui.define([], function() {
"use strict";

return {
    ValidatorRequestUser: [{
        setters: [{
            properties: ["Validation/Email", "Validation/SharedEmail", "Validation/DuplicateEmail"],
            value: true
        }, {
            properties: ["EmailInputValueState"],
            value: sap.ui.core.ValueState.None
        }],
        constraint: [{
            property: "bEmailValid",
            not: false
        }]
    }, {
        setters: [{
            properties: ["Validation/Email"],
            value: false
        }, {
            properties: ["ValidationEmailText"],
            value: { path: "MESSAGE_EMAIL_INVALID", i18n: true }
        }, {
            properties: ["EmailInputValueState"],
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            property: "bEmailValid",
            not: true
        }, {
            property: "bEmailFormatValid",
            not: true
        }]
    }, {
        setters: [{
            properties: ["Validation/Email", "Validation/validLength"],
            value: false
        }, {
            properties: ["ValidationEmailText"],
            value: { path: "MESSAGE_EMAIL_LENGTH_INVALID", i18n: true }
        }, {
            properties: ["EmailInputValueState"],
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            property: "bEmailValid",
            not: true
        }, {
            property: "bInvalidLength",
            not: false
        }]
    }, {
        setters: [{
            properties: ["Validation/Email", "Validation/SharedEmail"],
            value: false
        }, {
            properties: ["ValidationEmailText"],
            value: { path: "MESSAGE_SHARED_EMAIL_NEW", i18n: true }
        }, {
            properties: ["EmailInputValueState"],
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            property: "bEmailValid",
            not: true
        }, {
            property: "bEmailShared",
            not: false
        }]
    }, {
        setters: [{
            properties: ["Validation/Email"],
            value: false
        }, {
            properties: ["Validation/DuplicateEmail"],
            value: true
        }, {
            properties: ["ValidationEmailText"],
            value: { path: "MESSAGE_EMAIL_ALREADY_EXISITS", i18n: true }
        }, {
            properties: ["EmailInputValueState"],
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            property: "bEmailValid",
            not: true
        }, {
            property: "bEmailDuplicate",
            not: false
        }]
    }],
    ValidationRequestUser: [{
        title: "VALUE_STATE_FIRST_NAME",
        subtitle: "DETAIL_USER_FIRST_NAME",
        type: "Error",
        valueStates: [{
            path: "FirstNameValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "Validation/FirstName",
            not: true
        }]
    }, {
        title: "VALUE_STATE_LAST_NAME",
        subtitle: "DETAIL_USER_LAST_NAME",
        type: "Error",
        valueStates: [{
            path: "LastNameValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "Validation/LastName",
            not: true
        }]
    }, {
        title: "MESSAGE_SHARED_EMAIL_NEW2",
        description: "MESSAGE_SHARED_EMAIL_POLICY_NEW2",
        type: "Error",
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: false
        }, {
            path: "Validation/Email",
            not: true 
        }, {
            path: "Validation/SharedEmail",
            not: true
        }]
    }, {
        title: "MESSAGE_EMAIL_INVALID_NEW",
        description: "MESSAGE_EMAIL_INVALID_POLICY",
        type: "Error",
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: false
        }, {
            path: "Validation/Email",
            not: true 
        }, {
            path: "Validation/validFormat",
            not: true
        }]
    }, {
        title: "MESSAGE_EMAIL_LENGTH_INVALID",
        description: [{
            path: "MESSAGE_EMAIL_LENGTH_POLICY", 
            args: [{ path: "_emailMaxLength", closure: true}]
        }],
        type: "Error",
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: false
        }, {
            path: "Validation/Email",
            not: true 
        }, {
            path: "Validation/validLength",
            not: true
        }]
    }, {
        title: "MESSAGE_EMAIL_ALREADY_EXISITS_NEW",
        description: "MESSAGE_STRIP_DETAILS__DUPLICATE_EMAIL",
        descPress: {
            func: "_showErrorEmailIsDuplicate",
            args: [true]
        },
        linkText: "MISC_SHOW_DUPLICATES",
        type: "Error",
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: false
        }, {
            path: "Validation/Email",
            not: false 
        }, {
            path: "Validation/DuplicateEmail",
            not: true
        }]
    }, {
        title: "MESSAGE_SHARED_EMAIL_NEW2",
        description: "MESSAGE_SHARED_EMAIL_POLICY_NEW2",
        type: "Error",
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: false
        }, {
            path: "Validation/Email",
            not: false 
        }, {
            path: "Validation/SharedEmail",
            not: true
        }]
    }, {
        title: "MESSAGE_SHARED_EMAIL_NEW_TWO_LINE",
        description: "MESSAGE_SHARED_EMAIL_POLICY_NEW",
        type: "Error",
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: true
        }, {
            path: "Validation/Email",
            not: true 
        }, {
            path: "Validation/SharedEmail",
            not: true
        }]
    }, {
        title: "MESSAGE_EMAIL_INVALID",
        type: "Error",
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: true
        }, {
            path: "Validation/Email",
            not: true 
        }, {
            path: "Validation/SharedEmail",
            not: false
        }]
    }, {
        title: "MESSAGE_EMAIL_LENGTH_INVALID",
        description: [{
            path: "MESSAGE_EMAIL_LENGTH_POLICY", 
            args: {
                path: "_emailMaxLength",
                closure: true
            }
        }],
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        type: "Error",
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: true
        }, {
            path: "Validation/Email",
            not: true 
        }, {
            path: "Validation/validLength",
            not: true
        }]
    }, {
        title: "MESSAGE_EMAIL_ALREADY_EXISITS_TWO_LINE",
        description: "MESSAGE_DUPLICATE_EMAIL_POLICY_NEW",
        type: "Error",
        valueStates: [{
            path: "EmailValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "/domainCheckActive",
            model: "appSettings",
            not: true
        }, {
            path: "Validation/Email",
            not: false
        }, {
            path: "Validation/DuplicateEmail",
            not: true
        }]
    }, {
        title: "MESSAGE_TITLE__UNVERIFIED_EMAIL_DOMAIN__SUPER_ADMIN",
        description: "MESSAGE_DESCRIPTION__UNVERIFIED_EMAIL_DOMAIN__SUPER_ADMIN",
        type: "Warning",
        valueStates: [{
            path: "emailDomainSuperCloudAdminValueState",
            value: sap.ui.core.ValueState.Warning
        }],
        constraint: [{
            path: "Validation/AdditionalNoteNeeded",
            not: false
        }]
    }, {
        title: "MESSAGE_TITLE__EMAIL_INCORRECT_FORMAT",
        description: "MESSAGE_DESCRIPTION__EMAIL_INCORRECT_FORMAT",
        type: "Error",
        valueStates: [{
            path: "emailDomainSuperCloudAdminValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "IsSuperAdmin",
            not: false
        }, [{
            path: "Validation/EmailDomainPresent",
            not: true
        }, {
            path: "Validation/EmailDomainCorrectFormat",
            not: true
        }, false]]
    }, {
        title: "MESSAGE_TITLE__EMAIL_DOMAIN_MISSING",
        description: "MESSAGE_DESCRIPTION__EMAIL_DOMAIN_MISSING",
        type: "Error",
        constraint: [{
            path: "IsSuperAdmin",
            not: true
        }, {
            path: "Validation/EmailDomainPresent",
            not: true
        }]
    }, {
        title: "MESSAGE_PLEASE_ENTER_A_VALID_DATE",
        subtitle: "LABEL_EXPIRY_DATE",
        type: "Error",
        valueStates: [{
            path: "ExpiryDateValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "Validation/ExpiryDate",
            not: true
        }]
    }, {
        title: "VALUE_STATE_CUSTOMER",
        subtitle: "CUSTOMER",
        type: "Error",
        valueStates: [{
            path: "CustomerValueState",
            value: sap.ui.core.ValueState.Error
        }],
        constraint: [{
            path: "Validation/Customer",
            not: true
        }]
    }]
};
});
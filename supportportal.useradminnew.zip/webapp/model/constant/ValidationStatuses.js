sap.ui.define([], function() {
"use strict";

return {
    ValidationRequestUserStatuses: [{
        properties: ["EmailValueState"],
        value: sap.ui.core.ValueState.None,
        constraint: [{
            path: "Validation/Email"
        }, {
            path: "Validation/DuplicateEmail"
        }]
    }, {
        properties: ["EmailValueState"],
        value: sap.ui.core.ValueState.Error,
        constraint: [[{
            path: "Validation/Email"
        }, {
            path: "Validation/DuplicateEmail",
            not: true
        }], {
            path: "Validation/validFormat",
            not: true
        }, {
            path: "Validation/validLength",
            not: true
        }, {
            path: "Validation/SharedEmail",
            not: true
        }, false]
    }, {
        properties: ["emailDomainSuperCloudAdminValueState"],
        value: sap.ui.core.ValueState.Error,
        constraint: [{
            path: "Validation/Email"
        }, {
            path: "Validation/DuplicateEmail",
            not: true
        }, {
            path: "IsSuperAdmin"
        }]
    }, {
        properties: ["emailDomainUserAdminValueState"],
        value: sap.ui.core.ValueState.Error,
        constraint: [{
            path: "Validation/Email"
        }, {
            path: "Validation/DuplicateEmail",
            not: true
        }, {
            path: "IsSuperAdmin",
            not: true
        }]
    }, {
        properties: ["emailDomainUserAdminValueState"],
        value: sap.ui.core.ValueState.None
    }, {
        properties: ["emailDomainSuperCloudAdminValueState"],
        value: sap.ui.core.ValueState.Information,
        constraint: [{
            path: "IsSuperAdmin"
        }, {
            func: "isDomainSelectorSUAFocused"
        }] 
    }, {
        properties: ["emailDomainSuperCloudAdminValueState"],
        value: sap.ui.core.ValueState.Warning, 
        constraint: [{
            path: "Validation/AdditionalNoteNeeded"
        }]
    }, {
        properties: ["emailDomainSuperCloudAdminValueState"],
        value: sap.ui.core.ValueState.Error,
        constraint: [{
            path: "Validation/EmailDomainPresent",
            not: true
        }, {
            path: "Validation/EmailDomainPresent",
            not: true
        }, {
            path: "Validation/EmailDomainPresent",
            not: true
        }, false]
    }, ] 
};
});
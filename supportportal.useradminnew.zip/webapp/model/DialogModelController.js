sap.ui.define([
    "sap/ui/base/Object",
    "sap/ui/model/json/JSONModel"
], function (BaseObject, JSONModel) {
    /**
     * A class used to create and reset dialog model that 
     * simplifies working with dialogs' data and settings
     * @param {sap.support.useradministration.controller.dialog.BaseDialog[]} aDialogs list of dialog controllers' constructors
     * @constructor
     * @class
     * @extends sap.ui.base.Object
     * @public
     * @alias sap.support.useradministration.model.DialogModelController
     */
    return BaseObject.extend("sap.support.useradministration.model.DialogModelController", {
        _oFactories: null,
        _oModel: null,
        
        constructor: function(aDialogs) {
            var oData = {},
                oFactories = {};
            aDialogs.forEach(function(oDialogConstructor) {
                var oPrototype = oDialogConstructor.prototype,
                    Factory = oPrototype.getDataFactory(),
                    sName = oPrototype.getName();
                
                if (sName && Factory) {
                    oFactories[sName] = Factory;
                    oData[sName] = new Factory();
                } else {
                    jQuery.sap.log.error("Dialog name or data factory not provided");
                }
            });
            this._oModel = new JSONModel(oData);
            this._oFactories = oFactories;
        },
        
        /**
         * Returns dialog model
         * @returns {sap.ui.model.json.JSONModel} model
         * @function
         * @public
         */
        getModel: function() {
            return this._oModel;
        },
        
        /**
         * Resets given property in the dialog model if factory exists
         * @param {string} sPropertyName property name
         * @function
         * @public
         */
        resetProperty: function(sPropertyName) {
            var Factory = this._oFactories[sPropertyName],
                sSlash = sPropertyName[0] === "/" ? "" : "/";
            if (Factory) {
                this._oModel.setProperty(sSlash + sPropertyName, new Factory());
            } else {
                jQuery.sap.log.error("Factory '" + sPropertyName + "' not found.");
            }
        }
    });
});